package org.apache.commons.lang3;

import org.apache.commons.lang3.math.NumberUtils;

public class BooleanUtils
{
  public static Boolean and(Boolean[] paramArrayOfBoolean)
  {
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    Boolean localBoolean;
    try
    {
      if (and(ArrayUtils.toPrimitive(paramArrayOfBoolean)))
        localBoolean = Boolean.TRUE;
      else
        localBoolean = Boolean.FALSE;
    }
    catch (NullPointerException localNullPointerException)
    {
      throw new IllegalArgumentException("The array must not contain any null elements");
    }
    return localBoolean;
  }

  public static boolean and(boolean[] paramArrayOfBoolean)
  {
    boolean bool = false;
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    int i = paramArrayOfBoolean.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        bool = true;
      while (paramArrayOfBoolean[j] == 0)
        return bool;
    }
  }

  public static boolean isFalse(Boolean paramBoolean)
  {
    return Boolean.FALSE.equals(paramBoolean);
  }

  public static boolean isNotFalse(Boolean paramBoolean)
  {
    if (isFalse(paramBoolean));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isNotTrue(Boolean paramBoolean)
  {
    if (isTrue(paramBoolean));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isTrue(Boolean paramBoolean)
  {
    return Boolean.TRUE.equals(paramBoolean);
  }

  public static Boolean negate(Boolean paramBoolean)
  {
    Boolean localBoolean;
    if (paramBoolean == null)
      localBoolean = null;
    while (true)
    {
      return localBoolean;
      if (paramBoolean.booleanValue())
        localBoolean = Boolean.FALSE;
      else
        localBoolean = Boolean.TRUE;
    }
  }

  public static Boolean or(Boolean[] paramArrayOfBoolean)
  {
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    Boolean localBoolean;
    try
    {
      if (or(ArrayUtils.toPrimitive(paramArrayOfBoolean)))
        localBoolean = Boolean.TRUE;
      else
        localBoolean = Boolean.FALSE;
    }
    catch (NullPointerException localNullPointerException)
    {
      throw new IllegalArgumentException("The array must not contain any null elements");
    }
    return localBoolean;
  }

  public static boolean or(boolean[] paramArrayOfBoolean)
  {
    boolean bool = false;
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    int i = paramArrayOfBoolean.length;
    for (int j = 0; ; j++)
    {
      if (j >= i);
      while (true)
      {
        return bool;
        if (paramArrayOfBoolean[j] == 0)
          break;
        bool = true;
      }
    }
  }

  public static boolean toBoolean(int paramInt)
  {
    if (paramInt != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean toBoolean(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == paramInt2);
    for (boolean bool = true; ; bool = false)
    {
      return bool;
      if (paramInt1 != paramInt3)
        break;
    }
    throw new IllegalArgumentException("The Integer did not match either specified value");
  }

  public static boolean toBoolean(Boolean paramBoolean)
  {
    if ((paramBoolean != null) && (paramBoolean.booleanValue()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean toBoolean(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3)
  {
    boolean bool = true;
    if (paramInteger1 == null)
      if (paramInteger2 != null);
    while (true)
    {
      return bool;
      if (paramInteger3 != null)
        break;
      bool = false;
      continue;
      if (!paramInteger1.equals(paramInteger2))
      {
        if (!paramInteger1.equals(paramInteger3))
          break;
        bool = false;
      }
    }
    throw new IllegalArgumentException("The Integer did not match either specified value");
  }

  public static boolean toBoolean(String paramString)
  {
    if (toBooleanObject(paramString) == Boolean.TRUE);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean toBoolean(String paramString1, String paramString2, String paramString3)
  {
    boolean bool = true;
    if (paramString1 == paramString2);
    while (true)
    {
      return bool;
      if (paramString1 == paramString3)
      {
        bool = false;
      }
      else
      {
        if (paramString1 == null)
          break;
        if (!paramString1.equals(paramString2))
        {
          if (!paramString1.equals(paramString3))
            break;
          bool = false;
        }
      }
    }
    throw new IllegalArgumentException("The String did not match either specified value");
  }

  public static boolean toBooleanDefaultIfNull(Boolean paramBoolean, boolean paramBoolean1)
  {
    if (paramBoolean == null);
    while (true)
    {
      return paramBoolean1;
      paramBoolean1 = paramBoolean.booleanValue();
    }
  }

  public static Boolean toBooleanObject(int paramInt)
  {
    if (paramInt == 0);
    for (Boolean localBoolean = Boolean.FALSE; ; localBoolean = Boolean.TRUE)
      return localBoolean;
  }

  public static Boolean toBooleanObject(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Boolean localBoolean;
    if (paramInt1 == paramInt2)
      localBoolean = Boolean.TRUE;
    while (true)
    {
      return localBoolean;
      if (paramInt1 == paramInt3)
      {
        localBoolean = Boolean.FALSE;
      }
      else
      {
        if (paramInt1 != paramInt4)
          break;
        localBoolean = null;
      }
    }
    throw new IllegalArgumentException("The Integer did not match any specified value");
  }

  public static Boolean toBooleanObject(Integer paramInteger)
  {
    Boolean localBoolean;
    if (paramInteger == null)
      localBoolean = null;
    while (true)
    {
      return localBoolean;
      if (paramInteger.intValue() == 0)
        localBoolean = Boolean.FALSE;
      else
        localBoolean = Boolean.TRUE;
    }
  }

  public static Boolean toBooleanObject(Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, Integer paramInteger4)
  {
    Boolean localBoolean = null;
    if (paramInteger1 == null)
      if (paramInteger2 == null)
        localBoolean = Boolean.TRUE;
    while (true)
    {
      return localBoolean;
      if (paramInteger3 == null)
        localBoolean = Boolean.FALSE;
      else if (paramInteger4 != null)
        do
        {
          throw new IllegalArgumentException("The Integer did not match any specified value");
          if (paramInteger1.equals(paramInteger2))
          {
            localBoolean = Boolean.TRUE;
            break;
          }
          if (paramInteger1.equals(paramInteger3))
          {
            localBoolean = Boolean.FALSE;
            break;
          }
        }
        while (!paramInteger1.equals(paramInteger4));
    }
  }

  public static Boolean toBooleanObject(String paramString)
  {
    Boolean localBoolean;
    if (paramString == "true")
      localBoolean = Boolean.TRUE;
    while (true)
    {
      return localBoolean;
      if (paramString == null)
      {
        localBoolean = null;
      }
      else
      {
        switch (paramString.length())
        {
        default:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        }
        int i;
        int j;
        int k;
        int m;
        int n;
        do
        {
          int i1;
          int i2;
          int i3;
          int i4;
          do
          {
            int i5;
            int i6;
            int i7;
            do
            {
              int i8;
              int i9;
              do
              {
                int i10;
                do
                {
                  localBoolean = null;
                  break;
                  i10 = paramString.charAt(0);
                  if ((i10 == 121) || (i10 == 89) || (i10 == 116) || (i10 == 84))
                  {
                    localBoolean = Boolean.TRUE;
                    break;
                  }
                }
                while ((i10 != 110) && (i10 != 78) && (i10 != 102) && (i10 != 70));
                localBoolean = Boolean.FALSE;
                break;
                i8 = paramString.charAt(0);
                i9 = paramString.charAt(1);
                if (((i8 == 111) || (i8 == 79)) && ((i9 == 110) || (i9 == 78)))
                {
                  localBoolean = Boolean.TRUE;
                  break;
                }
              }
              while (((i8 != 110) && (i8 != 78)) || ((i9 != 111) && (i9 != 79)));
              localBoolean = Boolean.FALSE;
              break;
              i5 = paramString.charAt(0);
              i6 = paramString.charAt(1);
              i7 = paramString.charAt(2);
              if (((i5 == 121) || (i5 == 89)) && ((i6 == 101) || (i6 == 69)) && ((i7 == 115) || (i7 == 83)))
              {
                localBoolean = Boolean.TRUE;
                break;
              }
            }
            while (((i5 != 111) && (i5 != 79)) || ((i6 != 102) && (i6 != 70)) || ((i7 != 102) && (i7 != 70)));
            localBoolean = Boolean.FALSE;
            break;
            i1 = paramString.charAt(0);
            i2 = paramString.charAt(1);
            i3 = paramString.charAt(2);
            i4 = paramString.charAt(3);
          }
          while (((i1 != 116) && (i1 != 84)) || ((i2 != 114) && (i2 != 82)) || ((i3 != 117) && (i3 != 85)) || ((i4 != 101) && (i4 != 69)));
          localBoolean = Boolean.TRUE;
          break;
          i = paramString.charAt(0);
          j = paramString.charAt(1);
          k = paramString.charAt(2);
          m = paramString.charAt(3);
          n = paramString.charAt(4);
        }
        while (((i != 102) && (i != 70)) || ((j != 97) && (j != 65)) || ((k != 108) && (k != 76)) || ((m != 115) && (m != 83)) || ((n != 101) && (n != 69)));
        localBoolean = Boolean.FALSE;
      }
    }
  }

  public static Boolean toBooleanObject(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    Boolean localBoolean = null;
    if (paramString1 == null)
      if (paramString2 == null)
        localBoolean = Boolean.TRUE;
    while (true)
    {
      return localBoolean;
      if (paramString3 == null)
        localBoolean = Boolean.FALSE;
      else if (paramString4 != null)
        do
        {
          throw new IllegalArgumentException("The String did not match any specified value");
          if (paramString1.equals(paramString2))
          {
            localBoolean = Boolean.TRUE;
            break;
          }
          if (paramString1.equals(paramString3))
          {
            localBoolean = Boolean.FALSE;
            break;
          }
        }
        while (!paramString1.equals(paramString4));
    }
  }

  public static int toInteger(Boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramBoolean == null)
      return paramInt3;
    if (paramBoolean.booleanValue());
    while (true)
    {
      paramInt3 = paramInt1;
      break;
      paramInt1 = paramInt2;
    }
  }

  public static int toInteger(boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 1; ; i = 0)
      return i;
  }

  public static int toInteger(boolean paramBoolean, int paramInt1, int paramInt2)
  {
    if (paramBoolean);
    while (true)
    {
      return paramInt1;
      paramInt1 = paramInt2;
    }
  }

  public static Integer toIntegerObject(Boolean paramBoolean)
  {
    Integer localInteger;
    if (paramBoolean == null)
      localInteger = null;
    while (true)
    {
      return localInteger;
      if (paramBoolean.booleanValue())
        localInteger = NumberUtils.INTEGER_ONE;
      else
        localInteger = NumberUtils.INTEGER_ZERO;
    }
  }

  public static Integer toIntegerObject(Boolean paramBoolean, Integer paramInteger1, Integer paramInteger2, Integer paramInteger3)
  {
    if (paramBoolean == null)
      return paramInteger3;
    if (paramBoolean.booleanValue());
    while (true)
    {
      paramInteger3 = paramInteger1;
      break;
      paramInteger1 = paramInteger2;
    }
  }

  public static Integer toIntegerObject(boolean paramBoolean)
  {
    if (paramBoolean);
    for (Integer localInteger = NumberUtils.INTEGER_ONE; ; localInteger = NumberUtils.INTEGER_ZERO)
      return localInteger;
  }

  public static Integer toIntegerObject(boolean paramBoolean, Integer paramInteger1, Integer paramInteger2)
  {
    if (paramBoolean);
    while (true)
    {
      return paramInteger1;
      paramInteger1 = paramInteger2;
    }
  }

  public static String toString(Boolean paramBoolean, String paramString1, String paramString2, String paramString3)
  {
    if (paramBoolean == null)
      return paramString3;
    if (paramBoolean.booleanValue());
    while (true)
    {
      paramString3 = paramString1;
      break;
      paramString1 = paramString2;
    }
  }

  public static String toString(boolean paramBoolean, String paramString1, String paramString2)
  {
    if (paramBoolean);
    while (true)
    {
      return paramString1;
      paramString1 = paramString2;
    }
  }

  public static String toStringOnOff(Boolean paramBoolean)
  {
    return toString(paramBoolean, "on", "off", null);
  }

  public static String toStringOnOff(boolean paramBoolean)
  {
    return toString(paramBoolean, "on", "off");
  }

  public static String toStringTrueFalse(Boolean paramBoolean)
  {
    return toString(paramBoolean, "true", "false", null);
  }

  public static String toStringTrueFalse(boolean paramBoolean)
  {
    return toString(paramBoolean, "true", "false");
  }

  public static String toStringYesNo(Boolean paramBoolean)
  {
    return toString(paramBoolean, "yes", "no", null);
  }

  public static String toStringYesNo(boolean paramBoolean)
  {
    return toString(paramBoolean, "yes", "no");
  }

  public static Boolean xor(Boolean[] paramArrayOfBoolean)
  {
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    Boolean localBoolean;
    try
    {
      if (xor(ArrayUtils.toPrimitive(paramArrayOfBoolean)))
        localBoolean = Boolean.TRUE;
      else
        localBoolean = Boolean.FALSE;
    }
    catch (NullPointerException localNullPointerException)
    {
      throw new IllegalArgumentException("The array must not contain any null elements");
    }
    return localBoolean;
  }

  public static boolean xor(boolean[] paramArrayOfBoolean)
  {
    boolean bool = false;
    if (paramArrayOfBoolean == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfBoolean.length == 0)
      throw new IllegalArgumentException("Array is empty");
    int i = 0;
    int j = paramArrayOfBoolean.length;
    for (int k = 0; ; k++)
    {
      if (k >= j)
        if (i == 1)
          bool = true;
      do
      {
        return bool;
        if (paramArrayOfBoolean[k] == 0)
          break;
      }
      while (i >= 1);
      i++;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.BooleanUtils
 * JD-Core Version:    0.6.2
 */