package org.apache.commons.lang3.tuple;

import java.io.Serializable;
import java.util.Map.Entry;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.builder.CompareToBuilder;

public abstract class Pair<L, R>
  implements Map.Entry<L, R>, Comparable<Pair<L, R>>, Serializable
{
  private static final long serialVersionUID = 4954918890077093841L;

  public static <L, R> Pair<L, R> of(L paramL, R paramR)
  {
    return new ImmutablePair(paramL, paramR);
  }

  public int compareTo(Pair<L, R> paramPair)
  {
    return new CompareToBuilder().append(getLeft(), paramPair.getLeft()).append(getRight(), paramPair.getRight()).toComparison();
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this);
    while (true)
    {
      return bool;
      if ((paramObject instanceof Map.Entry))
      {
        Map.Entry localEntry = (Map.Entry)paramObject;
        if ((!ObjectUtils.equals(getKey(), localEntry.getKey())) || (!ObjectUtils.equals(getValue(), localEntry.getValue())))
          bool = false;
      }
      else
      {
        bool = false;
      }
    }
  }

  public final L getKey()
  {
    return getLeft();
  }

  public abstract L getLeft();

  public abstract R getRight();

  public R getValue()
  {
    return getRight();
  }

  public int hashCode()
  {
    int i = 0;
    int j;
    if (getKey() == null)
    {
      j = 0;
      if (getValue() != null)
        break label33;
    }
    while (true)
    {
      return j ^ i;
      j = getKey().hashCode();
      break;
      label33: i = getValue().hashCode();
    }
  }

  public String toString()
  {
    return '(' + getLeft() + ',' + getRight() + ')';
  }

  public String toString(String paramString)
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = getLeft();
    arrayOfObject[1] = getRight();
    return String.format(paramString, arrayOfObject);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.tuple.Pair
 * JD-Core Version:    0.6.2
 */