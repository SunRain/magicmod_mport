package org.apache.commons.lang3;

public class CharSequenceUtils
{
  static int indexOf(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    if ((paramCharSequence instanceof String))
    {
      j = ((String)paramCharSequence).indexOf(paramInt1, paramInt2);
      return j;
    }
    int i = paramCharSequence.length();
    if (paramInt2 < 0)
      paramInt2 = 0;
    for (int j = paramInt2; ; j++)
    {
      if (j >= i)
      {
        j = -1;
        break;
      }
      if (paramCharSequence.charAt(j) == paramInt1)
        break;
    }
  }

  static int indexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    return paramCharSequence1.toString().indexOf(paramCharSequence2.toString(), paramInt);
  }

  static int lastIndexOf(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    if ((paramCharSequence instanceof String));
    int i;
    for (int j = ((String)paramCharSequence).lastIndexOf(paramInt1, paramInt2); ; j = -1)
    {
      return j;
      i = paramCharSequence.length();
      if (paramInt2 >= 0)
        break;
    }
    if (paramInt2 >= i)
      paramInt2 = i - 1;
    for (j = paramInt2; ; j--)
    {
      if (j < 0)
      {
        j = -1;
        break;
      }
      if (paramCharSequence.charAt(j) == paramInt1)
        break;
    }
  }

  static int lastIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    return paramCharSequence1.toString().lastIndexOf(paramCharSequence2.toString(), paramInt);
  }

  static boolean regionMatches(CharSequence paramCharSequence1, boolean paramBoolean, int paramInt1, CharSequence paramCharSequence2, int paramInt2, int paramInt3)
  {
    if (((paramCharSequence1 instanceof String)) && ((paramCharSequence2 instanceof String)));
    for (boolean bool = ((String)paramCharSequence1).regionMatches(paramBoolean, paramInt1, (String)paramCharSequence2, paramInt2, paramInt3); ; bool = paramCharSequence1.toString().regionMatches(paramBoolean, paramInt1, paramCharSequence2.toString(), paramInt2, paramInt3))
      return bool;
  }

  public static CharSequence subSequence(CharSequence paramCharSequence, int paramInt)
  {
    if (paramCharSequence == null);
    for (CharSequence localCharSequence = null; ; localCharSequence = paramCharSequence.subSequence(paramInt, paramCharSequence.length()))
      return localCharSequence;
  }

  static char[] toCharArray(CharSequence paramCharSequence)
  {
    char[] arrayOfChar;
    if ((paramCharSequence instanceof String))
      arrayOfChar = ((String)paramCharSequence).toCharArray();
    while (true)
    {
      return arrayOfChar;
      int i = paramCharSequence.length();
      arrayOfChar = new char[paramCharSequence.length()];
      for (int j = 0; j < i; j++)
        arrayOfChar[j] = paramCharSequence.charAt(j);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.CharSequenceUtils
 * JD-Core Version:    0.6.2
 */