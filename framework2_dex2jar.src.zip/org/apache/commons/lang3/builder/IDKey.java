package org.apache.commons.lang3.builder;

final class IDKey
{
  private final int id;
  private final Object value;

  public IDKey(Object paramObject)
  {
    this.id = System.identityHashCode(paramObject);
    this.value = paramObject;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (!(paramObject instanceof IDKey));
    while (true)
    {
      return bool;
      IDKey localIDKey = (IDKey)paramObject;
      if ((this.id == localIDKey.id) && (this.value == localIDKey.value))
        bool = true;
    }
  }

  public int hashCode()
  {
    return this.id;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.builder.IDKey
 * JD-Core Version:    0.6.2
 */