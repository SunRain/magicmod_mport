package org.apache.commons.lang3.event;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.lang3.reflect.MethodUtils;

public class EventUtils
{
  public static <L> void addEventListener(Object paramObject, Class<L> paramClass, L paramL)
  {
    try
    {
      MethodUtils.invokeMethod(paramObject, "add" + paramClass.getSimpleName(), new Object[] { paramL });
      return;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      throw new IllegalArgumentException("Class " + paramObject.getClass().getName() + " does not have a public add" + paramClass.getSimpleName() + " method which takes a parameter of type " + paramClass.getName() + ".");
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      throw new IllegalArgumentException("Class " + paramObject.getClass().getName() + " does not have an accessible add" + paramClass.getSimpleName() + " method which takes a parameter of type " + paramClass.getName() + ".");
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      throw new RuntimeException("Unable to add listener.", localInvocationTargetException.getCause());
    }
  }

  public static <L> void bindEventsToMethod(Object paramObject1, String paramString, Object paramObject2, Class<L> paramClass, String[] paramArrayOfString)
  {
    addEventListener(paramObject2, paramClass, paramClass.cast(Proxy.newProxyInstance(paramObject1.getClass().getClassLoader(), new Class[] { paramClass }, new EventBindingInvocationHandler(paramObject1, paramString, paramArrayOfString))));
  }

  private static class EventBindingInvocationHandler
    implements InvocationHandler
  {
    private final Set<String> eventTypes;
    private final String methodName;
    private final Object target;

    EventBindingInvocationHandler(Object paramObject, String paramString, String[] paramArrayOfString)
    {
      this.target = paramObject;
      this.methodName = paramString;
      this.eventTypes = new HashSet(Arrays.asList(paramArrayOfString));
    }

    private boolean hasMatchingParametersMethod(Method paramMethod)
    {
      if (MethodUtils.getAccessibleMethod(this.target.getClass(), this.methodName, paramMethod.getParameterTypes()) != null);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
      throws Throwable
    {
      Object localObject;
      if ((this.eventTypes.isEmpty()) || (this.eventTypes.contains(paramMethod.getName())))
        if (hasMatchingParametersMethod(paramMethod))
          localObject = MethodUtils.invokeMethod(this.target, this.methodName, paramArrayOfObject);
      while (true)
      {
        return localObject;
        localObject = MethodUtils.invokeMethod(this.target, this.methodName, new Object[0]);
        continue;
        localObject = null;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.event.EventUtils
 * JD-Core Version:    0.6.2
 */