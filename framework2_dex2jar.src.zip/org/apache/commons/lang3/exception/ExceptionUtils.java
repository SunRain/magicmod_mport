package org.apache.commons.lang3.exception;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;

public class ExceptionUtils
{
  private static final String[] CAUSE_METHOD_NAMES = { "getCause", "getNextException", "getTargetException", "getException", "getSourceException", "getRootCause", "getCausedByException", "getNested", "getLinkedException", "getNestedException", "getLinkedCause", "getThrowable" };
  static final String WRAPPED_MARKER = " [wrapped] ";

  @Deprecated
  public static Throwable getCause(Throwable paramThrowable)
  {
    return getCause(paramThrowable, CAUSE_METHOD_NAMES);
  }

  @Deprecated
  public static Throwable getCause(Throwable paramThrowable, String[] paramArrayOfString)
  {
    Throwable localThrowable;
    if (paramThrowable == null)
    {
      localThrowable = null;
      return localThrowable;
    }
    if (paramArrayOfString == null)
      paramArrayOfString = CAUSE_METHOD_NAMES;
    int i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        localThrowable = null;
        break;
      }
      String str = paramArrayOfString[j];
      if (str != null)
      {
        localThrowable = getCauseUsingMethodName(paramThrowable, str);
        if (localThrowable != null)
          break;
      }
    }
  }

  private static Throwable getCauseUsingMethodName(Throwable paramThrowable, String paramString)
  {
    Object localObject = null;
    try
    {
      Method localMethod = paramThrowable.getClass().getMethod(paramString, new Class[0]);
      localObject = localMethod;
      label19: if ((localObject != null) && (Throwable.class.isAssignableFrom(localObject.getReturnType())));
      try
      {
        localThrowable = (Throwable)localObject.invoke(paramThrowable, new Object[0]);
        return localThrowable;
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        while (true)
          Throwable localThrowable = null;
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        break label54;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        label54: break label54;
      }
    }
    catch (SecurityException localSecurityException)
    {
      break label19;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      break label19;
    }
  }

  @Deprecated
  public static String[] getDefaultCauseMethodNames()
  {
    return (String[])ArrayUtils.clone(CAUSE_METHOD_NAMES);
  }

  public static String getMessage(Throwable paramThrowable)
  {
    if (paramThrowable == null);
    String str1;
    String str2;
    for (String str3 = ""; ; str3 = str1 + ": " + StringUtils.defaultString(str2))
    {
      return str3;
      str1 = ClassUtils.getShortClassName(paramThrowable, null);
      str2 = paramThrowable.getMessage();
    }
  }

  public static Throwable getRootCause(Throwable paramThrowable)
  {
    List localList = getThrowableList(paramThrowable);
    if (localList.size() < 2);
    for (Throwable localThrowable = null; ; localThrowable = (Throwable)localList.get(-1 + localList.size()))
      return localThrowable;
  }

  public static String getRootCauseMessage(Throwable paramThrowable)
  {
    Throwable localThrowable = getRootCause(paramThrowable);
    if (localThrowable == null)
      localThrowable = paramThrowable;
    return getMessage(localThrowable);
  }

  public static String[] getRootCauseStackTrace(Throwable paramThrowable)
  {
    if (paramThrowable == null);
    Throwable[] arrayOfThrowable;
    int i;
    ArrayList localArrayList;
    List localList1;
    int j;
    for (String[] arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY; ; arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]))
    {
      return arrayOfString;
      arrayOfThrowable = getThrowables(paramThrowable);
      i = arrayOfThrowable.length;
      localArrayList = new ArrayList();
      localList1 = getStackFrameList(arrayOfThrowable[(i - 1)]);
      j = i;
      j--;
      if (j >= 0)
        break;
    }
    List localList2 = localList1;
    if (j != 0)
    {
      localList1 = getStackFrameList(arrayOfThrowable[(j - 1)]);
      removeCommonFrames(localList2, localList1);
    }
    if (j == i - 1)
      localArrayList.add(arrayOfThrowable[j].toString());
    while (true)
    {
      for (int k = 0; k < localList2.size(); k++)
        localArrayList.add((String)localList2.get(k));
      break;
      localArrayList.add(" [wrapped] " + arrayOfThrowable[j].toString());
    }
  }

  static List<String> getStackFrameList(Throwable paramThrowable)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(getStackTrace(paramThrowable), SystemUtils.LINE_SEPARATOR);
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    if (!localStringTokenizer.hasMoreTokens());
    while (true)
    {
      return localArrayList;
      String str = localStringTokenizer.nextToken();
      int j = str.indexOf("at");
      if ((j != -1) && (str.substring(0, j).trim().length() == 0))
      {
        i = 1;
        localArrayList.add(str);
        break;
      }
      if (i == 0)
        break;
    }
  }

  static String[] getStackFrames(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, SystemUtils.LINE_SEPARATOR);
    ArrayList localArrayList = new ArrayList();
    while (true)
    {
      if (!localStringTokenizer.hasMoreTokens())
        return (String[])localArrayList.toArray(new String[localArrayList.size()]);
      localArrayList.add(localStringTokenizer.nextToken());
    }
  }

  public static String[] getStackFrames(Throwable paramThrowable)
  {
    if (paramThrowable == null);
    for (String[] arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY; ; arrayOfString = getStackFrames(getStackTrace(paramThrowable)))
      return arrayOfString;
  }

  public static String getStackTrace(Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter, true));
    return localStringWriter.getBuffer().toString();
  }

  public static int getThrowableCount(Throwable paramThrowable)
  {
    return getThrowableList(paramThrowable).size();
  }

  public static List<Throwable> getThrowableList(Throwable paramThrowable)
  {
    ArrayList localArrayList = new ArrayList();
    while (true)
    {
      if ((paramThrowable == null) || (localArrayList.contains(paramThrowable)))
        return localArrayList;
      localArrayList.add(paramThrowable);
      paramThrowable = getCause(paramThrowable);
    }
  }

  public static Throwable[] getThrowables(Throwable paramThrowable)
  {
    List localList = getThrowableList(paramThrowable);
    return (Throwable[])localList.toArray(new Throwable[localList.size()]);
  }

  private static int indexOf(Throwable paramThrowable, Class<?> paramClass, int paramInt, boolean paramBoolean)
  {
    if ((paramThrowable == null) || (paramClass == null));
    Throwable[] arrayOfThrowable;
    for (int i = -1; ; i = -1)
    {
      return i;
      if (paramInt < 0)
        paramInt = 0;
      arrayOfThrowable = getThrowables(paramThrowable);
      if (paramInt < arrayOfThrowable.length)
        break;
    }
    if (paramBoolean)
    {
      i = paramInt;
      label46: if (i < arrayOfThrowable.length);
    }
    label111: 
    while (true)
    {
      i = -1;
      break;
      if (paramClass.isAssignableFrom(arrayOfThrowable[i].getClass()))
        break;
      i++;
      break label46;
      for (i = paramInt; ; i++)
      {
        if (i >= arrayOfThrowable.length)
          break label111;
        if (paramClass.equals(arrayOfThrowable[i].getClass()))
          break;
      }
    }
  }

  public static int indexOfThrowable(Throwable paramThrowable, Class<?> paramClass)
  {
    return indexOf(paramThrowable, paramClass, 0, false);
  }

  public static int indexOfThrowable(Throwable paramThrowable, Class<?> paramClass, int paramInt)
  {
    return indexOf(paramThrowable, paramClass, paramInt, false);
  }

  public static int indexOfType(Throwable paramThrowable, Class<?> paramClass)
  {
    return indexOf(paramThrowable, paramClass, 0, true);
  }

  public static int indexOfType(Throwable paramThrowable, Class<?> paramClass, int paramInt)
  {
    return indexOf(paramThrowable, paramClass, paramInt, true);
  }

  public static void printRootCauseStackTrace(Throwable paramThrowable)
  {
    printRootCauseStackTrace(paramThrowable, System.err);
  }

  public static void printRootCauseStackTrace(Throwable paramThrowable, PrintStream paramPrintStream)
  {
    if (paramThrowable == null)
      return;
    if (paramPrintStream == null)
      throw new IllegalArgumentException("The PrintStream must not be null");
    String[] arrayOfString = getRootCauseStackTrace(paramThrowable);
    int i = arrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        paramPrintStream.flush();
        break;
      }
      paramPrintStream.println(arrayOfString[j]);
    }
  }

  public static void printRootCauseStackTrace(Throwable paramThrowable, PrintWriter paramPrintWriter)
  {
    if (paramThrowable == null)
      return;
    if (paramPrintWriter == null)
      throw new IllegalArgumentException("The PrintWriter must not be null");
    String[] arrayOfString = getRootCauseStackTrace(paramThrowable);
    int i = arrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        paramPrintWriter.flush();
        break;
      }
      paramPrintWriter.println(arrayOfString[j]);
    }
  }

  public static void removeCommonFrames(List<String> paramList1, List<String> paramList2)
  {
    if ((paramList1 == null) || (paramList2 == null))
      throw new IllegalArgumentException("The List must not be null");
    int i = -1 + paramList1.size();
    for (int j = -1 + paramList2.size(); ; j--)
    {
      if ((i < 0) || (j < 0))
        return;
      if (((String)paramList1.get(i)).equals((String)paramList2.get(j)))
        paramList1.remove(i);
      i--;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.exception.ExceptionUtils
 * JD-Core Version:    0.6.2
 */