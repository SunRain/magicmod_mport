package org.apache.commons.lang3.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

public class DefaultExceptionContext
  implements ExceptionContext, Serializable
{
  private static final long serialVersionUID = 20110706L;
  private final List<Pair<String, Object>> contextValues = new ArrayList();

  public DefaultExceptionContext addContextValue(String paramString, Object paramObject)
  {
    this.contextValues.add(new ImmutablePair(paramString, paramObject));
    return this;
  }

  public List<Pair<String, Object>> getContextEntries()
  {
    return this.contextValues;
  }

  public Set<String> getContextLabels()
  {
    HashSet localHashSet = new HashSet();
    Iterator localIterator = this.contextValues.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localHashSet;
      localHashSet.add((String)((Pair)localIterator.next()).getKey());
    }
  }

  public List<Object> getContextValues(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.contextValues.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localArrayList;
      Pair localPair = (Pair)localIterator.next();
      if (StringUtils.equals(paramString, (CharSequence)localPair.getKey()))
        localArrayList.add(localPair.getValue());
    }
  }

  public Object getFirstContextValue(String paramString)
  {
    Iterator localIterator = this.contextValues.iterator();
    if (!localIterator.hasNext());
    Pair localPair;
    for (Object localObject = null; ; localObject = localPair.getValue())
    {
      return localObject;
      localPair = (Pair)localIterator.next();
      if (!StringUtils.equals(paramString, (CharSequence)localPair.getKey()))
        break;
    }
  }

  public String getFormattedExceptionMessage(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder(256);
    if (paramString != null)
      localStringBuilder.append(paramString);
    int i;
    Iterator localIterator;
    if (this.contextValues.size() > 0)
    {
      if (localStringBuilder.length() > 0)
        localStringBuilder.append('\n');
      localStringBuilder.append("Exception Context:\n");
      i = 0;
      localIterator = this.contextValues.iterator();
      if (!localIterator.hasNext())
        localStringBuilder.append("---------------------------------");
    }
    else
    {
      return localStringBuilder.toString();
    }
    Pair localPair = (Pair)localIterator.next();
    localStringBuilder.append("\t[");
    i++;
    localStringBuilder.append(i);
    localStringBuilder.append(':');
    localStringBuilder.append((String)localPair.getKey());
    localStringBuilder.append("=");
    Object localObject = localPair.getValue();
    if (localObject == null)
      localStringBuilder.append("null");
    while (true)
    {
      localStringBuilder.append("]\n");
      break;
      try
      {
        String str2 = localObject.toString();
        str1 = str2;
        localStringBuilder.append(str1);
      }
      catch (Exception localException)
      {
        while (true)
          String str1 = "Exception thrown on toString(): " + ExceptionUtils.getStackTrace(localException);
      }
    }
  }

  public DefaultExceptionContext setContextValue(String paramString, Object paramObject)
  {
    Iterator localIterator = this.contextValues.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        addContextValue(paramString, paramObject);
        return this;
      }
      if (StringUtils.equals(paramString, (CharSequence)((Pair)localIterator.next()).getKey()))
        localIterator.remove();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.exception.DefaultExceptionContext
 * JD-Core Version:    0.6.2
 */