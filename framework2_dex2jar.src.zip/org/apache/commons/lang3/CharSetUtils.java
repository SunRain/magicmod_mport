package org.apache.commons.lang3;

public class CharSetUtils
{
  public static int count(String paramString, String[] paramArrayOfString)
  {
    int i = 0;
    int j;
    if ((StringUtils.isEmpty(paramString)) || (deepEmpty(paramArrayOfString)))
      j = 0;
    while (true)
    {
      return j;
      CharSet localCharSet = CharSet.getInstance(paramArrayOfString);
      j = 0;
      char[] arrayOfChar = paramString.toCharArray();
      int k = arrayOfChar.length;
      while (i < k)
      {
        if (localCharSet.contains(arrayOfChar[i]))
          j++;
        i++;
      }
    }
  }

  private static boolean deepEmpty(String[] paramArrayOfString)
  {
    boolean bool = false;
    int i;
    if (paramArrayOfString != null)
      i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        bool = true;
      while (StringUtils.isNotEmpty(paramArrayOfString[j]))
        return bool;
    }
  }

  public static String delete(String paramString, String[] paramArrayOfString)
  {
    if ((StringUtils.isEmpty(paramString)) || (deepEmpty(paramArrayOfString)));
    while (true)
    {
      return paramString;
      paramString = modify(paramString, paramArrayOfString, false);
    }
  }

  public static String keep(String paramString, String[] paramArrayOfString)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      if ((paramString.length() == 0) || (deepEmpty(paramArrayOfString)))
        str = "";
      else
        str = modify(paramString, paramArrayOfString, true);
    }
  }

  private static String modify(String paramString, String[] paramArrayOfString, boolean paramBoolean)
  {
    CharSet localCharSet = CharSet.getInstance(paramArrayOfString);
    StringBuilder localStringBuilder = new StringBuilder(paramString.length());
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localStringBuilder.toString();
      if (localCharSet.contains(arrayOfChar[j]) == paramBoolean)
        localStringBuilder.append(arrayOfChar[j]);
    }
  }

  public static String squeeze(String paramString, String[] paramArrayOfString)
  {
    if ((StringUtils.isEmpty(paramString)) || (deepEmpty(paramArrayOfString)));
    CharSet localCharSet;
    StringBuilder localStringBuilder;
    char[] arrayOfChar;
    int j;
    int k;
    while (true)
    {
      return paramString;
      localCharSet = CharSet.getInstance(paramArrayOfString);
      localStringBuilder = new StringBuilder(paramString.length());
      arrayOfChar = paramString.toCharArray();
      int i = arrayOfChar.length;
      j = 32;
      k = 0;
      if (k < i)
        break;
      paramString = localStringBuilder.toString();
    }
    char c = arrayOfChar[k];
    if ((c == j) && (k != 0) && (localCharSet.contains(c)));
    while (true)
    {
      k++;
      break;
      localStringBuilder.append(c);
      j = c;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.CharSetUtils
 * JD-Core Version:    0.6.2
 */