package org.apache.commons.lang3;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectStreamClass;
import java.io.Serializable;

public class SerializationUtils
{
  // ERROR //
  public static <T extends Serializable> T clone(T paramT)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull +9 -> 10
    //   4: aconst_null
    //   5: astore 8
    //   7: aload 8
    //   9: areturn
    //   10: new 16	java/io/ByteArrayInputStream
    //   13: dup
    //   14: aload_0
    //   15: invokestatic 20	org/apache/commons/lang3/SerializationUtils:serialize	(Ljava/io/Serializable;)[B
    //   18: invokespecial 23	java/io/ByteArrayInputStream:<init>	([B)V
    //   21: astore_1
    //   22: aconst_null
    //   23: astore_2
    //   24: new 25	org/apache/commons/lang3/SerializationUtils$ClassLoaderAwareObjectInputStream
    //   27: dup
    //   28: aload_1
    //   29: aload_0
    //   30: invokevirtual 29	java/lang/Object:getClass	()Ljava/lang/Class;
    //   33: invokevirtual 35	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   36: invokespecial 38	org/apache/commons/lang3/SerializationUtils$ClassLoaderAwareObjectInputStream:<init>	(Ljava/io/InputStream;Ljava/lang/ClassLoader;)V
    //   39: astore_3
    //   40: aload_3
    //   41: invokevirtual 42	org/apache/commons/lang3/SerializationUtils$ClassLoaderAwareObjectInputStream:readObject	()Ljava/lang/Object;
    //   44: checkcast 44	java/io/Serializable
    //   47: astore 8
    //   49: aload_3
    //   50: ifnull -43 -> 7
    //   53: aload_3
    //   54: invokevirtual 47	org/apache/commons/lang3/SerializationUtils$ClassLoaderAwareObjectInputStream:close	()V
    //   57: goto -50 -> 7
    //   60: astore 9
    //   62: new 49	org/apache/commons/lang3/SerializationException
    //   65: dup
    //   66: ldc 51
    //   68: aload 9
    //   70: invokespecial 54	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   73: athrow
    //   74: astore 4
    //   76: new 49	org/apache/commons/lang3/SerializationException
    //   79: dup
    //   80: ldc 56
    //   82: aload 4
    //   84: invokespecial 54	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   87: athrow
    //   88: astore 5
    //   90: aload_2
    //   91: ifnull +7 -> 98
    //   94: aload_2
    //   95: invokevirtual 47	org/apache/commons/lang3/SerializationUtils$ClassLoaderAwareObjectInputStream:close	()V
    //   98: aload 5
    //   100: athrow
    //   101: astore 7
    //   103: new 49	org/apache/commons/lang3/SerializationException
    //   106: dup
    //   107: ldc 58
    //   109: aload 7
    //   111: invokespecial 54	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   114: athrow
    //   115: astore 6
    //   117: new 49	org/apache/commons/lang3/SerializationException
    //   120: dup
    //   121: ldc 51
    //   123: aload 6
    //   125: invokespecial 54	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   128: athrow
    //   129: astore 5
    //   131: aload_3
    //   132: astore_2
    //   133: goto -43 -> 90
    //   136: astore 7
    //   138: aload_3
    //   139: astore_2
    //   140: goto -37 -> 103
    //   143: astore 4
    //   145: aload_3
    //   146: astore_2
    //   147: goto -71 -> 76
    //
    // Exception table:
    //   from	to	target	type
    //   53	57	60	java/io/IOException
    //   24	40	74	java/lang/ClassNotFoundException
    //   24	40	88	finally
    //   76	88	88	finally
    //   103	115	88	finally
    //   24	40	101	java/io/IOException
    //   94	98	115	java/io/IOException
    //   40	49	129	finally
    //   40	49	136	java/io/IOException
    //   40	49	143	java/lang/ClassNotFoundException
  }

  // ERROR //
  public static Object deserialize(InputStream paramInputStream)
  {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull +13 -> 14
    //   4: new 62	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc 64
    //   10: invokespecial 67	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   13: athrow
    //   14: aconst_null
    //   15: astore_1
    //   16: new 69	java/io/ObjectInputStream
    //   19: dup
    //   20: aload_0
    //   21: invokespecial 72	java/io/ObjectInputStream:<init>	(Ljava/io/InputStream;)V
    //   24: astore_2
    //   25: aload_2
    //   26: invokevirtual 73	java/io/ObjectInputStream:readObject	()Ljava/lang/Object;
    //   29: astore 7
    //   31: aload_2
    //   32: ifnull +7 -> 39
    //   35: aload_2
    //   36: invokevirtual 74	java/io/ObjectInputStream:close	()V
    //   39: aload 7
    //   41: areturn
    //   42: astore_3
    //   43: new 49	org/apache/commons/lang3/SerializationException
    //   46: dup
    //   47: aload_3
    //   48: invokespecial 77	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/Throwable;)V
    //   51: athrow
    //   52: astore 4
    //   54: aload_1
    //   55: ifnull +7 -> 62
    //   58: aload_1
    //   59: invokevirtual 74	java/io/ObjectInputStream:close	()V
    //   62: aload 4
    //   64: athrow
    //   65: astore 6
    //   67: new 49	org/apache/commons/lang3/SerializationException
    //   70: dup
    //   71: aload 6
    //   73: invokespecial 77	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/Throwable;)V
    //   76: athrow
    //   77: astore 8
    //   79: goto -40 -> 39
    //   82: astore 5
    //   84: goto -22 -> 62
    //   87: astore 4
    //   89: aload_2
    //   90: astore_1
    //   91: goto -37 -> 54
    //   94: astore 6
    //   96: aload_2
    //   97: astore_1
    //   98: goto -31 -> 67
    //   101: astore_3
    //   102: aload_2
    //   103: astore_1
    //   104: goto -61 -> 43
    //
    // Exception table:
    //   from	to	target	type
    //   16	25	42	java/lang/ClassNotFoundException
    //   16	25	52	finally
    //   43	52	52	finally
    //   67	77	52	finally
    //   16	25	65	java/io/IOException
    //   35	39	77	java/io/IOException
    //   58	62	82	java/io/IOException
    //   25	31	87	finally
    //   25	31	94	java/io/IOException
    //   25	31	101	java/lang/ClassNotFoundException
  }

  public static Object deserialize(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
      throw new IllegalArgumentException("The byte[] must not be null");
    return deserialize(new ByteArrayInputStream(paramArrayOfByte));
  }

  // ERROR //
  public static void serialize(Serializable paramSerializable, java.io.OutputStream paramOutputStream)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +13 -> 14
    //   4: new 62	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc 85
    //   10: invokespecial 67	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   13: athrow
    //   14: aconst_null
    //   15: astore_2
    //   16: new 87	java/io/ObjectOutputStream
    //   19: dup
    //   20: aload_1
    //   21: invokespecial 90	java/io/ObjectOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 94	java/io/ObjectOutputStream:writeObject	(Ljava/lang/Object;)V
    //   30: aload_3
    //   31: ifnull +7 -> 38
    //   34: aload_3
    //   35: invokevirtual 95	java/io/ObjectOutputStream:close	()V
    //   38: return
    //   39: astore 4
    //   41: new 49	org/apache/commons/lang3/SerializationException
    //   44: dup
    //   45: aload 4
    //   47: invokespecial 77	org/apache/commons/lang3/SerializationException:<init>	(Ljava/lang/Throwable;)V
    //   50: athrow
    //   51: astore 5
    //   53: aload_2
    //   54: ifnull +7 -> 61
    //   57: aload_2
    //   58: invokevirtual 95	java/io/ObjectOutputStream:close	()V
    //   61: aload 5
    //   63: athrow
    //   64: astore 6
    //   66: goto -5 -> 61
    //   69: astore 7
    //   71: goto -33 -> 38
    //   74: astore 5
    //   76: aload_3
    //   77: astore_2
    //   78: goto -25 -> 53
    //   81: astore 4
    //   83: aload_3
    //   84: astore_2
    //   85: goto -44 -> 41
    //
    // Exception table:
    //   from	to	target	type
    //   16	25	39	java/io/IOException
    //   16	25	51	finally
    //   41	51	51	finally
    //   57	61	64	java/io/IOException
    //   34	38	69	java/io/IOException
    //   25	30	74	finally
    //   25	30	81	java/io/IOException
  }

  public static byte[] serialize(Serializable paramSerializable)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(512);
    serialize(paramSerializable, localByteArrayOutputStream);
    return localByteArrayOutputStream.toByteArray();
  }

  static class ClassLoaderAwareObjectInputStream extends ObjectInputStream
  {
    private ClassLoader classLoader;

    public ClassLoaderAwareObjectInputStream(InputStream paramInputStream, ClassLoader paramClassLoader)
      throws IOException
    {
      super();
      this.classLoader = paramClassLoader;
    }

    protected Class<?> resolveClass(ObjectStreamClass paramObjectStreamClass)
      throws IOException, ClassNotFoundException
    {
      String str = paramObjectStreamClass.getName();
      try
      {
        Class localClass2 = Class.forName(str, false, this.classLoader);
        localClass1 = localClass2;
        return localClass1;
      }
      catch (ClassNotFoundException localClassNotFoundException)
      {
        while (true)
          Class localClass1 = Class.forName(str, false, Thread.currentThread().getContextClassLoader());
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.SerializationUtils
 * JD-Core Version:    0.6.2
 */