package org.apache.commons.lang3;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringUtils
{
  public static final String EMPTY = "";
  public static final int INDEX_NOT_FOUND = -1;
  private static final int PAD_LIMIT = 8192;
  private static final Pattern WHITESPACE_BLOCK = Pattern.compile("\\s+");

  public static String abbreviate(String paramString, int paramInt)
  {
    return abbreviate(paramString, 0, paramInt);
  }

  public static String abbreviate(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      if (paramInt2 < 4)
        throw new IllegalArgumentException("Minimum abbreviation width is 4");
      if (paramString.length() > paramInt2)
      {
        if (paramInt1 > paramString.length())
          paramInt1 = paramString.length();
        if (paramString.length() - paramInt1 < paramInt2 - 3)
          paramInt1 = paramString.length() - (paramInt2 - 3);
        if (paramInt1 <= 4)
        {
          paramString = paramString.substring(0, paramInt2 - 3) + "...";
        }
        else
        {
          if (paramInt2 < 7)
            throw new IllegalArgumentException("Minimum abbreviation width with offset is 7");
          if (-3 + (paramInt1 + paramInt2) < paramString.length())
            paramString = "..." + abbreviate(paramString.substring(paramInt1), paramInt2 - 3);
          else
            paramString = "..." + paramString.substring(paramString.length() - (paramInt2 - 3));
        }
      }
    }
  }

  public static String abbreviateMiddle(String paramString1, String paramString2, int paramInt)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      if ((paramInt < paramString1.length()) && (paramInt >= 2 + paramString2.length()))
      {
        int i = paramInt - paramString2.length();
        int j = i / 2 + i % 2;
        int k = paramString1.length() - i / 2;
        StringBuilder localStringBuilder = new StringBuilder(paramInt);
        localStringBuilder.append(paramString1.substring(0, j));
        localStringBuilder.append(paramString2);
        localStringBuilder.append(paramString1.substring(k));
        paramString1 = localStringBuilder.toString();
      }
    }
  }

  public static String capitalize(String paramString)
  {
    int i;
    if (paramString != null)
    {
      i = paramString.length();
      if (i != 0)
        break label15;
    }
    while (true)
    {
      return paramString;
      label15: paramString = i + Character.toTitleCase(paramString.charAt(0)) + paramString.substring(1);
    }
  }

  public static String center(String paramString, int paramInt)
  {
    return center(paramString, paramInt, ' ');
  }

  public static String center(String paramString, int paramInt, char paramChar)
  {
    if ((paramString == null) || (paramInt <= 0));
    while (true)
    {
      return paramString;
      int i = paramString.length();
      int j = paramInt - i;
      if (j > 0)
        paramString = rightPad(leftPad(paramString, i + j / 2, paramChar), paramInt, paramChar);
    }
  }

  public static String center(String paramString1, int paramInt, String paramString2)
  {
    if ((paramString1 == null) || (paramInt <= 0));
    while (true)
    {
      return paramString1;
      if (isEmpty(paramString2))
        paramString2 = " ";
      int i = paramString1.length();
      int j = paramInt - i;
      if (j > 0)
        paramString1 = rightPad(leftPad(paramString1, i + j / 2, paramString2), paramInt, paramString2);
    }
  }

  public static String chomp(String paramString)
  {
    if (isEmpty(paramString));
    while (true)
    {
      return paramString;
      if (paramString.length() != 1)
        break;
      int k = paramString.charAt(0);
      if ((k == 13) || (k == 10))
        paramString = "";
    }
    int i = -1 + paramString.length();
    int j = paramString.charAt(i);
    if (j == 10)
      if (paramString.charAt(i - 1) == '\r')
        i--;
    while (true)
    {
      paramString = paramString.substring(0, i);
      break;
      if (j != 13)
        i++;
    }
  }

  @Deprecated
  public static String chomp(String paramString1, String paramString2)
  {
    return removeEnd(paramString1, paramString2);
  }

  public static String chop(String paramString)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      int i = paramString.length();
      if (i < 2)
      {
        str = "";
      }
      else
      {
        int j = i - 1;
        str = paramString.substring(0, j);
        if ((paramString.charAt(j) == '\n') && (str.charAt(j - 1) == '\r'))
          str = str.substring(0, j - 1);
      }
    }
  }

  public static boolean contains(CharSequence paramCharSequence, int paramInt)
  {
    boolean bool = false;
    if (isEmpty(paramCharSequence));
    while (true)
    {
      return bool;
      if (CharSequenceUtils.indexOf(paramCharSequence, paramInt, 0) >= 0)
        bool = true;
    }
  }

  public static boolean contains(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    boolean bool = false;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    while (true)
    {
      return bool;
      if (CharSequenceUtils.indexOf(paramCharSequence1, paramCharSequence2, 0) >= 0)
        bool = true;
    }
  }

  public static boolean containsAny(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if (paramCharSequence2 == null);
    for (boolean bool = false; ; bool = containsAny(paramCharSequence1, CharSequenceUtils.toCharArray(paramCharSequence2)))
      return bool;
  }

  public static boolean containsAny(CharSequence paramCharSequence, char[] paramArrayOfChar)
  {
    boolean bool = true;
    if ((isEmpty(paramCharSequence)) || (ArrayUtils.isEmpty(paramArrayOfChar)));
    int j;
    int k;
    int m;
    int n;
    for (bool = false; ; bool = false)
    {
      return bool;
      int i = paramCharSequence.length();
      j = paramArrayOfChar.length;
      k = i - 1;
      m = j - 1;
      n = 0;
      label45: if (n < i)
        break;
    }
    char c = paramCharSequence.charAt(n);
    for (int i1 = 0; ; i1++)
    {
      if (i1 >= j)
      {
        n++;
        break label45;
      }
      if ((paramArrayOfChar[i1] == c) && ((!Character.isHighSurrogate(c)) || (i1 == m) || ((n < k) && (paramArrayOfChar[(i1 + 1)] == paramCharSequence.charAt(n + 1)))))
        break;
    }
  }

  public static boolean containsIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    boolean bool = false;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    label61: 
    while (true)
    {
      return bool;
      int i = paramCharSequence2.length();
      int j = paramCharSequence1.length() - i;
      for (int k = 0; ; k++)
      {
        if (k > j)
          break label61;
        if (CharSequenceUtils.regionMatches(paramCharSequence1, true, k, paramCharSequence2, 0, i))
        {
          bool = true;
          break;
        }
      }
    }
  }

  public static boolean containsNone(CharSequence paramCharSequence, String paramString)
  {
    if ((paramCharSequence == null) || (paramString == null));
    for (boolean bool = true; ; bool = containsNone(paramCharSequence, paramString.toCharArray()))
      return bool;
  }

  public static boolean containsNone(CharSequence paramCharSequence, char[] paramArrayOfChar)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (paramArrayOfChar == null));
    int j;
    int k;
    int m;
    int n;
    for (bool = true; ; bool = true)
    {
      return bool;
      int i = paramCharSequence.length();
      j = i - 1;
      k = paramArrayOfChar.length;
      m = k - 1;
      n = 0;
      label39: if (n < i)
        break;
    }
    char c = paramCharSequence.charAt(n);
    for (int i1 = 0; ; i1++)
    {
      if (i1 >= k)
      {
        n++;
        break label39;
      }
      if ((paramArrayOfChar[i1] == c) && ((!Character.isHighSurrogate(c)) || (i1 == m) || ((n < j) && (paramArrayOfChar[(i1 + 1)] == paramCharSequence.charAt(n + 1)))))
        break;
    }
  }

  public static boolean containsOnly(CharSequence paramCharSequence, String paramString)
  {
    if ((paramCharSequence == null) || (paramString == null));
    for (boolean bool = false; ; bool = containsOnly(paramCharSequence, paramString.toCharArray()))
      return bool;
  }

  public static boolean containsOnly(CharSequence paramCharSequence, char[] paramArrayOfChar)
  {
    boolean bool = true;
    if ((paramArrayOfChar == null) || (paramCharSequence == null))
      bool = false;
    while (true)
    {
      return bool;
      if (paramCharSequence.length() != 0)
        if (paramArrayOfChar.length == 0)
          bool = false;
        else if (indexOfAnyBut(paramCharSequence, paramArrayOfChar) != -1)
          bool = false;
    }
  }

  public static boolean containsWhitespace(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (isEmpty(paramCharSequence));
    label47: 
    while (true)
    {
      return bool;
      int i = paramCharSequence.length();
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label47;
        if (Character.isWhitespace(paramCharSequence.charAt(j)))
        {
          bool = true;
          break;
        }
      }
    }
  }

  public static int countMatches(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if ((isEmpty(paramCharSequence1)) || (isEmpty(paramCharSequence2)))
    {
      i = 0;
      return i;
    }
    int i = 0;
    int k;
    for (int j = 0; ; j = k + paramCharSequence2.length())
    {
      k = CharSequenceUtils.indexOf(paramCharSequence1, paramCharSequence2, j);
      if (k == -1)
        break;
      i++;
    }
  }

  public static <T extends CharSequence> T defaultIfBlank(T paramT1, T paramT2)
  {
    if (isBlank(paramT1));
    while (true)
    {
      return paramT2;
      paramT2 = paramT1;
    }
  }

  public static <T extends CharSequence> T defaultIfEmpty(T paramT1, T paramT2)
  {
    if (isEmpty(paramT1));
    while (true)
    {
      return paramT2;
      paramT2 = paramT1;
    }
  }

  public static String defaultString(String paramString)
  {
    if (paramString == null)
      paramString = "";
    return paramString;
  }

  public static String defaultString(String paramString1, String paramString2)
  {
    if (paramString1 == null);
    while (true)
    {
      return paramString2;
      paramString2 = paramString1;
    }
  }

  public static String deleteWhitespace(String paramString)
  {
    if (isEmpty(paramString));
    char[] arrayOfChar;
    int j;
    int k;
    while (true)
    {
      return paramString;
      int i = paramString.length();
      arrayOfChar = new char[i];
      j = 0;
      k = 0;
      if (j < i)
        break;
      if (k != i)
        paramString = new String(arrayOfChar, 0, k);
    }
    int m;
    if (!Character.isWhitespace(paramString.charAt(j)))
    {
      m = k + 1;
      arrayOfChar[k] = paramString.charAt(j);
    }
    while (true)
    {
      j++;
      k = m;
      break;
      m = k;
    }
  }

  public static String difference(String paramString1, String paramString2)
  {
    if (paramString1 == null);
    while (true)
    {
      return paramString2;
      if (paramString2 == null)
      {
        paramString2 = paramString1;
      }
      else
      {
        int i = indexOfDifference(paramString1, paramString2);
        if (i == -1)
          paramString2 = "";
        else
          paramString2 = paramString2.substring(i);
      }
    }
  }

  public static boolean endsWith(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    return endsWith(paramCharSequence1, paramCharSequence2, false);
  }

  private static boolean endsWith(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean)
  {
    boolean bool = false;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      if ((paramCharSequence1 == null) && (paramCharSequence2 == null))
        bool = true;
    while (true)
    {
      return bool;
      if (paramCharSequence2.length() <= paramCharSequence1.length())
        bool = CharSequenceUtils.regionMatches(paramCharSequence1, paramBoolean, paramCharSequence1.length() - paramCharSequence2.length(), paramCharSequence2, 0, paramCharSequence2.length());
    }
  }

  public static boolean endsWithAny(CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence)
  {
    boolean bool = false;
    if ((isEmpty(paramCharSequence)) || (ArrayUtils.isEmpty(paramArrayOfCharSequence)));
    label50: 
    while (true)
    {
      return bool;
      int i = paramArrayOfCharSequence.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label50;
        if (endsWith(paramCharSequence, paramArrayOfCharSequence[j]))
        {
          bool = true;
          break;
        }
      }
    }
  }

  public static boolean endsWithIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    return endsWith(paramCharSequence1, paramCharSequence2, true);
  }

  public static boolean equals(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    boolean bool;
    if (paramCharSequence1 == null)
      if (paramCharSequence2 == null)
        bool = true;
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = paramCharSequence1.equals(paramCharSequence2);
    }
  }

  public static boolean equalsIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    boolean bool = true;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      if (paramCharSequence1 != paramCharSequence2);
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = CharSequenceUtils.regionMatches(paramCharSequence1, bool, 0, paramCharSequence2, 0, Math.max(paramCharSequence1.length(), paramCharSequence2.length()));
    }
  }

  public static String getCommonPrefix(String[] paramArrayOfString)
  {
    String str;
    if ((paramArrayOfString == null) || (paramArrayOfString.length == 0))
      str = "";
    while (true)
    {
      return str;
      int i = indexOfDifference(paramArrayOfString);
      if (i == -1)
      {
        if (paramArrayOfString[0] == null)
          str = "";
        else
          str = paramArrayOfString[0];
      }
      else if (i == 0)
        str = "";
      else
        str = paramArrayOfString[0].substring(0, i);
    }
  }

  public static int getLevenshteinDistance(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      throw new IllegalArgumentException("Strings must not be null");
    int i = paramCharSequence1.length();
    int j = paramCharSequence2.length();
    if (i == 0);
    for (int i3 = j; ; i3 = i)
    {
      return i3;
      if (j != 0)
        break;
    }
    if (i > j)
    {
      CharSequence localCharSequence = paramCharSequence1;
      paramCharSequence1 = paramCharSequence2;
      paramCharSequence2 = localCharSequence;
      i = j;
      j = paramCharSequence2.length();
    }
    Object localObject1 = new int[i + 1];
    Object localObject2 = new int[i + 1];
    int k = 0;
    label91: if (k > i);
    int n;
    int i1;
    for (int m = 1; ; m++)
    {
      if (m > j)
      {
        i3 = localObject1[i];
        break;
        localObject1[k] = k;
        k++;
        break label91;
      }
      n = paramCharSequence2.charAt(m - 1);
      localObject2[0] = m;
      i1 = 1;
      if (i1 <= i)
        break label173;
      Object localObject3 = localObject1;
      localObject1 = localObject2;
      localObject2 = localObject3;
    }
    label173: if (paramCharSequence1.charAt(i1 - 1) == n);
    for (int i2 = 0; ; i2 = 1)
    {
      localObject2[i1] = Math.min(Math.min(1 + localObject2[(i1 - 1)], 1 + localObject1[i1]), i2 + localObject1[(i1 - 1)]);
      i1++;
      break;
    }
  }

  public static int getLevenshteinDistance(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      throw new IllegalArgumentException("Strings must not be null");
    if (paramInt < 0)
      throw new IllegalArgumentException("Threshold must not be negative");
    int i = paramCharSequence1.length();
    int j = paramCharSequence2.length();
    int i6;
    if (i == 0)
      if (j <= paramInt)
        i6 = j;
    while (true)
    {
      return i6;
      i6 = -1;
      continue;
      if (j == 0)
      {
        if (i <= paramInt)
          i6 = i;
        else
          i6 = -1;
      }
      else
      {
        if (i > j)
        {
          CharSequence localCharSequence = paramCharSequence1;
          paramCharSequence1 = paramCharSequence2;
          paramCharSequence2 = localCharSequence;
          i = j;
          j = paramCharSequence2.length();
        }
        Object localObject1 = new int[i + 1];
        Object localObject2 = new int[i + 1];
        int k = 1 + Math.min(i, paramInt);
        int m = 0;
        label143: if (m >= k)
        {
          Arrays.fill((int[])localObject1, k, localObject1.length, 2147483647);
          Arrays.fill((int[])localObject2, 2147483647);
        }
        int i2;
        int i5;
        for (int n = 1; ; n++)
        {
          if (n > j)
          {
            if (localObject1[i] > paramInt)
              break label376;
            i6 = localObject1[i];
            break;
            localObject1[m] = m;
            m++;
            break label143;
          }
          int i1 = n - 1;
          i2 = paramCharSequence2.charAt(i1);
          localObject2[0] = n;
          int i3 = Math.max(1, n - paramInt);
          int i4 = Math.min(i, n + paramInt);
          if (i3 > i4)
          {
            i6 = -1;
            break;
          }
          if (i3 > 1)
            localObject2[(i3 - 1)] = 2147483647;
          i5 = i3;
          if (i5 <= i4)
            break label308;
          Object localObject3 = localObject1;
          localObject1 = localObject2;
          localObject2 = localObject3;
        }
        label308: if (paramCharSequence1.charAt(i5 - 1) == i2)
          localObject2[i5] = localObject1[(i5 - 1)];
        while (true)
        {
          i5++;
          break;
          localObject2[i5] = (1 + Math.min(Math.min(localObject2[(i5 - 1)], localObject1[i5]), localObject1[(i5 - 1)]));
        }
        label376: i6 = -1;
      }
    }
  }

  public static int indexOf(CharSequence paramCharSequence, int paramInt)
  {
    if (isEmpty(paramCharSequence));
    for (int i = -1; ; i = CharSequenceUtils.indexOf(paramCharSequence, paramInt, 0))
      return i;
  }

  public static int indexOf(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    if (isEmpty(paramCharSequence));
    for (int i = -1; ; i = CharSequenceUtils.indexOf(paramCharSequence, paramInt1, paramInt2))
      return i;
  }

  public static int indexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    for (int i = -1; ; i = CharSequenceUtils.indexOf(paramCharSequence1, paramCharSequence2, 0))
      return i;
  }

  public static int indexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    for (int i = -1; ; i = CharSequenceUtils.indexOf(paramCharSequence1, paramCharSequence2, paramInt))
      return i;
  }

  public static int indexOfAny(CharSequence paramCharSequence, String paramString)
  {
    if ((isEmpty(paramCharSequence)) || (isEmpty(paramString)));
    for (int i = -1; ; i = indexOfAny(paramCharSequence, paramString.toCharArray()))
      return i;
  }

  public static int indexOfAny(CharSequence paramCharSequence, char[] paramArrayOfChar)
  {
    if ((isEmpty(paramCharSequence)) || (ArrayUtils.isEmpty(paramArrayOfChar)));
    int k;
    int m;
    int n;
    for (int i = -1; ; i = -1)
    {
      return i;
      int j = paramCharSequence.length();
      k = j - 1;
      m = paramArrayOfChar.length;
      n = m - 1;
      i = 0;
      label42: if (i < j)
        break;
    }
    char c = paramCharSequence.charAt(i);
    for (int i1 = 0; ; i1++)
    {
      if (i1 >= m)
      {
        i++;
        break label42;
      }
      if ((paramArrayOfChar[i1] == c) && ((i >= k) || (i1 >= n) || (!Character.isHighSurrogate(c)) || (paramArrayOfChar[(i1 + 1)] == paramCharSequence.charAt(i + 1))))
        break;
    }
  }

  public static int indexOfAny(CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence)
  {
    int i;
    if ((paramCharSequence == null) || (paramArrayOfCharSequence == null))
      i = -1;
    int k;
    while (true)
    {
      return i;
      int j = paramArrayOfCharSequence.length;
      i = 2147483647;
      k = 0;
      if (k < j)
        break;
      if (i == 2147483647)
        i = -1;
    }
    CharSequence localCharSequence = paramArrayOfCharSequence[k];
    if (localCharSequence == null);
    while (true)
    {
      k++;
      break;
      int m = CharSequenceUtils.indexOf(paramCharSequence, localCharSequence, 0);
      if ((m != -1) && (m < i))
        i = m;
    }
  }

  public static int indexOfAnyBut(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    int i;
    if ((isEmpty(paramCharSequence1)) || (isEmpty(paramCharSequence2)))
      i = -1;
    while (true)
    {
      return i;
      int j = paramCharSequence1.length();
      i = 0;
      if (i >= j)
      {
        i = -1;
      }
      else
      {
        char c = paramCharSequence1.charAt(i);
        int k;
        if (CharSequenceUtils.indexOf(paramCharSequence2, c, 0) >= 0)
        {
          k = 1;
          label59: if ((i + 1 < j) && (Character.isHighSurrogate(c)))
          {
            m = paramCharSequence1.charAt(i + 1);
            if ((k != 0) && (CharSequenceUtils.indexOf(paramCharSequence2, m, 0) < 0))
              continue;
          }
        }
        else
        {
          while (k != 0)
          {
            int m;
            i++;
            break;
            k = 0;
            break label59;
          }
        }
      }
    }
  }

  public static int indexOfAnyBut(CharSequence paramCharSequence, char[] paramArrayOfChar)
  {
    int i;
    if ((isEmpty(paramCharSequence)) || (ArrayUtils.isEmpty(paramArrayOfChar)))
      i = -1;
    label129: 
    while (true)
    {
      return i;
      int j = paramCharSequence.length();
      int k = j - 1;
      int m = paramArrayOfChar.length;
      int n = m - 1;
      i = 0;
      if (i >= j)
      {
        i = -1;
      }
      else
      {
        char c = paramCharSequence.charAt(i);
        for (int i1 = 0; ; i1++)
        {
          if (i1 >= m)
            break label129;
          if ((paramArrayOfChar[i1] == c) && ((i >= k) || (i1 >= n) || (!Character.isHighSurrogate(c)) || (paramArrayOfChar[(i1 + 1)] == paramCharSequence.charAt(i + 1))))
          {
            i++;
            break;
          }
        }
      }
    }
  }

  public static int indexOfDifference(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if (paramCharSequence1 == paramCharSequence2)
      i = -1;
    else
      while (true)
      {
        label7: return i;
        if ((paramCharSequence1 != null) && (paramCharSequence2 != null))
          break;
        i = 0;
      }
    for (int i = 0; ; i++)
    {
      if ((i >= paramCharSequence1.length()) || (i >= paramCharSequence2.length()))
      {
        if ((i < paramCharSequence2.length()) || (i < paramCharSequence1.length()))
          break label7;
        i = -1;
        break label7;
      }
      if (paramCharSequence1.charAt(i) != paramCharSequence2.charAt(i))
        break;
    }
  }

  public static int indexOfDifference(CharSequence[] paramArrayOfCharSequence)
  {
    int i;
    if ((paramArrayOfCharSequence == null) || (paramArrayOfCharSequence.length <= 1))
      i = -1;
    int m;
    int i2;
    int i3;
    while (true)
    {
      return i;
      int j = 0;
      int k = 1;
      m = paramArrayOfCharSequence.length;
      i = 2147483647;
      int n = 0;
      int i1 = 0;
      if (i1 >= m)
      {
        if ((k != 0) || ((n == 0) && (j == 0)))
          i = -1;
      }
      else
      {
        if (paramArrayOfCharSequence[i1] == null)
        {
          j = 1;
          i = 0;
        }
        while (true)
        {
          i1++;
          break;
          k = 0;
          i = Math.min(paramArrayOfCharSequence[i1].length(), i);
          n = Math.max(paramArrayOfCharSequence[i1].length(), n);
        }
        if (i == 0)
        {
          i = 0;
        }
        else
        {
          i2 = -1;
          i3 = 0;
          if (i3 < i)
            break;
          label129: if ((i2 != -1) || (i == n))
            i = i2;
        }
      }
    }
    int i4 = paramArrayOfCharSequence[0].charAt(i3);
    label202: label204: for (int i5 = 1; ; i5++)
    {
      if (i5 >= m);
      while (true)
      {
        if (i2 != -1)
          break label202;
        i3++;
        break;
        if (paramArrayOfCharSequence[i5].charAt(i3) == i4)
          break label204;
        i2 = i3;
      }
      break label129;
    }
  }

  public static int indexOfIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    return indexOfIgnoreCase(paramCharSequence1, paramCharSequence2, 0);
  }

  public static int indexOfIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      i = -1;
    int j;
    while (true)
    {
      return i;
      if (paramInt < 0)
        paramInt = 0;
      j = 1 + (paramCharSequence1.length() - paramCharSequence2.length());
      if (paramInt > j)
      {
        i = -1;
      }
      else
      {
        if (paramCharSequence2.length() != 0)
          break;
        i = paramInt;
      }
    }
    for (int i = paramInt; ; i++)
    {
      if (i >= j)
      {
        i = -1;
        break;
      }
      if (CharSequenceUtils.regionMatches(paramCharSequence1, true, i, paramCharSequence2, 0, paramCharSequence2.length()))
        break;
    }
  }

  public static boolean isAllLowerCase(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (isEmpty(paramCharSequence)))
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isLowerCase(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isAllUpperCase(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (isEmpty(paramCharSequence)))
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isUpperCase(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isAlpha(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (paramCharSequence.length() == 0))
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isLetter(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isAlphaSpace(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (paramCharSequence == null)
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if ((!Character.isLetter(paramCharSequence.charAt(j))) && (paramCharSequence.charAt(j) != ' '))
        break;
    }
  }

  public static boolean isAlphanumeric(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (paramCharSequence.length() == 0))
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isLetterOrDigit(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isAlphanumericSpace(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (paramCharSequence == null)
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if ((!Character.isLetterOrDigit(paramCharSequence.charAt(j))) && (paramCharSequence.charAt(j) != ' '))
        break;
    }
  }

  public static boolean isAsciiPrintable(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (paramCharSequence == null)
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!CharUtils.isAsciiPrintable(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isBlank(CharSequence paramCharSequence)
  {
    boolean bool = true;
    int i;
    if (paramCharSequence != null)
    {
      i = paramCharSequence.length();
      if (i != 0)
        break label19;
    }
    label19: label48: 
    while (true)
    {
      return bool;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label48;
        if (!Character.isWhitespace(paramCharSequence.charAt(j)))
        {
          bool = false;
          break;
        }
      }
    }
  }

  public static boolean isEmpty(CharSequence paramCharSequence)
  {
    if ((paramCharSequence != null) && (paramCharSequence.length() != 0));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isNotBlank(CharSequence paramCharSequence)
  {
    if (isBlank(paramCharSequence));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isNotEmpty(CharSequence paramCharSequence)
  {
    if (isEmpty(paramCharSequence));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isNumeric(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if ((paramCharSequence == null) || (paramCharSequence.length() == 0))
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isDigit(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static boolean isNumericSpace(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (paramCharSequence == null)
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if ((!Character.isDigit(paramCharSequence.charAt(j))) && (paramCharSequence.charAt(j) != ' '))
        break;
    }
  }

  public static boolean isWhitespace(CharSequence paramCharSequence)
  {
    boolean bool = false;
    if (paramCharSequence == null)
      return bool;
    int i = paramCharSequence.length();
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (!Character.isWhitespace(paramCharSequence.charAt(j)))
        break;
    }
  }

  public static String join(Iterable<?> paramIterable, char paramChar)
  {
    if (paramIterable == null);
    for (String str = null; ; str = join(paramIterable.iterator(), paramChar))
      return str;
  }

  public static String join(Iterable<?> paramIterable, String paramString)
  {
    if (paramIterable == null);
    for (String str = null; ; str = join(paramIterable.iterator(), paramString))
      return str;
  }

  public static String join(Iterator<?> paramIterator, char paramChar)
  {
    String str;
    if (paramIterator == null)
      str = null;
    Object localObject1;
    while (true)
    {
      return str;
      if (!paramIterator.hasNext())
      {
        str = "";
      }
      else
      {
        localObject1 = paramIterator.next();
        if (paramIterator.hasNext())
          break;
        str = ObjectUtils.toString(localObject1);
      }
    }
    StringBuilder localStringBuilder = new StringBuilder(256);
    if (localObject1 != null)
      localStringBuilder.append(localObject1);
    while (true)
    {
      if (!paramIterator.hasNext())
      {
        str = localStringBuilder.toString();
        break;
      }
      localStringBuilder.append(paramChar);
      Object localObject2 = paramIterator.next();
      if (localObject2 != null)
        localStringBuilder.append(localObject2);
    }
  }

  public static String join(Iterator<?> paramIterator, String paramString)
  {
    String str;
    if (paramIterator == null)
      str = null;
    Object localObject1;
    while (true)
    {
      return str;
      if (!paramIterator.hasNext())
      {
        str = "";
      }
      else
      {
        localObject1 = paramIterator.next();
        if (paramIterator.hasNext())
          break;
        str = ObjectUtils.toString(localObject1);
      }
    }
    StringBuilder localStringBuilder = new StringBuilder(256);
    if (localObject1 != null)
      localStringBuilder.append(localObject1);
    while (true)
    {
      if (!paramIterator.hasNext())
      {
        str = localStringBuilder.toString();
        break;
      }
      if (paramString != null)
        localStringBuilder.append(paramString);
      Object localObject2 = paramIterator.next();
      if (localObject2 != null)
        localStringBuilder.append(localObject2);
    }
  }

  public static <T> String join(T[] paramArrayOfT)
  {
    return join(paramArrayOfT, null);
  }

  public static String join(Object[] paramArrayOfObject, char paramChar)
  {
    if (paramArrayOfObject == null);
    for (String str = null; ; str = join(paramArrayOfObject, paramChar, 0, paramArrayOfObject.length))
      return str;
  }

  public static String join(Object[] paramArrayOfObject, char paramChar, int paramInt1, int paramInt2)
  {
    if (paramArrayOfObject == null);
    int i;
    for (String str = null; ; str = "")
    {
      return str;
      i = paramInt2 - paramInt1;
      if (i > 0)
        break;
    }
    StringBuilder localStringBuilder = new StringBuilder(i * 16);
    for (int j = paramInt1; ; j++)
    {
      if (j >= paramInt2)
      {
        str = localStringBuilder.toString();
        break;
      }
      if (j > paramInt1)
        localStringBuilder.append(paramChar);
      if (paramArrayOfObject[j] != null)
        localStringBuilder.append(paramArrayOfObject[j]);
    }
  }

  public static String join(Object[] paramArrayOfObject, String paramString)
  {
    if (paramArrayOfObject == null);
    for (String str = null; ; str = join(paramArrayOfObject, paramString, 0, paramArrayOfObject.length))
      return str;
  }

  public static String join(Object[] paramArrayOfObject, String paramString, int paramInt1, int paramInt2)
  {
    if (paramArrayOfObject == null);
    int i;
    for (String str = null; ; str = "")
    {
      return str;
      if (paramString == null)
        paramString = "";
      i = paramInt2 - paramInt1;
      if (i > 0)
        break;
    }
    StringBuilder localStringBuilder = new StringBuilder(i * 16);
    for (int j = paramInt1; ; j++)
    {
      if (j >= paramInt2)
      {
        str = localStringBuilder.toString();
        break;
      }
      if (j > paramInt1)
        localStringBuilder.append(paramString);
      if (paramArrayOfObject[j] != null)
        localStringBuilder.append(paramArrayOfObject[j]);
    }
  }

  public static int lastIndexOf(CharSequence paramCharSequence, int paramInt)
  {
    if (isEmpty(paramCharSequence));
    for (int i = -1; ; i = CharSequenceUtils.lastIndexOf(paramCharSequence, paramInt, paramCharSequence.length()))
      return i;
  }

  public static int lastIndexOf(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    if (isEmpty(paramCharSequence));
    for (int i = -1; ; i = CharSequenceUtils.lastIndexOf(paramCharSequence, paramInt1, paramInt2))
      return i;
  }

  public static int lastIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    for (int i = -1; ; i = CharSequenceUtils.lastIndexOf(paramCharSequence1, paramCharSequence2, paramCharSequence1.length()))
      return i;
  }

  public static int lastIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    for (int i = -1; ; i = CharSequenceUtils.lastIndexOf(paramCharSequence1, paramCharSequence2, paramInt))
      return i;
  }

  public static int lastIndexOfAny(CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence)
  {
    if ((paramCharSequence == null) || (paramArrayOfCharSequence == null))
    {
      i = -1;
      return i;
    }
    int j = paramArrayOfCharSequence.length;
    int i = -1;
    int k = 0;
    label20: CharSequence localCharSequence;
    if (k < j)
    {
      localCharSequence = paramArrayOfCharSequence[k];
      if (localCharSequence != null)
        break label43;
    }
    while (true)
    {
      k++;
      break label20;
      break;
      label43: int m = CharSequenceUtils.lastIndexOf(paramCharSequence, localCharSequence, paramCharSequence.length());
      if (m > i)
        i = m;
    }
  }

  public static int lastIndexOfIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null));
    for (int i = -1; ; i = lastIndexOfIgnoreCase(paramCharSequence1, paramCharSequence2, paramCharSequence1.length()))
      return i;
  }

  public static int lastIndexOfIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      i = -1;
    while (true)
    {
      return i;
      if (paramInt > paramCharSequence1.length() - paramCharSequence2.length())
        paramInt = paramCharSequence1.length() - paramCharSequence2.length();
      if (paramInt < 0)
      {
        i = -1;
      }
      else
      {
        if (paramCharSequence2.length() != 0)
          break;
        i = paramInt;
      }
    }
    for (int i = paramInt; ; i--)
    {
      if (i < 0)
      {
        i = -1;
        break;
      }
      if (CharSequenceUtils.regionMatches(paramCharSequence1, true, i, paramCharSequence2, 0, paramCharSequence2.length()))
        break;
    }
  }

  public static int lastOrdinalIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    return ordinalIndexOf(paramCharSequence1, paramCharSequence2, paramInt, true);
  }

  public static String left(String paramString, int paramInt)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      if (paramInt < 0)
        paramString = "";
      else if (paramString.length() > paramInt)
        paramString = paramString.substring(0, paramInt);
    }
  }

  public static String leftPad(String paramString, int paramInt)
  {
    return leftPad(paramString, paramInt, ' ');
  }

  public static String leftPad(String paramString, int paramInt, char paramChar)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      int i = paramInt - paramString.length();
      if (i > 0)
        if (i > 8192)
          paramString = leftPad(paramString, paramInt, String.valueOf(paramChar));
        else
          paramString = repeat(paramChar, i).concat(paramString);
    }
  }

  public static String leftPad(String paramString1, int paramInt, String paramString2)
  {
    if (paramString1 == null)
      paramString1 = null;
    int i;
    int j;
    while (true)
    {
      return paramString1;
      if (isEmpty(paramString2))
        paramString2 = " ";
      i = paramString2.length();
      j = paramInt - paramString1.length();
      if (j > 0)
        if ((i == 1) && (j <= 8192))
        {
          paramString1 = leftPad(paramString1, paramInt, paramString2.charAt(0));
        }
        else if (j == i)
        {
          paramString1 = paramString2.concat(paramString1);
        }
        else
        {
          if (j >= i)
            break;
          paramString1 = paramString2.substring(0, j).concat(paramString1);
        }
    }
    char[] arrayOfChar1 = new char[j];
    char[] arrayOfChar2 = paramString2.toCharArray();
    for (int k = 0; ; k++)
    {
      if (k >= j)
      {
        paramString1 = new String(arrayOfChar1).concat(paramString1);
        break;
      }
      arrayOfChar1[k] = arrayOfChar2[(k % i)];
    }
  }

  public static int length(CharSequence paramCharSequence)
  {
    if (paramCharSequence == null);
    for (int i = 0; ; i = paramCharSequence.length())
      return i;
  }

  public static String lowerCase(String paramString)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.toLowerCase())
      return str;
  }

  public static String lowerCase(String paramString, Locale paramLocale)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.toLowerCase(paramLocale))
      return str;
  }

  public static String mid(String paramString, int paramInt1, int paramInt2)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      if ((paramInt2 < 0) || (paramInt1 > paramString.length()))
      {
        str = "";
      }
      else
      {
        if (paramInt1 < 0)
          paramInt1 = 0;
        if (paramString.length() <= paramInt1 + paramInt2)
          str = paramString.substring(paramInt1);
        else
          str = paramString.substring(paramInt1, paramInt1 + paramInt2);
      }
    }
  }

  public static String normalizeSpace(String paramString)
  {
    if (paramString == null);
    for (String str = null; ; str = WHITESPACE_BLOCK.matcher(trim(paramString)).replaceAll(" "))
      return str;
  }

  public static int ordinalIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt)
  {
    return ordinalIndexOf(paramCharSequence1, paramCharSequence2, paramInt, false);
  }

  private static int ordinalIndexOf(CharSequence paramCharSequence1, CharSequence paramCharSequence2, int paramInt, boolean paramBoolean)
  {
    int i = -1;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null) || (paramInt <= 0));
    label67: label111: 
    while (true)
    {
      return i;
      if (paramCharSequence2.length() == 0)
      {
        if (paramBoolean);
        for (int k = paramCharSequence1.length(); ; k = 0)
        {
          i = k;
          break;
        }
      }
      int j = 0;
      if (paramBoolean)
        i = paramCharSequence1.length();
      if (paramBoolean);
      for (i = CharSequenceUtils.lastIndexOf(paramCharSequence1, paramCharSequence2, i - 1); ; i = CharSequenceUtils.indexOf(paramCharSequence1, paramCharSequence2, i + 1))
      {
        if (i < 0)
          break label111;
        j++;
        if (j < paramInt)
          break label67;
        break;
      }
    }
  }

  public static String overlay(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    if (paramString1 == null);
    int i;
    for (String str = null; ; str = 1 + (i + paramInt1 - paramInt2 + paramString2.length()) + paramString1.substring(0, paramInt1) + paramString2 + paramString1.substring(paramInt2))
    {
      return str;
      if (paramString2 == null)
        paramString2 = "";
      i = paramString1.length();
      if (paramInt1 < 0)
        paramInt1 = 0;
      if (paramInt1 > i)
        paramInt1 = i;
      if (paramInt2 < 0)
        paramInt2 = 0;
      if (paramInt2 > i)
        paramInt2 = i;
      if (paramInt1 > paramInt2)
      {
        int j = paramInt1;
        paramInt1 = paramInt2;
        paramInt2 = j;
      }
    }
  }

  public static String remove(String paramString, char paramChar)
  {
    if ((isEmpty(paramString)) || (paramString.indexOf(paramChar) == -1))
      return paramString;
    char[] arrayOfChar = paramString.toCharArray();
    int i = 0;
    for (int j = 0; ; j++)
    {
      if (j >= arrayOfChar.length)
      {
        paramString = new String(arrayOfChar, 0, i);
        break;
      }
      if (arrayOfChar[j] != paramChar)
      {
        int k = i + 1;
        arrayOfChar[i] = arrayOfChar[j];
        i = k;
      }
    }
  }

  public static String remove(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      paramString1 = replace(paramString1, paramString2, "", -1);
    }
  }

  private static String removeAccentsJava6(CharSequence paramCharSequence)
    throws IllegalAccessException, InvocationTargetException
  {
    if ((InitStripAccents.java6NormalizeMethod == null) || (InitStripAccents.java6NormalizerFormNFD == null))
      throw new IllegalStateException("java.text.Normalizer is not available", InitStripAccents.java6Exception);
    Method localMethod = InitStripAccents.java6NormalizeMethod;
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramCharSequence;
    arrayOfObject[1] = InitStripAccents.java6NormalizerFormNFD;
    String str = (String)localMethod.invoke(null, arrayOfObject);
    return InitStripAccents.java6Pattern.matcher(str).replaceAll("");
  }

  private static String removeAccentsSUN(CharSequence paramCharSequence)
    throws IllegalAccessException, InvocationTargetException
  {
    if (InitStripAccents.sunDecomposeMethod == null)
      throw new IllegalStateException("sun.text.Normalizer is not available", InitStripAccents.sunException);
    Method localMethod = InitStripAccents.sunDecomposeMethod;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = paramCharSequence;
    arrayOfObject[1] = Boolean.FALSE;
    arrayOfObject[2] = Integer.valueOf(0);
    String str = (String)localMethod.invoke(null, arrayOfObject);
    return InitStripAccents.sunPattern.matcher(str).replaceAll("");
  }

  public static String removeEnd(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      if (paramString1.endsWith(paramString2))
        paramString1 = paramString1.substring(0, paramString1.length() - paramString2.length());
    }
  }

  public static String removeEndIgnoreCase(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      if (endsWithIgnoreCase(paramString1, paramString2))
        paramString1 = paramString1.substring(0, paramString1.length() - paramString2.length());
    }
  }

  public static String removeStart(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      if (paramString1.startsWith(paramString2))
        paramString1 = paramString1.substring(paramString2.length());
    }
  }

  public static String removeStartIgnoreCase(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      if (startsWithIgnoreCase(paramString1, paramString2))
        paramString1 = paramString1.substring(paramString2.length());
    }
  }

  public static String repeat(char paramChar, int paramInt)
  {
    char[] arrayOfChar = new char[paramInt];
    for (int i = paramInt - 1; ; i--)
    {
      if (i < 0)
        return new String(arrayOfChar);
      arrayOfChar[i] = paramChar;
    }
  }

  public static String repeat(String paramString, int paramInt)
  {
    if (paramString == null)
      paramString = null;
    int i;
    while (true)
    {
      return paramString;
      if (paramInt <= 0)
      {
        paramString = "";
      }
      else
      {
        i = paramString.length();
        if ((paramInt != 1) && (i != 0))
        {
          if ((i != 1) || (paramInt > 8192))
            break;
          paramString = repeat(paramString.charAt(0), paramInt);
        }
      }
    }
    int j = i * paramInt;
    StringBuilder localStringBuilder;
    switch (i)
    {
    default:
      localStringBuilder = new StringBuilder(j);
    case 1:
    case 2:
    }
    for (int i1 = 0; ; i1++)
    {
      if (i1 >= paramInt)
      {
        paramString = localStringBuilder.toString();
        break;
        paramString = repeat(paramString.charAt(0), paramInt);
        break;
        int k = paramString.charAt(0);
        int m = paramString.charAt(1);
        char[] arrayOfChar = new char[j];
        for (int n = -2 + paramInt * 2; ; n = -1 + (n - 1))
        {
          if (n < 0)
          {
            paramString = new String(arrayOfChar);
            break;
          }
          arrayOfChar[n] = k;
          arrayOfChar[(n + 1)] = m;
        }
      }
      localStringBuilder.append(paramString);
    }
  }

  public static String repeat(String paramString1, String paramString2, int paramInt)
  {
    if ((paramString1 == null) || (paramString2 == null));
    for (String str = repeat(paramString1, paramInt); ; str = removeEnd(repeat(paramString1 + paramString2, paramInt), paramString2))
      return str;
  }

  public static String replace(String paramString1, String paramString2, String paramString3)
  {
    return replace(paramString1, paramString2, paramString3, -1);
  }

  public static String replace(String paramString1, String paramString2, String paramString3, int paramInt)
  {
    int i = 64;
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)) || (paramString3 == null) || (paramInt == 0));
    int j;
    int k;
    do
    {
      return paramString1;
      j = 0;
      k = paramString1.indexOf(paramString2, 0);
    }
    while (k == -1);
    int m = paramString2.length();
    int n = paramString3.length() - m;
    if (n < 0)
      n = 0;
    label76: StringBuilder localStringBuilder;
    if (paramInt < 0)
    {
      i = 16;
      localStringBuilder = new StringBuilder(n * i + paramString1.length());
    }
    while (true)
    {
      if (k == -1);
      do
      {
        localStringBuilder.append(paramString1.substring(j));
        paramString1 = localStringBuilder.toString();
        break;
        if (paramInt > i)
          break label76;
        i = paramInt;
        break label76;
        localStringBuilder.append(paramString1.substring(j, k)).append(paramString3);
        j = k + m;
        paramInt--;
      }
      while (paramInt == 0);
      k = paramString1.indexOf(paramString2, j);
    }
  }

  public static String replaceChars(String paramString, char paramChar1, char paramChar2)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.replace(paramChar1, paramChar2))
      return str;
  }

  public static String replaceChars(String paramString1, String paramString2, String paramString3)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    int i;
    int j;
    StringBuilder localStringBuilder;
    int m;
    while (true)
    {
      return paramString1;
      if (paramString3 == null)
        paramString3 = "";
      i = 0;
      j = paramString3.length();
      int k = paramString1.length();
      localStringBuilder = new StringBuilder(k);
      m = 0;
      if (m < k)
        break;
      if (i != 0)
        paramString1 = localStringBuilder.toString();
    }
    char c = paramString1.charAt(m);
    int n = paramString2.indexOf(c);
    if (n >= 0)
    {
      i = 1;
      if (n < j)
        localStringBuilder.append(paramString3.charAt(n));
    }
    while (true)
    {
      m++;
      break;
      localStringBuilder.append(c);
    }
  }

  public static String replaceEach(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    return replaceEach(paramString, paramArrayOfString1, paramArrayOfString2, false, 0);
  }

  private static String replaceEach(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean, int paramInt)
  {
    if ((paramString == null) || (paramString.length() == 0) || (paramArrayOfString1 == null) || (paramArrayOfString1.length == 0) || (paramArrayOfString2 == null) || (paramArrayOfString2.length == 0));
    while (true)
    {
      return paramString;
      if (paramInt < 0)
        throw new IllegalStateException("Aborting to protect against StackOverflowError - output of one loop is the input of another");
      int i = paramArrayOfString1.length;
      int j = paramArrayOfString2.length;
      if (i != j)
        throw new IllegalArgumentException("Search and Replace array lengths don't match: " + i + " vs " + j);
      boolean[] arrayOfBoolean = new boolean[i];
      int k = -1;
      int m = -1;
      int n = 0;
      int i2;
      int i3;
      int i4;
      StringBuilder localStringBuilder;
      int i8;
      if (n >= i)
      {
        if (k != -1)
        {
          i2 = 0;
          i3 = 0;
          i4 = 0;
          if (i4 >= paramArrayOfString1.length)
          {
            localStringBuilder = new StringBuilder(Math.min(i3, paramString.length() / 5) + paramString.length());
            if (k != -1)
              break label353;
            i8 = paramString.length();
          }
        }
      }
      else
      {
        String str3;
        for (int i9 = i2; ; i9++)
        {
          if (i9 >= i8)
          {
            str3 = localStringBuilder.toString();
            if (paramBoolean)
              break label531;
            paramString = str3;
            break;
            if ((arrayOfBoolean[n] != 0) || (paramArrayOfString1[n] == null) || (paramArrayOfString1[n].length() == 0) || (paramArrayOfString2[n] == null));
            while (true)
            {
              n++;
              break;
              String str1 = paramArrayOfString1[n];
              int i1 = paramString.indexOf(str1);
              if (i1 == -1)
              {
                arrayOfBoolean[n] = true;
              }
              else if ((k == -1) || (i1 < k))
              {
                k = i1;
                m = n;
              }
            }
            if ((paramArrayOfString1[i4] == null) || (paramArrayOfString2[i4] == null));
            while (true)
            {
              i4++;
              break;
              int i10 = paramArrayOfString2[i4].length() - paramArrayOfString1[i4].length();
              if (i10 > 0)
                i3 += i10 * 3;
            }
            label353: int i5 = i2;
            label357: int i6;
            if (i5 >= k)
            {
              localStringBuilder.append(paramArrayOfString2[m]);
              i2 = k + paramArrayOfString1[m].length();
              k = -1;
              m = -1;
              i6 = 0;
              label395: if (i6 < i)
                if ((arrayOfBoolean[i6] == 0) && (paramArrayOfString1[i6] != null) && (paramArrayOfString1[i6].length() != 0) && (paramArrayOfString2[i6] != null))
                  break label458;
            }
            while (true)
            {
              i6++;
              break label395;
              break;
              localStringBuilder.append(paramString.charAt(i5));
              i5++;
              break label357;
              label458: String str2 = paramArrayOfString1[i6];
              int i7 = paramString.indexOf(str2, i2);
              if (i7 == -1)
              {
                arrayOfBoolean[i6] = true;
              }
              else if ((k == -1) || (i7 < k))
              {
                k = i7;
                m = i6;
              }
            }
          }
          localStringBuilder.append(paramString.charAt(i9));
        }
        label531: paramString = replaceEach(str3, paramArrayOfString1, paramArrayOfString2, paramBoolean, paramInt - 1);
      }
    }
  }

  public static String replaceEachRepeatedly(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    if (paramArrayOfString1 == null);
    for (int i = 0; ; i = paramArrayOfString1.length)
      return replaceEach(paramString, paramArrayOfString1, paramArrayOfString2, true, i);
  }

  public static String replaceOnce(String paramString1, String paramString2, String paramString3)
  {
    return replace(paramString1, paramString2, paramString3, 1);
  }

  public static String reverse(String paramString)
  {
    if (paramString == null);
    for (String str = null; ; str = new StringBuilder(paramString).reverse().toString())
      return str;
  }

  public static String reverseDelimited(String paramString, char paramChar)
  {
    if (paramString == null);
    String[] arrayOfString;
    for (String str = null; ; str = join(arrayOfString, paramChar))
    {
      return str;
      arrayOfString = split(paramString, paramChar);
      ArrayUtils.reverse(arrayOfString);
    }
  }

  public static String right(String paramString, int paramInt)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      if (paramInt < 0)
        paramString = "";
      else if (paramString.length() > paramInt)
        paramString = paramString.substring(paramString.length() - paramInt);
    }
  }

  public static String rightPad(String paramString, int paramInt)
  {
    return rightPad(paramString, paramInt, ' ');
  }

  public static String rightPad(String paramString, int paramInt, char paramChar)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      int i = paramInt - paramString.length();
      if (i > 0)
        if (i > 8192)
          paramString = rightPad(paramString, paramInt, String.valueOf(paramChar));
        else
          paramString = paramString.concat(repeat(paramChar, i));
    }
  }

  public static String rightPad(String paramString1, int paramInt, String paramString2)
  {
    if (paramString1 == null)
      paramString1 = null;
    int i;
    int j;
    while (true)
    {
      return paramString1;
      if (isEmpty(paramString2))
        paramString2 = " ";
      i = paramString2.length();
      j = paramInt - paramString1.length();
      if (j > 0)
        if ((i == 1) && (j <= 8192))
        {
          paramString1 = rightPad(paramString1, paramInt, paramString2.charAt(0));
        }
        else if (j == i)
        {
          paramString1 = paramString1.concat(paramString2);
        }
        else
        {
          if (j >= i)
            break;
          paramString1 = paramString1.concat(paramString2.substring(0, j));
        }
    }
    char[] arrayOfChar1 = new char[j];
    char[] arrayOfChar2 = paramString2.toCharArray();
    for (int k = 0; ; k++)
    {
      if (k >= j)
      {
        paramString1 = paramString1.concat(new String(arrayOfChar1));
        break;
      }
      arrayOfChar1[k] = arrayOfChar2[(k % i)];
    }
  }

  public static String[] split(String paramString)
  {
    return split(paramString, null, -1);
  }

  public static String[] split(String paramString, char paramChar)
  {
    return splitWorker(paramString, paramChar, false);
  }

  public static String[] split(String paramString1, String paramString2)
  {
    return splitWorker(paramString1, paramString2, -1, false);
  }

  public static String[] split(String paramString1, String paramString2, int paramInt)
  {
    return splitWorker(paramString1, paramString2, paramInt, false);
  }

  public static String[] splitByCharacterType(String paramString)
  {
    return splitByCharacterType(paramString, false);
  }

  private static String[] splitByCharacterType(String paramString, boolean paramBoolean)
  {
    if (paramString == null);
    for (String[] arrayOfString = null; ; arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY)
    {
      return arrayOfString;
      if (paramString.length() != 0)
        break;
    }
    char[] arrayOfChar = paramString.toCharArray();
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    int j = Character.getType(arrayOfChar[0]);
    int m;
    for (int k = 0 + 1; ; k++)
    {
      if (k >= arrayOfChar.length)
      {
        localArrayList.add(new String(arrayOfChar, i, arrayOfChar.length - i));
        arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
        break;
      }
      m = Character.getType(arrayOfChar[k]);
      if (m != j)
        break label128;
    }
    label128: int n;
    if ((paramBoolean) && (m == 2) && (j == 1))
    {
      n = k - 1;
      if (n != i)
        localArrayList.add(new String(arrayOfChar, i, n - i));
    }
    for (i = n; ; i = k)
    {
      j = m;
      break;
      localArrayList.add(new String(arrayOfChar, i, k - i));
    }
  }

  public static String[] splitByCharacterTypeCamelCase(String paramString)
  {
    return splitByCharacterType(paramString, true);
  }

  public static String[] splitByWholeSeparator(String paramString1, String paramString2)
  {
    return splitByWholeSeparatorWorker(paramString1, paramString2, -1, false);
  }

  public static String[] splitByWholeSeparator(String paramString1, String paramString2, int paramInt)
  {
    return splitByWholeSeparatorWorker(paramString1, paramString2, paramInt, false);
  }

  public static String[] splitByWholeSeparatorPreserveAllTokens(String paramString1, String paramString2)
  {
    return splitByWholeSeparatorWorker(paramString1, paramString2, -1, true);
  }

  public static String[] splitByWholeSeparatorPreserveAllTokens(String paramString1, String paramString2, int paramInt)
  {
    return splitByWholeSeparatorWorker(paramString1, paramString2, paramInt, true);
  }

  private static String[] splitByWholeSeparatorWorker(String paramString1, String paramString2, int paramInt, boolean paramBoolean)
  {
    String[] arrayOfString = null;
    if (paramString1 == null);
    int i;
    while (true)
    {
      return arrayOfString;
      i = paramString1.length();
      if (i == 0)
      {
        arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY;
      }
      else
      {
        if ((paramString2 != null) && (!"".equals(paramString2)))
          break;
        arrayOfString = splitWorker(paramString1, null, paramInt, paramBoolean);
      }
    }
    int j = paramString2.length();
    ArrayList localArrayList = new ArrayList();
    int k = 0;
    int m = 0;
    int n = 0;
    while (true)
    {
      if (n >= i)
      {
        arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
        break;
      }
      n = paramString1.indexOf(paramString2, m);
      if (n > -1)
      {
        if (n > m)
        {
          k++;
          if (k == paramInt)
          {
            n = i;
            localArrayList.add(paramString1.substring(m));
          }
          else
          {
            localArrayList.add(paramString1.substring(m, n));
            m = n + j;
          }
        }
        else
        {
          if (paramBoolean)
          {
            k++;
            if (k != paramInt)
              break label219;
            n = i;
            localArrayList.add(paramString1.substring(m));
          }
          while (true)
          {
            m = n + j;
            break;
            label219: localArrayList.add("");
          }
        }
      }
      else
      {
        localArrayList.add(paramString1.substring(m));
        n = i;
      }
    }
  }

  public static String[] splitPreserveAllTokens(String paramString)
  {
    return splitWorker(paramString, null, -1, true);
  }

  public static String[] splitPreserveAllTokens(String paramString, char paramChar)
  {
    return splitWorker(paramString, paramChar, true);
  }

  public static String[] splitPreserveAllTokens(String paramString1, String paramString2)
  {
    return splitWorker(paramString1, paramString2, -1, true);
  }

  public static String[] splitPreserveAllTokens(String paramString1, String paramString2, int paramInt)
  {
    return splitWorker(paramString1, paramString2, paramInt, true);
  }

  private static String[] splitWorker(String paramString, char paramChar, boolean paramBoolean)
  {
    if (paramString == null);
    int i;
    for (String[] arrayOfString = null; ; arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY)
    {
      return arrayOfString;
      i = paramString.length();
      if (i != 0)
        break;
    }
    ArrayList localArrayList = new ArrayList();
    int j = 0;
    int k = 0;
    int m = 0;
    int n = 0;
    while (true)
    {
      if (j >= i)
      {
        if ((m != 0) || ((paramBoolean) && (n != 0)))
          localArrayList.add(paramString.substring(k, j));
        arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
        break;
      }
      if (paramString.charAt(j) == paramChar)
      {
        if ((m != 0) || (paramBoolean))
        {
          localArrayList.add(paramString.substring(k, j));
          m = 0;
          n = 1;
        }
        j++;
        k = j;
      }
      else
      {
        n = 0;
        m = 1;
        j++;
      }
    }
  }

  private static String[] splitWorker(String paramString1, String paramString2, int paramInt, boolean paramBoolean)
  {
    String[] arrayOfString;
    if (paramString1 == null)
      arrayOfString = null;
    int i;
    ArrayList localArrayList;
    int j;
    int k;
    int m;
    int n;
    int i6;
    while (true)
    {
      return arrayOfString;
      i = paramString1.length();
      if (i == 0)
      {
        arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY;
      }
      else
      {
        localArrayList = new ArrayList();
        j = 0;
        k = 0;
        m = 0;
        n = 0;
        if (paramString2 != null)
          break label210;
        i6 = 1;
        if (j < i)
          break;
        label67: if ((m != 0) || ((paramBoolean) && (n != 0)))
          localArrayList.add(paramString1.substring(k, j));
        arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
      }
    }
    int i7;
    if (Character.isWhitespace(paramString1.charAt(j)))
    {
      if ((m == 0) && (!paramBoolean))
        break label447;
      n = 1;
      i7 = i6 + 1;
      if (i6 == paramInt)
      {
        j = i;
        n = 0;
      }
      localArrayList.add(paramString1.substring(k, j));
      m = 0;
    }
    while (true)
    {
      j++;
      k = j;
      i6 = i7;
      break;
      n = 0;
      m = 1;
      j++;
      break;
      label210: int i4;
      int i5;
      if (paramString2.length() == 1)
      {
        int i3 = paramString2.charAt(0);
        i4 = 1;
        while (j < i)
          if (paramString1.charAt(j) == i3)
          {
            if ((m == 0) && (!paramBoolean))
              break label434;
            n = 1;
            i5 = i4 + 1;
            if (i4 == paramInt)
            {
              j = i;
              n = 0;
            }
            localArrayList.add(paramString1.substring(k, j));
            m = 0;
            label302: j++;
            k = j;
            i4 = i5;
          }
          else
          {
            n = 0;
            m = 1;
            j++;
          }
        break label67;
      }
      label391: label427: label434: label445: 
      while (true)
      {
        int i1;
        int i2;
        if (paramString2.indexOf(paramString1.charAt(j)) >= 0)
        {
          if ((m == 0) && (!paramBoolean))
            break label427;
          n = 1;
          i2 = i1 + 1;
          if (i1 == paramInt)
          {
            j = i;
            n = 0;
          }
          localArrayList.add(paramString1.substring(k, j));
          m = 0;
          j++;
          k = j;
          i1 = i2;
        }
        while (true)
        {
          if (j < i)
            break label445;
          break;
          n = 0;
          m = 1;
          j++;
          continue;
          i2 = i1;
          break label391;
          i5 = i4;
          break label302;
          i1 = 1;
        }
      }
      label447: i7 = i6;
    }
  }

  public static boolean startsWith(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    return startsWith(paramCharSequence1, paramCharSequence2, false);
  }

  private static boolean startsWith(CharSequence paramCharSequence1, CharSequence paramCharSequence2, boolean paramBoolean)
  {
    boolean bool = false;
    if ((paramCharSequence1 == null) || (paramCharSequence2 == null))
      if ((paramCharSequence1 == null) && (paramCharSequence2 == null))
        bool = true;
    while (true)
    {
      return bool;
      if (paramCharSequence2.length() <= paramCharSequence1.length())
        bool = CharSequenceUtils.regionMatches(paramCharSequence1, paramBoolean, 0, paramCharSequence2, 0, paramCharSequence2.length());
    }
  }

  public static boolean startsWithAny(CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence)
  {
    boolean bool = false;
    if ((isEmpty(paramCharSequence)) || (ArrayUtils.isEmpty(paramArrayOfCharSequence)));
    label50: 
    while (true)
    {
      return bool;
      int i = paramArrayOfCharSequence.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label50;
        if (startsWith(paramCharSequence, paramArrayOfCharSequence[j]))
        {
          bool = true;
          break;
        }
      }
    }
  }

  public static boolean startsWithIgnoreCase(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    return startsWith(paramCharSequence1, paramCharSequence2, true);
  }

  public static String strip(String paramString)
  {
    return strip(paramString, null);
  }

  public static String strip(String paramString1, String paramString2)
  {
    if (isEmpty(paramString1));
    while (true)
    {
      return paramString1;
      paramString1 = stripEnd(stripStart(paramString1, paramString2), paramString2);
    }
  }

  public static String stripAccents(String paramString)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      try
      {
        if (InitStripAccents.java6NormalizeMethod != null)
        {
          str = removeAccentsJava6(paramString);
          continue;
        }
        if (InitStripAccents.sunDecomposeMethod != null)
        {
          str = removeAccentsSUN(paramString);
          continue;
        }
        throw new UnsupportedOperationException("The stripAccents(CharSequence) method requires at least Java6, but got: " + InitStripAccents.java6Exception + "; or a Sun JVM: " + InitStripAccents.sunException);
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new RuntimeException("IllegalArgumentException occurred", localIllegalArgumentException);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        throw new RuntimeException("IllegalAccessException occurred", localIllegalAccessException);
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        throw new RuntimeException("InvocationTargetException occurred", localInvocationTargetException);
      }
      catch (SecurityException localSecurityException)
      {
        throw new RuntimeException("SecurityException occurred", localSecurityException);
      }
    }
  }

  public static String[] stripAll(String[] paramArrayOfString)
  {
    return stripAll(paramArrayOfString, null);
  }

  public static String[] stripAll(String[] paramArrayOfString, String paramString)
  {
    int i;
    String[] arrayOfString;
    if (paramArrayOfString != null)
    {
      i = paramArrayOfString.length;
      if (i != 0);
    }
    else
    {
      arrayOfString = paramArrayOfString;
    }
    while (true)
    {
      return arrayOfString;
      arrayOfString = new String[i];
      for (int j = 0; j < i; j++)
        arrayOfString[j] = strip(paramArrayOfString[j], paramString);
    }
  }

  public static String stripEnd(String paramString1, String paramString2)
  {
    int i;
    if (paramString1 != null)
    {
      i = paramString1.length();
      if (i != 0);
    }
    else
    {
      return paramString1;
    }
    if (paramString2 == null)
      label19: if ((i != 0) && (Character.isWhitespace(paramString1.charAt(i - 1))));
    while (true)
    {
      paramString1 = paramString1.substring(0, i);
      break;
      i--;
      break label19;
      if (paramString2.length() == 0)
        break;
      while ((i != 0) && (paramString2.indexOf(paramString1.charAt(i - 1)) != -1))
        i--;
    }
  }

  public static String stripStart(String paramString1, String paramString2)
  {
    int i;
    if (paramString1 != null)
    {
      i = paramString1.length();
      if (i != 0);
    }
    else
    {
      return paramString1;
    }
    int j = 0;
    if (paramString2 == null)
      label21: if ((j != i) && (Character.isWhitespace(paramString1.charAt(j))));
    while (true)
    {
      paramString1 = paramString1.substring(j);
      break;
      j++;
      break label21;
      if (paramString2.length() == 0)
        break;
      while ((j != i) && (paramString2.indexOf(paramString1.charAt(j)) != -1))
        j++;
    }
  }

  public static String stripToEmpty(String paramString)
  {
    if (paramString == null);
    for (String str = ""; ; str = strip(paramString, null))
      return str;
  }

  public static String stripToNull(String paramString)
  {
    Object localObject = null;
    if (paramString == null);
    while (true)
    {
      return localObject;
      String str = strip(paramString, null);
      if (str.length() == 0)
        str = null;
      localObject = str;
    }
  }

  public static String substring(String paramString, int paramInt)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      if (paramInt < 0)
        paramInt += paramString.length();
      if (paramInt < 0)
        paramInt = 0;
      if (paramInt > paramString.length())
        str = "";
      else
        str = paramString.substring(paramInt);
    }
  }

  public static String substring(String paramString, int paramInt1, int paramInt2)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      if (paramInt2 < 0)
        paramInt2 += paramString.length();
      if (paramInt1 < 0)
        paramInt1 += paramString.length();
      if (paramInt2 > paramString.length())
        paramInt2 = paramString.length();
      if (paramInt1 > paramInt2)
      {
        str = "";
      }
      else
      {
        if (paramInt1 < 0)
          paramInt1 = 0;
        if (paramInt2 < 0)
          paramInt2 = 0;
        str = paramString.substring(paramInt1, paramInt2);
      }
    }
  }

  public static String substringAfter(String paramString1, String paramString2)
  {
    if (isEmpty(paramString1));
    while (true)
    {
      return paramString1;
      if (paramString2 == null)
      {
        paramString1 = "";
      }
      else
      {
        int i = paramString1.indexOf(paramString2);
        if (i == -1)
          paramString1 = "";
        else
          paramString1 = paramString1.substring(i + paramString2.length());
      }
    }
  }

  public static String substringAfterLast(String paramString1, String paramString2)
  {
    if (isEmpty(paramString1));
    while (true)
    {
      return paramString1;
      if (isEmpty(paramString2))
      {
        paramString1 = "";
      }
      else
      {
        int i = paramString1.lastIndexOf(paramString2);
        if ((i == -1) || (i == paramString1.length() - paramString2.length()))
          paramString1 = "";
        else
          paramString1 = paramString1.substring(i + paramString2.length());
      }
    }
  }

  public static String substringBefore(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (paramString2 == null));
    while (true)
    {
      return paramString1;
      if (paramString2.length() == 0)
      {
        paramString1 = "";
      }
      else
      {
        int i = paramString1.indexOf(paramString2);
        if (i != -1)
          paramString1 = paramString1.substring(0, i);
      }
    }
  }

  public static String substringBeforeLast(String paramString1, String paramString2)
  {
    if ((isEmpty(paramString1)) || (isEmpty(paramString2)));
    while (true)
    {
      return paramString1;
      int i = paramString1.lastIndexOf(paramString2);
      if (i != -1)
        paramString1 = paramString1.substring(0, i);
    }
  }

  public static String substringBetween(String paramString1, String paramString2)
  {
    return substringBetween(paramString1, paramString2, paramString2);
  }

  public static String substringBetween(String paramString1, String paramString2, String paramString3)
  {
    String str = null;
    if ((paramString1 == null) || (paramString2 == null) || (paramString3 == null));
    while (true)
    {
      return str;
      int i = paramString1.indexOf(paramString2);
      if (i != -1)
      {
        int j = paramString1.indexOf(paramString3, i + paramString2.length());
        if (j != -1)
          str = paramString1.substring(i + paramString2.length(), j);
      }
    }
  }

  public static String[] substringsBetween(String paramString1, String paramString2, String paramString3)
  {
    String[] arrayOfString = null;
    label20: int i;
    int j;
    int k;
    ArrayList localArrayList;
    if ((paramString1 == null) || (isEmpty(paramString2)) || (isEmpty(paramString3)));else
    {
      while (true)
      {
        return arrayOfString;
        i = paramString1.length();
        if (i != 0)
          break;
        arrayOfString = ArrayUtils.EMPTY_STRING_ARRAY;
      }
      j = paramString3.length();
      k = paramString2.length();
      localArrayList = new ArrayList();
    }
    int i2;
    for (int m = 0; ; m = i2 + j)
    {
      if (m >= i - j)
      {
        if (localArrayList.isEmpty())
          break label20;
        arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
        break label20;
      }
      int n = paramString1.indexOf(paramString2, m);
      if (n < 0)
        break;
      int i1 = n + k;
      i2 = paramString1.indexOf(paramString3, i1);
      if (i2 < 0)
        break;
      localArrayList.add(paramString1.substring(i1, i2));
    }
  }

  public static String swapCase(String paramString)
  {
    if (isEmpty(paramString));
    char[] arrayOfChar;
    int i;
    while (true)
    {
      return paramString;
      arrayOfChar = paramString.toCharArray();
      i = 0;
      if (i < arrayOfChar.length)
        break;
      paramString = new String(arrayOfChar);
    }
    char c = arrayOfChar[i];
    if (Character.isUpperCase(c))
      arrayOfChar[i] = Character.toLowerCase(c);
    while (true)
    {
      i++;
      break;
      if (Character.isTitleCase(c))
        arrayOfChar[i] = Character.toLowerCase(c);
      else if (Character.isLowerCase(c))
        arrayOfChar[i] = Character.toUpperCase(c);
    }
  }

  public static String toString(byte[] paramArrayOfByte, String paramString)
    throws UnsupportedEncodingException
  {
    if (paramString == null);
    for (String str = new String(paramArrayOfByte); ; str = new String(paramArrayOfByte, paramString))
      return str;
  }

  public static String trim(String paramString)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.trim())
      return str;
  }

  public static String trimToEmpty(String paramString)
  {
    if (paramString == null);
    for (String str = ""; ; str = paramString.trim())
      return str;
  }

  public static String trimToNull(String paramString)
  {
    String str = trim(paramString);
    if (isEmpty(str))
      str = null;
    return str;
  }

  public static String uncapitalize(String paramString)
  {
    int i;
    if (paramString != null)
    {
      i = paramString.length();
      if (i != 0)
        break label15;
    }
    while (true)
    {
      return paramString;
      label15: paramString = i + Character.toLowerCase(paramString.charAt(0)) + paramString.substring(1);
    }
  }

  public static String upperCase(String paramString)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.toUpperCase())
      return str;
  }

  public static String upperCase(String paramString, Locale paramLocale)
  {
    if (paramString == null);
    for (String str = null; ; str = paramString.toUpperCase(paramLocale))
      return str;
  }

  private static class InitStripAccents
  {
    private static final Throwable java6Exception;
    private static final Method java6NormalizeMethod;
    private static final Object java6NormalizerFormNFD;
    private static final Pattern java6Pattern;
    private static final Method sunDecomposeMethod;
    private static final Throwable sunException;
    private static final Pattern sunPattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");

    static
    {
      java6Pattern = sunPattern;
      Object localObject1 = null;
      Object localObject2 = null;
      Object localObject3 = null;
      Object localObject4 = null;
      Object localObject5 = null;
      try
      {
        Class localClass2 = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer$Form");
        localObject1 = localClass2.getField("NFD").get(null);
        Method localMethod2 = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer").getMethod("normalize", new Class[] { CharSequence.class, localClass2 });
        localObject2 = localMethod2;
        java6Exception = localObject4;
        java6NormalizerFormNFD = localObject1;
        java6NormalizeMethod = localObject2;
        sunException = localObject5;
        sunDecomposeMethod = localObject3;
        return;
      }
      catch (Exception localException1)
      {
        while (true)
        {
          localObject4 = localException1;
          try
          {
            Class localClass1 = Thread.currentThread().getContextClassLoader().loadClass("sun.text.Normalizer");
            Class[] arrayOfClass = new Class[3];
            arrayOfClass[0] = String.class;
            arrayOfClass[1] = Boolean.TYPE;
            arrayOfClass[2] = Integer.TYPE;
            Method localMethod1 = localClass1.getMethod("decompose", arrayOfClass);
            localObject3 = localMethod1;
          }
          catch (Exception localException2)
          {
            localObject5 = localException2;
          }
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.StringUtils
 * JD-Core Version:    0.6.2
 */