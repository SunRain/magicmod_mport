package org.apache.commons.lang3;

import java.io.Serializable;
import java.util.Comparator;

public final class Range<T>
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private final Comparator<T> comparator;
  private transient int hashCode;
  private final T maximum;
  private final T minimum;
  private transient String toString;

  private Range(T paramT1, T paramT2, Comparator<T> paramComparator)
  {
    if ((paramT1 == null) || (paramT2 == null))
      throw new IllegalArgumentException("Elements in a range must not be null: element1=" + paramT1 + ", element2=" + paramT2);
    if (paramComparator == null)
      paramComparator = ComparableComparator.INSTANCE;
    if (paramComparator.compare(paramT1, paramT2) < 1)
      this.minimum = paramT1;
    for (this.maximum = paramT2; ; this.maximum = paramT1)
    {
      this.comparator = paramComparator;
      return;
      this.minimum = paramT2;
    }
  }

  public static <T extends Comparable<T>> Range<T> between(T paramT1, T paramT2)
  {
    return between(paramT1, paramT2, null);
  }

  public static <T> Range<T> between(T paramT1, T paramT2, Comparator<T> paramComparator)
  {
    return new Range(paramT1, paramT2, paramComparator);
  }

  public static <T extends Comparable<T>> Range<T> is(T paramT)
  {
    return between(paramT, paramT, null);
  }

  public static <T> Range<T> is(T paramT, Comparator<T> paramComparator)
  {
    return between(paramT, paramT, paramComparator);
  }

  public boolean contains(T paramT)
  {
    boolean bool = false;
    if (paramT == null);
    while (true)
    {
      return bool;
      if ((this.comparator.compare(paramT, this.minimum) > -1) && (this.comparator.compare(paramT, this.maximum) < 1))
        bool = true;
    }
  }

  public boolean containsRange(Range<T> paramRange)
  {
    boolean bool = false;
    if (paramRange == null);
    while (true)
    {
      return bool;
      if ((contains(paramRange.minimum)) && (contains(paramRange.maximum)))
        bool = true;
    }
  }

  public int elementCompareTo(T paramT)
  {
    if (paramT == null)
      throw new NullPointerException("Element is null");
    int i;
    if (isAfter(paramT))
      i = -1;
    while (true)
    {
      return i;
      if (isBefore(paramT))
        i = 1;
      else
        i = 0;
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this);
    while (true)
    {
      return bool;
      if ((paramObject == null) || (paramObject.getClass() != getClass()))
      {
        bool = false;
      }
      else
      {
        Range localRange = (Range)paramObject;
        if ((!this.minimum.equals(localRange.minimum)) || (!this.maximum.equals(localRange.maximum)))
          bool = false;
      }
    }
  }

  public Comparator<T> getComparator()
  {
    return this.comparator;
  }

  public T getMaximum()
  {
    return this.maximum;
  }

  public T getMinimum()
  {
    return this.minimum;
  }

  public int hashCode()
  {
    int i = this.hashCode;
    if (this.hashCode == 0)
    {
      i = 37 * (37 * (629 + getClass().hashCode()) + this.minimum.hashCode()) + this.maximum.hashCode();
      this.hashCode = i;
    }
    return i;
  }

  public Range<T> intersectionWith(Range<T> paramRange)
  {
    if (!isOverlappedBy(paramRange))
      throw new IllegalArgumentException(String.format("Cannot calculate intersection with non-overlapping range %s", new Object[] { paramRange }));
    if (equals(paramRange))
      return this;
    Object localObject1;
    if (getComparator().compare(this.minimum, paramRange.minimum) < 0)
    {
      localObject1 = paramRange.minimum;
      label64: if (getComparator().compare(this.maximum, paramRange.maximum) >= 0)
        break label110;
    }
    label110: for (Object localObject2 = this.maximum; ; localObject2 = paramRange.maximum)
    {
      this = between(localObject1, localObject2, getComparator());
      break;
      localObject1 = this.minimum;
      break label64;
    }
  }

  public boolean isAfter(T paramT)
  {
    boolean bool = false;
    if (paramT == null);
    while (true)
    {
      return bool;
      if (this.comparator.compare(paramT, this.minimum) < 0)
        bool = true;
    }
  }

  public boolean isAfterRange(Range<T> paramRange)
  {
    if (paramRange == null);
    for (boolean bool = false; ; bool = isAfter(paramRange.maximum))
      return bool;
  }

  public boolean isBefore(T paramT)
  {
    boolean bool = false;
    if (paramT == null);
    while (true)
    {
      return bool;
      if (this.comparator.compare(paramT, this.maximum) > 0)
        bool = true;
    }
  }

  public boolean isBeforeRange(Range<T> paramRange)
  {
    if (paramRange == null);
    for (boolean bool = false; ; bool = isBefore(paramRange.minimum))
      return bool;
  }

  public boolean isEndedBy(T paramT)
  {
    boolean bool = false;
    if (paramT == null);
    while (true)
    {
      return bool;
      if (this.comparator.compare(paramT, this.maximum) == 0)
        bool = true;
    }
  }

  public boolean isNaturalOrdering()
  {
    if (this.comparator == ComparableComparator.INSTANCE);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isOverlappedBy(Range<T> paramRange)
  {
    boolean bool = false;
    if (paramRange == null);
    while (true)
    {
      return bool;
      if ((paramRange.contains(this.minimum)) || (paramRange.contains(this.maximum)) || (contains(paramRange.minimum)))
        bool = true;
    }
  }

  public boolean isStartedBy(T paramT)
  {
    boolean bool = false;
    if (paramT == null);
    while (true)
    {
      return bool;
      if (this.comparator.compare(paramT, this.minimum) == 0)
        bool = true;
    }
  }

  public String toString()
  {
    String str = this.toString;
    if (str == null)
    {
      StringBuilder localStringBuilder = new StringBuilder(32);
      localStringBuilder.append('[');
      localStringBuilder.append(this.minimum);
      localStringBuilder.append("..");
      localStringBuilder.append(this.maximum);
      localStringBuilder.append(']');
      str = localStringBuilder.toString();
      this.toString = str;
    }
    return str;
  }

  public String toString(String paramString)
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = this.minimum;
    arrayOfObject[1] = this.maximum;
    arrayOfObject[2] = this.comparator;
    return String.format(paramString, arrayOfObject);
  }

  private static enum ComparableComparator
    implements Comparator
  {
    static
    {
      ComparableComparator[] arrayOfComparableComparator = new ComparableComparator[1];
      arrayOfComparableComparator[0] = INSTANCE;
    }

    public int compare(Object paramObject1, Object paramObject2)
    {
      return ((Comparable)paramObject1).compareTo(paramObject2);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.Range
 * JD-Core Version:    0.6.2
 */