package org.apache.commons.lang3.text;

import java.io.Reader;
import java.io.Writer;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.SystemUtils;

public class StrBuilder
  implements CharSequence, Appendable
{
  static final int CAPACITY = 32;
  private static final long serialVersionUID = 7628716375283629643L;
  protected char[] buffer;
  private String newLine;
  private String nullText;
  protected int size;

  public StrBuilder()
  {
    this(32);
  }

  public StrBuilder(int paramInt)
  {
    if (paramInt <= 0)
      paramInt = 32;
    this.buffer = new char[paramInt];
  }

  public StrBuilder(String paramString)
  {
    if (paramString == null)
      this.buffer = new char[32];
    while (true)
    {
      return;
      this.buffer = new char[32 + paramString.length()];
      append(paramString);
    }
  }

  private void deleteImpl(int paramInt1, int paramInt2, int paramInt3)
  {
    System.arraycopy(this.buffer, paramInt2, this.buffer, paramInt1, this.size - paramInt2);
    this.size -= paramInt3;
  }

  private StrBuilder replaceImpl(StrMatcher paramStrMatcher, String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramStrMatcher == null) || (this.size == 0))
      return this;
    if (paramString == null);
    for (int i = 0; ; i = paramString.length())
    {
      char[] arrayOfChar = this.buffer;
      for (int j = paramInt1; (j < paramInt2) && (paramInt3 != 0); j++)
      {
        int k = paramStrMatcher.isMatch(arrayOfChar, j, paramInt1, paramInt2);
        if (k > 0)
        {
          replaceImpl(j, j + k, k, paramString, i);
          paramInt2 = i + (paramInt2 - k);
          j = -1 + (j + i);
          if (paramInt3 > 0)
            paramInt3--;
        }
      }
      break;
    }
  }

  private void replaceImpl(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4)
  {
    int i = paramInt4 + (this.size - paramInt3);
    if (paramInt4 != paramInt3)
    {
      ensureCapacity(i);
      System.arraycopy(this.buffer, paramInt2, this.buffer, paramInt1 + paramInt4, this.size - paramInt2);
      this.size = i;
    }
    if (paramInt4 > 0)
      paramString.getChars(0, paramInt4, this.buffer, paramInt1);
  }

  public StrBuilder append(char paramChar)
  {
    ensureCapacity(1 + length());
    char[] arrayOfChar = this.buffer;
    int i = this.size;
    this.size = (i + 1);
    arrayOfChar[i] = paramChar;
    return this;
  }

  public StrBuilder append(double paramDouble)
  {
    return append(String.valueOf(paramDouble));
  }

  public StrBuilder append(float paramFloat)
  {
    return append(String.valueOf(paramFloat));
  }

  public StrBuilder append(int paramInt)
  {
    return append(String.valueOf(paramInt));
  }

  public StrBuilder append(long paramLong)
  {
    return append(String.valueOf(paramLong));
  }

  public StrBuilder append(CharSequence paramCharSequence)
  {
    if (paramCharSequence == null);
    for (StrBuilder localStrBuilder = appendNull(); ; localStrBuilder = append(paramCharSequence.toString()))
      return localStrBuilder;
  }

  public StrBuilder append(CharSequence paramCharSequence, int paramInt1, int paramInt2)
  {
    if (paramCharSequence == null);
    for (StrBuilder localStrBuilder = appendNull(); ; localStrBuilder = append(paramCharSequence.toString(), paramInt1, paramInt2))
      return localStrBuilder;
  }

  public StrBuilder append(Object paramObject)
  {
    if (paramObject == null);
    for (StrBuilder localStrBuilder = appendNull(); ; localStrBuilder = append(paramObject.toString()))
      return localStrBuilder;
  }

  public StrBuilder append(String paramString)
  {
    if (paramString == null)
      this = appendNull();
    while (true)
    {
      return this;
      int i = paramString.length();
      if (i > 0)
      {
        int j = length();
        ensureCapacity(j + i);
        paramString.getChars(0, i, this.buffer, j);
        this.size = (i + this.size);
      }
    }
  }

  public StrBuilder append(String paramString, int paramInt1, int paramInt2)
  {
    if (paramString == null)
      this = appendNull();
    while (true)
    {
      return this;
      if ((paramInt1 < 0) || (paramInt1 > paramString.length()))
        throw new StringIndexOutOfBoundsException("startIndex must be valid");
      if ((paramInt2 < 0) || (paramInt1 + paramInt2 > paramString.length()))
        throw new StringIndexOutOfBoundsException("length must be valid");
      if (paramInt2 > 0)
      {
        int i = length();
        ensureCapacity(i + paramInt2);
        paramString.getChars(paramInt1, paramInt1 + paramInt2, this.buffer, i);
        this.size = (paramInt2 + this.size);
      }
    }
  }

  public StrBuilder append(StringBuffer paramStringBuffer)
  {
    if (paramStringBuffer == null)
      this = appendNull();
    while (true)
    {
      return this;
      int i = paramStringBuffer.length();
      if (i > 0)
      {
        int j = length();
        ensureCapacity(j + i);
        paramStringBuffer.getChars(0, i, this.buffer, j);
        this.size = (i + this.size);
      }
    }
  }

  public StrBuilder append(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    if (paramStringBuffer == null)
      this = appendNull();
    while (true)
    {
      return this;
      if ((paramInt1 < 0) || (paramInt1 > paramStringBuffer.length()))
        throw new StringIndexOutOfBoundsException("startIndex must be valid");
      if ((paramInt2 < 0) || (paramInt1 + paramInt2 > paramStringBuffer.length()))
        throw new StringIndexOutOfBoundsException("length must be valid");
      if (paramInt2 > 0)
      {
        int i = length();
        ensureCapacity(i + paramInt2);
        paramStringBuffer.getChars(paramInt1, paramInt1 + paramInt2, this.buffer, i);
        this.size = (paramInt2 + this.size);
      }
    }
  }

  public StrBuilder append(StrBuilder paramStrBuilder)
  {
    if (paramStrBuilder == null)
      this = appendNull();
    while (true)
    {
      return this;
      int i = paramStrBuilder.length();
      if (i > 0)
      {
        int j = length();
        ensureCapacity(j + i);
        System.arraycopy(paramStrBuilder.buffer, 0, this.buffer, j, i);
        this.size = (i + this.size);
      }
    }
  }

  public StrBuilder append(StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    if (paramStrBuilder == null)
      this = appendNull();
    while (true)
    {
      return this;
      if ((paramInt1 < 0) || (paramInt1 > paramStrBuilder.length()))
        throw new StringIndexOutOfBoundsException("startIndex must be valid");
      if ((paramInt2 < 0) || (paramInt1 + paramInt2 > paramStrBuilder.length()))
        throw new StringIndexOutOfBoundsException("length must be valid");
      if (paramInt2 > 0)
      {
        int i = length();
        ensureCapacity(i + paramInt2);
        paramStrBuilder.getChars(paramInt1, paramInt1 + paramInt2, this.buffer, i);
        this.size = (paramInt2 + this.size);
      }
    }
  }

  public StrBuilder append(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      ensureCapacity(4 + this.size);
      char[] arrayOfChar6 = this.buffer;
      int i1 = this.size;
      this.size = (i1 + 1);
      arrayOfChar6[i1] = 't';
      char[] arrayOfChar7 = this.buffer;
      int i2 = this.size;
      this.size = (i2 + 1);
      arrayOfChar7[i2] = 'r';
      char[] arrayOfChar8 = this.buffer;
      int i3 = this.size;
      this.size = (i3 + 1);
      arrayOfChar8[i3] = 'u';
      char[] arrayOfChar9 = this.buffer;
      int i4 = this.size;
      this.size = (i4 + 1);
      arrayOfChar9[i4] = 'e';
    }
    while (true)
    {
      return this;
      ensureCapacity(5 + this.size);
      char[] arrayOfChar1 = this.buffer;
      int i = this.size;
      this.size = (i + 1);
      arrayOfChar1[i] = 'f';
      char[] arrayOfChar2 = this.buffer;
      int j = this.size;
      this.size = (j + 1);
      arrayOfChar2[j] = 'a';
      char[] arrayOfChar3 = this.buffer;
      int k = this.size;
      this.size = (k + 1);
      arrayOfChar3[k] = 'l';
      char[] arrayOfChar4 = this.buffer;
      int m = this.size;
      this.size = (m + 1);
      arrayOfChar4[m] = 's';
      char[] arrayOfChar5 = this.buffer;
      int n = this.size;
      this.size = (n + 1);
      arrayOfChar5[n] = 'e';
    }
  }

  public StrBuilder append(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null)
      this = appendNull();
    while (true)
    {
      return this;
      int i = paramArrayOfChar.length;
      if (i > 0)
      {
        int j = length();
        ensureCapacity(j + i);
        System.arraycopy(paramArrayOfChar, 0, this.buffer, j, i);
        this.size = (i + this.size);
      }
    }
  }

  public StrBuilder append(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    if (paramArrayOfChar == null)
      this = appendNull();
    while (true)
    {
      return this;
      if ((paramInt1 < 0) || (paramInt1 > paramArrayOfChar.length))
        throw new StringIndexOutOfBoundsException("Invalid startIndex: " + paramInt2);
      if ((paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfChar.length))
        throw new StringIndexOutOfBoundsException("Invalid length: " + paramInt2);
      if (paramInt2 > 0)
      {
        int i = length();
        ensureCapacity(i + paramInt2);
        System.arraycopy(paramArrayOfChar, paramInt1, this.buffer, i, paramInt2);
        this.size = (paramInt2 + this.size);
      }
    }
  }

  public StrBuilder appendAll(Iterable<?> paramIterable)
  {
    Iterator localIterator;
    if (paramIterable != null)
      localIterator = paramIterable.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return this;
      append(localIterator.next());
    }
  }

  public StrBuilder appendAll(Iterator<?> paramIterator)
  {
    if (paramIterator != null);
    while (true)
    {
      if (!paramIterator.hasNext())
        return this;
      append(paramIterator.next());
    }
  }

  public StrBuilder appendAll(Object[] paramArrayOfObject)
  {
    int i;
    if ((paramArrayOfObject != null) && (paramArrayOfObject.length > 0))
      i = paramArrayOfObject.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return this;
      append(paramArrayOfObject[j]);
    }
  }

  public StrBuilder appendFixedWidthPadLeft(int paramInt1, int paramInt2, char paramChar)
  {
    return appendFixedWidthPadLeft(String.valueOf(paramInt1), paramInt2, paramChar);
  }

  public StrBuilder appendFixedWidthPadLeft(Object paramObject, int paramInt, char paramChar)
  {
    if (paramInt > 0)
    {
      ensureCapacity(paramInt + this.size);
      if (paramObject != null)
        break label78;
    }
    int i;
    label78: for (String str = getNullText(); ; str = paramObject.toString())
    {
      if (str == null)
        str = "";
      i = str.length();
      if (i < paramInt)
        break;
      str.getChars(i - paramInt, i, this.buffer, this.size);
      this.size = (paramInt + this.size);
      return this;
    }
    int j = paramInt - i;
    for (int k = 0; ; k++)
    {
      if (k >= j)
      {
        str.getChars(0, i, this.buffer, j + this.size);
        break;
      }
      this.buffer[(k + this.size)] = paramChar;
    }
  }

  public StrBuilder appendFixedWidthPadRight(int paramInt1, int paramInt2, char paramChar)
  {
    return appendFixedWidthPadRight(String.valueOf(paramInt1), paramInt2, paramChar);
  }

  public StrBuilder appendFixedWidthPadRight(Object paramObject, int paramInt, char paramChar)
  {
    String str;
    int i;
    if (paramInt > 0)
    {
      ensureCapacity(paramInt + this.size);
      if (paramObject != null)
        break label74;
      str = getNullText();
      if (str == null)
        str = "";
      i = str.length();
      if (i < paramInt)
        break label83;
      str.getChars(0, paramInt, this.buffer, this.size);
    }
    while (true)
    {
      this.size = (paramInt + this.size);
      return this;
      label74: str = paramObject.toString();
      break;
      label83: int j = paramInt - i;
      str.getChars(0, i, this.buffer, this.size);
      for (int k = 0; k < j; k++)
        this.buffer[(k + (i + this.size))] = paramChar;
    }
  }

  public StrBuilder appendNewLine()
  {
    if (this.newLine == null)
      append(SystemUtils.LINE_SEPARATOR);
    while (true)
    {
      return this;
      this = append(this.newLine);
    }
  }

  public StrBuilder appendNull()
  {
    if (this.nullText == null);
    while (true)
    {
      return this;
      this = append(this.nullText);
    }
  }

  public StrBuilder appendPadding(int paramInt, char paramChar)
  {
    if (paramInt >= 0)
      ensureCapacity(paramInt + this.size);
    for (int i = 0; ; i++)
    {
      if (i >= paramInt)
        return this;
      char[] arrayOfChar = this.buffer;
      int j = this.size;
      this.size = (j + 1);
      arrayOfChar[j] = paramChar;
    }
  }

  public StrBuilder appendSeparator(char paramChar)
  {
    if (size() > 0)
      append(paramChar);
    return this;
  }

  public StrBuilder appendSeparator(char paramChar1, char paramChar2)
  {
    if (size() > 0)
      append(paramChar1);
    while (true)
    {
      return this;
      append(paramChar2);
    }
  }

  public StrBuilder appendSeparator(char paramChar, int paramInt)
  {
    if (paramInt > 0)
      append(paramChar);
    return this;
  }

  public StrBuilder appendSeparator(String paramString)
  {
    return appendSeparator(paramString, null);
  }

  public StrBuilder appendSeparator(String paramString, int paramInt)
  {
    if ((paramString != null) && (paramInt > 0))
      append(paramString);
    return this;
  }

  public StrBuilder appendSeparator(String paramString1, String paramString2)
  {
    if (isEmpty());
    for (String str = paramString2; ; str = paramString1)
    {
      if (str != null)
        append(str);
      return this;
    }
  }

  public StrBuilder appendWithSeparators(Iterable<?> paramIterable, String paramString)
  {
    String str;
    Iterator localIterator;
    if (paramIterable != null)
    {
      str = ObjectUtils.toString(paramString);
      localIterator = paramIterable.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
        return this;
      append(localIterator.next());
      if (localIterator.hasNext())
        append(str);
    }
  }

  public StrBuilder appendWithSeparators(Iterator<?> paramIterator, String paramString)
  {
    String str;
    if (paramIterator != null)
      str = ObjectUtils.toString(paramString);
    while (true)
    {
      if (!paramIterator.hasNext())
        return this;
      append(paramIterator.next());
      if (paramIterator.hasNext())
        append(str);
    }
  }

  public StrBuilder appendWithSeparators(Object[] paramArrayOfObject, String paramString)
  {
    String str;
    if ((paramArrayOfObject != null) && (paramArrayOfObject.length > 0))
    {
      str = ObjectUtils.toString(paramString);
      append(paramArrayOfObject[0]);
    }
    for (int i = 1; ; i++)
    {
      if (i >= paramArrayOfObject.length)
        return this;
      append(str);
      append(paramArrayOfObject[i]);
    }
  }

  public StrBuilder appendln(char paramChar)
  {
    return append(paramChar).appendNewLine();
  }

  public StrBuilder appendln(double paramDouble)
  {
    return append(paramDouble).appendNewLine();
  }

  public StrBuilder appendln(float paramFloat)
  {
    return append(paramFloat).appendNewLine();
  }

  public StrBuilder appendln(int paramInt)
  {
    return append(paramInt).appendNewLine();
  }

  public StrBuilder appendln(long paramLong)
  {
    return append(paramLong).appendNewLine();
  }

  public StrBuilder appendln(Object paramObject)
  {
    return append(paramObject).appendNewLine();
  }

  public StrBuilder appendln(String paramString)
  {
    return append(paramString).appendNewLine();
  }

  public StrBuilder appendln(String paramString, int paramInt1, int paramInt2)
  {
    return append(paramString, paramInt1, paramInt2).appendNewLine();
  }

  public StrBuilder appendln(StringBuffer paramStringBuffer)
  {
    return append(paramStringBuffer).appendNewLine();
  }

  public StrBuilder appendln(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    return append(paramStringBuffer, paramInt1, paramInt2).appendNewLine();
  }

  public StrBuilder appendln(StrBuilder paramStrBuilder)
  {
    return append(paramStrBuilder).appendNewLine();
  }

  public StrBuilder appendln(StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    return append(paramStrBuilder, paramInt1, paramInt2).appendNewLine();
  }

  public StrBuilder appendln(boolean paramBoolean)
  {
    return append(paramBoolean).appendNewLine();
  }

  public StrBuilder appendln(char[] paramArrayOfChar)
  {
    return append(paramArrayOfChar).appendNewLine();
  }

  public StrBuilder appendln(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    return append(paramArrayOfChar, paramInt1, paramInt2).appendNewLine();
  }

  public Reader asReader()
  {
    return new StrBuilderReader();
  }

  public StrTokenizer asTokenizer()
  {
    return new StrBuilderTokenizer();
  }

  public Writer asWriter()
  {
    return new StrBuilderWriter();
  }

  public int capacity()
  {
    return this.buffer.length;
  }

  public char charAt(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= length()))
      throw new StringIndexOutOfBoundsException(paramInt);
    return this.buffer[paramInt];
  }

  public StrBuilder clear()
  {
    this.size = 0;
    return this;
  }

  public boolean contains(char paramChar)
  {
    char[] arrayOfChar = this.buffer;
    for (int i = 0; ; i++)
    {
      if (i >= this.size);
      for (boolean bool = false; ; bool = true)
      {
        return bool;
        if (arrayOfChar[i] != paramChar)
          break;
      }
    }
  }

  public boolean contains(String paramString)
  {
    boolean bool = false;
    if (indexOf(paramString, 0) >= 0)
      bool = true;
    return bool;
  }

  public boolean contains(StrMatcher paramStrMatcher)
  {
    boolean bool = false;
    if (indexOf(paramStrMatcher, 0) >= 0)
      bool = true;
    return bool;
  }

  public StrBuilder delete(int paramInt1, int paramInt2)
  {
    int i = validateRange(paramInt1, paramInt2);
    int j = i - paramInt1;
    if (j > 0)
      deleteImpl(paramInt1, i, j);
    return this;
  }

  public StrBuilder deleteAll(char paramChar)
  {
    int i = 0;
    if (i >= this.size)
      return this;
    int j;
    if (this.buffer[i] == paramChar)
    {
      j = i;
      label24: i++;
      if (i < this.size)
        break label59;
    }
    while (true)
    {
      int k = i - j;
      deleteImpl(j, i, k);
      i -= k;
      i++;
      break;
      label59: if (this.buffer[i] == paramChar)
        break label24;
    }
  }

  public StrBuilder deleteAll(String paramString)
  {
    int i;
    if (paramString == null)
    {
      i = 0;
      if (i <= 0);
    }
    for (int j = indexOf(paramString, 0); ; j = indexOf(paramString, j))
    {
      if (j < 0)
      {
        return this;
        i = paramString.length();
        break;
      }
      deleteImpl(j, j + i, i);
    }
  }

  public StrBuilder deleteAll(StrMatcher paramStrMatcher)
  {
    return replace(paramStrMatcher, null, 0, this.size, -1);
  }

  public StrBuilder deleteCharAt(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.size))
      throw new StringIndexOutOfBoundsException(paramInt);
    deleteImpl(paramInt, paramInt + 1, 1);
    return this;
  }

  public StrBuilder deleteFirst(char paramChar)
  {
    for (int i = 0; ; i++)
    {
      if (i >= this.size);
      while (true)
      {
        return this;
        if (this.buffer[i] != paramChar)
          break;
        deleteImpl(i, i + 1, 1);
      }
    }
  }

  public StrBuilder deleteFirst(String paramString)
  {
    if (paramString == null);
    for (int i = 0; ; i = paramString.length())
    {
      if (i > 0)
      {
        int j = indexOf(paramString, 0);
        if (j >= 0)
          deleteImpl(j, j + i, i);
      }
      return this;
    }
  }

  public StrBuilder deleteFirst(StrMatcher paramStrMatcher)
  {
    return replace(paramStrMatcher, null, 0, this.size, 1);
  }

  public boolean endsWith(String paramString)
  {
    boolean bool = false;
    if (paramString == null);
    int i;
    do
      while (true)
      {
        return bool;
        i = paramString.length();
        if (i != 0)
          break;
        bool = true;
      }
    while (i > this.size);
    int j = this.size - i;
    int k = 0;
    while (true)
    {
      if (k >= i)
      {
        bool = true;
        break;
      }
      if (this.buffer[j] != paramString.charAt(k))
        break;
      k++;
      j++;
    }
  }

  public StrBuilder ensureCapacity(int paramInt)
  {
    if (paramInt > this.buffer.length)
    {
      char[] arrayOfChar = this.buffer;
      this.buffer = new char[paramInt * 2];
      System.arraycopy(arrayOfChar, 0, this.buffer, 0, this.size);
    }
    return this;
  }

  public boolean equals(Object paramObject)
  {
    if ((paramObject instanceof StrBuilder));
    for (boolean bool = equals((StrBuilder)paramObject); ; bool = false)
      return bool;
  }

  public boolean equals(StrBuilder paramStrBuilder)
  {
    boolean bool = true;
    if (this == paramStrBuilder);
    label70: 
    while (true)
    {
      return bool;
      if (this.size != paramStrBuilder.size)
      {
        bool = false;
      }
      else
      {
        char[] arrayOfChar1 = this.buffer;
        char[] arrayOfChar2 = paramStrBuilder.buffer;
        for (int i = -1 + this.size; ; i--)
        {
          if (i < 0)
            break label70;
          if (arrayOfChar1[i] != arrayOfChar2[i])
          {
            bool = false;
            break;
          }
        }
      }
    }
  }

  public boolean equalsIgnoreCase(StrBuilder paramStrBuilder)
  {
    boolean bool = true;
    if (this == paramStrBuilder);
    label91: 
    while (true)
    {
      return bool;
      if (this.size != paramStrBuilder.size)
      {
        bool = false;
      }
      else
      {
        char[] arrayOfChar1 = this.buffer;
        char[] arrayOfChar2 = paramStrBuilder.buffer;
        for (int i = -1 + this.size; ; i--)
        {
          if (i < 0)
            break label91;
          char c1 = arrayOfChar1[i];
          char c2 = arrayOfChar2[i];
          if ((c1 != c2) && (Character.toUpperCase(c1) != Character.toUpperCase(c2)))
          {
            bool = false;
            break;
          }
        }
      }
    }
  }

  public void getChars(int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3)
  {
    if (paramInt1 < 0)
      throw new StringIndexOutOfBoundsException(paramInt1);
    if ((paramInt2 < 0) || (paramInt2 > length()))
      throw new StringIndexOutOfBoundsException(paramInt2);
    if (paramInt1 > paramInt2)
      throw new StringIndexOutOfBoundsException("end < start");
    System.arraycopy(this.buffer, paramInt1, paramArrayOfChar, paramInt3, paramInt2 - paramInt1);
  }

  public char[] getChars(char[] paramArrayOfChar)
  {
    int i = length();
    if ((paramArrayOfChar == null) || (paramArrayOfChar.length < i))
      paramArrayOfChar = new char[i];
    System.arraycopy(this.buffer, 0, paramArrayOfChar, 0, i);
    return paramArrayOfChar;
  }

  public String getNewLineText()
  {
    return this.newLine;
  }

  public String getNullText()
  {
    return this.nullText;
  }

  public int hashCode()
  {
    char[] arrayOfChar = this.buffer;
    int i = 0;
    for (int j = -1 + this.size; ; j--)
    {
      if (j < 0)
        return i;
      i = i * 31 + arrayOfChar[j];
    }
  }

  public int indexOf(char paramChar)
  {
    return indexOf(paramChar, 0);
  }

  public int indexOf(char paramChar, int paramInt)
  {
    if (paramInt < 0)
      paramInt = 0;
    if (paramInt >= this.size)
    {
      i = -1;
      return i;
    }
    char[] arrayOfChar = this.buffer;
    for (int i = paramInt; ; i++)
    {
      if (i >= this.size)
      {
        i = -1;
        break;
      }
      if (arrayOfChar[i] == paramChar)
        break;
    }
  }

  public int indexOf(String paramString)
  {
    return indexOf(paramString, 0);
  }

  public int indexOf(String paramString, int paramInt)
  {
    if (paramInt < 0)
      paramInt = 0;
    if ((paramString == null) || (paramInt >= this.size))
      paramInt = -1;
    int i;
    char[] arrayOfChar;
    int k;
    while (true)
    {
      return paramInt;
      i = paramString.length();
      if (i == 1)
        paramInt = indexOf(paramString.charAt(0), paramInt);
      else if (i != 0)
        if (i > this.size)
        {
          paramInt = -1;
        }
        else
        {
          arrayOfChar = this.buffer;
          int j = 1 + (this.size - i);
          k = paramInt;
          label82: if (k < j)
            break;
          paramInt = -1;
        }
    }
    for (int m = 0; ; m++)
    {
      if (m >= i)
      {
        paramInt = k;
        break;
      }
      if (paramString.charAt(m) != arrayOfChar[(k + m)])
      {
        k++;
        break label82;
      }
    }
  }

  public int indexOf(StrMatcher paramStrMatcher)
  {
    return indexOf(paramStrMatcher, 0);
  }

  public int indexOf(StrMatcher paramStrMatcher, int paramInt)
  {
    if (paramInt < 0)
      paramInt = 0;
    if ((paramStrMatcher == null) || (paramInt >= this.size))
    {
      i = -1;
      return i;
    }
    int j = this.size;
    char[] arrayOfChar = this.buffer;
    for (int i = paramInt; ; i++)
    {
      if (i >= j)
      {
        i = -1;
        break;
      }
      if (paramStrMatcher.isMatch(arrayOfChar, i, paramInt, j) > 0)
        break;
    }
  }

  public StrBuilder insert(int paramInt, char paramChar)
  {
    validateIndex(paramInt);
    ensureCapacity(1 + this.size);
    System.arraycopy(this.buffer, paramInt, this.buffer, paramInt + 1, this.size - paramInt);
    this.buffer[paramInt] = paramChar;
    this.size = (1 + this.size);
    return this;
  }

  public StrBuilder insert(int paramInt, double paramDouble)
  {
    return insert(paramInt, String.valueOf(paramDouble));
  }

  public StrBuilder insert(int paramInt, float paramFloat)
  {
    return insert(paramInt, String.valueOf(paramFloat));
  }

  public StrBuilder insert(int paramInt1, int paramInt2)
  {
    return insert(paramInt1, String.valueOf(paramInt2));
  }

  public StrBuilder insert(int paramInt, long paramLong)
  {
    return insert(paramInt, String.valueOf(paramLong));
  }

  public StrBuilder insert(int paramInt, Object paramObject)
  {
    if (paramObject == null);
    for (StrBuilder localStrBuilder = insert(paramInt, this.nullText); ; localStrBuilder = insert(paramInt, paramObject.toString()))
      return localStrBuilder;
  }

  public StrBuilder insert(int paramInt, String paramString)
  {
    validateIndex(paramInt);
    if (paramString == null)
      paramString = this.nullText;
    if (paramString == null);
    for (int i = 0; ; i = paramString.length())
    {
      if (i > 0)
      {
        int j = i + this.size;
        ensureCapacity(j);
        System.arraycopy(this.buffer, paramInt, this.buffer, paramInt + i, this.size - paramInt);
        this.size = j;
        paramString.getChars(0, i, this.buffer, paramInt);
      }
      return this;
    }
  }

  public StrBuilder insert(int paramInt, boolean paramBoolean)
  {
    validateIndex(paramInt);
    if (paramBoolean)
    {
      ensureCapacity(4 + this.size);
      System.arraycopy(this.buffer, paramInt, this.buffer, paramInt + 4, this.size - paramInt);
      char[] arrayOfChar5 = this.buffer;
      int n = paramInt + 1;
      arrayOfChar5[paramInt] = 't';
      char[] arrayOfChar6 = this.buffer;
      int i1 = n + 1;
      arrayOfChar6[n] = 'r';
      char[] arrayOfChar7 = this.buffer;
      int i2 = i1 + 1;
      arrayOfChar7[i1] = 'u';
      this.buffer[i2] = 'e';
    }
    for (this.size = (4 + this.size); ; this.size = (5 + this.size))
    {
      return this;
      ensureCapacity(5 + this.size);
      System.arraycopy(this.buffer, paramInt, this.buffer, paramInt + 5, this.size - paramInt);
      char[] arrayOfChar1 = this.buffer;
      int i = paramInt + 1;
      arrayOfChar1[paramInt] = 'f';
      char[] arrayOfChar2 = this.buffer;
      int j = i + 1;
      arrayOfChar2[i] = 'a';
      char[] arrayOfChar3 = this.buffer;
      int k = j + 1;
      arrayOfChar3[j] = 'l';
      char[] arrayOfChar4 = this.buffer;
      int m = k + 1;
      arrayOfChar4[k] = 's';
      this.buffer[m] = 'e';
    }
  }

  public StrBuilder insert(int paramInt, char[] paramArrayOfChar)
  {
    validateIndex(paramInt);
    if (paramArrayOfChar == null)
      this = insert(paramInt, this.nullText);
    while (true)
    {
      return this;
      int i = paramArrayOfChar.length;
      if (i > 0)
      {
        ensureCapacity(i + this.size);
        System.arraycopy(this.buffer, paramInt, this.buffer, paramInt + i, this.size - paramInt);
        System.arraycopy(paramArrayOfChar, 0, this.buffer, paramInt, i);
        this.size = (i + this.size);
      }
    }
  }

  public StrBuilder insert(int paramInt1, char[] paramArrayOfChar, int paramInt2, int paramInt3)
  {
    validateIndex(paramInt1);
    if (paramArrayOfChar == null)
      this = insert(paramInt1, this.nullText);
    while (true)
    {
      return this;
      if ((paramInt2 < 0) || (paramInt2 > paramArrayOfChar.length))
        throw new StringIndexOutOfBoundsException("Invalid offset: " + paramInt2);
      if ((paramInt3 < 0) || (paramInt2 + paramInt3 > paramArrayOfChar.length))
        throw new StringIndexOutOfBoundsException("Invalid length: " + paramInt3);
      if (paramInt3 > 0)
      {
        ensureCapacity(paramInt3 + this.size);
        System.arraycopy(this.buffer, paramInt1, this.buffer, paramInt1 + paramInt3, this.size - paramInt1);
        System.arraycopy(paramArrayOfChar, paramInt2, this.buffer, paramInt1, paramInt3);
        this.size = (paramInt3 + this.size);
      }
    }
  }

  public boolean isEmpty()
  {
    if (this.size == 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public int lastIndexOf(char paramChar)
  {
    return lastIndexOf(paramChar, -1 + this.size);
  }

  public int lastIndexOf(char paramChar, int paramInt)
  {
    if (paramInt >= this.size)
      paramInt = -1 + this.size;
    if (paramInt < 0)
    {
      i = -1;
      return i;
    }
    for (int i = paramInt; ; i--)
    {
      if (i < 0)
      {
        i = -1;
        break;
      }
      if (this.buffer[i] == paramChar)
        break;
    }
  }

  public int lastIndexOf(String paramString)
  {
    return lastIndexOf(paramString, -1 + this.size);
  }

  public int lastIndexOf(String paramString, int paramInt)
  {
    if (paramInt >= this.size)
      paramInt = -1 + this.size;
    int i;
    if ((paramString == null) || (paramInt < 0))
      i = -1;
    while (true)
    {
      return i;
      int j = paramString.length();
      if ((j > 0) && (j <= this.size))
      {
        if (j == 1)
        {
          i = lastIndexOf(paramString.charAt(0), paramInt);
        }
        else
        {
          i = 1 + (paramInt - j);
          if (i >= 0);
        }
      }
      else
      {
        label121: 
        while (j != 0)
        {
          i = -1;
          break;
          for (int k = 0; ; k++)
          {
            if (k >= j)
              break label121;
            if (paramString.charAt(k) != this.buffer[(i + k)])
            {
              i--;
              break;
            }
          }
          break;
        }
        i = paramInt;
      }
    }
  }

  public int lastIndexOf(StrMatcher paramStrMatcher)
  {
    return lastIndexOf(paramStrMatcher, this.size);
  }

  public int lastIndexOf(StrMatcher paramStrMatcher, int paramInt)
  {
    if (paramInt >= this.size)
      paramInt = -1 + this.size;
    if ((paramStrMatcher == null) || (paramInt < 0))
    {
      i = -1;
      return i;
    }
    char[] arrayOfChar = this.buffer;
    int j = paramInt + 1;
    for (int i = paramInt; ; i--)
    {
      if (i < 0)
      {
        i = -1;
        break;
      }
      if (paramStrMatcher.isMatch(arrayOfChar, i, 0, j) > 0)
        break;
    }
  }

  public String leftString(int paramInt)
  {
    String str;
    if (paramInt <= 0)
      str = "";
    while (true)
    {
      return str;
      if (paramInt >= this.size)
        str = new String(this.buffer, 0, this.size);
      else
        str = new String(this.buffer, 0, paramInt);
    }
  }

  public int length()
  {
    return this.size;
  }

  public String midString(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      paramInt1 = 0;
    String str;
    if ((paramInt2 <= 0) || (paramInt1 >= this.size))
      str = "";
    while (true)
    {
      return str;
      if (this.size <= paramInt1 + paramInt2)
        str = new String(this.buffer, paramInt1, this.size - paramInt1);
      else
        str = new String(this.buffer, paramInt1, paramInt2);
    }
  }

  public StrBuilder minimizeCapacity()
  {
    if (this.buffer.length > length())
    {
      char[] arrayOfChar = this.buffer;
      this.buffer = new char[length()];
      System.arraycopy(arrayOfChar, 0, this.buffer, 0, this.size);
    }
    return this;
  }

  public StrBuilder replace(int paramInt1, int paramInt2, String paramString)
  {
    int i = validateRange(paramInt1, paramInt2);
    if (paramString == null);
    for (int j = 0; ; j = paramString.length())
    {
      replaceImpl(paramInt1, i, i - paramInt1, paramString, j);
      return this;
    }
  }

  public StrBuilder replace(StrMatcher paramStrMatcher, String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    return replaceImpl(paramStrMatcher, paramString, paramInt1, validateRange(paramInt1, paramInt2), paramInt3);
  }

  public StrBuilder replaceAll(char paramChar1, char paramChar2)
  {
    if (paramChar1 != paramChar2);
    for (int i = 0; ; i++)
    {
      if (i >= this.size)
        return this;
      if (this.buffer[i] == paramChar1)
        this.buffer[i] = paramChar2;
    }
  }

  public StrBuilder replaceAll(String paramString1, String paramString2)
  {
    int i;
    int j;
    if (paramString1 == null)
    {
      i = 0;
      if (i > 0)
      {
        if (paramString2 != null)
          break label40;
        j = 0;
      }
    }
    label17: for (int k = indexOf(paramString1, 0); ; k = indexOf(paramString1, k + j))
    {
      if (k < 0)
      {
        return this;
        i = paramString1.length();
        break;
        label40: j = paramString2.length();
        break label17;
      }
      replaceImpl(k, k + i, i, paramString2, j);
    }
  }

  public StrBuilder replaceAll(StrMatcher paramStrMatcher, String paramString)
  {
    return replace(paramStrMatcher, paramString, 0, this.size, -1);
  }

  public StrBuilder replaceFirst(char paramChar1, char paramChar2)
  {
    if (paramChar1 != paramChar2);
    for (int i = 0; ; i++)
    {
      if (i >= this.size);
      while (true)
      {
        return this;
        if (this.buffer[i] != paramChar1)
          break;
        this.buffer[i] = paramChar2;
      }
    }
  }

  public StrBuilder replaceFirst(String paramString1, String paramString2)
  {
    int i = 0;
    int j;
    int k;
    if (paramString1 == null)
    {
      j = 0;
      if (j > 0)
      {
        k = indexOf(paramString1, 0);
        if (k >= 0)
          if (paramString2 != null)
            break label57;
      }
    }
    while (true)
    {
      replaceImpl(k, k + j, j, paramString2, i);
      return this;
      j = paramString1.length();
      break;
      label57: i = paramString2.length();
    }
  }

  public StrBuilder replaceFirst(StrMatcher paramStrMatcher, String paramString)
  {
    return replace(paramStrMatcher, paramString, 0, this.size, 1);
  }

  public StrBuilder reverse()
  {
    if (this.size == 0);
    while (true)
    {
      return this;
      int i = this.size / 2;
      char[] arrayOfChar = this.buffer;
      int j = 0;
      for (int k = -1 + this.size; j < i; k--)
      {
        int m = arrayOfChar[j];
        arrayOfChar[j] = arrayOfChar[k];
        arrayOfChar[k] = m;
        j++;
      }
    }
  }

  public String rightString(int paramInt)
  {
    String str;
    if (paramInt <= 0)
      str = "";
    while (true)
    {
      return str;
      if (paramInt >= this.size)
        str = new String(this.buffer, 0, this.size);
      else
        str = new String(this.buffer, this.size - paramInt, paramInt);
    }
  }

  public StrBuilder setCharAt(int paramInt, char paramChar)
  {
    if ((paramInt < 0) || (paramInt >= length()))
      throw new StringIndexOutOfBoundsException(paramInt);
    this.buffer[paramInt] = paramChar;
    return this;
  }

  public StrBuilder setLength(int paramInt)
  {
    if (paramInt < 0)
      throw new StringIndexOutOfBoundsException(paramInt);
    if (paramInt < this.size)
      this.size = paramInt;
    while (true)
    {
      return this;
      if (paramInt > this.size)
      {
        ensureCapacity(paramInt);
        int i = this.size;
        this.size = paramInt;
        for (int j = i; j < paramInt; j++)
          this.buffer[j] = '\000';
      }
    }
  }

  public StrBuilder setNewLineText(String paramString)
  {
    this.newLine = paramString;
    return this;
  }

  public StrBuilder setNullText(String paramString)
  {
    if ((paramString != null) && (paramString.length() == 0))
      paramString = null;
    this.nullText = paramString;
    return this;
  }

  public int size()
  {
    return this.size;
  }

  public boolean startsWith(String paramString)
  {
    boolean bool = false;
    if (paramString == null);
    int i;
    do
      while (true)
      {
        return bool;
        i = paramString.length();
        if (i != 0)
          break;
        bool = true;
      }
    while (i > this.size);
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        bool = true;
        break;
      }
      if (this.buffer[j] != paramString.charAt(j))
        break;
    }
  }

  public CharSequence subSequence(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      throw new StringIndexOutOfBoundsException(paramInt1);
    if (paramInt2 > this.size)
      throw new StringIndexOutOfBoundsException(paramInt2);
    if (paramInt1 > paramInt2)
      throw new StringIndexOutOfBoundsException(paramInt2 - paramInt1);
    return substring(paramInt1, paramInt2);
  }

  public String substring(int paramInt)
  {
    return substring(paramInt, this.size);
  }

  public String substring(int paramInt1, int paramInt2)
  {
    int i = validateRange(paramInt1, paramInt2);
    return new String(this.buffer, paramInt1, i - paramInt1);
  }

  public char[] toCharArray()
  {
    char[] arrayOfChar;
    if (this.size == 0)
      arrayOfChar = ArrayUtils.EMPTY_CHAR_ARRAY;
    while (true)
    {
      return arrayOfChar;
      arrayOfChar = new char[this.size];
      System.arraycopy(this.buffer, 0, arrayOfChar, 0, this.size);
    }
  }

  public char[] toCharArray(int paramInt1, int paramInt2)
  {
    int i = validateRange(paramInt1, paramInt2) - paramInt1;
    char[] arrayOfChar;
    if (i == 0)
      arrayOfChar = ArrayUtils.EMPTY_CHAR_ARRAY;
    while (true)
    {
      return arrayOfChar;
      arrayOfChar = new char[i];
      System.arraycopy(this.buffer, paramInt1, arrayOfChar, 0, i);
    }
  }

  public String toString()
  {
    return new String(this.buffer, 0, this.size);
  }

  public StringBuffer toStringBuffer()
  {
    return new StringBuffer(this.size).append(this.buffer, 0, this.size);
  }

  public StrBuilder trim()
  {
    if (this.size == 0)
      return this;
    int i = this.size;
    char[] arrayOfChar = this.buffer;
    int j = 0;
    label21: if ((j >= i) || (arrayOfChar[j] > ' '));
    while (true)
    {
      if ((j >= i) || (arrayOfChar[(i - 1)] > ' '))
      {
        if (i < this.size)
          delete(i, this.size);
        if (j <= 0)
          break;
        delete(0, j);
        break;
        j++;
        break label21;
      }
      i--;
    }
  }

  protected void validateIndex(int paramInt)
  {
    if ((paramInt < 0) || (paramInt > this.size))
      throw new StringIndexOutOfBoundsException(paramInt);
  }

  protected int validateRange(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0)
      throw new StringIndexOutOfBoundsException(paramInt1);
    if (paramInt2 > this.size)
      paramInt2 = this.size;
    if (paramInt1 > paramInt2)
      throw new StringIndexOutOfBoundsException("end < start");
    return paramInt2;
  }

  class StrBuilderReader extends Reader
  {
    private int mark;
    private int pos;

    StrBuilderReader()
    {
    }

    public void close()
    {
    }

    public void mark(int paramInt)
    {
      this.mark = this.pos;
    }

    public boolean markSupported()
    {
      return true;
    }

    public int read()
    {
      if (!ready());
      StrBuilder localStrBuilder;
      int i;
      for (int j = -1; ; j = localStrBuilder.charAt(i))
      {
        return j;
        localStrBuilder = StrBuilder.this;
        i = this.pos;
        this.pos = (i + 1);
      }
    }

    public int read(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    {
      if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt1 > paramArrayOfChar.length) || (paramInt1 + paramInt2 > paramArrayOfChar.length) || (paramInt1 + paramInt2 < 0))
        throw new IndexOutOfBoundsException();
      int i;
      if (paramInt2 == 0)
        i = 0;
      while (true)
      {
        return i;
        if (this.pos >= StrBuilder.this.size())
        {
          i = -1;
        }
        else
        {
          if (paramInt2 + this.pos > StrBuilder.this.size())
            paramInt2 = StrBuilder.this.size() - this.pos;
          StrBuilder.this.getChars(this.pos, paramInt2 + this.pos, paramArrayOfChar, paramInt1);
          this.pos = (paramInt2 + this.pos);
          i = paramInt2;
        }
      }
    }

    public boolean ready()
    {
      if (this.pos < StrBuilder.this.size());
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public void reset()
    {
      this.pos = this.mark;
    }

    public long skip(long paramLong)
    {
      if (paramLong + this.pos > StrBuilder.this.size())
        paramLong = StrBuilder.this.size() - this.pos;
      if (paramLong < 0L)
        paramLong = 0L;
      while (true)
      {
        return paramLong;
        this.pos = ((int)(paramLong + this.pos));
      }
    }
  }

  class StrBuilderTokenizer extends StrTokenizer
  {
    StrBuilderTokenizer()
    {
    }

    public String getContent()
    {
      String str = super.getContent();
      if (str == null)
        str = StrBuilder.this.toString();
      return str;
    }

    protected List<String> tokenize(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    {
      if (paramArrayOfChar == null);
      for (List localList = super.tokenize(StrBuilder.this.buffer, 0, StrBuilder.this.size()); ; localList = super.tokenize(paramArrayOfChar, paramInt1, paramInt2))
        return localList;
    }
  }

  class StrBuilderWriter extends Writer
  {
    StrBuilderWriter()
    {
    }

    public void close()
    {
    }

    public void flush()
    {
    }

    public void write(int paramInt)
    {
      StrBuilder.this.append((char)paramInt);
    }

    public void write(String paramString)
    {
      StrBuilder.this.append(paramString);
    }

    public void write(String paramString, int paramInt1, int paramInt2)
    {
      StrBuilder.this.append(paramString, paramInt1, paramInt2);
    }

    public void write(char[] paramArrayOfChar)
    {
      StrBuilder.this.append(paramArrayOfChar);
    }

    public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    {
      StrBuilder.this.append(paramArrayOfChar, paramInt1, paramInt2);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.StrBuilder
 * JD-Core Version:    0.6.2
 */