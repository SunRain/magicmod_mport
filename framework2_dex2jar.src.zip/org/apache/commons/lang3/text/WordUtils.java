package org.apache.commons.lang3.text;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;

public class WordUtils
{
  public static String capitalize(String paramString)
  {
    return capitalize(paramString, null);
  }

  public static String capitalize(String paramString, char[] paramArrayOfChar)
  {
    int i;
    if (paramArrayOfChar == null)
    {
      i = -1;
      if ((!StringUtils.isEmpty(paramString)) && (i != 0))
        break label25;
    }
    label25: char[] arrayOfChar;
    int j;
    int k;
    while (true)
    {
      return paramString;
      i = paramArrayOfChar.length;
      break;
      arrayOfChar = paramString.toCharArray();
      j = 1;
      k = 0;
      if (k < arrayOfChar.length)
        break label55;
      paramString = new String(arrayOfChar);
    }
    label55: char c = arrayOfChar[k];
    if (isDelimiter(c, paramArrayOfChar))
      j = 1;
    while (true)
    {
      k++;
      break;
      if (j != 0)
      {
        arrayOfChar[k] = Character.toTitleCase(c);
        j = 0;
      }
    }
  }

  public static String capitalizeFully(String paramString)
  {
    return capitalizeFully(paramString, null);
  }

  public static String capitalizeFully(String paramString, char[] paramArrayOfChar)
  {
    int i;
    if (paramArrayOfChar == null)
    {
      i = -1;
      if ((!StringUtils.isEmpty(paramString)) && (i != 0))
        break label25;
    }
    while (true)
    {
      return paramString;
      i = paramArrayOfChar.length;
      break;
      label25: paramString = capitalize(paramString.toLowerCase(), paramArrayOfChar);
    }
  }

  public static String initials(String paramString)
  {
    return initials(paramString, null);
  }

  public static String initials(String paramString, char[] paramArrayOfChar)
  {
    if (StringUtils.isEmpty(paramString));
    char[] arrayOfChar;
    int j;
    int k;
    int m;
    while (true)
    {
      return paramString;
      if ((paramArrayOfChar != null) && (paramArrayOfChar.length == 0))
      {
        paramString = "";
      }
      else
      {
        int i = paramString.length();
        arrayOfChar = new char[1 + i / 2];
        j = 1;
        k = 0;
        m = 0;
        if (k < i)
          break;
        paramString = new String(arrayOfChar, 0, m);
      }
    }
    char c = paramString.charAt(k);
    int n;
    if (isDelimiter(c, paramArrayOfChar))
    {
      j = 1;
      n = m;
    }
    while (true)
    {
      k++;
      m = n;
      break;
      if (j != 0)
      {
        n = m + 1;
        arrayOfChar[m] = c;
        j = 0;
      }
      else
      {
        n = m;
      }
    }
  }

  private static boolean isDelimiter(char paramChar, char[] paramArrayOfChar)
  {
    boolean bool = false;
    if (paramArrayOfChar == null)
      bool = Character.isWhitespace(paramChar);
    label42: 
    while (true)
    {
      return bool;
      int i = paramArrayOfChar.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label42;
        if (paramChar == paramArrayOfChar[j])
        {
          bool = true;
          break;
        }
      }
    }
  }

  public static String swapCase(String paramString)
  {
    if (StringUtils.isEmpty(paramString));
    char[] arrayOfChar;
    boolean bool;
    int i;
    while (true)
    {
      return paramString;
      arrayOfChar = paramString.toCharArray();
      bool = true;
      i = 0;
      if (i < arrayOfChar.length)
        break;
      paramString = new String(arrayOfChar);
    }
    char c = arrayOfChar[i];
    if (Character.isUpperCase(c))
    {
      arrayOfChar[i] = Character.toLowerCase(c);
      bool = false;
    }
    while (true)
    {
      i++;
      break;
      if (Character.isTitleCase(c))
      {
        arrayOfChar[i] = Character.toLowerCase(c);
        bool = false;
      }
      else if (Character.isLowerCase(c))
      {
        if (bool)
        {
          arrayOfChar[i] = Character.toTitleCase(c);
          bool = false;
        }
        else
        {
          arrayOfChar[i] = Character.toUpperCase(c);
        }
      }
      else
      {
        bool = Character.isWhitespace(c);
      }
    }
  }

  public static String uncapitalize(String paramString)
  {
    return uncapitalize(paramString, null);
  }

  public static String uncapitalize(String paramString, char[] paramArrayOfChar)
  {
    int i;
    if (paramArrayOfChar == null)
    {
      i = -1;
      if ((!StringUtils.isEmpty(paramString)) && (i != 0))
        break label25;
    }
    label25: char[] arrayOfChar;
    int j;
    int k;
    while (true)
    {
      return paramString;
      i = paramArrayOfChar.length;
      break;
      arrayOfChar = paramString.toCharArray();
      j = 1;
      k = 0;
      if (k < arrayOfChar.length)
        break label55;
      paramString = new String(arrayOfChar);
    }
    label55: char c = arrayOfChar[k];
    if (isDelimiter(c, paramArrayOfChar))
      j = 1;
    while (true)
    {
      k++;
      break;
      if (j != 0)
      {
        arrayOfChar[k] = Character.toLowerCase(c);
        j = 0;
      }
    }
  }

  public static String wrap(String paramString, int paramInt)
  {
    return wrap(paramString, paramInt, null, false);
  }

  public static String wrap(String paramString1, int paramInt, String paramString2, boolean paramBoolean)
  {
    String str;
    if (paramString1 == null)
    {
      str = null;
      return str;
    }
    if (paramString2 == null)
      paramString2 = SystemUtils.LINE_SEPARATOR;
    if (paramInt < 1)
      paramInt = 1;
    int i = paramString1.length();
    int j = 0;
    StringBuilder localStringBuilder = new StringBuilder(i + 32);
    while (true)
    {
      if (i - j <= paramInt)
      {
        localStringBuilder.append(paramString1.substring(j));
        str = localStringBuilder.toString();
        break;
      }
      if (paramString1.charAt(j) == ' ')
      {
        j++;
      }
      else
      {
        int k = paramString1.lastIndexOf(' ', paramInt + j);
        if (k >= j)
        {
          localStringBuilder.append(paramString1.substring(j, k));
          localStringBuilder.append(paramString2);
          j = k + 1;
        }
        else if (paramBoolean)
        {
          localStringBuilder.append(paramString1.substring(j, paramInt + j));
          localStringBuilder.append(paramString2);
          j += paramInt;
        }
        else
        {
          int m = paramString1.indexOf(' ', paramInt + j);
          if (m >= 0)
          {
            localStringBuilder.append(paramString1.substring(j, m));
            localStringBuilder.append(paramString2);
            j = m + 1;
          }
          else
          {
            localStringBuilder.append(paramString1.substring(j));
            j = i;
          }
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.WordUtils
 * JD-Core Version:    0.6.2
 */