package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import org.apache.commons.lang3.ArrayUtils;

public class AggregateTranslator extends CharSequenceTranslator
{
  private final CharSequenceTranslator[] translators;

  public AggregateTranslator(CharSequenceTranslator[] paramArrayOfCharSequenceTranslator)
  {
    this.translators = ((CharSequenceTranslator[])ArrayUtils.clone(paramArrayOfCharSequenceTranslator));
  }

  public int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException
  {
    CharSequenceTranslator[] arrayOfCharSequenceTranslator = this.translators;
    int i = arrayOfCharSequenceTranslator.length;
    for (int j = 0; ; j++)
    {
      int k;
      if (j >= i)
        k = 0;
      do
      {
        return k;
        k = arrayOfCharSequenceTranslator[j].translate(paramCharSequence, paramInt, paramWriter);
      }
      while (k != 0);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.AggregateTranslator
 * JD-Core Version:    0.6.2
 */