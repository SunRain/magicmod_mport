package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Locale;

public abstract class CharSequenceTranslator
{
  public static String hex(int paramInt)
  {
    return Integer.toHexString(paramInt).toUpperCase(Locale.ENGLISH);
  }

  public abstract int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException;

  public final String translate(CharSequence paramCharSequence)
  {
    Object localObject;
    if (paramCharSequence == null)
      localObject = null;
    while (true)
    {
      return localObject;
      try
      {
        StringWriter localStringWriter = new StringWriter(2 * paramCharSequence.length());
        translate(paramCharSequence, localStringWriter);
        String str = localStringWriter.toString();
        localObject = str;
      }
      catch (IOException localIOException)
      {
        throw new RuntimeException(localIOException);
      }
    }
  }

  public final void translate(CharSequence paramCharSequence, Writer paramWriter)
    throws IOException
  {
    if (paramWriter == null)
      throw new IllegalArgumentException("The Writer must not be null");
    if (paramCharSequence == null)
      return;
    int i = 0;
    int j = paramCharSequence.length();
    while (true)
    {
      int k;
      if (i < j)
      {
        k = translate(paramCharSequence, i, paramWriter);
        if (k == 0)
        {
          char[] arrayOfChar = Character.toChars(Character.codePointAt(paramCharSequence, i));
          paramWriter.write(arrayOfChar);
          i += arrayOfChar.length;
        }
      }
      else
      {
        break;
        for (int m = 0; m < k; m++)
          i += Character.charCount(Character.codePointAt(paramCharSequence, i));
      }
    }
  }

  public final CharSequenceTranslator with(CharSequenceTranslator[] paramArrayOfCharSequenceTranslator)
  {
    CharSequenceTranslator[] arrayOfCharSequenceTranslator = new CharSequenceTranslator[1 + paramArrayOfCharSequenceTranslator.length];
    arrayOfCharSequenceTranslator[0] = this;
    System.arraycopy(paramArrayOfCharSequenceTranslator, 0, arrayOfCharSequenceTranslator, 1, paramArrayOfCharSequenceTranslator.length);
    return new AggregateTranslator(arrayOfCharSequenceTranslator);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.CharSequenceTranslator
 * JD-Core Version:    0.6.2
 */