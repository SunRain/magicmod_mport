package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.EnumSet;

public class NumericEntityUnescaper extends CharSequenceTranslator
{
  private final EnumSet<OPTION> options;

  public NumericEntityUnescaper(OPTION[] paramArrayOfOPTION)
  {
    if (paramArrayOfOPTION.length > 0);
    OPTION[] arrayOfOPTION;
    for (this.options = EnumSet.copyOf(Arrays.asList(paramArrayOfOPTION)); ; this.options = EnumSet.copyOf(Arrays.asList(arrayOfOPTION)))
    {
      return;
      arrayOfOPTION = new OPTION[1];
      arrayOfOPTION[0] = OPTION.semiColonRequired;
    }
  }

  public boolean isSet(OPTION paramOPTION)
  {
    if (this.options == null);
    for (boolean bool = false; ; bool = this.options.contains(paramOPTION))
      return bool;
  }

  public int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException
  {
    int i = paramCharSequence.length();
    int k;
    int m;
    int j;
    if ((paramCharSequence.charAt(paramInt) == '&') && (paramInt < i - 2) && (paramCharSequence.charAt(paramInt + 1) == '#'))
    {
      k = paramInt + 2;
      m = 0;
      int n = paramCharSequence.charAt(k);
      if ((n == 120) || (n == 88))
      {
        k++;
        m = 1;
        if (k == i)
          j = 0;
      }
    }
    while (true)
    {
      return j;
      int i1 = k;
      label97: int i2;
      if ((i1 >= i) || (((paramCharSequence.charAt(i1) < '0') || (paramCharSequence.charAt(i1) > '9')) && ((paramCharSequence.charAt(i1) < 'a') || (paramCharSequence.charAt(i1) > 'f')) && ((paramCharSequence.charAt(i1) < 'A') || (paramCharSequence.charAt(i1) > 'F'))))
      {
        if ((i1 == i) || (paramCharSequence.charAt(i1) != ';'))
          break label232;
        i2 = 1;
      }
      while (true)
        if (i2 == 0)
        {
          if (isSet(OPTION.semiColonRequired))
          {
            j = 0;
            break;
            i1++;
            break label97;
            label232: i2 = 0;
            continue;
          }
          if (isSet(OPTION.errorIfNoSemiColon))
            throw new IllegalArgumentException("Semi-colon required at end of numeric entity");
        }
      if (m != 0);
      while (true)
      {
        int i4;
        try
        {
          int i9 = Integer.parseInt(paramCharSequence.subSequence(k, i1).toString(), 16);
          i4 = i9;
          if (i4 <= 65535)
            break label398;
          char[] arrayOfChar = Character.toChars(i4);
          paramWriter.write(arrayOfChar[0]);
          paramWriter.write(arrayOfChar[1]);
          int i5 = i1 + 2 - k;
          if (m == 0)
            break label407;
          i6 = 1;
          int i7 = i5 + i6;
          if (i2 == 0)
            break label413;
          i8 = 1;
          j = i8 + i7;
          break;
          int i3 = Integer.parseInt(paramCharSequence.subSequence(k, i1).toString(), 10);
          i4 = i3;
          continue;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          j = 0;
        }
        break;
        label398: paramWriter.write(i4);
        continue;
        label407: int i6 = 0;
        continue;
        label413: int i8 = 0;
      }
      j = 0;
    }
  }

  public static enum OPTION
  {
    static
    {
      semiColonOptional = new OPTION("semiColonOptional", 1);
      errorIfNoSemiColon = new OPTION("errorIfNoSemiColon", 2);
      OPTION[] arrayOfOPTION = new OPTION[3];
      arrayOfOPTION[0] = semiColonRequired;
      arrayOfOPTION[1] = semiColonOptional;
      arrayOfOPTION[2] = errorIfNoSemiColon;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.NumericEntityUnescaper
 * JD-Core Version:    0.6.2
 */