package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;

public class OctalUnescaper extends CharSequenceTranslator
{
  private static int OCTAL_MAX = 377;

  public int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException
  {
    int j;
    int k;
    if ((paramCharSequence.charAt(paramInt) == '\\') && (paramInt < -1 + paramCharSequence.length()) && (Character.isDigit(paramCharSequence.charAt(paramInt + 1))))
    {
      j = paramInt + 1;
      k = paramInt + 2;
      if ((k >= paramCharSequence.length()) || (!Character.isDigit(paramCharSequence.charAt(k))))
        label74: paramWriter.write(Integer.parseInt(paramCharSequence.subSequence(j, k).toString(), 8));
    }
    for (int i = k + 1 - j; ; i = 0)
    {
      return i;
      k++;
      if (Integer.parseInt(paramCharSequence.subSequence(j, k).toString(), 10) <= OCTAL_MAX)
        break;
      k--;
      break label74;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.OctalUnescaper
 * JD-Core Version:    0.6.2
 */