package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;

public class LookupTranslator extends CharSequenceTranslator
{
  private final int longest;
  private final HashMap<CharSequence, CharSequence> lookupMap = new HashMap();
  private final int shortest;

  public LookupTranslator(CharSequence[][] paramArrayOfCharSequence)
  {
    int i = 2147483647;
    int j = 0;
    int k;
    if (paramArrayOfCharSequence != null)
      k = paramArrayOfCharSequence.length;
    for (int m = 0; ; m++)
    {
      if (m >= k)
      {
        this.shortest = i;
        this.longest = j;
        return;
      }
      CharSequence[] arrayOfCharSequence = paramArrayOfCharSequence[m];
      this.lookupMap.put(arrayOfCharSequence[0], arrayOfCharSequence[1]);
      int n = arrayOfCharSequence[0].length();
      if (n < i)
        i = n;
      if (n > j)
        j = n;
    }
  }

  public int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException
  {
    int i = this.longest;
    if (paramInt + this.longest > paramCharSequence.length())
      i = paramCharSequence.length() - paramInt;
    for (int j = i; ; j--)
    {
      if (j < this.shortest)
        j = 0;
      while (true)
      {
        return j;
        CharSequence localCharSequence1 = paramCharSequence.subSequence(paramInt, paramInt + j);
        CharSequence localCharSequence2 = (CharSequence)this.lookupMap.get(localCharSequence1);
        if (localCharSequence2 == null)
          break;
        paramWriter.write(localCharSequence2.toString());
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.LookupTranslator
 * JD-Core Version:    0.6.2
 */