package org.apache.commons.lang3.text.translate;

import java.io.IOException;
import java.io.Writer;

public class UnicodeUnescaper extends CharSequenceTranslator
{
  public int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter)
    throws IOException
  {
    int j;
    CharSequence localCharSequence;
    if ((paramCharSequence.charAt(paramInt) == '\\') && (paramInt + 1 < paramCharSequence.length()) && (paramCharSequence.charAt(paramInt + 1) == 'u'))
    {
      j = 2;
      if ((paramInt + j >= paramCharSequence.length()) || (paramCharSequence.charAt(paramInt + j) != 'u'))
      {
        if ((paramInt + j < paramCharSequence.length()) && (paramCharSequence.charAt(paramInt + j) == '+'))
          j++;
        if (4 + (paramInt + j) > paramCharSequence.length())
          break label194;
        localCharSequence = paramCharSequence.subSequence(paramInt + j, 4 + (paramInt + j));
      }
    }
    while (true)
    {
      try
      {
        paramWriter.write((char)Integer.parseInt(localCharSequence.toString(), 16));
        i = j + 4;
        return i;
        j++;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        throw new IllegalArgumentException("Unable to parse unicode value: " + localCharSequence, localNumberFormatException);
      }
      label194: throw new IllegalArgumentException("Less than 4 hex digits in unicode value: '" + paramCharSequence.subSequence(paramInt, paramCharSequence.length()) + "' due to end of CharSequence");
      int i = 0;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.translate.UnicodeUnescaper
 * JD-Core Version:    0.6.2
 */