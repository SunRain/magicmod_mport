package org.apache.commons.lang3.text;

import java.text.Format;
import java.text.MessageFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.Validate;

public class ExtendedMessageFormat extends MessageFormat
{
  private static final String DUMMY_PATTERN = "";
  private static final char END_FE = '}';
  private static final String ESCAPED_QUOTE = "''";
  private static final int HASH_SEED = 31;
  private static final char QUOTE = '\'';
  private static final char START_FE = '{';
  private static final char START_FMT = ',';
  private static final long serialVersionUID = -2362048321261811743L;
  private final Map<String, ? extends FormatFactory> registry;
  private String toPattern;

  public ExtendedMessageFormat(String paramString)
  {
    this(paramString, Locale.getDefault());
  }

  public ExtendedMessageFormat(String paramString, Locale paramLocale)
  {
    this(paramString, paramLocale, null);
  }

  public ExtendedMessageFormat(String paramString, Locale paramLocale, Map<String, ? extends FormatFactory> paramMap)
  {
    super("");
    setLocale(paramLocale);
    this.registry = paramMap;
    applyPattern(paramString);
  }

  public ExtendedMessageFormat(String paramString, Map<String, ? extends FormatFactory> paramMap)
  {
    this(paramString, Locale.getDefault(), paramMap);
  }

  private StringBuilder appendQuotedString(String paramString, ParsePosition paramParsePosition, StringBuilder paramStringBuilder, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = null;
    int i = paramParsePosition.getIndex();
    char[] arrayOfChar = paramString.toCharArray();
    if ((paramBoolean) && (arrayOfChar[i] == '\''))
    {
      next(paramParsePosition);
      if (paramStringBuilder != null);
    }
    while (true)
    {
      return localStringBuilder;
      localStringBuilder = paramStringBuilder.append('\'');
      continue;
      int j = i;
      int k = paramParsePosition.getIndex();
      if (k >= paramString.length())
        throw new IllegalArgumentException("Unterminated quoted string at position " + i);
      if ((paramBoolean) && (paramString.substring(k).startsWith("''")))
      {
        paramStringBuilder.append(arrayOfChar, j, paramParsePosition.getIndex() - j).append('\'');
        paramParsePosition.setIndex(k + "''".length());
        j = paramParsePosition.getIndex();
      }
      while (true)
      {
        k++;
        break;
        switch (arrayOfChar[paramParsePosition.getIndex()])
        {
        default:
          next(paramParsePosition);
        case '\'':
        }
      }
      next(paramParsePosition);
      if (paramStringBuilder != null)
        localStringBuilder = paramStringBuilder.append(arrayOfChar, j, paramParsePosition.getIndex() - j);
    }
  }

  private boolean containsElements(Collection<?> paramCollection)
  {
    boolean bool = false;
    if ((paramCollection == null) || (paramCollection.isEmpty()))
      break label24;
    while (true)
    {
      return bool;
      Iterator localIterator = paramCollection.iterator();
      label24: if (localIterator.hasNext())
      {
        if (localIterator.next() == null)
          break;
        bool = true;
      }
    }
  }

  private Format getFormat(String paramString)
  {
    String str1;
    String str2;
    FormatFactory localFormatFactory;
    if (this.registry != null)
    {
      str1 = paramString;
      str2 = null;
      int i = paramString.indexOf(',');
      if (i > 0)
      {
        str1 = paramString.substring(0, i).trim();
        str2 = paramString.substring(i + 1).trim();
      }
      localFormatFactory = (FormatFactory)this.registry.get(str1);
      if (localFormatFactory == null);
    }
    for (Format localFormat = localFormatFactory.getFormat(str1, str2, getLocale()); ; localFormat = null)
      return localFormat;
  }

  private void getQuotedString(String paramString, ParsePosition paramParsePosition, boolean paramBoolean)
  {
    appendQuotedString(paramString, paramParsePosition, null, paramBoolean);
  }

  private String insertFormats(String paramString, ArrayList<String> paramArrayList)
  {
    if (!containsElements(paramArrayList));
    StringBuilder localStringBuilder;
    ParsePosition localParsePosition;
    int i;
    int j;
    while (true)
    {
      return paramString;
      localStringBuilder = new StringBuilder(2 * paramString.length());
      localParsePosition = new ParsePosition(0);
      i = -1;
      j = 0;
      if (localParsePosition.getIndex() < paramString.length())
        break;
      paramString = localStringBuilder.toString();
    }
    char c = paramString.charAt(localParsePosition.getIndex());
    switch (c)
    {
    default:
    case '\'':
    case '{':
    case '}':
    }
    while (true)
    {
      localStringBuilder.append(c);
      next(localParsePosition);
      break;
      appendQuotedString(paramString, localParsePosition, localStringBuilder, false);
      break;
      j++;
      if (j != 1)
        break;
      i++;
      localStringBuilder.append('{').append(readArgumentIndex(paramString, next(localParsePosition)));
      String str = (String)paramArrayList.get(i);
      if (str == null)
        break;
      localStringBuilder.append(',').append(str);
      break;
      j--;
    }
  }

  private ParsePosition next(ParsePosition paramParsePosition)
  {
    paramParsePosition.setIndex(1 + paramParsePosition.getIndex());
    return paramParsePosition;
  }

  private String parseFormatDescription(String paramString, ParsePosition paramParsePosition)
  {
    int i = paramParsePosition.getIndex();
    seekNonWs(paramString, paramParsePosition);
    int j = paramParsePosition.getIndex();
    int k = 1;
    if (paramParsePosition.getIndex() >= paramString.length())
      throw new IllegalArgumentException("Unterminated format element at position " + i);
    switch (paramString.charAt(paramParsePosition.getIndex()))
    {
    default:
    case '{':
    case '}':
    case '\'':
    }
    while (true)
    {
      next(paramParsePosition);
      break;
      k++;
      continue;
      k--;
      if (k == 0)
      {
        return paramString.substring(j, paramParsePosition.getIndex());
        getQuotedString(paramString, paramParsePosition, false);
      }
    }
  }

  private int readArgumentIndex(String paramString, ParsePosition paramParsePosition)
  {
    int i = paramParsePosition.getIndex();
    seekNonWs(paramString, paramParsePosition);
    StringBuffer localStringBuffer = new StringBuffer();
    int j = 0;
    char c;
    while (true)
    {
      if ((j != 0) || (paramParsePosition.getIndex() >= paramString.length()))
      {
        if (j == 0)
          break label210;
        throw new IllegalArgumentException("Invalid format argument index at position " + i + ": " + paramString.substring(i, paramParsePosition.getIndex()));
      }
      c = paramString.charAt(paramParsePosition.getIndex());
      if (!Character.isWhitespace(c))
        break;
      seekNonWs(paramString, paramParsePosition);
      c = paramString.charAt(paramParsePosition.getIndex());
      if ((c == ',') || (c == '}'))
        break;
      j = 1;
      next(paramParsePosition);
    }
    if (((c == ',') || (c == '}')) && (localStringBuffer.length() > 0))
      try
      {
        int k = Integer.parseInt(localStringBuffer.toString());
        return k;
      }
      catch (NumberFormatException localNumberFormatException)
      {
      }
    if (Character.isDigit(c));
    for (j = 0; ; j = 1)
    {
      localStringBuffer.append(c);
      break;
    }
    label210: throw new IllegalArgumentException("Unterminated format element at position " + i);
  }

  private void seekNonWs(String paramString, ParsePosition paramParsePosition)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i;
    do
    {
      i = StrMatcher.splitMatcher().isMatch(arrayOfChar, paramParsePosition.getIndex());
      paramParsePosition.setIndex(i + paramParsePosition.getIndex());
    }
    while ((i > 0) && (paramParsePosition.getIndex() < paramString.length()));
  }

  public final void applyPattern(String paramString)
  {
    if (this.registry == null)
    {
      super.applyPattern(paramString);
      this.toPattern = super.toPattern();
    }
    ArrayList localArrayList1;
    ArrayList localArrayList2;
    StringBuilder localStringBuilder;
    ParsePosition localParsePosition;
    char[] arrayOfChar;
    int i;
    do
    {
      return;
      localArrayList1 = new ArrayList();
      localArrayList2 = new ArrayList();
      localStringBuilder = new StringBuilder(paramString.length());
      localParsePosition = new ParsePosition(0);
      arrayOfChar = paramString.toCharArray();
      i = 0;
      if (localParsePosition.getIndex() < paramString.length())
        break;
      super.applyPattern(localStringBuilder.toString());
      this.toPattern = insertFormats(super.toPattern(), localArrayList2);
    }
    while (!containsElements(localArrayList1));
    Format[] arrayOfFormat = getFormats();
    int m = 0;
    Iterator localIterator = localArrayList1.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        super.setFormats(arrayOfFormat);
        break;
        switch (arrayOfChar[localParsePosition.getIndex()])
        {
        default:
          localStringBuilder.append(arrayOfChar[localParsePosition.getIndex()]);
          next(localParsePosition);
          break;
        case '\'':
          appendQuotedString(paramString, localParsePosition, localStringBuilder, true);
          break;
        case '{':
          i++;
          seekNonWs(paramString, localParsePosition);
          int j = localParsePosition.getIndex();
          int k = readArgumentIndex(paramString, next(localParsePosition));
          localStringBuilder.append('{').append(k);
          seekNonWs(paramString, localParsePosition);
          Format localFormat1 = null;
          String str = null;
          if (arrayOfChar[localParsePosition.getIndex()] == ',')
          {
            str = parseFormatDescription(paramString, next(localParsePosition));
            localFormat1 = getFormat(str);
            if (localFormat1 == null)
              localStringBuilder.append(',').append(str);
          }
          localArrayList1.add(localFormat1);
          if (localFormat1 == null)
            str = null;
          localArrayList2.add(str);
          boolean bool1;
          if (localArrayList1.size() == i)
          {
            bool1 = true;
            label360: Validate.isTrue(bool1);
            if (localArrayList2.size() != i)
              break label427;
          }
          label427: for (boolean bool2 = true; ; bool2 = false)
          {
            Validate.isTrue(bool2);
            if (arrayOfChar[localParsePosition.getIndex()] == '}')
              break;
            throw new IllegalArgumentException("Unreadable format element at position " + j);
            bool1 = false;
            break label360;
          }
        }
      }
      Format localFormat2 = (Format)localIterator.next();
      if (localFormat2 != null)
        arrayOfFormat[m] = localFormat2;
      m++;
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this);
    while (true)
    {
      return bool;
      if (paramObject == null)
      {
        bool = false;
      }
      else if (!super.equals(paramObject))
      {
        bool = false;
      }
      else if (ObjectUtils.notEqual(getClass(), paramObject.getClass()))
      {
        bool = false;
      }
      else
      {
        ExtendedMessageFormat localExtendedMessageFormat = (ExtendedMessageFormat)paramObject;
        if (ObjectUtils.notEqual(this.toPattern, localExtendedMessageFormat.toPattern))
          bool = false;
        else if (ObjectUtils.notEqual(this.registry, localExtendedMessageFormat.registry))
          bool = false;
      }
    }
  }

  public int hashCode()
  {
    return 31 * (31 * super.hashCode() + ObjectUtils.hashCode(this.registry)) + ObjectUtils.hashCode(this.toPattern);
  }

  public void setFormat(int paramInt, Format paramFormat)
  {
    throw new UnsupportedOperationException();
  }

  public void setFormatByArgumentIndex(int paramInt, Format paramFormat)
  {
    throw new UnsupportedOperationException();
  }

  public void setFormats(Format[] paramArrayOfFormat)
  {
    throw new UnsupportedOperationException();
  }

  public void setFormatsByArgumentIndex(Format[] paramArrayOfFormat)
  {
    throw new UnsupportedOperationException();
  }

  public String toPattern()
  {
    return this.toPattern;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.ExtendedMessageFormat
 * JD-Core Version:    0.6.2
 */