package org.apache.commons.lang3.text;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class StrSubstitutor
{
  public static final char DEFAULT_ESCAPE = '$';
  public static final StrMatcher DEFAULT_PREFIX = StrMatcher.stringMatcher("${");
  public static final StrMatcher DEFAULT_SUFFIX = StrMatcher.stringMatcher("}");
  private boolean enableSubstitutionInVariables;
  private char escapeChar;
  private StrMatcher prefixMatcher;
  private StrMatcher suffixMatcher;
  private StrLookup<?> variableResolver;

  public StrSubstitutor()
  {
    this(null, DEFAULT_PREFIX, DEFAULT_SUFFIX, '$');
  }

  public <V> StrSubstitutor(Map<String, V> paramMap)
  {
    this(StrLookup.mapLookup(paramMap), DEFAULT_PREFIX, DEFAULT_SUFFIX, '$');
  }

  public <V> StrSubstitutor(Map<String, V> paramMap, String paramString1, String paramString2)
  {
    this(StrLookup.mapLookup(paramMap), paramString1, paramString2, '$');
  }

  public <V> StrSubstitutor(Map<String, V> paramMap, String paramString1, String paramString2, char paramChar)
  {
    this(StrLookup.mapLookup(paramMap), paramString1, paramString2, paramChar);
  }

  public StrSubstitutor(StrLookup<?> paramStrLookup)
  {
    this(paramStrLookup, DEFAULT_PREFIX, DEFAULT_SUFFIX, '$');
  }

  public StrSubstitutor(StrLookup<?> paramStrLookup, String paramString1, String paramString2, char paramChar)
  {
    setVariableResolver(paramStrLookup);
    setVariablePrefix(paramString1);
    setVariableSuffix(paramString2);
    setEscapeChar(paramChar);
  }

  public StrSubstitutor(StrLookup<?> paramStrLookup, StrMatcher paramStrMatcher1, StrMatcher paramStrMatcher2, char paramChar)
  {
    setVariableResolver(paramStrLookup);
    setVariablePrefixMatcher(paramStrMatcher1);
    setVariableSuffixMatcher(paramStrMatcher2);
    setEscapeChar(paramChar);
  }

  private void checkCyclicSubstitution(String paramString, List<String> paramList)
  {
    if (!paramList.contains(paramString))
      return;
    StrBuilder localStrBuilder = new StrBuilder(256);
    localStrBuilder.append("Infinite loop in property interpolation of ");
    localStrBuilder.append((String)paramList.remove(0));
    localStrBuilder.append(": ");
    localStrBuilder.appendWithSeparators(paramList, "->");
    throw new IllegalStateException(localStrBuilder.toString());
  }

  public static <V> String replace(Object paramObject, Map<String, V> paramMap)
  {
    return new StrSubstitutor(paramMap).replace(paramObject);
  }

  public static <V> String replace(Object paramObject, Map<String, V> paramMap, String paramString1, String paramString2)
  {
    return new StrSubstitutor(paramMap, paramString1, paramString2).replace(paramObject);
  }

  public static String replace(Object paramObject, Properties paramProperties)
  {
    String str2;
    if (paramProperties == null)
    {
      str2 = paramObject.toString();
      return str2;
    }
    HashMap localHashMap = new HashMap();
    Enumeration localEnumeration = paramProperties.propertyNames();
    while (true)
    {
      if (!localEnumeration.hasMoreElements())
      {
        str2 = replace(paramObject, localHashMap);
        break;
      }
      String str1 = (String)localEnumeration.nextElement();
      localHashMap.put(str1, paramProperties.getProperty(str1));
    }
  }

  public static String replaceSystemProperties(Object paramObject)
  {
    return new StrSubstitutor(StrLookup.systemPropertiesLookup()).replace(paramObject);
  }

  private int substitute(StrBuilder paramStrBuilder, int paramInt1, int paramInt2, List<String> paramList)
  {
    StrMatcher localStrMatcher1 = getVariablePrefixMatcher();
    StrMatcher localStrMatcher2 = getVariableSuffixMatcher();
    int i = getEscapeChar();
    int j;
    int k;
    int m;
    char[] arrayOfChar;
    int n;
    int i1;
    label46: int i13;
    if (paramList == null)
    {
      j = 1;
      k = 0;
      m = 0;
      arrayOfChar = paramStrBuilder.buffer;
      n = paramInt1 + paramInt2;
      i1 = paramInt1;
      if (i1 < n)
        break label75;
      if (j == 0)
        break label502;
      if (k == 0)
        break label496;
      i13 = 1;
    }
    while (true)
    {
      return i13;
      j = 0;
      break;
      label75: int i2 = localStrMatcher1.isMatch(arrayOfChar, i1, paramInt1, n);
      if (i2 == 0)
      {
        i1++;
        break label46;
      }
      if ((i1 > paramInt1) && (arrayOfChar[(i1 - 1)] == i))
      {
        paramStrBuilder.deleteCharAt(i1 - 1);
        arrayOfChar = paramStrBuilder.buffer;
        m--;
        k = 1;
        n--;
        break label46;
      }
      int i3 = i1;
      i1 += i2;
      int i4 = 0;
      while (true)
      {
        if (i1 >= n)
          break label494;
        if (isEnableSubstitutionInVariables())
        {
          int i12 = localStrMatcher1.isMatch(arrayOfChar, i1, paramInt1, n);
          if (i12 != 0)
          {
            i4++;
            i1 += i12;
          }
        }
        else
        {
          int i5 = localStrMatcher2.isMatch(arrayOfChar, i1, paramInt1, n);
          if (i5 == 0)
          {
            i1++;
          }
          else
          {
            if (i4 == 0)
            {
              int i6 = i3 + i2;
              int i7 = i1 - i3 - i2;
              String str1 = new String(arrayOfChar, i6, i7);
              if (isEnableSubstitutionInVariables())
              {
                StrBuilder localStrBuilder = new StrBuilder(str1);
                substitute(localStrBuilder, 0, localStrBuilder.length());
                str1 = localStrBuilder.toString();
              }
              i1 += i5;
              int i8 = i1;
              if (paramList == null)
              {
                paramList = new ArrayList();
                String str2 = new String(arrayOfChar, paramInt1, paramInt2);
                paramList.add(str2);
              }
              checkCyclicSubstitution(str1, paramList);
              paramList.add(str1);
              String str3 = resolveVariable(str1, paramStrBuilder, i3, i8);
              if (str3 != null)
              {
                int i10 = str3.length();
                paramStrBuilder.replace(i3, i8, str3);
                k = 1;
                int i11 = i10 + substitute(paramStrBuilder, i3, i10, paramList) - (i8 - i3);
                i1 += i11;
                n += i11;
                m += i11;
                arrayOfChar = paramStrBuilder.buffer;
              }
              int i9 = -1 + paramList.size();
              paramList.remove(i9);
              break;
            }
            i4--;
            i1 += i5;
          }
        }
      }
      label494: break label46;
      label496: i13 = 0;
      continue;
      label502: i13 = m;
    }
  }

  public char getEscapeChar()
  {
    return this.escapeChar;
  }

  public StrMatcher getVariablePrefixMatcher()
  {
    return this.prefixMatcher;
  }

  public StrLookup<?> getVariableResolver()
  {
    return this.variableResolver;
  }

  public StrMatcher getVariableSuffixMatcher()
  {
    return this.suffixMatcher;
  }

  public boolean isEnableSubstitutionInVariables()
  {
    return this.enableSubstitutionInVariables;
  }

  public String replace(Object paramObject)
  {
    if (paramObject == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder().append(paramObject);
      substitute(localStrBuilder, 0, localStrBuilder.length());
    }
  }

  public String replace(String paramString)
  {
    if (paramString == null)
      paramString = null;
    while (true)
    {
      return paramString;
      StrBuilder localStrBuilder = new StrBuilder(paramString);
      if (substitute(localStrBuilder, 0, paramString.length()))
        paramString = localStrBuilder.toString();
    }
  }

  public String replace(String paramString, int paramInt1, int paramInt2)
  {
    String str;
    if (paramString == null)
      str = null;
    while (true)
    {
      return str;
      StrBuilder localStrBuilder = new StrBuilder(paramInt2).append(paramString, paramInt1, paramInt2);
      if (!substitute(localStrBuilder, 0, paramInt2))
        str = paramString.substring(paramInt1, paramInt1 + paramInt2);
      else
        str = localStrBuilder.toString();
    }
  }

  public String replace(StringBuffer paramStringBuffer)
  {
    if (paramStringBuffer == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramStringBuffer.length()).append(paramStringBuffer);
      substitute(localStrBuilder, 0, localStrBuilder.length());
    }
  }

  public String replace(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    if (paramStringBuffer == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramInt2).append(paramStringBuffer, paramInt1, paramInt2);
      substitute(localStrBuilder, 0, paramInt2);
    }
  }

  public String replace(StrBuilder paramStrBuilder)
  {
    if (paramStrBuilder == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramStrBuilder.length()).append(paramStrBuilder);
      substitute(localStrBuilder, 0, localStrBuilder.length());
    }
  }

  public String replace(StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    if (paramStrBuilder == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramInt2).append(paramStrBuilder, paramInt1, paramInt2);
      substitute(localStrBuilder, 0, paramInt2);
    }
  }

  public String replace(char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramArrayOfChar.length).append(paramArrayOfChar);
      substitute(localStrBuilder, 0, paramArrayOfChar.length);
    }
  }

  public String replace(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    if (paramArrayOfChar == null);
    StrBuilder localStrBuilder;
    for (String str = null; ; str = localStrBuilder.toString())
    {
      return str;
      localStrBuilder = new StrBuilder(paramInt2).append(paramArrayOfChar, paramInt1, paramInt2);
      substitute(localStrBuilder, 0, paramInt2);
    }
  }

  public boolean replaceIn(StringBuffer paramStringBuffer)
  {
    boolean bool = false;
    if (paramStringBuffer == null);
    while (true)
    {
      return bool;
      bool = replaceIn(paramStringBuffer, 0, paramStringBuffer.length());
    }
  }

  public boolean replaceIn(StringBuffer paramStringBuffer, int paramInt1, int paramInt2)
  {
    boolean bool = false;
    if (paramStringBuffer == null);
    while (true)
    {
      return bool;
      StrBuilder localStrBuilder = new StrBuilder(paramInt2).append(paramStringBuffer, paramInt1, paramInt2);
      if (substitute(localStrBuilder, 0, paramInt2))
      {
        paramStringBuffer.replace(paramInt1, paramInt1 + paramInt2, localStrBuilder.toString());
        bool = true;
      }
    }
  }

  public boolean replaceIn(StrBuilder paramStrBuilder)
  {
    boolean bool = false;
    if (paramStrBuilder == null);
    while (true)
    {
      return bool;
      bool = substitute(paramStrBuilder, 0, paramStrBuilder.length());
    }
  }

  public boolean replaceIn(StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    if (paramStrBuilder == null);
    for (boolean bool = false; ; bool = substitute(paramStrBuilder, paramInt1, paramInt2))
      return bool;
  }

  protected String resolveVariable(String paramString, StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    StrLookup localStrLookup = getVariableResolver();
    if (localStrLookup == null);
    for (String str = null; ; str = localStrLookup.lookup(paramString))
      return str;
  }

  public void setEnableSubstitutionInVariables(boolean paramBoolean)
  {
    this.enableSubstitutionInVariables = paramBoolean;
  }

  public void setEscapeChar(char paramChar)
  {
    this.escapeChar = paramChar;
  }

  public StrSubstitutor setVariablePrefix(char paramChar)
  {
    return setVariablePrefixMatcher(StrMatcher.charMatcher(paramChar));
  }

  public StrSubstitutor setVariablePrefix(String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("Variable prefix must not be null!");
    return setVariablePrefixMatcher(StrMatcher.stringMatcher(paramString));
  }

  public StrSubstitutor setVariablePrefixMatcher(StrMatcher paramStrMatcher)
  {
    if (paramStrMatcher == null)
      throw new IllegalArgumentException("Variable prefix matcher must not be null!");
    this.prefixMatcher = paramStrMatcher;
    return this;
  }

  public void setVariableResolver(StrLookup<?> paramStrLookup)
  {
    this.variableResolver = paramStrLookup;
  }

  public StrSubstitutor setVariableSuffix(char paramChar)
  {
    return setVariableSuffixMatcher(StrMatcher.charMatcher(paramChar));
  }

  public StrSubstitutor setVariableSuffix(String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("Variable suffix must not be null!");
    return setVariableSuffixMatcher(StrMatcher.stringMatcher(paramString));
  }

  public StrSubstitutor setVariableSuffixMatcher(StrMatcher paramStrMatcher)
  {
    if (paramStrMatcher == null)
      throw new IllegalArgumentException("Variable suffix matcher must not be null!");
    this.suffixMatcher = paramStrMatcher;
    return this;
  }

  protected boolean substitute(StrBuilder paramStrBuilder, int paramInt1, int paramInt2)
  {
    if (substitute(paramStrBuilder, paramInt1, paramInt2, null) > 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.StrSubstitutor
 * JD-Core Version:    0.6.2
 */