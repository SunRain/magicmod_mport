package org.apache.commons.lang3.text;

import java.util.Map;

public abstract class StrLookup<V>
{
  private static final StrLookup<String> NONE_LOOKUP = new MapStrLookup(null);
  private static final StrLookup<String> SYSTEM_PROPERTIES_LOOKUP;

  static
  {
    try
    {
      localObject = new MapStrLookup(System.getProperties());
      SYSTEM_PROPERTIES_LOOKUP = (StrLookup)localObject;
      return;
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        Object localObject = NONE_LOOKUP;
    }
  }

  public static <V> StrLookup<V> mapLookup(Map<String, V> paramMap)
  {
    return new MapStrLookup(paramMap);
  }

  public static StrLookup<?> noneLookup()
  {
    return NONE_LOOKUP;
  }

  public static StrLookup<String> systemPropertiesLookup()
  {
    return SYSTEM_PROPERTIES_LOOKUP;
  }

  public abstract String lookup(String paramString);

  static class MapStrLookup<V> extends StrLookup<V>
  {
    private final Map<String, V> map;

    MapStrLookup(Map<String, V> paramMap)
    {
      this.map = paramMap;
    }

    public String lookup(String paramString)
    {
      String str = null;
      if (this.map == null);
      while (true)
      {
        return str;
        Object localObject = this.map.get(paramString);
        if (localObject != null)
          str = localObject.toString();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.text.StrLookup
 * JD-Core Version:    0.6.2
 */