package org.apache.commons.lang3;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;

public class Validate
{
  private static final String DEFAULT_EXCLUSIVE_BETWEEN_EX_MESSAGE = "The value %s is not in the specified exclusive range of %s to %s";
  private static final String DEFAULT_INCLUSIVE_BETWEEN_EX_MESSAGE = "The value %s is not in the specified inclusive range of %s to %s";
  private static final String DEFAULT_IS_ASSIGNABLE_EX_MESSAGE = "Cannot assign a %s to a %s";
  private static final String DEFAULT_IS_INSTANCE_OF_EX_MESSAGE = "Expected type: %s, actual: %s";
  private static final String DEFAULT_IS_NULL_EX_MESSAGE = "The validated object is null";
  private static final String DEFAULT_IS_TRUE_EX_MESSAGE = "The validated expression is false";
  private static final String DEFAULT_MATCHES_PATTERN_EX = "The string %s does not match the pattern %s";
  private static final String DEFAULT_NOT_BLANK_EX_MESSAGE = "The validated character sequence is blank";
  private static final String DEFAULT_NOT_EMPTY_ARRAY_EX_MESSAGE = "The validated array is empty";
  private static final String DEFAULT_NOT_EMPTY_CHAR_SEQUENCE_EX_MESSAGE = "The validated character sequence is empty";
  private static final String DEFAULT_NOT_EMPTY_COLLECTION_EX_MESSAGE = "The validated collection is empty";
  private static final String DEFAULT_NOT_EMPTY_MAP_EX_MESSAGE = "The validated map is empty";
  private static final String DEFAULT_NO_NULL_ELEMENTS_ARRAY_EX_MESSAGE = "The validated array contains null element at index: %d";
  private static final String DEFAULT_NO_NULL_ELEMENTS_COLLECTION_EX_MESSAGE = "The validated collection contains null element at index: %d";
  private static final String DEFAULT_VALID_INDEX_ARRAY_EX_MESSAGE = "The validated array index is invalid: %d";
  private static final String DEFAULT_VALID_INDEX_CHAR_SEQUENCE_EX_MESSAGE = "The validated character sequence index is invalid: %d";
  private static final String DEFAULT_VALID_INDEX_COLLECTION_EX_MESSAGE = "The validated collection index is invalid: %d";
  private static final String DEFAULT_VALID_STATE_EX_MESSAGE = "The validated state is false";

  public static <T> void exclusiveBetween(T paramT1, T paramT2, Comparable<T> paramComparable)
  {
    if ((paramComparable.compareTo(paramT1) <= 0) || (paramComparable.compareTo(paramT2) >= 0))
      throw new IllegalArgumentException(String.format("The value %s is not in the specified exclusive range of %s to %s", new Object[] { paramComparable, paramT1, paramT2 }));
  }

  public static <T> void exclusiveBetween(T paramT1, T paramT2, Comparable<T> paramComparable, String paramString, Object[] paramArrayOfObject)
  {
    if ((paramComparable.compareTo(paramT1) <= 0) || (paramComparable.compareTo(paramT2) >= 0))
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
  }

  public static <T> void inclusiveBetween(T paramT1, T paramT2, Comparable<T> paramComparable)
  {
    if ((paramComparable.compareTo(paramT1) < 0) || (paramComparable.compareTo(paramT2) > 0))
      throw new IllegalArgumentException(String.format("The value %s is not in the specified inclusive range of %s to %s", new Object[] { paramComparable, paramT1, paramT2 }));
  }

  public static <T> void inclusiveBetween(T paramT1, T paramT2, Comparable<T> paramComparable, String paramString, Object[] paramArrayOfObject)
  {
    if ((paramComparable.compareTo(paramT1) < 0) || (paramComparable.compareTo(paramT2) > 0))
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
  }

  public static void isAssignableFrom(Class<?> paramClass1, Class<?> paramClass2)
  {
    if (!paramClass1.isAssignableFrom(paramClass2))
    {
      Object[] arrayOfObject = new Object[2];
      if (paramClass2 == null);
      for (String str = "null"; ; str = paramClass2.getName())
      {
        arrayOfObject[0] = str;
        arrayOfObject[1] = paramClass1.getName();
        throw new IllegalArgumentException(String.format("Cannot assign a %s to a %s", arrayOfObject));
      }
    }
  }

  public static void isAssignableFrom(Class<?> paramClass1, Class<?> paramClass2, String paramString, Object[] paramArrayOfObject)
  {
    if (!paramClass1.isAssignableFrom(paramClass2))
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
  }

  public static void isInstanceOf(Class<?> paramClass, Object paramObject)
  {
    if (!paramClass.isInstance(paramObject))
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramClass.getName();
      if (paramObject == null);
      for (String str = "null"; ; str = paramObject.getClass().getName())
      {
        arrayOfObject[1] = str;
        throw new IllegalArgumentException(String.format("Expected type: %s, actual: %s", arrayOfObject));
      }
    }
  }

  public static void isInstanceOf(Class<?> paramClass, Object paramObject, String paramString, Object[] paramArrayOfObject)
  {
    if (!paramClass.isInstance(paramObject))
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
  }

  public static void isTrue(boolean paramBoolean)
  {
    if (!paramBoolean)
      throw new IllegalArgumentException("The validated expression is false");
  }

  public static void isTrue(boolean paramBoolean, String paramString, double paramDouble)
  {
    if (!paramBoolean)
    {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Double.valueOf(paramDouble);
      throw new IllegalArgumentException(String.format(paramString, arrayOfObject));
    }
  }

  public static void isTrue(boolean paramBoolean, String paramString, long paramLong)
  {
    if (!paramBoolean)
    {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Long.valueOf(paramLong);
      throw new IllegalArgumentException(String.format(paramString, arrayOfObject));
    }
  }

  public static void isTrue(boolean paramBoolean, String paramString, Object[] paramArrayOfObject)
  {
    if (!paramBoolean)
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
  }

  public static void matchesPattern(CharSequence paramCharSequence, String paramString)
  {
    if (!Pattern.matches(paramString, paramCharSequence))
      throw new IllegalArgumentException(String.format("The string %s does not match the pattern %s", new Object[] { paramCharSequence, paramString }));
  }

  public static void matchesPattern(CharSequence paramCharSequence, String paramString1, String paramString2, Object[] paramArrayOfObject)
  {
    if (!Pattern.matches(paramString1, paramCharSequence))
      throw new IllegalArgumentException(String.format(paramString2, paramArrayOfObject));
  }

  public static <T extends Iterable<?>> T noNullElements(T paramT)
  {
    return noNullElements(paramT, "The validated collection contains null element at index: %d", new Object[0]);
  }

  public static <T extends Iterable<?>> T noNullElements(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    notNull(paramT);
    int i = 0;
    Iterator localIterator = paramT.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return paramT;
      if (localIterator.next() == null)
      {
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(i);
        throw new IllegalArgumentException(String.format(paramString, ArrayUtils.addAll(paramArrayOfObject, arrayOfObject)));
      }
      i++;
    }
  }

  public static <T> T[] noNullElements(T[] paramArrayOfT)
  {
    return noNullElements(paramArrayOfT, "The validated array contains null element at index: %d", new Object[0]);
  }

  public static <T> T[] noNullElements(T[] paramArrayOfT, String paramString, Object[] paramArrayOfObject)
  {
    notNull(paramArrayOfT);
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfT.length)
        return paramArrayOfT;
      if (paramArrayOfT[i] == null)
        throw new IllegalArgumentException(String.format(paramString, ArrayUtils.add(paramArrayOfObject, Integer.valueOf(i))));
    }
  }

  public static <T extends CharSequence> T notBlank(T paramT)
  {
    return notBlank(paramT, "The validated character sequence is blank", new Object[0]);
  }

  public static <T extends CharSequence> T notBlank(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    if (StringUtils.isBlank(paramT))
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T extends CharSequence> T notEmpty(T paramT)
  {
    return notEmpty(paramT, "The validated character sequence is empty", new Object[0]);
  }

  public static <T extends CharSequence> T notEmpty(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    if (paramT.length() == 0)
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T extends Collection<?>> T notEmpty(T paramT)
  {
    return notEmpty(paramT, "The validated collection is empty", new Object[0]);
  }

  public static <T extends Collection<?>> T notEmpty(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    if (paramT.isEmpty())
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T extends Map<?, ?>> T notEmpty(T paramT)
  {
    return notEmpty(paramT, "The validated map is empty", new Object[0]);
  }

  public static <T extends Map<?, ?>> T notEmpty(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    if (paramT.isEmpty())
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T> T[] notEmpty(T[] paramArrayOfT)
  {
    return notEmpty(paramArrayOfT, "The validated array is empty", new Object[0]);
  }

  public static <T> T[] notEmpty(T[] paramArrayOfT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramArrayOfT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    if (paramArrayOfT.length == 0)
      throw new IllegalArgumentException(String.format(paramString, paramArrayOfObject));
    return paramArrayOfT;
  }

  public static <T> T notNull(T paramT)
  {
    return notNull(paramT, "The validated object is null", new Object[0]);
  }

  public static <T> T notNull(T paramT, String paramString, Object[] paramArrayOfObject)
  {
    if (paramT == null)
      throw new NullPointerException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T extends CharSequence> T validIndex(T paramT, int paramInt)
  {
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    return validIndex(paramT, paramInt, "The validated character sequence index is invalid: %d", arrayOfObject);
  }

  public static <T extends CharSequence> T validIndex(T paramT, int paramInt, String paramString, Object[] paramArrayOfObject)
  {
    notNull(paramT);
    if ((paramInt < 0) || (paramInt >= paramT.length()))
      throw new IndexOutOfBoundsException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T extends Collection<?>> T validIndex(T paramT, int paramInt)
  {
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    return validIndex(paramT, paramInt, "The validated collection index is invalid: %d", arrayOfObject);
  }

  public static <T extends Collection<?>> T validIndex(T paramT, int paramInt, String paramString, Object[] paramArrayOfObject)
  {
    notNull(paramT);
    if ((paramInt < 0) || (paramInt >= paramT.size()))
      throw new IndexOutOfBoundsException(String.format(paramString, paramArrayOfObject));
    return paramT;
  }

  public static <T> T[] validIndex(T[] paramArrayOfT, int paramInt)
  {
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    return validIndex(paramArrayOfT, paramInt, "The validated array index is invalid: %d", arrayOfObject);
  }

  public static <T> T[] validIndex(T[] paramArrayOfT, int paramInt, String paramString, Object[] paramArrayOfObject)
  {
    notNull(paramArrayOfT);
    if ((paramInt < 0) || (paramInt >= paramArrayOfT.length))
      throw new IndexOutOfBoundsException(String.format(paramString, paramArrayOfObject));
    return paramArrayOfT;
  }

  public static void validState(boolean paramBoolean)
  {
    if (!paramBoolean)
      throw new IllegalStateException("The validated state is false");
  }

  public static void validState(boolean paramBoolean, String paramString, Object[] paramArrayOfObject)
  {
    if (!paramBoolean)
      throw new IllegalStateException(String.format(paramString, paramArrayOfObject));
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.Validate
 * JD-Core Version:    0.6.2
 */