package org.apache.commons.lang3;

public class CharUtils
{
  private static final String[] CHAR_STRING_ARRAY = new String[''];
  public static final char CR = '\r';
  public static final char LF = '\n';

  static
  {
    int j;
    for (int i = 0; ; j = (char)(i + 1))
    {
      if (i >= CHAR_STRING_ARRAY.length)
        return;
      CHAR_STRING_ARRAY[i] = String.valueOf(i);
    }
  }

  public static boolean isAscii(char paramChar)
  {
    if (paramChar < '');
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isAsciiAlpha(char paramChar)
  {
    if (((paramChar < 'A') || (paramChar > 'Z')) && ((paramChar < 'a') || (paramChar > 'z')));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isAsciiAlphaLower(char paramChar)
  {
    if ((paramChar >= 'a') && (paramChar <= 'z'));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isAsciiAlphaUpper(char paramChar)
  {
    if ((paramChar >= 'A') && (paramChar <= 'Z'));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isAsciiAlphanumeric(char paramChar)
  {
    if (((paramChar < 'A') || (paramChar > 'Z')) && ((paramChar < 'a') || (paramChar > 'z')) && ((paramChar < '0') || (paramChar > '9')));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isAsciiControl(char paramChar)
  {
    if ((paramChar >= ' ') && (paramChar != ''));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static boolean isAsciiNumeric(char paramChar)
  {
    if ((paramChar >= '0') && (paramChar <= '9'));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isAsciiPrintable(char paramChar)
  {
    if ((paramChar >= ' ') && (paramChar < ''));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static char toChar(Character paramCharacter)
  {
    if (paramCharacter == null)
      throw new IllegalArgumentException("The Character must not be null");
    return paramCharacter.charValue();
  }

  public static char toChar(Character paramCharacter, char paramChar)
  {
    if (paramCharacter == null);
    while (true)
    {
      return paramChar;
      paramChar = paramCharacter.charValue();
    }
  }

  public static char toChar(String paramString)
  {
    if (StringUtils.isEmpty(paramString))
      throw new IllegalArgumentException("The String must not be empty");
    return paramString.charAt(0);
  }

  public static char toChar(String paramString, char paramChar)
  {
    if (StringUtils.isEmpty(paramString));
    while (true)
    {
      return paramChar;
      paramChar = paramString.charAt(0);
    }
  }

  @Deprecated
  public static Character toCharacterObject(char paramChar)
  {
    return Character.valueOf(paramChar);
  }

  public static Character toCharacterObject(String paramString)
  {
    if (StringUtils.isEmpty(paramString));
    for (Character localCharacter = null; ; localCharacter = Character.valueOf(paramString.charAt(0)))
      return localCharacter;
  }

  public static int toIntValue(char paramChar)
  {
    if (!isAsciiNumeric(paramChar))
      throw new IllegalArgumentException("The character " + paramChar + " is not in the range '0' - '9'");
    return paramChar - '0';
  }

  public static int toIntValue(char paramChar, int paramInt)
  {
    if (!isAsciiNumeric(paramChar));
    while (true)
    {
      return paramInt;
      paramInt = paramChar - '0';
    }
  }

  public static int toIntValue(Character paramCharacter)
  {
    if (paramCharacter == null)
      throw new IllegalArgumentException("The character must not be null");
    return toIntValue(paramCharacter.charValue());
  }

  public static int toIntValue(Character paramCharacter, int paramInt)
  {
    if (paramCharacter == null);
    while (true)
    {
      return paramInt;
      paramInt = toIntValue(paramCharacter.charValue(), paramInt);
    }
  }

  public static String toString(char paramChar)
  {
    if (paramChar < '');
    for (String str = CHAR_STRING_ARRAY[paramChar]; ; str = new String(new char[] { paramChar }))
      return str;
  }

  public static String toString(Character paramCharacter)
  {
    if (paramCharacter == null);
    for (String str = null; ; str = toString(paramCharacter.charValue()))
      return str;
  }

  public static String unicodeEscaped(char paramChar)
  {
    String str;
    if (paramChar < '\020')
      str = "\\u000" + Integer.toHexString(paramChar);
    while (true)
    {
      return str;
      if (paramChar < 'Ā')
        str = "\\u00" + Integer.toHexString(paramChar);
      else if (paramChar < 'က')
        str = "\\u0" + Integer.toHexString(paramChar);
      else
        str = "\\u" + Integer.toHexString(paramChar);
    }
  }

  public static String unicodeEscaped(Character paramCharacter)
  {
    if (paramCharacter == null);
    for (String str = null; ; str = unicodeEscaped(paramCharacter.charValue()))
      return str;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.CharUtils
 * JD-Core Version:    0.6.2
 */