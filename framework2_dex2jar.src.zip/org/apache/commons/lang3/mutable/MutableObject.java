package org.apache.commons.lang3.mutable;

import java.io.Serializable;

public class MutableObject<T>
  implements Mutable<T>, Serializable
{
  private static final long serialVersionUID = 86241875189L;
  private T value;

  public MutableObject()
  {
  }

  public MutableObject(T paramT)
  {
    this.value = paramT;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (paramObject == null);
    while (true)
    {
      return bool;
      if (this == paramObject)
      {
        bool = true;
      }
      else if (getClass() == paramObject.getClass())
      {
        MutableObject localMutableObject = (MutableObject)paramObject;
        bool = this.value.equals(localMutableObject.value);
      }
    }
  }

  public T getValue()
  {
    return this.value;
  }

  public int hashCode()
  {
    if (this.value == null);
    for (int i = 0; ; i = this.value.hashCode())
      return i;
  }

  public void setValue(T paramT)
  {
    this.value = paramT;
  }

  public String toString()
  {
    if (this.value == null);
    for (String str = "null"; ; str = this.value.toString())
      return str;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.MutableObject
 * JD-Core Version:    0.6.2
 */