package org.apache.commons.lang3.mutable;

public class MutableLong extends Number
  implements Comparable<MutableLong>, Mutable<Number>
{
  private static final long serialVersionUID = 62986528375L;
  private long value;

  public MutableLong()
  {
  }

  public MutableLong(long paramLong)
  {
    this.value = paramLong;
  }

  public MutableLong(Number paramNumber)
  {
    this.value = paramNumber.longValue();
  }

  public MutableLong(String paramString)
    throws NumberFormatException
  {
    this.value = Long.parseLong(paramString);
  }

  public void add(long paramLong)
  {
    this.value = (paramLong + this.value);
  }

  public void add(Number paramNumber)
  {
    this.value += paramNumber.longValue();
  }

  public int compareTo(MutableLong paramMutableLong)
  {
    long l = paramMutableLong.value;
    int i;
    if (this.value < l)
      i = -1;
    while (true)
    {
      return i;
      if (this.value == l)
        i = 0;
      else
        i = 1;
    }
  }

  public void decrement()
  {
    this.value -= 1L;
  }

  public double doubleValue()
  {
    return this.value;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (((paramObject instanceof MutableLong)) && (this.value == ((MutableLong)paramObject).longValue()))
      bool = true;
    return bool;
  }

  public float floatValue()
  {
    return (float)this.value;
  }

  public Long getValue()
  {
    return Long.valueOf(this.value);
  }

  public int hashCode()
  {
    return (int)(this.value ^ this.value >>> 32);
  }

  public void increment()
  {
    this.value = (1L + this.value);
  }

  public int intValue()
  {
    return (int)this.value;
  }

  public long longValue()
  {
    return this.value;
  }

  public void setValue(long paramLong)
  {
    this.value = paramLong;
  }

  public void setValue(Number paramNumber)
  {
    this.value = paramNumber.longValue();
  }

  public void subtract(long paramLong)
  {
    this.value -= paramLong;
  }

  public void subtract(Number paramNumber)
  {
    this.value -= paramNumber.longValue();
  }

  public Long toLong()
  {
    return Long.valueOf(longValue());
  }

  public String toString()
  {
    return String.valueOf(this.value);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.MutableLong
 * JD-Core Version:    0.6.2
 */