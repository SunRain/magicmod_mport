package org.apache.commons.lang3.mutable;

import java.io.Serializable;

public class MutableBoolean
  implements Mutable<Boolean>, Serializable, Comparable<MutableBoolean>
{
  private static final long serialVersionUID = -4830728138360036487L;
  private boolean value;

  public MutableBoolean()
  {
  }

  public MutableBoolean(Boolean paramBoolean)
  {
    this.value = paramBoolean.booleanValue();
  }

  public MutableBoolean(boolean paramBoolean)
  {
    this.value = paramBoolean;
  }

  public boolean booleanValue()
  {
    return this.value;
  }

  public int compareTo(MutableBoolean paramMutableBoolean)
  {
    boolean bool = paramMutableBoolean.value;
    int i;
    if (this.value == bool)
      i = 0;
    while (true)
    {
      return i;
      if (this.value)
        i = 1;
      else
        i = -1;
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (((paramObject instanceof MutableBoolean)) && (this.value == ((MutableBoolean)paramObject).booleanValue()))
      bool = true;
    return bool;
  }

  public Boolean getValue()
  {
    return Boolean.valueOf(this.value);
  }

  public int hashCode()
  {
    if (this.value);
    for (int i = Boolean.TRUE.hashCode(); ; i = Boolean.FALSE.hashCode())
      return i;
  }

  public boolean isFalse()
  {
    if (this.value);
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public boolean isTrue()
  {
    return this.value;
  }

  public void setValue(Boolean paramBoolean)
  {
    this.value = paramBoolean.booleanValue();
  }

  public void setValue(boolean paramBoolean)
  {
    this.value = paramBoolean;
  }

  public Boolean toBoolean()
  {
    return Boolean.valueOf(booleanValue());
  }

  public String toString()
  {
    return String.valueOf(this.value);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.MutableBoolean
 * JD-Core Version:    0.6.2
 */