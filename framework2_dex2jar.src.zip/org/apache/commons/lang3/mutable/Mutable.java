package org.apache.commons.lang3.mutable;

public abstract interface Mutable<T>
{
  public abstract T getValue();

  public abstract void setValue(T paramT);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.Mutable
 * JD-Core Version:    0.6.2
 */