package org.apache.commons.lang3.mutable;

public class MutableShort extends Number
  implements Comparable<MutableShort>, Mutable<Number>
{
  private static final long serialVersionUID = -2135791679L;
  private short value;

  public MutableShort()
  {
  }

  public MutableShort(Number paramNumber)
  {
    this.value = paramNumber.shortValue();
  }

  public MutableShort(String paramString)
    throws NumberFormatException
  {
    this.value = Short.parseShort(paramString);
  }

  public MutableShort(short paramShort)
  {
    this.value = paramShort;
  }

  public void add(Number paramNumber)
  {
    this.value = ((short)(this.value + paramNumber.shortValue()));
  }

  public void add(short paramShort)
  {
    this.value = ((short)(paramShort + this.value));
  }

  public int compareTo(MutableShort paramMutableShort)
  {
    int i = paramMutableShort.value;
    int j;
    if (this.value < i)
      j = -1;
    while (true)
    {
      return j;
      if (this.value == i)
        j = 0;
      else
        j = 1;
    }
  }

  public void decrement()
  {
    this.value = ((short)(-1 + this.value));
  }

  public double doubleValue()
  {
    return this.value;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (((paramObject instanceof MutableShort)) && (this.value == ((MutableShort)paramObject).shortValue()))
      bool = true;
    return bool;
  }

  public float floatValue()
  {
    return this.value;
  }

  public Short getValue()
  {
    return Short.valueOf(this.value);
  }

  public int hashCode()
  {
    return this.value;
  }

  public void increment()
  {
    this.value = ((short)(1 + this.value));
  }

  public int intValue()
  {
    return this.value;
  }

  public long longValue()
  {
    return this.value;
  }

  public void setValue(Number paramNumber)
  {
    this.value = paramNumber.shortValue();
  }

  public void setValue(short paramShort)
  {
    this.value = paramShort;
  }

  public short shortValue()
  {
    return this.value;
  }

  public void subtract(Number paramNumber)
  {
    this.value = ((short)(this.value - paramNumber.shortValue()));
  }

  public void subtract(short paramShort)
  {
    this.value = ((short)(this.value - paramShort));
  }

  public Short toShort()
  {
    return Short.valueOf(shortValue());
  }

  public String toString()
  {
    return String.valueOf(this.value);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.MutableShort
 * JD-Core Version:    0.6.2
 */