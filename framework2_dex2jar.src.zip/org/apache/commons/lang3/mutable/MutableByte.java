package org.apache.commons.lang3.mutable;

public class MutableByte extends Number
  implements Comparable<MutableByte>, Mutable<Number>
{
  private static final long serialVersionUID = -1585823265L;
  private byte value;

  public MutableByte()
  {
  }

  public MutableByte(byte paramByte)
  {
    this.value = paramByte;
  }

  public MutableByte(Number paramNumber)
  {
    this.value = paramNumber.byteValue();
  }

  public MutableByte(String paramString)
    throws NumberFormatException
  {
    this.value = Byte.parseByte(paramString);
  }

  public void add(byte paramByte)
  {
    this.value = ((byte)(paramByte + this.value));
  }

  public void add(Number paramNumber)
  {
    this.value = ((byte)(this.value + paramNumber.byteValue()));
  }

  public byte byteValue()
  {
    return this.value;
  }

  public int compareTo(MutableByte paramMutableByte)
  {
    int i = paramMutableByte.value;
    int j;
    if (this.value < i)
      j = -1;
    while (true)
    {
      return j;
      if (this.value == i)
        j = 0;
      else
        j = 1;
    }
  }

  public void decrement()
  {
    this.value = ((byte)(-1 + this.value));
  }

  public double doubleValue()
  {
    return this.value;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = false;
    if (((paramObject instanceof MutableByte)) && (this.value == ((MutableByte)paramObject).byteValue()))
      bool = true;
    return bool;
  }

  public float floatValue()
  {
    return this.value;
  }

  public Byte getValue()
  {
    return Byte.valueOf(this.value);
  }

  public int hashCode()
  {
    return this.value;
  }

  public void increment()
  {
    this.value = ((byte)(1 + this.value));
  }

  public int intValue()
  {
    return this.value;
  }

  public long longValue()
  {
    return this.value;
  }

  public void setValue(byte paramByte)
  {
    this.value = paramByte;
  }

  public void setValue(Number paramNumber)
  {
    this.value = paramNumber.byteValue();
  }

  public void subtract(byte paramByte)
  {
    this.value = ((byte)(this.value - paramByte));
  }

  public void subtract(Number paramNumber)
  {
    this.value = ((byte)(this.value - paramNumber.byteValue()));
  }

  public Byte toByte()
  {
    return Byte.valueOf(byteValue());
  }

  public String toString()
  {
    return String.valueOf(this.value);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.mutable.MutableByte
 * JD-Core Version:    0.6.2
 */