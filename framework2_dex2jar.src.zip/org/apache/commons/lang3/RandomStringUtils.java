package org.apache.commons.lang3;

import java.util.Random;

public class RandomStringUtils
{
  private static final Random RANDOM = new Random();

  public static String random(int paramInt)
  {
    return random(paramInt, false, false);
  }

  public static String random(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2)
  {
    return random(paramInt1, paramInt2, paramInt3, paramBoolean1, paramBoolean2, null, RANDOM);
  }

  public static String random(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, char[] paramArrayOfChar)
  {
    return random(paramInt1, paramInt2, paramInt3, paramBoolean1, paramBoolean2, paramArrayOfChar, RANDOM);
  }

  public static String random(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, char[] paramArrayOfChar, Random paramRandom)
  {
    String str;
    if (paramInt1 == 0)
    {
      str = "";
      return str;
    }
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Requested random string length " + paramInt1 + " is less than 0.");
    if ((paramInt2 == 0) && (paramInt3 == 0))
    {
      paramInt3 = 123;
      paramInt2 = 32;
      if ((!paramBoolean1) && (!paramBoolean2))
      {
        paramInt2 = 0;
        paramInt3 = 2147483647;
      }
    }
    char[] arrayOfChar = new char[paramInt1];
    int i = paramInt3 - paramInt2;
    int j = paramInt1;
    while (true)
    {
      int k = j - 1;
      if (j == 0)
      {
        str = new String(arrayOfChar);
        break;
      }
      int m;
      if (paramArrayOfChar == null)
        m = (char)(paramInt2 + paramRandom.nextInt(i));
      while (true)
        if (((paramBoolean1) && (Character.isLetter(m))) || ((paramBoolean2) && (Character.isDigit(m))) || ((!paramBoolean1) && (!paramBoolean2)))
        {
          int n;
          if ((m >= 56320) && (m <= 57343))
          {
            if (k == 0)
            {
              j = k + 1;
              break;
              n = paramArrayOfChar[(paramInt2 + paramRandom.nextInt(i))];
              continue;
            }
            arrayOfChar[k] = n;
            int i2 = k - 1;
            arrayOfChar[i2] = ((char)(55296 + paramRandom.nextInt(128)));
            j = i2;
            break;
          }
          if ((n >= 55296) && (n <= 56191))
          {
            if (k == 0)
            {
              j = k + 1;
              break;
            }
            arrayOfChar[k] = ((char)(56320 + paramRandom.nextInt(128)));
            int i1 = k - 1;
            arrayOfChar[i1] = n;
            j = i1;
            break;
          }
          if ((n >= 56192) && (n <= 56319))
          {
            j = k + 1;
            break;
          }
          arrayOfChar[k] = n;
          j = k;
          break;
        }
      j = k + 1;
    }
  }

  public static String random(int paramInt, String paramString)
  {
    if (paramString == null);
    for (String str = random(paramInt, 0, 0, false, false, null, RANDOM); ; str = random(paramInt, paramString.toCharArray()))
      return str;
  }

  public static String random(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    return random(paramInt, 0, 0, paramBoolean1, paramBoolean2);
  }

  public static String random(int paramInt, char[] paramArrayOfChar)
  {
    if (paramArrayOfChar == null);
    for (String str = random(paramInt, 0, 0, false, false, null, RANDOM); ; str = random(paramInt, 0, paramArrayOfChar.length, false, false, paramArrayOfChar, RANDOM))
      return str;
  }

  public static String randomAlphabetic(int paramInt)
  {
    return random(paramInt, true, false);
  }

  public static String randomAlphanumeric(int paramInt)
  {
    return random(paramInt, true, true);
  }

  public static String randomAscii(int paramInt)
  {
    return random(paramInt, 32, 127, false, false);
  }

  public static String randomNumeric(int paramInt)
  {
    return random(paramInt, false, true);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.RandomStringUtils
 * JD-Core Version:    0.6.2
 */