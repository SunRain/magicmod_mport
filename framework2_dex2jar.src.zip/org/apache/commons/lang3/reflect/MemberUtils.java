package org.apache.commons.lang3.reflect;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Member;
import java.lang.reflect.Modifier;
import org.apache.commons.lang3.ClassUtils;

public abstract class MemberUtils
{
  private static final int ACCESS_TEST = 7;
  private static final Class<?>[] ORDERED_PRIMITIVE_TYPES = arrayOfClass;

  static
  {
    Class[] arrayOfClass = new Class[7];
    arrayOfClass[0] = Byte.TYPE;
    arrayOfClass[1] = Short.TYPE;
    arrayOfClass[2] = Character.TYPE;
    arrayOfClass[3] = Integer.TYPE;
    arrayOfClass[4] = Long.TYPE;
    arrayOfClass[5] = Float.TYPE;
    arrayOfClass[6] = Double.TYPE;
  }

  public static int compareParameterTypes(Class<?>[] paramArrayOfClass1, Class<?>[] paramArrayOfClass2, Class<?>[] paramArrayOfClass3)
  {
    float f1 = getTotalTransformationCost(paramArrayOfClass3, paramArrayOfClass1);
    float f2 = getTotalTransformationCost(paramArrayOfClass3, paramArrayOfClass2);
    int i;
    if (f1 < f2)
      i = -1;
    while (true)
    {
      return i;
      if (f2 < f1)
        i = 1;
      else
        i = 0;
    }
  }

  private static float getObjectTransformationCost(Class<?> paramClass1, Class<?> paramClass2)
  {
    if (paramClass2.isPrimitive())
    {
      f = getPrimitivePromotionCost(paramClass1, paramClass2);
      return f;
    }
    float f = 0.0F;
    while (true)
    {
      if ((paramClass1 == null) || (paramClass2.equals(paramClass1)));
      while (true)
      {
        if (paramClass1 != null)
          break label62;
        f += 1.5F;
        break;
        if ((!paramClass2.isInterface()) || (!ClassUtils.isAssignable(paramClass1, paramClass2)))
          break label64;
        f += 0.25F;
      }
      label62: break;
      label64: f += 1.0F;
      paramClass1 = paramClass1.getSuperclass();
    }
  }

  private static float getPrimitivePromotionCost(Class<?> paramClass1, Class<?> paramClass2)
  {
    float f = 0.0F;
    Object localObject = paramClass1;
    if (!((Class)localObject).isPrimitive())
    {
      f = 0.0F + 0.1F;
      localObject = ClassUtils.wrapperToPrimitive((Class)localObject);
    }
    for (int i = 0; ; i++)
    {
      if ((localObject == paramClass2) || (i >= ORDERED_PRIMITIVE_TYPES.length))
        return f;
      if (localObject == ORDERED_PRIMITIVE_TYPES[i])
      {
        f += 0.1F;
        if (i < -1 + ORDERED_PRIMITIVE_TYPES.length)
          localObject = ORDERED_PRIMITIVE_TYPES[(i + 1)];
      }
    }
  }

  private static float getTotalTransformationCost(Class<?>[] paramArrayOfClass1, Class<?>[] paramArrayOfClass2)
  {
    float f = 0.0F;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfClass1.length)
        return f;
      f += getObjectTransformationCost(paramArrayOfClass1[i], paramArrayOfClass2[i]);
    }
  }

  static boolean isAccessible(Member paramMember)
  {
    if ((paramMember != null) && (Modifier.isPublic(paramMember.getModifiers())) && (!paramMember.isSynthetic()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  static boolean isPackageAccess(int paramInt)
  {
    if ((paramInt & 0x7) == 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  static void setAccessibleWorkaround(AccessibleObject paramAccessibleObject)
  {
    if ((paramAccessibleObject == null) || (paramAccessibleObject.isAccessible()));
    while (true)
    {
      return;
      Member localMember = (Member)paramAccessibleObject;
      if ((Modifier.isPublic(localMember.getModifiers())) && (isPackageAccess(localMember.getDeclaringClass().getModifiers())))
        try
        {
          paramAccessibleObject.setAccessible(true);
        }
        catch (SecurityException localSecurityException)
        {
        }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.reflect.MemberUtils
 * JD-Core Version:    0.6.2
 */