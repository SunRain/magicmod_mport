package org.apache.commons.lang3.reflect;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ClassUtils;

public class ConstructorUtils
{
  public static <T> Constructor<T> getAccessibleConstructor(Class<T> paramClass, Class<?>[] paramArrayOfClass)
  {
    try
    {
      Constructor localConstructor2 = getAccessibleConstructor(paramClass.getConstructor(paramArrayOfClass));
      localConstructor1 = localConstructor2;
      return localConstructor1;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      while (true)
        Constructor localConstructor1 = null;
    }
  }

  public static <T> Constructor<T> getAccessibleConstructor(Constructor<T> paramConstructor)
  {
    if ((MemberUtils.isAccessible(paramConstructor)) && (Modifier.isPublic(paramConstructor.getDeclaringClass().getModifiers())));
    while (true)
    {
      return paramConstructor;
      paramConstructor = null;
    }
  }

  public static <T> Constructor<T> getMatchingAccessibleConstructor(Class<T> paramClass, Class<?>[] paramArrayOfClass)
  {
    Object localObject2;
    Object localObject1;
    Constructor[] arrayOfConstructor;
    int i;
    int j;
    try
    {
      localObject2 = paramClass.getConstructor(paramArrayOfClass);
      MemberUtils.setAccessibleWorkaround((AccessibleObject)localObject2);
      return localObject2;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      localObject1 = null;
      arrayOfConstructor = paramClass.getConstructors();
      i = arrayOfConstructor.length;
      j = 0;
    }
    while (true)
    {
      if (j >= i)
      {
        localObject2 = localObject1;
        break;
      }
      Constructor localConstructor1 = arrayOfConstructor[j];
      if (ClassUtils.isAssignable(paramArrayOfClass, localConstructor1.getParameterTypes(), true))
      {
        Constructor localConstructor2 = getAccessibleConstructor(localConstructor1);
        if (localConstructor2 != null)
        {
          MemberUtils.setAccessibleWorkaround(localConstructor2);
          if ((localObject1 == null) || (MemberUtils.compareParameterTypes(localConstructor2.getParameterTypes(), localObject1.getParameterTypes(), paramArrayOfClass) < 0))
            localObject1 = localConstructor2;
        }
      }
      j++;
    }
  }

  public static <T> T invokeConstructor(Class<T> paramClass, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    Class[] arrayOfClass = new Class[paramArrayOfObject.length];
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfObject.length)
        return invokeConstructor(paramClass, paramArrayOfObject, arrayOfClass);
      arrayOfClass[i] = paramArrayOfObject[i].getClass();
    }
  }

  public static <T> T invokeConstructor(Class<T> paramClass, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
  {
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    Constructor localConstructor = getMatchingAccessibleConstructor(paramClass, paramArrayOfClass);
    if (localConstructor == null)
      throw new NoSuchMethodException("No such accessible constructor on object: " + paramClass.getName());
    return localConstructor.newInstance(paramArrayOfObject);
  }

  public static <T> T invokeExactConstructor(Class<T> paramClass, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    int i = paramArrayOfObject.length;
    Class[] arrayOfClass = new Class[i];
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return invokeExactConstructor(paramClass, paramArrayOfObject, arrayOfClass);
      arrayOfClass[j] = paramArrayOfObject[j].getClass();
    }
  }

  public static <T> T invokeExactConstructor(Class<T> paramClass, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    Constructor localConstructor = getAccessibleConstructor(paramClass, paramArrayOfClass);
    if (localConstructor == null)
      throw new NoSuchMethodException("No such accessible constructor on object: " + paramClass.getName());
    return localConstructor.newInstance(paramArrayOfObject);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.reflect.ConstructorUtils
 * JD-Core Version:    0.6.2
 */