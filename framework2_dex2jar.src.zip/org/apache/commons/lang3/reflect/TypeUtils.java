package org.apache.commons.lang3.reflect;

import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.GenericDeclaration;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.lang3.ClassUtils;

public class TypeUtils
{
  public static Map<TypeVariable<?>, Type> determineTypeArguments(Class<?> paramClass, ParameterizedType paramParameterizedType)
  {
    Object localObject = null;
    Class localClass = getRawType(paramParameterizedType);
    if (!isAssignable(paramClass, localClass));
    while (true)
    {
      return localObject;
      if (paramClass.equals(localClass))
      {
        localObject = getTypeArguments(paramParameterizedType, localClass, null);
      }
      else
      {
        Type localType = getClosestParentType(paramClass, localClass);
        if ((localType instanceof Class))
        {
          localObject = determineTypeArguments((Class)localType, paramParameterizedType);
        }
        else
        {
          ParameterizedType localParameterizedType = (ParameterizedType)localType;
          localObject = determineTypeArguments(getRawType(localParameterizedType), paramParameterizedType);
          mapTypeVariablesToArguments(paramClass, localParameterizedType, (Map)localObject);
        }
      }
    }
  }

  public static Type getArrayComponentType(Type paramType)
  {
    Object localObject = null;
    if ((paramType instanceof Class))
    {
      Class localClass = (Class)paramType;
      if (localClass.isArray())
        localObject = localClass.getComponentType();
    }
    while (true)
    {
      return localObject;
      if ((paramType instanceof GenericArrayType))
        localObject = ((GenericArrayType)paramType).getGenericComponentType();
    }
  }

  private static Type getClosestParentType(Class<?> paramClass1, Class<?> paramClass2)
  {
    Type[] arrayOfType;
    Object localObject;
    int j;
    if (paramClass2.isInterface())
    {
      arrayOfType = paramClass1.getGenericInterfaces();
      localObject = null;
      int i = arrayOfType.length;
      j = 0;
      if (j >= i)
        if (localObject == null)
          break label128;
    }
    while (true)
    {
      return localObject;
      Type localType = arrayOfType[j];
      if ((localType instanceof ParameterizedType));
      for (Class localClass = getRawType((ParameterizedType)localType); ; localClass = (Class)localType)
      {
        if ((isAssignable(localClass, paramClass2)) && (isAssignable((Type)localObject, localClass)))
          localObject = localType;
        j++;
        break;
        if (!(localType instanceof Class))
          break label103;
      }
      label103: throw new IllegalStateException("Unexpected generic interface type found: " + localType);
      label128: localObject = paramClass1.getGenericSuperclass();
    }
  }

  public static Type[] getImplicitBounds(TypeVariable<?> paramTypeVariable)
  {
    Type[] arrayOfType1 = paramTypeVariable.getBounds();
    Type[] arrayOfType2;
    if (arrayOfType1.length == 0)
    {
      arrayOfType2 = new Type[1];
      arrayOfType2[0] = Object.class;
    }
    while (true)
    {
      return arrayOfType2;
      arrayOfType2 = normalizeUpperBounds(arrayOfType1);
    }
  }

  public static Type[] getImplicitLowerBounds(WildcardType paramWildcardType)
  {
    Type[] arrayOfType = paramWildcardType.getLowerBounds();
    if (arrayOfType.length == 0)
      arrayOfType = new Type[1];
    return arrayOfType;
  }

  public static Type[] getImplicitUpperBounds(WildcardType paramWildcardType)
  {
    Type[] arrayOfType1 = paramWildcardType.getUpperBounds();
    Type[] arrayOfType2;
    if (arrayOfType1.length == 0)
    {
      arrayOfType2 = new Type[1];
      arrayOfType2[0] = Object.class;
    }
    while (true)
    {
      return arrayOfType2;
      arrayOfType2 = normalizeUpperBounds(arrayOfType1);
    }
  }

  private static Class<?> getRawType(ParameterizedType paramParameterizedType)
  {
    Type localType = paramParameterizedType.getRawType();
    if (!(localType instanceof Class))
      throw new IllegalStateException("Wait... What!? Type of rawType: " + localType);
    return (Class)localType;
  }

  public static Class<?> getRawType(Type paramType1, Type paramType2)
  {
    Class localClass;
    if ((paramType1 instanceof Class))
      localClass = (Class)paramType1;
    while (true)
    {
      return localClass;
      if ((paramType1 instanceof ParameterizedType))
      {
        localClass = getRawType((ParameterizedType)paramType1);
      }
      else if ((paramType1 instanceof TypeVariable))
      {
        if (paramType2 == null)
        {
          localClass = null;
        }
        else
        {
          GenericDeclaration localGenericDeclaration = ((TypeVariable)paramType1).getGenericDeclaration();
          if (!(localGenericDeclaration instanceof Class))
          {
            localClass = null;
          }
          else
          {
            Map localMap = getTypeArguments(paramType2, (Class)localGenericDeclaration);
            if (localMap == null)
            {
              localClass = null;
            }
            else
            {
              Type localType = (Type)localMap.get(paramType1);
              if (localType == null)
                localClass = null;
              else
                localClass = getRawType(localType, paramType2);
            }
          }
        }
      }
      else if ((paramType1 instanceof GenericArrayType))
      {
        localClass = Array.newInstance(getRawType(((GenericArrayType)paramType1).getGenericComponentType(), paramType2), 0).getClass();
      }
      else
      {
        if (!(paramType1 instanceof WildcardType))
          break;
        localClass = null;
      }
    }
    throw new IllegalArgumentException("unknown type: " + paramType1);
  }

  private static Map<TypeVariable<?>, Type> getTypeArguments(Class<?> paramClass1, Class<?> paramClass2, Map<TypeVariable<?>, Type> paramMap)
  {
    Object localObject;
    if (!isAssignable(paramClass1, paramClass2))
      localObject = null;
    label94: 
    while (true)
    {
      return localObject;
      if (paramClass1.isPrimitive())
      {
        if (paramClass2.isPrimitive())
          localObject = new HashMap();
        else
          paramClass1 = ClassUtils.primitiveToWrapper(paramClass1);
      }
      else
      {
        if (paramMap == null);
        for (localObject = new HashMap(); ; localObject = new HashMap(paramMap))
        {
          if ((paramClass1.getTypeParameters().length > 0) || (paramClass2.equals(paramClass1)))
            break label94;
          localObject = getTypeArguments(getClosestParentType(paramClass1, paramClass2), paramClass2, (Map)localObject);
          break;
        }
      }
    }
  }

  public static Map<TypeVariable<?>, Type> getTypeArguments(ParameterizedType paramParameterizedType)
  {
    return getTypeArguments(paramParameterizedType, getRawType(paramParameterizedType), null);
  }

  private static Map<TypeVariable<?>, Type> getTypeArguments(ParameterizedType paramParameterizedType, Class<?> paramClass, Map<TypeVariable<?>, Type> paramMap)
  {
    Class localClass = getRawType(paramParameterizedType);
    if (!isAssignable(localClass, paramClass))
      localObject = null;
    Type[] arrayOfType;
    TypeVariable[] arrayOfTypeVariable;
    int i;
    while (true)
    {
      return localObject;
      Type localType1 = paramParameterizedType.getOwnerType();
      if (!(localType1 instanceof ParameterizedType))
        break;
      ParameterizedType localParameterizedType = (ParameterizedType)localType1;
      localObject = getTypeArguments(localParameterizedType, getRawType(localParameterizedType), paramMap);
      arrayOfType = paramParameterizedType.getActualTypeArguments();
      arrayOfTypeVariable = localClass.getTypeParameters();
      i = 0;
      if (i < arrayOfTypeVariable.length)
        break label133;
      if (!paramClass.equals(localClass))
        localObject = getTypeArguments(getClosestParentType(localClass, paramClass), paramClass, (Map)localObject);
    }
    if (paramMap == null);
    for (Object localObject = new HashMap(); ; localObject = new HashMap(paramMap))
      break;
    label133: Type localType2 = arrayOfType[i];
    TypeVariable localTypeVariable = arrayOfTypeVariable[i];
    if (((Map)localObject).containsKey(localType2));
    for (Type localType3 = (Type)((Map)localObject).get(localType2); ; localType3 = localType2)
    {
      ((Map)localObject).put(localTypeVariable, localType3);
      i++;
      break;
    }
  }

  public static Map<TypeVariable<?>, Type> getTypeArguments(Type paramType, Class<?> paramClass)
  {
    return getTypeArguments(paramType, paramClass, null);
  }

  private static Map<TypeVariable<?>, Type> getTypeArguments(Type paramType, Class<?> paramClass, Map<TypeVariable<?>, Type> paramMap)
  {
    Map localMap = null;
    int i = 0;
    if ((paramType instanceof Class))
      localMap = getTypeArguments((Class)paramType, paramClass, paramMap);
    label144: label205: 
    while (true)
    {
      return localMap;
      if ((paramType instanceof ParameterizedType))
      {
        localMap = getTypeArguments((ParameterizedType)paramType, paramClass, paramMap);
      }
      else if ((paramType instanceof GenericArrayType))
      {
        Type localType3 = ((GenericArrayType)paramType).getGenericComponentType();
        if (paramClass.isArray())
          paramClass = paramClass.getComponentType();
        localMap = getTypeArguments(localType3, paramClass, paramMap);
      }
      else if ((paramType instanceof WildcardType))
      {
        Type[] arrayOfType2 = getImplicitUpperBounds((WildcardType)paramType);
        int k = arrayOfType2.length;
        while (true)
        {
          if (i >= k)
            break label144;
          Type localType2 = arrayOfType2[i];
          if (isAssignable(localType2, paramClass))
          {
            localMap = getTypeArguments(localType2, paramClass, paramMap);
            break;
          }
          i++;
        }
      }
      else
      {
        if (!(paramType instanceof TypeVariable))
          break;
        Type[] arrayOfType1 = getImplicitBounds((TypeVariable)paramType);
        int j = arrayOfType1.length;
        while (true)
        {
          if (i >= j)
            break label205;
          Type localType1 = arrayOfType1[i];
          if (isAssignable(localType1, paramClass))
          {
            localMap = getTypeArguments(localType1, paramClass, paramMap);
            break;
          }
          i++;
        }
      }
    }
    throw new IllegalStateException("found an unhandled type: " + paramType);
  }

  public static boolean isArrayType(Type paramType)
  {
    if ((!(paramType instanceof GenericArrayType)) && ((!(paramType instanceof Class)) || (!((Class)paramType).isArray())));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  private static boolean isAssignable(Type paramType, Class<?> paramClass)
  {
    boolean bool = false;
    if (paramType == null)
      if ((paramClass == null) || (!paramClass.isPrimitive()));
    label133: 
    do
      while (true)
      {
        return bool;
        bool = true;
        continue;
        if (paramClass != null)
          if (paramClass.equals(paramType))
          {
            bool = true;
          }
          else if ((paramType instanceof Class))
          {
            bool = ClassUtils.isAssignable((Class)paramType, paramClass);
          }
          else if ((paramType instanceof ParameterizedType))
          {
            bool = isAssignable(getRawType((ParameterizedType)paramType), paramClass);
          }
          else if ((paramType instanceof TypeVariable))
          {
            Type[] arrayOfType = ((TypeVariable)paramType).getBounds();
            int i = arrayOfType.length;
            for (int j = 0; ; j++)
            {
              if (j >= i)
                break label133;
              if (isAssignable(arrayOfType[j], paramClass))
              {
                bool = true;
                break;
              }
            }
          }
          else
          {
            if (!(paramType instanceof GenericArrayType))
              break;
            if ((paramClass.equals(Object.class)) || ((paramClass.isArray()) && (isAssignable(((GenericArrayType)paramType).getGenericComponentType(), paramClass.getComponentType()))))
              bool = true;
          }
      }
    while ((paramType instanceof WildcardType));
    throw new IllegalStateException("found an unhandled type: " + paramType);
  }

  private static boolean isAssignable(Type paramType, GenericArrayType paramGenericArrayType, Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool = true;
    if (paramType == null);
    while (true)
    {
      return bool;
      if (paramGenericArrayType == null)
      {
        bool = false;
      }
      else if (!paramGenericArrayType.equals(paramType))
      {
        Type localType = paramGenericArrayType.getGenericComponentType();
        if ((paramType instanceof Class))
        {
          Class localClass = (Class)paramType;
          if ((!localClass.isArray()) || (!isAssignable(localClass.getComponentType(), localType, paramMap)))
            bool = false;
        }
        else if ((paramType instanceof GenericArrayType))
        {
          bool = isAssignable(((GenericArrayType)paramType).getGenericComponentType(), localType, paramMap);
        }
        else
        {
          if ((paramType instanceof WildcardType))
          {
            Type[] arrayOfType2 = getImplicitUpperBounds((WildcardType)paramType);
            int k = arrayOfType2.length;
            for (int m = 0; ; m++)
            {
              if (m >= k)
              {
                bool = false;
                break;
              }
              if (isAssignable(arrayOfType2[m], paramGenericArrayType))
                break;
            }
          }
          if ((paramType instanceof TypeVariable))
          {
            Type[] arrayOfType1 = getImplicitBounds((TypeVariable)paramType);
            int i = arrayOfType1.length;
            for (int j = 0; ; j++)
            {
              if (j >= i)
              {
                bool = false;
                break;
              }
              if (isAssignable(arrayOfType1[j], paramGenericArrayType))
                break;
            }
          }
          if (!(paramType instanceof ParameterizedType))
            break;
          bool = false;
        }
      }
    }
    throw new IllegalStateException("found an unhandled type: " + paramType);
  }

  private static boolean isAssignable(Type paramType, ParameterizedType paramParameterizedType, Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool = true;
    if (paramType == null)
      break label79;
    while (true)
    {
      return bool;
      if (paramParameterizedType == null)
      {
        bool = false;
      }
      else if (!paramParameterizedType.equals(paramType))
      {
        Class localClass = getRawType(paramParameterizedType);
        Map localMap = getTypeArguments(paramType, localClass, null);
        if (localMap == null)
        {
          bool = false;
        }
        else if (!localMap.isEmpty())
        {
          Iterator localIterator = getTypeArguments(paramParameterizedType, localClass, paramMap).entrySet().iterator();
          label79: if (localIterator.hasNext())
          {
            Map.Entry localEntry = (Map.Entry)localIterator.next();
            Type localType1 = (Type)localEntry.getValue();
            Type localType2 = (Type)localMap.get(localEntry.getKey());
            if ((localType2 == null) || (localType1.equals(localType2)) || (((localType1 instanceof WildcardType)) && (isAssignable(localType2, localType1, paramMap))))
              break;
            bool = false;
          }
        }
      }
    }
  }

  public static boolean isAssignable(Type paramType1, Type paramType2)
  {
    return isAssignable(paramType1, paramType2, null);
  }

  private static boolean isAssignable(Type paramType1, Type paramType2, Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool;
    if ((paramType2 == null) || ((paramType2 instanceof Class)))
      bool = isAssignable(paramType1, (Class)paramType2);
    while (true)
    {
      return bool;
      if ((paramType2 instanceof ParameterizedType))
      {
        bool = isAssignable(paramType1, (ParameterizedType)paramType2, paramMap);
      }
      else if ((paramType2 instanceof GenericArrayType))
      {
        bool = isAssignable(paramType1, (GenericArrayType)paramType2, paramMap);
      }
      else if ((paramType2 instanceof WildcardType))
      {
        bool = isAssignable(paramType1, (WildcardType)paramType2, paramMap);
      }
      else
      {
        if (!(paramType2 instanceof TypeVariable))
          break;
        bool = isAssignable(paramType1, (TypeVariable)paramType2, paramMap);
      }
    }
    throw new IllegalStateException("found an unhandled type: " + paramType2);
  }

  private static boolean isAssignable(Type paramType, TypeVariable<?> paramTypeVariable, Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool;
    if (paramType == null)
      bool = true;
    while (true)
    {
      return bool;
      if (paramTypeVariable == null)
      {
        bool = false;
      }
      else
      {
        if (!paramTypeVariable.equals(paramType))
          break;
        bool = true;
      }
    }
    Type[] arrayOfType;
    int i;
    if ((paramType instanceof TypeVariable))
    {
      arrayOfType = getImplicitBounds((TypeVariable)paramType);
      i = arrayOfType.length;
    }
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        if ((!(paramType instanceof Class)) && (!(paramType instanceof ParameterizedType)) && (!(paramType instanceof GenericArrayType)) && (!(paramType instanceof WildcardType)))
          break label118;
        bool = false;
        break;
      }
      if (isAssignable(arrayOfType[j], paramTypeVariable, paramMap))
      {
        bool = true;
        break;
      }
    }
    label118: throw new IllegalStateException("found an unhandled type: " + paramType);
  }

  private static boolean isAssignable(Type paramType, WildcardType paramWildcardType, Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool;
    if (paramType == null)
      bool = true;
    Type[] arrayOfType1;
    Type[] arrayOfType2;
    Type[] arrayOfType3;
    Type[] arrayOfType4;
    int i1;
    label79: int i5;
    while (true)
    {
      return bool;
      if (paramWildcardType == null)
      {
        bool = false;
      }
      else if (paramWildcardType.equals(paramType))
      {
        bool = true;
      }
      else
      {
        arrayOfType1 = getImplicitUpperBounds(paramWildcardType);
        arrayOfType2 = getImplicitLowerBounds(paramWildcardType);
        if (!(paramType instanceof WildcardType))
          break label222;
        WildcardType localWildcardType = (WildcardType)paramType;
        arrayOfType3 = getImplicitUpperBounds(localWildcardType);
        arrayOfType4 = getImplicitLowerBounds(localWildcardType);
        int n = arrayOfType1.length;
        i1 = 0;
        if (i1 < n)
          break;
        int i4 = arrayOfType2.length;
        i5 = 0;
        label94: if (i5 < i4)
          break label164;
        bool = true;
      }
    }
    Type localType1 = substituteTypeVariables(arrayOfType1[i1], paramMap);
    int i2 = arrayOfType3.length;
    for (int i3 = 0; ; i3++)
    {
      if (i3 >= i2)
      {
        i1++;
        break label79;
      }
      if (!isAssignable(arrayOfType3[i3], localType1, paramMap))
      {
        bool = false;
        break;
      }
    }
    label164: Type localType2 = substituteTypeVariables(arrayOfType2[i5], paramMap);
    int i6 = arrayOfType4.length;
    for (int i7 = 0; ; i7++)
    {
      if (i7 >= i6)
      {
        i5++;
        break label94;
      }
      if (!isAssignable(localType2, arrayOfType4[i7], paramMap))
      {
        bool = false;
        break;
      }
    }
    label222: int i = arrayOfType1.length;
    int j = 0;
    label229: int k;
    if (j >= i)
      k = arrayOfType2.length;
    for (int m = 0; ; m++)
    {
      if (m >= k)
      {
        bool = true;
        break;
        if (!isAssignable(paramType, substituteTypeVariables(arrayOfType1[j], paramMap), paramMap))
        {
          bool = false;
          break;
        }
        j++;
        break label229;
      }
      if (!isAssignable(substituteTypeVariables(arrayOfType2[m], paramMap), paramType, paramMap))
      {
        bool = false;
        break;
      }
    }
  }

  public static boolean isInstance(Object paramObject, Type paramType)
  {
    boolean bool = false;
    if (paramType == null);
    while (true)
    {
      return bool;
      if (paramObject == null)
      {
        if ((!(paramType instanceof Class)) || (!((Class)paramType).isPrimitive()))
          bool = true;
      }
      else
        bool = isAssignable(paramObject.getClass(), paramType, null);
    }
  }

  private static <T> void mapTypeVariablesToArguments(Class<T> paramClass, ParameterizedType paramParameterizedType, Map<TypeVariable<?>, Type> paramMap)
  {
    Type localType1 = paramParameterizedType.getOwnerType();
    if ((localType1 instanceof ParameterizedType))
      mapTypeVariablesToArguments(paramClass, (ParameterizedType)localType1, paramMap);
    Type[] arrayOfType = paramParameterizedType.getActualTypeArguments();
    TypeVariable[] arrayOfTypeVariable = getRawType(paramParameterizedType).getTypeParameters();
    List localList = Arrays.asList(paramClass.getTypeParameters());
    for (int i = 0; ; i++)
    {
      if (i >= arrayOfType.length)
        return;
      TypeVariable localTypeVariable = arrayOfTypeVariable[i];
      Type localType2 = arrayOfType[i];
      if ((localList.contains(localType2)) && (paramMap.containsKey(localTypeVariable)))
        paramMap.put((TypeVariable)localType2, (Type)paramMap.get(localTypeVariable));
    }
  }

  public static Type[] normalizeUpperBounds(Type[] paramArrayOfType)
  {
    if (paramArrayOfType.length < 2);
    HashSet localHashSet;
    int j;
    while (true)
    {
      return paramArrayOfType;
      localHashSet = new HashSet(paramArrayOfType.length);
      int i = paramArrayOfType.length;
      j = 0;
      if (j < i)
        break;
      paramArrayOfType = (Type[])localHashSet.toArray(new Type[localHashSet.size()]);
    }
    Type localType1 = paramArrayOfType[j];
    int k = 0;
    int m = paramArrayOfType.length;
    label122: for (int n = 0; ; n++)
    {
      if (n >= m);
      while (true)
      {
        if (k == 0)
          localHashSet.add(localType1);
        j++;
        break;
        Type localType2 = paramArrayOfType[n];
        if ((localType1 == localType2) || (!isAssignable(localType2, localType1, null)))
          break label122;
        k = 1;
      }
    }
  }

  private static Type substituteTypeVariables(Type paramType, Map<TypeVariable<?>, Type> paramMap)
  {
    Type localType;
    if (((paramType instanceof TypeVariable)) && (paramMap != null))
    {
      localType = (Type)paramMap.get(paramType);
      if (localType == null)
        throw new IllegalArgumentException("missing assignment type for type variable " + paramType);
    }
    else
    {
      localType = paramType;
    }
    return localType;
  }

  public static boolean typesSatisfyVariables(Map<TypeVariable<?>, Type> paramMap)
  {
    boolean bool = false;
    Iterator localIterator = paramMap.entrySet().iterator();
    label103: 
    while (true)
    {
      if (!localIterator.hasNext())
      {
        bool = true;
        return bool;
      }
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      TypeVariable localTypeVariable = (TypeVariable)localEntry.getKey();
      Type localType = (Type)localEntry.getValue();
      Type[] arrayOfType = getImplicitBounds(localTypeVariable);
      int i = arrayOfType.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label103;
        if (!isAssignable(localType, substituteTypeVariables(arrayOfType[j], paramMap), paramMap))
          break;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.reflect.TypeUtils
 * JD-Core Version:    0.6.2
 */