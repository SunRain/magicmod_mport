package org.apache.commons.lang3.reflect;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ClassUtils;

public class MethodUtils
{
  public static Method getAccessibleMethod(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass)
  {
    try
    {
      Method localMethod2 = getAccessibleMethod(paramClass.getMethod(paramString, paramArrayOfClass));
      localMethod1 = localMethod2;
      return localMethod1;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      while (true)
        Method localMethod1 = null;
    }
  }

  public static Method getAccessibleMethod(Method paramMethod)
  {
    if (!MemberUtils.isAccessible(paramMethod))
      paramMethod = null;
    while (true)
    {
      return paramMethod;
      Class localClass = paramMethod.getDeclaringClass();
      if (!Modifier.isPublic(localClass.getModifiers()))
      {
        String str = paramMethod.getName();
        Class[] arrayOfClass = paramMethod.getParameterTypes();
        paramMethod = getAccessibleMethodFromInterfaceNest(localClass, str, arrayOfClass);
        if (paramMethod == null)
          paramMethod = getAccessibleMethodFromSuperclass(localClass, str, arrayOfClass);
      }
    }
  }

  private static Method getAccessibleMethodFromInterfaceNest(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass)
  {
    Object localObject = null;
    if (paramClass == null)
      return localObject;
    Class[] arrayOfClass = paramClass.getInterfaces();
    int i = 0;
    label17: if (i >= arrayOfClass.length);
    while (true)
    {
      paramClass = paramClass.getSuperclass();
      break;
      if (!Modifier.isPublic(arrayOfClass[i].getModifiers()))
      {
        label47: i++;
        break label17;
      }
      try
      {
        Method localMethod = arrayOfClass[i].getDeclaredMethod(paramString, paramArrayOfClass);
        localObject = localMethod;
        label68: if (localObject != null)
          continue;
        localObject = getAccessibleMethodFromInterfaceNest(arrayOfClass[i], paramString, paramArrayOfClass);
        if (localObject == null)
          break label47;
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        break label68;
      }
    }
  }

  private static Method getAccessibleMethodFromSuperclass(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass)
  {
    Object localObject = null;
    for (Class localClass = paramClass.getSuperclass(); ; localClass = localClass.getSuperclass())
    {
      if (localClass == null);
      while (true)
      {
        return localObject;
        if (!Modifier.isPublic(localClass.getModifiers()))
          break;
        try
        {
          Method localMethod = localClass.getMethod(paramString, paramArrayOfClass);
          localObject = localMethod;
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
        }
      }
    }
  }

  public static Method getMatchingAccessibleMethod(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass)
  {
    Object localObject2;
    Object localObject1;
    Method[] arrayOfMethod;
    int i;
    int j;
    try
    {
      localObject2 = paramClass.getMethod(paramString, paramArrayOfClass);
      MemberUtils.setAccessibleWorkaround((AccessibleObject)localObject2);
      return localObject2;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      localObject1 = null;
      arrayOfMethod = paramClass.getMethods();
      i = arrayOfMethod.length;
      j = 0;
    }
    while (true)
    {
      if (j >= i)
      {
        if (localObject1 != null)
          MemberUtils.setAccessibleWorkaround((AccessibleObject)localObject1);
        localObject2 = localObject1;
        break;
      }
      Method localMethod1 = arrayOfMethod[j];
      if ((localMethod1.getName().equals(paramString)) && (ClassUtils.isAssignable(paramArrayOfClass, localMethod1.getParameterTypes(), true)))
      {
        Method localMethod2 = getAccessibleMethod(localMethod1);
        if ((localMethod2 != null) && ((localObject1 == null) || (MemberUtils.compareParameterTypes(localMethod2.getParameterTypes(), ((Method)localObject1).getParameterTypes(), paramArrayOfClass) < 0)))
          localObject1 = localMethod2;
      }
      j++;
    }
  }

  public static Object invokeExactMethod(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    int i = paramArrayOfObject.length;
    Class[] arrayOfClass = new Class[i];
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return invokeExactMethod(paramObject, paramString, paramArrayOfObject, arrayOfClass);
      arrayOfClass[j] = paramArrayOfObject[j].getClass();
    }
  }

  public static Object invokeExactMethod(Object paramObject, String paramString, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    Method localMethod = getAccessibleMethod(paramObject.getClass(), paramString, paramArrayOfClass);
    if (localMethod == null)
      throw new NoSuchMethodException("No such accessible method: " + paramString + "() on object: " + paramObject.getClass().getName());
    return localMethod.invoke(paramObject, paramArrayOfObject);
  }

  public static Object invokeExactStaticMethod(Class<?> paramClass, String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    int i = paramArrayOfObject.length;
    Class[] arrayOfClass = new Class[i];
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return invokeExactStaticMethod(paramClass, paramString, paramArrayOfObject, arrayOfClass);
      arrayOfClass[j] = paramArrayOfObject[j].getClass();
    }
  }

  public static Object invokeExactStaticMethod(Class<?> paramClass, String paramString, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    Method localMethod = getAccessibleMethod(paramClass, paramString, paramArrayOfClass);
    if (localMethod == null)
      throw new NoSuchMethodException("No such accessible method: " + paramString + "() on class: " + paramClass.getName());
    return localMethod.invoke(null, paramArrayOfObject);
  }

  public static Object invokeMethod(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    int i = paramArrayOfObject.length;
    Class[] arrayOfClass = new Class[i];
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return invokeMethod(paramObject, paramString, paramArrayOfObject, arrayOfClass);
      arrayOfClass[j] = paramArrayOfObject[j].getClass();
    }
  }

  public static Object invokeMethod(Object paramObject, String paramString, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    Method localMethod = getMatchingAccessibleMethod(paramObject.getClass(), paramString, paramArrayOfClass);
    if (localMethod == null)
      throw new NoSuchMethodException("No such accessible method: " + paramString + "() on object: " + paramObject.getClass().getName());
    return localMethod.invoke(paramObject, paramArrayOfObject);
  }

  public static Object invokeStaticMethod(Class<?> paramClass, String paramString, Object[] paramArrayOfObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    int i = paramArrayOfObject.length;
    Class[] arrayOfClass = new Class[i];
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return invokeStaticMethod(paramClass, paramString, paramArrayOfObject, arrayOfClass);
      arrayOfClass[j] = paramArrayOfObject[j].getClass();
    }
  }

  public static Object invokeStaticMethod(Class<?> paramClass, String paramString, Object[] paramArrayOfObject, Class<?>[] paramArrayOfClass)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if (paramArrayOfClass == null)
      paramArrayOfClass = ArrayUtils.EMPTY_CLASS_ARRAY;
    if (paramArrayOfObject == null)
      paramArrayOfObject = ArrayUtils.EMPTY_OBJECT_ARRAY;
    Method localMethod = getMatchingAccessibleMethod(paramClass, paramString, paramArrayOfClass);
    if (localMethod == null)
      throw new NoSuchMethodException("No such accessible method: " + paramString + "() on class: " + paramClass.getName());
    return localMethod.invoke(null, paramArrayOfObject);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.reflect.MethodUtils
 * JD-Core Version:    0.6.2
 */