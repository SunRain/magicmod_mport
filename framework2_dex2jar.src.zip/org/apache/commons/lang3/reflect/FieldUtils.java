package org.apache.commons.lang3.reflect;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang3.ClassUtils;

public class FieldUtils
{
  public static Field getDeclaredField(Class<?> paramClass, String paramString)
  {
    return getDeclaredField(paramClass, paramString, false);
  }

  public static Field getDeclaredField(Class<?> paramClass, String paramString, boolean paramBoolean)
  {
    if (paramClass == null)
      throw new IllegalArgumentException("The class must not be null");
    if (paramString == null)
      throw new IllegalArgumentException("The field name must not be null");
    try
    {
      localField = paramClass.getDeclaredField(paramString);
      if (!MemberUtils.isAccessible(localField))
      {
        if (!paramBoolean)
          break label56;
        localField.setAccessible(true);
      }
      while (true)
      {
        return localField;
        label56: localField = null;
      }
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      while (true)
        Field localField = null;
    }
  }

  public static Field getField(Class<?> paramClass, String paramString)
  {
    Field localField = getField(paramClass, paramString, false);
    MemberUtils.setAccessibleWorkaround(localField);
    return localField;
  }

  public static Field getField(Class<?> paramClass, String paramString, boolean paramBoolean)
  {
    if (paramClass == null)
      throw new IllegalArgumentException("The class must not be null");
    if (paramString == null)
      throw new IllegalArgumentException("The field name must not be null");
    Object localObject1 = paramClass;
    Object localObject3;
    Iterator localIterator;
    if (localObject1 == null)
    {
      localObject3 = null;
      localIterator = ClassUtils.getAllInterfaces(paramClass).iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
      {
        Object localObject2 = localObject3;
        while (true)
        {
          return localObject2;
          try
          {
            localObject2 = ((Class)localObject1).getDeclaredField(paramString);
            if (!Modifier.isPublic(((Field)localObject2).getModifiers()))
              if (paramBoolean)
                ((Field)localObject2).setAccessible(true);
          }
          catch (NoSuchFieldException localNoSuchFieldException1)
          {
            localObject1 = ((Class)localObject1).getSuperclass();
          }
        }
        break;
      }
      Class localClass = (Class)localIterator.next();
      Field localField;
      try
      {
        localField = localClass.getField(paramString);
        if (localObject3 == null)
          break label174;
        throw new IllegalArgumentException("Reference to field " + paramString + " is ambiguous relative to " + paramClass + "; a matching field exists on two or more implemented interfaces.");
      }
      catch (NoSuchFieldException localNoSuchFieldException2)
      {
      }
      continue;
      label174: localObject3 = localField;
    }
  }

  public static Object readDeclaredField(Object paramObject, String paramString)
    throws IllegalAccessException
  {
    return readDeclaredField(paramObject, paramString, false);
  }

  public static Object readDeclaredField(Object paramObject, String paramString, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramObject == null)
      throw new IllegalArgumentException("target object must not be null");
    Class localClass = paramObject.getClass();
    Field localField = getDeclaredField(localClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate declared field " + localClass.getName() + "." + paramString);
    return readField(localField, paramObject);
  }

  public static Object readDeclaredStaticField(Class<?> paramClass, String paramString)
    throws IllegalAccessException
  {
    return readDeclaredStaticField(paramClass, paramString, false);
  }

  public static Object readDeclaredStaticField(Class<?> paramClass, String paramString, boolean paramBoolean)
    throws IllegalAccessException
  {
    Field localField = getDeclaredField(paramClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate declared field " + paramClass.getName() + "." + paramString);
    return readStaticField(localField, false);
  }

  public static Object readField(Object paramObject, String paramString)
    throws IllegalAccessException
  {
    return readField(paramObject, paramString, false);
  }

  public static Object readField(Object paramObject, String paramString, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramObject == null)
      throw new IllegalArgumentException("target object must not be null");
    Class localClass = paramObject.getClass();
    Field localField = getField(localClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate field " + paramString + " on " + localClass);
    return readField(localField, paramObject);
  }

  public static Object readField(Field paramField, Object paramObject)
    throws IllegalAccessException
  {
    return readField(paramField, paramObject, false);
  }

  public static Object readField(Field paramField, Object paramObject, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramField == null)
      throw new IllegalArgumentException("The field must not be null");
    if ((paramBoolean) && (!paramField.isAccessible()))
      paramField.setAccessible(true);
    while (true)
    {
      return paramField.get(paramObject);
      MemberUtils.setAccessibleWorkaround(paramField);
    }
  }

  public static Object readStaticField(Class<?> paramClass, String paramString)
    throws IllegalAccessException
  {
    return readStaticField(paramClass, paramString, false);
  }

  public static Object readStaticField(Class<?> paramClass, String paramString, boolean paramBoolean)
    throws IllegalAccessException
  {
    Field localField = getField(paramClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate field " + paramString + " on " + paramClass);
    return readStaticField(localField, false);
  }

  public static Object readStaticField(Field paramField)
    throws IllegalAccessException
  {
    return readStaticField(paramField, false);
  }

  public static Object readStaticField(Field paramField, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramField == null)
      throw new IllegalArgumentException("The field must not be null");
    if (!Modifier.isStatic(paramField.getModifiers()))
      throw new IllegalArgumentException("The field '" + paramField.getName() + "' is not static");
    return readField(paramField, null, paramBoolean);
  }

  public static void writeDeclaredField(Object paramObject1, String paramString, Object paramObject2)
    throws IllegalAccessException
  {
    writeDeclaredField(paramObject1, paramString, paramObject2, false);
  }

  public static void writeDeclaredField(Object paramObject1, String paramString, Object paramObject2, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramObject1 == null)
      throw new IllegalArgumentException("target object must not be null");
    Class localClass = paramObject1.getClass();
    Field localField = getDeclaredField(localClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate declared field " + localClass.getName() + "." + paramString);
    writeField(localField, paramObject1, paramObject2);
  }

  public static void writeDeclaredStaticField(Class<?> paramClass, String paramString, Object paramObject)
    throws IllegalAccessException
  {
    writeDeclaredStaticField(paramClass, paramString, paramObject, false);
  }

  public static void writeDeclaredStaticField(Class<?> paramClass, String paramString, Object paramObject, boolean paramBoolean)
    throws IllegalAccessException
  {
    Field localField = getDeclaredField(paramClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate declared field " + paramClass.getName() + "." + paramString);
    writeField(localField, null, paramObject);
  }

  public static void writeField(Object paramObject1, String paramString, Object paramObject2)
    throws IllegalAccessException
  {
    writeField(paramObject1, paramString, paramObject2, false);
  }

  public static void writeField(Object paramObject1, String paramString, Object paramObject2, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramObject1 == null)
      throw new IllegalArgumentException("target object must not be null");
    Class localClass = paramObject1.getClass();
    Field localField = getField(localClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate declared field " + localClass.getName() + "." + paramString);
    writeField(localField, paramObject1, paramObject2);
  }

  public static void writeField(Field paramField, Object paramObject1, Object paramObject2)
    throws IllegalAccessException
  {
    writeField(paramField, paramObject1, paramObject2, false);
  }

  public static void writeField(Field paramField, Object paramObject1, Object paramObject2, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramField == null)
      throw new IllegalArgumentException("The field must not be null");
    if ((paramBoolean) && (!paramField.isAccessible()))
      paramField.setAccessible(true);
    while (true)
    {
      paramField.set(paramObject1, paramObject2);
      return;
      MemberUtils.setAccessibleWorkaround(paramField);
    }
  }

  public static void writeStaticField(Class<?> paramClass, String paramString, Object paramObject)
    throws IllegalAccessException
  {
    writeStaticField(paramClass, paramString, paramObject, false);
  }

  public static void writeStaticField(Class<?> paramClass, String paramString, Object paramObject, boolean paramBoolean)
    throws IllegalAccessException
  {
    Field localField = getField(paramClass, paramString, paramBoolean);
    if (localField == null)
      throw new IllegalArgumentException("Cannot locate field " + paramString + " on " + paramClass);
    writeStaticField(localField, paramObject);
  }

  public static void writeStaticField(Field paramField, Object paramObject)
    throws IllegalAccessException
  {
    writeStaticField(paramField, paramObject, false);
  }

  public static void writeStaticField(Field paramField, Object paramObject, boolean paramBoolean)
    throws IllegalAccessException
  {
    if (paramField == null)
      throw new IllegalArgumentException("The field must not be null");
    if (!Modifier.isStatic(paramField.getModifiers()))
      throw new IllegalArgumentException("The field '" + paramField.getName() + "' is not static");
    writeField(paramField, null, paramObject, paramBoolean);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.reflect.FieldUtils
 * JD-Core Version:    0.6.2
 */