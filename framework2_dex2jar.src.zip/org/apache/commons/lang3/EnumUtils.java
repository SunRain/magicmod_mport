package org.apache.commons.lang3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EnumUtils
{
  private static <E extends Enum<E>> Class<E> checkBitVectorable(Class<E> paramClass)
  {
    Validate.notNull(paramClass, "EnumClass must be defined.", new Object[0]);
    Enum[] arrayOfEnum = (Enum[])paramClass.getEnumConstants();
    boolean bool1;
    if (arrayOfEnum != null)
    {
      bool1 = true;
      Validate.isTrue(bool1, "%s does not seem to be an Enum type", new Object[] { paramClass });
      if (arrayOfEnum.length > 64)
        break label97;
    }
    label97: for (boolean bool2 = true; ; bool2 = false)
    {
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = Integer.valueOf(arrayOfEnum.length);
      arrayOfObject[1] = paramClass.getSimpleName();
      arrayOfObject[2] = Integer.valueOf(64);
      Validate.isTrue(bool2, "Cannot store %s %s values in %s bits", arrayOfObject);
      return paramClass;
      bool1 = false;
      break;
    }
  }

  public static <E extends Enum<E>> long generateBitVector(Class<E> paramClass, Iterable<E> paramIterable)
  {
    checkBitVectorable(paramClass);
    Validate.notNull(paramIterable);
    long l = 0L;
    Iterator localIterator = paramIterable.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return l;
      l |= 1 << ((Enum)localIterator.next()).ordinal();
    }
  }

  public static <E extends Enum<E>> long generateBitVector(Class<E> paramClass, E[] paramArrayOfE)
  {
    Validate.noNullElements(paramArrayOfE);
    return generateBitVector(paramClass, Arrays.asList(paramArrayOfE));
  }

  public static <E extends Enum<E>> E getEnum(Class<E> paramClass, String paramString)
  {
    Object localObject = null;
    if (paramString == null);
    while (true)
    {
      return localObject;
      try
      {
        Enum localEnum = Enum.valueOf(paramClass, paramString);
        localObject = localEnum;
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
      }
    }
  }

  public static <E extends Enum<E>> List<E> getEnumList(Class<E> paramClass)
  {
    return new ArrayList(Arrays.asList((Enum[])paramClass.getEnumConstants()));
  }

  public static <E extends Enum<E>> Map<String, E> getEnumMap(Class<E> paramClass)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    Enum[] arrayOfEnum = (Enum[])paramClass.getEnumConstants();
    int i = arrayOfEnum.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localLinkedHashMap;
      Enum localEnum = arrayOfEnum[j];
      localLinkedHashMap.put(localEnum.name(), localEnum);
    }
  }

  public static <E extends Enum<E>> boolean isValidEnum(Class<E> paramClass, String paramString)
  {
    boolean bool = false;
    if (paramString == null);
    while (true)
    {
      return bool;
      try
      {
        Enum.valueOf(paramClass, paramString);
        bool = true;
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
      }
    }
  }

  public static <E extends Enum<E>> EnumSet<E> processBitVector(Class<E> paramClass, long paramLong)
  {
    Enum[] arrayOfEnum = (Enum[])checkBitVectorable(paramClass).getEnumConstants();
    EnumSet localEnumSet = EnumSet.noneOf(paramClass);
    int i = arrayOfEnum.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localEnumSet;
      Enum localEnum = arrayOfEnum[j];
      if ((paramLong & 1 << localEnum.ordinal()) != 0L)
        localEnumSet.add(localEnum);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.EnumUtils
 * JD-Core Version:    0.6.2
 */