package org.apache.commons.lang3;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

final class CharRange
  implements Iterable<Character>, Serializable
{
  private static final long serialVersionUID = 8270183163158333422L;
  private final char end;
  private transient String iToString;
  private final boolean negated;
  private final char start;

  private CharRange(char paramChar1, char paramChar2, boolean paramBoolean)
  {
    if (paramChar1 > paramChar2)
    {
      char c = paramChar1;
      paramChar1 = paramChar2;
      paramChar2 = c;
    }
    this.start = paramChar1;
    this.end = paramChar2;
    this.negated = paramBoolean;
  }

  public static CharRange is(char paramChar)
  {
    return new CharRange(paramChar, paramChar, false);
  }

  public static CharRange isIn(char paramChar1, char paramChar2)
  {
    return new CharRange(paramChar1, paramChar2, false);
  }

  public static CharRange isNot(char paramChar)
  {
    return new CharRange(paramChar, paramChar, true);
  }

  public static CharRange isNotIn(char paramChar1, char paramChar2)
  {
    return new CharRange(paramChar1, paramChar2, true);
  }

  public boolean contains(char paramChar)
  {
    if ((paramChar >= this.start) && (paramChar <= this.end));
    for (int i = 1; ; i = 0)
      return i ^ this.negated;
  }

  public boolean contains(CharRange paramCharRange)
  {
    boolean bool = true;
    if (paramCharRange == null)
      throw new IllegalArgumentException("The Range must not be null");
    if (this.negated)
      if (paramCharRange.negated)
        if ((this.start < paramCharRange.start) || (this.end > paramCharRange.end));
    while (true)
    {
      return bool;
      bool = false;
      continue;
      if ((paramCharRange.end >= this.start) && (paramCharRange.start <= this.end))
      {
        bool = false;
        continue;
        if (paramCharRange.negated)
        {
          if ((this.start != 0) || (this.end != 65535))
            bool = false;
        }
        else if ((this.start > paramCharRange.start) || (this.end < paramCharRange.end))
          bool = false;
      }
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (paramObject == this);
    while (true)
    {
      return bool;
      if (!(paramObject instanceof CharRange))
      {
        bool = false;
      }
      else
      {
        CharRange localCharRange = (CharRange)paramObject;
        if ((this.start != localCharRange.start) || (this.end != localCharRange.end) || (this.negated != localCharRange.negated))
          bool = false;
      }
    }
  }

  public char getEnd()
  {
    return this.end;
  }

  public char getStart()
  {
    return this.start;
  }

  public int hashCode()
  {
    int i = 'S' + this.start + '\007' * this.end;
    if (this.negated);
    for (int j = 1; ; j = 0)
      return j + i;
  }

  public boolean isNegated()
  {
    return this.negated;
  }

  public Iterator<Character> iterator()
  {
    return new CharacterIterator(this, null);
  }

  public String toString()
  {
    if (this.iToString == null)
    {
      StringBuilder localStringBuilder = new StringBuilder(4);
      if (isNegated())
        localStringBuilder.append('^');
      localStringBuilder.append(this.start);
      if (this.start != this.end)
      {
        localStringBuilder.append('-');
        localStringBuilder.append(this.end);
      }
      this.iToString = localStringBuilder.toString();
    }
    return this.iToString;
  }

  private static class CharacterIterator
    implements Iterator<Character>
  {
    private char current;
    private boolean hasNext;
    private final CharRange range;

    private CharacterIterator(CharRange paramCharRange)
    {
      this.range = paramCharRange;
      this.hasNext = true;
      if (this.range.negated)
        if (this.range.start == 0)
          if (this.range.end == 65535)
            this.hasNext = false;
      while (true)
      {
        return;
        this.current = ((char)('\001' + this.range.end));
        continue;
        this.current = '\000';
        continue;
        this.current = this.range.start;
      }
    }

    private void prepareNext()
    {
      if (this.range.negated)
        if (this.current == 65535)
          this.hasNext = false;
      while (true)
      {
        return;
        if ('\001' + this.current == this.range.start)
        {
          if (this.range.end == 65535)
            this.hasNext = false;
          else
            this.current = ((char)('\001' + this.range.end));
        }
        else
        {
          this.current = ((char)('\001' + this.current));
          continue;
          if (this.current < this.range.end)
            this.current = ((char)('\001' + this.current));
          else
            this.hasNext = false;
        }
      }
    }

    public boolean hasNext()
    {
      return this.hasNext;
    }

    public Character next()
    {
      if (!this.hasNext)
        throw new NoSuchElementException();
      char c = this.current;
      prepareNext();
      return Character.valueOf(c);
    }

    public void remove()
    {
      throw new UnsupportedOperationException();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.CharRange
 * JD-Core Version:    0.6.2
 */