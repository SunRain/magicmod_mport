package org.apache.commons.lang3;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class AnnotationUtils
{
  private static final ToStringStyle TO_STRING_STYLE = new ToStringStyle()
  {
    private static final long serialVersionUID = 1L;

    protected void appendDetail(StringBuffer paramAnonymousStringBuffer, String paramAnonymousString, Object paramAnonymousObject)
    {
      if ((paramAnonymousObject instanceof Annotation))
        paramAnonymousObject = AnnotationUtils.toString((Annotation)paramAnonymousObject);
      super.appendDetail(paramAnonymousStringBuffer, paramAnonymousString, paramAnonymousObject);
    }

    protected String getShortClassName(Class<?> paramAnonymousClass)
    {
      Object localObject = null;
      Iterator localIterator = ClassUtils.getAllInterfaces(paramAnonymousClass).iterator();
      if (!localIterator.hasNext())
        label21: if (localObject != null)
          break label75;
      label75: for (String str = ""; ; str = localObject.getName())
      {
        return new StringBuilder(str).insert(0, '@').toString();
        Class localClass = (Class)localIterator.next();
        if (!Annotation.class.isAssignableFrom(localClass))
          break;
        localObject = localClass;
        break label21;
      }
    }
  };

  private static boolean annotationArrayMemberEquals(Annotation[] paramArrayOfAnnotation1, Annotation[] paramArrayOfAnnotation2)
  {
    boolean bool = false;
    if (paramArrayOfAnnotation1.length != paramArrayOfAnnotation2.length)
      return bool;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfAnnotation1.length)
      {
        bool = true;
        break;
      }
      if (!equals(paramArrayOfAnnotation1[i], paramArrayOfAnnotation2[i]))
        break;
    }
  }

  private static boolean arrayMemberEquals(Class<?> paramClass, Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if (paramClass.isAnnotation())
      bool = annotationArrayMemberEquals((Annotation[])paramObject1, (Annotation[])paramObject2);
    while (true)
    {
      return bool;
      if (paramClass.equals(Byte.TYPE))
        bool = Arrays.equals((byte[])paramObject1, (byte[])paramObject2);
      else if (paramClass.equals(Short.TYPE))
        bool = Arrays.equals((short[])paramObject1, (short[])paramObject2);
      else if (paramClass.equals(Integer.TYPE))
        bool = Arrays.equals((int[])paramObject1, (int[])paramObject2);
      else if (paramClass.equals(Character.TYPE))
        bool = Arrays.equals((char[])paramObject1, (char[])paramObject2);
      else if (paramClass.equals(Long.TYPE))
        bool = Arrays.equals((long[])paramObject1, (long[])paramObject2);
      else if (paramClass.equals(Float.TYPE))
        bool = Arrays.equals((float[])paramObject1, (float[])paramObject2);
      else if (paramClass.equals(Double.TYPE))
        bool = Arrays.equals((double[])paramObject1, (double[])paramObject2);
      else if (paramClass.equals(Boolean.TYPE))
        bool = Arrays.equals((boolean[])paramObject1, (boolean[])paramObject2);
      else
        bool = Arrays.equals((Object[])paramObject1, (Object[])paramObject2);
    }
  }

  private static int arrayMemberHash(Class<?> paramClass, Object paramObject)
  {
    int i;
    if (paramClass.equals(Byte.TYPE))
      i = Arrays.hashCode((byte[])paramObject);
    while (true)
    {
      return i;
      if (paramClass.equals(Short.TYPE))
        i = Arrays.hashCode((short[])paramObject);
      else if (paramClass.equals(Integer.TYPE))
        i = Arrays.hashCode((int[])paramObject);
      else if (paramClass.equals(Character.TYPE))
        i = Arrays.hashCode((char[])paramObject);
      else if (paramClass.equals(Long.TYPE))
        i = Arrays.hashCode((long[])paramObject);
      else if (paramClass.equals(Float.TYPE))
        i = Arrays.hashCode((float[])paramObject);
      else if (paramClass.equals(Double.TYPE))
        i = Arrays.hashCode((double[])paramObject);
      else if (paramClass.equals(Boolean.TYPE))
        i = Arrays.hashCode((boolean[])paramObject);
      else
        i = Arrays.hashCode((Object[])paramObject);
    }
  }

  public static boolean equals(Annotation paramAnnotation1, Annotation paramAnnotation2)
  {
    boolean bool1 = true;
    if (paramAnnotation1 == paramAnnotation2);
    while (true)
    {
      return bool1;
      if ((paramAnnotation1 == null) || (paramAnnotation2 == null))
      {
        bool1 = false;
      }
      else
      {
        Class localClass1 = paramAnnotation1.annotationType();
        Class localClass2 = paramAnnotation2.annotationType();
        Object[] arrayOfObject1 = new Object[bool1];
        arrayOfObject1[0] = paramAnnotation1;
        Validate.notNull(localClass1, "Annotation %s with null annotationType()", arrayOfObject1);
        Object[] arrayOfObject2 = new Object[bool1];
        arrayOfObject2[0] = paramAnnotation2;
        Validate.notNull(localClass2, "Annotation %s with null annotationType()", arrayOfObject2);
        if (!localClass1.equals(localClass2))
          bool1 = false;
        else
          try
          {
            Method localMethod;
            for (localMethod : localClass1.getDeclaredMethods())
              if ((localMethod.getParameterTypes().length == 0) && (isValidAnnotationMemberType(localMethod.getReturnType())))
              {
                Object localObject1 = localMethod.invoke(paramAnnotation1, new Object[0]);
                Object localObject2 = localMethod.invoke(paramAnnotation2, new Object[0]);
                boolean bool2 = memberEquals(localMethod.getReturnType(), localObject1, localObject2);
                if (!bool2)
                {
                  bool1 = false;
                  break;
                }
              }
          }
          catch (IllegalAccessException localIllegalAccessException)
          {
            bool1 = false;
          }
          catch (InvocationTargetException localInvocationTargetException)
          {
            bool1 = false;
          }
      }
    }
  }

  public static int hashCode(Annotation paramAnnotation)
  {
    int i = 0;
    int j = 0;
    Method[] arrayOfMethod = paramAnnotation.annotationType().getDeclaredMethods();
    int k = arrayOfMethod.length;
    while (true)
    {
      if (i >= k)
        return j;
      Method localMethod = arrayOfMethod[i];
      try
      {
        localObject = localMethod.invoke(paramAnnotation, new Object[0]);
        if (localObject == null)
          throw new IllegalStateException(String.format("Annotation method %s returned null", new Object[] { localMethod }));
      }
      catch (RuntimeException localRuntimeException)
      {
        Object localObject;
        throw localRuntimeException;
        int m = hashMember(localMethod.getName(), localObject);
        j += m;
        i++;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
  }

  private static int hashMember(String paramString, Object paramObject)
  {
    int i = 127 * paramString.hashCode();
    int j;
    if (paramObject.getClass().isArray())
      j = i ^ arrayMemberHash(paramObject.getClass().getComponentType(), paramObject);
    while (true)
    {
      return j;
      if ((paramObject instanceof Annotation))
        j = i ^ hashCode((Annotation)paramObject);
      else
        j = i ^ paramObject.hashCode();
    }
  }

  public static boolean isValidAnnotationMemberType(Class<?> paramClass)
  {
    boolean bool = false;
    if (paramClass == null);
    while (true)
    {
      return bool;
      if (paramClass.isArray())
        paramClass = paramClass.getComponentType();
      if ((paramClass.isPrimitive()) || (paramClass.isEnum()) || (paramClass.isAnnotation()) || (String.class.equals(paramClass)) || (Class.class.equals(paramClass)))
        bool = true;
    }
  }

  private static boolean memberEquals(Class<?> paramClass, Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if (paramObject1 == paramObject2)
      bool = true;
    while (true)
    {
      return bool;
      if ((paramObject1 == null) || (paramObject2 == null))
        bool = false;
      else if (paramClass.isArray())
        bool = arrayMemberEquals(paramClass.getComponentType(), paramObject1, paramObject2);
      else if (paramClass.isAnnotation())
        bool = equals((Annotation)paramObject1, (Annotation)paramObject2);
      else
        bool = paramObject1.equals(paramObject2);
    }
  }

  public static String toString(Annotation paramAnnotation)
  {
    int i = 0;
    ToStringBuilder localToStringBuilder = new ToStringBuilder(paramAnnotation, TO_STRING_STYLE);
    Method[] arrayOfMethod = paramAnnotation.annotationType().getDeclaredMethods();
    int j = arrayOfMethod.length;
    if (i >= j)
      return localToStringBuilder.build();
    Method localMethod = arrayOfMethod[i];
    if (localMethod.getParameterTypes().length > 0);
    while (true)
    {
      i++;
      break;
      try
      {
        localToStringBuilder.append(localMethod.getName(), localMethod.invoke(paramAnnotation, new Object[0]));
      }
      catch (RuntimeException localRuntimeException)
      {
        throw localRuntimeException;
      }
      catch (Exception localException)
      {
        throw new RuntimeException(localException);
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.AnnotationUtils
 * JD-Core Version:    0.6.2
 */