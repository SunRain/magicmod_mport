package org.apache.commons.lang3.concurrent;

import java.util.concurrent.atomic.AtomicReference;

public abstract class AtomicSafeInitializer<T>
  implements ConcurrentInitializer<T>
{
  private final AtomicReference<AtomicSafeInitializer<T>> factory = new AtomicReference();
  private final AtomicReference<T> reference = new AtomicReference();

  public final T get()
    throws ConcurrentException
  {
    while (true)
    {
      Object localObject = this.reference.get();
      if (localObject != null)
        return localObject;
      if (this.factory.compareAndSet(null, this))
        this.reference.set(initialize());
    }
  }

  protected abstract T initialize()
    throws ConcurrentException;
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.AtomicSafeInitializer
 * JD-Core Version:    0.6.2
 */