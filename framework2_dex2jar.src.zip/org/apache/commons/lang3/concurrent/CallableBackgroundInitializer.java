package org.apache.commons.lang3.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;

public class CallableBackgroundInitializer<T> extends BackgroundInitializer<T>
{
  private final Callable<T> callable;

  public CallableBackgroundInitializer(Callable<T> paramCallable)
  {
    checkCallable(paramCallable);
    this.callable = paramCallable;
  }

  public CallableBackgroundInitializer(Callable<T> paramCallable, ExecutorService paramExecutorService)
  {
    super(paramExecutorService);
    checkCallable(paramCallable);
    this.callable = paramCallable;
  }

  private void checkCallable(Callable<T> paramCallable)
  {
    if (paramCallable == null)
      throw new IllegalArgumentException("Callable must not be null!");
  }

  protected T initialize()
    throws Exception
  {
    return this.callable.call();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.CallableBackgroundInitializer
 * JD-Core Version:    0.6.2
 */