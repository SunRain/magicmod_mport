package org.apache.commons.lang3.concurrent;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class ConcurrentUtils
{
  static Throwable checkedException(Throwable paramThrowable)
  {
    if ((paramThrowable != null) && (!(paramThrowable instanceof RuntimeException)) && (!(paramThrowable instanceof Error)))
      return paramThrowable;
    throw new IllegalArgumentException("Not a checked exception: " + paramThrowable);
  }

  public static <T> Future<T> constantFuture(T paramT)
  {
    return new ConstantFuture(paramT);
  }

  public static <K, V> V createIfAbsent(ConcurrentMap<K, V> paramConcurrentMap, K paramK, ConcurrentInitializer<V> paramConcurrentInitializer)
    throws ConcurrentException
  {
    Object localObject;
    if ((paramConcurrentMap == null) || (paramConcurrentInitializer == null))
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = paramConcurrentMap.get(paramK);
      if (localObject == null)
        localObject = putIfAbsent(paramConcurrentMap, paramK, paramConcurrentInitializer.get());
    }
  }

  public static <K, V> V createIfAbsentUnchecked(ConcurrentMap<K, V> paramConcurrentMap, K paramK, ConcurrentInitializer<V> paramConcurrentInitializer)
  {
    try
    {
      Object localObject = createIfAbsent(paramConcurrentMap, paramK, paramConcurrentInitializer);
      return localObject;
    }
    catch (ConcurrentException localConcurrentException)
    {
      throw new ConcurrentRuntimeException(localConcurrentException.getCause());
    }
  }

  public static ConcurrentException extractCause(ExecutionException paramExecutionException)
  {
    if ((paramExecutionException == null) || (paramExecutionException.getCause() == null));
    for (ConcurrentException localConcurrentException = null; ; localConcurrentException = new ConcurrentException(paramExecutionException.getMessage(), paramExecutionException.getCause()))
    {
      return localConcurrentException;
      throwCause(paramExecutionException);
    }
  }

  public static ConcurrentRuntimeException extractCauseUnchecked(ExecutionException paramExecutionException)
  {
    if ((paramExecutionException == null) || (paramExecutionException.getCause() == null));
    for (ConcurrentRuntimeException localConcurrentRuntimeException = null; ; localConcurrentRuntimeException = new ConcurrentRuntimeException(paramExecutionException.getMessage(), paramExecutionException.getCause()))
    {
      return localConcurrentRuntimeException;
      throwCause(paramExecutionException);
    }
  }

  public static void handleCause(ExecutionException paramExecutionException)
    throws ConcurrentException
  {
    ConcurrentException localConcurrentException = extractCause(paramExecutionException);
    if (localConcurrentException != null)
      throw localConcurrentException;
  }

  public static void handleCauseUnchecked(ExecutionException paramExecutionException)
  {
    ConcurrentRuntimeException localConcurrentRuntimeException = extractCauseUnchecked(paramExecutionException);
    if (localConcurrentRuntimeException != null)
      throw localConcurrentRuntimeException;
  }

  public static <T> T initialize(ConcurrentInitializer<T> paramConcurrentInitializer)
    throws ConcurrentException
  {
    if (paramConcurrentInitializer != null);
    for (Object localObject = paramConcurrentInitializer.get(); ; localObject = null)
      return localObject;
  }

  public static <T> T initializeUnchecked(ConcurrentInitializer<T> paramConcurrentInitializer)
  {
    try
    {
      Object localObject = initialize(paramConcurrentInitializer);
      return localObject;
    }
    catch (ConcurrentException localConcurrentException)
    {
      throw new ConcurrentRuntimeException(localConcurrentException.getCause());
    }
  }

  public static <K, V> V putIfAbsent(ConcurrentMap<K, V> paramConcurrentMap, K paramK, V paramV)
  {
    Object localObject;
    if (paramConcurrentMap == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = paramConcurrentMap.putIfAbsent(paramK, paramV);
      if (localObject == null)
        localObject = paramV;
    }
  }

  private static void throwCause(ExecutionException paramExecutionException)
  {
    if ((paramExecutionException.getCause() instanceof RuntimeException))
      throw ((RuntimeException)paramExecutionException.getCause());
    if ((paramExecutionException.getCause() instanceof Error))
      throw ((Error)paramExecutionException.getCause());
  }

  static final class ConstantFuture<T>
    implements Future<T>
  {
    private final T value;

    ConstantFuture(T paramT)
    {
      this.value = paramT;
    }

    public boolean cancel(boolean paramBoolean)
    {
      return false;
    }

    public T get()
    {
      return this.value;
    }

    public T get(long paramLong, TimeUnit paramTimeUnit)
    {
      return this.value;
    }

    public boolean isCancelled()
    {
      return false;
    }

    public boolean isDone()
    {
      return true;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.ConcurrentUtils
 * JD-Core Version:    0.6.2
 */