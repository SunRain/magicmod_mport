package org.apache.commons.lang3.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public abstract class BackgroundInitializer<T>
  implements ConcurrentInitializer<T>
{
  private ExecutorService executor;
  private ExecutorService externalExecutor;
  private Future<T> future;

  protected BackgroundInitializer()
  {
    this(null);
  }

  protected BackgroundInitializer(ExecutorService paramExecutorService)
  {
    setExternalExecutor(paramExecutorService);
  }

  private ExecutorService createExecutor()
  {
    return Executors.newFixedThreadPool(getTaskCount());
  }

  private Callable<T> createTask(ExecutorService paramExecutorService)
  {
    return new InitializationTask(paramExecutorService);
  }

  public T get()
    throws ConcurrentException
  {
    try
    {
      Object localObject2 = getFuture().get();
      localObject1 = localObject2;
      return localObject1;
    }
    catch (ExecutionException localExecutionException)
    {
      while (true)
      {
        ConcurrentUtils.handleCause(localExecutionException);
        Object localObject1 = null;
      }
    }
    catch (InterruptedException localInterruptedException)
    {
      Thread.currentThread().interrupt();
      throw new ConcurrentException(localInterruptedException);
    }
  }

  protected final ExecutorService getActiveExecutor()
  {
    try
    {
      ExecutorService localExecutorService = this.executor;
      return localExecutorService;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public final ExecutorService getExternalExecutor()
  {
    try
    {
      ExecutorService localExecutorService = this.externalExecutor;
      return localExecutorService;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public Future<T> getFuture()
  {
    try
    {
      if (this.future == null)
        throw new IllegalStateException("start() must be called first!");
    }
    finally
    {
    }
    Future localFuture = this.future;
    return localFuture;
  }

  protected int getTaskCount()
  {
    return 1;
  }

  protected abstract T initialize()
    throws Exception;

  public boolean isStarted()
  {
    try
    {
      Future localFuture = this.future;
      if (localFuture != null)
      {
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  public final void setExternalExecutor(ExecutorService paramExecutorService)
  {
    try
    {
      if (isStarted())
        throw new IllegalStateException("Cannot set ExecutorService after start()!");
    }
    finally
    {
    }
    this.externalExecutor = paramExecutorService;
  }

  public boolean start()
  {
    try
    {
      if (!isStarted())
      {
        this.executor = getExternalExecutor();
        ExecutorService localExecutorService;
        if (this.executor == null)
        {
          localExecutorService = createExecutor();
          this.executor = localExecutorService;
        }
        while (true)
        {
          this.future = this.executor.submit(createTask(localExecutorService));
          bool = true;
          return bool;
          localExecutorService = null;
        }
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  private class InitializationTask
    implements Callable<T>
  {
    private final ExecutorService execFinally;

    public InitializationTask(ExecutorService arg2)
    {
      Object localObject;
      this.execFinally = localObject;
    }

    public T call()
      throws Exception
    {
      try
      {
        Object localObject2 = BackgroundInitializer.this.initialize();
        return localObject2;
      }
      finally
      {
        if (this.execFinally != null)
          this.execFinally.shutdown();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.BackgroundInitializer
 * JD-Core Version:    0.6.2
 */