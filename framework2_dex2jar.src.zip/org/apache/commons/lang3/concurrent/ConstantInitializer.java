package org.apache.commons.lang3.concurrent;

import org.apache.commons.lang3.ObjectUtils;

public class ConstantInitializer<T>
  implements ConcurrentInitializer<T>
{
  private static final String FMT_TO_STRING = "ConstantInitializer@%d [ object = %s ]";
  private final T object;

  public ConstantInitializer(T paramT)
  {
    this.object = paramT;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool;
    if (this == paramObject)
      bool = true;
    while (true)
    {
      return bool;
      if (!(paramObject instanceof ConstantInitializer))
      {
        bool = false;
      }
      else
      {
        ConstantInitializer localConstantInitializer = (ConstantInitializer)paramObject;
        bool = ObjectUtils.equals(getObject(), localConstantInitializer.getObject());
      }
    }
  }

  public T get()
    throws ConcurrentException
  {
    return getObject();
  }

  public final T getObject()
  {
    return this.object;
  }

  public int hashCode()
  {
    if (getObject() != null);
    for (int i = getObject().hashCode(); ; i = 0)
      return i;
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Integer.valueOf(System.identityHashCode(this));
    arrayOfObject[1] = String.valueOf(getObject());
    return String.format("ConstantInitializer@%d [ object = %s ]", arrayOfObject);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.ConstantInitializer
 * JD-Core Version:    0.6.2
 */