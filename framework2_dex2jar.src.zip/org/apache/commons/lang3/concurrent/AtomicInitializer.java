package org.apache.commons.lang3.concurrent;

import java.util.concurrent.atomic.AtomicReference;

public abstract class AtomicInitializer<T>
  implements ConcurrentInitializer<T>
{
  private final AtomicReference<T> reference = new AtomicReference();

  public T get()
    throws ConcurrentException
  {
    Object localObject = this.reference.get();
    if (localObject == null)
    {
      localObject = initialize();
      if (!this.reference.compareAndSet(null, localObject))
        localObject = this.reference.get();
    }
    return localObject;
  }

  protected abstract T initialize()
    throws ConcurrentException;
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.AtomicInitializer
 * JD-Core Version:    0.6.2
 */