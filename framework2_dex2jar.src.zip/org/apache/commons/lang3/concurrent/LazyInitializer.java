package org.apache.commons.lang3.concurrent;

public abstract class LazyInitializer<T>
  implements ConcurrentInitializer<T>
{
  private volatile T object;

  public T get()
    throws ConcurrentException
  {
    Object localObject1 = this.object;
    if (localObject1 == null)
      try
      {
        localObject1 = this.object;
        if (localObject1 == null)
        {
          localObject1 = initialize();
          this.object = localObject1;
        }
      }
      finally
      {
        localObject2 = finally;
        throw localObject2;
      }
    return localObject1;
  }

  protected abstract T initialize()
    throws ConcurrentException;
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.LazyInitializer
 * JD-Core Version:    0.6.2
 */