package org.apache.commons.lang3.concurrent;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.ExecutorService;

public class MultiBackgroundInitializer extends BackgroundInitializer<MultiBackgroundInitializerResults>
{
  private final Map<String, BackgroundInitializer<?>> childInitializers = new HashMap();

  public MultiBackgroundInitializer()
  {
  }

  public MultiBackgroundInitializer(ExecutorService paramExecutorService)
  {
    super(paramExecutorService);
  }

  // ERROR //
  public void addInitializer(String paramString, BackgroundInitializer<?> paramBackgroundInitializer)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +13 -> 14
    //   4: new 24	java/lang/IllegalArgumentException
    //   7: dup
    //   8: ldc 26
    //   10: invokespecial 29	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   13: athrow
    //   14: aload_2
    //   15: ifnonnull +13 -> 28
    //   18: new 24	java/lang/IllegalArgumentException
    //   21: dup
    //   22: ldc 31
    //   24: invokespecial 29	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   27: athrow
    //   28: aload_0
    //   29: monitorenter
    //   30: aload_0
    //   31: invokevirtual 35	org/apache/commons/lang3/concurrent/MultiBackgroundInitializer:isStarted	()Z
    //   34: ifeq +18 -> 52
    //   37: new 37	java/lang/IllegalStateException
    //   40: dup
    //   41: ldc 39
    //   43: invokespecial 40	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   46: athrow
    //   47: astore_3
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_3
    //   51: athrow
    //   52: aload_0
    //   53: getfield 17	org/apache/commons/lang3/concurrent/MultiBackgroundInitializer:childInitializers	Ljava/util/Map;
    //   56: aload_1
    //   57: aload_2
    //   58: invokeinterface 46 3 0
    //   63: pop
    //   64: aload_0
    //   65: monitorexit
    //   66: return
    //
    // Exception table:
    //   from	to	target	type
    //   30	50	47	finally
    //   52	66	47	finally
  }

  protected int getTaskCount()
  {
    int i = 1;
    Iterator localIterator = this.childInitializers.values().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return i;
      i += ((BackgroundInitializer)localIterator.next()).getTaskCount();
    }
  }

  protected MultiBackgroundInitializerResults initialize()
    throws Exception
  {
    while (true)
    {
      ExecutorService localExecutorService;
      Iterator localIterator1;
      HashMap localHashMap2;
      HashMap localHashMap3;
      Iterator localIterator2;
      try
      {
        HashMap localHashMap1 = new HashMap(this.childInitializers);
        localExecutorService = getActiveExecutor();
        localIterator1 = localHashMap1.values().iterator();
        if (!localIterator1.hasNext())
        {
          localHashMap2 = new HashMap();
          localHashMap3 = new HashMap();
          localIterator2 = localHashMap1.entrySet().iterator();
          if (localIterator2.hasNext())
            break label139;
          return new MultiBackgroundInitializerResults(localHashMap1, localHashMap2, localHashMap3, null);
        }
      }
      finally
      {
      }
      BackgroundInitializer localBackgroundInitializer = (BackgroundInitializer)localIterator1.next();
      if (localBackgroundInitializer.getExternalExecutor() == null)
        localBackgroundInitializer.setExternalExecutor(localExecutorService);
      localBackgroundInitializer.start();
      continue;
      label139: Map.Entry localEntry = (Map.Entry)localIterator2.next();
      try
      {
        localHashMap2.put((String)localEntry.getKey(), ((BackgroundInitializer)localEntry.getValue()).get());
      }
      catch (ConcurrentException localConcurrentException)
      {
        localHashMap3.put((String)localEntry.getKey(), localConcurrentException);
      }
    }
  }

  public static class MultiBackgroundInitializerResults
  {
    private final Map<String, ConcurrentException> exceptions;
    private final Map<String, BackgroundInitializer<?>> initializers;
    private final Map<String, Object> resultObjects;

    private MultiBackgroundInitializerResults(Map<String, BackgroundInitializer<?>> paramMap, Map<String, Object> paramMap1, Map<String, ConcurrentException> paramMap2)
    {
      this.initializers = paramMap;
      this.resultObjects = paramMap1;
      this.exceptions = paramMap2;
    }

    private BackgroundInitializer<?> checkName(String paramString)
    {
      BackgroundInitializer localBackgroundInitializer = (BackgroundInitializer)this.initializers.get(paramString);
      if (localBackgroundInitializer == null)
        throw new NoSuchElementException("No child initializer with name " + paramString);
      return localBackgroundInitializer;
    }

    public ConcurrentException getException(String paramString)
    {
      checkName(paramString);
      return (ConcurrentException)this.exceptions.get(paramString);
    }

    public BackgroundInitializer<?> getInitializer(String paramString)
    {
      return checkName(paramString);
    }

    public Object getResultObject(String paramString)
    {
      checkName(paramString);
      return this.resultObjects.get(paramString);
    }

    public Set<String> initializerNames()
    {
      return Collections.unmodifiableSet(this.initializers.keySet());
    }

    public boolean isException(String paramString)
    {
      checkName(paramString);
      return this.exceptions.containsKey(paramString);
    }

    public boolean isSuccessful()
    {
      return this.exceptions.isEmpty();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.concurrent.MultiBackgroundInitializer
 * JD-Core Version:    0.6.2
 */