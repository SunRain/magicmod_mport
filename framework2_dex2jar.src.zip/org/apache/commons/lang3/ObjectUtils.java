package org.apache.commons.lang3;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import org.apache.commons.lang3.exception.CloneFailedException;
import org.apache.commons.lang3.mutable.MutableInt;

public class ObjectUtils
{
  public static final Null NULL = new Null();

  public static <T> T clone(T paramT)
  {
    Class localClass;
    Object localObject3;
    if ((paramT instanceof Cloneable))
      if (paramT.getClass().isArray())
      {
        localClass = paramT.getClass().getComponentType();
        if (!localClass.isPrimitive())
          localObject3 = ((Object[])paramT).clone();
      }
    for (Object localObject1 = localObject3; ; localObject1 = null)
      while (true)
      {
        return localObject1;
        int i = Array.getLength(paramT);
        localObject3 = Array.newInstance(localClass, i);
        int k;
        for (int j = i; ; j = k)
        {
          k = j - 1;
          if (j <= 0)
            break;
          Array.set(localObject3, k, Array.get(paramT, k));
        }
        try
        {
          Object localObject2 = paramT.getClass().getMethod("clone", new Class[0]).invoke(paramT, new Object[0]);
          localObject3 = localObject2;
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          throw new CloneFailedException("Cloneable type " + paramT.getClass().getName() + " has no clone method", localNoSuchMethodException);
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          throw new CloneFailedException("Cannot clone Cloneable type " + paramT.getClass().getName(), localIllegalAccessException);
        }
        catch (InvocationTargetException localInvocationTargetException)
        {
          throw new CloneFailedException("Exception cloning Cloneable type " + paramT.getClass().getName(), localInvocationTargetException.getCause());
        }
      }
  }

  public static <T> T cloneIfPossible(T paramT)
  {
    Object localObject = clone(paramT);
    if (localObject == null);
    while (true)
    {
      return paramT;
      paramT = localObject;
    }
  }

  public static <T extends Comparable<? super T>> int compare(T paramT1, T paramT2)
  {
    return compare(paramT1, paramT2, false);
  }

  public static <T extends Comparable<? super T>> int compare(T paramT1, T paramT2, boolean paramBoolean)
  {
    int i = 1;
    int j = -1;
    if (paramT1 == paramT2)
      i = 0;
    while (true)
    {
      return i;
      if (paramT1 == null)
      {
        if (!paramBoolean)
          i = j;
      }
      else
      {
        if (paramT2 == null)
        {
          if (paramBoolean);
          while (true)
          {
            i = j;
            break;
            j = i;
          }
        }
        i = paramT1.compareTo(paramT2);
      }
    }
  }

  public static <T> T defaultIfNull(T paramT1, T paramT2)
  {
    if (paramT1 != null);
    while (true)
    {
      return paramT1;
      paramT1 = paramT2;
    }
  }

  public static boolean equals(Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if (paramObject1 == paramObject2)
      bool = true;
    while (true)
    {
      return bool;
      if ((paramObject1 == null) || (paramObject2 == null))
        bool = false;
      else
        bool = paramObject1.equals(paramObject2);
    }
  }

  public static <T> T firstNonNull(T[] paramArrayOfT)
  {
    int i;
    if (paramArrayOfT != null)
      i = paramArrayOfT.length;
    for (int j = 0; ; j++)
    {
      T ?;
      if (j >= i)
        ? = null;
      do
      {
        return ?;
        ? = paramArrayOfT[j];
      }
      while (? != null);
    }
  }

  public static int hashCode(Object paramObject)
  {
    if (paramObject == null);
    for (int i = 0; ; i = paramObject.hashCode())
      return i;
  }

  public static int hashCodeMulti(Object[] paramArrayOfObject)
  {
    int i = 1;
    int j;
    if (paramArrayOfObject != null)
      j = paramArrayOfObject.length;
    for (int k = 0; ; k++)
    {
      if (k >= j)
        return i;
      Object localObject = paramArrayOfObject[k];
      i = i * 31 + hashCode(localObject);
    }
  }

  public static String identityToString(Object paramObject)
  {
    if (paramObject == null);
    StringBuffer localStringBuffer;
    for (String str = null; ; str = localStringBuffer.toString())
    {
      return str;
      localStringBuffer = new StringBuffer();
      identityToString(localStringBuffer, paramObject);
    }
  }

  public static void identityToString(StringBuffer paramStringBuffer, Object paramObject)
  {
    if (paramObject == null)
      throw new NullPointerException("Cannot get the toString of a null identity");
    paramStringBuffer.append(paramObject.getClass().getName()).append('@').append(Integer.toHexString(System.identityHashCode(paramObject)));
  }

  public static <T extends Comparable<? super T>> T max(T[] paramArrayOfT)
  {
    Object localObject = null;
    int i;
    if (paramArrayOfT != null)
      i = paramArrayOfT.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localObject;
      T ? = paramArrayOfT[j];
      if (compare(?, (Comparable)localObject, false) > 0)
        localObject = ?;
    }
  }

  public static <T extends Comparable<? super T>> T median(T[] paramArrayOfT)
  {
    Validate.notEmpty(paramArrayOfT);
    Validate.noNullElements(paramArrayOfT);
    TreeSet localTreeSet = new TreeSet();
    Collections.addAll(localTreeSet, paramArrayOfT);
    return (Comparable)localTreeSet.toArray()[((-1 + localTreeSet.size()) / 2)];
  }

  public static <T> T median(Comparator<T> paramComparator, T[] paramArrayOfT)
  {
    Validate.notEmpty(paramArrayOfT, "null/empty items", new Object[0]);
    Validate.noNullElements(paramArrayOfT);
    Validate.notNull(paramComparator, "null comparator", new Object[0]);
    TreeSet localTreeSet = new TreeSet(paramComparator);
    Collections.addAll(localTreeSet, paramArrayOfT);
    return localTreeSet.toArray()[((-1 + localTreeSet.size()) / 2)];
  }

  public static <T extends Comparable<? super T>> T min(T[] paramArrayOfT)
  {
    Object localObject = null;
    int i;
    if (paramArrayOfT != null)
      i = paramArrayOfT.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localObject;
      T ? = paramArrayOfT[j];
      if (compare(?, (Comparable)localObject, true) < 0)
        localObject = ?;
    }
  }

  public static <T> T mode(T[] paramArrayOfT)
  {
    HashMap localHashMap;
    int j;
    Object localObject;
    int k;
    Iterator localIterator;
    if (ArrayUtils.isNotEmpty(paramArrayOfT))
    {
      localHashMap = new HashMap(paramArrayOfT.length);
      int i = paramArrayOfT.length;
      j = 0;
      if (j >= i)
      {
        localObject = null;
        k = 0;
        localIterator = localHashMap.entrySet().iterator();
        label44: if (localIterator.hasNext())
          break label107;
      }
    }
    while (true)
    {
      return localObject;
      T ? = paramArrayOfT[j];
      MutableInt localMutableInt = (MutableInt)localHashMap.get(?);
      if (localMutableInt == null)
        localHashMap.put(?, new MutableInt(1));
      while (true)
      {
        j++;
        break;
        localMutableInt.increment();
      }
      label107: Map.Entry localEntry = (Map.Entry)localIterator.next();
      int m = ((MutableInt)localEntry.getValue()).intValue();
      if (m == k)
      {
        localObject = null;
        break label44;
      }
      if (m <= k)
        break label44;
      k = m;
      localObject = localEntry.getKey();
      break label44;
      localObject = null;
    }
  }

  public static boolean notEqual(Object paramObject1, Object paramObject2)
  {
    if (equals(paramObject1, paramObject2));
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  public static String toString(Object paramObject)
  {
    if (paramObject == null);
    for (String str = ""; ; str = paramObject.toString())
      return str;
  }

  public static String toString(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = paramObject.toString();
    }
  }

  public static class Null
    implements Serializable
  {
    private static final long serialVersionUID = 7092611880189329093L;

    private Object readResolve()
    {
      return ObjectUtils.NULL;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.ObjectUtils
 * JD-Core Version:    0.6.2
 */