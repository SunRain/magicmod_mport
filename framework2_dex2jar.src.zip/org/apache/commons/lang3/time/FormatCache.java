package org.apache.commons.lang3.time;

import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

abstract class FormatCache<F extends Format>
{
  static final int NONE = -1;
  private final ConcurrentMap<MultipartKey, String> cDateTimeInstanceCache = new ConcurrentHashMap(7);
  private final ConcurrentMap<MultipartKey, F> cInstanceCache = new ConcurrentHashMap(7);

  protected abstract F createInstance(String paramString, TimeZone paramTimeZone, Locale paramLocale);

  public F getDateTimeInstance(Integer paramInteger1, Integer paramInteger2, TimeZone paramTimeZone, Locale paramLocale)
  {
    if (paramLocale == null)
      paramLocale = Locale.getDefault();
    MultipartKey localMultipartKey = new MultipartKey(new Object[] { paramInteger1, paramInteger2, paramLocale });
    Object localObject1 = (String)this.cDateTimeInstanceCache.get(localMultipartKey);
    if ((localObject1 != null) || (paramInteger1 == null));
    try
    {
      Object localObject2 = DateFormat.getTimeInstance(paramInteger2.intValue(), paramLocale);
      while (true)
      {
        localObject1 = ((SimpleDateFormat)localObject2).toPattern();
        String str = (String)this.cDateTimeInstanceCache.putIfAbsent(localMultipartKey, localObject1);
        if (str != null)
          localObject1 = str;
        return getInstance((String)localObject1, paramTimeZone, paramLocale);
        if (paramInteger2 == null)
        {
          localObject2 = DateFormat.getDateInstance(paramInteger1.intValue(), paramLocale);
        }
        else
        {
          DateFormat localDateFormat = DateFormat.getDateTimeInstance(paramInteger1.intValue(), paramInteger2.intValue(), paramLocale);
          localObject2 = localDateFormat;
        }
      }
    }
    catch (ClassCastException localClassCastException)
    {
    }
    throw new IllegalArgumentException("No date time pattern for locale: " + paramLocale);
  }

  public F getInstance()
  {
    return getDateTimeInstance(Integer.valueOf(3), Integer.valueOf(3), TimeZone.getDefault(), Locale.getDefault());
  }

  public F getInstance(String paramString, TimeZone paramTimeZone, Locale paramLocale)
  {
    if (paramString == null)
      throw new NullPointerException("pattern must not be null");
    if (paramTimeZone == null)
      paramTimeZone = TimeZone.getDefault();
    if (paramLocale == null)
      paramLocale = Locale.getDefault();
    MultipartKey localMultipartKey = new MultipartKey(new Object[] { paramString, paramTimeZone, paramLocale });
    Object localObject = (Format)this.cInstanceCache.get(localMultipartKey);
    if (localObject == null)
    {
      localObject = createInstance(paramString, paramTimeZone, paramLocale);
      Format localFormat = (Format)this.cInstanceCache.putIfAbsent(localMultipartKey, localObject);
      if (localFormat != null)
        localObject = localFormat;
    }
    return localObject;
  }

  private static class MultipartKey
  {
    private int hashCode;
    private final Object[] keys;

    public MultipartKey(Object[] paramArrayOfObject)
    {
      this.keys = paramArrayOfObject;
    }

    public boolean equals(Object paramObject)
    {
      boolean bool;
      if (this == paramObject)
        bool = true;
      while (true)
      {
        return bool;
        if (!(paramObject instanceof MultipartKey))
          bool = false;
        else
          bool = Arrays.equals(this.keys, ((MultipartKey)paramObject).keys);
      }
    }

    public int hashCode()
    {
      int i;
      Object[] arrayOfObject;
      int j;
      if (this.hashCode == 0)
      {
        i = 0;
        arrayOfObject = this.keys;
        j = arrayOfObject.length;
      }
      for (int k = 0; ; k++)
      {
        if (k >= j)
        {
          this.hashCode = i;
          return this.hashCode;
        }
        Object localObject = arrayOfObject[k];
        if (localObject != null)
          i = i * 7 + localObject.hashCode();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.time.FormatCache
 * JD-Core Version:    0.6.2
 */