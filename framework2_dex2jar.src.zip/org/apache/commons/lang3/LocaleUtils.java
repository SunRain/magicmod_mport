package org.apache.commons.lang3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class LocaleUtils
{
  private static final ConcurrentMap<String, List<Locale>> cCountriesByLanguage = new ConcurrentHashMap();
  private static final ConcurrentMap<String, List<Locale>> cLanguagesByCountry = new ConcurrentHashMap();

  public static List<Locale> availableLocaleList()
  {
    return SyncAvoid.AVAILABLE_LOCALE_LIST;
  }

  public static Set<Locale> availableLocaleSet()
  {
    return SyncAvoid.AVAILABLE_LOCALE_SET;
  }

  public static List<Locale> countriesByLanguage(String paramString)
  {
    List localList1;
    if (paramString == null)
      localList1 = Collections.emptyList();
    do
    {
      return localList1;
      localList1 = (List)cCountriesByLanguage.get(paramString);
    }
    while (localList1 != null);
    ArrayList localArrayList = new ArrayList();
    List localList2 = availableLocaleList();
    for (int i = 0; ; i++)
    {
      if (i >= localList2.size())
      {
        List localList3 = Collections.unmodifiableList(localArrayList);
        cCountriesByLanguage.putIfAbsent(paramString, localList3);
        localList1 = (List)cCountriesByLanguage.get(paramString);
        break;
      }
      Locale localLocale = (Locale)localList2.get(i);
      if ((paramString.equals(localLocale.getLanguage())) && (localLocale.getCountry().length() != 0) && (localLocale.getVariant().length() == 0))
        localArrayList.add(localLocale);
    }
  }

  public static boolean isAvailableLocale(Locale paramLocale)
  {
    return availableLocaleList().contains(paramLocale);
  }

  public static List<Locale> languagesByCountry(String paramString)
  {
    List localList1;
    if (paramString == null)
      localList1 = Collections.emptyList();
    do
    {
      return localList1;
      localList1 = (List)cLanguagesByCountry.get(paramString);
    }
    while (localList1 != null);
    ArrayList localArrayList = new ArrayList();
    List localList2 = availableLocaleList();
    for (int i = 0; ; i++)
    {
      if (i >= localList2.size())
      {
        List localList3 = Collections.unmodifiableList(localArrayList);
        cLanguagesByCountry.putIfAbsent(paramString, localList3);
        localList1 = (List)cLanguagesByCountry.get(paramString);
        break;
      }
      Locale localLocale = (Locale)localList2.get(i);
      if ((paramString.equals(localLocale.getCountry())) && (localLocale.getVariant().length() == 0))
        localArrayList.add(localLocale);
    }
  }

  public static List<Locale> localeLookupList(Locale paramLocale)
  {
    return localeLookupList(paramLocale, paramLocale);
  }

  public static List<Locale> localeLookupList(Locale paramLocale1, Locale paramLocale2)
  {
    ArrayList localArrayList = new ArrayList(4);
    if (paramLocale1 != null)
    {
      localArrayList.add(paramLocale1);
      if (paramLocale1.getVariant().length() > 0)
        localArrayList.add(new Locale(paramLocale1.getLanguage(), paramLocale1.getCountry()));
      if (paramLocale1.getCountry().length() > 0)
        localArrayList.add(new Locale(paramLocale1.getLanguage(), ""));
      if (!localArrayList.contains(paramLocale2))
        localArrayList.add(paramLocale2);
    }
    return Collections.unmodifiableList(localArrayList);
  }

  public static Locale toLocale(String paramString)
  {
    Locale localLocale;
    if (paramString == null)
      localLocale = null;
    while (true)
    {
      return localLocale;
      int i = paramString.length();
      if ((i != 2) && (i != 5) && (i < 7))
        throw new IllegalArgumentException("Invalid locale format: " + paramString);
      int j = paramString.charAt(0);
      int k = paramString.charAt(1);
      if ((j < 97) || (j > 122) || (k < 97) || (k > 122))
        throw new IllegalArgumentException("Invalid locale format: " + paramString);
      if (i == 2)
      {
        localLocale = new Locale(paramString, "");
      }
      else
      {
        if (paramString.charAt(2) != '_')
          throw new IllegalArgumentException("Invalid locale format: " + paramString);
        int m = paramString.charAt(3);
        if (m == 95)
        {
          localLocale = new Locale(paramString.substring(0, 2), "", paramString.substring(4));
        }
        else
        {
          int n = paramString.charAt(4);
          if ((m < 65) || (m > 90) || (n < 65) || (n > 90))
            throw new IllegalArgumentException("Invalid locale format: " + paramString);
          if (i == 5)
          {
            localLocale = new Locale(paramString.substring(0, 2), paramString.substring(3, 5));
          }
          else
          {
            if (paramString.charAt(5) != '_')
              throw new IllegalArgumentException("Invalid locale format: " + paramString);
            localLocale = new Locale(paramString.substring(0, 2), paramString.substring(3, 5), paramString.substring(6));
          }
        }
      }
    }
  }

  static class SyncAvoid
  {
    private static List<Locale> AVAILABLE_LOCALE_LIST = Collections.unmodifiableList(new ArrayList(Arrays.asList(Locale.getAvailableLocales())));
    private static Set<Locale> AVAILABLE_LOCALE_SET = Collections.unmodifiableSet(new HashSet(LocaleUtils.availableLocaleList()));
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.LocaleUtils
 * JD-Core Version:    0.6.2
 */