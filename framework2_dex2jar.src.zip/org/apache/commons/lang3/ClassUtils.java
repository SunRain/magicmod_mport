package org.apache.commons.lang3;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ClassUtils
{
  public static final String INNER_CLASS_SEPARATOR;
  public static final char INNER_CLASS_SEPARATOR_CHAR = '$';
  public static final String PACKAGE_SEPARATOR = String.valueOf('.');
  public static final char PACKAGE_SEPARATOR_CHAR = '.';
  private static final Map<String, String> abbreviationMap;
  private static final Map<Class<?>, Class<?>> primitiveWrapperMap;
  private static final Map<String, String> reverseAbbreviationMap;
  private static final Map<Class<?>, Class<?>> wrapperPrimitiveMap;

  static
  {
    INNER_CLASS_SEPARATOR = String.valueOf('$');
    primitiveWrapperMap = new HashMap();
    primitiveWrapperMap.put(Boolean.TYPE, Boolean.class);
    primitiveWrapperMap.put(Byte.TYPE, Byte.class);
    primitiveWrapperMap.put(Character.TYPE, Character.class);
    primitiveWrapperMap.put(Short.TYPE, Short.class);
    primitiveWrapperMap.put(Integer.TYPE, Integer.class);
    primitiveWrapperMap.put(Long.TYPE, Long.class);
    primitiveWrapperMap.put(Double.TYPE, Double.class);
    primitiveWrapperMap.put(Float.TYPE, Float.class);
    primitiveWrapperMap.put(Void.TYPE, Void.TYPE);
    wrapperPrimitiveMap = new HashMap();
    Iterator localIterator = primitiveWrapperMap.keySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        abbreviationMap = new HashMap();
        reverseAbbreviationMap = new HashMap();
        addAbbreviation("int", "I");
        addAbbreviation("boolean", "Z");
        addAbbreviation("float", "F");
        addAbbreviation("long", "J");
        addAbbreviation("short", "S");
        addAbbreviation("byte", "B");
        addAbbreviation("double", "D");
        addAbbreviation("char", "C");
        return;
      }
      Class localClass1 = (Class)localIterator.next();
      Class localClass2 = (Class)primitiveWrapperMap.get(localClass1);
      if (!localClass1.equals(localClass2))
        wrapperPrimitiveMap.put(localClass2, localClass1);
    }
  }

  private static void addAbbreviation(String paramString1, String paramString2)
  {
    abbreviationMap.put(paramString1, paramString2);
    reverseAbbreviationMap.put(paramString2, paramString1);
  }

  public static List<Class<?>> convertClassNamesToClasses(List<String> paramList)
  {
    Object localObject;
    if (paramList == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new ArrayList(paramList.size());
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        try
        {
          ((List)localObject).add(Class.forName(str));
        }
        catch (Exception localException)
        {
          ((List)localObject).add(null);
        }
      }
    }
  }

  public static List<String> convertClassesToClassNames(List<Class<?>> paramList)
  {
    Object localObject;
    if (paramList == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new ArrayList(paramList.size());
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        Class localClass = (Class)localIterator.next();
        if (localClass == null)
          ((List)localObject).add(null);
        else
          ((List)localObject).add(localClass.getName());
      }
    }
  }

  public static List<Class<?>> getAllInterfaces(Class<?> paramClass)
  {
    if (paramClass == null);
    LinkedHashSet localLinkedHashSet;
    for (Object localObject = null; ; localObject = new ArrayList(localLinkedHashSet))
    {
      return localObject;
      localLinkedHashSet = new LinkedHashSet();
      getAllInterfaces(paramClass, localLinkedHashSet);
    }
  }

  private static void getAllInterfaces(Class<?> paramClass, HashSet<Class<?>> paramHashSet)
  {
    if (paramClass == null)
      return;
    Class[] arrayOfClass = paramClass.getInterfaces();
    int i = arrayOfClass.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        paramClass = paramClass.getSuperclass();
        break;
      }
      Class localClass = arrayOfClass[j];
      if (paramHashSet.add(localClass))
        getAllInterfaces(localClass, paramHashSet);
    }
  }

  public static List<Class<?>> getAllSuperclasses(Class<?> paramClass)
  {
    Object localObject;
    if (paramClass == null)
      localObject = null;
    while (true)
    {
      return localObject;
      localObject = new ArrayList();
      for (Class localClass = paramClass.getSuperclass(); localClass != null; localClass = localClass.getSuperclass())
        ((List)localObject).add(localClass);
    }
  }

  private static String getCanonicalName(String paramString)
  {
    String str = StringUtils.deleteWhitespace(paramString);
    if (str == null)
      str = null;
    int i;
    label15: 
    do
    {
      return str;
      i = 0;
      if (str.startsWith("["))
        break;
    }
    while (i < 1);
    int k;
    label55: label63: StringBuilder localStringBuilder;
    if (str.startsWith("L"))
      if (str.endsWith(";"))
      {
        k = -1 + str.length();
        str = str.substring(1, k);
        localStringBuilder = new StringBuilder(str);
      }
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        str = localStringBuilder.toString();
        break;
        i++;
        str = str.substring(1);
        break label15;
        k = str.length();
        break label55;
        if (str.length() <= 0)
          break label63;
        str = (String)reverseAbbreviationMap.get(str.substring(0, 1));
        break label63;
      }
      localStringBuilder.append("[]");
    }
  }

  public static Class<?> getClass(ClassLoader paramClassLoader, String paramString)
    throws ClassNotFoundException
  {
    return getClass(paramClassLoader, paramString, true);
  }

  public static Class<?> getClass(ClassLoader paramClassLoader, String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    Object localObject;
    try
    {
      if (abbreviationMap.containsKey(paramString))
      {
        localObject = Class.forName("[" + (String)abbreviationMap.get(paramString), paramBoolean, paramClassLoader).getComponentType();
      }
      else
      {
        Class localClass2 = Class.forName(toCanonicalName(paramString), paramBoolean, paramClassLoader);
        localObject = localClass2;
      }
    }
    catch (ClassNotFoundException localClassNotFoundException1)
    {
      int i = paramString.lastIndexOf('.');
      if (i != -1)
        try
        {
          Class localClass1 = getClass(paramClassLoader, paramString.substring(0, i) + '$' + paramString.substring(i + 1), paramBoolean);
          localObject = localClass1;
        }
        catch (ClassNotFoundException localClassNotFoundException2)
        {
        }
      else
        throw localClassNotFoundException1;
    }
    return localObject;
  }

  public static Class<?> getClass(String paramString)
    throws ClassNotFoundException
  {
    return getClass(paramString, true);
  }

  public static Class<?> getClass(String paramString, boolean paramBoolean)
    throws ClassNotFoundException
  {
    ClassLoader localClassLoader1 = Thread.currentThread().getContextClassLoader();
    if (localClassLoader1 == null);
    for (ClassLoader localClassLoader2 = ClassUtils.class.getClassLoader(); ; localClassLoader2 = localClassLoader1)
      return getClass(localClassLoader2, paramString, paramBoolean);
  }

  public static String getPackageCanonicalName(Class<?> paramClass)
  {
    if (paramClass == null);
    for (String str = ""; ; str = getPackageCanonicalName(paramClass.getName()))
      return str;
  }

  public static String getPackageCanonicalName(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = getPackageCanonicalName(paramObject.getClass().getName());
    }
  }

  public static String getPackageCanonicalName(String paramString)
  {
    return getPackageName(getCanonicalName(paramString));
  }

  public static String getPackageName(Class<?> paramClass)
  {
    if (paramClass == null);
    for (String str = ""; ; str = getPackageName(paramClass.getName()))
      return str;
  }

  public static String getPackageName(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = getPackageName(paramObject.getClass());
    }
  }

  public static String getPackageName(String paramString)
  {
    String str;
    if ((paramString == null) || (paramString.length() == 0))
      str = "";
    while (true)
    {
      return str;
      do
        paramString = paramString.substring(1);
      while (paramString.charAt(0) == '[');
      if ((paramString.charAt(0) == 'L') && (paramString.charAt(-1 + paramString.length()) == ';'))
        paramString = paramString.substring(1);
      int i = paramString.lastIndexOf('.');
      if (i == -1)
        str = "";
      else
        str = paramString.substring(0, i);
    }
  }

  public static Method getPublicMethod(Class<?> paramClass, String paramString, Class<?>[] paramArrayOfClass)
    throws SecurityException, NoSuchMethodException
  {
    Object localObject = paramClass.getMethod(paramString, paramArrayOfClass);
    if (Modifier.isPublic(((Method)localObject).getDeclaringClass().getModifiers()))
      return localObject;
    ArrayList localArrayList = new ArrayList();
    localArrayList.addAll(getAllInterfaces(paramClass));
    localArrayList.addAll(getAllSuperclasses(paramClass));
    Iterator localIterator = localArrayList.iterator();
    while (true)
      while (true)
      {
        if (!localIterator.hasNext())
          throw new NoSuchMethodException("Can't find a public method for " + paramString + " " + ArrayUtils.toString(paramArrayOfClass));
        Class localClass = (Class)localIterator.next();
        if (Modifier.isPublic(localClass.getModifiers()))
          try
          {
            Method localMethod = localClass.getMethod(paramString, paramArrayOfClass);
            if (Modifier.isPublic(localMethod.getDeclaringClass().getModifiers()))
              localObject = localMethod;
          }
          catch (NoSuchMethodException localNoSuchMethodException)
          {
          }
      }
  }

  public static String getShortCanonicalName(Class<?> paramClass)
  {
    if (paramClass == null);
    for (String str = ""; ; str = getShortCanonicalName(paramClass.getName()))
      return str;
  }

  public static String getShortCanonicalName(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = getShortCanonicalName(paramObject.getClass().getName());
    }
  }

  public static String getShortCanonicalName(String paramString)
  {
    return getShortClassName(getCanonicalName(paramString));
  }

  public static String getShortClassName(Class<?> paramClass)
  {
    if (paramClass == null);
    for (String str = ""; ; str = getShortClassName(paramClass.getName()))
      return str;
  }

  public static String getShortClassName(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = getShortClassName(paramObject.getClass());
    }
  }

  public static String getShortClassName(String paramString)
  {
    int i = 0;
    if (paramString == null);
    for (String str2 = ""; ; str2 = "")
    {
      return str2;
      if (paramString.length() != 0)
        break;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    if (paramString.startsWith("["))
    {
      label46: if (paramString.charAt(0) == '[')
        break label189;
      if ((paramString.charAt(0) == 'L') && (paramString.charAt(-1 + paramString.length()) == ';'))
        paramString = paramString.substring(1, -1 + paramString.length());
    }
    if (reverseAbbreviationMap.containsKey(paramString))
      paramString = (String)reverseAbbreviationMap.get(paramString);
    int j = paramString.lastIndexOf('.');
    if (j == -1);
    while (true)
    {
      int k = paramString.indexOf('$', i);
      String str1 = paramString.substring(j + 1);
      if (k != -1)
        str1 = str1.replace('$', '.');
      str2 = str1 + localStringBuilder;
      break;
      label189: paramString = paramString.substring(1);
      localStringBuilder.append("[]");
      break label46;
      i = j + 1;
    }
  }

  public static String getSimpleName(Class<?> paramClass)
  {
    if (paramClass == null);
    for (String str = ""; ; str = paramClass.getSimpleName())
      return str;
  }

  public static String getSimpleName(Object paramObject, String paramString)
  {
    if (paramObject == null);
    while (true)
    {
      return paramString;
      paramString = getSimpleName(paramObject.getClass());
    }
  }

  public static boolean isAssignable(Class<?> paramClass1, Class<?> paramClass2)
  {
    return isAssignable(paramClass1, paramClass2, SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_1_5));
  }

  public static boolean isAssignable(Class<?> paramClass1, Class<?> paramClass2, boolean paramBoolean)
  {
    boolean bool = false;
    if (paramClass2 == null);
    while (true)
    {
      return bool;
      if (paramClass1 == null)
      {
        if (!paramClass2.isPrimitive())
          bool = true;
      }
      else if (paramBoolean)
      {
        if ((paramClass1.isPrimitive()) && (!paramClass2.isPrimitive()))
        {
          paramClass1 = primitiveToWrapper(paramClass1);
          if (paramClass1 == null);
        }
        else if ((paramClass2.isPrimitive()) && (!paramClass1.isPrimitive()))
        {
          paramClass1 = wrapperToPrimitive(paramClass1);
          if (paramClass1 == null)
            continue;
        }
      }
      else if (paramClass1.equals(paramClass2))
        bool = true;
      else if (paramClass1.isPrimitive())
      {
        if (paramClass2.isPrimitive())
          if (Integer.TYPE.equals(paramClass1))
          {
            if ((Long.TYPE.equals(paramClass2)) || (Float.TYPE.equals(paramClass2)) || (Double.TYPE.equals(paramClass2)))
              bool = true;
          }
          else if (Long.TYPE.equals(paramClass1))
          {
            if ((Float.TYPE.equals(paramClass2)) || (Double.TYPE.equals(paramClass2)))
              bool = true;
          }
          else if ((!Boolean.TYPE.equals(paramClass1)) && (!Double.TYPE.equals(paramClass1)))
            if (Float.TYPE.equals(paramClass1))
              bool = Double.TYPE.equals(paramClass2);
            else if (Character.TYPE.equals(paramClass1))
            {
              if ((Integer.TYPE.equals(paramClass2)) || (Long.TYPE.equals(paramClass2)) || (Float.TYPE.equals(paramClass2)) || (Double.TYPE.equals(paramClass2)))
                bool = true;
            }
            else if (Short.TYPE.equals(paramClass1))
            {
              if ((Integer.TYPE.equals(paramClass2)) || (Long.TYPE.equals(paramClass2)) || (Float.TYPE.equals(paramClass2)) || (Double.TYPE.equals(paramClass2)))
                bool = true;
            }
            else if ((Byte.TYPE.equals(paramClass1)) && ((Short.TYPE.equals(paramClass2)) || (Integer.TYPE.equals(paramClass2)) || (Long.TYPE.equals(paramClass2)) || (Float.TYPE.equals(paramClass2)) || (Double.TYPE.equals(paramClass2))))
              bool = true;
      }
      else
        bool = paramClass2.isAssignableFrom(paramClass1);
    }
  }

  public static boolean isAssignable(Class<?>[] paramArrayOfClass1, Class<?>[] paramArrayOfClass2)
  {
    return isAssignable(paramArrayOfClass1, paramArrayOfClass2, SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_1_5));
  }

  public static boolean isAssignable(Class<?>[] paramArrayOfClass1, Class<?>[] paramArrayOfClass2, boolean paramBoolean)
  {
    boolean bool = false;
    if (!ArrayUtils.isSameLength(paramArrayOfClass1, paramArrayOfClass2))
      return bool;
    if (paramArrayOfClass1 == null)
      paramArrayOfClass1 = ArrayUtils.EMPTY_CLASS_ARRAY;
    if (paramArrayOfClass2 == null)
      paramArrayOfClass2 = ArrayUtils.EMPTY_CLASS_ARRAY;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfClass1.length)
      {
        bool = true;
        break;
      }
      if (!isAssignable(paramArrayOfClass1[i], paramArrayOfClass2[i], paramBoolean))
        break;
    }
  }

  public static boolean isInnerClass(Class<?> paramClass)
  {
    if ((paramClass != null) && (paramClass.getEnclosingClass() != null));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean isPrimitiveOrWrapper(Class<?> paramClass)
  {
    boolean bool = false;
    if (paramClass == null);
    while (true)
    {
      return bool;
      if ((paramClass.isPrimitive()) || (isPrimitiveWrapper(paramClass)))
        bool = true;
    }
  }

  public static boolean isPrimitiveWrapper(Class<?> paramClass)
  {
    return wrapperPrimitiveMap.containsKey(paramClass);
  }

  public static Class<?> primitiveToWrapper(Class<?> paramClass)
  {
    Object localObject = paramClass;
    if ((paramClass != null) && (paramClass.isPrimitive()))
      localObject = (Class)primitiveWrapperMap.get(paramClass);
    return localObject;
  }

  public static Class<?>[] primitivesToWrappers(Class<?>[] paramArrayOfClass)
  {
    if (paramArrayOfClass == null)
      paramArrayOfClass = null;
    while (paramArrayOfClass.length == 0)
      return paramArrayOfClass;
    Class[] arrayOfClass = new Class[paramArrayOfClass.length];
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfClass.length)
      {
        paramArrayOfClass = arrayOfClass;
        break;
      }
      arrayOfClass[i] = primitiveToWrapper(paramArrayOfClass[i]);
    }
  }

  private static String toCanonicalName(String paramString)
  {
    String str1 = StringUtils.deleteWhitespace(paramString);
    if (str1 == null)
      throw new NullPointerException("className must not be null.");
    StringBuilder localStringBuilder;
    if (str1.endsWith("[]"))
    {
      localStringBuilder = new StringBuilder();
      if (str1.endsWith("[]"))
        break label79;
      String str2 = (String)abbreviationMap.get(str1);
      if (str2 == null)
        break label102;
      localStringBuilder.append(str2);
    }
    while (true)
    {
      str1 = localStringBuilder.toString();
      return str1;
      label79: str1 = str1.substring(0, -2 + str1.length());
      localStringBuilder.append("[");
      break;
      label102: localStringBuilder.append("L").append(str1).append(";");
    }
  }

  public static Class<?>[] toClass(Object[] paramArrayOfObject)
  {
    Object localObject = null;
    if (paramArrayOfObject == null);
    Class[] arrayOfClass;
    int i;
    while (true)
    {
      return localObject;
      if (paramArrayOfObject.length == 0)
      {
        localObject = ArrayUtils.EMPTY_CLASS_ARRAY;
      }
      else
      {
        arrayOfClass = new Class[paramArrayOfObject.length];
        i = 0;
        if (i < paramArrayOfObject.length)
          break;
        localObject = arrayOfClass;
      }
    }
    if (paramArrayOfObject[i] == null);
    for (Class localClass = null; ; localClass = paramArrayOfObject[i].getClass())
    {
      arrayOfClass[i] = localClass;
      i++;
      break;
    }
  }

  public static Class<?> wrapperToPrimitive(Class<?> paramClass)
  {
    return (Class)wrapperPrimitiveMap.get(paramClass);
  }

  public static Class<?>[] wrappersToPrimitives(Class<?>[] paramArrayOfClass)
  {
    if (paramArrayOfClass == null)
      paramArrayOfClass = null;
    while (paramArrayOfClass.length == 0)
      return paramArrayOfClass;
    Class[] arrayOfClass = new Class[paramArrayOfClass.length];
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfClass.length)
      {
        paramArrayOfClass = arrayOfClass;
        break;
      }
      arrayOfClass[i] = wrapperToPrimitive(paramArrayOfClass[i]);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.ClassUtils
 * JD-Core Version:    0.6.2
 */