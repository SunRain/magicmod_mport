package org.apache.commons.lang3.math;

public class IEEE754rUtils
{
  public static double max(double paramDouble1, double paramDouble2)
  {
    if (Double.isNaN(paramDouble1));
    while (true)
    {
      return paramDouble2;
      if (Double.isNaN(paramDouble2))
        paramDouble2 = paramDouble1;
      else
        paramDouble2 = Math.max(paramDouble1, paramDouble2);
    }
  }

  public static double max(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return max(max(paramDouble1, paramDouble2), paramDouble3);
  }

  public static double max(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfDouble.length == 0)
      throw new IllegalArgumentException("Array cannot be empty.");
    double d = paramArrayOfDouble[0];
    for (int i = 1; ; i++)
    {
      if (i >= paramArrayOfDouble.length)
        return d;
      d = max(paramArrayOfDouble[i], d);
    }
  }

  public static float max(float paramFloat1, float paramFloat2)
  {
    if (Float.isNaN(paramFloat1));
    while (true)
    {
      return paramFloat2;
      if (Float.isNaN(paramFloat2))
        paramFloat2 = paramFloat1;
      else
        paramFloat2 = Math.max(paramFloat1, paramFloat2);
    }
  }

  public static float max(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return max(max(paramFloat1, paramFloat2), paramFloat3);
  }

  public static float max(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfFloat.length == 0)
      throw new IllegalArgumentException("Array cannot be empty.");
    float f = paramArrayOfFloat[0];
    for (int i = 1; ; i++)
    {
      if (i >= paramArrayOfFloat.length)
        return f;
      f = max(paramArrayOfFloat[i], f);
    }
  }

  public static double min(double paramDouble1, double paramDouble2)
  {
    if (Double.isNaN(paramDouble1));
    while (true)
    {
      return paramDouble2;
      if (Double.isNaN(paramDouble2))
        paramDouble2 = paramDouble1;
      else
        paramDouble2 = Math.min(paramDouble1, paramDouble2);
    }
  }

  public static double min(double paramDouble1, double paramDouble2, double paramDouble3)
  {
    return min(min(paramDouble1, paramDouble2), paramDouble3);
  }

  public static double min(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfDouble.length == 0)
      throw new IllegalArgumentException("Array cannot be empty.");
    double d = paramArrayOfDouble[0];
    for (int i = 1; ; i++)
    {
      if (i >= paramArrayOfDouble.length)
        return d;
      d = min(paramArrayOfDouble[i], d);
    }
  }

  public static float min(float paramFloat1, float paramFloat2)
  {
    if (Float.isNaN(paramFloat1));
    while (true)
    {
      return paramFloat2;
      if (Float.isNaN(paramFloat2))
        paramFloat2 = paramFloat1;
      else
        paramFloat2 = Math.min(paramFloat1, paramFloat2);
    }
  }

  public static float min(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    return min(min(paramFloat1, paramFloat2), paramFloat3);
  }

  public static float min(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null)
      throw new IllegalArgumentException("The Array must not be null");
    if (paramArrayOfFloat.length == 0)
      throw new IllegalArgumentException("Array cannot be empty.");
    float f = paramArrayOfFloat[0];
    for (int i = 1; ; i++)
    {
      if (i >= paramArrayOfFloat.length)
        return f;
      f = min(paramArrayOfFloat[i], f);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     org.apache.commons.lang3.math.IEEE754rUtils
 * JD-Core Version:    0.6.2
 */