package miui.v5.widget;

public abstract interface SearchModeAnimationListener
{
  public abstract void onStart();

  public abstract void onStop();

  public abstract void onUpdate(float paramFloat);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     miui.v5.widget.SearchModeAnimationListener
 * JD-Core Version:    0.6.2
 */