package miui.v5.widget;

public class SimpleSearchModeAnimationListener
  implements SearchModeAnimationListener
{
  public void onStart()
  {
  }

  public void onStop()
  {
  }

  public void onUpdate(float paramFloat)
  {
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     miui.v5.widget.SimpleSearchModeAnimationListener
 * JD-Core Version:    0.6.2
 */