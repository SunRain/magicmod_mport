package com.android.internal.transition;

import android.transition.ChangeBounds;
import android.transition.ChangeText;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.ViewGroup;

public class ActionBarTransition
{
  private static boolean TRANSITIONS_ENABLED = false;
  private static final int TRANSITION_DURATION = 120;
  private static final Transition sTransition;

  static
  {
    TransitionSet localTransitionSet2;
    if (TRANSITIONS_ENABLED)
    {
      ChangeText localChangeText = new ChangeText();
      localChangeText.setChangeBehavior(3);
      TransitionSet localTransitionSet1 = new TransitionSet();
      localTransitionSet1.addTransition(localChangeText).addTransition(new ChangeBounds());
      localTransitionSet2 = new TransitionSet();
      localTransitionSet2.addTransition(new Fade(2)).addTransition(localTransitionSet1).addTransition(new Fade(1));
      localTransitionSet2.setOrdering(1);
      localTransitionSet2.setDuration(120L);
    }
    for (sTransition = localTransitionSet2; ; sTransition = null)
      return;
  }

  public static void beginDelayedTransition(ViewGroup paramViewGroup)
  {
    if (TRANSITIONS_ENABLED)
      TransitionManager.beginDelayedTransition(paramViewGroup, sTransition);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.transition.ActionBarTransition
 * JD-Core Version:    0.6.2
 */