package com.android.internal.http.multipart;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class ByteArrayPartSource
  implements PartSource
{
  private byte[] bytes;
  private String fileName;

  public ByteArrayPartSource(String paramString, byte[] paramArrayOfByte)
  {
    this.fileName = paramString;
    this.bytes = paramArrayOfByte;
  }

  public InputStream createInputStream()
  {
    return new ByteArrayInputStream(this.bytes);
  }

  public String getFileName()
  {
    return this.fileName;
  }

  public long getLength()
  {
    return this.bytes.length;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.http.multipart.ByteArrayPartSource
 * JD-Core Version:    0.6.2
 */