package com.android.internal.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.ActionProvider;
import android.view.ActionProvider.SubUiVisibilityListener;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageButton;
import android.widget.ListPopupWindow;
import android.widget.ListPopupWindow.ForwardingListener;
import com.android.internal.transition.ActionBarTransition;
import com.android.internal.view.ActionBarPolicy;
import java.util.ArrayList;

public class ActionMenuPresenter extends BaseMenuPresenter
  implements ActionProvider.SubUiVisibilityListener
{
  private static final String TAG = "ActionMenuPresenter";
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  private ActionButtonSubmenu mActionButtonPopup;
  private int mActionItemWidthLimit;
  private boolean mExpandedActionViewsExclusive;
  private int mMaxItems;
  private boolean mMaxItemsSet;
  private int mMinCellSize;
  int mOpenSubMenuId;
  private View mOverflowButton;
  private OverflowPopup mOverflowPopup;
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback(null);
  private OpenOverflowRunnable mPostedOpenRunnable;
  private boolean mReserveOverflow;
  private boolean mReserveOverflowSet;
  private View mScrapActionButtonView;
  private boolean mStrictWidthLimit;
  private int mWidthLimit;
  private boolean mWidthLimitSet;

  public ActionMenuPresenter(Context paramContext)
  {
    super(paramContext, 17367068, 17367067);
  }

  private View findViewForItem(MenuItem paramMenuItem)
  {
    ViewGroup localViewGroup = (ViewGroup)this.mMenuView;
    if (localViewGroup == null);
    label68: for (View localView = null; ; localView = null)
    {
      return localView;
      int i = localViewGroup.getChildCount();
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label68;
        localView = localViewGroup.getChildAt(j);
        if (((localView instanceof MenuView.ItemView)) && (((MenuView.ItemView)localView).getItemData() == paramMenuItem))
          break;
      }
    }
  }

  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView)
  {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView localActionMenuView = (ActionMenuView)this.mMenuView;
    ((ActionMenuItemView)paramItemView).setItemInvoker(localActionMenuView);
  }

  public boolean dismissPopupMenus()
  {
    return hideOverflowMenu() | hideSubMenus();
  }

  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt)
  {
    if (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton);
    for (boolean bool = false; ; bool = super.filterLeftoverView(paramViewGroup, paramInt))
      return bool;
  }

  public boolean flagActionItems()
  {
    ArrayList localArrayList = this.mMenu.getVisibleItems();
    int i = localArrayList.size();
    int j = this.mMaxItems;
    int k = this.mActionItemWidthLimit;
    int m = View.MeasureSpec.makeMeasureSpec(0, 0);
    ViewGroup localViewGroup = (ViewGroup)this.mMenuView;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    if (i4 < i)
    {
      MenuItemImpl localMenuItemImpl3 = (MenuItemImpl)localArrayList.get(i4);
      if (localMenuItemImpl3.requiresActionButton())
        n++;
      while (true)
      {
        if ((this.mExpandedActionViewsExclusive) && (localMenuItemImpl3.isActionViewExpanded()))
          j = 0;
        i4++;
        break;
        if (localMenuItemImpl3.requestsActionButton())
          i1++;
        else
          i3 = 1;
      }
    }
    if ((this.mReserveOverflow) && ((i3 != 0) || (n + i1 > j)))
      j--;
    int i5 = j - n;
    SparseBooleanArray localSparseBooleanArray = this.mActionButtonGroups;
    localSparseBooleanArray.clear();
    int i6 = 0;
    int i7 = 0;
    if (this.mStrictWidthLimit)
    {
      i7 = k / this.mMinCellSize;
      int i15 = k % this.mMinCellSize;
      i6 = this.mMinCellSize + i15 / i7;
    }
    int i8 = 0;
    if (i8 < i)
    {
      MenuItemImpl localMenuItemImpl1 = (MenuItemImpl)localArrayList.get(i8);
      View localView2;
      if (localMenuItemImpl1.requiresActionButton())
      {
        localView2 = getItemView(localMenuItemImpl1, this.mScrapActionButtonView, localViewGroup);
        if (this.mScrapActionButtonView == null)
          this.mScrapActionButtonView = localView2;
        if (this.mStrictWidthLimit)
        {
          i7 -= ActionMenuView.measureChildForCells(localView2, i6, i7, m, 0);
          label289: int i13 = localView2.getMeasuredWidth();
          k -= i13;
          if (i2 == 0)
            i2 = i13;
          int i14 = localMenuItemImpl1.getGroupId();
          if (i14 != 0)
            localSparseBooleanArray.put(i14, true);
          localMenuItemImpl1.setIsActionButton(true);
        }
      }
      while (true)
      {
        i8++;
        break;
        localView2.measure(m, m);
        break label289;
        if (localMenuItemImpl1.requestsActionButton())
        {
          int i9 = localMenuItemImpl1.getGroupId();
          boolean bool1 = localSparseBooleanArray.get(i9);
          boolean bool2;
          label410: View localView1;
          label478: boolean bool4;
          if (((i5 > 0) || (bool1)) && (k > 0) && ((!this.mStrictWidthLimit) || (i7 > 0)))
          {
            bool2 = true;
            if (bool2)
            {
              localView1 = getItemView(localMenuItemImpl1, this.mScrapActionButtonView, localViewGroup);
              if (this.mScrapActionButtonView == null)
                this.mScrapActionButtonView = localView1;
              if (!this.mStrictWidthLimit)
                break label565;
              int i12 = ActionMenuView.measureChildForCells(localView1, i6, i7, m, 0);
              i7 -= i12;
              if (i12 == 0)
                bool2 = false;
              int i11 = localView1.getMeasuredWidth();
              k -= i11;
              if (i2 == 0)
                i2 = i11;
              if (!this.mStrictWidthLimit)
                break label583;
              if (k < 0)
                break label577;
              bool4 = true;
              label516: bool2 &= bool4;
            }
            if ((!bool2) || (i9 == 0))
              break label610;
            localSparseBooleanArray.put(i9, true);
          }
          while (true)
          {
            if (bool2)
              i5--;
            localMenuItemImpl1.setIsActionButton(bool2);
            break;
            bool2 = false;
            break label410;
            label565: localView1.measure(m, m);
            break label478;
            label577: bool4 = false;
            break label516;
            label583: if (k + i2 > 0);
            for (boolean bool3 = true; ; bool3 = false)
            {
              bool2 &= bool3;
              break;
            }
            label610: if (bool1)
            {
              localSparseBooleanArray.put(i9, false);
              for (int i10 = 0; i10 < i8; i10++)
              {
                MenuItemImpl localMenuItemImpl2 = (MenuItemImpl)localArrayList.get(i10);
                if (localMenuItemImpl2.getGroupId() == i9)
                {
                  if (localMenuItemImpl2.isActionButton())
                    i5++;
                  localMenuItemImpl2.setIsActionButton(false);
                }
              }
            }
          }
        }
        localMenuItemImpl1.setIsActionButton(false);
      }
    }
    return true;
  }

  public View getItemView(final MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup)
  {
    View localView = paramMenuItemImpl.getActionView();
    if ((localView == null) || (paramMenuItemImpl.hasCollapsibleActionView()))
      localView = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup);
    int i;
    if (paramMenuItemImpl.isActionViewExpanded())
    {
      i = 8;
      localView.setVisibility(i);
      if (!paramMenuItemImpl.hasSubMenu())
        break label112;
      localView.setOnTouchListener(new ListPopupWindow.ForwardingListener(localView)
      {
        public ListPopupWindow getPopup()
        {
          if (ActionMenuPresenter.this.mActionButtonPopup != null);
          for (ListPopupWindow localListPopupWindow = ActionMenuPresenter.this.mActionButtonPopup.getPopup(); ; localListPopupWindow = null)
            return localListPopupWindow;
        }

        protected boolean onForwardingStarted()
        {
          return ActionMenuPresenter.this.onSubMenuSelected((SubMenuBuilder)paramMenuItemImpl.getSubMenu());
        }

        protected boolean onForwardingStopped()
        {
          return ActionMenuPresenter.this.dismissPopupMenus();
        }
      });
    }
    while (true)
    {
      ActionMenuView localActionMenuView = (ActionMenuView)paramViewGroup;
      ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
      if (!localActionMenuView.checkLayoutParams(localLayoutParams))
        localView.setLayoutParams(localActionMenuView.generateLayoutParams(localLayoutParams));
      return localView;
      i = 0;
      break;
      label112: localView.setOnTouchListener(null);
    }
  }

  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    MenuView localMenuView = super.getMenuView(paramViewGroup);
    ((ActionMenuView)localMenuView).setPresenter(this);
    return localMenuView;
  }

  public boolean hideOverflowMenu()
  {
    boolean bool;
    if ((this.mPostedOpenRunnable != null) && (this.mMenuView != null))
    {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      bool = true;
    }
    while (true)
    {
      return bool;
      OverflowPopup localOverflowPopup = this.mOverflowPopup;
      if (localOverflowPopup != null)
      {
        localOverflowPopup.dismiss();
        bool = true;
      }
      else
      {
        bool = false;
      }
    }
  }

  public boolean hideSubMenus()
  {
    if (this.mActionButtonPopup != null)
      this.mActionButtonPopup.dismiss();
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
  {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources localResources = paramContext.getResources();
    ActionBarPolicy localActionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = localActionBarPolicy.showsOverflowMenuButton();
    if (!this.mWidthLimitSet)
      this.mWidthLimit = localActionBarPolicy.getEmbeddedMenuWidthLimit();
    if (!this.mMaxItemsSet)
      this.mMaxItems = localActionBarPolicy.getMaxActionButtons();
    int i = this.mWidthLimit;
    if (this.mReserveOverflow)
    {
      if (this.mOverflowButton == null)
      {
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      }
      i -= this.mOverflowButton.getMeasuredWidth();
    }
    while (true)
    {
      this.mActionItemWidthLimit = i;
      this.mMinCellSize = ((int)(56.0F * localResources.getDisplayMetrics().density));
      this.mScrapActionButtonView = null;
      return;
      this.mOverflowButton = null;
    }
  }

  public boolean isOverflowMenuShowPending()
  {
    if ((this.mPostedOpenRunnable != null) || (isOverflowMenuShowing()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isOverflowMenuShowing()
  {
    if ((this.mOverflowPopup != null) && (this.mOverflowPopup.isShowing()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isOverflowReserved()
  {
    return this.mReserveOverflow;
  }

  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    if (!this.mMaxItemsSet)
      this.mMaxItems = this.mContext.getResources().getInteger(17694793);
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true);
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    SavedState localSavedState = (SavedState)paramParcelable;
    if (localSavedState.openSubMenuId > 0)
    {
      MenuItem localMenuItem = this.mMenu.findItem(localSavedState.openSubMenuId);
      if (localMenuItem != null)
        onSubMenuSelected((SubMenuBuilder)localMenuItem.getSubMenu());
    }
  }

  public Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState();
    localSavedState.openSubMenuId = this.mOpenSubMenuId;
    return localSavedState;
  }

  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
  {
    boolean bool = false;
    if (!paramSubMenuBuilder.hasVisibleItems());
    while (true)
    {
      return bool;
      for (SubMenuBuilder localSubMenuBuilder = paramSubMenuBuilder; localSubMenuBuilder.getParentMenu() != this.mMenu; localSubMenuBuilder = (SubMenuBuilder)localSubMenuBuilder.getParentMenu());
      View localView = findViewForItem(localSubMenuBuilder.getItem());
      if (localView == null)
      {
        if (this.mOverflowButton != null)
          localView = this.mOverflowButton;
      }
      else
      {
        this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
        this.mActionButtonPopup = new ActionButtonSubmenu(this.mContext, paramSubMenuBuilder);
        this.mActionButtonPopup.setAnchorView(localView);
        this.mActionButtonPopup.show();
        super.onSubMenuSelected(paramSubMenuBuilder);
        bool = true;
      }
    }
  }

  public void onSubUiVisibilityChanged(boolean paramBoolean)
  {
    if (paramBoolean)
      super.onSubMenuSelected(null);
    while (true)
    {
      return;
      this.mMenu.close(false);
    }
  }

  public void setExpandedActionViewsExclusive(boolean paramBoolean)
  {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }

  public void setItemLimit(int paramInt)
  {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }

  public void setReserveOverflow(boolean paramBoolean)
  {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }

  public void setWidthLimit(int paramInt, boolean paramBoolean)
  {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }

  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl)
  {
    return paramMenuItemImpl.isActionButton();
  }

  public boolean showOverflowMenu()
  {
    boolean bool = true;
    if ((this.mReserveOverflow) && (!isOverflowMenuShowing()) && (this.mMenu != null) && (this.mMenuView != null) && (this.mPostedOpenRunnable == null) && (!this.mMenu.getNonActionItems().isEmpty()))
    {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, this.mOverflowButton, bool));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
    }
    while (true)
    {
      return bool;
      bool = false;
    }
  }

  public void updateMenuView(boolean paramBoolean)
  {
    ViewGroup localViewGroup1 = (ViewGroup)((View)this.mMenuView).getParent();
    if (localViewGroup1 != null)
      ActionBarTransition.beginDelayedTransition(localViewGroup1);
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    if (this.mMenu != null)
    {
      ArrayList localArrayList2 = this.mMenu.getActionItems();
      int k = localArrayList2.size();
      for (int m = 0; m < k; m++)
      {
        ActionProvider localActionProvider = ((MenuItemImpl)localArrayList2.get(m)).getActionProvider();
        if (localActionProvider != null)
          localActionProvider.setSubUiVisibilityListener(this);
      }
    }
    ArrayList localArrayList1;
    int i;
    int j;
    if (this.mMenu != null)
    {
      localArrayList1 = this.mMenu.getNonActionItems();
      i = 0;
      if ((this.mReserveOverflow) && (localArrayList1 != null))
      {
        j = localArrayList1.size();
        if (j != 1)
          break label272;
        if (((MenuItemImpl)localArrayList1.get(0)).isActionViewExpanded())
          break label266;
        i = 1;
      }
      label160: if (i == 0)
        break label289;
      if (this.mOverflowButton == null)
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
      ViewGroup localViewGroup2 = (ViewGroup)this.mOverflowButton.getParent();
      if (localViewGroup2 != this.mMenuView)
      {
        if (localViewGroup2 != null)
          localViewGroup2.removeView(this.mOverflowButton);
        ActionMenuView localActionMenuView = (ActionMenuView)this.mMenuView;
        localActionMenuView.addView(this.mOverflowButton, localActionMenuView.generateOverflowButtonLayoutParams());
      }
    }
    while (true)
    {
      ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
      return;
      localArrayList1 = null;
      break;
      label266: i = 0;
      break label160;
      label272: if (j > 0);
      for (i = 1; ; i = 0)
        break;
      label289: if ((this.mOverflowButton != null) && (this.mOverflowButton.getParent() == this.mMenuView))
        ((ViewGroup)this.mMenuView).removeView(this.mOverflowButton);
    }
  }

  private class ActionButtonSubmenu extends MenuPopupHelper
  {
    private SubMenuBuilder mSubMenu;

    public ActionButtonSubmenu(Context paramSubMenuBuilder, SubMenuBuilder arg3)
    {
      super(localMenuBuilder);
      this.mSubMenu = localMenuBuilder;
      View localView;
      boolean bool;
      int i;
      if (!((MenuItemImpl)localMenuBuilder.getItem()).isActionButton())
      {
        if (ActionMenuPresenter.this.mOverflowButton == null)
        {
          localView = (View)ActionMenuPresenter.this.mMenuView;
          setAnchorView(localView);
        }
      }
      else
      {
        setCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
        bool = false;
        i = localMenuBuilder.size();
      }
      for (int j = 0; ; j++)
        if (j < i)
        {
          MenuItem localMenuItem = localMenuBuilder.getItem(j);
          if ((localMenuItem.isVisible()) && (localMenuItem.getIcon() != null))
            bool = true;
        }
        else
        {
          setForceShowIcon(bool);
          return;
          localView = ActionMenuPresenter.this.mOverflowButton;
          break;
        }
    }

    public void onDismiss()
    {
      super.onDismiss();
      ActionMenuPresenter.access$102(ActionMenuPresenter.this, null);
      ActionMenuPresenter.this.mOpenSubMenuId = 0;
    }
  }

  private class OpenOverflowRunnable
    implements Runnable
  {
    private ActionMenuPresenter.OverflowPopup mPopup;

    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup arg2)
    {
      Object localObject;
      this.mPopup = localObject;
    }

    public void run()
    {
      ActionMenuPresenter.this.mMenu.changeMenuMode();
      View localView = (View)ActionMenuPresenter.this.mMenuView;
      if ((localView != null) && (localView.getWindowToken() != null) && (this.mPopup.tryShow()))
        ActionMenuPresenter.access$202(ActionMenuPresenter.this, this.mPopup);
      ActionMenuPresenter.access$302(ActionMenuPresenter.this, null);
    }
  }

  private class OverflowMenuButton extends ImageButton
    implements ActionMenuView.ActionMenuChildView
  {
    public OverflowMenuButton(Context arg2)
    {
      super(null, 16843510);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      setOnTouchListener(new ListPopupWindow.ForwardingListener(this)
      {
        public ListPopupWindow getPopup()
        {
          if (ActionMenuPresenter.this.mOverflowPopup == null);
          for (ListPopupWindow localListPopupWindow = null; ; localListPopupWindow = ActionMenuPresenter.this.mOverflowPopup.getPopup())
            return localListPopupWindow;
        }

        public boolean onForwardingStarted()
        {
          ActionMenuPresenter.this.showOverflowMenu();
          return true;
        }

        public boolean onForwardingStopped()
        {
          if (ActionMenuPresenter.this.mPostedOpenRunnable != null);
          for (boolean bool = false; ; bool = true)
          {
            return bool;
            ActionMenuPresenter.this.hideOverflowMenu();
          }
        }
      });
    }

    public boolean needsDividerAfter()
    {
      return false;
    }

    public boolean needsDividerBefore()
    {
      return false;
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setCanOpenPopup(true);
    }

    protected void onMeasure(int paramInt1, int paramInt2)
    {
      if (View.MeasureSpec.getMode(paramInt2) == -2147483648)
        paramInt2 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt2), 1073741824);
      super.onMeasure(paramInt1, paramInt2);
    }

    public boolean performClick()
    {
      if (super.performClick());
      while (true)
      {
        return true;
        playSoundEffect(0);
        ActionMenuPresenter.this.showOverflowMenu();
      }
    }
  }

  private class OverflowPopup extends MenuPopupHelper
  {
    public OverflowPopup(Context paramMenuBuilder, MenuBuilder paramView, View paramBoolean, boolean arg5)
    {
      super(paramView, paramBoolean, bool);
      setGravity(8388613);
      setCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }

    public void onDismiss()
    {
      super.onDismiss();
      ActionMenuPresenter.this.mMenu.close();
      ActionMenuPresenter.access$202(ActionMenuPresenter.this, null);
    }
  }

  private class PopupPresenterCallback
    implements MenuPresenter.Callback
  {
    private PopupPresenterCallback()
    {
    }

    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
      if ((paramMenuBuilder instanceof SubMenuBuilder))
        ((SubMenuBuilder)paramMenuBuilder).getRootMenu().close(false);
      MenuPresenter.Callback localCallback = ActionMenuPresenter.this.getCallback();
      if (localCallback != null)
        localCallback.onCloseMenu(paramMenuBuilder, paramBoolean);
    }

    public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder)
    {
      boolean bool1 = false;
      if (paramMenuBuilder == null)
        return bool1;
      ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)paramMenuBuilder).getItem().getItemId();
      MenuPresenter.Callback localCallback = ActionMenuPresenter.this.getCallback();
      if (localCallback != null);
      for (boolean bool2 = localCallback.onOpenSubMenu(paramMenuBuilder); ; bool2 = false)
      {
        bool1 = bool2;
        break;
      }
    }
  }

  private static class SavedState
    implements Parcelable
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
      public ActionMenuPresenter.SavedState createFromParcel(Parcel paramAnonymousParcel)
      {
        return new ActionMenuPresenter.SavedState(paramAnonymousParcel);
      }

      public ActionMenuPresenter.SavedState[] newArray(int paramAnonymousInt)
      {
        return new ActionMenuPresenter.SavedState[paramAnonymousInt];
      }
    };
    public int openSubMenuId;

    SavedState()
    {
    }

    SavedState(Parcel paramParcel)
    {
      this.openSubMenuId = paramParcel.readInt();
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeInt(this.openSubMenuId);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.view.menu.ActionMenuPresenter
 * JD-Core Version:    0.6.2
 */