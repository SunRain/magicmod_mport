package com.android.internal.notification;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract.Contacts;
import android.provider.Settings.Global;
import android.text.SpannableString;
import android.util.Slog;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class DemoContactNotificationScorer
  implements NotificationScorer
{
  private static final Uri CONTACTS_URI = ContactsContract.Contacts.CONTENT_URI;
  private static final boolean DBG = false;
  protected static final boolean ENABLE_CONTACT_SCORER = true;
  private static final int NOTIFICATION_PRIORITY_MULTIPLIER = 10;
  private static final String[] PROJECTION;
  private static final List<String> RELEVANT_KEYS_LIST = Arrays.asList(new String[] { "android.infoText", "android.text", "android.textLines", "android.subText", "android.title" });
  private static final String SETTING_ENABLE_SCORER = "contact_scorer_enabled";
  private static final String TAG = "DemoContactNotificationScorer";
  private Context mContext;
  protected boolean mEnabled;

  static
  {
    PROJECTION = new String[] { "_id", "display_name" };
  }

  private static final int clamp(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < paramInt2);
    while (true)
    {
      return paramInt2;
      if (paramInt1 > paramInt3)
        paramInt2 = paramInt3;
      else
        paramInt2 = paramInt1;
    }
  }

  private static List<String> extractSpannedStrings(CharSequence paramCharSequence)
  {
    if (paramCharSequence == null);
    String[] arrayOfString;
    for (Object localObject1 = Collections.emptyList(); ; localObject1 = Arrays.asList(arrayOfString))
    {
      return localObject1;
      if ((paramCharSequence instanceof SpannableString))
        break;
      arrayOfString = new String[1];
      arrayOfString[0] = paramCharSequence.toString();
    }
    SpannableString localSpannableString = (SpannableString)paramCharSequence;
    Object[] arrayOfObject = localSpannableString.getSpans(0, localSpannableString.length(), Object.class);
    localObject1 = new ArrayList();
    int i = arrayOfObject.length;
    int j = 0;
    while (j < i)
    {
      Object localObject2 = arrayOfObject[j];
      try
      {
        ((ArrayList)localObject1).add(localSpannableString.subSequence(localSpannableString.getSpanStart(localObject2), localSpannableString.getSpanEnd(localObject2)).toString());
        j++;
      }
      catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
      {
        while (true)
          Slog.e("DemoContactNotificationScorer", "Bad indices when extracting spanned subsequence", localStringIndexOutOfBoundsException);
      }
    }
  }

  private static String getQuestionMarksInParens(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder("(");
    for (int i = 0; i < paramInt; i++)
    {
      if (localStringBuilder.length() > 1)
        localStringBuilder.append(',');
      localStringBuilder.append('?');
    }
    localStringBuilder.append(")");
    return localStringBuilder.toString();
  }

  private boolean hasStarredContact(Bundle paramBundle)
  {
    boolean bool;
    if (paramBundle == null)
      bool = false;
    while (true)
    {
      return bool;
      ArrayList localArrayList = new ArrayList();
      Iterator localIterator = RELEVANT_KEYS_LIST.iterator();
      while (localIterator.hasNext())
      {
        String str2 = (String)localIterator.next();
        if (paramBundle.get(str2) != null)
          if ((paramBundle.get(str2) instanceof CharSequence))
          {
            localArrayList.addAll(extractSpannedStrings((CharSequence)paramBundle.get(str2)));
          }
          else if ((paramBundle.get(str2) instanceof CharSequence[]))
          {
            CharSequence[] arrayOfCharSequence = (CharSequence[])paramBundle.get(str2);
            int j = arrayOfCharSequence.length;
            for (int k = 0; k < j; k++)
              localArrayList.addAll(extractSpannedStrings(arrayOfCharSequence[k]));
          }
          else
          {
            Slog.w("DemoContactNotificationScorer", "Strange, the extra " + str2 + " is of unexpected type.");
          }
      }
      if (localArrayList.isEmpty())
      {
        bool = false;
        continue;
      }
      String[] arrayOfString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
      String str1 = "display_name IN " + getQuestionMarksInParens(arrayOfString.length) + " AND " + "starred" + " ='1'";
      Cursor localCursor = null;
      try
      {
        localCursor = this.mContext.getContentResolver().query(CONTACTS_URI, PROJECTION, str1, arrayOfString, null);
        if (localCursor != null)
        {
          int i = localCursor.getCount();
          if (i > 0);
          for (bool = true; localCursor != null; bool = false)
          {
            localCursor.close();
            break;
          }
        }
        if (localCursor != null)
          localCursor.close();
        bool = false;
      }
      catch (Throwable localThrowable)
      {
        while (true)
        {
          Slog.w("DemoContactNotificationScorer", "Problem getting content resolver or performing contacts query.", localThrowable);
          if (localCursor != null)
            localCursor.close();
        }
      }
      finally
      {
        if (localCursor != null)
          localCursor.close();
      }
    }
  }

  private static int priorityBumpMap(int paramInt)
  {
    int i = clamp(paramInt, -20, 20);
    if (i != paramInt)
      return paramInt;
    if (i <= -10);
    for (int j = (int)(i + 1.5D * (i + 20)); ; j = (int)(i + 0.5D * (20 - i)))
    {
      paramInt = j;
      break;
    }
  }

  public int getScore(Notification paramNotification, int paramInt)
  {
    if ((paramNotification == null) || (!this.mEnabled));
    for (int i = paramInt; ; i = paramInt)
    {
      return i;
      if (hasStarredContact(paramNotification.extras))
        paramInt = priorityBumpMap(paramInt);
    }
  }

  public void initialize(Context paramContext)
  {
    int i = 1;
    this.mContext = paramContext;
    if (i == Settings.Global.getInt(this.mContext.getContentResolver(), "contact_scorer_enabled", 0));
    while (true)
    {
      this.mEnabled = i;
      return;
      i = 0;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.notification.DemoContactNotificationScorer
 * JD-Core Version:    0.6.2
 */