package com.android.internal.policy;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IKeyguardExitCallback extends IInterface
{
  public abstract void onKeyguardExitResult(boolean paramBoolean)
    throws RemoteException;

  public static abstract class Stub extends Binder
    implements IKeyguardExitCallback
  {
    private static final String DESCRIPTOR = "com.android.internal.policy.IKeyguardExitCallback";
    static final int TRANSACTION_onKeyguardExitResult = 1;

    public Stub()
    {
      attachInterface(this, "com.android.internal.policy.IKeyguardExitCallback");
    }

    public static IKeyguardExitCallback asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        IInterface localIInterface = paramIBinder.queryLocalInterface("com.android.internal.policy.IKeyguardExitCallback");
        if ((localIInterface != null) && ((localIInterface instanceof IKeyguardExitCallback)))
          localObject = (IKeyguardExitCallback)localIInterface;
        else
          localObject = new Proxy(paramIBinder);
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool1 = true;
      switch (paramInt1)
      {
      default:
        bool1 = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        while (true)
        {
          return bool1;
          paramParcel2.writeString("com.android.internal.policy.IKeyguardExitCallback");
        }
      case 1:
      }
      paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardExitCallback");
      if (paramParcel1.readInt() != 0);
      for (boolean bool2 = bool1; ; bool2 = false)
      {
        onKeyguardExitResult(bool2);
        break;
      }
    }

    private static class Proxy
      implements IKeyguardExitCallback
    {
      private IBinder mRemote;

      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.mRemote;
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.internal.policy.IKeyguardExitCallback";
      }

      public void onKeyguardExitResult(boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardExitCallback");
          if (paramBoolean)
          {
            localParcel.writeInt(i);
            this.mRemote.transact(1, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.policy.IKeyguardExitCallback
 * JD-Core Version:    0.6.2
 */