package com.android.internal.policy;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public abstract interface IKeyguardShowCallback extends IInterface
{
  public abstract void onShown(IBinder paramIBinder)
    throws RemoteException;

  public static abstract class Stub extends Binder
    implements IKeyguardShowCallback
  {
    private static final String DESCRIPTOR = "com.android.internal.policy.IKeyguardShowCallback";
    static final int TRANSACTION_onShown = 1;

    public Stub()
    {
      attachInterface(this, "com.android.internal.policy.IKeyguardShowCallback");
    }

    public static IKeyguardShowCallback asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        IInterface localIInterface = paramIBinder.queryLocalInterface("com.android.internal.policy.IKeyguardShowCallback");
        if ((localIInterface != null) && ((localIInterface instanceof IKeyguardShowCallback)))
          localObject = (IKeyguardShowCallback)localIInterface;
        else
          localObject = new Proxy(paramIBinder);
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      boolean bool = true;
      switch (paramInt1)
      {
      default:
        bool = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      }
      while (true)
      {
        return bool;
        paramParcel2.writeString("com.android.internal.policy.IKeyguardShowCallback");
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardShowCallback");
        onShown(paramParcel1.readStrongBinder());
      }
    }

    private static class Proxy
      implements IKeyguardShowCallback
    {
      private IBinder mRemote;

      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.mRemote;
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.internal.policy.IKeyguardShowCallback";
      }

      public void onShown(IBinder paramIBinder)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardShowCallback");
          localParcel.writeStrongBinder(paramIBinder);
          this.mRemote.transact(1, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.policy.IKeyguardShowCallback
 * JD-Core Version:    0.6.2
 */