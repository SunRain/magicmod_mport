package com.android.internal.policy;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.view.MotionEvent;

public abstract interface IKeyguardService extends IInterface
{
  public abstract void dismiss()
    throws RemoteException;

  public abstract void dispatch(MotionEvent paramMotionEvent)
    throws RemoteException;

  public abstract void doKeyguardTimeout(Bundle paramBundle)
    throws RemoteException;

  public abstract boolean isDismissable()
    throws RemoteException;

  public abstract boolean isInputRestricted()
    throws RemoteException;

  public abstract boolean isSecure()
    throws RemoteException;

  public abstract boolean isShowing()
    throws RemoteException;

  public abstract boolean isShowingAndNotHidden()
    throws RemoteException;

  public abstract void keyguardDone(boolean paramBoolean1, boolean paramBoolean2)
    throws RemoteException;

  public abstract void launchCamera()
    throws RemoteException;

  public abstract void onBootCompleted()
    throws RemoteException;

  public abstract void onDreamingStarted()
    throws RemoteException;

  public abstract void onDreamingStopped()
    throws RemoteException;

  public abstract void onScreenTurnedOff(int paramInt)
    throws RemoteException;

  public abstract void onScreenTurnedOn(IKeyguardShowCallback paramIKeyguardShowCallback)
    throws RemoteException;

  public abstract void onSystemReady()
    throws RemoteException;

  public abstract void setCurrentUser(int paramInt)
    throws RemoteException;

  public abstract void setHidden(boolean paramBoolean)
    throws RemoteException;

  public abstract void setKeyguardEnabled(boolean paramBoolean)
    throws RemoteException;

  public abstract void showAssistant()
    throws RemoteException;

  public abstract void verifyUnlock(IKeyguardExitCallback paramIKeyguardExitCallback)
    throws RemoteException;

  public static abstract class Stub extends Binder
    implements IKeyguardService
  {
    private static final String DESCRIPTOR = "com.android.internal.policy.IKeyguardService";
    static final int TRANSACTION_dismiss = 9;
    static final int TRANSACTION_dispatch = 19;
    static final int TRANSACTION_doKeyguardTimeout = 16;
    static final int TRANSACTION_isDismissable = 5;
    static final int TRANSACTION_isInputRestricted = 4;
    static final int TRANSACTION_isSecure = 2;
    static final int TRANSACTION_isShowing = 1;
    static final int TRANSACTION_isShowingAndNotHidden = 3;
    static final int TRANSACTION_keyguardDone = 7;
    static final int TRANSACTION_launchCamera = 20;
    static final int TRANSACTION_onBootCompleted = 21;
    static final int TRANSACTION_onDreamingStarted = 10;
    static final int TRANSACTION_onDreamingStopped = 11;
    static final int TRANSACTION_onScreenTurnedOff = 12;
    static final int TRANSACTION_onScreenTurnedOn = 13;
    static final int TRANSACTION_onSystemReady = 15;
    static final int TRANSACTION_setCurrentUser = 17;
    static final int TRANSACTION_setHidden = 8;
    static final int TRANSACTION_setKeyguardEnabled = 14;
    static final int TRANSACTION_showAssistant = 18;
    static final int TRANSACTION_verifyUnlock = 6;

    public Stub()
    {
      attachInterface(this, "com.android.internal.policy.IKeyguardService");
    }

    public static IKeyguardService asInterface(IBinder paramIBinder)
    {
      Object localObject;
      if (paramIBinder == null)
        localObject = null;
      while (true)
      {
        return localObject;
        IInterface localIInterface = paramIBinder.queryLocalInterface("com.android.internal.policy.IKeyguardService");
        if ((localIInterface != null) && ((localIInterface instanceof IKeyguardService)))
          localObject = (IKeyguardService)localIInterface;
        else
          localObject = new Proxy(paramIBinder);
      }
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      int i = 0;
      int j = 1;
      switch (paramInt1)
      {
      default:
        j = super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      }
      while (true)
      {
        return j;
        paramParcel2.writeString("com.android.internal.policy.IKeyguardService");
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool9 = isShowing();
        paramParcel2.writeNoException();
        if (bool9)
          i = j;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool8 = isSecure();
        paramParcel2.writeNoException();
        if (bool8)
          i = j;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool7 = isShowingAndNotHidden();
        paramParcel2.writeNoException();
        if (bool7)
          i = j;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool6 = isInputRestricted();
        paramParcel2.writeNoException();
        if (bool6)
          i = j;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool5 = isDismissable();
        paramParcel2.writeNoException();
        if (bool5)
          i = j;
        paramParcel2.writeInt(i);
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        verifyUnlock(IKeyguardExitCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        boolean bool3;
        if (paramParcel1.readInt() != 0)
        {
          bool3 = j;
          label422: if (paramParcel1.readInt() == 0)
            break label450;
        }
        label450: for (boolean bool4 = j; ; bool4 = false)
        {
          keyguardDone(bool3, bool4);
          break;
          bool3 = false;
          break label422;
        }
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        if (paramParcel1.readInt() != 0);
        for (boolean bool2 = j; ; bool2 = false)
        {
          setHidden(bool2);
          break;
        }
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        dismiss();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onDreamingStarted();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onDreamingStopped();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onScreenTurnedOff(paramParcel1.readInt());
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onScreenTurnedOn(IKeyguardShowCallback.Stub.asInterface(paramParcel1.readStrongBinder()));
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        if (paramParcel1.readInt() != 0);
        for (boolean bool1 = j; ; bool1 = false)
        {
          setKeyguardEnabled(bool1);
          break;
        }
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onSystemReady();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        if (paramParcel1.readInt() != 0);
        for (Bundle localBundle = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1); ; localBundle = null)
        {
          doKeyguardTimeout(localBundle);
          break;
        }
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        setCurrentUser(paramParcel1.readInt());
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        showAssistant();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        if (paramParcel1.readInt() != 0);
        for (MotionEvent localMotionEvent = (MotionEvent)MotionEvent.CREATOR.createFromParcel(paramParcel1); ; localMotionEvent = null)
        {
          dispatch(localMotionEvent);
          break;
        }
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        launchCamera();
        continue;
        paramParcel1.enforceInterface("com.android.internal.policy.IKeyguardService");
        onBootCompleted();
      }
    }

    private static class Proxy
      implements IKeyguardService
    {
      private IBinder mRemote;

      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.mRemote;
      }

      public void dismiss()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(9, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void dispatch(MotionEvent paramMotionEvent)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramMotionEvent != null)
          {
            localParcel.writeInt(1);
            paramMotionEvent.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.mRemote.transact(19, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void doKeyguardTimeout(Bundle paramBundle)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramBundle != null)
          {
            localParcel.writeInt(1);
            paramBundle.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.mRemote.transact(16, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public String getInterfaceDescriptor()
      {
        return "com.android.internal.policy.IKeyguardService";
      }

      public boolean isDismissable()
        throws RemoteException
      {
        boolean bool = false;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(5, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public boolean isInputRestricted()
        throws RemoteException
      {
        boolean bool = false;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(4, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public boolean isSecure()
        throws RemoteException
      {
        boolean bool = false;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(2, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public boolean isShowing()
        throws RemoteException
      {
        boolean bool = true;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(1, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          if (i != 0)
            return bool;
          bool = false;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public boolean isShowingAndNotHidden()
        throws RemoteException
      {
        boolean bool = false;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(3, localParcel1, localParcel2, 0);
          localParcel2.readException();
          int i = localParcel2.readInt();
          if (i != 0)
            bool = true;
          return bool;
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
      }

      public void keyguardDone(boolean paramBoolean1, boolean paramBoolean2)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramBoolean1);
          for (int j = i; ; j = 0)
          {
            localParcel.writeInt(j);
            if (!paramBoolean2)
              break;
            localParcel.writeInt(i);
            this.mRemote.transact(7, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void launchCamera()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(20, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onBootCompleted()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(21, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onDreamingStarted()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(10, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onDreamingStopped()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(11, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onScreenTurnedOff(int paramInt)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          localParcel.writeInt(paramInt);
          this.mRemote.transact(12, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onScreenTurnedOn(IKeyguardShowCallback paramIKeyguardShowCallback)
        throws RemoteException
      {
        IBinder localIBinder = null;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramIKeyguardShowCallback != null)
            localIBinder = paramIKeyguardShowCallback.asBinder();
          localParcel.writeStrongBinder(localIBinder);
          this.mRemote.transact(13, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void onSystemReady()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(15, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void setCurrentUser(int paramInt)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          localParcel.writeInt(paramInt);
          this.mRemote.transact(17, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void setHidden(boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramBoolean)
          {
            localParcel.writeInt(i);
            this.mRemote.transact(8, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void setKeyguardEnabled(boolean paramBoolean)
        throws RemoteException
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramBoolean)
          {
            localParcel.writeInt(i);
            this.mRemote.transact(14, localParcel, null, 1);
            return;
          }
          i = 0;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void showAssistant()
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          this.mRemote.transact(18, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }

      public void verifyUnlock(IKeyguardExitCallback paramIKeyguardExitCallback)
        throws RemoteException
      {
        IBinder localIBinder = null;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.android.internal.policy.IKeyguardService");
          if (paramIKeyguardExitCallback != null)
            localIBinder = paramIKeyguardExitCallback.asBinder();
          localParcel.writeStrongBinder(localIBinder);
          this.mRemote.transact(6, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.policy.IKeyguardService
 * JD-Core Version:    0.6.2
 */