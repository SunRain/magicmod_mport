package com.android.internal.widget;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import com.android.internal.app.ActionBarImpl;

public class ActionBarOverlayLayout extends ViewGroup
{
  static final int[] ATTRS = { 16843499, 16842841 };
  private static final String TAG = "ActionBarOverlayLayout";
  private ActionBarImpl mActionBar;
  private View mActionBarBottom;
  private int mActionBarHeight;
  private ActionBarContainer mActionBarTop;
  private ActionBarView mActionBarView;
  private final Rect mBaseContentInsets = new Rect();
  private final Rect mBaseInnerInsets = new Rect();
  private View mContent;
  private final Rect mContentInsets = new Rect();
  private boolean mIgnoreWindowContentOverlay;
  private final Rect mInnerInsets = new Rect();
  private final Rect mLastBaseContentInsets = new Rect();
  private final Rect mLastInnerInsets = new Rect();
  private int mLastSystemUiVisibility;
  private boolean mOverlayMode;
  private Drawable mWindowContentOverlay;
  private int mWindowVisibility = 0;

  public ActionBarOverlayLayout(Context paramContext)
  {
    super(paramContext);
    init(paramContext);
  }

  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init(paramContext);
  }

  private boolean applyInsets(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    boolean bool = false;
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((paramBoolean1) && (localLayoutParams.leftMargin != paramRect.left))
    {
      bool = true;
      localLayoutParams.leftMargin = paramRect.left;
    }
    if ((paramBoolean2) && (localLayoutParams.topMargin != paramRect.top))
    {
      bool = true;
      localLayoutParams.topMargin = paramRect.top;
    }
    if ((paramBoolean4) && (localLayoutParams.rightMargin != paramRect.right))
    {
      bool = true;
      localLayoutParams.rightMargin = paramRect.right;
    }
    if ((paramBoolean3) && (localLayoutParams.bottomMargin != paramRect.bottom))
    {
      bool = true;
      localLayoutParams.bottomMargin = paramRect.bottom;
    }
    return bool;
  }

  private void init(Context paramContext)
  {
    int i = 1;
    TypedArray localTypedArray = getContext().getTheme().obtainStyledAttributes(ATTRS);
    this.mActionBarHeight = localTypedArray.getDimensionPixelSize(0, 0);
    this.mWindowContentOverlay = localTypedArray.getDrawable(i);
    if (this.mWindowContentOverlay == null)
    {
      int j = i;
      setWillNotDraw(j);
      localTypedArray.recycle();
      if (paramContext.getApplicationInfo().targetSdkVersion >= 19)
        break label79;
    }
    while (true)
    {
      this.mIgnoreWindowContentOverlay = i;
      return;
      int k = 0;
      break;
      label79: i = 0;
    }
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }

  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    if ((this.mWindowContentOverlay != null) && (!this.mIgnoreWindowContentOverlay))
      if (this.mActionBarTop.getVisibility() != 0)
        break label81;
    label81: for (int i = (int)(0.5F + (this.mActionBarTop.getBottom() + this.mActionBarTop.getTranslationY())); ; i = 0)
    {
      this.mWindowContentOverlay.setBounds(0, i, getWidth(), i + this.mWindowContentOverlay.getIntrinsicHeight());
      this.mWindowContentOverlay.draw(paramCanvas);
      return;
    }
  }

  protected void findViews()
  {
    pullChildren();
  }

  protected boolean fitSystemWindows(Rect paramRect)
  {
    pullChildren();
    if ((0x100 & getWindowSystemUiVisibility()) != 0);
    while (true)
    {
      boolean bool = applyInsets(this.mActionBarTop, paramRect, true, true, false, true);
      if (this.mActionBarBottom != null)
        bool |= applyInsets(this.mActionBarBottom, paramRect, true, false, true, true);
      this.mBaseInnerInsets.set(paramRect);
      computeFitSystemWindows(this.mBaseInnerInsets, this.mBaseContentInsets);
      if (!this.mLastBaseContentInsets.equals(this.mBaseContentInsets))
      {
        bool = true;
        this.mLastBaseContentInsets.set(this.mBaseContentInsets);
      }
      if (bool)
        requestLayout();
      return true;
    }
  }

  protected LayoutParams generateDefaultLayoutParams()
  {
    return new LayoutParams(-1, -1);
  }

  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new LayoutParams(paramLayoutParams);
  }

  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected ActionBarImpl getActionBar()
  {
    return this.mActionBar;
  }

  protected View getActionBarBottom()
  {
    return this.mActionBarBottom;
  }

  protected View getActionBarTop()
  {
    return this.mActionBarTop;
  }

  protected ActionBarView getActionView()
  {
    return this.mActionBarView;
  }

  protected Rect getBaseContentInsets()
  {
    return this.mBaseContentInsets;
  }

  protected Rect getBaseInnerInsets()
  {
    return this.mBaseInnerInsets;
  }

  protected ActionBarContainer getContainerView()
  {
    return this.mActionBarTop;
  }

  protected View getContent()
  {
    return this.mContent;
  }

  protected Rect getContentInsets()
  {
    return this.mContentInsets;
  }

  protected Rect getInnerInsets()
  {
    return this.mInnerInsets;
  }

  protected Rect getLastInnerInsets()
  {
    return this.mLastInnerInsets;
  }

  protected boolean isOverlayMode()
  {
    return this.mOverlayMode;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getChildCount();
    int j = getPaddingLeft();
    (paramInt3 - paramInt1 - getPaddingRight());
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2 - getPaddingBottom();
    int n = 0;
    if (n < i)
    {
      View localView = getChildAt(n);
      LayoutParams localLayoutParams;
      int i1;
      int i2;
      int i3;
      if (localView.getVisibility() != 8)
      {
        localLayoutParams = (LayoutParams)localView.getLayoutParams();
        i1 = localView.getMeasuredWidth();
        i2 = localView.getMeasuredHeight();
        i3 = j + localLayoutParams.leftMargin;
        if (localView != this.mActionBarBottom)
          break label148;
      }
      label148: for (int i4 = m - i2 - localLayoutParams.bottomMargin; ; i4 = k + localLayoutParams.topMargin)
      {
        localView.layout(i3, i4, i3 + i1, i4 + i2);
        n++;
        break;
      }
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    pullChildren();
    int i = 0;
    int j = 0;
    measureChildWithMargins(this.mActionBarTop, paramInt1, 0, paramInt2, 0);
    LayoutParams localLayoutParams1 = (LayoutParams)this.mActionBarTop.getLayoutParams();
    int k = Math.max(0, this.mActionBarTop.getMeasuredWidth() + localLayoutParams1.leftMargin + localLayoutParams1.rightMargin);
    int m = Math.max(0, this.mActionBarTop.getMeasuredHeight() + localLayoutParams1.topMargin + localLayoutParams1.bottomMargin);
    int n = combineMeasuredStates(0, this.mActionBarTop.getMeasuredState());
    if (this.mActionBarBottom != null)
    {
      measureChildWithMargins(this.mActionBarBottom, paramInt1, 0, paramInt2, 0);
      LayoutParams localLayoutParams3 = (LayoutParams)this.mActionBarBottom.getLayoutParams();
      k = Math.max(k, this.mActionBarBottom.getMeasuredWidth() + localLayoutParams3.leftMargin + localLayoutParams3.rightMargin);
      m = Math.max(m, this.mActionBarBottom.getMeasuredHeight() + localLayoutParams3.topMargin + localLayoutParams3.bottomMargin);
      n = combineMeasuredStates(n, this.mActionBarBottom.getMeasuredState());
    }
    int i1;
    label251: Rect localRect4;
    if ((0x100 & getWindowSystemUiVisibility()) != 0)
    {
      i1 = 1;
      if (i1 == 0)
        break label563;
      i = this.mActionBarHeight;
      if ((this.mActionBar != null) && (this.mActionBar.hasNonEmbeddedTabs()) && (this.mActionBarTop.getTabContainer() != null))
        i += this.mActionBarHeight;
      if ((this.mActionBarView.isSplitActionBar()) && (this.mActionBarBottom != null))
      {
        if (i1 == 0)
          break label584;
        j = this.mActionBarHeight;
      }
      label279: this.mContentInsets.set(this.mBaseContentInsets);
      this.mInnerInsets.set(this.mBaseInnerInsets);
      if ((this.mOverlayMode) || (i1 != 0))
        break label596;
      Rect localRect3 = this.mContentInsets;
      localRect3.top = (i + localRect3.top);
      localRect4 = this.mContentInsets;
    }
    label563: label584: label596: Rect localRect2;
    for (localRect4.bottom = (j + localRect4.bottom); ; localRect2.bottom = (j + localRect2.bottom))
    {
      applyInsets(this.mContent, this.mContentInsets, true, true, true, true);
      if (!this.mLastInnerInsets.equals(this.mInnerInsets))
      {
        this.mLastInnerInsets.set(this.mInnerInsets);
        super.fitSystemWindows(this.mInnerInsets);
      }
      measureChildWithMargins(this.mContent, paramInt1, 0, paramInt2, 0);
      LayoutParams localLayoutParams2 = (LayoutParams)this.mContent.getLayoutParams();
      int i2 = Math.max(k, this.mContent.getMeasuredWidth() + localLayoutParams2.leftMargin + localLayoutParams2.rightMargin);
      int i3 = Math.max(m, this.mContent.getMeasuredHeight() + localLayoutParams2.topMargin + localLayoutParams2.bottomMargin);
      int i4 = combineMeasuredStates(n, this.mContent.getMeasuredState());
      int i5 = i2 + (getPaddingLeft() + getPaddingRight());
      int i6 = Math.max(i3 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight());
      setMeasuredDimension(resolveSizeAndState(Math.max(i5, getSuggestedMinimumWidth()), paramInt1, i4), resolveSizeAndState(i6, paramInt2, i4 << 16));
      return;
      i1 = 0;
      break;
      if (this.mActionBarTop.getVisibility() != 0)
        break label251;
      i = this.mActionBarTop.getMeasuredHeight();
      break label251;
      j = this.mActionBarBottom.getMeasuredHeight();
      break label279;
      Rect localRect1 = this.mInnerInsets;
      localRect1.top = (i + localRect1.top);
      localRect2 = this.mInnerInsets;
    }
  }

  public void onWindowSystemUiVisibilityChanged(int paramInt)
  {
    boolean bool1 = true;
    super.onWindowSystemUiVisibilityChanged(paramInt);
    pullChildren();
    int i = paramInt ^ this.mLastSystemUiVisibility;
    this.mLastSystemUiVisibility = paramInt;
    boolean bool2;
    label47: boolean bool3;
    if ((paramInt & 0x4) == 0)
    {
      bool2 = bool1;
      if (this.mActionBar == null)
        break label125;
      this.mActionBar.isSystemShowing();
      if ((paramInt & 0x100) == 0)
        break label130;
      bool3 = bool1;
      label58: if (this.mActionBar != null)
      {
        ActionBarImpl localActionBarImpl = this.mActionBar;
        if (bool3)
          break label136;
        label76: localActionBarImpl.enableContentAnimations(bool1);
        if ((!bool2) && (bool3))
          break label141;
        this.mActionBar.showForSystem();
      }
    }
    while (true)
    {
      if (((i & 0x100) != 0) && (this.mActionBar != null))
        requestFitSystemWindows();
      return;
      bool2 = false;
      break;
      label125: break label47;
      label130: bool3 = false;
      break label58;
      label136: bool1 = false;
      break label76;
      label141: this.mActionBar.hideForSystem();
    }
  }

  protected void onWindowVisibilityChanged(int paramInt)
  {
    super.onWindowVisibilityChanged(paramInt);
    this.mWindowVisibility = paramInt;
    if (this.mActionBar != null)
      this.mActionBar.setWindowVisibility(paramInt);
  }

  void pullChildren()
  {
    if (this.mContent == null)
    {
      this.mContent = findViewById(16908290);
      this.mActionBarTop = ((ActionBarContainer)findViewById(16909096));
      this.mActionBarView = ((ActionBarView)findViewById(16909097));
      this.mActionBarBottom = findViewById(16909099);
    }
  }

  public void setActionBar(ActionBarImpl paramActionBarImpl)
  {
    this.mActionBar = paramActionBarImpl;
    if (getWindowToken() != null)
    {
      this.mActionBar.setWindowVisibility(this.mWindowVisibility);
      if (this.mLastSystemUiVisibility != 0)
      {
        onWindowSystemUiVisibilityChanged(this.mLastSystemUiVisibility);
        requestFitSystemWindows();
      }
    }
  }

  public void setOverlayMode(boolean paramBoolean)
  {
    this.mOverlayMode = paramBoolean;
    if ((paramBoolean) && (getContext().getApplicationInfo().targetSdkVersion < 19));
    for (boolean bool = true; ; bool = false)
    {
      this.mIgnoreWindowContentOverlay = bool;
      return;
    }
  }

  public void setShowingForActionMode(boolean paramBoolean)
  {
    if (paramBoolean)
      if ((0x500 & getWindowSystemUiVisibility()) == 1280)
        setDisabledSystemUiVisibility(4);
    while (true)
    {
      return;
      setDisabledSystemUiVisibility(0);
    }
  }

  public boolean shouldDelayChildPressedState()
  {
    return false;
  }

  protected void superFitSystemWindows(Rect paramRect)
  {
    super.fitSystemWindows(paramRect);
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.widget.ActionBarOverlayLayout
 * JD-Core Version:    0.6.2
 */