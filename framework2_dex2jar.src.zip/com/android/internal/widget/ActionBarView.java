package com.android.internal.widget;

import android.animation.LayoutTransition;
import android.app.ActionBar.LayoutParams;
import android.app.ActionBar.OnNavigationListener;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.CollapsibleActionView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.Window.Callback;
import android.view.accessibility.AccessibilityEvent;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import com.android.internal.R.styleable;
import com.android.internal.transition.ActionBarTransition;
import com.android.internal.view.menu.ActionMenuItem;
import com.android.internal.view.menu.ActionMenuPresenter;
import com.android.internal.view.menu.ActionMenuView;
import com.android.internal.view.menu.MenuBuilder;
import com.android.internal.view.menu.MenuItemImpl;
import com.android.internal.view.menu.MenuPresenter;
import com.android.internal.view.menu.MenuPresenter.Callback;
import com.android.internal.view.menu.MenuView;
import com.android.internal.view.menu.SubMenuBuilder;
import java.util.List;
import miui.util.UiUtils;

public class ActionBarView extends AbsActionBarView
{
  private static final int DEFAULT_CUSTOM_GRAVITY = 8388627;
  public static final int DISPLAY_DEFAULT = 0;
  private static final int DISPLAY_RELAYOUT_MASK = 63;
  private static final String TAG = "ActionBarView";
  private ActionBar.OnNavigationListener mCallback;
  private ActionBarContextView mContextView;
  private View mCustomNavView;
  private int mDisplayOptions = -1;
  View mExpandedActionView;
  private final View.OnClickListener mExpandedActionViewUpListener = new View.OnClickListener()
  {
    public void onClick(View paramAnonymousView)
    {
      MenuItemImpl localMenuItemImpl = ActionBarView.this.mExpandedMenuPresenter.mCurrentExpandedItem;
      if (localMenuItemImpl != null)
        localMenuItemImpl.collapseActionView();
    }
  };
  private HomeView mExpandedHomeLayout;
  private ExpandedActionViewMenuPresenter mExpandedMenuPresenter;
  private CharSequence mHomeDescription;
  private int mHomeDescriptionRes;
  private HomeView mHomeLayout;
  private Drawable mIcon;
  private boolean mIncludeTabs;
  private int mIndeterminateProgressStyle;
  private ProgressBar mIndeterminateProgressView;
  private boolean mIsCollapsable;
  private boolean mIsCollapsed;
  private int mItemPadding;
  private LinearLayout mListNavLayout;
  private Drawable mLogo;
  private ActionMenuItem mLogoNavItem;
  private boolean mMenuPrepared;
  MenuPresenter.Callback mMenuPresenterCallback;
  private final AdapterView.OnItemSelectedListener mNavItemSelectedListener = new AdapterView.OnItemSelectedListener()
  {
    public void onItemSelected(AdapterView paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
    {
      if (ActionBarView.this.mCallback != null)
        ActionBarView.this.mCallback.onNavigationItemSelected(paramAnonymousInt, paramAnonymousLong);
    }

    public void onNothingSelected(AdapterView paramAnonymousAdapterView)
    {
    }
  };
  private int mNavigationMode;
  private MenuBuilder mOptionsMenu;
  private int mProgressBarPadding;
  private int mProgressStyle;
  private ProgressBar mProgressView;
  private Spinner mSpinner;
  private SpinnerAdapter mSpinnerAdapter;
  private CharSequence mSubtitle;
  private int mSubtitleStyleRes;
  private TextView mSubtitleView;
  private ScrollingTabContainerView mTabScrollView;
  private Runnable mTabSelector;
  private CharSequence mTitle;
  private ViewGroup mTitleLayout;
  private int mTitleStyleRes;
  private View mTitleUpView;
  private TextView mTitleView;
  private final View.OnClickListener mUpClickListener = new View.OnClickListener()
  {
    public void onClick(View paramAnonymousView)
    {
      if (ActionBarView.this.mMenuPrepared)
        ActionBarView.this.mWindowCallback.onMenuItemSelected(0, ActionBarView.this.mLogoNavItem);
    }
  };
  private ViewGroup mUpGoerFive;
  private boolean mUserTitle;
  private boolean mWasHomeEnabled;
  Window.Callback mWindowCallback;

  public ActionBarView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    setBackgroundResource(0);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ActionBar, 16843470, 0);
    paramContext.getApplicationInfo();
    paramContext.getPackageManager();
    this.mNavigationMode = localTypedArray.getInt(7, 0);
    this.mTitle = localTypedArray.getText(5);
    this.mSubtitle = localTypedArray.getText(9);
    this.mLogo = localTypedArray.getDrawable(6);
    this.mIcon = localTypedArray.getDrawable(0);
    LayoutInflater localLayoutInflater = LayoutInflater.from(paramContext);
    int i = localTypedArray.getResourceId(15, 17367064);
    this.mUpGoerFive = ((ViewGroup)localLayoutInflater.inflate(17367066, this, false));
    this.mHomeLayout = ((HomeView)localLayoutInflater.inflate(i, this.mUpGoerFive, false));
    this.mExpandedHomeLayout = ((HomeView)localLayoutInflater.inflate(i, this.mUpGoerFive, false));
    this.mExpandedHomeLayout.setShowUp(true);
    this.mExpandedHomeLayout.setOnClickListener(this.mExpandedActionViewUpListener);
    this.mExpandedHomeLayout.setContentDescription(getResources().getText(17040658));
    Drawable localDrawable = this.mUpGoerFive.getBackground();
    if (localDrawable != null)
      this.mExpandedHomeLayout.setBackground(localDrawable.getConstantState().newDrawable());
    this.mExpandedHomeLayout.setEnabled(true);
    this.mExpandedHomeLayout.setFocusable(true);
    this.mTitleStyleRes = localTypedArray.getResourceId(11, 0);
    this.mSubtitleStyleRes = localTypedArray.getResourceId(12, 0);
    this.mProgressStyle = localTypedArray.getResourceId(1, 0);
    this.mIndeterminateProgressStyle = localTypedArray.getResourceId(13, 0);
    this.mProgressBarPadding = localTypedArray.getDimensionPixelOffset(14, 0);
    this.mItemPadding = localTypedArray.getDimensionPixelOffset(16, 0);
    setDisplayOptions(localTypedArray.getInt(8, 0));
    int j = localTypedArray.getResourceId(10, 0);
    if (j != 0)
    {
      this.mCustomNavView = localLayoutInflater.inflate(j, this, false);
      this.mNavigationMode = 0;
      setDisplayOptions(0x10 | this.mDisplayOptions);
    }
    this.mContentHeight = localTypedArray.getLayoutDimension(4, 0);
    localTypedArray.recycle();
    this.mLogoNavItem = new ActionMenuItem(paramContext, 0, 16908332, 0, 0, this.mTitle);
    this.mUpGoerFive.setOnClickListener(this.mUpClickListener);
    this.mUpGoerFive.setClickable(true);
    this.mUpGoerFive.setFocusable(true);
    if (getImportantForAccessibility() == 0)
      setImportantForAccessibility(1);
  }

  private CharSequence buildHomeContentDescription()
  {
    CharSequence localCharSequence1;
    CharSequence localCharSequence2;
    Object localObject;
    if (this.mHomeDescription != null)
    {
      localCharSequence1 = this.mHomeDescription;
      localCharSequence2 = getTitle();
      CharSequence localCharSequence3 = getSubtitle();
      if (TextUtils.isEmpty(localCharSequence2))
        break label136;
      if (TextUtils.isEmpty(localCharSequence3))
        break label109;
      localObject = getResources().getString(17040661, new Object[] { localCharSequence2, localCharSequence3, localCharSequence1 });
    }
    while (true)
    {
      return localObject;
      if ((0x4 & this.mDisplayOptions) != 0)
      {
        localCharSequence1 = this.mContext.getResources().getText(17040658);
        break;
      }
      localCharSequence1 = this.mContext.getResources().getText(17040657);
      break;
      label109: localObject = getResources().getString(17040660, new Object[] { localCharSequence2, localCharSequence1 });
      continue;
      label136: localObject = localCharSequence1;
    }
  }

  private void configPresenters(MenuBuilder paramMenuBuilder)
  {
    if (paramMenuBuilder != null)
    {
      paramMenuBuilder.addMenuPresenter(this.mActionMenuPresenter);
      paramMenuBuilder.addMenuPresenter(this.mExpandedMenuPresenter);
    }
    while (true)
    {
      return;
      this.mActionMenuPresenter.initForMenu(this.mContext, null);
      this.mExpandedMenuPresenter.initForMenu(this.mContext, null);
      this.mActionMenuPresenter.updateMenuView(true);
      this.mExpandedMenuPresenter.updateMenuView(true);
    }
  }

  private void initTitle()
  {
    if (miuiInitTitle())
    {
      this.mUpGoerFive.addView(this.mTitleLayout);
      this.mTitleUpView = this.mTitleLayout.findViewById(101384367);
    }
    while (true)
    {
      return;
      if (this.mTitleLayout == null)
      {
        this.mTitleLayout = ((LinearLayout)LayoutInflater.from(getContext()).inflate(17367065, this, false));
        this.mTitleView = ((TextView)this.mTitleLayout.findViewById(16908901));
        this.mSubtitleView = ((TextView)this.mTitleLayout.findViewById(16908902));
        if (this.mTitleStyleRes != 0)
          this.mTitleView.setTextAppearance(this.mContext, this.mTitleStyleRes);
        if (this.mTitle != null)
          this.mTitleView.setText(this.mTitle);
        if (this.mSubtitleStyleRes != 0)
          this.mSubtitleView.setTextAppearance(this.mContext, this.mSubtitleStyleRes);
        if (this.mSubtitle != null)
        {
          this.mSubtitleView.setText(this.mSubtitle);
          this.mSubtitleView.setVisibility(0);
        }
      }
      ActionBarTransition.beginDelayedTransition(this);
      this.mUpGoerFive.addView(this.mTitleLayout);
      if ((this.mExpandedActionView != null) || ((TextUtils.isEmpty(this.mTitle)) && (TextUtils.isEmpty(this.mSubtitle))))
        this.mTitleLayout.setVisibility(8);
      else
        this.mTitleLayout.setVisibility(0);
    }
  }

  private void setHomeButtonEnabled(boolean paramBoolean1, boolean paramBoolean2)
  {
    if (paramBoolean2)
      this.mWasHomeEnabled = paramBoolean1;
    if (this.mExpandedActionView != null);
    while (true)
    {
      return;
      this.mUpGoerFive.setEnabled(paramBoolean1);
      this.mUpGoerFive.setFocusable(paramBoolean1);
      updateHomeAccessibility(paramBoolean1);
    }
  }

  private void setTitleImpl(CharSequence paramCharSequence)
  {
    int i = 0;
    ActionBarTransition.beginDelayedTransition(this);
    this.mTitle = paramCharSequence;
    int j;
    ViewGroup localViewGroup;
    if (this.mTitleView != null)
    {
      this.mTitleView.setText(paramCharSequence);
      if ((this.mExpandedActionView != null) || ((0x8 & this.mDisplayOptions) == 0) || ((TextUtils.isEmpty(this.mTitle)) && (TextUtils.isEmpty(this.mSubtitle))))
        break label111;
      j = 1;
      localViewGroup = this.mTitleLayout;
      if (j == 0)
        break label117;
    }
    while (true)
    {
      localViewGroup.setVisibility(i);
      if (this.mLogoNavItem != null)
        this.mLogoNavItem.setTitle(paramCharSequence);
      updateHomeAccessibility(this.mUpGoerFive.isEnabled());
      return;
      label111: j = 0;
      break;
      label117: i = 8;
    }
  }

  private void updateHomeAccessibility(boolean paramBoolean)
  {
    if (!paramBoolean)
    {
      this.mUpGoerFive.setContentDescription(null);
      this.mUpGoerFive.setImportantForAccessibility(2);
    }
    while (true)
    {
      return;
      this.mUpGoerFive.setImportantForAccessibility(0);
      this.mUpGoerFive.setContentDescription(buildHomeContentDescription());
    }
  }

  public void collapseActionView()
  {
    if (this.mExpandedMenuPresenter == null);
    for (MenuItemImpl localMenuItemImpl = null; ; localMenuItemImpl = this.mExpandedMenuPresenter.mCurrentExpandedItem)
    {
      if (localMenuItemImpl != null)
        localMenuItemImpl.collapseActionView();
      return;
    }
  }

  protected ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    return new ActionBar.LayoutParams(8388627);
  }

  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new ActionBar.LayoutParams(getContext(), paramAttributeSet);
  }

  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    if (paramLayoutParams == null)
      paramLayoutParams = generateDefaultLayoutParams();
    return paramLayoutParams;
  }

  public View getCustomNavigationView()
  {
    return this.mCustomNavView;
  }

  public int getDisplayOptions()
  {
    return this.mDisplayOptions;
  }

  public SpinnerAdapter getDropdownAdapter()
  {
    return this.mSpinnerAdapter;
  }

  public int getDropdownSelectedPosition()
  {
    return this.mSpinner.getSelectedItemPosition();
  }

  public View getExpandedActionView()
  {
    return this.mExpandedActionView;
  }

  public int getNavigationMode()
  {
    return this.mNavigationMode;
  }

  public CharSequence getSubtitle()
  {
    return this.mSubtitle;
  }

  public int getSubtitleStyleRes()
  {
    return this.mSubtitleStyleRes;
  }

  public TextView getSubtitleView()
  {
    return this.mSubtitleView;
  }

  public ScrollingTabContainerView getTabScrollView()
  {
    return this.mTabScrollView;
  }

  public CharSequence getTitle()
  {
    return this.mTitle;
  }

  public ViewGroup getTitleLayout()
  {
    return this.mTitleLayout;
  }

  public int getTitleStyleRes()
  {
    return this.mTitleStyleRes;
  }

  public TextView getTitleView()
  {
    return this.mTitleView;
  }

  public View.OnClickListener getUpClickListener()
  {
    return this.mUpClickListener;
  }

  public boolean hasEmbeddedTabs()
  {
    return this.mIncludeTabs;
  }

  public boolean hasExpandedActionView()
  {
    if ((this.mExpandedMenuPresenter != null) && (this.mExpandedMenuPresenter.mCurrentExpandedItem != null));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean hasIcon()
  {
    if (this.mIcon != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean hasLogo()
  {
    if (this.mLogo != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void initIndeterminateProgress()
  {
    this.mIndeterminateProgressView = new ProgressBar(this.mContext, null, 0, this.mIndeterminateProgressStyle);
    this.mIndeterminateProgressView.setId(16909093);
    this.mIndeterminateProgressView.setVisibility(8);
    addView(this.mIndeterminateProgressView);
  }

  public void initProgress()
  {
    this.mProgressView = new ProgressBar(this.mContext, null, 0, this.mProgressStyle);
    this.mProgressView.setId(16909094);
    this.mProgressView.setMax(10000);
    this.mProgressView.setVisibility(8);
    addView(this.mProgressView);
  }

  public boolean isCollapsed()
  {
    return this.mIsCollapsed;
  }

  public boolean isSplitActionBar()
  {
    return this.mSplitActionBar;
  }

  public boolean isTitleTruncated()
  {
    boolean bool = false;
    if (this.mTitleView == null);
    label55: 
    while (true)
    {
      return bool;
      Layout localLayout = this.mTitleView.getLayout();
      if (localLayout != null)
      {
        int i = localLayout.getLineCount();
        for (int j = 0; ; j++)
        {
          if (j >= i)
            break label55;
          if (localLayout.getEllipsisCount(j) > 0)
          {
            bool = true;
            break;
          }
        }
      }
    }
  }

  protected boolean miuiInitTitle()
  {
    return UiUtils.isV5Ui(this.mContext);
  }

  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    this.mTitleView = null;
    this.mSubtitleView = null;
    this.mTitleUpView = null;
    if ((this.mTitleLayout != null) && (this.mTitleLayout.getParent() == this.mUpGoerFive))
      this.mUpGoerFive.removeView(this.mTitleLayout);
    this.mTitleLayout = null;
    if ((0x8 & this.mDisplayOptions) != 0)
      initTitle();
    if (this.mHomeDescriptionRes != 0)
      setHomeActionContentDescription(this.mHomeDescriptionRes);
    if ((this.mTabScrollView != null) && (this.mIncludeTabs))
    {
      ViewGroup.LayoutParams localLayoutParams = this.mTabScrollView.getLayoutParams();
      if (localLayoutParams != null)
      {
        localLayoutParams.width = -2;
        localLayoutParams.height = -1;
      }
      this.mTabScrollView.setAllowCollapse(true);
    }
  }

  public void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    removeCallbacks(this.mTabSelector);
    if (this.mActionMenuPresenter != null)
    {
      this.mActionMenuPresenter.hideOverflowMenu();
      this.mActionMenuPresenter.hideSubMenus();
    }
  }

  protected void onFinishInflate()
  {
    super.onFinishInflate();
    this.mUpGoerFive.addView(this.mHomeLayout, 0);
    addView(this.mUpGoerFive);
    if ((this.mCustomNavView != null) && ((0x10 & this.mDisplayOptions) != 0))
    {
      ViewParent localViewParent = this.mCustomNavView.getParent();
      if (localViewParent != this)
      {
        if ((localViewParent instanceof ViewGroup))
          ((ViewGroup)localViewParent).removeView(this.mCustomNavView);
        addView(this.mCustomNavView);
      }
    }
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    if (i <= 0)
      return;
    boolean bool1 = isLayoutRtl();
    int j;
    label36: int k;
    label47: int m;
    label63: int n;
    HomeView localHomeView;
    label82: int i1;
    label114: int i2;
    label146: int i3;
    label220: boolean bool3;
    label252: boolean bool2;
    label315: View localView;
    label361: ActionBar.LayoutParams localLayoutParams1;
    label394: int i6;
    label406: int i7;
    int i8;
    int i9;
    int i10;
    int i18;
    label513: int i11;
    label556: int i13;
    if (bool1)
    {
      j = 1;
      if (!bool1)
        break label721;
      k = getPaddingLeft();
      if (!bool1)
        break label735;
      m = paramInt3 - paramInt1 - getPaddingRight();
      n = getPaddingTop();
      if (this.mExpandedActionView == null)
        break label744;
      localHomeView = this.mExpandedHomeLayout;
      if ((this.mTitleLayout == null) || (this.mTitleLayout.getVisibility() == 8) || ((0x8 & this.mDisplayOptions) == 0))
        break label753;
      i1 = 1;
      i2 = 0;
      if (localHomeView.getParent() == this.mUpGoerFive)
      {
        if (localHomeView.getVisibility() == 8)
          break label759;
        i2 = localHomeView.getStartOffset();
      }
      i3 = next(m + positionChild(this.mUpGoerFive, next(m, i2, bool1), n, i, bool1), i2, bool1);
      if (this.mExpandedActionView == null);
      switch (this.mNavigationMode)
      {
      case 0:
      default:
        if ((this.mMenuView != null) && (this.mMenuView.getParent() == this))
        {
          ActionMenuView localActionMenuView = this.mMenuView;
          if (!bool1)
          {
            bool3 = true;
            positionChild(localActionMenuView, k, n, i, bool3);
            k += j * this.mMenuView.getMeasuredWidth();
          }
        }
        else
        {
          if ((this.mIndeterminateProgressView != null) && (this.mIndeterminateProgressView.getVisibility() != 8))
          {
            ProgressBar localProgressBar = this.mIndeterminateProgressView;
            if (bool1)
              break label896;
            bool2 = true;
            positionChild(localProgressBar, k, n, i, bool2);
            k += j * this.mIndeterminateProgressView.getMeasuredWidth();
          }
          localView = null;
          if (this.mExpandedActionView == null)
            break label902;
          localView = this.mExpandedActionView;
          if (localView != null)
          {
            int i5 = getLayoutDirection();
            ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
            if (!(localLayoutParams instanceof ActionBar.LayoutParams))
              break label928;
            localLayoutParams1 = (ActionBar.LayoutParams)localLayoutParams;
            if (localLayoutParams1 == null)
              break label934;
            i6 = localLayoutParams1.gravity;
            i7 = localView.getMeasuredWidth();
            i8 = 0;
            i9 = 0;
            if (localLayoutParams1 != null)
            {
              i3 = next(i3, localLayoutParams1.getMarginStart(), bool1);
              k += j * localLayoutParams1.getMarginEnd();
              i8 = localLayoutParams1.topMargin;
              i9 = localLayoutParams1.bottomMargin;
            }
            i10 = i6 & 0x800007;
            if (i10 != 1)
              break label987;
            i18 = (this.mRight - this.mLeft - i7) / 2;
            if (!bool1)
              break label954;
            if (i18 + i7 <= i3)
              break label941;
            i10 = 5;
            i11 = 0;
            switch (Gravity.getAbsoluteGravity(i10, i5))
            {
            case 2:
            case 4:
            default:
              int i12 = i6 & 0x70;
              if (i6 == 0)
                i12 = 16;
              i13 = 0;
              switch (i12)
              {
              default:
              case 16:
              case 48:
              case 80:
              }
              break;
            case 1:
            case 3:
            case 5:
            }
          }
        }
        break;
      case 1:
      case 2:
      }
    }
    while (true)
    {
      int i14 = localView.getMeasuredWidth();
      int i15 = i11 + i14;
      int i16 = i13 + localView.getMeasuredHeight();
      localView.layout(i11, i13, i15, i16);
      next(i3, i14, bool1);
      if (this.mProgressView == null)
        break;
      this.mProgressView.bringToFront();
      int i4 = this.mProgressView.getMeasuredHeight() / 2;
      this.mProgressView.layout(this.mProgressBarPadding, -i4, this.mProgressBarPadding + this.mProgressView.getMeasuredWidth(), i4);
      break;
      j = -1;
      break label36;
      label721: k = paramInt3 - paramInt1 - getPaddingRight();
      break label47;
      label735: m = getPaddingLeft();
      break label63;
      label744: localHomeView = this.mHomeLayout;
      break label82;
      label753: i1 = 0;
      break label114;
      label759: if (i1 == 0)
        break label146;
      i2 = localHomeView.getUpWidth();
      break label146;
      if (this.mListNavLayout == null)
        break label220;
      if (i1 != 0)
        i3 = next(i3, this.mItemPadding, bool1);
      i3 = next(i3 + positionChild(this.mListNavLayout, i3, n, i, bool1), this.mItemPadding, bool1);
      break label220;
      if (this.mTabScrollView == null)
        break label220;
      if (i1 != 0)
        i3 = next(i3, this.mItemPadding, bool1);
      i3 = next(i3 + positionChild(this.mTabScrollView, i3, n, i, bool1), this.mItemPadding, bool1);
      break label220;
      bool3 = false;
      break label252;
      label896: bool2 = false;
      break label315;
      label902: if (((0x10 & this.mDisplayOptions) == 0) || (this.mCustomNavView == null))
        break label361;
      localView = this.mCustomNavView;
      break label361;
      label928: localLayoutParams1 = null;
      break label394;
      label934: i6 = 8388627;
      break label406;
      label941: if (i18 >= k)
        break label513;
      i10 = 3;
      break label513;
      label954: int i19 = i18 + i7;
      if (i18 < i3)
      {
        i10 = 3;
        break label513;
      }
      if (i19 <= k)
        break label513;
      i10 = 5;
      break label513;
      label987: if (i6 != 0)
        break label513;
      i10 = 8388611;
      break label513;
      i11 = (this.mRight - this.mLeft - i7) / 2;
      break label556;
      if (bool1);
      for (i11 = k; ; i11 = i3)
        break;
      if (bool1);
      for (i11 = i3 - i7; ; i11 = k - i7)
        break;
      int i17 = getPaddingTop();
      i13 = (this.mBottom - this.mTop - getPaddingBottom() - i17 - localView.getMeasuredHeight()) / 2;
      continue;
      i13 = i8 + getPaddingTop();
      continue;
      i13 = getHeight() - getPaddingBottom() - localView.getMeasuredHeight() - i9;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int i = getChildCount();
    if (Injector.ActionBarViewHook.isCollapsable(this, this.mIsCollapsable))
    {
      int i31 = 0;
      for (int i32 = 0; i32 < i; i32++)
      {
        View localView2 = getChildAt(i32);
        if ((localView2.getVisibility() != 8) && ((localView2 != this.mMenuView) || (Injector.ActionBarViewHook.getMenuItemCount(this.mMenuView) != 0)) && (localView2 != this.mUpGoerFive))
          i31++;
      }
      int i33 = this.mUpGoerFive.getChildCount();
      for (int i34 = 0; i34 < i33; i34++)
        if (this.mUpGoerFive.getChildAt(i34).getVisibility() != 8)
          i31++;
      if (i31 == 0)
      {
        setMeasuredDimension(0, 0);
        this.mIsCollapsed = true;
        return;
      }
    }
    this.mIsCollapsed = false;
    if (View.MeasureSpec.getMode(paramInt1) != 1073741824)
      throw new IllegalStateException(getClass().getSimpleName() + " can only be used " + "with android:layout_width=\"match_parent\" (or fill_parent)");
    if (View.MeasureSpec.getMode(paramInt2) != -2147483648)
      throw new IllegalStateException(getClass().getSimpleName() + " can only be used " + "with android:layout_height=\"wrap_content\"");
    int j = View.MeasureSpec.getSize(paramInt1);
    int k;
    int m;
    int i2;
    int i5;
    int i6;
    int i7;
    int i8;
    label371: HomeView localHomeView;
    label384: ViewGroup.LayoutParams localLayoutParams1;
    int i9;
    label409: int i10;
    label620: View localView1;
    label636: ViewGroup.LayoutParams localLayoutParams2;
    ActionBar.LayoutParams localLayoutParams;
    label667: int i14;
    int i16;
    int i17;
    int i18;
    label762: int i19;
    label782: int i20;
    if (this.mContentHeight >= 0)
    {
      k = this.mContentHeight;
      m = getPaddingTop() + getPaddingBottom();
      int n = getPaddingLeft();
      int i1 = getPaddingRight();
      i2 = k - m;
      int i3 = View.MeasureSpec.makeMeasureSpec(i2, -2147483648);
      int i4 = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
      i5 = j - n - i1;
      i6 = i5 / 2;
      i7 = i6;
      if ((this.mTitleLayout == null) || (this.mTitleLayout.getVisibility() == 8) || ((0x8 & this.mDisplayOptions) == 0))
        break label972;
      i8 = 1;
      if (this.mExpandedActionView == null)
        break label978;
      localHomeView = this.mExpandedHomeLayout;
      localLayoutParams1 = localHomeView.getLayoutParams();
      if (localLayoutParams1.width >= 0)
        break label987;
      i9 = View.MeasureSpec.makeMeasureSpec(i5, -2147483648);
      localHomeView.measure(i9, i4);
      i10 = 0;
      if (((localHomeView.getVisibility() != 8) && (localHomeView.getParent() == this.mUpGoerFive)) || (i8 != 0))
      {
        i10 = localHomeView.getMeasuredWidth();
        int i30 = i10 + localHomeView.getStartOffset();
        i5 = Math.max(0, i5 - i30);
        i6 = Math.max(0, i5 - i30);
      }
      if ((this.mMenuView != null) && (this.mMenuView.getParent() == this))
      {
        i5 = measureChildView(this.mMenuView, i5, i4, 0);
        i7 = Math.max(0, i7 - this.mMenuView.getMeasuredWidth());
      }
      if ((this.mIndeterminateProgressView != null) && (this.mIndeterminateProgressView.getVisibility() != 8))
      {
        i5 = measureChildView(this.mIndeterminateProgressView, i5, i3, 0);
        i7 = Math.max(0, i7 - this.mIndeterminateProgressView.getMeasuredWidth());
      }
      if (this.mExpandedActionView == null);
      switch (this.mNavigationMode)
      {
      default:
        localView1 = null;
        if (this.mExpandedActionView != null)
        {
          localView1 = this.mExpandedActionView;
          if (localView1 != null)
          {
            localLayoutParams2 = generateLayoutParams(localView1.getLayoutParams());
            if (!(localLayoutParams2 instanceof ActionBar.LayoutParams))
              break label1245;
            localLayoutParams = (ActionBar.LayoutParams)localLayoutParams2;
            i14 = 0;
            int i15 = 0;
            if (localLayoutParams != null)
            {
              i14 = localLayoutParams.leftMargin + localLayoutParams.rightMargin;
              i15 = localLayoutParams.topMargin + localLayoutParams.bottomMargin;
            }
            if (this.mContentHeight > 0)
              break label1251;
            i16 = -2147483648;
            if (localLayoutParams2.height >= 0)
              i2 = Math.min(localLayoutParams2.height, i2);
            i17 = Math.max(0, i2 - i15);
            if (localLayoutParams2.width == -2)
              break label1277;
            i18 = 1073741824;
            if (localLayoutParams2.width < 0)
              break label1285;
            i19 = Math.min(localLayoutParams2.width, i5);
            i20 = Math.max(0, i19 - i14);
            if (localLayoutParams == null)
              break label1292;
          }
        }
        break;
      case 1:
      case 2:
      }
    }
    int i11;
    label1285: label1292: for (int i21 = localLayoutParams.gravity; ; i21 = 8388627)
    {
      if (((i21 & 0x7) == 1) && (localLayoutParams2.width == -1))
        i20 = 2 * Math.min(i6, i7);
      localView1.measure(View.MeasureSpec.makeMeasureSpec(i20, i18), View.MeasureSpec.makeMeasureSpec(i17, i16));
      i5 -= i14 + localView1.getMeasuredWidth();
      measureChildView(this.mUpGoerFive, i5 + i10, View.MeasureSpec.makeMeasureSpec(this.mContentHeight, 1073741824), 0);
      if (this.mTitleLayout != null)
        Math.max(0, i6 - this.mTitleLayout.getMeasuredWidth());
      if (this.mContentHeight > 0)
        break label1379;
      i11 = 0;
      for (int i12 = 0; i12 < i; i12++)
      {
        int i13 = m + getChildAt(i12).getMeasuredHeight();
        if (i13 > i11)
          i11 = i13;
      }
      k = View.MeasureSpec.getSize(paramInt2);
      break;
      label972: i8 = 0;
      break label371;
      label978: localHomeView = this.mHomeLayout;
      break label384;
      label987: i9 = View.MeasureSpec.makeMeasureSpec(localLayoutParams1.width, 1073741824);
      break label409;
      if (this.mListNavLayout == null)
        break label620;
      if (i8 != 0);
      for (int i26 = 2 * this.mItemPadding; ; i26 = this.mItemPadding)
      {
        int i27 = Math.max(0, i5 - i26);
        int i28 = Math.max(0, i6 - i26);
        this.mListNavLayout.measure(View.MeasureSpec.makeMeasureSpec(i27, -2147483648), View.MeasureSpec.makeMeasureSpec(i2, 1073741824));
        int i29 = this.mListNavLayout.getMeasuredWidth();
        i5 = Math.max(0, i27 - i29);
        i6 = Math.max(0, i28 - i29);
        break;
      }
      if (this.mTabScrollView == null)
        break label620;
      if (i8 != 0);
      for (int i22 = 2 * this.mItemPadding; ; i22 = this.mItemPadding)
      {
        int i23 = Math.max(0, i5 - i22);
        int i24 = Math.max(0, i6 - i22);
        this.mTabScrollView.measure(View.MeasureSpec.makeMeasureSpec(i23, -2147483648), View.MeasureSpec.makeMeasureSpec(i2, 1073741824));
        int i25 = this.mTabScrollView.getMeasuredWidth();
        i5 = Math.max(0, i23 - i25);
        i6 = Math.max(0, i24 - i25);
        break;
      }
      if (((0x10 & this.mDisplayOptions) == 0) || (this.mCustomNavView == null))
        break label636;
      localView1 = this.mCustomNavView;
      break label636;
      label1245: localLayoutParams = null;
      break label667;
      label1251: if (localLayoutParams2.height != -2);
      for (i16 = 1073741824; ; i16 = -2147483648)
        break;
      label1277: i18 = -2147483648;
      break label762;
      i19 = i5;
      break label782;
    }
    setMeasuredDimension(j, i11);
    while (true)
    {
      if (this.mContextView != null)
        this.mContextView.setContentHeight(getMeasuredHeight());
      if ((this.mProgressView == null) || (this.mProgressView.getVisibility() == 8))
        break;
      this.mProgressView.measure(View.MeasureSpec.makeMeasureSpec(j - 2 * this.mProgressBarPadding, 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), -2147483648));
      break;
      label1379: setMeasuredDimension(j, k);
    }
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    if ((localSavedState.expandedMenuItemId != 0) && (this.mExpandedMenuPresenter != null) && (this.mOptionsMenu != null))
    {
      MenuItem localMenuItem = this.mOptionsMenu.findItem(localSavedState.expandedMenuItemId);
      if (localMenuItem != null)
        localMenuItem.expandActionView();
    }
    if (localSavedState.isOverflowOpen)
      postShowOverflowMenu();
  }

  public Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    if ((this.mExpandedMenuPresenter != null) && (this.mExpandedMenuPresenter.mCurrentExpandedItem != null))
      localSavedState.expandedMenuItemId = this.mExpandedMenuPresenter.mCurrentExpandedItem.getItemId();
    localSavedState.isOverflowOpen = isOverflowMenuShowing();
    return localSavedState;
  }

  public void onWindowHide()
  {
    if ((this.mSplitView instanceof com.miui.internal.v5.widget.ActionBarContainer))
      ((com.miui.internal.v5.widget.ActionBarContainer)this.mSplitView).onWindowHide();
  }

  public void onWindowShow()
  {
    if ((this.mSplitView instanceof com.miui.internal.v5.widget.ActionBarContainer))
      ((com.miui.internal.v5.widget.ActionBarContainer)this.mSplitView).onWindowShow();
  }

  public void setCallback(ActionBar.OnNavigationListener paramOnNavigationListener)
  {
    this.mCallback = paramOnNavigationListener;
  }

  public void setCollapsable(boolean paramBoolean)
  {
    this.mIsCollapsable = paramBoolean;
  }

  public void setContextView(ActionBarContextView paramActionBarContextView)
  {
    this.mContextView = paramActionBarContextView;
  }

  public void setCustomNavigationView(View paramView)
  {
    if ((0x10 & this.mDisplayOptions) != 0);
    for (int i = 1; ; i = 0)
    {
      if (i != 0)
        ActionBarTransition.beginDelayedTransition(this);
      if ((this.mCustomNavView != null) && (i != 0))
        removeView(this.mCustomNavView);
      this.mCustomNavView = paramView;
      if ((this.mCustomNavView != null) && (i != 0))
        addView(this.mCustomNavView);
      return;
    }
  }

  public void setDisplayOptions(int paramInt)
  {
    int i = -1;
    boolean bool2;
    label41: int n;
    label82: Drawable localDrawable;
    label99: label124: boolean bool1;
    label132: int j;
    label144: int k;
    label156: int m;
    if (this.mDisplayOptions == i)
    {
      this.mDisplayOptions = paramInt;
      if ((i & 0x3F) == 0)
        break label380;
      ActionBarTransition.beginDelayedTransition(this);
      if ((i & 0x4) != 0)
      {
        if ((paramInt & 0x4) == 0)
          break label291;
        bool2 = true;
        this.mHomeLayout.setShowUp(bool2);
        if (bool2)
          setHomeButtonEnabled(true);
      }
      if ((i & 0x1) != 0)
      {
        if ((this.mLogo == null) || ((paramInt & 0x1) == 0))
          break label297;
        n = 1;
        HomeView localHomeView = this.mHomeLayout;
        if (n == 0)
          break label303;
        localDrawable = this.mLogo;
        localHomeView.setIcon(localDrawable);
      }
      if ((i & 0x8) != 0)
      {
        if ((paramInt & 0x8) == 0)
          break label312;
        initTitle();
      }
      if ((paramInt & 0x2) == 0)
        break label326;
      bool1 = true;
      if ((0x4 & this.mDisplayOptions) == 0)
        break label331;
      j = 1;
      if ((bool1) || (j == 0))
        break label337;
      k = 1;
      this.mHomeLayout.setShowIcon(bool1);
      if (((!bool1) && (k == 0)) || (this.mExpandedActionView != null))
        break label343;
      m = 0;
      label183: this.mHomeLayout.setVisibility(m);
      if (((i & 0x10) != 0) && (this.mCustomNavView != null))
      {
        if ((paramInt & 0x10) == 0)
          break label350;
        addView(this.mCustomNavView);
      }
      label221: if ((Injector.ActionBarViewHook.checkTitleLayout(this.mTitleLayout, this.mTitleView)) && ((i & 0x20) != 0))
      {
        if ((paramInt & 0x20) == 0)
          break label361;
        this.mTitleView.setSingleLine(false);
        this.mTitleView.setMaxLines(2);
      }
      label265: requestLayout();
    }
    while (true)
    {
      updateHomeAccessibility(this.mUpGoerFive.isEnabled());
      return;
      i = paramInt ^ this.mDisplayOptions;
      break;
      label291: bool2 = false;
      break label41;
      label297: n = 0;
      break label82;
      label303: localDrawable = this.mIcon;
      break label99;
      label312: this.mUpGoerFive.removeView(this.mTitleLayout);
      break label124;
      label326: bool1 = false;
      break label132;
      label331: j = 0;
      break label144;
      label337: k = 0;
      break label156;
      label343: m = 8;
      break label183;
      label350: removeView(this.mCustomNavView);
      break label221;
      label361: this.mTitleView.setMaxLines(1);
      this.mTitleView.setSingleLine(true);
      break label265;
      label380: invalidate();
    }
  }

  public void setDropdownAdapter(SpinnerAdapter paramSpinnerAdapter)
  {
    this.mSpinnerAdapter = paramSpinnerAdapter;
    if (this.mSpinner != null)
      this.mSpinner.setAdapter(paramSpinnerAdapter);
  }

  public void setDropdownSelectedPosition(int paramInt)
  {
    this.mSpinner.setSelection(paramInt);
  }

  public void setEmbeddedTabView(ScrollingTabContainerView paramScrollingTabContainerView)
  {
    if (this.mTabScrollView != null)
      removeView(this.mTabScrollView);
    this.mTabScrollView = paramScrollingTabContainerView;
    if (paramScrollingTabContainerView != null);
    for (boolean bool = true; ; bool = false)
    {
      this.mIncludeTabs = bool;
      if ((this.mIncludeTabs) && (this.mNavigationMode == 2))
      {
        addView(this.mTabScrollView);
        ViewGroup.LayoutParams localLayoutParams = this.mTabScrollView.getLayoutParams();
        localLayoutParams.width = -2;
        localLayoutParams.height = -1;
        paramScrollingTabContainerView.setAllowCollapse(true);
      }
      return;
    }
  }

  public void setHomeActionContentDescription(int paramInt)
  {
    this.mHomeDescriptionRes = paramInt;
    if (paramInt != 0);
    for (CharSequence localCharSequence = getResources().getText(paramInt); ; localCharSequence = null)
    {
      this.mHomeDescription = localCharSequence;
      updateHomeAccessibility(this.mUpGoerFive.isEnabled());
      return;
    }
  }

  public void setHomeActionContentDescription(CharSequence paramCharSequence)
  {
    this.mHomeDescription = paramCharSequence;
    updateHomeAccessibility(this.mUpGoerFive.isEnabled());
  }

  public void setHomeAsUpIndicator(int paramInt)
  {
    this.mHomeLayout.setUpIndicator(paramInt);
  }

  public void setHomeAsUpIndicator(Drawable paramDrawable)
  {
    this.mHomeLayout.setUpIndicator(paramDrawable);
  }

  public void setHomeButtonEnabled(boolean paramBoolean)
  {
    setHomeButtonEnabled(paramBoolean, true);
  }

  public void setIcon(int paramInt)
  {
    if (paramInt != 0);
    for (Drawable localDrawable = this.mContext.getResources().getDrawable(paramInt); ; localDrawable = null)
    {
      setIcon(localDrawable);
      return;
    }
  }

  public void setIcon(Drawable paramDrawable)
  {
    this.mIcon = paramDrawable;
    if ((paramDrawable != null) && (((0x1 & this.mDisplayOptions) == 0) || (this.mLogo == null)))
      this.mHomeLayout.setIcon(paramDrawable);
    if (this.mExpandedActionView != null)
      this.mExpandedHomeLayout.setIcon(this.mIcon.getConstantState().newDrawable(getResources()));
  }

  public void setLogo(int paramInt)
  {
    if (paramInt != 0);
    for (Drawable localDrawable = this.mContext.getResources().getDrawable(paramInt); ; localDrawable = null)
    {
      setLogo(localDrawable);
      return;
    }
  }

  public void setLogo(Drawable paramDrawable)
  {
    this.mLogo = paramDrawable;
    if ((paramDrawable != null) && ((0x1 & this.mDisplayOptions) != 0))
      this.mHomeLayout.setIcon(paramDrawable);
  }

  public void setMenu(Menu paramMenu, MenuPresenter.Callback paramCallback)
  {
    if (paramMenu == this.mOptionsMenu)
      return;
    if (this.mOptionsMenu != null)
    {
      this.mOptionsMenu.removeMenuPresenter(this.mActionMenuPresenter);
      this.mOptionsMenu.removeMenuPresenter(this.mExpandedMenuPresenter);
    }
    MenuBuilder localMenuBuilder = (MenuBuilder)paramMenu;
    this.mOptionsMenu = localMenuBuilder;
    if (this.mMenuView != null)
    {
      ViewGroup localViewGroup3 = (ViewGroup)this.mMenuView.getParent();
      if (localViewGroup3 != null)
        localViewGroup3.removeView(this.mMenuView);
    }
    if (this.mActionMenuPresenter == null)
    {
      this.mActionMenuPresenter = Injector.ActionBarViewHook.createActionMenuPresenter(this.mContext);
      this.mActionMenuPresenter.setCallback(paramCallback);
      this.mActionMenuPresenter.setId(16908894);
      this.mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter(null);
    }
    ViewGroup.LayoutParams localLayoutParams = new ViewGroup.LayoutParams(-2, -1);
    ActionMenuView localActionMenuView;
    if (!this.mSplitActionBar)
    {
      this.mActionMenuPresenter.setExpandedActionViewsExclusive(getResources().getBoolean(17891337));
      configPresenters(localMenuBuilder);
      localActionMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
      ViewGroup localViewGroup2 = (ViewGroup)localActionMenuView.getParent();
      if ((localViewGroup2 != null) && (localViewGroup2 != this))
        localViewGroup2.removeView(localActionMenuView);
      addView(localActionMenuView, localLayoutParams);
    }
    while (true)
    {
      this.mMenuView = localActionMenuView;
      break;
      this.mActionMenuPresenter.setExpandedActionViewsExclusive(false);
      this.mActionMenuPresenter.setWidthLimit(getContext().getResources().getDisplayMetrics().widthPixels, true);
      this.mActionMenuPresenter.setItemLimit(2147483647);
      localLayoutParams.width = -1;
      configPresenters(localMenuBuilder);
      localActionMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
      if (this.mSplitView != null)
      {
        ViewGroup localViewGroup1 = (ViewGroup)localActionMenuView.getParent();
        if ((localViewGroup1 != null) && (localViewGroup1 != this.mSplitView))
          localViewGroup1.removeView(localActionMenuView);
        localActionMenuView.setVisibility(getAnimatedVisibility());
        this.mSplitView.addView(localActionMenuView, localLayoutParams);
      }
      else
      {
        localActionMenuView.setLayoutParams(localLayoutParams);
      }
    }
  }

  public void setMenuPrepared()
  {
    this.mMenuPrepared = true;
  }

  public void setNavigationMode(int paramInt)
  {
    int i = this.mNavigationMode;
    if (paramInt != i)
    {
      ActionBarTransition.beginDelayedTransition(this);
      switch (i)
      {
      default:
        switch (paramInt)
        {
        default:
        case 1:
        case 2:
        }
        break;
      case 1:
      case 2:
      }
    }
    while (true)
    {
      this.mNavigationMode = paramInt;
      requestLayout();
      return;
      if (this.mListNavLayout == null)
        break;
      removeView(this.mListNavLayout);
      break;
      if ((this.mTabScrollView == null) || (!this.mIncludeTabs))
        break;
      removeView(this.mTabScrollView);
      break;
      if (this.mSpinner == null)
      {
        this.mSpinner = new Spinner(this.mContext, null, 16843479);
        this.mSpinner.setId(16908897);
        this.mListNavLayout = new LinearLayout(this.mContext, null, 16843508);
        LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -1);
        localLayoutParams.gravity = 17;
        this.mListNavLayout.addView(this.mSpinner, localLayoutParams);
      }
      if (this.mSpinner.getAdapter() != this.mSpinnerAdapter)
        this.mSpinner.setAdapter(this.mSpinnerAdapter);
      this.mSpinner.setOnItemSelectedListener(this.mNavItemSelectedListener);
      addView(this.mListNavLayout);
      continue;
      if ((this.mTabScrollView != null) && (this.mIncludeTabs))
        addView(this.mTabScrollView);
    }
  }

  public void setSplitActionBar(boolean paramBoolean)
  {
    int i;
    if (this.mSplitActionBar != paramBoolean)
    {
      if (this.mMenuView != null)
      {
        ViewGroup localViewGroup = (ViewGroup)this.mMenuView.getParent();
        if (localViewGroup != null)
          localViewGroup.removeView(this.mMenuView);
        if (!paramBoolean)
          break label138;
        if (this.mSplitView != null)
          this.mSplitView.addView(this.mMenuView);
        this.mMenuView.getLayoutParams().width = -1;
        this.mMenuView.requestLayout();
      }
      if (this.mSplitView != null)
      {
        ActionBarContainer localActionBarContainer = this.mSplitView;
        if (!paramBoolean)
          break label161;
        i = 0;
        label99: localActionBarContainer.setVisibility(i);
      }
      if (this.mActionMenuPresenter != null)
      {
        if (paramBoolean)
          break label167;
        this.mActionMenuPresenter.setExpandedActionViewsExclusive(getResources().getBoolean(17891337));
      }
    }
    while (true)
    {
      super.setSplitActionBar(paramBoolean);
      return;
      label138: addView(this.mMenuView);
      this.mMenuView.getLayoutParams().width = -2;
      break;
      label161: i = 8;
      break label99;
      label167: this.mActionMenuPresenter.setExpandedActionViewsExclusive(false);
      this.mActionMenuPresenter.setWidthLimit(getContext().getResources().getDisplayMetrics().widthPixels, true);
      this.mActionMenuPresenter.setItemLimit(2147483647);
    }
  }

  public void setSubtitle(CharSequence paramCharSequence)
  {
    int i = 0;
    ActionBarTransition.beginDelayedTransition(this);
    this.mSubtitle = paramCharSequence;
    int j;
    int k;
    label84: ViewGroup localViewGroup;
    if (this.mSubtitleView != null)
    {
      this.mSubtitleView.setText(paramCharSequence);
      TextView localTextView = this.mSubtitleView;
      if (paramCharSequence == null)
        break label113;
      j = 0;
      localTextView.setVisibility(j);
      if ((this.mExpandedActionView != null) || ((0x8 & this.mDisplayOptions) == 0) || ((TextUtils.isEmpty(this.mTitle)) && (TextUtils.isEmpty(this.mSubtitle))))
        break label120;
      k = 1;
      localViewGroup = this.mTitleLayout;
      if (k == 0)
        break label126;
    }
    while (true)
    {
      localViewGroup.setVisibility(i);
      updateHomeAccessibility(this.mUpGoerFive.isEnabled());
      return;
      label113: j = 8;
      break;
      label120: k = 0;
      break label84;
      label126: i = 8;
    }
  }

  public void setSubtitleView(TextView paramTextView)
  {
    this.mSubtitleView = paramTextView;
  }

  public void setTitle(CharSequence paramCharSequence)
  {
    this.mUserTitle = true;
    setTitleImpl(paramCharSequence);
  }

  public void setTitleLayout(ViewGroup paramViewGroup)
  {
    this.mTitleLayout = paramViewGroup;
  }

  public void setTitleView(TextView paramTextView)
  {
    this.mTitleView = paramTextView;
  }

  public void setWindowCallback(Window.Callback paramCallback)
  {
    this.mWindowCallback = paramCallback;
  }

  public void setWindowTitle(CharSequence paramCharSequence)
  {
    if (!this.mUserTitle)
      setTitleImpl(paramCharSequence);
  }

  public boolean shouldDelayChildPressedState()
  {
    return false;
  }

  private class ExpandedActionViewMenuPresenter
    implements MenuPresenter
  {
    MenuItemImpl mCurrentExpandedItem;
    MenuBuilder mMenu;

    private ExpandedActionViewMenuPresenter()
    {
    }

    public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
    {
      ActionBarTransition.beginDelayedTransition(ActionBarView.this);
      if ((ActionBarView.this.mExpandedActionView instanceof CollapsibleActionView))
        ((CollapsibleActionView)ActionBarView.this.mExpandedActionView).onActionViewCollapsed();
      ActionBarView.this.removeView(ActionBarView.this.mExpandedActionView);
      ActionBarView.this.mUpGoerFive.removeView(ActionBarView.this.mExpandedHomeLayout);
      ActionBarView.this.mExpandedActionView = null;
      if ((0x2 & ActionBarView.this.mDisplayOptions) != 0)
        ActionBarView.this.mHomeLayout.setVisibility(0);
      if ((0x8 & ActionBarView.this.mDisplayOptions) != 0)
      {
        if (ActionBarView.this.mTitleLayout != null)
          break label234;
        ActionBarView.this.initTitle();
      }
      while (true)
      {
        if (ActionBarView.this.mTabScrollView != null)
          ActionBarView.this.mTabScrollView.setVisibility(0);
        if (ActionBarView.this.mSpinner != null)
          ActionBarView.this.mSpinner.setVisibility(0);
        if (ActionBarView.this.mCustomNavView != null)
          ActionBarView.this.mCustomNavView.setVisibility(0);
        ActionBarView.this.mExpandedHomeLayout.setIcon(null);
        this.mCurrentExpandedItem = null;
        ActionBarView.this.setHomeButtonEnabled(ActionBarView.this.mWasHomeEnabled);
        ActionBarView.this.requestLayout();
        paramMenuItemImpl.setActionViewExpanded(false);
        return true;
        label234: ActionBarView.this.mTitleLayout.setVisibility(0);
      }
    }

    public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl)
    {
      ActionBarTransition.beginDelayedTransition(ActionBarView.this);
      ActionBarView.this.mExpandedActionView = paramMenuItemImpl.getActionView();
      ActionBarView.this.mExpandedHomeLayout.setIcon(ActionBarView.this.mIcon.getConstantState().newDrawable(ActionBarView.this.getResources()));
      this.mCurrentExpandedItem = paramMenuItemImpl;
      if (ActionBarView.this.mExpandedActionView.getParent() != ActionBarView.this)
        ActionBarView.this.addView(ActionBarView.this.mExpandedActionView);
      if (ActionBarView.this.mExpandedHomeLayout.getParent() != ActionBarView.this.mUpGoerFive)
        ActionBarView.this.mUpGoerFive.addView(ActionBarView.this.mExpandedHomeLayout);
      ActionBarView.this.mHomeLayout.setVisibility(8);
      if (ActionBarView.this.mTitleLayout != null)
        ActionBarView.this.mTitleLayout.setVisibility(8);
      if (ActionBarView.this.mTabScrollView != null)
        ActionBarView.this.mTabScrollView.setVisibility(8);
      if (ActionBarView.this.mSpinner != null)
        ActionBarView.this.mSpinner.setVisibility(8);
      if (ActionBarView.this.mCustomNavView != null)
        ActionBarView.this.mCustomNavView.setVisibility(8);
      ActionBarView.this.setHomeButtonEnabled(false, false);
      ActionBarView.this.requestLayout();
      paramMenuItemImpl.setActionViewExpanded(true);
      if ((ActionBarView.this.mExpandedActionView instanceof CollapsibleActionView))
        ((CollapsibleActionView)ActionBarView.this.mExpandedActionView).onActionViewExpanded();
      return true;
    }

    public boolean flagActionItems()
    {
      return false;
    }

    public int getId()
    {
      return 0;
    }

    public MenuView getMenuView(ViewGroup paramViewGroup)
    {
      return null;
    }

    public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
    {
      if ((this.mMenu != null) && (this.mCurrentExpandedItem != null))
        this.mMenu.collapseItemActionView(this.mCurrentExpandedItem);
      this.mMenu = paramMenuBuilder;
    }

    public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
    {
    }

    public void onRestoreInstanceState(Parcelable paramParcelable)
    {
    }

    public Parcelable onSaveInstanceState()
    {
      return null;
    }

    public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder)
    {
      return false;
    }

    public void setCallback(MenuPresenter.Callback paramCallback)
    {
    }

    public void updateMenuView(boolean paramBoolean)
    {
      int i;
      int j;
      if (this.mCurrentExpandedItem != null)
      {
        i = 0;
        if (this.mMenu != null)
          j = this.mMenu.size();
      }
      for (int k = 0; ; k++)
        if (k < j)
        {
          if (this.mMenu.getItem(k) == this.mCurrentExpandedItem)
            i = 1;
        }
        else
        {
          if (i == 0)
            collapseItemActionView(this.mMenu, this.mCurrentExpandedItem);
          return;
        }
    }
  }

  private static class HomeView extends FrameLayout
  {
    private static final long DEFAULT_TRANSITION_DURATION = 150L;
    private Drawable mDefaultUpIndicator;
    private ImageView mIconView;
    private int mStartOffset;
    private int mUpIndicatorRes;
    private ImageView mUpView;
    private int mUpWidth;

    public HomeView(Context paramContext)
    {
      this(paramContext, null);
    }

    public HomeView(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      LayoutTransition localLayoutTransition = getLayoutTransition();
      if (localLayoutTransition != null)
        localLayoutTransition.setDuration(150L);
    }

    public boolean dispatchHoverEvent(MotionEvent paramMotionEvent)
    {
      return onHoverEvent(paramMotionEvent);
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      onPopulateAccessibilityEvent(paramAccessibilityEvent);
      return true;
    }

    public int getStartOffset()
    {
      return Injector.ActionBarViewHook.getStartOffset(getContext(), this.mUpView, this.mUpWidth);
    }

    public int getUpWidth()
    {
      return Injector.ActionBarViewHook.getUpWidth(getContext(), this.mUpWidth);
    }

    protected void onConfigurationChanged(Configuration paramConfiguration)
    {
      super.onConfigurationChanged(paramConfiguration);
      if (this.mUpIndicatorRes != 0)
        setUpIndicator(this.mUpIndicatorRes);
    }

    protected void onFinishInflate()
    {
      this.mUpView = ((ImageView)findViewById(16908890));
      this.mIconView = ((ImageView)findViewById(16908332));
      this.mDefaultUpIndicator = this.mUpView.getDrawable();
    }

    protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      int i = (paramInt4 - paramInt2) / 2;
      boolean bool = isLayoutRtl();
      int j = getWidth();
      int k = 0;
      int i8;
      int i11;
      int i12;
      int n;
      int i2;
      int i3;
      int i4;
      int i6;
      int i5;
      if (this.mUpView.getVisibility() != 8)
      {
        FrameLayout.LayoutParams localLayoutParams2 = (FrameLayout.LayoutParams)this.mUpView.getLayoutParams();
        int i7 = this.mUpView.getMeasuredHeight();
        i8 = this.mUpView.getMeasuredWidth();
        k = i8 + localLayoutParams2.leftMargin + localLayoutParams2.rightMargin;
        int i9 = i - i7 / 2;
        int i10 = i9 + i7;
        if (bool)
        {
          i11 = j;
          i12 = i11 - i8;
          paramInt3 -= k;
          this.mUpView.layout(i12, i9, i11, i10);
        }
      }
      else
      {
        FrameLayout.LayoutParams localLayoutParams1 = (FrameLayout.LayoutParams)this.mIconView.getLayoutParams();
        int m = this.mIconView.getMeasuredHeight();
        n = this.mIconView.getMeasuredWidth();
        int i1 = (paramInt3 - paramInt1) / 2;
        i2 = Math.max(localLayoutParams1.topMargin, i - m / 2);
        i3 = i2 + m;
        i4 = Math.max(localLayoutParams1.getMarginStart(), i1 - n / 2);
        if (!bool)
          break label267;
        i6 = j - k - i4;
        i5 = i6 - n;
      }
      while (true)
      {
        this.mIconView.layout(i5, i2, i6, i3);
        return;
        i11 = i8;
        i12 = 0;
        paramInt1 += k;
        break;
        label267: i5 = k + i4;
        i6 = i5 + n;
      }
    }

    protected void onMeasure(int paramInt1, int paramInt2)
    {
      measureChildWithMargins(this.mUpView, paramInt1, 0, paramInt2, 0);
      FrameLayout.LayoutParams localLayoutParams1 = (FrameLayout.LayoutParams)this.mUpView.getLayoutParams();
      int i = localLayoutParams1.leftMargin + localLayoutParams1.rightMargin;
      this.mUpWidth = this.mUpView.getMeasuredWidth();
      this.mStartOffset = (i + this.mUpWidth);
      int j;
      int k;
      label177: int i1;
      int i2;
      if (this.mUpView.getVisibility() == 8)
      {
        j = 0;
        k = localLayoutParams1.topMargin + this.mUpView.getMeasuredHeight() + localLayoutParams1.bottomMargin;
        if (this.mIconView.getVisibility() == 8)
          break label274;
        measureChildWithMargins(this.mIconView, paramInt1, j, paramInt2, 0);
        FrameLayout.LayoutParams localLayoutParams2 = (FrameLayout.LayoutParams)this.mIconView.getLayoutParams();
        j += localLayoutParams2.leftMargin + this.mIconView.getMeasuredWidth() + localLayoutParams2.rightMargin;
        k = Math.max(k, localLayoutParams2.topMargin + this.mIconView.getMeasuredHeight() + localLayoutParams2.bottomMargin);
        int m = View.MeasureSpec.getMode(paramInt1);
        int n = View.MeasureSpec.getMode(paramInt2);
        i1 = View.MeasureSpec.getSize(paramInt1);
        i2 = View.MeasureSpec.getSize(paramInt2);
        switch (m)
        {
        default:
          label228: switch (n)
          {
          default:
          case -2147483648:
          case 1073741824:
          }
          break;
        case -2147483648:
        case 1073741824:
        }
      }
      while (true)
      {
        setMeasuredDimension(j, k);
        return;
        j = this.mStartOffset;
        break;
        label274: if (i >= 0)
          break label177;
        j -= i;
        break label177;
        j = Math.min(j, i1);
        break label228;
        j = i1;
        break label228;
        k = Math.min(k, i2);
        continue;
        k = i2;
      }
    }

    public void onPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
    {
      super.onPopulateAccessibilityEvent(paramAccessibilityEvent);
      CharSequence localCharSequence = getContentDescription();
      if (!TextUtils.isEmpty(localCharSequence))
        paramAccessibilityEvent.getText().add(localCharSequence);
    }

    public void setIcon(Drawable paramDrawable)
    {
      this.mIconView.setImageDrawable(paramDrawable);
    }

    public void setShowIcon(boolean paramBoolean)
    {
      ImageView localImageView = this.mIconView;
      if (paramBoolean);
      for (int i = 0; ; i = 8)
      {
        localImageView.setVisibility(i);
        return;
      }
    }

    public void setShowUp(boolean paramBoolean)
    {
      ImageView localImageView = this.mUpView;
      if (paramBoolean);
      for (int i = 0; ; i = 8)
      {
        localImageView.setVisibility(i);
        return;
      }
    }

    public void setUpIndicator(int paramInt)
    {
      this.mUpIndicatorRes = paramInt;
      ImageView localImageView = this.mUpView;
      if (paramInt != 0);
      for (Drawable localDrawable = getResources().getDrawable(paramInt); ; localDrawable = null)
      {
        localImageView.setImageDrawable(localDrawable);
        return;
      }
    }

    public void setUpIndicator(Drawable paramDrawable)
    {
      ImageView localImageView = this.mUpView;
      if (paramDrawable != null);
      while (true)
      {
        localImageView.setImageDrawable(paramDrawable);
        this.mUpIndicatorRes = 0;
        return;
        paramDrawable = this.mDefaultUpIndicator;
      }
    }
  }

  static class SavedState extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
      public ActionBarView.SavedState createFromParcel(Parcel paramAnonymousParcel)
      {
        return new ActionBarView.SavedState(paramAnonymousParcel, null);
      }

      public ActionBarView.SavedState[] newArray(int paramAnonymousInt)
      {
        return new ActionBarView.SavedState[paramAnonymousInt];
      }
    };
    int expandedMenuItemId;
    boolean isOverflowOpen;

    private SavedState(Parcel paramParcel)
    {
      super();
      this.expandedMenuItemId = paramParcel.readInt();
      if (paramParcel.readInt() != 0);
      for (boolean bool = true; ; bool = false)
      {
        this.isOverflowOpen = bool;
        return;
      }
    }

    SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.expandedMenuItemId);
      if (this.isOverflowOpen);
      for (int i = 1; ; i = 0)
      {
        paramParcel.writeInt(i);
        return;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.widget.ActionBarView
 * JD-Core Version:    0.6.2
 */