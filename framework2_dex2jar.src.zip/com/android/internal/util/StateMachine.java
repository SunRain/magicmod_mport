package com.android.internal.util;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

public class StateMachine
{
  public static final boolean HANDLED = true;
  public static final boolean NOT_HANDLED = false;
  private static final int SM_INIT_CMD = -2;
  private static final int SM_QUIT_CMD = -1;
  private String mName;
  private SmHandler mSmHandler;
  private HandlerThread mSmThread;

  protected StateMachine(String paramString)
  {
    this.mSmThread = new HandlerThread(paramString);
    this.mSmThread.start();
    initStateMachine(paramString, this.mSmThread.getLooper());
  }

  protected StateMachine(String paramString, Handler paramHandler)
  {
    initStateMachine(paramString, paramHandler.getLooper());
  }

  protected StateMachine(String paramString, Looper paramLooper)
  {
    initStateMachine(paramString, paramLooper);
  }

  private void initStateMachine(String paramString, Looper paramLooper)
  {
    this.mName = paramString;
    this.mSmHandler = new SmHandler(paramLooper, this, null);
  }

  protected void addLogRec(String paramString)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.mLogRecords.add(this, localSmHandler.getCurrentMessage(), paramString, localSmHandler.getCurrentState(), localSmHandler.mStateStack[localSmHandler.mStateStackTopIndex].state, localSmHandler.mDestState);
    }
  }

  protected final void addState(State paramState)
  {
    this.mSmHandler.addState(paramState, null);
  }

  protected final void addState(State paramState1, State paramState2)
  {
    this.mSmHandler.addState(paramState1, paramState2);
  }

  public final Collection<LogRec> copyLogRecs()
  {
    Vector localVector = new Vector();
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler != null)
    {
      Iterator localIterator = SmHandler.access$1600(localSmHandler).mLogRecVector.iterator();
      while (localIterator.hasNext())
        localVector.add((LogRec)localIterator.next());
    }
    return localVector;
  }

  protected final void deferMessage(Message paramMessage)
  {
    this.mSmHandler.deferMessage(paramMessage);
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println(getName() + ":");
    paramPrintWriter.println(" total records=" + getLogRecCount());
    for (int i = 0; i < getLogRecSize(); i++)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(i);
      arrayOfObject[1] = getLogRec(i).toString();
      paramPrintWriter.printf(" rec[%d]: %s\n", arrayOfObject);
      paramPrintWriter.flush();
    }
    paramPrintWriter.println("curState=" + getCurrentState().getName());
  }

  protected final Message getCurrentMessage()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (Message localMessage = null; ; localMessage = localSmHandler.getCurrentMessage())
      return localMessage;
  }

  protected final IState getCurrentState()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (IState localIState = null; ; localIState = localSmHandler.getCurrentState())
      return localIState;
  }

  public final Handler getHandler()
  {
    return this.mSmHandler;
  }

  public final LogRec getLogRec(int paramInt)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (LogRec localLogRec = null; ; localLogRec = localSmHandler.mLogRecords.get(paramInt))
      return localLogRec;
  }

  public final int getLogRecCount()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (int i = 0; ; i = localSmHandler.mLogRecords.count())
      return i;
  }

  public final int getLogRecSize()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (int i = 0; ; i = localSmHandler.mLogRecords.size())
      return i;
  }

  protected String getLogRecString(Message paramMessage)
  {
    return "";
  }

  public final String getName()
  {
    return this.mName;
  }

  protected String getWhatToString(int paramInt)
  {
    return null;
  }

  protected void haltedProcessMessage(Message paramMessage)
  {
  }

  public boolean isDbg()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    for (boolean bool = false; ; bool = localSmHandler.isDbg())
      return bool;
  }

  protected final boolean isQuit(Message paramMessage)
  {
    SmHandler localSmHandler = this.mSmHandler;
    boolean bool;
    if (localSmHandler == null)
      if (paramMessage.what == -1)
        bool = true;
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = localSmHandler.isQuit(paramMessage);
    }
  }

  protected void log(String paramString)
  {
    Log.d(this.mName, paramString);
  }

  protected void logAndAddLogRec(String paramString)
  {
    addLogRec(paramString);
    log(paramString);
  }

  protected void logd(String paramString)
  {
    Log.d(this.mName, paramString);
  }

  protected void loge(String paramString)
  {
    Log.e(this.mName, paramString);
  }

  protected void loge(String paramString, Throwable paramThrowable)
  {
    Log.e(this.mName, paramString, paramThrowable);
  }

  protected void logi(String paramString)
  {
    Log.i(this.mName, paramString);
  }

  protected void logv(String paramString)
  {
    Log.v(this.mName, paramString);
  }

  protected void logw(String paramString)
  {
    Log.w(this.mName, paramString);
  }

  public final Message obtainMessage()
  {
    return Message.obtain(this.mSmHandler);
  }

  public final Message obtainMessage(int paramInt)
  {
    return Message.obtain(this.mSmHandler, paramInt);
  }

  public final Message obtainMessage(int paramInt1, int paramInt2)
  {
    return Message.obtain(this.mSmHandler, paramInt1, paramInt2, 0);
  }

  public final Message obtainMessage(int paramInt1, int paramInt2, int paramInt3)
  {
    return Message.obtain(this.mSmHandler, paramInt1, paramInt2, paramInt3);
  }

  public final Message obtainMessage(int paramInt1, int paramInt2, int paramInt3, Object paramObject)
  {
    return Message.obtain(this.mSmHandler, paramInt1, paramInt2, paramInt3, paramObject);
  }

  public final Message obtainMessage(int paramInt, Object paramObject)
  {
    return Message.obtain(this.mSmHandler, paramInt, paramObject);
  }

  protected void onHalting()
  {
  }

  protected void onQuitting()
  {
  }

  protected final void quit()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.quit();
    }
  }

  protected final void quitNow()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.quitNow();
    }
  }

  protected boolean recordLogRec(Message paramMessage)
  {
    return true;
  }

  protected final void removeMessages(int paramInt)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.removeMessages(paramInt);
    }
  }

  public final void sendMessage(int paramInt)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(obtainMessage(paramInt));
    }
  }

  public final void sendMessage(int paramInt1, int paramInt2)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(obtainMessage(paramInt1, paramInt2));
    }
  }

  public final void sendMessage(int paramInt1, int paramInt2, int paramInt3)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(obtainMessage(paramInt1, paramInt2, paramInt3));
    }
  }

  public final void sendMessage(int paramInt1, int paramInt2, int paramInt3, Object paramObject)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(obtainMessage(paramInt1, paramInt2, paramInt3, paramObject));
    }
  }

  public final void sendMessage(int paramInt, Object paramObject)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(obtainMessage(paramInt, paramObject));
    }
  }

  public final void sendMessage(Message paramMessage)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessage(paramMessage);
    }
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt));
    }
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt1, int paramInt2)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt1, paramInt2));
    }
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt1, int paramInt2, int paramInt3)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt1, paramInt2, paramInt3));
    }
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt1, int paramInt2, int paramInt3, Object paramObject)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt1, paramInt2, paramInt3, paramObject));
    }
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt, Object paramObject)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt, paramObject));
    }
  }

  protected final void sendMessageAtFrontOfQueue(Message paramMessage)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageAtFrontOfQueue(paramMessage);
    }
  }

  public final void sendMessageDelayed(int paramInt1, int paramInt2, int paramInt3, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(obtainMessage(paramInt1, paramInt2, paramInt3), paramLong);
    }
  }

  public final void sendMessageDelayed(int paramInt1, int paramInt2, int paramInt3, Object paramObject, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(obtainMessage(paramInt1, paramInt2, paramInt3, paramObject), paramLong);
    }
  }

  public final void sendMessageDelayed(int paramInt1, int paramInt2, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(obtainMessage(paramInt1, paramInt2), paramLong);
    }
  }

  public final void sendMessageDelayed(int paramInt, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(obtainMessage(paramInt), paramLong);
    }
  }

  public final void sendMessageDelayed(int paramInt, Object paramObject, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(obtainMessage(paramInt, paramObject), paramLong);
    }
  }

  public final void sendMessageDelayed(Message paramMessage, long paramLong)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.sendMessageDelayed(paramMessage, paramLong);
    }
  }

  public void setDbg(boolean paramBoolean)
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.setDbg(paramBoolean);
    }
  }

  protected final void setInitialState(State paramState)
  {
    this.mSmHandler.setInitialState(paramState);
  }

  public final void setLogOnlyTransitions(boolean paramBoolean)
  {
    this.mSmHandler.mLogRecords.setLogOnlyTransitions(paramBoolean);
  }

  public final void setLogRecSize(int paramInt)
  {
    this.mSmHandler.mLogRecords.setSize(paramInt);
  }

  public void start()
  {
    SmHandler localSmHandler = this.mSmHandler;
    if (localSmHandler == null);
    while (true)
    {
      return;
      localSmHandler.completeConstruction();
    }
  }

  protected final void transitionTo(IState paramIState)
  {
    this.mSmHandler.transitionTo(paramIState);
  }

  protected final void transitionToHaltingState()
  {
    this.mSmHandler.transitionTo(this.mSmHandler.mHaltingState);
  }

  protected void unhandledMessage(Message paramMessage)
  {
    if (this.mSmHandler.mDbg)
      loge(" - unhandledMessage: msg.what=" + paramMessage.what);
  }

  public static class LogRec
  {
    private IState mDstState;
    private String mInfo;
    private IState mOrgState;
    private StateMachine mSm;
    private IState mState;
    private long mTime;
    private int mWhat;

    LogRec(StateMachine paramStateMachine, Message paramMessage, String paramString, IState paramIState1, IState paramIState2, IState paramIState3)
    {
      update(paramStateMachine, paramMessage, paramString, paramIState1, paramIState2, paramIState3);
    }

    public IState getDestState()
    {
      return this.mDstState;
    }

    public String getInfo()
    {
      return this.mInfo;
    }

    public IState getOriginalState()
    {
      return this.mOrgState;
    }

    public IState getState()
    {
      return this.mState;
    }

    public long getTime()
    {
      return this.mTime;
    }

    public long getWhat()
    {
      return this.mWhat;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("time=");
      Calendar localCalendar = Calendar.getInstance();
      localCalendar.setTimeInMillis(this.mTime);
      localStringBuilder.append(String.format("%tm-%td %tH:%tM:%tS.%tL", new Object[] { localCalendar, localCalendar, localCalendar, localCalendar, localCalendar, localCalendar }));
      localStringBuilder.append(" processed=");
      String str1;
      String str2;
      label109: String str3;
      label134: String str4;
      if (this.mState == null)
      {
        str1 = "<null>";
        localStringBuilder.append(str1);
        localStringBuilder.append(" org=");
        if (this.mOrgState != null)
          break label256;
        str2 = "<null>";
        localStringBuilder.append(str2);
        localStringBuilder.append(" dest=");
        if (this.mDstState != null)
          break label270;
        str3 = "<null>";
        localStringBuilder.append(str3);
        localStringBuilder.append(" what=");
        if (this.mSm == null)
          break label284;
        str4 = this.mSm.getWhatToString(this.mWhat);
        label168: if (!TextUtils.isEmpty(str4))
          break label291;
        localStringBuilder.append(this.mWhat);
        localStringBuilder.append("(0x");
        localStringBuilder.append(Integer.toHexString(this.mWhat));
        localStringBuilder.append(")");
      }
      while (true)
      {
        if (!TextUtils.isEmpty(this.mInfo))
        {
          localStringBuilder.append(" ");
          localStringBuilder.append(this.mInfo);
        }
        return localStringBuilder.toString();
        str1 = this.mState.getName();
        break;
        label256: str2 = this.mOrgState.getName();
        break label109;
        label270: str3 = this.mDstState.getName();
        break label134;
        label284: str4 = "";
        break label168;
        label291: localStringBuilder.append(str4);
      }
    }

    public void update(StateMachine paramStateMachine, Message paramMessage, String paramString, IState paramIState1, IState paramIState2, IState paramIState3)
    {
      this.mSm = paramStateMachine;
      this.mTime = System.currentTimeMillis();
      if (paramMessage != null);
      for (int i = paramMessage.what; ; i = 0)
      {
        this.mWhat = i;
        this.mInfo = paramString;
        this.mState = paramIState1;
        this.mOrgState = paramIState2;
        this.mDstState = paramIState3;
        return;
      }
    }
  }

  private static class LogRecords
  {
    private static final int DEFAULT_SIZE = 20;
    private int mCount = 0;
    private boolean mLogOnlyTransitions = false;
    private Vector<StateMachine.LogRec> mLogRecVector = new Vector();
    private int mMaxSize = 20;
    private int mOldestIndex = 0;

    void add(StateMachine paramStateMachine, Message paramMessage, String paramString, IState paramIState1, IState paramIState2, IState paramIState3)
    {
      try
      {
        this.mCount = (1 + this.mCount);
        if (this.mLogRecVector.size() < this.mMaxSize)
          this.mLogRecVector.add(new StateMachine.LogRec(paramStateMachine, paramMessage, paramString, paramIState1, paramIState2, paramIState3));
        while (true)
        {
          return;
          StateMachine.LogRec localLogRec = (StateMachine.LogRec)this.mLogRecVector.get(this.mOldestIndex);
          this.mOldestIndex = (1 + this.mOldestIndex);
          if (this.mOldestIndex >= this.mMaxSize)
            this.mOldestIndex = 0;
          localLogRec.update(paramStateMachine, paramMessage, paramString, paramIState1, paramIState2, paramIState3);
        }
      }
      finally
      {
      }
    }

    void cleanup()
    {
      try
      {
        this.mLogRecVector.clear();
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    int count()
    {
      try
      {
        int i = this.mCount;
        return i;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    StateMachine.LogRec get(int paramInt)
    {
      try
      {
        int i = paramInt + this.mOldestIndex;
        if (i >= this.mMaxSize)
          i -= this.mMaxSize;
        int j = size();
        if (i >= j);
        for (StateMachine.LogRec localLogRec = null; ; localLogRec = (StateMachine.LogRec)this.mLogRecVector.get(i))
          return localLogRec;
      }
      finally
      {
      }
    }

    boolean logOnlyTransitions()
    {
      try
      {
        boolean bool = this.mLogOnlyTransitions;
        return bool;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    void setLogOnlyTransitions(boolean paramBoolean)
    {
      try
      {
        this.mLogOnlyTransitions = paramBoolean;
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    void setSize(int paramInt)
    {
      try
      {
        this.mMaxSize = paramInt;
        this.mCount = 0;
        this.mLogRecVector.clear();
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    int size()
    {
      try
      {
        int i = this.mLogRecVector.size();
        return i;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }
  }

  private static class SmHandler extends Handler
  {
    private static final Object mSmHandlerObj = new Object();
    private boolean mDbg = false;
    private ArrayList<Message> mDeferredMessages = new ArrayList();
    private State mDestState;
    private HaltingState mHaltingState = new HaltingState(null);
    private boolean mHasQuit = false;
    private State mInitialState;
    private boolean mIsConstructionCompleted;
    private StateMachine.LogRecords mLogRecords = new StateMachine.LogRecords(null);
    private Message mMsg;
    private QuittingState mQuittingState = new QuittingState(null);
    private StateMachine mSm;
    private HashMap<State, StateInfo> mStateInfo = new HashMap();
    private StateInfo[] mStateStack;
    private int mStateStackTopIndex = -1;
    private StateInfo[] mTempStateStack;
    private int mTempStateStackCount;

    private SmHandler(Looper paramLooper, StateMachine paramStateMachine)
    {
      super();
      this.mSm = paramStateMachine;
      addState(this.mHaltingState, null);
      addState(this.mQuittingState, null);
    }

    private final StateInfo addState(State paramState1, State paramState2)
    {
      StateMachine localStateMachine;
      StringBuilder localStringBuilder;
      if (this.mDbg)
      {
        localStateMachine = this.mSm;
        localStringBuilder = new StringBuilder().append("addStateInternal: E state=").append(paramState1.getName()).append(",parent=");
        if (paramState2 != null)
          break label158;
      }
      StateInfo localStateInfo1;
      StateInfo localStateInfo2;
      label158: for (String str = ""; ; str = paramState2.getName())
      {
        localStateMachine.log(str);
        localStateInfo1 = null;
        if (paramState2 != null)
        {
          localStateInfo1 = (StateInfo)this.mStateInfo.get(paramState2);
          if (localStateInfo1 == null)
            localStateInfo1 = addState(paramState2, null);
        }
        localStateInfo2 = (StateInfo)this.mStateInfo.get(paramState1);
        if (localStateInfo2 == null)
        {
          localStateInfo2 = new StateInfo(null);
          this.mStateInfo.put(paramState1, localStateInfo2);
        }
        if ((localStateInfo2.parentStateInfo == null) || (localStateInfo2.parentStateInfo == localStateInfo1))
          break;
        throw new RuntimeException("state already added");
      }
      localStateInfo2.state = paramState1;
      localStateInfo2.parentStateInfo = localStateInfo1;
      localStateInfo2.active = false;
      if (this.mDbg)
        this.mSm.log("addStateInternal: X stateInfo: " + localStateInfo2);
      return localStateInfo2;
    }

    private final void cleanupAfterQuitting()
    {
      if (this.mSm.mSmThread != null)
      {
        getLooper().quit();
        StateMachine.access$402(this.mSm, null);
      }
      StateMachine.access$502(this.mSm, null);
      this.mSm = null;
      this.mMsg = null;
      this.mLogRecords.cleanup();
      this.mStateStack = null;
      this.mTempStateStack = null;
      this.mStateInfo.clear();
      this.mInitialState = null;
      this.mDestState = null;
      this.mDeferredMessages.clear();
      this.mHasQuit = true;
    }

    private final void completeConstruction()
    {
      if (this.mDbg)
        this.mSm.log("completeConstruction: E");
      int i = 0;
      Iterator localIterator = this.mStateInfo.values().iterator();
      while (localIterator.hasNext())
      {
        StateInfo localStateInfo1 = (StateInfo)localIterator.next();
        int j = 0;
        StateInfo localStateInfo2 = localStateInfo1;
        while (localStateInfo2 != null)
        {
          localStateInfo2 = localStateInfo2.parentStateInfo;
          j++;
        }
        if (i < j)
          i = j;
      }
      if (this.mDbg)
        this.mSm.log("completeConstruction: maxDepth=" + i);
      this.mStateStack = new StateInfo[i];
      this.mTempStateStack = new StateInfo[i];
      setupInitialStateStack();
      sendMessageAtFrontOfQueue(obtainMessage(-2, mSmHandlerObj));
      if (this.mDbg)
        this.mSm.log("completeConstruction: X");
    }

    private final void deferMessage(Message paramMessage)
    {
      if (this.mDbg)
        this.mSm.log("deferMessage: msg=" + paramMessage.what);
      Message localMessage = obtainMessage();
      localMessage.copyFrom(paramMessage);
      this.mDeferredMessages.add(localMessage);
    }

    private final Message getCurrentMessage()
    {
      return this.mMsg;
    }

    private final IState getCurrentState()
    {
      return this.mStateStack[this.mStateStackTopIndex].state;
    }

    private final void invokeEnterMethods(int paramInt)
    {
      for (int i = paramInt; i <= this.mStateStackTopIndex; i++)
      {
        if (this.mDbg)
          this.mSm.log("invokeEnterMethods: " + this.mStateStack[i].state.getName());
        this.mStateStack[i].state.enter();
        this.mStateStack[i].active = true;
      }
    }

    private final void invokeExitMethods(StateInfo paramStateInfo)
    {
      while ((this.mStateStackTopIndex >= 0) && (this.mStateStack[this.mStateStackTopIndex] != paramStateInfo))
      {
        State localState = this.mStateStack[this.mStateStackTopIndex].state;
        if (this.mDbg)
          this.mSm.log("invokeExitMethods: " + localState.getName());
        localState.exit();
        this.mStateStack[this.mStateStackTopIndex].active = false;
        this.mStateStackTopIndex = (-1 + this.mStateStackTopIndex);
      }
    }

    private final boolean isDbg()
    {
      return this.mDbg;
    }

    private final boolean isQuit(Message paramMessage)
    {
      if ((paramMessage.what == -1) && (paramMessage.obj == mSmHandlerObj));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    private final void moveDeferredMessageAtFrontOfQueue()
    {
      for (int i = -1 + this.mDeferredMessages.size(); i >= 0; i--)
      {
        Message localMessage = (Message)this.mDeferredMessages.get(i);
        if (this.mDbg)
          this.mSm.log("moveDeferredMessageAtFrontOfQueue; what=" + localMessage.what);
        sendMessageAtFrontOfQueue(localMessage);
      }
      this.mDeferredMessages.clear();
    }

    private final int moveTempStateStackToStateStack()
    {
      int i = 1 + this.mStateStackTopIndex;
      int j = -1 + this.mTempStateStackCount;
      int k = i;
      while (j >= 0)
      {
        if (this.mDbg)
          this.mSm.log("moveTempStackToStateStack: i=" + j + ",j=" + k);
        this.mStateStack[k] = this.mTempStateStack[j];
        k++;
        j--;
      }
      this.mStateStackTopIndex = (k - 1);
      if (this.mDbg)
        this.mSm.log("moveTempStackToStateStack: X mStateStackTop=" + this.mStateStackTopIndex + ",startingIndex=" + i + ",Top=" + this.mStateStack[this.mStateStackTopIndex].state.getName());
      return i;
    }

    private void performTransitions(State paramState, Message paramMessage)
    {
      State localState1 = this.mStateStack[this.mStateStackTopIndex].state;
      int i;
      if ((this.mSm.recordLogRec(this.mMsg)) && (paramMessage.obj != mSmHandlerObj))
      {
        i = 1;
        if (!this.mLogRecords.logOnlyTransitions())
          break label163;
        if (this.mDestState != null)
          this.mLogRecords.add(this.mSm, this.mMsg, this.mSm.getLogRecString(this.mMsg), paramState, localState1, this.mDestState);
      }
      State localState2;
      while (true)
      {
        localState2 = this.mDestState;
        if (localState2 == null)
          break label208;
        while (true)
        {
          if (this.mDbg)
            this.mSm.log("handleMessage: new destination call exit/enter");
          invokeExitMethods(setupTempStateStackWithStatesToEnter(localState2));
          invokeEnterMethods(moveTempStateStackToStateStack());
          moveDeferredMessageAtFrontOfQueue();
          if (localState2 == this.mDestState)
            break;
          localState2 = this.mDestState;
        }
        i = 0;
        break;
        label163: if (i != 0)
          this.mLogRecords.add(this.mSm, this.mMsg, this.mSm.getLogRecString(this.mMsg), paramState, localState1, this.mDestState);
      }
      this.mDestState = null;
      label208: if (localState2 != null)
      {
        if (localState2 != this.mQuittingState)
          break label234;
        this.mSm.onQuitting();
        cleanupAfterQuitting();
      }
      while (true)
      {
        return;
        label234: if (localState2 == this.mHaltingState)
          this.mSm.onHalting();
      }
    }

    private final State processMsg(Message paramMessage)
    {
      StateInfo localStateInfo = this.mStateStack[this.mStateStackTopIndex];
      if (this.mDbg)
        this.mSm.log("processMsg: " + localStateInfo.state.getName());
      if (isQuit(paramMessage))
      {
        transitionTo(this.mQuittingState);
        if (localStateInfo == null)
          break label148;
      }
      label148: for (State localState = localStateInfo.state; ; localState = null)
      {
        return localState;
        do
        {
          if (this.mDbg)
            this.mSm.log("processMsg: " + localStateInfo.state.getName());
          if (localStateInfo.state.processMessage(paramMessage))
            break;
          localStateInfo = localStateInfo.parentStateInfo;
        }
        while (localStateInfo != null);
        this.mSm.unhandledMessage(paramMessage);
        break;
      }
    }

    private final void quit()
    {
      if (this.mDbg)
        this.mSm.log("quit:");
      sendMessage(obtainMessage(-1, mSmHandlerObj));
    }

    private final void quitNow()
    {
      if (this.mDbg)
        this.mSm.log("quitNow:");
      sendMessageAtFrontOfQueue(obtainMessage(-1, mSmHandlerObj));
    }

    private final void setDbg(boolean paramBoolean)
    {
      this.mDbg = paramBoolean;
    }

    private final void setInitialState(State paramState)
    {
      if (this.mDbg)
        this.mSm.log("setInitialState: initialState=" + paramState.getName());
      this.mInitialState = paramState;
    }

    private final void setupInitialStateStack()
    {
      if (this.mDbg)
        this.mSm.log("setupInitialStateStack: E mInitialState=" + this.mInitialState.getName());
      StateInfo localStateInfo = (StateInfo)this.mStateInfo.get(this.mInitialState);
      for (this.mTempStateStackCount = 0; localStateInfo != null; this.mTempStateStackCount = (1 + this.mTempStateStackCount))
      {
        this.mTempStateStack[this.mTempStateStackCount] = localStateInfo;
        localStateInfo = localStateInfo.parentStateInfo;
      }
      this.mStateStackTopIndex = -1;
      moveTempStateStackToStateStack();
    }

    private final StateInfo setupTempStateStackWithStatesToEnter(State paramState)
    {
      this.mTempStateStackCount = 0;
      StateInfo localStateInfo = (StateInfo)this.mStateInfo.get(paramState);
      do
      {
        StateInfo[] arrayOfStateInfo = this.mTempStateStack;
        int i = this.mTempStateStackCount;
        this.mTempStateStackCount = (i + 1);
        arrayOfStateInfo[i] = localStateInfo;
        localStateInfo = localStateInfo.parentStateInfo;
      }
      while ((localStateInfo != null) && (!localStateInfo.active));
      if (this.mDbg)
        this.mSm.log("setupTempStateStackWithStatesToEnter: X mTempStateStackCount=" + this.mTempStateStackCount + ",curStateInfo: " + localStateInfo);
      return localStateInfo;
    }

    private final void transitionTo(IState paramIState)
    {
      this.mDestState = ((State)paramIState);
      if (this.mDbg)
        this.mSm.log("transitionTo: destState=" + this.mDestState.getName());
    }

    public final void handleMessage(Message paramMessage)
    {
      State localState;
      if (!this.mHasQuit)
      {
        if (this.mDbg)
          this.mSm.log("handleMessage: E msg.what=" + paramMessage.what);
        this.mMsg = paramMessage;
        localState = null;
        if (!this.mIsConstructionCompleted)
          break label95;
        localState = processMsg(paramMessage);
      }
      while (true)
      {
        performTransitions(localState, paramMessage);
        if ((this.mDbg) && (this.mSm != null))
          this.mSm.log("handleMessage: X");
        return;
        label95: if ((this.mIsConstructionCompleted) || (this.mMsg.what != -2) || (this.mMsg.obj != mSmHandlerObj))
          break;
        this.mIsConstructionCompleted = true;
        invokeEnterMethods(0);
      }
      throw new RuntimeException("StateMachine.handleMessage: The start method not called, received msg: " + paramMessage);
    }

    private class HaltingState extends State
    {
      private HaltingState()
      {
      }

      public boolean processMessage(Message paramMessage)
      {
        StateMachine.this.haltedProcessMessage(paramMessage);
        return true;
      }
    }

    private class QuittingState extends State
    {
      private QuittingState()
      {
      }

      public boolean processMessage(Message paramMessage)
      {
        return false;
      }
    }

    private class StateInfo
    {
      boolean active;
      StateInfo parentStateInfo;
      State state;

      private StateInfo()
      {
      }

      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder().append("state=").append(this.state.getName()).append(",active=").append(this.active).append(",parent=");
        if (this.parentStateInfo == null);
        for (String str = "null"; ; str = this.parentStateInfo.state.getName())
          return str;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.util.StateMachine
 * JD-Core Version:    0.6.2
 */