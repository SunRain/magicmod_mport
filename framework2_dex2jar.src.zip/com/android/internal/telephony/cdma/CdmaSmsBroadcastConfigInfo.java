package com.android.internal.telephony.cdma;

public class CdmaSmsBroadcastConfigInfo
{
  private int mFromServiceCategory;
  private int mLanguage;
  private boolean mSelected;
  private int mToServiceCategory;

  public CdmaSmsBroadcastConfigInfo(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    this.mFromServiceCategory = paramInt1;
    this.mToServiceCategory = paramInt2;
    this.mLanguage = paramInt3;
    this.mSelected = paramBoolean;
  }

  public int getFromServiceCategory()
  {
    return this.mFromServiceCategory;
  }

  public int getLanguage()
  {
    return this.mLanguage;
  }

  public int getToServiceCategory()
  {
    return this.mToServiceCategory;
  }

  public boolean isSelected()
  {
    return this.mSelected;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("CdmaSmsBroadcastConfigInfo: Id [").append(this.mFromServiceCategory).append(", ").append(this.mToServiceCategory).append("] ");
    if (isSelected());
    for (String str = "ENABLED"; ; str = "DISABLED")
      return str;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaSmsBroadcastConfigInfo
 * JD-Core Version:    0.6.2
 */