package com.android.internal.telephony.cdma;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import android.os.RegistrantList;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.telephony.CellIdentityLte;
import android.telephony.CellInfo;
import android.telephony.CellInfoLte;
import android.telephony.CellSignalStrengthLte;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.EventLog;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.RuimRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class CdmaLteServiceStateTracker extends CdmaServiceStateTracker
{
  private CDMALTEPhone mCdmaLtePhone;
  private final CellInfoLte mCellInfoLte;
  private CellIdentityLte mLasteCellIdentityLte = new CellIdentityLte();
  private CellIdentityLte mNewCellIdentityLte = new CellIdentityLte();

  public CdmaLteServiceStateTracker(CDMALTEPhone paramCDMALTEPhone)
  {
    super(paramCDMALTEPhone, new CellInfoLte());
    this.mCdmaLtePhone = paramCDMALTEPhone;
    this.mCellInfoLte = ((CellInfoLte)this.mCellInfo);
    ((CellInfoLte)this.mCellInfo).setCellSignalStrength(new CellSignalStrengthLte());
    ((CellInfoLte)this.mCellInfo).setCellIdentity(new CellIdentityLte());
    log("CdmaLteServiceStateTracker Constructors");
  }

  private boolean isInHomeSidNid(int paramInt1, int paramInt2)
  {
    boolean bool = true;
    if (isSidsAllZeros());
    while (true)
    {
      return bool;
      if ((this.mHomeSystemId.length == this.mHomeNetworkId.length) && (paramInt1 != 0))
      {
        for (int i = 0; ; i++)
        {
          if (i >= this.mHomeSystemId.length)
            break label101;
          if ((this.mHomeSystemId[i] == paramInt1) && ((this.mHomeNetworkId[i] == 0) || (this.mHomeNetworkId[i] == 65535) || (paramInt2 == 0) || (paramInt2 == 65535) || (this.mHomeNetworkId[i] == paramInt2)))
            break;
        }
        label101: bool = false;
      }
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("CdmaLteServiceStateTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mCdmaLtePhone=" + this.mCdmaLtePhone);
  }

  public List<CellInfo> getAllCellInfo()
  {
    Object localObject1;
    if (this.mCi.getRilVersion() >= 8)
      localObject1 = super.getAllCellInfo();
    while (true)
    {
      return localObject1;
      localObject1 = new ArrayList();
      synchronized (this.mCellInfo)
      {
        ((ArrayList)localObject1).add(this.mCellInfoLte);
        log("getAllCellInfo: arrayList=" + localObject1);
      }
    }
  }

  public void handleMessage(Message paramMessage)
  {
    if (!this.mPhone.mIsTheCurrentActivePhone)
      loge("Received message " + paramMessage + "[" + paramMessage.what + "]" + " while being destroyed. Ignoring.");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      default:
        super.handleMessage(paramMessage);
        break;
      case 5:
        log("handleMessage EVENT_POLL_STATE_GPRS");
        AsyncResult localAsyncResult = (AsyncResult)paramMessage.obj;
        handlePollStateResult(paramMessage.what, localAsyncResult);
        break;
      case 27:
        updatePhoneObject();
        RuimRecords localRuimRecords = (RuimRecords)this.mIccRecords;
        if ((localRuimRecords != null) && (localRuimRecords.isProvisioned()))
        {
          this.mMdn = localRuimRecords.getMdn();
          this.mMin = localRuimRecords.getMin();
          parseSidNid(localRuimRecords.getSid(), localRuimRecords.getNid());
          this.mPrlVersion = localRuimRecords.getPrlVersion();
          this.mIsMinInfoReady = true;
          updateOtaspState();
        }
        pollState();
      }
    }
  }

  protected void handlePollStateResultMessage(int paramInt, AsyncResult paramAsyncResult)
  {
    String[] arrayOfString;
    int i;
    int j;
    if (paramInt == 5)
    {
      arrayOfString = (String[])paramAsyncResult.result;
      log("handlePollStateResultMessage: EVENT_POLL_STATE_GPRS states.length=" + arrayOfString.length + " states=" + arrayOfString);
      i = 0;
      j = -1;
      if (arrayOfString.length <= 0);
    }
    while (true)
    {
      try
      {
        j = Integer.parseInt(arrayOfString[0]);
        if ((arrayOfString.length >= 4) && (arrayOfString[3] != null))
        {
          int i10 = Integer.parseInt(arrayOfString[3]);
          i = i10;
        }
        if (arrayOfString.length >= 10)
          str = null;
      }
      catch (NumberFormatException localException6)
      {
        try
        {
          str = this.mNewSS.getOperatorNumeric();
          int i9 = Integer.parseInt(str.substring(0, 3));
          m = i9;
        }
        catch (Exception localException6)
        {
          try
          {
            int i7 = Integer.parseInt(str.substring(3));
            n = i7;
          }
          catch (Exception localException6)
          {
            try
            {
              int i6 = Integer.decode(arrayOfString[6]).intValue();
              i1 = i6;
            }
            catch (Exception localException6)
            {
              try
              {
                int i5 = Integer.decode(arrayOfString[7]).intValue();
                i2 = i5;
              }
              catch (Exception localException6)
              {
                try
                {
                  int i4 = Integer.decode(arrayOfString[8]).intValue();
                  i3 = i4;
                }
                catch (Exception localException6)
                {
                  try
                  {
                    String str;
                    int m;
                    Integer.decode(arrayOfString[9]).intValue();
                    this.mNewCellIdentityLte = new CellIdentityLte(m, n, i3, i2, i1);
                    log("handlePollStateResultMessage: mNewLteCellIdentity=" + this.mNewCellIdentityLte);
                    this.mNewSS.setRilDataRadioTechnology(i);
                    int k = regCodeToServiceState(j);
                    this.mNewSS.setDataRegState(k);
                    log("handlPollStateResultMessage: CdmaLteSST setDataRegState=" + k + " regState=" + j + " dataRadioTechnology=" + i);
                    return;
                    localNumberFormatException = localNumberFormatException;
                    loge("handlePollStateResultMessage: error parsing GprsRegistrationState: " + localNumberFormatException);
                    continue;
                    localException1 = localException1;
                    try
                    {
                      str = this.mSS.getOperatorNumeric();
                      int i8 = Integer.parseInt(str.substring(0, 3));
                      m = i8;
                    }
                    catch (Exception localException2)
                    {
                      loge("handlePollStateResultMessage: bad mcc operatorNumeric=" + str + " ex=" + localException2);
                      str = "";
                      m = 2147483647;
                    }
                    continue;
                    localException3 = localException3;
                    loge("handlePollStateResultMessage: bad mnc operatorNumeric=" + str + " e=" + localException3);
                    int n = 2147483647;
                    continue;
                    localException4 = localException4;
                    loge("handlePollStateResultMessage: bad tac states[6]=" + arrayOfString[6] + " e=" + localException4);
                    int i1 = 2147483647;
                    continue;
                    localException5 = localException5;
                    loge("handlePollStateResultMessage: bad pci states[7]=" + arrayOfString[7] + " e=" + localException5);
                    int i2 = 2147483647;
                    continue;
                    localException6 = localException6;
                    loge("handlePollStateResultMessage: bad eci states[8]=" + arrayOfString[8] + " e=" + localException6);
                    int i3 = 2147483647;
                    continue;
                  }
                  catch (Exception localException7)
                  {
                    continue;
                  }
                }
              }
            }
          }
        }
      }
      super.handlePollStateResultMessage(paramInt, paramAsyncResult);
    }
  }

  public boolean isConcurrentVoiceAndDataAllowed()
  {
    int i = 1;
    if (this.mSS.getCssIndicator() == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  protected void log(String paramString)
  {
    Rlog.d("CdmaSST", "[CdmaLteSST] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("CdmaSST", "[CdmaLteSST] " + paramString);
  }

  protected boolean onSignalStrengthResult(AsyncResult paramAsyncResult, boolean paramBoolean)
  {
    if (this.mSS.getRilDataRadioTechnology() == 14)
      paramBoolean = true;
    boolean bool = super.onSignalStrengthResult(paramAsyncResult, paramBoolean);
    synchronized (this.mCellInfo)
    {
      if (this.mSS.getRilDataRadioTechnology() == 14)
      {
        this.mCellInfoLte.setTimeStamp(1000L * SystemClock.elapsedRealtime());
        this.mCellInfoLte.setTimeStampType(4);
        this.mCellInfoLte.getCellSignalStrength().initialize(this.mSignalStrength, 2147483647);
      }
      if (this.mCellInfoLte.getCellIdentity() != null)
      {
        ArrayList localArrayList = new ArrayList();
        localArrayList.add(this.mCellInfoLte);
        this.mPhoneBase.notifyCellInfo(localArrayList);
      }
      return bool;
    }
  }

  protected void pollState()
  {
    this.mPollingContext = new int[1];
    this.mPollingContext[0] = 0;
    switch (1.$SwitchMap$com$android$internal$telephony$CommandsInterface$RadioState[this.mCi.getRadioState().ordinal()])
    {
    default:
      int[] arrayOfInt1 = this.mPollingContext;
      arrayOfInt1[0] = (1 + arrayOfInt1[0]);
      this.mCi.getOperator(obtainMessage(25, this.mPollingContext));
      int[] arrayOfInt2 = this.mPollingContext;
      arrayOfInt2[0] = (1 + arrayOfInt2[0]);
      this.mCi.getVoiceRegistrationState(obtainMessage(24, this.mPollingContext));
      int[] arrayOfInt3 = this.mPollingContext;
      arrayOfInt3[0] = (1 + arrayOfInt3[0]);
      this.mCi.getDataRegistrationState(obtainMessage(5, this.mPollingContext));
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      this.mNewSS.setStateOutOfService();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      pollStateDone();
      continue;
      this.mNewSS.setStateOff();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      pollStateDone();
    }
  }

  protected void pollStateDone()
  {
    log("pollStateDone: lte 1 ss=[" + this.mSS + "] newSS=[" + this.mNewSS + "]");
    useDataRegStateForDataOnlyDevices();
    boolean bool1;
    boolean bool2;
    label93: boolean bool3;
    label115: boolean bool4;
    label138: boolean bool5;
    label158: boolean bool6;
    label178: boolean bool7;
    label198: boolean bool8;
    label215: boolean bool9;
    label238: boolean bool10;
    label261: boolean bool11;
    label278: boolean bool12;
    label339: boolean bool13;
    label390: boolean bool14;
    label416: String str5;
    label819: String str1;
    String str2;
    label1008: String str3;
    label1029: ArrayList localArrayList;
    if ((this.mSS.getVoiceRegState() != 0) && (this.mNewSS.getVoiceRegState() == 0))
    {
      bool1 = true;
      if ((this.mSS.getVoiceRegState() != 0) || (this.mNewSS.getVoiceRegState() == 0))
        break label1318;
      bool2 = true;
      if ((this.mSS.getDataRegState() == 0) || (this.mNewSS.getDataRegState() != 0))
        break label1323;
      bool3 = true;
      if ((this.mSS.getDataRegState() != 0) || (this.mNewSS.getDataRegState() == 0))
        break label1328;
      bool4 = true;
      if (this.mSS.getDataRegState() == this.mNewSS.getDataRegState())
        break label1334;
      bool5 = true;
      if (this.mSS.getRilVoiceRadioTechnology() == this.mNewSS.getRilVoiceRadioTechnology())
        break label1340;
      bool6 = true;
      if (this.mSS.getRilDataRadioTechnology() == this.mNewSS.getRilDataRadioTechnology())
        break label1346;
      bool7 = true;
      if (this.mNewSS.equals(this.mSS))
        break label1352;
      bool8 = true;
      if ((this.mSS.getRoaming()) || (!this.mNewSS.getRoaming()))
        break label1358;
      bool9 = true;
      if ((!this.mSS.getRoaming()) || (this.mNewSS.getRoaming()))
        break label1364;
      bool10 = true;
      if (this.mNewCellLoc.equals(this.mCellLoc))
        break label1370;
      bool11 = true;
      if ((this.mNewSS.getDataRegState() != 0) || (((this.mSS.getRilDataRadioTechnology() != 14) || (this.mNewSS.getRilDataRadioTechnology() != 13)) && ((this.mSS.getRilDataRadioTechnology() != 13) || (this.mNewSS.getRilDataRadioTechnology() != 14))))
        break label1376;
      bool12 = true;
      if (((this.mNewSS.getRilDataRadioTechnology() != 14) && (this.mNewSS.getRilDataRadioTechnology() != 13)) || (this.mSS.getRilDataRadioTechnology() == 14) || (this.mSS.getRilDataRadioTechnology() == 13))
        break label1382;
      bool13 = true;
      if ((this.mNewSS.getRilDataRadioTechnology() < 4) || (this.mNewSS.getRilDataRadioTechnology() > 8))
        break label1388;
      bool14 = true;
      log("pollStateDone: hasRegistered=" + bool1 + " hasDeegistered=" + bool2 + " hasCdmaDataConnectionAttached=" + bool3 + " hasCdmaDataConnectionDetached=" + bool4 + " hasCdmaDataConnectionChanged=" + bool5 + " hasVoiceRadioTechnologyChanged= " + bool6 + " hasDataRadioTechnologyChanged=" + bool7 + " hasChanged=" + bool8 + " hasRoamingOn=" + bool9 + " hasRoamingOff=" + bool10 + " hasLocationChanged=" + bool11 + " has4gHandoff = " + bool12 + " hasMultiApnSupport=" + bool13 + " hasLostMultiApnSupport=" + bool14);
      if ((this.mSS.getVoiceRegState() != this.mNewSS.getVoiceRegState()) || (this.mSS.getDataRegState() != this.mNewSS.getDataRegState()))
      {
        Object[] arrayOfObject = new Object[4];
        arrayOfObject[0] = Integer.valueOf(this.mSS.getVoiceRegState());
        arrayOfObject[1] = Integer.valueOf(this.mSS.getDataRegState());
        arrayOfObject[2] = Integer.valueOf(this.mNewSS.getVoiceRegState());
        arrayOfObject[3] = Integer.valueOf(this.mNewSS.getDataRegState());
        EventLog.writeEvent(50116, arrayOfObject);
      }
      ServiceState localServiceState = this.mSS;
      this.mSS = this.mNewSS;
      this.mNewSS = localServiceState;
      this.mNewSS.setStateOutOfService();
      CdmaCellLocation localCdmaCellLocation = this.mCellLoc;
      this.mCellLoc = this.mNewCellLoc;
      this.mNewCellLoc = localCdmaCellLocation;
      this.mNewSS.setStateOutOfService();
      if (bool6)
        updatePhoneObject();
      if (bool7)
        this.mPhone.setSystemProperty("gsm.network.type", ServiceState.rilRadioTechnologyToString(this.mSS.getRilDataRadioTechnology()));
      if (bool1)
        this.mNetworkAttachedRegistrants.notifyRegistrants();
      if (bool8)
      {
        if (this.mPhone.isEriFileLoaded())
        {
          if (this.mSS.getVoiceRegState() != 0)
            break label1394;
          str5 = this.mPhone.getCdmaEriText();
          this.mSS.setOperatorAlphaLong(str5);
        }
        if ((this.mUiccApplcation != null) && (this.mUiccApplcation.getState() == IccCardApplicationStatus.AppState.APPSTATE_READY) && (this.mIccRecords != null))
        {
          boolean bool17 = ((RuimRecords)this.mIccRecords).getCsimSpnDisplayCondition();
          int i = this.mSS.getCdmaEriIconIndex();
          if ((bool17) && (i == 1) && (isInHomeSidNid(this.mSS.getSystemId(), this.mSS.getNetworkId())) && (this.mIccRecords != null))
            this.mSS.setOperatorAlphaLong(this.mIccRecords.getServiceProviderName());
        }
        this.mPhone.setSystemProperty("gsm.operator.alpha", this.mSS.getOperatorAlphaLong());
        str1 = SystemProperties.get("gsm.operator.numeric", "");
        str2 = this.mSS.getOperatorNumeric();
        this.mPhone.setSystemProperty("gsm.operator.numeric", str2);
        if (str2 != null)
          break label1467;
        log("operatorNumeric is null");
        this.mPhone.setSystemProperty("gsm.operator.iso-country", "");
        this.mGotCountryCode = false;
        CDMAPhone localCDMAPhone = this.mPhone;
        if (!this.mSS.getRoaming())
          break label1604;
        str3 = "true";
        localCDMAPhone.setSystemProperty("gsm.operator.isroaming", str3);
        updateSpnDisplay();
        this.mPhone.notifyServiceStateChanged(this.mSS);
      }
      if ((bool3) || (bool12))
        this.mAttachedRegistrants.notifyRegistrants();
      if (bool4)
        this.mDetachedRegistrants.notifyRegistrants();
      if ((bool5) || (bool7))
      {
        notifyDataRegStateRilRadioTechnologyChanged();
        this.mPhone.notifyDataConnection(null);
      }
      if (bool9)
        this.mRoamingOnRegistrants.notifyRegistrants();
      if (bool10)
        this.mRoamingOffRegistrants.notifyRegistrants();
      if (bool11)
        this.mPhone.notifyLocationChanged();
      localArrayList = new ArrayList();
    }
    while (true)
    {
      boolean bool15;
      synchronized (this.mCellInfo)
      {
        while (true)
        {
          CellInfoLte localCellInfoLte = (CellInfoLte)this.mCellInfo;
          if (this.mNewCellIdentityLte.equals(this.mLasteCellIdentityLte))
            break label1612;
          bool15 = true;
          break label1632;
          (1000L * SystemClock.elapsedRealtime());
          if (this.mSS.getVoiceRegState() != 0)
            break label1618;
          bool16 = true;
          this.mLasteCellIdentityLte = this.mNewCellIdentityLte;
          localCellInfoLte.setRegisterd(bool16);
          localCellInfoLte.setCellIdentity(this.mLasteCellIdentityLte);
          log("pollStateDone: hasRegistered=" + bool1 + " hasDeregistered=" + bool2 + " cidChanged=" + bool15 + " mCellInfo=" + this.mCellInfo);
          localArrayList.add(this.mCellInfo);
          this.mPhoneBase.notifyCellInfo(localArrayList);
          return;
          bool1 = false;
          break;
          label1318: bool2 = false;
          break label93;
          label1323: bool3 = false;
          break label115;
          label1328: bool4 = false;
          break label138;
          label1334: bool5 = false;
          break label158;
          label1340: bool6 = false;
          break label178;
          label1346: bool7 = false;
          break label198;
          label1352: bool8 = false;
          break label215;
          label1358: bool9 = false;
          break label238;
          label1364: bool10 = false;
          break label261;
          label1370: bool11 = false;
          break label278;
          label1376: bool12 = false;
          break label339;
          label1382: bool13 = false;
          break label390;
          label1388: bool14 = false;
          break label416;
          label1394: if (this.mSS.getVoiceRegState() == 3)
          {
            if (this.mIccRecords != null);
            for (str5 = this.mIccRecords.getServiceProviderName(); TextUtils.isEmpty(str5); str5 = null)
            {
              str5 = SystemProperties.get("ro.cdma.home.operator.alpha");
              break;
            }
          }
          str5 = this.mPhone.getContext().getText(17039509).toString();
          break label819;
          label1467: Object localObject2 = "";
          str2.substring(0, 3);
          try
          {
            String str4 = MccTable.countryCodeForMcc(Integer.parseInt(str2.substring(0, 3)));
            localObject2 = str4;
            this.mPhone.setSystemProperty("gsm.operator.iso-country", (String)localObject2);
            this.mGotCountryCode = true;
            if (!shouldFixTimeZoneNow(this.mPhone, str2, str1, this.mNeedFixZone))
              break label1008;
            fixTimeZone((String)localObject2);
          }
          catch (NumberFormatException localNumberFormatException)
          {
            while (true)
              loge("countryCodeForMcc error" + localNumberFormatException);
          }
          catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
          {
            while (true)
              loge("countryCodeForMcc error" + localStringIndexOutOfBoundsException);
          }
        }
        label1604: str3 = "false";
        break label1029;
        label1612: bool15 = false;
        break label1632;
        label1618: boolean bool16 = false;
      }
      label1632: if ((!bool1) && (!bool2))
        if (!bool15);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaLteServiceStateTracker
 * JD-Core Version:    0.6.2
 */