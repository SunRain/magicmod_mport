package com.android.internal.telephony.cdma;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.telephony.PhoneNumberUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.SmsAddress;
import com.android.internal.telephony.WakeLockStateMachine;
import com.android.internal.telephony.cdma.sms.BearerData;
import com.android.internal.telephony.cdma.sms.CdmaSmsAddress;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public final class CdmaServiceCategoryProgramHandler extends WakeLockStateMachine
{
  final CommandsInterface mCi;
  private final BroadcastReceiver mScpResultsReceiver = new BroadcastReceiver()
  {
    private void sendScpResults()
    {
      int i = getResultCode();
      if ((i != -1) && (i != 1))
        CdmaServiceCategoryProgramHandler.this.loge("SCP results error: result code = " + i);
      DataOutputStream localDataOutputStream;
      while (true)
      {
        return;
        Bundle localBundle = getResultExtras(false);
        if (localBundle == null)
        {
          CdmaServiceCategoryProgramHandler.this.loge("SCP results error: missing extras");
        }
        else
        {
          String str = localBundle.getString("sender");
          if (str == null)
          {
            CdmaServiceCategoryProgramHandler.this.loge("SCP results error: missing sender extra.");
          }
          else
          {
            ArrayList localArrayList = localBundle.getParcelableArrayList("results");
            if (localArrayList == null)
            {
              CdmaServiceCategoryProgramHandler.this.loge("SCP results error: missing results extra.");
            }
            else
            {
              BearerData localBearerData = new BearerData();
              localBearerData.messageType = 2;
              localBearerData.messageId = SmsMessage.getNextMessageId();
              localBearerData.serviceCategoryProgramResults = localArrayList;
              byte[] arrayOfByte = BearerData.encode(localBearerData);
              ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(100);
              localDataOutputStream = new DataOutputStream(localByteArrayOutputStream);
              try
              {
                localDataOutputStream.writeInt(4102);
                localDataOutputStream.writeInt(0);
                localDataOutputStream.writeInt(0);
                CdmaSmsAddress localCdmaSmsAddress = CdmaSmsAddress.parse(PhoneNumberUtils.cdmaCheckAndProcessPlusCodeForSms(str));
                localDataOutputStream.write(localCdmaSmsAddress.digitMode);
                localDataOutputStream.write(localCdmaSmsAddress.numberMode);
                localDataOutputStream.write(localCdmaSmsAddress.ton);
                localDataOutputStream.write(localCdmaSmsAddress.numberPlan);
                localDataOutputStream.write(localCdmaSmsAddress.numberOfDigits);
                localDataOutputStream.write(localCdmaSmsAddress.origBytes, 0, localCdmaSmsAddress.origBytes.length);
                localDataOutputStream.write(0);
                localDataOutputStream.write(0);
                localDataOutputStream.write(0);
                localDataOutputStream.write(arrayOfByte.length);
                localDataOutputStream.write(arrayOfByte, 0, arrayOfByte.length);
                CdmaServiceCategoryProgramHandler.this.mCi.sendCdmaSms(localByteArrayOutputStream.toByteArray(), null);
                try
                {
                  localDataOutputStream.close();
                }
                catch (IOException localIOException3)
                {
                }
              }
              catch (IOException localIOException2)
              {
                localIOException2 = localIOException2;
                CdmaServiceCategoryProgramHandler.this.loge("exception creating SCP results PDU", localIOException2);
                localDataOutputStream.close();
              }
              finally
              {
              }
            }
          }
        }
      }
      try
      {
        localDataOutputStream.close();
        label363: throw localObject;
      }
      catch (IOException localIOException1)
      {
        break label363;
      }
    }

    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      sendScpResults();
      CdmaServiceCategoryProgramHandler.this.log("mScpResultsReceiver finished");
      CdmaServiceCategoryProgramHandler.this.sendMessage(2);
    }
  };

  CdmaServiceCategoryProgramHandler(Context paramContext, CommandsInterface paramCommandsInterface)
  {
    super("CdmaServiceCategoryProgramHandler", paramContext, null);
    this.mContext = paramContext;
    this.mCi = paramCommandsInterface;
  }

  private boolean handleServiceCategoryProgramData(SmsMessage paramSmsMessage)
  {
    ArrayList localArrayList = paramSmsMessage.getSmsCbProgramData();
    if (localArrayList == null)
      loge("handleServiceCategoryProgramData: program data list is null!");
    for (boolean bool = false; ; bool = true)
    {
      return bool;
      Intent localIntent = new Intent("android.provider.Telephony.SMS_SERVICE_CATEGORY_PROGRAM_DATA_RECEIVED");
      localIntent.putExtra("sender", paramSmsMessage.getOriginatingAddress());
      localIntent.putParcelableArrayListExtra("program_data", localArrayList);
      this.mContext.sendOrderedBroadcast(localIntent, "android.permission.RECEIVE_SMS", 16, this.mScpResultsReceiver, getHandler(), -1, null, null);
    }
  }

  static CdmaServiceCategoryProgramHandler makeScpHandler(Context paramContext, CommandsInterface paramCommandsInterface)
  {
    CdmaServiceCategoryProgramHandler localCdmaServiceCategoryProgramHandler = new CdmaServiceCategoryProgramHandler(paramContext, paramCommandsInterface);
    localCdmaServiceCategoryProgramHandler.start();
    return localCdmaServiceCategoryProgramHandler;
  }

  protected boolean handleSmsMessage(Message paramMessage)
  {
    if ((paramMessage.obj instanceof SmsMessage));
    for (boolean bool = handleServiceCategoryProgramData((SmsMessage)paramMessage.obj); ; bool = false)
    {
      return bool;
      loge("handleMessage got object of type: " + paramMessage.obj.getClass().getName());
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaServiceCategoryProgramHandler
 * JD-Core Version:    0.6.2
 */