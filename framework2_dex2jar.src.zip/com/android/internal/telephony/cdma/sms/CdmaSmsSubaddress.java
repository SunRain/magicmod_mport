package com.android.internal.telephony.cdma.sms;

public class CdmaSmsSubaddress
{
  public byte odd;
  public byte[] origBytes;
  public int type;
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.sms.CdmaSmsSubaddress
 * JD-Core Version:    0.6.2
 */