package com.android.internal.telephony.cdma;

import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.Intent;
import android.os.Message;
import android.os.SystemProperties;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.GsmAlphabet.TextEncodingDetails;
import com.android.internal.telephony.ImsSMSDispatcher;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.SMSDispatcher;
import com.android.internal.telephony.SMSDispatcher.SmsTracker;
import com.android.internal.telephony.SmsHeader;
import com.android.internal.telephony.SmsMessageBase;
import com.android.internal.telephony.SmsUsageMonitor;
import com.android.internal.telephony.cdma.sms.UserData;
import java.util.ArrayList;
import java.util.HashMap;

public class CdmaSMSDispatcher extends SMSDispatcher
{
  private static final String TAG = "CdmaSMSDispatcher";
  private static final boolean VDBG;

  public CdmaSMSDispatcher(PhoneBase paramPhoneBase, SmsUsageMonitor paramSmsUsageMonitor, ImsSMSDispatcher paramImsSMSDispatcher)
  {
    super(paramPhoneBase, paramSmsUsageMonitor, paramImsSMSDispatcher);
    Rlog.d("CdmaSMSDispatcher", "CdmaSMSDispatcher created");
  }

  protected GsmAlphabet.TextEncodingDetails calculateLength(CharSequence paramCharSequence, boolean paramBoolean)
  {
    return SmsMessage.calculateLength(paramCharSequence, paramBoolean);
  }

  protected String getFormat()
  {
    return "3gpp2";
  }

  void handleCdmaStatusReport(SmsMessage paramSmsMessage)
  {
    int i = 0;
    int j = this.deliveryPendingList.size();
    while (true)
    {
      PendingIntent localPendingIntent;
      Intent localIntent;
      if (i < j)
      {
        SMSDispatcher.SmsTracker localSmsTracker = (SMSDispatcher.SmsTracker)this.deliveryPendingList.get(i);
        if (localSmsTracker.mMessageRef != paramSmsMessage.mMessageRef)
          break label112;
        this.deliveryPendingList.remove(i);
        localSmsTracker.updateSentMessageStatus(this.mContext, 0);
        localPendingIntent = localSmsTracker.mDeliveryIntent;
        localIntent = new Intent();
        localIntent.putExtra("pdu", paramSmsMessage.getPdu());
        localIntent.putExtra("format", getFormat());
      }
      try
      {
        localPendingIntent.send(this.mContext, -1, localIntent);
        label111: return;
        label112: i++;
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
        break label111;
      }
    }
  }

  protected void handleStatusReport(Object paramObject)
  {
    if ((paramObject instanceof SmsMessage))
      handleCdmaStatusReport((SmsMessage)paramObject);
    while (true)
    {
      return;
      Rlog.e("CdmaSMSDispatcher", "handleStatusReport() called for object type " + paramObject.getClass().getName());
    }
  }

  protected void sendData(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfByte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    if (paramPendingIntent2 != null);
    for (boolean bool = true; ; bool = false)
    {
      sendSubmitPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramInt, paramArrayOfByte, SmsMessage.getSubmitPdu(paramString2, paramString1, paramInt, paramArrayOfByte, bool)), paramPendingIntent1, paramPendingIntent2, getFormat()));
      return;
    }
  }

  protected void sendNewSubmitPdu(String paramString1, String paramString2, String paramString3, SmsHeader paramSmsHeader, int paramInt, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, boolean paramBoolean)
  {
    int i = 1;
    UserData localUserData = new UserData();
    localUserData.payloadStr = paramString3;
    localUserData.userDataHeader = paramSmsHeader;
    if (paramInt == i)
    {
      localUserData.msgEncoding = 9;
      localUserData.msgEncodingSet = i;
      if ((paramPendingIntent2 == null) || (!paramBoolean))
        break label97;
    }
    while (true)
    {
      sendSubmitPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramString3, SmsMessage.getSubmitPdu(paramString1, localUserData, i)), paramPendingIntent1, paramPendingIntent2, getFormat()));
      return;
      localUserData.msgEncoding = 4;
      break;
      label97: i = 0;
    }
  }

  protected void sendSms(SMSDispatcher.SmsTracker paramSmsTracker)
  {
    byte[] arrayOfByte = (byte[])paramSmsTracker.mData.get("pdu");
    Message localMessage = obtainMessage(2, paramSmsTracker);
    Rlog.d("CdmaSMSDispatcher", "sendSms:  isIms()=" + isIms() + " mRetryCount=" + paramSmsTracker.mRetryCount + " mImsRetry=" + paramSmsTracker.mImsRetry + " mMessageRef=" + paramSmsTracker.mMessageRef + " SS=" + this.mPhone.getServiceState().getState());
    if ((paramSmsTracker.mImsRetry == 0) && (!isIms()))
      this.mCi.sendCdmaSms(arrayOfByte, localMessage);
    while (true)
    {
      return;
      this.mCi.sendImsCdmaSms(arrayOfByte, paramSmsTracker.mImsRetry, paramSmsTracker.mMessageRef, localMessage);
      paramSmsTracker.mImsRetry = (1 + paramSmsTracker.mImsRetry);
    }
  }

  void sendStatusReportMessage(SmsMessage paramSmsMessage)
  {
    sendMessage(obtainMessage(10, paramSmsMessage));
  }

  protected void sendSubmitPdu(SMSDispatcher.SmsTracker paramSmsTracker)
  {
    if ((!SystemProperties.getBoolean("ril.cdma.inecmmode", false)) || (paramSmsTracker.mSentIntent != null));
    try
    {
      paramSmsTracker.mSentIntent.send(4);
      while (true)
      {
        label24: return;
        sendRawPdu(paramSmsTracker);
      }
    }
    catch (PendingIntent.CanceledException localCanceledException)
    {
      break label24;
    }
  }

  protected void sendText(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    if (paramPendingIntent2 != null);
    for (boolean bool = true; ; bool = false)
    {
      sendSubmitPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramString3, SmsMessage.getSubmitPdu(paramString2, paramString1, paramString3, bool, null)), paramPendingIntent1, paramPendingIntent2, getFormat()));
      return;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaSMSDispatcher
 * JD-Core Version:    0.6.2
 */