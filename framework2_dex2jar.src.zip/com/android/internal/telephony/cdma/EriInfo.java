package com.android.internal.telephony.cdma;

public final class EriInfo
{
  public static final int ROAMING_ICON_MODE_FLASH = 1;
  public static final int ROAMING_ICON_MODE_NORMAL = 0;
  public static final int ROAMING_INDICATOR_FLASH = 2;
  public static final int ROAMING_INDICATOR_OFF = 1;
  public static final int ROAMING_INDICATOR_ON;
  public int alertId;
  public int callPromptId;
  public String eriText;
  public int iconIndex;
  public int iconMode;
  public int roamingIndicator;

  public EriInfo(int paramInt1, int paramInt2, int paramInt3, String paramString, int paramInt4, int paramInt5)
  {
    this.roamingIndicator = paramInt1;
    this.iconIndex = paramInt2;
    this.iconMode = paramInt3;
    this.eriText = paramString;
    this.callPromptId = paramInt4;
    this.alertId = paramInt5;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.EriInfo
 * JD-Core Version:    0.6.2
 */