package com.android.internal.telephony.cdma;

import android.content.Context;
import android.telephony.Rlog;
import com.android.internal.telephony.PhoneBase;
import java.util.HashMap;

public final class EriManager
{
  private static final boolean DBG = true;
  static final int ERI_FROM_FILE_SYSTEM = 1;
  static final int ERI_FROM_MODEM = 2;
  static final int ERI_FROM_XML = 0;
  private static final String LOG_TAG = "CDMA";
  private static final boolean VDBG;
  private Context mContext;
  private EriFile mEriFile;
  private int mEriFileSource = 0;
  private boolean mIsEriFileLoaded;

  public EriManager(PhoneBase paramPhoneBase, Context paramContext, int paramInt)
  {
    this.mContext = paramContext;
    this.mEriFileSource = paramInt;
    this.mEriFile = new EriFile();
  }

  private EriDisplayInformation getEriDisplayInformation(int paramInt1, int paramInt2)
  {
    Object localObject;
    if (this.mIsEriFileLoaded)
    {
      EriInfo localEriInfo3 = getEriInfo(paramInt1);
      if (localEriInfo3 != null)
      {
        localObject = new EriDisplayInformation(localEriInfo3.iconIndex, localEriInfo3.iconMode, localEriInfo3.eriText);
        return localObject;
      }
    }
    EriDisplayInformation localEriDisplayInformation;
    switch (paramInt1)
    {
    default:
      if (!this.mIsEriFileLoaded)
      {
        Rlog.d("CDMA", "ERI File not loaded");
        if (paramInt2 > 2)
          localEriDisplayInformation = new EriDisplayInformation(2, 1, this.mContext.getText(17039498).toString());
      }
      break;
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    }
    while (true)
    {
      localObject = localEriDisplayInformation;
      break;
      localEriDisplayInformation = new EriDisplayInformation(0, 0, this.mContext.getText(17039496).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(1, 0, this.mContext.getText(17039497).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(2, 1, this.mContext.getText(17039498).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039499).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039500).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039501).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039502).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039503).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039504).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039505).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039506).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039507).toString());
      continue;
      localEriDisplayInformation = new EriDisplayInformation(paramInt1, 0, this.mContext.getText(17039508).toString());
      continue;
      switch (paramInt2)
      {
      default:
        localEriDisplayInformation = new EriDisplayInformation(-1, -1, "ERI text");
        break;
      case 0:
        localEriDisplayInformation = new EriDisplayInformation(0, 0, this.mContext.getText(17039496).toString());
        break;
      case 1:
        localEriDisplayInformation = new EriDisplayInformation(1, 0, this.mContext.getText(17039497).toString());
        break;
      case 2:
        localEriDisplayInformation = new EriDisplayInformation(2, 1, this.mContext.getText(17039498).toString());
        continue;
        EriInfo localEriInfo1 = getEriInfo(paramInt1);
        EriInfo localEriInfo2 = getEriInfo(paramInt2);
        if (localEriInfo1 == null)
        {
          if (localEriInfo2 == null)
          {
            Rlog.e("CDMA", "ERI defRoamInd " + paramInt2 + " not found in ERI file ...on");
            localEriDisplayInformation = new EriDisplayInformation(0, 0, this.mContext.getText(17039496).toString());
          }
          else
          {
            localEriDisplayInformation = new EriDisplayInformation(localEriInfo2.iconIndex, localEriInfo2.iconMode, localEriInfo2.eriText);
          }
        }
        else
          localEriDisplayInformation = new EriDisplayInformation(localEriInfo1.iconIndex, localEriInfo1.iconMode, localEriInfo1.eriText);
        break;
      }
    }
  }

  private EriInfo getEriInfo(int paramInt)
  {
    if (this.mEriFile.mRoamIndTable.containsKey(Integer.valueOf(paramInt)));
    for (EriInfo localEriInfo = (EriInfo)this.mEriFile.mRoamIndTable.get(Integer.valueOf(paramInt)); ; localEriInfo = null)
      return localEriInfo;
  }

  private void loadEriFileFromFileSystem()
  {
  }

  private void loadEriFileFromModem()
  {
  }

  // ERROR //
  private void loadEriFileFromXml()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: getfield 33	com/android/internal/telephony/cdma/EriManager:mContext	Landroid/content/Context;
    //   6: invokevirtual 150	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   9: astore_2
    //   10: ldc 17
    //   12: ldc 152
    //   14: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: new 154	java/io/FileInputStream
    //   21: dup
    //   22: aload_2
    //   23: ldc 155
    //   25: invokevirtual 161	android/content/res/Resources:getString	(I)Ljava/lang/String;
    //   28: invokespecial 164	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   31: astore 29
    //   33: invokestatic 170	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   36: astore 5
    //   38: aload 5
    //   40: aload 29
    //   42: aconst_null
    //   43: invokeinterface 176 3 0
    //   48: ldc 17
    //   50: ldc 178
    //   52: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   55: pop
    //   56: aload 29
    //   58: astore_1
    //   59: aload 5
    //   61: ifnonnull +19 -> 80
    //   64: ldc 17
    //   66: ldc 180
    //   68: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   71: pop
    //   72: aload_2
    //   73: ldc 181
    //   75: invokevirtual 185	android/content/res/Resources:getXml	(I)Landroid/content/res/XmlResourceParser;
    //   78: astore 5
    //   80: aload 5
    //   82: ldc 187
    //   84: invokestatic 193	com/android/internal/util/XmlUtils:beginDocument	(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)V
    //   87: aload_0
    //   88: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   91: aload 5
    //   93: aconst_null
    //   94: ldc 195
    //   96: invokeinterface 199 3 0
    //   101: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   104: putfield 206	com/android/internal/telephony/cdma/EriManager$EriFile:mVersionNumber	I
    //   107: aload_0
    //   108: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   111: aload 5
    //   113: aconst_null
    //   114: ldc 208
    //   116: invokeinterface 199 3 0
    //   121: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   124: putfield 211	com/android/internal/telephony/cdma/EriManager$EriFile:mNumberOfEriEntries	I
    //   127: aload_0
    //   128: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   131: aload 5
    //   133: aconst_null
    //   134: ldc 213
    //   136: invokeinterface 199 3 0
    //   141: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   144: putfield 216	com/android/internal/telephony/cdma/EriManager$EriFile:mEriFileType	I
    //   147: iconst_0
    //   148: istore 11
    //   150: aload 5
    //   152: invokestatic 220	com/android/internal/util/XmlUtils:nextElement	(Lorg/xmlpull/v1/XmlPullParser;)V
    //   155: aload 5
    //   157: invokeinterface 223 1 0
    //   162: astore 12
    //   164: aload 12
    //   166: ifnonnull +132 -> 298
    //   169: iload 11
    //   171: aload_0
    //   172: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   175: getfield 211	com/android/internal/telephony/cdma/EriManager$EriFile:mNumberOfEriEntries	I
    //   178: if_icmpeq +49 -> 227
    //   181: ldc 17
    //   183: new 99	java/lang/StringBuilder
    //   186: dup
    //   187: invokespecial 100	java/lang/StringBuilder:<init>	()V
    //   190: ldc 225
    //   192: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: aload_0
    //   196: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   199: getfield 211	com/android/internal/telephony/cdma/EriManager$EriFile:mNumberOfEriEntries	I
    //   202: invokevirtual 109	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   205: ldc 227
    //   207: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   210: iload 11
    //   212: invokevirtual 109	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   215: ldc 229
    //   217: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: invokevirtual 112	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   223: invokestatic 115	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   226: pop
    //   227: ldc 17
    //   229: ldc 231
    //   231: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   234: pop
    //   235: aload_0
    //   236: iconst_1
    //   237: putfield 44	com/android/internal/telephony/cdma/EriManager:mIsEriFileLoaded	Z
    //   240: aload 5
    //   242: instanceof 233
    //   245: ifeq +13 -> 258
    //   248: aload 5
    //   250: checkcast 233	android/content/res/XmlResourceParser
    //   253: invokeinterface 236 1 0
    //   258: aload_1
    //   259: ifnull +7 -> 266
    //   262: aload_1
    //   263: invokevirtual 237	java/io/FileInputStream:close	()V
    //   266: return
    //   267: astore 26
    //   269: ldc 17
    //   271: ldc 239
    //   273: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   276: pop
    //   277: aconst_null
    //   278: astore 5
    //   280: goto -221 -> 59
    //   283: astore_3
    //   284: ldc 17
    //   286: ldc 241
    //   288: invokestatic 72	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   291: pop
    //   292: aconst_null
    //   293: astore 5
    //   295: goto -236 -> 59
    //   298: aload 12
    //   300: ldc 243
    //   302: invokevirtual 248	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   305: ifeq +170 -> 475
    //   308: aload 5
    //   310: aconst_null
    //   311: ldc 250
    //   313: invokeinterface 199 3 0
    //   318: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   321: istore 20
    //   323: aload 5
    //   325: aconst_null
    //   326: ldc 252
    //   328: invokeinterface 199 3 0
    //   333: astore 21
    //   335: iload 20
    //   337: iflt +71 -> 408
    //   340: iload 20
    //   342: iconst_2
    //   343: if_icmpgt +65 -> 408
    //   346: aload_0
    //   347: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   350: getfield 256	com/android/internal/telephony/cdma/EriManager$EriFile:mCallPromptId	[Ljava/lang/String;
    //   353: iload 20
    //   355: aload 21
    //   357: aastore
    //   358: goto -208 -> 150
    //   361: astore 8
    //   363: ldc 17
    //   365: ldc_w 258
    //   368: aload 8
    //   370: invokestatic 261	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   373: pop
    //   374: aload 5
    //   376: instanceof 233
    //   379: ifeq +13 -> 392
    //   382: aload 5
    //   384: checkcast 233	android/content/res/XmlResourceParser
    //   387: invokeinterface 236 1 0
    //   392: aload_1
    //   393: ifnull -127 -> 266
    //   396: aload_1
    //   397: invokevirtual 237	java/io/FileInputStream:close	()V
    //   400: goto -134 -> 266
    //   403: astore 10
    //   405: goto -139 -> 266
    //   408: ldc 17
    //   410: new 99	java/lang/StringBuilder
    //   413: dup
    //   414: invokespecial 100	java/lang/StringBuilder:<init>	()V
    //   417: ldc_w 263
    //   420: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   423: iload 20
    //   425: invokevirtual 109	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   428: ldc_w 265
    //   431: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   434: invokevirtual 112	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   437: invokestatic 115	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   440: pop
    //   441: goto -291 -> 150
    //   444: astore 6
    //   446: aload 5
    //   448: instanceof 233
    //   451: ifeq +13 -> 464
    //   454: aload 5
    //   456: checkcast 233	android/content/res/XmlResourceParser
    //   459: invokeinterface 236 1 0
    //   464: aload_1
    //   465: ifnull +7 -> 472
    //   468: aload_1
    //   469: invokevirtual 237	java/io/FileInputStream:close	()V
    //   472: aload 6
    //   474: athrow
    //   475: aload 12
    //   477: ldc_w 267
    //   480: invokevirtual 248	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   483: ifeq -333 -> 150
    //   486: aload 5
    //   488: aconst_null
    //   489: ldc_w 269
    //   492: invokeinterface 199 3 0
    //   497: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   500: istore 13
    //   502: aload 5
    //   504: aconst_null
    //   505: ldc_w 271
    //   508: invokeinterface 199 3 0
    //   513: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   516: istore 14
    //   518: aload 5
    //   520: aconst_null
    //   521: ldc_w 273
    //   524: invokeinterface 199 3 0
    //   529: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   532: istore 15
    //   534: aload 5
    //   536: aconst_null
    //   537: ldc_w 275
    //   540: invokeinterface 199 3 0
    //   545: astore 16
    //   547: aload 5
    //   549: aconst_null
    //   550: ldc 243
    //   552: invokeinterface 199 3 0
    //   557: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   560: istore 17
    //   562: aload 5
    //   564: aconst_null
    //   565: ldc_w 277
    //   568: invokeinterface 199 3 0
    //   573: invokestatic 203	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   576: istore 18
    //   578: iinc 11 1
    //   581: aload_0
    //   582: getfield 40	com/android/internal/telephony/cdma/EriManager:mEriFile	Lcom/android/internal/telephony/cdma/EriManager$EriFile;
    //   585: getfield 119	com/android/internal/telephony/cdma/EriManager$EriFile:mRoamIndTable	Ljava/util/HashMap;
    //   588: iload 13
    //   590: invokestatic 125	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   593: new 52	com/android/internal/telephony/cdma/EriInfo
    //   596: dup
    //   597: iload 13
    //   599: iload 14
    //   601: iload 15
    //   603: aload 16
    //   605: iload 17
    //   607: iload 18
    //   609: invokespecial 280	com/android/internal/telephony/cdma/EriInfo:<init>	(IIILjava/lang/String;II)V
    //   612: invokevirtual 284	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   615: pop
    //   616: goto -466 -> 150
    //   619: astore 7
    //   621: goto -149 -> 472
    //   624: astore 31
    //   626: aload 29
    //   628: astore_1
    //   629: goto -345 -> 284
    //   632: astore 30
    //   634: aload 29
    //   636: astore_1
    //   637: goto -368 -> 269
    //
    // Exception table:
    //   from	to	target	type
    //   10	33	267	java/io/FileNotFoundException
    //   10	33	283	org/xmlpull/v1/XmlPullParserException
    //   80	240	361	java/lang/Exception
    //   298	358	361	java/lang/Exception
    //   408	441	361	java/lang/Exception
    //   475	616	361	java/lang/Exception
    //   262	266	403	java/io/IOException
    //   396	400	403	java/io/IOException
    //   80	240	444	finally
    //   298	358	444	finally
    //   363	374	444	finally
    //   408	441	444	finally
    //   475	616	444	finally
    //   468	472	619	java/io/IOException
    //   33	56	624	org/xmlpull/v1/XmlPullParserException
    //   33	56	632	java/io/FileNotFoundException
  }

  public void dispose()
  {
    this.mEriFile = new EriFile();
    this.mIsEriFileLoaded = false;
  }

  public int getCdmaEriIconIndex(int paramInt1, int paramInt2)
  {
    return getEriDisplayInformation(paramInt1, paramInt2).mEriIconIndex;
  }

  public int getCdmaEriIconMode(int paramInt1, int paramInt2)
  {
    return getEriDisplayInformation(paramInt1, paramInt2).mEriIconMode;
  }

  public String getCdmaEriText(int paramInt1, int paramInt2)
  {
    return getEriDisplayInformation(paramInt1, paramInt2).mEriIconText;
  }

  public int getEriFileType()
  {
    return this.mEriFile.mEriFileType;
  }

  public int getEriFileVersion()
  {
    return this.mEriFile.mVersionNumber;
  }

  public int getEriNumberOfEntries()
  {
    return this.mEriFile.mNumberOfEriEntries;
  }

  public boolean isEriFileLoaded()
  {
    return this.mIsEriFileLoaded;
  }

  public void loadEriFile()
  {
    switch (this.mEriFileSource)
    {
    default:
      loadEriFileFromXml();
    case 2:
    case 1:
    }
    while (true)
    {
      return;
      loadEriFileFromModem();
      continue;
      loadEriFileFromFileSystem();
    }
  }

  class EriDisplayInformation
  {
    int mEriIconIndex;
    int mEriIconMode;
    String mEriIconText;

    EriDisplayInformation(int paramInt1, int paramString, String arg4)
    {
      this.mEriIconIndex = paramInt1;
      this.mEriIconMode = paramString;
      Object localObject;
      this.mEriIconText = localObject;
    }

    public String toString()
    {
      return "EriDisplayInformation: { IconIndex: " + this.mEriIconIndex + " EriIconMode: " + this.mEriIconMode + " EriIconText: " + this.mEriIconText + " }";
    }
  }

  class EriFile
  {
    String[] mCallPromptId = { "", "", "" };
    int mEriFileType = -1;
    int mNumberOfEriEntries = 0;
    HashMap<Integer, EriInfo> mRoamIndTable = new HashMap();
    int mVersionNumber = -1;

    EriFile()
    {
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.EriManager
 * JD-Core Version:    0.6.2
 */