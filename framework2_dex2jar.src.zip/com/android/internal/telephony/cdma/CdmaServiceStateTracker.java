package com.android.internal.telephony.cdma;

import android.app.AlarmManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.ContentObserver;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.provider.Settings.SettingNotFoundException;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.cdma.CdmaCellLocation;
import android.text.TextUtils;
import android.util.EventLog;
import android.util.TimeUtils;
import com.android.internal.telephony.CommandException;
import com.android.internal.telephony.CommandException.Error;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.Injector.ServiceStateTrackerHook;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

public class CdmaServiceStateTracker extends ServiceStateTracker
{
  static final String LOG_TAG = "CdmaSST";
  private static final int NITZ_UPDATE_DIFF_DEFAULT = 2000;
  private static final int NITZ_UPDATE_SPACING_DEFAULT = 600000;
  private static final String UNACTIVATED_MIN2_VALUE = "000000";
  private static final String UNACTIVATED_MIN_VALUE = "1111110111";
  private static final String WAKELOCK_TAG = "ServiceStateTracker";
  private ContentObserver mAutoTimeObserver = new ContentObserver(new Handler())
  {
    public void onChange(boolean paramAnonymousBoolean)
    {
      CdmaServiceStateTracker.this.log("Auto time state changed");
      CdmaServiceStateTracker.this.revertToNitzTime();
    }
  };
  private ContentObserver mAutoTimeZoneObserver = new ContentObserver(new Handler())
  {
    public void onChange(boolean paramAnonymousBoolean)
    {
      CdmaServiceStateTracker.this.log("Auto time zone state changed");
      CdmaServiceStateTracker.this.revertToNitzTimeZone();
    }
  };
  protected RegistrantList mCdmaForSubscriptionInfoReadyRegistrants = new RegistrantList();
  private boolean mCdmaRoaming = false;
  private CdmaSubscriptionSourceManager mCdmaSSM;
  CdmaCellLocation mCellLoc;
  private ContentResolver mCr;
  protected String mCurPlmn = null;
  private String mCurrentCarrier = null;
  int mCurrentOtaspMode = 0;
  private int mDefaultRoamingIndicator;
  protected boolean mGotCountryCode = false;
  protected int[] mHomeNetworkId = null;
  protected int[] mHomeSystemId = null;
  private boolean mIsEriTextLoaded = false;
  private boolean mIsInPrl;
  protected boolean mIsMinInfoReady = false;
  protected boolean mIsSubscriptionFromRuim = false;
  protected String mMdn;
  protected String mMin;
  protected boolean mNeedFixZone = false;
  CdmaCellLocation mNewCellLoc;
  private int mNitzUpdateDiff = SystemProperties.getInt("ro.nitz_update_diff", 2000);
  private int mNitzUpdateSpacing = SystemProperties.getInt("ro.nitz_update_spacing", 600000);
  CDMAPhone mPhone;
  protected String mPrlVersion;
  private String mRegistrationDeniedReason;
  protected int mRegistrationState = -1;
  private int mRoamingIndicator;
  long mSavedAtTime;
  long mSavedTime;
  String mSavedTimeZone;
  private PowerManager.WakeLock mWakeLock;
  private boolean mZoneDst;
  private int mZoneOffset;
  private long mZoneTime;

  public CdmaServiceStateTracker(CDMAPhone paramCDMAPhone)
  {
    this(paramCDMAPhone, new CellInfoCdma());
  }

  protected CdmaServiceStateTracker(CDMAPhone paramCDMAPhone, CellInfo paramCellInfo)
  {
    super(paramCDMAPhone, paramCDMAPhone.mCi, paramCellInfo);
    this.mPhone = paramCDMAPhone;
    this.mCr = paramCDMAPhone.getContext().getContentResolver();
    this.mCellLoc = new CdmaCellLocation();
    this.mNewCellLoc = new CdmaCellLocation();
    this.mCdmaSSM = CdmaSubscriptionSourceManager.getInstance(paramCDMAPhone.getContext(), this.mCi, this, 39, null);
    if (this.mCdmaSSM.getCdmaSubscriptionSource() == 0);
    for (boolean bool2 = true; ; bool2 = false)
    {
      this.mIsSubscriptionFromRuim = bool2;
      this.mWakeLock = ((PowerManager)paramCDMAPhone.getContext().getSystemService("power")).newWakeLock(1, "ServiceStateTracker");
      this.mCi.registerForRadioStateChanged(this, 1, null);
      this.mCi.registerForVoiceNetworkStateChanged(this, 30, null);
      this.mCi.setOnNITZTime(this, 11, null);
      this.mCi.registerForCdmaPrlChanged(this, 40, null);
      paramCDMAPhone.registerForEriFileLoaded(this, 36, null);
      this.mCi.registerForCdmaOtaProvision(this, 37, null);
      if (Settings.Global.getInt(this.mCr, "airplane_mode_on", 0) <= 0)
        bool1 = true;
      this.mDesiredPowerState = bool1;
      this.mCr.registerContentObserver(Settings.Global.getUriFor("auto_time"), true, this.mAutoTimeObserver);
      this.mCr.registerContentObserver(Settings.Global.getUriFor("auto_time_zone"), true, this.mAutoTimeZoneObserver);
      setSignalStrengthDefaultValues();
      Injector.CdmaServiceStateTrackerHook.after_CdmaServiceStateTracker(this, paramCDMAPhone);
      return;
    }
  }

  private TimeZone findTimeZone(int paramInt, boolean paramBoolean, long paramLong)
  {
    int i = paramInt;
    if (paramBoolean)
      i += 4480;
    String[] arrayOfString = TimeZone.getAvailableIDs(i);
    Object localObject = null;
    Date localDate = new Date(paramLong);
    int j = arrayOfString.length;
    for (int k = 0; ; k++)
      if (k < j)
      {
        TimeZone localTimeZone = TimeZone.getTimeZone(arrayOfString[k]);
        if ((localTimeZone.getOffset(paramLong) == paramInt) && (localTimeZone.inDaylightTime(localDate) == paramBoolean))
          localObject = localTimeZone;
      }
      else
      {
        return localObject;
      }
  }

  private boolean getAutoTime()
  {
    boolean bool = true;
    try
    {
      int i = Settings.Global.getInt(this.mCr, "auto_time");
      if (i > 0);
      while (true)
      {
        label16: return bool;
        bool = false;
      }
    }
    catch (Settings.SettingNotFoundException localSettingNotFoundException)
    {
      break label16;
    }
  }

  private boolean getAutoTimeZone()
  {
    boolean bool = true;
    try
    {
      int i = Settings.Global.getInt(this.mCr, "auto_time_zone");
      if (i > 0);
      while (true)
      {
        label16: return bool;
        bool = false;
      }
    }
    catch (Settings.SettingNotFoundException localSettingNotFoundException)
    {
      break label16;
    }
  }

  private TimeZone getNitzTimeZone(int paramInt, boolean paramBoolean, long paramLong)
  {
    TimeZone localTimeZone = findTimeZone(paramInt, paramBoolean, paramLong);
    boolean bool;
    StringBuilder localStringBuilder;
    if (localTimeZone == null)
    {
      if (!paramBoolean)
      {
        bool = true;
        localTimeZone = findTimeZone(paramInt, bool, paramLong);
      }
    }
    else
    {
      localStringBuilder = new StringBuilder().append("getNitzTimeZone returning ");
      if (localTimeZone != null)
        break label78;
    }
    label78: for (Object localObject = localTimeZone; ; localObject = localTimeZone.getID())
    {
      log(localObject);
      return localTimeZone;
      bool = false;
      break;
    }
  }

  private void getSubscriptionInfoAndStartPollingThreads()
  {
    this.mCi.getCDMASubscription(obtainMessage(34));
    pollState();
  }

  private void handleCdmaSubscriptionSource(int paramInt)
  {
    log("Subscription Source : " + paramInt);
    if (paramInt == 0);
    for (boolean bool = true; ; bool = false)
    {
      this.mIsSubscriptionFromRuim = bool;
      saveCdmaSubscriptionSource(paramInt);
      if (!this.mIsSubscriptionFromRuim)
        sendMessage(obtainMessage(35));
      return;
    }
  }

  private boolean isHomeSid(int paramInt)
  {
    int i;
    if (this.mHomeSystemId != null)
    {
      i = 0;
      if (i < this.mHomeSystemId.length)
        if (paramInt != this.mHomeSystemId[i]);
    }
    for (boolean bool = true; ; bool = false)
    {
      return bool;
      i++;
      break;
    }
  }

  private boolean isRoamIndForHomeSystem(String paramString)
  {
    boolean bool = false;
    String str = SystemProperties.get("ro.cdma.homesystem");
    String[] arrayOfString;
    int i;
    if (!TextUtils.isEmpty(str))
    {
      arrayOfString = str.split(",");
      i = arrayOfString.length;
    }
    for (int j = 0; ; j++)
      if (j < i)
      {
        if (arrayOfString[j].equals(paramString))
          bool = true;
      }
      else
        return bool;
  }

  private boolean isRoamingBetweenOperators(boolean paramBoolean, ServiceState paramServiceState)
  {
    boolean bool1 = true;
    String str1 = SystemProperties.get("gsm.sim.operator.alpha", "empty");
    String str2 = paramServiceState.getOperatorAlphaLong();
    String str3 = paramServiceState.getOperatorAlphaShort();
    boolean bool2;
    boolean bool3;
    if ((str2 != null) && (str1.equals(str2)))
    {
      bool2 = bool1;
      if ((str3 == null) || (!str1.equals(str3)))
        break label83;
      bool3 = bool1;
      label61: if ((!paramBoolean) || (bool2) || (bool3))
        break label89;
    }
    while (true)
    {
      return bool1;
      bool2 = false;
      break;
      label83: bool3 = false;
      break label61;
      label89: bool1 = false;
    }
  }

  private void queueNextSignalStrengthPoll()
  {
    if (this.mDontPollSignalStrength);
    while (true)
    {
      return;
      Message localMessage = obtainMessage();
      localMessage.what = 10;
      sendMessageDelayed(localMessage, 20000L);
    }
  }

  private boolean regCodeIsRoaming(int paramInt)
  {
    if (5 == paramInt);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void revertToNitzTime()
  {
    if (Settings.Global.getInt(this.mCr, "auto_time", 0) == 0);
    while (true)
    {
      return;
      log("revertToNitzTime: mSavedTime=" + this.mSavedTime + " mSavedAtTime=" + this.mSavedAtTime);
      if ((this.mSavedTime != 0L) && (this.mSavedAtTime != 0L))
        setAndBroadcastNetworkSetTime(this.mSavedTime + (SystemClock.elapsedRealtime() - this.mSavedAtTime));
    }
  }

  private void revertToNitzTimeZone()
  {
    if (Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "auto_time_zone", 0) == 0);
    while (true)
    {
      return;
      log("revertToNitzTimeZone: tz='" + this.mSavedTimeZone);
      if (this.mSavedTimeZone != null)
        setAndBroadcastNetworkSetTimeZone(this.mSavedTimeZone);
    }
  }

  private void saveCdmaSubscriptionSource(int paramInt)
  {
    log("Storing cdma subscription source: " + paramInt);
    Settings.Global.putInt(this.mPhone.getContext().getContentResolver(), "subscription_mode", paramInt);
  }

  private void saveNitzTimeZone(String paramString)
  {
    this.mSavedTimeZone = paramString;
  }

  private void setAndBroadcastNetworkSetTime(long paramLong)
  {
    log("setAndBroadcastNetworkSetTime: time=" + paramLong + "ms");
    SystemClock.setCurrentTimeMillis(paramLong);
    Intent localIntent = new Intent("android.intent.action.NETWORK_SET_TIME");
    localIntent.addFlags(536870912);
    localIntent.putExtra("time", paramLong);
    this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
  }

  private void setAndBroadcastNetworkSetTimeZone(String paramString)
  {
    log("setAndBroadcastNetworkSetTimeZone: setTimeZone=" + paramString);
    ((AlarmManager)this.mPhone.getContext().getSystemService("alarm")).setTimeZone(paramString);
    Intent localIntent = new Intent("android.intent.action.NETWORK_SET_TIMEZONE");
    localIntent.addFlags(536870912);
    localIntent.putExtra("time-zone", paramString);
    this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
  }

  // ERROR //
  private void setTimeFromNITZString(String paramString, long paramLong)
  {
    // Byte code:
    //   0: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   3: lstore 4
    //   5: aload_0
    //   6: new 296	java/lang/StringBuilder
    //   9: dup
    //   10: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   13: ldc_w 500
    //   16: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: aload_1
    //   20: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: ldc_w 361
    //   26: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: lload_2
    //   30: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   33: ldc_w 502
    //   36: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: lload 4
    //   41: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   44: ldc_w 504
    //   47: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: lload 4
    //   52: lload_2
    //   53: lsub
    //   54: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   57: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   60: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   63: ldc_w 506
    //   66: invokestatic 275	java/util/TimeZone:getTimeZone	(Ljava/lang/String;)Ljava/util/TimeZone;
    //   69: invokestatic 511	java/util/Calendar:getInstance	(Ljava/util/TimeZone;)Ljava/util/Calendar;
    //   72: astore 7
    //   74: aload 7
    //   76: invokevirtual 514	java/util/Calendar:clear	()V
    //   79: aload 7
    //   81: bipush 16
    //   83: iconst_0
    //   84: invokevirtual 518	java/util/Calendar:set	(II)V
    //   87: aload_1
    //   88: ldc_w 520
    //   91: invokevirtual 367	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   94: astore 8
    //   96: aload 7
    //   98: iconst_1
    //   99: sipush 2000
    //   102: aload 8
    //   104: iconst_0
    //   105: aaload
    //   106: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   109: iadd
    //   110: invokevirtual 518	java/util/Calendar:set	(II)V
    //   113: aload 7
    //   115: iconst_2
    //   116: iconst_m1
    //   117: aload 8
    //   119: iconst_1
    //   120: aaload
    //   121: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   124: iadd
    //   125: invokevirtual 518	java/util/Calendar:set	(II)V
    //   128: aload 7
    //   130: iconst_5
    //   131: aload 8
    //   133: iconst_2
    //   134: aaload
    //   135: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   138: invokevirtual 518	java/util/Calendar:set	(II)V
    //   141: aload 7
    //   143: bipush 10
    //   145: aload 8
    //   147: iconst_3
    //   148: aaload
    //   149: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   152: invokevirtual 518	java/util/Calendar:set	(II)V
    //   155: aload 7
    //   157: bipush 12
    //   159: aload 8
    //   161: iconst_4
    //   162: aaload
    //   163: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   166: invokevirtual 518	java/util/Calendar:set	(II)V
    //   169: aload 7
    //   171: bipush 13
    //   173: aload 8
    //   175: iconst_5
    //   176: aaload
    //   177: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   180: invokevirtual 518	java/util/Calendar:set	(II)V
    //   183: aload_1
    //   184: bipush 45
    //   186: invokevirtual 530	java/lang/String:indexOf	(I)I
    //   189: iconst_m1
    //   190: if_icmpne +1077 -> 1267
    //   193: iconst_1
    //   194: istore 9
    //   196: aload 8
    //   198: bipush 6
    //   200: aaload
    //   201: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   204: istore 10
    //   206: aload 8
    //   208: arraylength
    //   209: bipush 8
    //   211: if_icmplt +1062 -> 1273
    //   214: aload 8
    //   216: bipush 7
    //   218: aaload
    //   219: invokestatic 526	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   222: istore 11
    //   224: goto +1021 -> 1245
    //   227: sipush 1000
    //   230: bipush 60
    //   232: bipush 15
    //   234: iload 12
    //   236: iload 10
    //   238: imul
    //   239: imul
    //   240: imul
    //   241: imul
    //   242: istore 13
    //   244: aconst_null
    //   245: astore 14
    //   247: aload 8
    //   249: arraylength
    //   250: bipush 9
    //   252: if_icmplt +20 -> 272
    //   255: aload 8
    //   257: bipush 8
    //   259: aaload
    //   260: bipush 33
    //   262: bipush 47
    //   264: invokevirtual 534	java/lang/String:replace	(CC)Ljava/lang/String;
    //   267: invokestatic 275	java/util/TimeZone:getTimeZone	(Ljava/lang/String;)Ljava/util/TimeZone;
    //   270: astore 14
    //   272: ldc_w 536
    //   275: invokestatic 353	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   278: astore 15
    //   280: aload 14
    //   282: ifnonnull +51 -> 333
    //   285: aload_0
    //   286: getfield 116	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mGotCountryCode	Z
    //   289: ifeq +44 -> 333
    //   292: aload 15
    //   294: ifnull +997 -> 1291
    //   297: aload 15
    //   299: invokevirtual 539	java/lang/String:length	()I
    //   302: ifle +989 -> 1291
    //   305: iload 11
    //   307: ifeq +978 -> 1285
    //   310: iconst_1
    //   311: istore 45
    //   313: aload 7
    //   315: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   318: lstore 46
    //   320: iload 13
    //   322: iload 45
    //   324: lload 46
    //   326: aload 15
    //   328: invokestatic 547	android/util/TimeUtils:getTimeZone	(IZJLjava/lang/String;)Ljava/util/TimeZone;
    //   331: astore 14
    //   333: aload 14
    //   335: ifnull +29 -> 364
    //   338: aload_0
    //   339: getfield 549	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mZoneOffset	I
    //   342: iload 13
    //   344: if_icmpne +20 -> 364
    //   347: aload_0
    //   348: getfield 551	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mZoneDst	Z
    //   351: istore 40
    //   353: iload 11
    //   355: ifeq +953 -> 1308
    //   358: iconst_1
    //   359: istore 41
    //   361: goto +895 -> 1256
    //   364: aload_0
    //   365: iconst_1
    //   366: putfield 114	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mNeedFixZone	Z
    //   369: aload_0
    //   370: iload 13
    //   372: putfield 549	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mZoneOffset	I
    //   375: iload 11
    //   377: ifeq +937 -> 1314
    //   380: iconst_1
    //   381: istore 16
    //   383: aload_0
    //   384: iload 16
    //   386: putfield 551	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mZoneDst	Z
    //   389: aload_0
    //   390: aload 7
    //   392: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   395: putfield 553	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mZoneTime	J
    //   398: new 296	java/lang/StringBuilder
    //   401: dup
    //   402: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   405: ldc_w 555
    //   408: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   411: iload 13
    //   413: invokevirtual 336	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   416: ldc_w 557
    //   419: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   422: iload 11
    //   424: invokevirtual 336	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   427: ldc_w 559
    //   430: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   433: astore 17
    //   435: aload 14
    //   437: ifnull +147 -> 584
    //   440: aload 14
    //   442: invokevirtual 317	java/util/TimeZone:getID	()Ljava/lang/String;
    //   445: astore 18
    //   447: aload_0
    //   448: aload 17
    //   450: aload 18
    //   452: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   455: ldc_w 561
    //   458: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   461: aload 15
    //   463: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   466: ldc_w 563
    //   469: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   472: aload_0
    //   473: getfield 116	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mGotCountryCode	Z
    //   476: invokevirtual 566	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   479: ldc_w 568
    //   482: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   485: aload_0
    //   486: getfield 114	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mNeedFixZone	Z
    //   489: invokevirtual 566	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   492: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   495: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   498: aload 14
    //   500: ifnull +28 -> 528
    //   503: aload_0
    //   504: invokespecial 570	com/android/internal/telephony/cdma/CdmaServiceStateTracker:getAutoTimeZone	()Z
    //   507: ifeq +12 -> 519
    //   510: aload_0
    //   511: aload 14
    //   513: invokevirtual 317	java/util/TimeZone:getID	()Ljava/lang/String;
    //   516: invokespecial 434	com/android/internal/telephony/cdma/CdmaServiceStateTracker:setAndBroadcastNetworkSetTimeZone	(Ljava/lang/String;)V
    //   519: aload_0
    //   520: aload 14
    //   522: invokevirtual 317	java/util/TimeZone:getID	()Ljava/lang/String;
    //   525: invokespecial 572	com/android/internal/telephony/cdma/CdmaServiceStateTracker:saveNitzTimeZone	(Ljava/lang/String;)V
    //   528: ldc_w 574
    //   531: invokestatic 353	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   534: astore 19
    //   536: aload 19
    //   538: ifnull +54 -> 592
    //   541: aload 19
    //   543: ldc_w 576
    //   546: invokevirtual 371	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   549: ifeq +43 -> 592
    //   552: aload_0
    //   553: ldc_w 578
    //   556: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   559: goto +707 -> 1266
    //   562: aload 7
    //   564: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   567: lstore 43
    //   569: aload_0
    //   570: iload 13
    //   572: iload 42
    //   574: lload 43
    //   576: invokespecial 580	com/android/internal/telephony/cdma/CdmaServiceStateTracker:getNitzTimeZone	(IZJ)Ljava/util/TimeZone;
    //   579: astore 14
    //   581: goto -248 -> 333
    //   584: ldc_w 582
    //   587: astore 18
    //   589: goto -142 -> 447
    //   592: aload_0
    //   593: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   596: invokevirtual 587	android/os/PowerManager$WakeLock:acquire	()V
    //   599: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   602: lload_2
    //   603: lsub
    //   604: lstore 23
    //   606: lload 23
    //   608: lconst_0
    //   609: lcmp
    //   610: ifge +121 -> 731
    //   613: aload_0
    //   614: new 296	java/lang/StringBuilder
    //   617: dup
    //   618: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   621: ldc_w 589
    //   624: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   627: aload_1
    //   628: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   634: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   637: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   640: lstore 38
    //   642: aload_0
    //   643: new 296	java/lang/StringBuilder
    //   646: dup
    //   647: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   650: ldc_w 591
    //   653: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   656: lload 38
    //   658: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   661: ldc_w 593
    //   664: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   667: lload 38
    //   669: lload 4
    //   671: lsub
    //   672: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   675: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   678: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   681: aload_0
    //   682: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   685: invokevirtual 596	android/os/PowerManager$WakeLock:release	()V
    //   688: goto +578 -> 1266
    //   691: astore 6
    //   693: aload_0
    //   694: new 296	java/lang/StringBuilder
    //   697: dup
    //   698: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   701: ldc_w 598
    //   704: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   707: aload_1
    //   708: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   711: ldc_w 600
    //   714: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   717: aload 6
    //   719: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   722: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   725: invokevirtual 603	com/android/internal/telephony/cdma/CdmaServiceStateTracker:loge	(Ljava/lang/String;)V
    //   728: goto +538 -> 1266
    //   731: lload 23
    //   733: ldc2_w 604
    //   736: lcmp
    //   737: ifle +92 -> 829
    //   740: aload_0
    //   741: new 296	java/lang/StringBuilder
    //   744: dup
    //   745: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   748: ldc_w 607
    //   751: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: lload 23
    //   756: ldc2_w 608
    //   759: ldiv
    //   760: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   763: ldc_w 611
    //   766: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   769: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   772: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   775: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   778: lstore 36
    //   780: aload_0
    //   781: new 296	java/lang/StringBuilder
    //   784: dup
    //   785: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   788: ldc_w 591
    //   791: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   794: lload 36
    //   796: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   799: ldc_w 593
    //   802: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   805: lload 36
    //   807: lload 4
    //   809: lsub
    //   810: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   813: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   816: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   819: aload_0
    //   820: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   823: invokevirtual 596	android/os/PowerManager$WakeLock:release	()V
    //   826: goto +440 -> 1266
    //   829: lload 23
    //   831: l2i
    //   832: istore 25
    //   834: aload 7
    //   836: bipush 14
    //   838: iload 25
    //   840: invokevirtual 614	java/util/Calendar:add	(II)V
    //   843: aload_0
    //   844: invokespecial 616	com/android/internal/telephony/cdma/CdmaServiceStateTracker:getAutoTime	()Z
    //   847: ifeq +155 -> 1002
    //   850: aload 7
    //   852: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   855: invokestatic 621	java/lang/System:currentTimeMillis	()J
    //   858: lsub
    //   859: lstore 28
    //   861: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   864: aload_0
    //   865: getfield 418	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mSavedAtTime	J
    //   868: lsub
    //   869: lstore 30
    //   871: aload_0
    //   872: getfield 161	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mCr	Landroid/content/ContentResolver;
    //   875: ldc_w 623
    //   878: aload_0
    //   879: getfield 99	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mNitzUpdateSpacing	I
    //   882: invokestatic 223	android/provider/Settings$Global:getInt	(Landroid/content/ContentResolver;Ljava/lang/String;I)I
    //   885: istore 32
    //   887: aload_0
    //   888: getfield 161	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mCr	Landroid/content/ContentResolver;
    //   891: ldc_w 625
    //   894: aload_0
    //   895: getfield 103	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mNitzUpdateDiff	I
    //   898: invokestatic 223	android/provider/Settings$Global:getInt	(Landroid/content/ContentResolver;Ljava/lang/String;I)I
    //   901: istore 33
    //   903: aload_0
    //   904: getfield 418	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mSavedAtTime	J
    //   907: lconst_0
    //   908: lcmp
    //   909: ifeq +24 -> 933
    //   912: lload 30
    //   914: iload 32
    //   916: i2l
    //   917: lcmp
    //   918: ifgt +15 -> 933
    //   921: lload 28
    //   923: invokestatic 631	java/lang/Math:abs	(J)J
    //   926: iload 33
    //   928: i2l
    //   929: lcmp
    //   930: ifle +163 -> 1093
    //   933: aload_0
    //   934: new 296	java/lang/StringBuilder
    //   937: dup
    //   938: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   941: ldc_w 633
    //   944: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   947: aload 7
    //   949: invokevirtual 637	java/util/Calendar:getTime	()Ljava/util/Date;
    //   952: invokevirtual 306	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   955: ldc_w 639
    //   958: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   961: lload 23
    //   963: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   966: ldc_w 641
    //   969: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   972: lload 28
    //   974: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   977: ldc_w 643
    //   980: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   983: aload_1
    //   984: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   987: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   990: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   993: aload_0
    //   994: aload 7
    //   996: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   999: invokespecial 427	com/android/internal/telephony/cdma/CdmaServiceStateTracker:setAndBroadcastNetworkSetTime	(J)V
    //   1002: aload_0
    //   1003: ldc_w 645
    //   1006: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   1009: ldc_w 647
    //   1012: aload 7
    //   1014: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   1017: invokestatic 651	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   1020: invokestatic 654	android/os/SystemProperties:set	(Ljava/lang/String;Ljava/lang/String;)V
    //   1023: aload_0
    //   1024: aload 7
    //   1026: invokevirtual 542	java/util/Calendar:getTimeInMillis	()J
    //   1029: putfield 411	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mSavedTime	J
    //   1032: aload_0
    //   1033: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   1036: putfield 418	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mSavedAtTime	J
    //   1039: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   1042: lstore 26
    //   1044: aload_0
    //   1045: new 296	java/lang/StringBuilder
    //   1048: dup
    //   1049: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   1052: ldc_w 591
    //   1055: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1058: lload 26
    //   1060: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1063: ldc_w 593
    //   1066: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1069: lload 26
    //   1071: lload 4
    //   1073: lsub
    //   1074: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1077: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1080: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   1083: aload_0
    //   1084: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   1087: invokevirtual 596	android/os/PowerManager$WakeLock:release	()V
    //   1090: goto +176 -> 1266
    //   1093: aload_0
    //   1094: new 296	java/lang/StringBuilder
    //   1097: dup
    //   1098: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   1101: ldc_w 656
    //   1104: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1107: lload 30
    //   1109: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1112: ldc_w 658
    //   1115: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1118: lload 28
    //   1120: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1123: ldc_w 447
    //   1126: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1129: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1132: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   1135: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   1138: lstore 34
    //   1140: aload_0
    //   1141: new 296	java/lang/StringBuilder
    //   1144: dup
    //   1145: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   1148: ldc_w 591
    //   1151: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1154: lload 34
    //   1156: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1159: ldc_w 593
    //   1162: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1165: lload 34
    //   1167: lload 4
    //   1169: lsub
    //   1170: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1173: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1176: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   1179: aload_0
    //   1180: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   1183: invokevirtual 596	android/os/PowerManager$WakeLock:release	()V
    //   1186: goto +80 -> 1266
    //   1189: astore 20
    //   1191: invokestatic 424	android/os/SystemClock:elapsedRealtime	()J
    //   1194: lstore 21
    //   1196: aload_0
    //   1197: new 296	java/lang/StringBuilder
    //   1200: dup
    //   1201: invokespecial 297	java/lang/StringBuilder:<init>	()V
    //   1204: ldc_w 591
    //   1207: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1210: lload 21
    //   1212: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1215: ldc_w 593
    //   1218: invokevirtual 303	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1221: lload 21
    //   1223: lload 4
    //   1225: lsub
    //   1226: invokevirtual 414	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   1229: invokevirtual 310	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1232: invokevirtual 314	com/android/internal/telephony/cdma/CdmaServiceStateTracker:log	(Ljava/lang/String;)V
    //   1235: aload_0
    //   1236: getfield 195	com/android/internal/telephony/cdma/CdmaServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   1239: invokevirtual 596	android/os/PowerManager$WakeLock:release	()V
    //   1242: aload 20
    //   1244: athrow
    //   1245: iload 9
    //   1247: ifeq +32 -> 1279
    //   1250: iconst_1
    //   1251: istore 12
    //   1253: goto -1026 -> 227
    //   1256: iload 40
    //   1258: iload 41
    //   1260: if_icmpeq -862 -> 398
    //   1263: goto -899 -> 364
    //   1266: return
    //   1267: iconst_0
    //   1268: istore 9
    //   1270: goto -1074 -> 196
    //   1273: iconst_0
    //   1274: istore 11
    //   1276: goto -31 -> 1245
    //   1279: iconst_m1
    //   1280: istore 12
    //   1282: goto -1055 -> 227
    //   1285: iconst_0
    //   1286: istore 45
    //   1288: goto -975 -> 313
    //   1291: iload 11
    //   1293: ifeq +9 -> 1302
    //   1296: iconst_1
    //   1297: istore 42
    //   1299: goto -737 -> 562
    //   1302: iconst_0
    //   1303: istore 42
    //   1305: goto -743 -> 562
    //   1308: iconst_0
    //   1309: istore 41
    //   1311: goto -55 -> 1256
    //   1314: iconst_0
    //   1315: istore 16
    //   1317: goto -934 -> 383
    //
    // Exception table:
    //   from	to	target	type
    //   63	589	691	java/lang/RuntimeException
    //   637	688	691	java/lang/RuntimeException
    //   775	826	691	java/lang/RuntimeException
    //   1039	1090	691	java/lang/RuntimeException
    //   1135	1245	691	java/lang/RuntimeException
    //   592	637	1189	finally
    //   740	775	1189	finally
    //   834	1039	1189	finally
    //   1093	1135	1189	finally
  }

  public void dispose()
  {
    checkCorrectThread();
    log("ServiceStateTracker dispose");
    this.mCi.unregisterForRadioStateChanged(this);
    this.mCi.unregisterForVoiceNetworkStateChanged(this);
    this.mCi.unregisterForCdmaOtaProvision(this);
    this.mPhone.unregisterForEriFileLoaded(this);
    if (this.mUiccApplcation != null)
      this.mUiccApplcation.unregisterForReady(this);
    if (this.mIccRecords != null)
      this.mIccRecords.unregisterForRecordsLoaded(this);
    this.mCi.unSetOnNITZTime(this);
    this.mCr.unregisterContentObserver(this.mAutoTimeObserver);
    this.mCr.unregisterContentObserver(this.mAutoTimeZoneObserver);
    this.mCdmaSSM.dispose(this);
    this.mCi.unregisterForCdmaPrlChanged(this);
    super.dispose();
    Injector.CdmaServiceStateTrackerHook.after_dispose(this);
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("CdmaServiceStateTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.println(" mSS=" + this.mSS);
    paramPrintWriter.println(" mNewSS=" + this.mNewSS);
    paramPrintWriter.println(" mCellLoc=" + this.mCellLoc);
    paramPrintWriter.println(" mNewCellLoc=" + this.mNewCellLoc);
    paramPrintWriter.println(" mCurrentOtaspMode=" + this.mCurrentOtaspMode);
    paramPrintWriter.println(" mCdmaRoaming=" + this.mCdmaRoaming);
    paramPrintWriter.println(" mRoamingIndicator=" + this.mRoamingIndicator);
    paramPrintWriter.println(" mIsInPrl=" + this.mIsInPrl);
    paramPrintWriter.println(" mDefaultRoamingIndicator=" + this.mDefaultRoamingIndicator);
    paramPrintWriter.println(" mRegistrationState=" + this.mRegistrationState);
    paramPrintWriter.println(" mNeedFixZone=" + this.mNeedFixZone);
    paramPrintWriter.println(" mZoneOffset=" + this.mZoneOffset);
    paramPrintWriter.println(" mZoneDst=" + this.mZoneDst);
    paramPrintWriter.println(" mZoneTime=" + this.mZoneTime);
    paramPrintWriter.println(" mGotCountryCode=" + this.mGotCountryCode);
    paramPrintWriter.println(" mSavedTimeZone=" + this.mSavedTimeZone);
    paramPrintWriter.println(" mSavedTime=" + this.mSavedTime);
    paramPrintWriter.println(" mSavedAtTime=" + this.mSavedAtTime);
    paramPrintWriter.println(" mWakeLock=" + this.mWakeLock);
    paramPrintWriter.println(" mCurPlmn=" + this.mCurPlmn);
    paramPrintWriter.println(" mMdn=" + this.mMdn);
    paramPrintWriter.println(" mHomeSystemId=" + this.mHomeSystemId);
    paramPrintWriter.println(" mHomeNetworkId=" + this.mHomeNetworkId);
    paramPrintWriter.println(" mMin=" + this.mMin);
    paramPrintWriter.println(" mPrlVersion=" + this.mPrlVersion);
    paramPrintWriter.println(" mIsMinInfoReady=" + this.mIsMinInfoReady);
    paramPrintWriter.println(" mIsEriTextLoaded=" + this.mIsEriTextLoaded);
    paramPrintWriter.println(" mIsSubscriptionFromRuim=" + this.mIsSubscriptionFromRuim);
    paramPrintWriter.println(" mCdmaSSM=" + this.mCdmaSSM);
    paramPrintWriter.println(" mRegistrationDeniedReason=" + this.mRegistrationDeniedReason);
    paramPrintWriter.println(" mCurrentCarrier=" + this.mCurrentCarrier);
  }

  protected void finalize()
  {
    log("CdmaServiceStateTracker finalized");
  }

  protected void fixTimeZone(String paramString)
  {
    String str = SystemProperties.get("persist.sys.timezone");
    log("fixTimeZone zoneName='" + str + "' mZoneOffset=" + this.mZoneOffset + " mZoneDst=" + this.mZoneDst + " iso-cc='" + paramString + "' iso-cc-idx=" + Arrays.binarySearch(GMT_COUNTRY_CODES, paramString));
    TimeZone localTimeZone;
    long l2;
    if ((this.mZoneOffset == 0) && (!this.mZoneDst) && (str != null) && (str.length() > 0) && (Arrays.binarySearch(GMT_COUNTRY_CODES, paramString) < 0))
    {
      localTimeZone = TimeZone.getDefault();
      if (this.mNeedFixZone)
      {
        long l1 = System.currentTimeMillis();
        l2 = localTimeZone.getOffset(l1);
        log("fixTimeZone: tzOffset=" + l2 + " ltod=" + TimeUtils.logTimeOfDay(l1));
        if (getAutoTime())
        {
          long l3 = l1 - l2;
          log("fixTimeZone: adj ltod=" + TimeUtils.logTimeOfDay(l3));
          setAndBroadcastNetworkSetTime(l3);
        }
      }
      else
      {
        log("fixTimeZone: using default TimeZone");
        label237: this.mNeedFixZone = false;
        if (localTimeZone == null)
          break label412;
        log("fixTimeZone: zone != null zone.getID=" + localTimeZone.getID());
        if (!getAutoTimeZone())
          break label402;
        setAndBroadcastNetworkSetTimeZone(localTimeZone.getID());
        label288: saveNitzTimeZone(localTimeZone.getID());
      }
    }
    while (true)
    {
      return;
      this.mSavedTime -= l2;
      log("fixTimeZone: adj mSavedTime=" + this.mSavedTime);
      break;
      if (paramString.equals(""))
      {
        localTimeZone = getNitzTimeZone(this.mZoneOffset, this.mZoneDst, this.mZoneTime);
        log("fixTimeZone: using NITZ TimeZone");
        break label237;
      }
      localTimeZone = TimeUtils.getTimeZone(this.mZoneOffset, this.mZoneDst, this.mZoneTime, paramString);
      log("fixTimeZone: using getTimeZone(off, dst, time, iso)");
      break label237;
      label402: log("fixTimeZone: skip changing zone as getAutoTimeZone was false");
      break label288;
      label412: log("fixTimeZone: zone == null, do nothing for zone");
    }
  }

  public String getCdmaMin()
  {
    return this.mMin;
  }

  public int getCurrentDataConnectionState()
  {
    return this.mSS.getDataRegState();
  }

  String getImsi()
  {
    String str1 = SystemProperties.get("gsm.sim.operator.numeric", "");
    if ((!TextUtils.isEmpty(str1)) && (getCdmaMin() != null));
    for (String str2 = str1 + getCdmaMin(); ; str2 = null)
      return str2;
  }

  public String getMdnNumber()
  {
    return this.mMdn;
  }

  int getOtasp()
  {
    int i;
    if ((this.mMin == null) || (this.mMin.length() < 6))
    {
      log("getOtasp: bad mMin='" + this.mMin + "'");
      i = 1;
    }
    while (true)
    {
      log("getOtasp: state=" + i);
      return i;
      if ((this.mMin.equals("1111110111")) || (this.mMin.substring(0, 6).equals("000000")) || (SystemProperties.getBoolean("test_cdma_setup", false)))
        i = 2;
      else
        i = 3;
    }
  }

  protected Phone getPhone()
  {
    return this.mPhone;
  }

  public String getPrlVersion()
  {
    return this.mPrlVersion;
  }

  public void handleMessage(Message paramMessage)
  {
    if (!this.mPhone.mIsTheCurrentActivePhone)
      loge("Received message " + paramMessage + "[" + paramMessage.what + "]" + " while being destroyed. Ignoring.");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      case 2:
      case 4:
      case 6:
      case 7:
      case 8:
      case 9:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      case 28:
      case 29:
      case 32:
      case 33:
      case 38:
      default:
        super.handleMessage(paramMessage);
        break;
      case 39:
        handleCdmaSubscriptionSource(this.mCdmaSSM.getCdmaSubscriptionSource());
        break;
      case 26:
        if (this.mPhone.getLteOnCdmaMode() == 1)
        {
          log("Receive EVENT_RUIM_READY");
          pollState();
        }
        while (true)
        {
          this.mPhone.prepareEri();
          break;
          log("Receive EVENT_RUIM_READY and Send Request getCDMASubscription.");
          getSubscriptionInfoAndStartPollingThreads();
        }
      case 35:
        updatePhoneObject();
        getSubscriptionInfoAndStartPollingThreads();
        break;
      case 1:
        if (this.mCi.getRadioState() == CommandsInterface.RadioState.RADIO_ON)
        {
          handleCdmaSubscriptionSource(this.mCdmaSSM.getCdmaSubscriptionSource());
          queueNextSignalStrengthPoll();
        }
        setPowerStateToDesired();
        pollState();
        break;
      case 30:
        pollState();
        break;
      case 3:
        if (this.mCi.getRadioState().isOn())
        {
          onSignalStrengthResult((AsyncResult)paramMessage.obj, false);
          queueNextSignalStrengthPoll();
        }
        break;
      case 31:
      case 5:
      case 24:
      case 25:
      case 34:
      case 10:
      case 11:
      case 12:
      case 27:
      case 18:
      case 36:
      case 37:
      case 40:
      }
    }
    AsyncResult localAsyncResult7 = (AsyncResult)paramMessage.obj;
    String[] arrayOfString2;
    int j;
    int k;
    int m;
    int n;
    int i1;
    if (localAsyncResult7.exception == null)
    {
      arrayOfString2 = (String[])localAsyncResult7.result;
      j = -1;
      k = 2147483647;
      m = 2147483647;
      n = -1;
      i1 = -1;
      if (arrayOfString2.length <= 9);
    }
    while (true)
    {
      try
      {
        if (arrayOfString2[4] != null)
          j = Integer.parseInt(arrayOfString2[4]);
        if (arrayOfString2[5] != null)
          k = Integer.parseInt(arrayOfString2[5]);
        if (arrayOfString2[6] == null)
          break label1105;
        m = Integer.parseInt(arrayOfString2[6]);
        break label1105;
        if (arrayOfString2[8] != null)
          n = Integer.parseInt(arrayOfString2[8]);
        if (arrayOfString2[9] != null)
        {
          int i2 = Integer.parseInt(arrayOfString2[9]);
          i1 = i2;
        }
        this.mCellLoc.setCellLocationData(j, k, m, n, i1);
        this.mPhone.notifyLocationChanged();
        disableSingleLocationUpdate();
      }
      catch (NumberFormatException localNumberFormatException)
      {
        loge("error parsing cell location data: " + localNumberFormatException);
        continue;
      }
      AsyncResult localAsyncResult6 = (AsyncResult)paramMessage.obj;
      handlePollStateResult(paramMessage.what, localAsyncResult6);
      break;
      AsyncResult localAsyncResult5 = (AsyncResult)paramMessage.obj;
      if (localAsyncResult5.exception != null)
        break;
      String[] arrayOfString1 = (String[])localAsyncResult5.result;
      if ((arrayOfString1 != null) && (arrayOfString1.length >= 5))
      {
        this.mMdn = arrayOfString1[0];
        parseSidNid(arrayOfString1[1], arrayOfString1[2]);
        this.mMin = arrayOfString1[3];
        this.mPrlVersion = arrayOfString1[4];
        log("GET_CDMA_SUBSCRIPTION: MDN=" + this.mMdn);
        this.mIsMinInfoReady = true;
        updateOtaspState();
        if ((!this.mIsSubscriptionFromRuim) && (this.mIccRecords != null))
        {
          log("GET_CDMA_SUBSCRIPTION set imsi in mIccRecords");
          this.mIccRecords.setImsi(getImsi());
          break;
        }
        log("GET_CDMA_SUBSCRIPTION either mIccRecords is null  or NV type device - not setting Imsi in mIccRecords");
        break;
      }
      log("GET_CDMA_SUBSCRIPTION: error parsing cdmaSubscription params num=" + arrayOfString1.length);
      break;
      this.mCi.getSignalStrength(obtainMessage(3));
      break;
      AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
      setTimeFromNITZString((String)((Object[])(Object[])localAsyncResult4.result)[0], ((Long)((Object[])(Object[])localAsyncResult4.result)[1]).longValue());
      break;
      AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
      this.mDontPollSignalStrength = true;
      onSignalStrengthResult(localAsyncResult3, false);
      break;
      log("EVENT_RUIM_RECORDS_LOADED: what=" + paramMessage.what);
      updatePhoneObject();
      updateSpnDisplay();
      break;
      if (((AsyncResult)paramMessage.obj).exception != null)
        break;
      this.mCi.getVoiceRegistrationState(obtainMessage(31, null));
      break;
      log("[CdmaServiceStateTracker] ERI file has been loaded, repolling.");
      pollState();
      break;
      AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
      if (localAsyncResult2.exception != null)
        break;
      int i = ((int[])(int[])localAsyncResult2.result)[0];
      if ((i != 8) && (i != 10))
        break;
      log("EVENT_OTA_PROVISION_STATUS_CHANGE: Complete, Reload MDN");
      this.mCi.getCDMASubscription(obtainMessage(34));
      break;
      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
      if (localAsyncResult1.exception != null)
        break;
      this.mPrlVersion = Integer.toString(((int[])(int[])localAsyncResult1.result)[0]);
      break;
      label1105: if ((k == 0) && (m == 0))
      {
        k = 2147483647;
        m = 2147483647;
      }
    }
  }

  protected void handlePollStateResult(int paramInt, AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.userObj != this.mPollingContext);
    label119: 
    do
    {
      CommandException.Error localError;
      while (true)
      {
        return;
        if (paramAsyncResult.exception == null)
          break label431;
        localError = null;
        if ((paramAsyncResult.exception instanceof CommandException))
          localError = ((CommandException)paramAsyncResult.exception).getCommandError();
        if (localError == CommandException.Error.RADIO_NOT_AVAILABLE)
        {
          cancelPollState();
        }
        else
        {
          if (this.mCi.getRadioState().isOn())
            break;
          cancelPollState();
        }
      }
      if (localError != CommandException.Error.OP_NOT_ALLOWED_BEFORE_REG_NW)
        loge("handlePollStateResult: RIL returned an error where it must succeed" + paramAsyncResult.exception);
      int[] arrayOfInt = this.mPollingContext;
      arrayOfInt[0] = (-1 + arrayOfInt[0]);
    }
    while (this.mPollingContext[0] != 0);
    boolean bool1 = false;
    if ((!isSidsAllZeros()) && (isHomeSid(this.mNewSS.getSystemId())))
      bool1 = true;
    label197: boolean bool2;
    if (this.mIsSubscriptionFromRuim)
    {
      this.mNewSS.setRoaming(isRoamingBetweenOperators(this.mCdmaRoaming, this.mNewSS));
      this.mNewSS.setCdmaDefaultRoamingIndicator(this.mDefaultRoamingIndicator);
      this.mNewSS.setCdmaRoamingIndicator(this.mRoamingIndicator);
      bool2 = true;
      if (TextUtils.isEmpty(this.mPrlVersion))
        bool2 = false;
      if ((bool2) && (this.mNewSS.getRilVoiceRadioTechnology() != 0))
        break label482;
      log("Turn off roaming indicator if !isPrlLoaded or voice RAT is unknown");
      this.mNewSS.setCdmaRoamingIndicator(1);
    }
    while (true)
    {
      while (true)
      {
        int i = this.mNewSS.getCdmaRoamingIndicator();
        this.mNewSS.setCdmaEriIconIndex(this.mPhone.mEriManager.getCdmaEriIconIndex(i, this.mDefaultRoamingIndicator));
        this.mNewSS.setCdmaEriIconMode(this.mPhone.mEriManager.getCdmaEriIconMode(i, this.mDefaultRoamingIndicator));
        log("Set CDMA Roaming Indicator to: " + this.mNewSS.getCdmaRoamingIndicator() + ". mCdmaRoaming = " + this.mCdmaRoaming + ", isPrlLoaded = " + bool2 + ". namMatch = " + bool1 + " , mIsInPrl = " + this.mIsInPrl + ", mRoamingIndicator = " + this.mRoamingIndicator + ", mDefaultRoamingIndicator= " + this.mDefaultRoamingIndicator);
        pollStateDone();
        break;
        try
        {
          label431: handlePollStateResultMessage(paramInt, paramAsyncResult);
        }
        catch (RuntimeException localRuntimeException)
        {
          loge("handlePollStateResult: Exception while polling service state. Probably malformed RIL response." + localRuntimeException);
        }
      }
      break label119;
      this.mNewSS.setRoaming(this.mCdmaRoaming);
      break label197;
      label482: if (!isSidsAllZeros())
        if ((!bool1) && (!this.mIsInPrl))
          this.mNewSS.setCdmaRoamingIndicator(this.mDefaultRoamingIndicator);
        else if ((bool1) && (!this.mIsInPrl))
        {
          if (this.mNewSS.getRilVoiceRadioTechnology() == 14)
          {
            log("Turn off roaming indicator as voice is LTE");
            this.mNewSS.setCdmaRoamingIndicator(1);
          }
          else
          {
            this.mNewSS.setCdmaRoamingIndicator(2);
          }
        }
        else if ((!bool1) && (this.mIsInPrl))
          this.mNewSS.setCdmaRoamingIndicator(this.mRoamingIndicator);
        else if (this.mRoamingIndicator <= 2)
          this.mNewSS.setCdmaRoamingIndicator(1);
        else
          this.mNewSS.setCdmaRoamingIndicator(this.mRoamingIndicator);
    }
  }

  protected void handlePollStateResultMessage(int paramInt, AsyncResult paramAsyncResult)
  {
    String[] arrayOfString2;
    int i;
    int j;
    int k;
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    int i4;
    int i5;
    int i6;
    int i7;
    switch (paramInt)
    {
    default:
      loge("handlePollStateResultMessage: RIL response handle in wrong phone! Expected CDMA RIL request and get GSM RIL request.");
    case 5:
      while (true)
      {
        return;
        String[] arrayOfString3 = (String[])paramAsyncResult.result;
        log("handlePollStateResultMessage: EVENT_POLL_STATE_GPRS states.length=" + arrayOfString3.length + " states=" + arrayOfString3);
        int i9 = 4;
        int i10 = 0;
        if (arrayOfString3.length > 0);
        try
        {
          i9 = Integer.parseInt(arrayOfString3[0]);
          if ((arrayOfString3.length >= 4) && (arrayOfString3[3] != null))
          {
            int i12 = Integer.parseInt(arrayOfString3[3]);
            i10 = i12;
          }
          int i11 = regCodeToServiceState(i9);
          this.mNewSS.setDataRegState(i11);
          this.mNewSS.setRilDataRadioTechnology(i10);
          log("handlPollStateResultMessage: cdma setDataRegState=" + i11 + " regState=" + i9 + " dataRadioTechnology=" + i10);
        }
        catch (NumberFormatException localNumberFormatException2)
        {
          while (true)
            loge("handlePollStateResultMessage: error parsing GprsRegistrationState: " + localNumberFormatException2);
        }
      }
    case 24:
      arrayOfString2 = (String[])paramAsyncResult.result;
      i = 4;
      j = -1;
      k = -1;
      m = 2147483647;
      n = 2147483647;
      i1 = 0;
      i2 = 0;
      i3 = 0;
      i4 = -1;
      i5 = 0;
      i6 = 0;
      i7 = 0;
      if (arrayOfString2.length < 14)
        break;
    case 25:
    }
    while (true)
    {
      try
      {
        if (arrayOfString2[0] != null)
          i = Integer.parseInt(arrayOfString2[0]);
        if (arrayOfString2[3] != null)
          j = Integer.parseInt(arrayOfString2[3]);
        if (arrayOfString2[4] != null)
          k = Integer.parseInt(arrayOfString2[4]);
        if (arrayOfString2[5] != null)
          m = Integer.parseInt(arrayOfString2[5]);
        if (arrayOfString2[6] == null)
          break label949;
        n = Integer.parseInt(arrayOfString2[6]);
        break label949;
        if (arrayOfString2[7] != null)
          i1 = Integer.parseInt(arrayOfString2[7]);
        if (arrayOfString2[8] != null)
          i2 = Integer.parseInt(arrayOfString2[8]);
        if (arrayOfString2[9] != null)
          i3 = Integer.parseInt(arrayOfString2[9]);
        if (arrayOfString2[10] != null)
          i4 = Integer.parseInt(arrayOfString2[10]);
        if (arrayOfString2[11] != null)
          i5 = Integer.parseInt(arrayOfString2[11]);
        if (arrayOfString2[12] != null)
          i6 = Integer.parseInt(arrayOfString2[12]);
        if (arrayOfString2[13] != null)
        {
          int i8 = Integer.parseInt(arrayOfString2[13]);
          i7 = i8;
        }
        this.mRegistrationState = i;
        if ((!regCodeIsRoaming(i)) || (isRoamIndForHomeSystem(arrayOfString2[10])))
          break label759;
        bool1 = true;
        this.mCdmaRoaming = bool1;
        this.mNewSS.setState(regCodeToServiceState(i));
        this.mNewSS.setRilVoiceRadioTechnology(j);
        this.mNewSS.setCssIndicator(i1);
        this.mNewSS.setSystemAndNetworkId(i2, i3);
        this.mRoamingIndicator = i4;
        if (i5 != 0)
          break label765;
        bool2 = false;
        this.mIsInPrl = bool2;
        this.mDefaultRoamingIndicator = i6;
        this.mNewCellLoc.setCellLocationData(k, m, n, i2, i3);
        if (i7 != 0)
          break label771;
        this.mRegistrationDeniedReason = "General";
        if (this.mRegistrationState != 3)
          break;
        log("Registration denied, " + this.mRegistrationDeniedReason);
      }
      catch (NumberFormatException localNumberFormatException1)
      {
        loge("EVENT_POLL_STATE_REGISTRATION_CDMA: error parsing: " + localNumberFormatException1);
        continue;
      }
      throw new RuntimeException("Warning! Wrong number of parameters returned from RIL_REQUEST_REGISTRATION_STATE: expected 14 or more strings and got " + arrayOfString2.length + " strings");
      label759: boolean bool1 = false;
      continue;
      label765: boolean bool2 = true;
      continue;
      label771: if (i7 == 1)
      {
        this.mRegistrationDeniedReason = "Authentication Failure";
      }
      else
      {
        this.mRegistrationDeniedReason = "";
        continue;
        String[] arrayOfString1 = (String[])paramAsyncResult.result;
        if ((arrayOfString1 != null) && (arrayOfString1.length >= 3))
        {
          if ((arrayOfString1[2] == null) || (arrayOfString1[2].length() < 5) || ("00000".equals(arrayOfString1[2])))
          {
            arrayOfString1[2] = SystemProperties.get(CDMAPhone.PROPERTY_CDMA_HOME_OPERATOR_NUMERIC, "00000");
            log("RIL_REQUEST_OPERATOR.response[2], the numeric,  is bad. Using SystemProperties '" + CDMAPhone.PROPERTY_CDMA_HOME_OPERATOR_NUMERIC + "'= " + arrayOfString1[2]);
          }
          if (!this.mIsSubscriptionFromRuim)
          {
            this.mNewSS.setOperatorName(null, arrayOfString1[1], arrayOfString1[2]);
            break;
          }
          this.mNewSS.setOperatorName(arrayOfString1[0], arrayOfString1[1], arrayOfString1[2]);
          break;
        }
        log("EVENT_POLL_STATE_OPERATOR_CDMA: error parsing opNames");
        break;
        label949: if ((m == 0) && (n == 0))
        {
          m = 2147483647;
          n = 2147483647;
        }
      }
    }
  }

  protected void hangupAndPowerOff()
  {
    this.mPhone.mCT.mRingingCall.hangupIfAlive();
    this.mPhone.mCT.mBackgroundCall.hangupIfAlive();
    this.mPhone.mCT.mForegroundCall.hangupIfAlive();
    this.mCi.setRadioPower(false, null);
  }

  public boolean isConcurrentVoiceAndDataAllowed()
  {
    return false;
  }

  public boolean isMinInfoReady()
  {
    return this.mIsMinInfoReady;
  }

  protected boolean isSidsAllZeros()
  {
    int i;
    if (this.mHomeSystemId != null)
    {
      i = 0;
      if (i < this.mHomeSystemId.length)
        if (this.mHomeSystemId[i] == 0);
    }
    for (boolean bool = false; ; bool = true)
    {
      return bool;
      i++;
      break;
    }
  }

  protected void log(String paramString)
  {
    Rlog.d("CdmaSST", "[CdmaSST] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("CdmaSST", "[CdmaSST] " + paramString);
  }

  protected void onUpdateIccAvailability()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      UiccCardApplication localUiccCardApplication = this.mUiccController.getUiccCardApplication(2);
      if (this.mUiccApplcation != localUiccCardApplication)
      {
        if (this.mUiccApplcation != null)
        {
          log("Removing stale icc objects.");
          this.mUiccApplcation.unregisterForReady(this);
          if (this.mIccRecords != null)
            this.mIccRecords.unregisterForRecordsLoaded(this);
          this.mIccRecords = null;
          this.mUiccApplcation = null;
        }
        if (localUiccCardApplication != null)
        {
          log("New card found");
          this.mUiccApplcation = localUiccCardApplication;
          this.mIccRecords = this.mUiccApplcation.getIccRecords();
          if (this.mIsSubscriptionFromRuim)
          {
            this.mUiccApplcation.registerForReady(this, 26, null);
            if (this.mIccRecords != null)
              this.mIccRecords.registerForRecordsLoaded(this, 27, null);
          }
        }
      }
    }
  }

  protected void parseSidNid(String paramString1, String paramString2)
  {
    if (paramString1 != null)
    {
      String[] arrayOfString2 = paramString1.split(",");
      this.mHomeSystemId = new int[arrayOfString2.length];
      int j = 0;
      while (true)
        if (j < arrayOfString2.length)
          try
          {
            this.mHomeSystemId[j] = Integer.parseInt(arrayOfString2[j]);
            j++;
          }
          catch (NumberFormatException localNumberFormatException2)
          {
            while (true)
              loge("error parsing system id: " + localNumberFormatException2);
          }
    }
    log("CDMA_SUBSCRIPTION: SID=" + paramString1);
    if (paramString2 != null)
    {
      String[] arrayOfString1 = paramString2.split(",");
      this.mHomeNetworkId = new int[arrayOfString1.length];
      int i = 0;
      while (true)
        if (i < arrayOfString1.length)
          try
          {
            this.mHomeNetworkId[i] = Integer.parseInt(arrayOfString1[i]);
            i++;
          }
          catch (NumberFormatException localNumberFormatException1)
          {
            while (true)
              loge("CDMA_SUBSCRIPTION: error parsing network id: " + localNumberFormatException1);
          }
    }
    log("CDMA_SUBSCRIPTION: NID=" + paramString2);
  }

  protected void pollState()
  {
    this.mPollingContext = new int[1];
    this.mPollingContext[0] = 0;
    switch (3.$SwitchMap$com$android$internal$telephony$CommandsInterface$RadioState[this.mCi.getRadioState().ordinal()])
    {
    default:
      int[] arrayOfInt1 = this.mPollingContext;
      arrayOfInt1[0] = (1 + arrayOfInt1[0]);
      this.mCi.getOperator(obtainMessage(25, this.mPollingContext));
      int[] arrayOfInt2 = this.mPollingContext;
      arrayOfInt2[0] = (1 + arrayOfInt2[0]);
      this.mCi.getVoiceRegistrationState(obtainMessage(24, this.mPollingContext));
      int[] arrayOfInt3 = this.mPollingContext;
      arrayOfInt3[0] = (1 + arrayOfInt3[0]);
      this.mCi.getDataRegistrationState(obtainMessage(5, this.mPollingContext));
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      this.mNewSS.setStateOutOfService();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      pollStateDone();
      continue;
      this.mNewSS.setStateOff();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      pollStateDone();
    }
  }

  protected void pollStateDone()
  {
    log("pollStateDone: cdma oldSS=[" + this.mSS + "] newSS=[" + this.mNewSS + "]");
    if ((Build.IS_DEBUGGABLE) && (SystemProperties.getBoolean("telephony.test.forceRoaming", false)))
      this.mNewSS.setRoaming(true);
    useDataRegStateForDataOnlyDevices();
    int i;
    label116: int j;
    label138: int k;
    label160: int m;
    label180: int n;
    label200: int i1;
    label220: int i2;
    label237: int i3;
    label260: int i4;
    label283: int i5;
    label300: String str5;
    label543: String str1;
    String str2;
    label631: CDMAPhone localCDMAPhone;
    if ((this.mSS.getVoiceRegState() != 0) && (this.mNewSS.getVoiceRegState() == 0))
    {
      i = 1;
      if ((this.mSS.getVoiceRegState() != 0) || (this.mNewSS.getVoiceRegState() == 0))
        break label763;
      if ((this.mSS.getDataRegState() == 0) || (this.mNewSS.getDataRegState() != 0))
        break label766;
      j = 1;
      if ((this.mSS.getDataRegState() != 0) || (this.mNewSS.getDataRegState() == 0))
        break label771;
      k = 1;
      if (this.mSS.getDataRegState() == this.mNewSS.getDataRegState())
        break label776;
      m = 1;
      if (this.mSS.getRilVoiceRadioTechnology() == this.mNewSS.getRilVoiceRadioTechnology())
        break label782;
      n = 1;
      if (this.mSS.getRilDataRadioTechnology() == this.mNewSS.getRilDataRadioTechnology())
        break label788;
      i1 = 1;
      if (this.mNewSS.equals(this.mSS))
        break label794;
      i2 = 1;
      if ((this.mSS.getRoaming()) || (!this.mNewSS.getRoaming()))
        break label800;
      i3 = 1;
      if ((!this.mSS.getRoaming()) || (this.mNewSS.getRoaming()))
        break label806;
      i4 = 1;
      if (this.mNewCellLoc.equals(this.mCellLoc))
        break label812;
      i5 = 1;
      if ((this.mSS.getVoiceRegState() != this.mNewSS.getVoiceRegState()) || (this.mSS.getDataRegState() != this.mNewSS.getDataRegState()))
      {
        Object[] arrayOfObject = new Object[4];
        arrayOfObject[0] = Integer.valueOf(this.mSS.getVoiceRegState());
        arrayOfObject[1] = Integer.valueOf(this.mSS.getDataRegState());
        arrayOfObject[2] = Integer.valueOf(this.mNewSS.getVoiceRegState());
        arrayOfObject[3] = Integer.valueOf(this.mNewSS.getDataRegState());
        EventLog.writeEvent(50116, arrayOfObject);
      }
      ServiceState localServiceState = this.mSS;
      this.mSS = this.mNewSS;
      this.mNewSS = localServiceState;
      this.mNewSS.setStateOutOfService();
      CdmaCellLocation localCdmaCellLocation = this.mCellLoc;
      this.mCellLoc = this.mNewCellLoc;
      this.mNewCellLoc = localCdmaCellLocation;
      if (n != 0)
        updatePhoneObject();
      if (i1 != 0)
        this.mPhone.setSystemProperty("gsm.network.type", ServiceState.rilRadioTechnologyToString(this.mSS.getRilDataRadioTechnology()));
      if (i != 0)
        this.mNetworkAttachedRegistrants.notifyRegistrants();
      if (i2 != 0)
      {
        if ((this.mCi.getRadioState().isOn()) && (!this.mIsSubscriptionFromRuim))
        {
          if (this.mSS.getVoiceRegState() != 0)
            break label818;
          str5 = this.mPhone.getCdmaEriText();
          this.mSS.setOperatorAlphaLong(str5);
        }
        this.mPhone.setSystemProperty("gsm.operator.alpha", this.mSS.getOperatorAlphaLong());
        str1 = SystemProperties.get("gsm.operator.numeric", "");
        str2 = this.mSS.getOperatorNumeric();
        this.mPhone.setSystemProperty("gsm.operator.numeric", str2);
        if (str2 != null)
          break label839;
        log("operatorNumeric is null");
        this.mPhone.setSystemProperty("gsm.operator.iso-country", "");
        this.mGotCountryCode = false;
        localCDMAPhone = this.mPhone;
        if (!this.mSS.getRoaming())
          break label976;
      }
    }
    label771: label776: label782: label788: label794: label800: label806: label812: label818: label839: label976: for (String str3 = "true"; ; str3 = "false")
      while (true)
      {
        localCDMAPhone.setSystemProperty("gsm.operator.isroaming", str3);
        updateSpnDisplay();
        this.mPhone.notifyServiceStateChanged(this.mSS);
        if (j != 0)
          this.mAttachedRegistrants.notifyRegistrants();
        if (k != 0)
          this.mDetachedRegistrants.notifyRegistrants();
        if ((m != 0) || (i1 != 0))
        {
          notifyDataRegStateRilRadioTechnologyChanged();
          this.mPhone.notifyDataConnection(null);
        }
        if (i3 != 0)
          this.mRoamingOnRegistrants.notifyRegistrants();
        if (i4 != 0)
          this.mRoamingOffRegistrants.notifyRegistrants();
        if (i5 != 0)
          this.mPhone.notifyLocationChanged();
        return;
        i = 0;
        break;
        label763: break label116;
        label766: j = 0;
        break label138;
        k = 0;
        break label160;
        m = 0;
        break label180;
        n = 0;
        break label200;
        i1 = 0;
        break label220;
        i2 = 0;
        break label237;
        i3 = 0;
        break label260;
        i4 = 0;
        break label283;
        i5 = 0;
        break label300;
        str5 = this.mPhone.getContext().getText(17039509).toString();
        break label543;
        Object localObject = "";
        str2.substring(0, 3);
        try
        {
          String str4 = MccTable.countryCodeForMcc(Integer.parseInt(str2.substring(0, 3)));
          localObject = str4;
          this.mPhone.setSystemProperty("gsm.operator.iso-country", (String)localObject);
          this.mGotCountryCode = true;
          if (!shouldFixTimeZoneNow(this.mPhone, str2, str1, this.mNeedFixZone))
            break label631;
          fixTimeZone((String)localObject);
        }
        catch (NumberFormatException localNumberFormatException)
        {
          while (true)
            loge("pollStateDone: countryCodeForMcc error" + localNumberFormatException);
        }
        catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
        {
          while (true)
            loge("pollStateDone: countryCodeForMcc error" + localStringIndexOutOfBoundsException);
        }
      }
  }

  protected int radioTechnologyToDataServiceState(int paramInt)
  {
    int i = 1;
    switch (paramInt)
    {
    case 9:
    case 10:
    case 11:
    default:
      loge("radioTechnologyToDataServiceState: Wrong radioTechnology code.");
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 12:
    case 13:
    }
    while (true)
    {
      return i;
      i = 0;
    }
  }

  protected int regCodeToServiceState(int paramInt)
  {
    int i = 1;
    switch (paramInt)
    {
    default:
      loge("regCodeToServiceState: unexpected service state " + paramInt);
    case 0:
    case 2:
    case 3:
    case 4:
    case 1:
    case 5:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 0;
    }
  }

  public void registerForSubscriptionInfoReady(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mCdmaForSubscriptionInfoReadyRegistrants.add(localRegistrant);
    if (isMinInfoReady())
      localRegistrant.notifyRegistrant();
  }

  protected void setPowerStateToDesired()
  {
    if ((this.mDesiredPowerState) && (this.mCi.getRadioState() == CommandsInterface.RadioState.RADIO_OFF))
      this.mCi.setRadioPower(true, null);
    while (true)
    {
      return;
      if ((!this.mDesiredPowerState) && (this.mCi.getRadioState().isOn()))
        powerOffRadioSafely(this.mPhone.mDcTracker);
    }
  }

  protected void setSignalStrengthDefaultValues()
  {
    this.mSignalStrength = new SignalStrength(false);
  }

  public void unregisterForSubscriptionInfoReady(Handler paramHandler)
  {
    this.mCdmaForSubscriptionInfoReadyRegistrants.remove(paramHandler);
  }

  protected void updateOtaspState()
  {
    int i = getOtasp();
    int j = this.mCurrentOtaspMode;
    this.mCurrentOtaspMode = i;
    if (this.mCdmaForSubscriptionInfoReadyRegistrants != null)
    {
      log("CDMA_SUBSCRIPTION: call notifyRegistrants()");
      this.mCdmaForSubscriptionInfoReadyRegistrants.notifyRegistrants();
    }
    if (j != this.mCurrentOtaspMode)
    {
      log("CDMA_SUBSCRIPTION: call notifyOtaspChanged old otaspMode=" + j + " new otaspMode=" + this.mCurrentOtaspMode);
      this.mPhone.notifyOtaspChanged(this.mCurrentOtaspMode);
    }
  }

  protected void updateSpnDisplay()
  {
    String str = Injector.ServiceStateTrackerHook.getSpn(this, this.mSS.getOperatorAlphaLong());
    if (!TextUtils.equals(str, this.mCurPlmn))
      if (str == null)
        break label140;
    label140: for (boolean bool = true; ; bool = false)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Boolean.valueOf(bool);
      arrayOfObject[1] = str;
      log(String.format("updateSpnDisplay: changed sending intent showPlmn='%b' plmn='%s'", arrayOfObject));
      Intent localIntent = new Intent("android.provider.Telephony.SPN_STRINGS_UPDATED");
      localIntent.addFlags(536870912);
      localIntent.putExtra("showSpn", false);
      localIntent.putExtra("spn", "");
      localIntent.putExtra("showPlmn", bool);
      localIntent.putExtra("plmn", str);
      this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
      this.mCurPlmn = str;
      return;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaServiceStateTracker
 * JD-Core Version:    0.6.2
 */