package com.android.internal.telephony.cdma;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.Connection.DisconnectCause;
import com.android.internal.telephony.DriverCall;
import com.android.internal.telephony.DriverCall.State;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.dataconnection.DcTrackerBase;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public final class CdmaCallTracker extends CallTracker
{
  private static final boolean DBG_POLL = false;
  static final String LOG_TAG = "CdmaCallTracker";
  static final int MAX_CONNECTIONS = 8;
  static final int MAX_CONNECTIONS_PER_CALL = 1;
  private static final boolean REPEAT_POLLING;
  CdmaCall mBackgroundCall = new CdmaCall(this);
  RegistrantList mCallWaitingRegistrants = new RegistrantList();
  CdmaConnection[] mConnections = new CdmaConnection[8];
  boolean mDesiredMute = false;
  ArrayList<CdmaConnection> mDroppedDuringPoll = new ArrayList(8);
  CdmaCall mForegroundCall = new CdmaCall(this);
  boolean mHangupPendingMO;
  private boolean mIsEcmTimerCanceled = false;
  boolean mIsInEmergencyCall = false;
  int mPendingCallClirMode;
  boolean mPendingCallInEcm = false;
  CdmaConnection mPendingMO;
  CDMAPhone mPhone;
  CdmaCall mRingingCall = new CdmaCall(this);
  PhoneConstants.State mState = PhoneConstants.State.IDLE;
  RegistrantList mVoiceCallEndedRegistrants = new RegistrantList();
  RegistrantList mVoiceCallStartedRegistrants = new RegistrantList();

  CdmaCallTracker(CDMAPhone paramCDMAPhone)
  {
    this.mPhone = paramCDMAPhone;
    this.mCi = paramCDMAPhone.mCi;
    this.mCi.registerForCallStateChanged(this, 2, null);
    this.mCi.registerForOn(this, 9, null);
    this.mCi.registerForNotAvailable(this, 10, null);
    this.mCi.registerForCallWaitingInfo(this, 15, null);
    this.mForegroundCall.setGeneric(false);
  }

  private void checkAndEnableDataCallAfterEmergencyCallDropped()
  {
    if (this.mIsInEmergencyCall)
    {
      this.mIsInEmergencyCall = false;
      String str = SystemProperties.get("ril.cdma.inecmmode", "false");
      log("checkAndEnableDataCallAfterEmergencyCallDropped,inEcm=" + str);
      if (str.compareTo("false") == 0)
        this.mPhone.mDcTracker.setInternalDataEnabled(true);
    }
  }

  private Connection checkMtFindNewRinging(DriverCall paramDriverCall, int paramInt)
  {
    CdmaConnection localCdmaConnection = null;
    this.mConnections[paramInt] = new CdmaConnection(this.mPhone.getContext(), paramDriverCall, this, paramInt);
    if (this.mConnections[paramInt].getCall() == this.mRingingCall)
    {
      localCdmaConnection = this.mConnections[paramInt];
      log("Notify new ring " + paramDriverCall);
    }
    while (true)
    {
      return localCdmaConnection;
      Rlog.e("CdmaCallTracker", "Phantom call appeared " + paramDriverCall);
      if ((paramDriverCall.state != DriverCall.State.ALERTING) && (paramDriverCall.state != DriverCall.State.DIALING))
      {
        this.mConnections[paramInt].onConnectedInOrOut();
        if (paramDriverCall.state == DriverCall.State.HOLDING)
          this.mConnections[paramInt].onStartedHolding();
      }
    }
  }

  private Connection dialThreeWay(String paramString)
  {
    if (!this.mForegroundCall.isIdle())
    {
      disableDataCallInEmergencyCall(paramString);
      this.mPendingMO = new CdmaConnection(this.mPhone.getContext(), checkForTestEmergencyNumber(paramString), this, this.mForegroundCall);
      this.mCi.sendCDMAFeatureCode(this.mPendingMO.mAddress, obtainMessage(16));
    }
    for (CdmaConnection localCdmaConnection = this.mPendingMO; ; localCdmaConnection = null)
      return localCdmaConnection;
  }

  private void disableDataCallInEmergencyCall(String paramString)
  {
    if (PhoneNumberUtils.isLocalEmergencyNumber(paramString, this.mPhone.getContext()))
    {
      log("disableDataCallInEmergencyCall");
      this.mIsInEmergencyCall = true;
      this.mPhone.mDcTracker.setInternalDataEnabled(false);
    }
  }

  private void flashAndSetGenericTrue()
  {
    this.mCi.sendCDMAFeatureCode("", obtainMessage(8));
    this.mForegroundCall.setGeneric(true);
    this.mPhone.notifyPreciseCallStateChanged();
  }

  private void handleCallWaitingInfo(CdmaCallWaitingNotification paramCdmaCallWaitingNotification)
  {
    if (this.mForegroundCall.mConnections.size() > 1)
      this.mForegroundCall.setGeneric(true);
    this.mRingingCall.setGeneric(false);
    new CdmaConnection(this.mPhone.getContext(), paramCdmaCallWaitingNotification, this, this.mRingingCall);
    updatePhoneState();
    notifyCallWaitingInfo(paramCdmaCallWaitingNotification);
  }

  private void handleEcmTimer(int paramInt)
  {
    this.mPhone.handleTimerInEmergencyCallbackMode(paramInt);
    switch (paramInt)
    {
    default:
      Rlog.e("CdmaCallTracker", "handleEcmTimer, unsupported action " + paramInt);
    case 1:
    case 0:
    }
    while (true)
    {
      return;
      this.mIsEcmTimerCanceled = true;
      continue;
      this.mIsEcmTimerCanceled = false;
    }
  }

  private void handleRadioNotAvailable()
  {
    pollCallsWhenSafe();
  }

  private void internalClearDisconnected()
  {
    this.mRingingCall.clearDisconnected();
    this.mForegroundCall.clearDisconnected();
    this.mBackgroundCall.clearDisconnected();
  }

  private void notifyCallWaitingInfo(CdmaCallWaitingNotification paramCdmaCallWaitingNotification)
  {
    if (this.mCallWaitingRegistrants != null)
      this.mCallWaitingRegistrants.notifyRegistrants(new AsyncResult(null, paramCdmaCallWaitingNotification, null));
  }

  private Message obtainCompleteMessage()
  {
    return obtainCompleteMessage(4);
  }

  private Message obtainCompleteMessage(int paramInt)
  {
    this.mPendingOperations = (1 + this.mPendingOperations);
    this.mLastRelevantPoll = null;
    this.mNeedsPoll = true;
    return obtainMessage(paramInt);
  }

  private void operationComplete()
  {
    this.mPendingOperations = (-1 + this.mPendingOperations);
    if ((this.mPendingOperations == 0) && (this.mNeedsPoll))
    {
      this.mLastRelevantPoll = obtainMessage(1);
      this.mCi.getCurrentCalls(this.mLastRelevantPoll);
    }
    while (true)
    {
      return;
      if (this.mPendingOperations < 0)
      {
        Rlog.e("CdmaCallTracker", "CdmaCallTracker.pendingOperations < 0");
        this.mPendingOperations = 0;
      }
    }
  }

  private void updatePhoneState()
  {
    PhoneConstants.State localState = this.mState;
    if (this.mRingingCall.isRinging())
    {
      this.mState = PhoneConstants.State.RINGING;
      if ((this.mState != PhoneConstants.State.IDLE) || (localState == this.mState))
        break label157;
      this.mVoiceCallEndedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
    }
    while (true)
    {
      log("update phone state, old=" + localState + " new=" + this.mState);
      if (this.mState != localState)
        this.mPhone.notifyPhoneStateChanged();
      return;
      if ((this.mPendingMO != null) || (!this.mForegroundCall.isIdle()) || (!this.mBackgroundCall.isIdle()))
      {
        this.mState = PhoneConstants.State.OFFHOOK;
        break;
      }
      this.mState = PhoneConstants.State.IDLE;
      break;
      label157: if ((localState == PhoneConstants.State.IDLE) && (localState != this.mState))
        this.mVoiceCallStartedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
    }
  }

  void acceptCall()
    throws CallStateException
  {
    if (this.mRingingCall.getState() == Call.State.INCOMING)
    {
      Rlog.i("phone", "acceptCall: incoming...");
      setMute(false);
      this.mCi.acceptCall(obtainCompleteMessage());
    }
    while (true)
    {
      return;
      if (this.mRingingCall.getState() != Call.State.WAITING)
        break;
      CdmaConnection localCdmaConnection = (CdmaConnection)this.mRingingCall.getLatestConnection();
      localCdmaConnection.updateParent(this.mRingingCall, this.mForegroundCall);
      localCdmaConnection.onConnectedInOrOut();
      updatePhoneState();
      switchWaitingOrHoldingAndActive();
    }
    throw new CallStateException("phone not ringing");
  }

  boolean canConference()
  {
    if ((this.mForegroundCall.getState() == Call.State.ACTIVE) && (this.mBackgroundCall.getState() == Call.State.HOLDING) && (!this.mBackgroundCall.isFull()) && (!this.mForegroundCall.isFull()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean canDial()
  {
    boolean bool1 = true;
    int i = this.mPhone.getServiceState().getState();
    String str = SystemProperties.get("ro.telephony.disable-call", "false");
    boolean bool2;
    Object[] arrayOfObject;
    boolean bool3;
    label124: boolean bool4;
    label143: boolean bool5;
    label165: boolean bool6;
    label187: boolean bool7;
    label212: boolean bool8;
    if ((i != 3) && (this.mPendingMO == null) && (!this.mRingingCall.isRinging()) && (!str.equals("true")) && ((!this.mForegroundCall.getState().isAlive()) || (this.mForegroundCall.getState() == Call.State.ACTIVE) || (!this.mBackgroundCall.getState().isAlive())))
    {
      bool2 = bool1;
      if (!bool2)
      {
        arrayOfObject = new Object[8];
        arrayOfObject[0] = Integer.valueOf(i);
        if (i == 3)
          break label290;
        bool3 = bool1;
        arrayOfObject[bool1] = Boolean.valueOf(bool3);
        if (this.mPendingMO != null)
          break label296;
        bool4 = bool1;
        arrayOfObject[2] = Boolean.valueOf(bool4);
        if (this.mRingingCall.isRinging())
          break label302;
        bool5 = bool1;
        arrayOfObject[3] = Boolean.valueOf(bool5);
        if (str.equals("true"))
          break label308;
        bool6 = bool1;
        arrayOfObject[4] = Boolean.valueOf(bool6);
        if (this.mForegroundCall.getState().isAlive())
          break label314;
        bool7 = bool1;
        arrayOfObject[5] = Boolean.valueOf(bool7);
        if (this.mForegroundCall.getState() != Call.State.ACTIVE)
          break label320;
        bool8 = bool1;
        label237: arrayOfObject[6] = Boolean.valueOf(bool8);
        if (this.mBackgroundCall.getState().isAlive())
          break label326;
      }
    }
    while (true)
    {
      arrayOfObject[7] = Boolean.valueOf(bool1);
      log(String.format("canDial is false\n((serviceState=%d) != ServiceState.STATE_POWER_OFF)::=%s\n&& pendingMO == null::=%s\n&& !ringingCall.isRinging()::=%s\n&& !disableCall.equals(\"true\")::=%s\n&& (!foregroundCall.getState().isAlive()::=%s\n   || foregroundCall.getState() == CdmaCall.State.ACTIVE::=%s\n   ||!backgroundCall.getState().isAlive())::=%s)", arrayOfObject));
      return bool2;
      bool2 = false;
      break;
      label290: bool3 = false;
      break label124;
      label296: bool4 = false;
      break label143;
      label302: bool5 = false;
      break label165;
      label308: bool6 = false;
      break label187;
      label314: bool7 = false;
      break label212;
      label320: bool8 = false;
      break label237;
      label326: bool1 = false;
    }
  }

  boolean canTransfer()
  {
    Rlog.e("CdmaCallTracker", "canTransfer: not possible in CDMA");
    return false;
  }

  void clearDisconnected()
  {
    internalClearDisconnected();
    updatePhoneState();
    this.mPhone.notifyPreciseCallStateChanged();
  }

  void conference()
  {
    flashAndSetGenericTrue();
  }

  Connection dial(String paramString)
    throws CallStateException
  {
    return dial(paramString, 0);
  }

  Connection dial(String paramString, int paramInt)
    throws CallStateException
  {
    clearDisconnected();
    if (!canDial())
      throw new CallStateException("cannot dial in current state");
    boolean bool1 = SystemProperties.get("ril.cdma.inecmmode", "false").equals("true");
    boolean bool2 = PhoneNumberUtils.isLocalEmergencyNumber(paramString, this.mPhone.getContext());
    if ((bool1) && (bool2))
      handleEcmTimer(1);
    this.mForegroundCall.setGeneric(false);
    Object localObject;
    if (this.mForegroundCall.getState() == Call.State.ACTIVE)
    {
      localObject = dialThreeWay(paramString);
      return localObject;
    }
    this.mPendingMO = new CdmaConnection(this.mPhone.getContext(), checkForTestEmergencyNumber(paramString), this, this.mForegroundCall);
    this.mHangupPendingMO = false;
    if ((this.mPendingMO.mAddress == null) || (this.mPendingMO.mAddress.length() == 0) || (this.mPendingMO.mAddress.indexOf('N') >= 0))
    {
      this.mPendingMO.mCause = Connection.DisconnectCause.INVALID_NUMBER;
      pollCallsWhenSafe();
    }
    while (true)
    {
      updatePhoneState();
      this.mPhone.notifyPreciseCallStateChanged();
      localObject = this.mPendingMO;
      break;
      setMute(false);
      disableDataCallInEmergencyCall(paramString);
      if ((!bool1) || ((bool1) && (bool2)))
      {
        this.mCi.dial(this.mPendingMO.mAddress, paramInt, obtainCompleteMessage());
      }
      else
      {
        this.mPhone.exitEmergencyCallbackMode();
        this.mPhone.setOnEcbModeExitResponse(this, 14, null);
        this.mPendingCallClirMode = paramInt;
        this.mPendingCallInEcm = true;
      }
    }
  }

  public void dispose()
  {
    this.mCi.unregisterForCallStateChanged(this);
    this.mCi.unregisterForOn(this);
    this.mCi.unregisterForNotAvailable(this);
    this.mCi.unregisterForCallWaitingInfo(this);
    CdmaConnection[] arrayOfCdmaConnection = this.mConnections;
    int i = arrayOfCdmaConnection.length;
    int j = 0;
    while (true)
      if (j < i)
      {
        CdmaConnection localCdmaConnection = arrayOfCdmaConnection[j];
        if (localCdmaConnection != null);
        try
        {
          hangup(localCdmaConnection);
          Rlog.d("CdmaCallTracker", "dispose: call connnection onDisconnect, cause LOST_SIGNAL");
          localCdmaConnection.onDisconnect(Connection.DisconnectCause.LOST_SIGNAL);
          j++;
        }
        catch (CallStateException localCallStateException2)
        {
          while (true)
            Rlog.e("CdmaCallTracker", "dispose: unexpected error on hangup", localCallStateException2);
        }
      }
    try
    {
      if (this.mPendingMO != null)
      {
        hangup(this.mPendingMO);
        Rlog.d("CdmaCallTracker", "dispose: call mPendingMO.onDsiconnect, cause LOST_SIGNAL");
        this.mPendingMO.onDisconnect(Connection.DisconnectCause.LOST_SIGNAL);
      }
      clearDisconnected();
      return;
    }
    catch (CallStateException localCallStateException1)
    {
      while (true)
        Rlog.e("CdmaCallTracker", "dispose: unexpected error on hangup", localCallStateException1);
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("GsmCallTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println("droppedDuringPoll: length=" + this.mConnections.length);
    for (int i = 0; i < this.mConnections.length; i++)
    {
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(i);
      arrayOfObject2[1] = this.mConnections[i];
      paramPrintWriter.printf(" mConnections[%d]=%s\n", arrayOfObject2);
    }
    paramPrintWriter.println(" mVoiceCallEndedRegistrants=" + this.mVoiceCallEndedRegistrants);
    paramPrintWriter.println(" mVoiceCallStartedRegistrants=" + this.mVoiceCallStartedRegistrants);
    paramPrintWriter.println(" mCallWaitingRegistrants=" + this.mCallWaitingRegistrants);
    paramPrintWriter.println("droppedDuringPoll: size=" + this.mDroppedDuringPoll.size());
    for (int j = 0; j < this.mDroppedDuringPoll.size(); j++)
    {
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = Integer.valueOf(j);
      arrayOfObject1[1] = this.mDroppedDuringPoll.get(j);
      paramPrintWriter.printf(" mDroppedDuringPoll[%d]=%s\n", arrayOfObject1);
    }
    paramPrintWriter.println(" mRingingCall=" + this.mRingingCall);
    paramPrintWriter.println(" mForegroundCall=" + this.mForegroundCall);
    paramPrintWriter.println(" mBackgroundCall=" + this.mBackgroundCall);
    paramPrintWriter.println(" mPendingMO=" + this.mPendingMO);
    paramPrintWriter.println(" mHangupPendingMO=" + this.mHangupPendingMO);
    paramPrintWriter.println(" mPendingCallInEcm=" + this.mPendingCallInEcm);
    paramPrintWriter.println(" mIsInEmergencyCall=" + this.mIsInEmergencyCall);
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.println(" mDesiredMute=" + this.mDesiredMute);
    paramPrintWriter.println(" mPendingCallClirMode=" + this.mPendingCallClirMode);
    paramPrintWriter.println(" mState=" + this.mState);
    paramPrintWriter.println(" mIsEcmTimerCanceled=" + this.mIsEcmTimerCanceled);
  }

  void explicitCallTransfer()
  {
    this.mCi.explicitCallTransfer(obtainCompleteMessage(13));
  }

  protected void finalize()
  {
    Rlog.d("CdmaCallTracker", "CdmaCallTracker finalized");
  }

  CdmaConnection getConnectionByIndex(CdmaCall paramCdmaCall, int paramInt)
    throws CallStateException
  {
    int i = paramCdmaCall.mConnections.size();
    int j = 0;
    CdmaConnection localCdmaConnection;
    if (j < i)
    {
      localCdmaConnection = (CdmaConnection)paramCdmaCall.mConnections.get(j);
      if (localCdmaConnection.getCDMAIndex() != paramInt);
    }
    while (true)
    {
      return localCdmaConnection;
      j++;
      break;
      localCdmaConnection = null;
    }
  }

  boolean getMute()
  {
    return this.mDesiredMute;
  }

  public void handleMessage(Message paramMessage)
  {
    if (!this.mPhone.mIsTheCurrentActivePhone)
      Rlog.w("CdmaCallTracker", "Ignoring events received on inactive CdmaPhone");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      case 8:
      case 6:
      case 7:
      case 11:
      case 12:
      case 13:
      default:
        throw new RuntimeException("unexpected event not handled");
      case 1:
        Rlog.d("CdmaCallTracker", "Event EVENT_POLL_CALLS_RESULT Received");
        ((AsyncResult)paramMessage.obj);
        if (paramMessage == this.mLastRelevantPoll)
        {
          this.mNeedsPoll = false;
          this.mLastRelevantPoll = null;
          handlePollCalls((AsyncResult)paramMessage.obj);
        }
        break;
      case 4:
        operationComplete();
        break;
      case 5:
        AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
        operationComplete();
        int i;
        if (localAsyncResult2.exception != null)
        {
          i = 16;
          Rlog.i("CdmaCallTracker", "Exception during getLastCallFailCause, assuming normal disconnect");
        }
        while (true)
        {
          int j = 0;
          int k = this.mDroppedDuringPoll.size();
          while (j < k)
          {
            ((CdmaConnection)this.mDroppedDuringPoll.get(j)).onRemoteDisconnect(i);
            j++;
          }
          i = ((int[])(int[])localAsyncResult2.result)[0];
        }
        updatePhoneState();
        this.mPhone.notifyPreciseCallStateChanged();
        this.mDroppedDuringPoll.clear();
        break;
      case 2:
      case 3:
        pollCallsWhenSafe();
        break;
      case 9:
        handleRadioAvailable();
        break;
      case 10:
        handleRadioNotAvailable();
        break;
      case 14:
        if (this.mPendingCallInEcm)
        {
          this.mCi.dial(this.mPendingMO.mAddress, this.mPendingCallClirMode, obtainCompleteMessage());
          this.mPendingCallInEcm = false;
        }
        this.mPhone.unsetOnEcbModeExitResponse(this);
        break;
      case 15:
        AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
        if (localAsyncResult1.exception == null)
        {
          handleCallWaitingInfo((CdmaCallWaitingNotification)localAsyncResult1.result);
          Rlog.d("CdmaCallTracker", "Event EVENT_CALL_WAITING_INFO_CDMA Received");
        }
        break;
      case 16:
        if (((AsyncResult)paramMessage.obj).exception == null)
        {
          this.mPendingMO.onConnectedInOrOut();
          this.mPendingMO = null;
        }
        break;
      }
    }
  }

  protected void handlePollCalls(AsyncResult paramAsyncResult)
  {
    Object localObject;
    Connection localConnection;
    int i;
    boolean bool1;
    int j;
    int k;
    CdmaConnection localCdmaConnection2;
    DriverCall localDriverCall;
    if (paramAsyncResult.exception == null)
    {
      localObject = (List)paramAsyncResult.result;
      localConnection = null;
      i = 0;
      bool1 = false;
      j = 0;
      k = 0;
      int m = 0;
      int n = ((List)localObject).size();
      if (k >= this.mConnections.length)
        break label689;
      localCdmaConnection2 = this.mConnections[k];
      localDriverCall = null;
      if (m < n)
      {
        localDriverCall = (DriverCall)((List)localObject).get(m);
        if (localDriverCall.index != k + 1)
          break label251;
        m++;
      }
      if ((localCdmaConnection2 != null) || (localDriverCall == null))
        break label338;
      if ((this.mPendingMO == null) || (!this.mPendingMO.compareTo(localDriverCall)))
        break label271;
      this.mConnections[k] = this.mPendingMO;
      this.mPendingMO.mIndex = k;
      this.mPendingMO.update(localDriverCall);
      this.mPendingMO = null;
      if (!this.mHangupPendingMO)
        break label329;
      this.mHangupPendingMO = false;
      if (this.mIsEcmTimerCanceled)
        handleEcmTimer(0);
    }
    while (true)
    {
      try
      {
        log("poll: hangupPendingMO, hangup conn " + k);
        hangup(this.mConnections[k]);
        return;
        if (isCommandExceptionRadioNotAvailable(paramAsyncResult.exception))
        {
          localObject = new ArrayList();
          break;
        }
        pollCallsAfterDelay();
        continue;
        label251: localDriverCall = null;
      }
      catch (CallStateException localCallStateException)
      {
        Rlog.e("CdmaCallTracker", "unexpected error on hangup");
        continue;
      }
      label271: log("pendingMo=" + this.mPendingMO + ", dc=" + localDriverCall);
      localConnection = checkMtFindNewRinging(localDriverCall, k);
      if (localConnection == null)
        j = 1;
      checkAndEnableDataCallAfterEmergencyCallDropped();
      label329: i = 1;
      while (true)
      {
        k++;
        break;
        label338: if ((localCdmaConnection2 != null) && (localDriverCall == null))
        {
          int i2 = this.mForegroundCall.mConnections.size();
          for (int i3 = 0; i3 < i2; i3++)
          {
            log("adding fgCall cn " + i3 + " to droppedDuringPoll");
            CdmaConnection localCdmaConnection4 = (CdmaConnection)this.mForegroundCall.mConnections.get(i3);
            this.mDroppedDuringPoll.add(localCdmaConnection4);
          }
          int i4 = this.mRingingCall.mConnections.size();
          for (int i5 = 0; i5 < i4; i5++)
          {
            log("adding rgCall cn " + i5 + " to droppedDuringPoll");
            CdmaConnection localCdmaConnection3 = (CdmaConnection)this.mRingingCall.mConnections.get(i5);
            this.mDroppedDuringPoll.add(localCdmaConnection3);
          }
          this.mForegroundCall.setGeneric(false);
          this.mRingingCall.setGeneric(false);
          if (this.mIsEcmTimerCanceled)
            handleEcmTimer(0);
          checkAndEnableDataCallAfterEmergencyCallDropped();
          this.mConnections[k] = null;
        }
        else if ((localCdmaConnection2 != null) && (localDriverCall != null))
        {
          if (localCdmaConnection2.mIsIncoming == localDriverCall.isMT)
            break label658;
          if (localDriverCall.isMT == true)
          {
            this.mDroppedDuringPoll.add(localCdmaConnection2);
            localConnection = checkMtFindNewRinging(localDriverCall, k);
            if (localConnection == null)
              j = 1;
            checkAndEnableDataCallAfterEmergencyCallDropped();
          }
          else
          {
            Rlog.e("CdmaCallTracker", "Error in RIL, Phantom call appeared " + localDriverCall);
          }
        }
      }
      label658: boolean bool2 = localCdmaConnection2.update(localDriverCall);
      if ((i != 0) || (bool2));
      for (i = 1; ; i = 0)
        break;
      label689: if (this.mPendingMO != null)
      {
        Rlog.d("CdmaCallTracker", "Pending MO dropped before poll fg state:" + this.mForegroundCall.getState());
        this.mDroppedDuringPoll.add(this.mPendingMO);
        this.mPendingMO = null;
        this.mHangupPendingMO = false;
        if (this.mPendingCallInEcm)
          this.mPendingCallInEcm = false;
      }
      if (localConnection != null)
        this.mPhone.notifyNewRingingConnection(localConnection);
      int i1 = -1 + this.mDroppedDuringPoll.size();
      if (i1 >= 0)
      {
        CdmaConnection localCdmaConnection1 = (CdmaConnection)this.mDroppedDuringPoll.get(i1);
        Connection.DisconnectCause localDisconnectCause;
        if ((localCdmaConnection1.isIncoming()) && (localCdmaConnection1.getConnectTime() == 0L))
          if (localCdmaConnection1.mCause == Connection.DisconnectCause.LOCAL)
          {
            localDisconnectCause = Connection.DisconnectCause.INCOMING_REJECTED;
            label838: log("missed/rejected call, conn.cause=" + localCdmaConnection1.mCause);
            log("setting cause to " + localDisconnectCause);
            this.mDroppedDuringPoll.remove(i1);
            bool1 |= localCdmaConnection1.onDisconnect(localDisconnectCause);
          }
        while (true)
        {
          i1--;
          break;
          localDisconnectCause = Connection.DisconnectCause.INCOMING_MISSED;
          break label838;
          if ((localCdmaConnection1.mCause == Connection.DisconnectCause.LOCAL) || (localCdmaConnection1.mCause == Connection.DisconnectCause.INVALID_NUMBER))
          {
            this.mDroppedDuringPoll.remove(i1);
            bool1 |= localCdmaConnection1.onDisconnect(localCdmaConnection1.mCause);
          }
        }
      }
      if (this.mDroppedDuringPoll.size() > 0)
        this.mCi.getLastCallFailCause(obtainNoPollCompleteMessage(5));
      if (0 != 0)
        pollCallsAfterDelay();
      if ((localConnection != null) || (i != 0) || (bool1))
        internalClearDisconnected();
      updatePhoneState();
      if (j != 0)
        this.mPhone.notifyUnknownConnection();
      if ((i != 0) || (localConnection != null) || (bool1))
        this.mPhone.notifyPreciseCallStateChanged();
    }
  }

  void hangup(CdmaCall paramCdmaCall)
    throws CallStateException
  {
    if (paramCdmaCall.getConnections().size() == 0)
      throw new CallStateException("no connections in call");
    if (paramCdmaCall == this.mRingingCall)
    {
      log("(ringing) hangup waiting or background");
      this.mCi.hangupWaitingOrBackground(obtainCompleteMessage());
    }
    while (true)
    {
      paramCdmaCall.onHangupLocal();
      this.mPhone.notifyPreciseCallStateChanged();
      return;
      if (paramCdmaCall == this.mForegroundCall)
      {
        if (paramCdmaCall.isDialingOrAlerting())
        {
          log("(foregnd) hangup dialing or alerting...");
          hangup((CdmaConnection)paramCdmaCall.getConnections().get(0));
        }
        else
        {
          hangupForegroundResumeBackground();
        }
      }
      else
      {
        if (paramCdmaCall != this.mBackgroundCall)
          break;
        if (this.mRingingCall.isRinging())
        {
          log("hangup all conns in background call");
          hangupAllConnections(paramCdmaCall);
        }
        else
        {
          hangupWaitingOrBackground();
        }
      }
    }
    throw new RuntimeException("CdmaCall " + paramCdmaCall + "does not belong to CdmaCallTracker " + this);
  }

  void hangup(CdmaConnection paramCdmaConnection)
    throws CallStateException
  {
    if (paramCdmaConnection.mOwner != this)
      throw new CallStateException("CdmaConnection " + paramCdmaConnection + "does not belong to CdmaCallTracker " + this);
    if (paramCdmaConnection == this.mPendingMO)
    {
      log("hangup: set hangupPendingMO to true");
      this.mHangupPendingMO = true;
    }
    while (true)
    {
      paramCdmaConnection.onHangupLocal();
      while (true)
      {
        return;
        if ((paramCdmaConnection.getCall() != this.mRingingCall) || (this.mRingingCall.getState() != Call.State.WAITING))
          break;
        paramCdmaConnection.onLocalDisconnect();
        updatePhoneState();
        this.mPhone.notifyPreciseCallStateChanged();
      }
      try
      {
        this.mCi.hangupConnection(paramCdmaConnection.getCDMAIndex(), obtainCompleteMessage());
      }
      catch (CallStateException localCallStateException)
      {
        Rlog.w("CdmaCallTracker", "CdmaCallTracker WARN: hangup() on absent connection " + paramCdmaConnection);
      }
    }
  }

  void hangupAllConnections(CdmaCall paramCdmaCall)
  {
    try
    {
      int i = paramCdmaCall.mConnections.size();
      for (int j = 0; j < i; j++)
      {
        CdmaConnection localCdmaConnection = (CdmaConnection)paramCdmaCall.mConnections.get(j);
        this.mCi.hangupConnection(localCdmaConnection.getCDMAIndex(), obtainCompleteMessage());
      }
    }
    catch (CallStateException localCallStateException)
    {
      Rlog.e("CdmaCallTracker", "hangupConnectionByIndex caught " + localCallStateException);
    }
  }

  void hangupConnectionByIndex(CdmaCall paramCdmaCall, int paramInt)
    throws CallStateException
  {
    int i = paramCdmaCall.mConnections.size();
    for (int j = 0; j < i; j++)
      if (((CdmaConnection)paramCdmaCall.mConnections.get(j)).getCDMAIndex() == paramInt)
      {
        this.mCi.hangupConnection(paramInt, obtainCompleteMessage());
        return;
      }
    throw new CallStateException("no gsm index found");
  }

  void hangupForegroundResumeBackground()
  {
    log("hangupForegroundResumeBackground");
    this.mCi.hangupForegroundResumeBackground(obtainCompleteMessage());
  }

  void hangupWaitingOrBackground()
  {
    log("hangupWaitingOrBackground");
    this.mCi.hangupWaitingOrBackground(obtainCompleteMessage());
  }

  boolean isInEmergencyCall()
  {
    return this.mIsInEmergencyCall;
  }

  protected void log(String paramString)
  {
    Rlog.d("CdmaCallTracker", "[CdmaCallTracker] " + paramString);
  }

  public void registerForCallWaiting(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mCallWaitingRegistrants.add(localRegistrant);
  }

  public void registerForVoiceCallEnded(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mVoiceCallEndedRegistrants.add(localRegistrant);
  }

  public void registerForVoiceCallStarted(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mVoiceCallStartedRegistrants.add(localRegistrant);
    if (this.mState != PhoneConstants.State.IDLE)
      localRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
  }

  void rejectCall()
    throws CallStateException
  {
    if (this.mRingingCall.getState().isRinging())
    {
      this.mCi.rejectCall(obtainCompleteMessage());
      return;
    }
    throw new CallStateException("phone not ringing");
  }

  void separate(CdmaConnection paramCdmaConnection)
    throws CallStateException
  {
    if (paramCdmaConnection.mOwner != this)
      throw new CallStateException("CdmaConnection " + paramCdmaConnection + "does not belong to CdmaCallTracker " + this);
    try
    {
      this.mCi.separateConnection(paramCdmaConnection.getCDMAIndex(), obtainCompleteMessage(12));
      return;
    }
    catch (CallStateException localCallStateException)
    {
      while (true)
        Rlog.w("CdmaCallTracker", "CdmaCallTracker WARN: separate() on absent connection " + paramCdmaConnection);
    }
  }

  void setMute(boolean paramBoolean)
  {
    this.mDesiredMute = paramBoolean;
    this.mCi.setMute(this.mDesiredMute, null);
  }

  void switchWaitingOrHoldingAndActive()
    throws CallStateException
  {
    if (this.mRingingCall.getState() == Call.State.INCOMING)
      throw new CallStateException("cannot be in the incoming state");
    if (this.mForegroundCall.getConnections().size() > 1)
      flashAndSetGenericTrue();
    while (true)
    {
      return;
      this.mCi.sendCDMAFeatureCode("", obtainMessage(8));
    }
  }

  public void unregisterForCallWaiting(Handler paramHandler)
  {
    this.mCallWaitingRegistrants.remove(paramHandler);
  }

  public void unregisterForVoiceCallEnded(Handler paramHandler)
  {
    this.mVoiceCallEndedRegistrants.remove(paramHandler);
  }

  public void unregisterForVoiceCallStarted(Handler paramHandler)
  {
    this.mVoiceCallStartedRegistrants.remove(paramHandler);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaCallTracker
 * JD-Core Version:    0.6.2
 */