package com.android.internal.telephony.cdma;

import android.util.Log;
import com.android.internal.telephony.MiuiIccPhoneBookInterfaceManager;

public class MiuiRuimPhoneBookInterfaceManager extends MiuiIccPhoneBookInterfaceManager
{
  static final String LOG_TAG = "CDMA";

  public MiuiRuimPhoneBookInterfaceManager(CDMAPhone paramCDMAPhone)
  {
    super(paramCDMAPhone);
  }

  protected void logd(String paramString)
  {
    Log.d("CDMA", "[RuimPbInterfaceManager] " + paramString);
  }

  protected void loge(String paramString)
  {
    Log.e("CDMA", "[RuimPbInterfaceManager] " + paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.MiuiRuimPhoneBookInterfaceManager
 * JD-Core Version:    0.6.2
 */