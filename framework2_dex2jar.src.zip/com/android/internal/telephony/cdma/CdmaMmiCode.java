package com.android.internal.telephony.cdma;

import android.content.Context;
import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandException;
import com.android.internal.telephony.CommandException.Error;
import com.android.internal.telephony.MmiCode;
import com.android.internal.telephony.MmiCode.State;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.UiccCardApplication;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CdmaMmiCode extends Handler
  implements MmiCode
{
  static final String ACTION_REGISTER = "**";
  static final int EVENT_SET_COMPLETE = 1;
  static final String LOG_TAG = "CdmaMmiCode";
  static final int MATCH_GROUP_ACTION = 2;
  static final int MATCH_GROUP_DIALING_NUMBER = 12;
  static final int MATCH_GROUP_POUND_STRING = 1;
  static final int MATCH_GROUP_PWD_CONFIRM = 11;
  static final int MATCH_GROUP_SERVICE_CODE = 3;
  static final int MATCH_GROUP_SIA = 5;
  static final int MATCH_GROUP_SIB = 7;
  static final int MATCH_GROUP_SIC = 9;
  static final String SC_PIN = "04";
  static final String SC_PIN2 = "042";
  static final String SC_PUK = "05";
  static final String SC_PUK2 = "052";
  static Pattern sPatternSuppService = Pattern.compile("((\\*|#|\\*#|\\*\\*|##)(\\d{2,3})(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*))?)?)?)?#)(.*)");
  String mAction;
  Context mContext;
  String mDialingNumber;
  CharSequence mMessage;
  CDMAPhone mPhone;
  String mPoundString;
  String mPwd;
  String mSc;
  String mSia;
  String mSib;
  String mSic;
  MmiCode.State mState = MmiCode.State.PENDING;
  UiccCardApplication mUiccApplication;

  CdmaMmiCode(CDMAPhone paramCDMAPhone, UiccCardApplication paramUiccCardApplication)
  {
    super(paramCDMAPhone.getHandler().getLooper());
    this.mPhone = paramCDMAPhone;
    this.mContext = paramCDMAPhone.getContext();
    this.mUiccApplication = paramUiccCardApplication;
  }

  private CharSequence getScString()
  {
    if ((this.mSc != null) && (isPinPukCommand()));
    for (Object localObject = this.mContext.getText(17039466); ; localObject = "")
      return localObject;
  }

  private void handlePasswordError(int paramInt)
  {
    this.mState = MmiCode.State.FAILED;
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    localStringBuilder.append(this.mContext.getText(paramInt));
    this.mMessage = localStringBuilder;
    this.mPhone.onMMIDone(this);
  }

  private static String makeEmptyNull(String paramString)
  {
    if ((paramString != null) && (paramString.length() == 0))
      paramString = null;
    return paramString;
  }

  public static CdmaMmiCode newFromDialString(String paramString, CDMAPhone paramCDMAPhone, UiccCardApplication paramUiccCardApplication)
  {
    CdmaMmiCode localCdmaMmiCode = null;
    Matcher localMatcher = sPatternSuppService.matcher(paramString);
    if (localMatcher.matches())
    {
      localCdmaMmiCode = new CdmaMmiCode(paramCDMAPhone, paramUiccCardApplication);
      localCdmaMmiCode.mPoundString = makeEmptyNull(localMatcher.group(1));
      localCdmaMmiCode.mAction = makeEmptyNull(localMatcher.group(2));
      localCdmaMmiCode.mSc = makeEmptyNull(localMatcher.group(3));
      localCdmaMmiCode.mSia = makeEmptyNull(localMatcher.group(5));
      localCdmaMmiCode.mSib = makeEmptyNull(localMatcher.group(7));
      localCdmaMmiCode.mSic = makeEmptyNull(localMatcher.group(9));
      localCdmaMmiCode.mPwd = makeEmptyNull(localMatcher.group(11));
      localCdmaMmiCode.mDialingNumber = makeEmptyNull(localMatcher.group(12));
    }
    return localCdmaMmiCode;
  }

  private void onSetComplete(Message paramMessage, AsyncResult paramAsyncResult)
  {
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    CommandException.Error localError;
    int i;
    if (paramAsyncResult.exception != null)
    {
      this.mState = MmiCode.State.FAILED;
      if ((paramAsyncResult.exception instanceof CommandException))
      {
        localError = ((CommandException)paramAsyncResult.exception).getCommandError();
        if (localError == CommandException.Error.PASSWORD_INCORRECT)
          if (isPinPukCommand())
            if ((this.mSc.equals("05")) || (this.mSc.equals("052")))
            {
              localStringBuilder.append(this.mContext.getText(17039451));
              i = paramMessage.arg1;
              if (i > 0)
                break label168;
              Rlog.d("CdmaMmiCode", "onSetComplete: PUK locked, cancel as lock screen will handle this");
              this.mState = MmiCode.State.CANCELLED;
            }
      }
    }
    while (true)
    {
      this.mMessage = localStringBuilder;
      this.mPhone.onMMIDone(this);
      return;
      localStringBuilder.append(this.mContext.getText(17039450));
      break;
      label168: if (i > 0)
      {
        Rlog.d("CdmaMmiCode", "onSetComplete: attemptsRemaining=" + i);
        Resources localResources = this.mContext.getResources();
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(i);
        localStringBuilder.append(localResources.getQuantityString(18022400, i, arrayOfObject));
        continue;
        localStringBuilder.append(this.mContext.getText(17039448));
        continue;
        if (localError == CommandException.Error.SIM_PUK2)
        {
          localStringBuilder.append(this.mContext.getText(17039450));
          localStringBuilder.append("\n");
          localStringBuilder.append(this.mContext.getText(17039456));
        }
        else if (localError == CommandException.Error.REQUEST_NOT_SUPPORTED)
        {
          if (this.mSc.equals("04"))
            localStringBuilder.append(this.mContext.getText(17039457));
        }
        else
        {
          localStringBuilder.append(this.mContext.getText(17039441));
          continue;
          localStringBuilder.append(this.mContext.getText(17039441));
          continue;
          if (isRegister())
          {
            this.mState = MmiCode.State.COMPLETE;
            localStringBuilder.append(this.mContext.getText(17039446));
          }
          else
          {
            this.mState = MmiCode.State.FAILED;
            localStringBuilder.append(this.mContext.getText(17039441));
          }
        }
      }
    }
  }

  public void cancel()
  {
    if ((this.mState == MmiCode.State.COMPLETE) || (this.mState == MmiCode.State.FAILED));
    while (true)
    {
      return;
      this.mState = MmiCode.State.CANCELLED;
      this.mPhone.onMMIDone(this);
    }
  }

  public CharSequence getMessage()
  {
    return this.mMessage;
  }

  public MmiCode.State getState()
  {
    return this.mState;
  }

  public void handleMessage(Message paramMessage)
  {
    if (paramMessage.what == 1)
      onSetComplete(paramMessage, (AsyncResult)paramMessage.obj);
    while (true)
    {
      return;
      Rlog.e("CdmaMmiCode", "Unexpected reply");
    }
  }

  public boolean isCancelable()
  {
    return false;
  }

  boolean isPinPukCommand()
  {
    if ((this.mSc != null) && ((this.mSc.equals("04")) || (this.mSc.equals("042")) || (this.mSc.equals("05")) || (this.mSc.equals("052"))));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isRegister()
  {
    if ((this.mAction != null) && (this.mAction.equals("**")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isUssdRequest()
  {
    Rlog.w("CdmaMmiCode", "isUssdRequest is not implemented in CdmaMmiCode");
    return false;
  }

  void processCode()
  {
    while (true)
    {
      String str1;
      String str2;
      int i;
      try
      {
        if (isPinPukCommand())
        {
          str1 = this.mSia;
          str2 = this.mSib;
          i = str2.length();
          if (isRegister())
          {
            if (str2.equals(this.mSic))
              break label366;
            handlePasswordError(17039452);
            break label365;
            handlePasswordError(17039453);
          }
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        this.mState = MmiCode.State.FAILED;
        this.mMessage = this.mContext.getText(17039441);
        this.mPhone.onMMIDone(this);
      }
      label365: label366: 
      do
      {
        if ((this.mSc.equals("04")) && (this.mUiccApplication != null) && (this.mUiccApplication.getState() == IccCardApplicationStatus.AppState.APPSTATE_PUK))
        {
          handlePasswordError(17039455);
        }
        else if (this.mUiccApplication != null)
        {
          Rlog.d("CdmaMmiCode", "process mmi service code using UiccApp sc=" + this.mSc);
          if (this.mSc.equals("04"))
            this.mUiccApplication.changeIccLockPassword(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("042"))
            this.mUiccApplication.changeIccFdnPassword(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("05"))
            this.mUiccApplication.supplyPuk(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("052"))
            this.mUiccApplication.supplyPuk2(str1, str2, obtainMessage(1, this));
          else
            throw new RuntimeException("Unsupported service code=" + this.mSc);
        }
        else
        {
          throw new RuntimeException("No application mUiccApplicaiton is null");
          throw new RuntimeException("Ivalid register/action=" + this.mAction);
        }
        return;
        if (i < 4)
          break;
      }
      while (i <= 8);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaMmiCode
 * JD-Core Version:    0.6.2
 */