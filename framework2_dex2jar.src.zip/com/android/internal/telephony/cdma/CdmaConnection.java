package com.android.internal.telephony.cdma;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Registrant;
import android.os.SystemClock;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.Connection.DisconnectCause;
import com.android.internal.telephony.Connection.PostDialState;
import com.android.internal.telephony.DriverCall;
import com.android.internal.telephony.DriverCall.State;
import com.android.internal.telephony.PhoneConstants;
import com.android.internal.telephony.UUSInfo;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;

public class CdmaConnection extends Connection
{
  static final int EVENT_DTMF_DONE = 1;
  static final int EVENT_NEXT_POST_DIAL = 3;
  static final int EVENT_PAUSE_DONE = 2;
  static final int EVENT_WAKE_LOCK_TIMEOUT = 4;
  static final String LOG_TAG = "CdmaConnection";
  static final int PAUSE_DELAY_MILLIS = 2000;
  private static final boolean VDBG = false;
  static final int WAKE_LOCK_TIMEOUT_MILLIS = 60000;
  String mAddress;
  Connection.DisconnectCause mCause = Connection.DisconnectCause.NOT_DISCONNECTED;
  long mConnectTime;
  long mConnectTimeReal;
  long mCreateTime;
  String mDialString;
  long mDisconnectTime;
  boolean mDisconnected;
  long mDuration;
  Handler mHandler;
  long mHoldingStartTime;
  int mIndex;
  boolean mIsIncoming;
  int mNextPostDialChar;
  int mNumberPresentation = PhoneConstants.PRESENTATION_ALLOWED;
  CdmaCallTracker mOwner;
  CdmaCall mParent;
  private PowerManager.WakeLock mPartialWakeLock;
  Connection.PostDialState mPostDialState = Connection.PostDialState.NOT_STARTED;
  String mPostDialString;

  CdmaConnection(Context paramContext, DriverCall paramDriverCall, CdmaCallTracker paramCdmaCallTracker, int paramInt)
  {
    createWakeLock(paramContext);
    acquireWakeLock();
    this.mOwner = paramCdmaCallTracker;
    this.mHandler = new MyHandler(this.mOwner.getLooper());
    this.mAddress = paramDriverCall.number;
    this.mIsIncoming = paramDriverCall.isMT;
    this.mCreateTime = System.currentTimeMillis();
    this.mCnapName = paramDriverCall.name;
    this.mCnapNamePresentation = paramDriverCall.namePresentation;
    this.mNumberPresentation = paramDriverCall.numberPresentation;
    this.mIndex = paramInt;
    this.mParent = parentFromDCState(paramDriverCall.state);
    this.mParent.attach(this, paramDriverCall);
  }

  CdmaConnection(Context paramContext, CdmaCallWaitingNotification paramCdmaCallWaitingNotification, CdmaCallTracker paramCdmaCallTracker, CdmaCall paramCdmaCall)
  {
    createWakeLock(paramContext);
    acquireWakeLock();
    this.mOwner = paramCdmaCallTracker;
    this.mHandler = new MyHandler(this.mOwner.getLooper());
    this.mAddress = paramCdmaCallWaitingNotification.number;
    this.mNumberPresentation = paramCdmaCallWaitingNotification.numberPresentation;
    this.mCnapName = paramCdmaCallWaitingNotification.name;
    this.mCnapNamePresentation = paramCdmaCallWaitingNotification.namePresentation;
    this.mIndex = -1;
    this.mIsIncoming = true;
    this.mCreateTime = System.currentTimeMillis();
    this.mConnectTime = 0L;
    this.mParent = paramCdmaCall;
    paramCdmaCall.attachFake(this, Call.State.WAITING);
  }

  CdmaConnection(Context paramContext, String paramString, CdmaCallTracker paramCdmaCallTracker, CdmaCall paramCdmaCall)
  {
    createWakeLock(paramContext);
    acquireWakeLock();
    this.mOwner = paramCdmaCallTracker;
    this.mHandler = new MyHandler(this.mOwner.getLooper());
    this.mDialString = paramString;
    Rlog.d("CdmaConnection", "[CDMAConn] CdmaConnection: dialString=" + paramString);
    String str = formatDialString(paramString);
    Rlog.d("CdmaConnection", "[CDMAConn] CdmaConnection:formated dialString=" + str);
    this.mAddress = PhoneNumberUtils.extractNetworkPortionAlt(str);
    this.mPostDialString = PhoneNumberUtils.extractPostDialPortion(str);
    this.mIndex = -1;
    this.mIsIncoming = false;
    this.mCnapName = null;
    this.mCnapNamePresentation = PhoneConstants.PRESENTATION_ALLOWED;
    this.mNumberPresentation = PhoneConstants.PRESENTATION_ALLOWED;
    this.mCreateTime = System.currentTimeMillis();
    if (paramCdmaCall != null)
    {
      this.mParent = paramCdmaCall;
      if (paramCdmaCall.mState != Call.State.ACTIVE)
        break label206;
      paramCdmaCall.attachFake(this, Call.State.ACTIVE);
    }
    while (true)
    {
      return;
      label206: paramCdmaCall.attachFake(this, Call.State.DIALING);
    }
  }

  private void acquireWakeLock()
  {
    log("acquireWakeLock");
    this.mPartialWakeLock.acquire();
  }

  private void createWakeLock(Context paramContext)
  {
    this.mPartialWakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "CdmaConnection");
  }

  private void doDisconnect()
  {
    this.mIndex = -1;
    this.mDisconnectTime = System.currentTimeMillis();
    this.mDuration = (SystemClock.elapsedRealtime() - this.mConnectTimeReal);
    this.mDisconnected = true;
  }

  static boolean equalsHandlesNulls(Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if (paramObject1 == null)
      if (paramObject2 == null)
        bool = true;
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = paramObject1.equals(paramObject2);
    }
  }

  private static int findNextPCharOrNonPOrNonWCharIndex(String paramString, int paramInt)
  {
    boolean bool = isWait(paramString.charAt(paramInt));
    int i = paramInt + 1;
    int j = paramString.length();
    while (true)
    {
      if (i < j)
      {
        char c = paramString.charAt(i);
        if (isWait(c))
          bool = true;
        if ((isWait(c)) || (isPause(c)));
      }
      else
      {
        if ((i < j) && (i > paramInt + 1) && (!bool) && (isPause(paramString.charAt(paramInt))))
          i = paramInt + 1;
        return i;
      }
      i++;
    }
  }

  private static char findPOrWCharToAppend(String paramString, int paramInt1, int paramInt2)
  {
    if (isPause(paramString.charAt(paramInt1)));
    for (char c = ','; ; c = ';')
    {
      if (paramInt2 > paramInt1 + 1)
        c = ';';
      return c;
    }
  }

  public static String formatDialString(String paramString)
  {
    if (paramString == null);
    StringBuilder localStringBuilder;
    for (String str = null; ; str = PhoneNumberUtils.cdmaCheckAndProcessPlusCode(localStringBuilder.toString()))
    {
      return str;
      int i = paramString.length();
      localStringBuilder = new StringBuilder();
      int j = 0;
      if (j < i)
      {
        char c = paramString.charAt(j);
        int k;
        if ((isPause(c)) || (isWait(c)))
          if (j < i - 1)
          {
            k = findNextPCharOrNonPOrNonWCharIndex(paramString, j);
            if (k >= i)
              break label104;
            localStringBuilder.append(findPOrWCharToAppend(paramString, j, k));
            if (k > j + 1)
              j = k - 1;
          }
        while (true)
        {
          j++;
          break;
          label104: if (k == i)
          {
            j = i - 1;
            continue;
            localStringBuilder.append(c);
          }
        }
      }
    }
  }

  private boolean isConnectingInOrOut()
  {
    if ((this.mParent == null) || (this.mParent == this.mOwner.mRingingCall) || (this.mParent.mState == Call.State.DIALING) || (this.mParent.mState == Call.State.ALERTING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private static boolean isPause(char paramChar)
  {
    if (paramChar == ',');
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private static boolean isWait(char paramChar)
  {
    if (paramChar == ';');
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void log(String paramString)
  {
    Rlog.d("CdmaConnection", "[CDMAConn] " + paramString);
  }

  private CdmaCall parentFromDCState(DriverCall.State paramState)
  {
    CdmaCall localCdmaCall;
    switch (1.$SwitchMap$com$android$internal$telephony$DriverCall$State[paramState.ordinal()])
    {
    default:
      throw new RuntimeException("illegal call state: " + paramState);
    case 1:
    case 2:
    case 3:
      localCdmaCall = this.mOwner.mForegroundCall;
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      return localCdmaCall;
      localCdmaCall = this.mOwner.mBackgroundCall;
      continue;
      localCdmaCall = this.mOwner.mRingingCall;
    }
  }

  private boolean processPostDialChar(char paramChar)
  {
    int i = 1;
    if (PhoneNumberUtils.is12Key(paramChar))
      this.mOwner.mCi.sendDtmf(paramChar, this.mHandler.obtainMessage(i));
    while (true)
    {
      return i;
      if (paramChar == ',')
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(2), 2000L);
      else if (paramChar == ';')
        setPostDialState(Connection.PostDialState.WAIT);
      else if (paramChar == 'N')
        setPostDialState(Connection.PostDialState.WILD);
      else
        int j = 0;
    }
  }

  private void releaseWakeLock()
  {
    synchronized (this.mPartialWakeLock)
    {
      if (this.mPartialWakeLock.isHeld())
      {
        log("releaseWakeLock");
        this.mPartialWakeLock.release();
      }
      return;
    }
  }

  private void setPostDialState(Connection.PostDialState paramPostDialState)
  {
    if ((paramPostDialState == Connection.PostDialState.STARTED) || (paramPostDialState == Connection.PostDialState.PAUSE));
    while (true)
    {
      synchronized (this.mPartialWakeLock)
      {
        if (this.mPartialWakeLock.isHeld())
        {
          this.mHandler.removeMessages(4);
          Message localMessage = this.mHandler.obtainMessage(4);
          this.mHandler.sendMessageDelayed(localMessage, 60000L);
          this.mPostDialState = paramPostDialState;
          return;
        }
        acquireWakeLock();
      }
      this.mHandler.removeMessages(4);
      releaseWakeLock();
    }
  }

  public void cancelPostDial()
  {
    setPostDialState(Connection.PostDialState.CANCELLED);
  }

  boolean compareTo(DriverCall paramDriverCall)
  {
    boolean bool = true;
    if ((!this.mIsIncoming) && (!paramDriverCall.isMT));
    while (true)
    {
      return bool;
      String str = PhoneNumberUtils.stringFromStringAndTOA(paramDriverCall.number, paramDriverCall.TOA);
      if ((this.mIsIncoming != paramDriverCall.isMT) || (!equalsHandlesNulls(this.mAddress, str)))
        bool = false;
    }
  }

  Connection.DisconnectCause disconnectCauseFromCode(int paramInt)
  {
    CDMAPhone localCDMAPhone;
    int i;
    IccCardApplicationStatus.AppState localAppState;
    Connection.DisconnectCause localDisconnectCause;
    switch (paramInt)
    {
    default:
      localCDMAPhone = this.mOwner.mPhone;
      i = localCDMAPhone.getServiceState().getState();
      UiccCardApplication localUiccCardApplication = UiccController.getInstance().getUiccCardApplication(2);
      if (localUiccCardApplication != null)
      {
        localAppState = localUiccCardApplication.getState();
        if (i != 3)
          break label295;
        localDisconnectCause = Connection.DisconnectCause.POWER_OFF;
      }
      break;
    case 17:
    case 34:
    case 68:
    case 240:
    case 241:
    case 1000:
    case 1001:
    case 1002:
    case 1003:
    case 1004:
    case 1005:
    case 1006:
    case 1007:
    case 1008:
    case 1009:
    }
    while (true)
    {
      return localDisconnectCause;
      localDisconnectCause = Connection.DisconnectCause.BUSY;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CONGESTION;
      continue;
      localDisconnectCause = Connection.DisconnectCause.LIMIT_EXCEEDED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CALL_BARRED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.FDN_BLOCKED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_LOCKED_UNTIL_POWER_CYCLE;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_DROP;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_INTERCEPT;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_REORDER;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_SO_REJECT;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_RETRY_ORDER;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_ACCESS_FAILURE;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_PREEMPTED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_NOT_EMERGENCY;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CDMA_ACCESS_BLOCKED;
      continue;
      localAppState = IccCardApplicationStatus.AppState.APPSTATE_UNKNOWN;
      break;
      label295: if ((i == 1) || (i == 2))
        localDisconnectCause = Connection.DisconnectCause.OUT_OF_SERVICE;
      else if ((localCDMAPhone.mCdmaSubscriptionSource == 0) && (localAppState != IccCardApplicationStatus.AppState.APPSTATE_READY))
        localDisconnectCause = Connection.DisconnectCause.ICC_ERROR;
      else if (paramInt == 16)
        localDisconnectCause = Connection.DisconnectCause.NORMAL;
      else
        localDisconnectCause = Connection.DisconnectCause.ERROR_UNSPECIFIED;
    }
  }

  public void dispose()
  {
  }

  void fakeHoldBeforeDial()
  {
    if (this.mParent != null)
      this.mParent.detach(this);
    this.mParent = this.mOwner.mBackgroundCall;
    this.mParent.attachFake(this, Call.State.HOLDING);
    onStartedHolding();
  }

  protected void finalize()
  {
    if (this.mPartialWakeLock.isHeld())
      Rlog.e("CdmaConnection", "[CdmaConn] UNEXPECTED; mPartialWakeLock is held when finalizing.");
    releaseWakeLock();
  }

  public String getAddress()
  {
    return this.mAddress;
  }

  int getCDMAIndex()
    throws CallStateException
  {
    if (this.mIndex >= 0)
      return 1 + this.mIndex;
    throw new CallStateException("CDMA connection index not assigned");
  }

  public CdmaCall getCall()
  {
    return this.mParent;
  }

  public long getConnectTime()
  {
    return this.mConnectTime;
  }

  public long getCreateTime()
  {
    return this.mCreateTime;
  }

  public Connection.DisconnectCause getDisconnectCause()
  {
    return this.mCause;
  }

  public long getDisconnectTime()
  {
    return this.mDisconnectTime;
  }

  public long getDurationMillis()
  {
    long l = 0L;
    if (this.mConnectTimeReal == l);
    while (true)
    {
      return l;
      if (this.mDuration == l)
        l = SystemClock.elapsedRealtime() - this.mConnectTimeReal;
      else
        l = this.mDuration;
    }
  }

  public long getHoldDurationMillis()
  {
    if (getState() != Call.State.HOLDING);
    for (long l = 0L; ; l = SystemClock.elapsedRealtime() - this.mHoldingStartTime)
      return l;
  }

  public int getNumberPresentation()
  {
    return this.mNumberPresentation;
  }

  public String getOrigDialString()
  {
    return this.mDialString;
  }

  public Connection.PostDialState getPostDialState()
  {
    return this.mPostDialState;
  }

  public String getRemainingPostDialString()
  {
    String str;
    if ((this.mPostDialState == Connection.PostDialState.CANCELLED) || (this.mPostDialState == Connection.PostDialState.COMPLETE) || (this.mPostDialString == null) || (this.mPostDialString.length() <= this.mNextPostDialChar))
      str = "";
    while (true)
    {
      return str;
      str = this.mPostDialString.substring(this.mNextPostDialChar);
      if (Injector.nullifyString(str) != null)
      {
        int i = str.indexOf(';');
        int j = str.indexOf(',');
        if ((i > 0) && ((i < j) || (j <= 0)))
          str = str.substring(0, i);
        else if (j > 0)
          str = str.substring(0, j);
      }
    }
  }

  public Call.State getState()
  {
    if (this.mDisconnected);
    for (Call.State localState = Call.State.DISCONNECTED; ; localState = super.getState())
      return localState;
  }

  public UUSInfo getUUSInfo()
  {
    return null;
  }

  public void hangup()
    throws CallStateException
  {
    if (!this.mDisconnected)
    {
      this.mOwner.hangup(this);
      return;
    }
    throw new CallStateException("disconnected");
  }

  public boolean isIncoming()
  {
    return this.mIsIncoming;
  }

  void onConnectedInOrOut()
  {
    this.mConnectTime = System.currentTimeMillis();
    this.mConnectTimeReal = SystemClock.elapsedRealtime();
    this.mDuration = 0L;
    log("onConnectedInOrOut: connectTime=" + this.mConnectTime);
    if (!this.mIsIncoming)
      processNextPostDialChar();
    while (true)
    {
      return;
      releaseWakeLock();
    }
  }

  boolean onDisconnect(Connection.DisconnectCause paramDisconnectCause)
  {
    boolean bool = false;
    this.mCause = paramDisconnectCause;
    if (!this.mDisconnected)
    {
      doDisconnect();
      this.mOwner.mPhone.notifyDisconnect(this);
      if (this.mParent != null)
        bool = this.mParent.connectionDisconnected(this);
    }
    releaseWakeLock();
    return bool;
  }

  void onHangupLocal()
  {
    this.mCause = Connection.DisconnectCause.LOCAL;
  }

  void onLocalDisconnect()
  {
    if (!this.mDisconnected)
    {
      doDisconnect();
      if (this.mParent != null)
        this.mParent.detach(this);
    }
    releaseWakeLock();
  }

  void onRemoteDisconnect(int paramInt)
  {
    onDisconnect(disconnectCauseFromCode(paramInt));
  }

  void onStartedHolding()
  {
    this.mHoldingStartTime = SystemClock.elapsedRealtime();
  }

  public void proceedAfterWaitChar()
  {
    if (this.mPostDialState != Connection.PostDialState.WAIT)
      Rlog.w("CdmaConnection", "CdmaConnection.proceedAfterWaitChar(): Expected getPostDialState() to be WAIT but was " + this.mPostDialState);
    while (true)
    {
      return;
      setPostDialState(Connection.PostDialState.STARTED);
      processNextPostDialChar();
    }
  }

  public void proceedAfterWildChar(String paramString)
  {
    if (this.mPostDialState != Connection.PostDialState.WILD)
      Rlog.w("CdmaConnection", "CdmaConnection.proceedAfterWaitChar(): Expected getPostDialState() to be WILD but was " + this.mPostDialState);
    while (true)
    {
      return;
      setPostDialState(Connection.PostDialState.STARTED);
      StringBuilder localStringBuilder = new StringBuilder(paramString);
      localStringBuilder.append(this.mPostDialString.substring(this.mNextPostDialChar));
      this.mPostDialString = localStringBuilder.toString();
      this.mNextPostDialChar = 0;
      log("proceedAfterWildChar: new postDialString is " + this.mPostDialString);
      processNextPostDialChar();
    }
  }

  void processNextPostDialChar()
  {
    if (this.mPostDialState == Connection.PostDialState.CANCELLED)
      releaseWakeLock();
    while (true)
    {
      return;
      char c;
      if ((this.mPostDialString == null) || (this.mPostDialString.length() <= this.mNextPostDialChar))
      {
        setPostDialState(Connection.PostDialState.COMPLETE);
        releaseWakeLock();
        c = '\000';
      }
      do
      {
        Registrant localRegistrant = this.mOwner.mPhone.mPostDialHandler;
        if (localRegistrant == null)
          break;
        Message localMessage = localRegistrant.messageForRegistrant();
        if (localMessage == null)
          break;
        Connection.PostDialState localPostDialState = this.mPostDialState;
        AsyncResult localAsyncResult = AsyncResult.forMessage(localMessage);
        localAsyncResult.result = this;
        localAsyncResult.userObj = localPostDialState;
        localMessage.arg1 = c;
        localMessage.sendToTarget();
        break;
        setPostDialState(Connection.PostDialState.STARTED);
        String str = this.mPostDialString;
        int i = this.mNextPostDialChar;
        this.mNextPostDialChar = (i + 1);
        c = str.charAt(i);
      }
      while (processPostDialChar(c));
      this.mHandler.obtainMessage(3).sendToTarget();
      Rlog.e("CDMA", "processNextPostDialChar: c=" + c + " isn't valid!");
    }
  }

  public void separate()
    throws CallStateException
  {
    if (!this.mDisconnected)
    {
      this.mOwner.separate(this);
      return;
    }
    throw new CallStateException("disconnected");
  }

  boolean update(DriverCall paramDriverCall)
  {
    int i = 0;
    boolean bool1 = isConnectingInOrOut();
    boolean bool2;
    CdmaCall localCdmaCall;
    if (getState() == Call.State.HOLDING)
    {
      bool2 = true;
      localCdmaCall = parentFromDCState(paramDriverCall.state);
      log("parent= " + this.mParent + ", newParent= " + localCdmaCall);
      if (!equalsHandlesNulls(this.mAddress, paramDriverCall.number))
      {
        log("update: phone # changed!");
        this.mAddress = paramDriverCall.number;
        i = 1;
      }
      if (!TextUtils.isEmpty(paramDriverCall.name))
        break label318;
      if (!TextUtils.isEmpty(this.mCnapName))
      {
        i = 1;
        this.mCnapName = "";
      }
    }
    while (true)
    {
      log("--dssds----" + this.mCnapName);
      this.mCnapNamePresentation = paramDriverCall.namePresentation;
      this.mNumberPresentation = paramDriverCall.numberPresentation;
      if (localCdmaCall == this.mParent)
        break label345;
      if (this.mParent != null)
        this.mParent.detach(this);
      localCdmaCall.attach(this, paramDriverCall);
      this.mParent = localCdmaCall;
      bool4 = true;
      log("Update, wasConnectingInOrOut=" + bool1 + ", wasHolding=" + bool2 + ", isConnectingInOrOut=" + isConnectingInOrOut() + ", changed=" + bool4);
      if ((bool1) && (!isConnectingInOrOut()))
        onConnectedInOrOut();
      if ((bool4) && (!bool2) && (getState() == Call.State.HOLDING))
        onStartedHolding();
      return bool4;
      bool2 = false;
      break;
      label318: if (!paramDriverCall.name.equals(this.mCnapName))
      {
        i = 1;
        this.mCnapName = paramDriverCall.name;
      }
    }
    label345: boolean bool3 = this.mParent.update(this, paramDriverCall);
    if ((i != 0) || (bool3));
    for (boolean bool4 = true; ; bool4 = false)
      break;
  }

  public void updateParent(CdmaCall paramCdmaCall1, CdmaCall paramCdmaCall2)
  {
    if (paramCdmaCall2 != paramCdmaCall1)
    {
      if (paramCdmaCall1 != null)
        paramCdmaCall1.detach(this);
      paramCdmaCall2.attachFake(this, Call.State.ACTIVE);
      this.mParent = paramCdmaCall2;
    }
  }

  static class Injector
  {
    static String nullifyString(String paramString)
    {
      return null;
    }
  }

  class MyHandler extends Handler
  {
    MyHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      }
      while (true)
      {
        return;
        CdmaConnection.this.processNextPostDialChar();
        continue;
        CdmaConnection.this.releaseWakeLock();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaConnection
 * JD-Core Version:    0.6.2
 */