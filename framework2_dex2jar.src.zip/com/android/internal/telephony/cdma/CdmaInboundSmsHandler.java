package com.android.internal.telephony.cdma;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Message;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.telephony.SmsCbMessage;
import com.android.internal.telephony.CellBroadcastHandler;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.InboundSmsHandler;
import com.android.internal.telephony.InboundSmsTracker;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.SmsConstants.MessageClass;
import com.android.internal.telephony.SmsMessageBase;
import com.android.internal.telephony.SmsStorageMonitor;
import com.android.internal.telephony.WspTypeDecoder;
import java.util.Arrays;

public class CdmaInboundSmsHandler extends InboundSmsHandler
{
  private final boolean mCheckForDuplicatePortsInOmadmWapPush = Resources.getSystem().getBoolean(17891396);
  private byte[] mLastAcknowledgedSmsFingerprint;
  private byte[] mLastDispatchedSmsFingerprint;
  private final CdmaServiceCategoryProgramHandler mServiceCategoryProgramHandler;
  private final CdmaSMSDispatcher mSmsDispatcher;

  private CdmaInboundSmsHandler(Context paramContext, SmsStorageMonitor paramSmsStorageMonitor, PhoneBase paramPhoneBase, CdmaSMSDispatcher paramCdmaSMSDispatcher)
  {
    super("CdmaInboundSmsHandler", paramContext, paramSmsStorageMonitor, paramPhoneBase, CellBroadcastHandler.makeCellBroadcastHandler(paramContext));
    this.mSmsDispatcher = paramCdmaSMSDispatcher;
    this.mServiceCategoryProgramHandler = CdmaServiceCategoryProgramHandler.makeScpHandler(paramContext, paramPhoneBase.mCi);
    paramPhoneBase.mCi.setOnNewCdmaSms(getHandler(), 1, null);
  }

  private static boolean checkDuplicatePortOmadmWapPush(byte[] paramArrayOfByte, int paramInt)
  {
    boolean bool = false;
    int i = paramInt + 4;
    byte[] arrayOfByte = new byte[paramArrayOfByte.length - i];
    System.arraycopy(paramArrayOfByte, i, arrayOfByte, 0, arrayOfByte.length);
    WspTypeDecoder localWspTypeDecoder = new WspTypeDecoder(arrayOfByte);
    if (!localWspTypeDecoder.decodeUintvarInteger(2));
    while (true)
    {
      return bool;
      if (localWspTypeDecoder.decodeContentType(2 + localWspTypeDecoder.getDecodedDataLength()))
        bool = "application/vnd.syncml.notification".equals(localWspTypeDecoder.getValueString());
    }
  }

  private void handleVoicemailTeleservice(SmsMessage paramSmsMessage)
  {
    int i = paramSmsMessage.getNumOfVoicemails();
    log("Voicemail count=" + i);
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(this.mContext).edit();
    localEditor.putInt("vm_count_key_cdma", i);
    localEditor.apply();
    this.mPhone.setVoiceMessageWaiting(1, i);
  }

  private static boolean isInEmergencyCallMode()
  {
    return "true".equals(SystemProperties.get("ril.cdma.inecmmode", "false"));
  }

  public static CdmaInboundSmsHandler makeInboundSmsHandler(Context paramContext, SmsStorageMonitor paramSmsStorageMonitor, PhoneBase paramPhoneBase, CdmaSMSDispatcher paramCdmaSMSDispatcher)
  {
    CdmaInboundSmsHandler localCdmaInboundSmsHandler = new CdmaInboundSmsHandler(paramContext, paramSmsStorageMonitor, paramPhoneBase, paramCdmaSMSDispatcher);
    localCdmaInboundSmsHandler.start();
    return localCdmaInboundSmsHandler;
  }

  private int processCdmaWapPdu(byte[] paramArrayOfByte, int paramInt, String paramString, long paramLong)
  {
    int i = 0 + 1;
    int j = 0xFF & paramArrayOfByte[0];
    if (j != 0)
      log("Received a WAP SMS which is not WDP. Discard.");
    int m;
    int n;
    int i1;
    for (int i5 = 1; ; i5 = 1)
    {
      return i5;
      int k = i + 1;
      m = 0xFF & paramArrayOfByte[i];
      n = k + 1;
      i1 = 0xFF & paramArrayOfByte[k];
      if (i1 < m)
        break;
      loge("WDP bad segment #" + i1 + " expecting 0-" + (m - 1));
    }
    int i2 = 0;
    int i3 = 0;
    if (i1 == 0)
    {
      int i6 = n + 1;
      int i7 = (0xFF & paramArrayOfByte[n]) << 8;
      int i8 = i6 + 1;
      i2 = i7 | 0xFF & paramArrayOfByte[i6];
      int i9 = i8 + 1;
      int i10 = (0xFF & paramArrayOfByte[i8]) << 8;
      n = i9 + 1;
      i3 = i10 | 0xFF & paramArrayOfByte[i9];
      if ((!this.mCheckForDuplicatePortsInOmadmWapPush) || (!checkDuplicatePortOmadmWapPush(paramArrayOfByte, n)));
    }
    for (int i4 = n + 4; ; i4 = n)
    {
      log("Received WAP PDU. Type = " + j + ", originator = " + paramString + ", src-port = " + i2 + ", dst-port = " + i3 + ", ID = " + paramInt + ", segment# = " + i1 + '/' + m);
      byte[] arrayOfByte = new byte[paramArrayOfByte.length - i4];
      System.arraycopy(paramArrayOfByte, i4, arrayOfByte, 0, paramArrayOfByte.length - i4);
      i5 = addTrackerToRawTableAndSendMessage(new InboundSmsTracker(arrayOfByte, paramLong, i3, true, paramString, paramInt, i1, m, true));
      break;
    }
  }

  private static int resultToCause(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    case 0:
    case 2:
    default:
      i = 96;
    case -1:
    case 1:
    case 3:
    case 4:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 35;
      continue;
      i = 4;
    }
  }

  protected void acknowledgeLastIncomingSms(boolean paramBoolean, int paramInt, Message paramMessage)
  {
    if (isInEmergencyCallMode());
    while (true)
    {
      return;
      int i = resultToCause(paramInt);
      this.mPhone.mCi.acknowledgeLastIncomingCdmaSms(paramBoolean, i, paramMessage);
      if (i == 0)
        this.mLastAcknowledgedSmsFingerprint = this.mLastDispatchedSmsFingerprint;
      this.mLastDispatchedSmsFingerprint = null;
    }
  }

  protected int dispatchMessageRadioSpecific(SmsMessageBase paramSmsMessageBase)
  {
    int i = 1;
    if (isInEmergencyCallMode())
      i = -1;
    while (true)
    {
      return i;
      SmsMessage localSmsMessage = (SmsMessage)paramSmsMessageBase;
      int j;
      if (i == localSmsMessage.getMessageType())
        j = i;
      while (true)
        if (j != 0)
        {
          log("Broadcast type message");
          SmsCbMessage localSmsCbMessage = localSmsMessage.parseBroadcastSms();
          if (localSmsCbMessage != null)
          {
            this.mCellBroadcastHandler.dispatchSmsMessage(localSmsCbMessage);
            break;
            j = 0;
            continue;
          }
          loge("error trying to parse broadcast SMS");
          break;
        }
      this.mLastDispatchedSmsFingerprint = localSmsMessage.getIncomingSmsFingerprint();
      if ((this.mLastAcknowledgedSmsFingerprint == null) || (!Arrays.equals(this.mLastDispatchedSmsFingerprint, this.mLastAcknowledgedSmsFingerprint)))
      {
        localSmsMessage.parseSms();
        int k = localSmsMessage.getTeleService();
        switch (k)
        {
        default:
          loge("unsupported teleservice 0x" + Integer.toHexString(k));
          i = 4;
          break;
        case 4099:
        case 262144:
          handleVoicemailTeleservice(localSmsMessage);
          break;
        case 4098:
        case 4101:
          if (localSmsMessage.isStatusReportMessage())
            this.mSmsDispatcher.sendStatusReportMessage(localSmsMessage);
          break;
        case 4102:
          this.mServiceCategoryProgramHandler.dispatchSmsMessage(localSmsMessage);
          break;
        case 4100:
          if ((!this.mStorageMonitor.isStorageAvailable()) && (localSmsMessage.getMessageClass() != SmsConstants.MessageClass.CLASS_0))
            i = 3;
          else if (4100 == k)
            i = processCdmaWapPdu(localSmsMessage.getUserData(), localSmsMessage.mMessageRef, localSmsMessage.getOriginatingAddress(), localSmsMessage.getTimestampMillis());
          else
            i = dispatchNormalMessage(paramSmsMessageBase);
          break;
        }
      }
    }
  }

  protected boolean is3gpp2()
  {
    return true;
  }

  protected void onQuitting()
  {
    this.mPhone.mCi.unSetOnNewCdmaSms(getHandler());
    this.mCellBroadcastHandler.dispose();
    log("unregistered for 3GPP2 SMS");
    super.onQuitting();
  }

  protected void onUpdatePhoneObject(PhoneBase paramPhoneBase)
  {
    super.onUpdatePhoneObject(paramPhoneBase);
    this.mCellBroadcastHandler.updatePhoneObject(paramPhoneBase);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CdmaInboundSmsHandler
 * JD-Core Version:    0.6.2
 */