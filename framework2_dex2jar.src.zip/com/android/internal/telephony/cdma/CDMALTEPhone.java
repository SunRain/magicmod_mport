package com.android.internal.telephony.cdma;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.SQLException;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.Telephony.Carriers;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.OperatorInfo;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.DataState;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.PhoneNotifier;
import com.android.internal.telephony.PhoneProxy;
import com.android.internal.telephony.dataconnection.DcTrackerBase;
import com.android.internal.telephony.uicc.IsimRecords;
import com.android.internal.telephony.uicc.IsimUiccRecords;
import com.android.internal.telephony.uicc.SIMRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class CDMALTEPhone extends CDMAPhone
{
  private static final boolean DBG = true;
  static final String LOG_LTE_TAG = "CDMALTEPhone";
  private IsimUiccRecords mIsimUiccRecords;
  private SIMRecords mSimRecords;

  public CDMALTEPhone(Context paramContext, CommandsInterface paramCommandsInterface, PhoneNotifier paramPhoneNotifier)
  {
    super(paramContext, paramCommandsInterface, paramPhoneNotifier, false);
  }

  private void handleSetSelectNetwork(AsyncResult paramAsyncResult)
  {
    if (!(paramAsyncResult.userObj instanceof NetworkSelectMessage))
      loge("unexpected result from user object.");
    while (true)
    {
      return;
      NetworkSelectMessage localNetworkSelectMessage = (NetworkSelectMessage)paramAsyncResult.userObj;
      if (localNetworkSelectMessage.message != null)
      {
        log("sending original message to recipient");
        AsyncResult.forMessage(localNetworkSelectMessage.message, paramAsyncResult.result, paramAsyncResult.exception);
        localNetworkSelectMessage.message.sendToTarget();
      }
      SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
      localEditor.putString("network_selection_key", localNetworkSelectMessage.operatorNumeric);
      localEditor.putString("network_selection_name_key", localNetworkSelectMessage.operatorAlphaLong);
      if (!localEditor.commit())
        loge("failed to commit network selection preference");
    }
  }

  public void dispose()
  {
    synchronized (PhoneProxy.lockForRadioTechnologyChange)
    {
      super.dispose();
      return;
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("CDMALTEPhone extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }

  public void getAvailableNetworks(Message paramMessage)
  {
    this.mCi.getAvailableNetworks(paramMessage);
  }

  public PhoneConstants.DataState getDataConnectionState(String paramString)
  {
    PhoneConstants.DataState localDataState = PhoneConstants.DataState.DISCONNECTED;
    if (this.mSST == null)
      localDataState = PhoneConstants.DataState.DISCONNECTED;
    while (true)
    {
      log("getDataConnectionState apnType=" + paramString + " ret=" + localDataState);
      return localDataState;
      if (!this.mDcTracker.isApnTypeEnabled(paramString))
        localDataState = PhoneConstants.DataState.DISCONNECTED;
      else
        switch (1.$SwitchMap$com$android$internal$telephony$DctConstants$State[this.mDcTracker.getState(paramString).ordinal()])
        {
        default:
          break;
        case 1:
        case 2:
        case 3:
          localDataState = PhoneConstants.DataState.DISCONNECTED;
          break;
        case 4:
        case 5:
          if ((this.mCT.mState != PhoneConstants.State.IDLE) && (!this.mSST.isConcurrentVoiceAndDataAllowed()))
            localDataState = PhoneConstants.DataState.SUSPENDED;
          else
            localDataState = PhoneConstants.DataState.CONNECTED;
          break;
        case 6:
        case 7:
          localDataState = PhoneConstants.DataState.CONNECTING;
        }
    }
  }

  public String getDeviceSvn()
  {
    return this.mImeiSv;
  }

  public String getGroupIdLevel1()
  {
    if (this.mSimRecords != null);
    for (String str = this.mSimRecords.getGid1(); ; str = "")
      return str;
  }

  public String getImei()
  {
    return this.mImei;
  }

  public IsimRecords getIsimRecords()
  {
    return this.mIsimUiccRecords;
  }

  public String getMsisdn()
  {
    if (this.mSimRecords != null);
    for (String str = this.mSimRecords.getMsisdnNumber(); ; str = null)
      return str;
  }

  public String getSubscriberId()
  {
    if (this.mSimRecords != null);
    for (String str = this.mSimRecords.getIMSI(); ; str = "")
      return str;
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 16:
    }
    while (true)
    {
      return;
      handleSetSelectNetwork((AsyncResult)paramMessage.obj);
    }
  }

  protected void initSstIcc()
  {
    this.mSST = new CdmaLteServiceStateTracker(this);
  }

  protected void log(String paramString)
  {
    Rlog.d("CDMALTEPhone", paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("CDMALTEPhone", paramString);
  }

  protected void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e("CDMALTEPhone", paramString, paramThrowable);
  }

  protected void onUpdateIccAvailability()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      UiccCardApplication localUiccCardApplication1 = this.mUiccController.getUiccCardApplication(3);
      IsimUiccRecords localIsimUiccRecords = null;
      if (localUiccCardApplication1 != null)
        localIsimUiccRecords = (IsimUiccRecords)localUiccCardApplication1.getIccRecords();
      this.mIsimUiccRecords = localIsimUiccRecords;
      UiccCardApplication localUiccCardApplication2 = this.mUiccController.getUiccCardApplication(1);
      SIMRecords localSIMRecords = null;
      if (localUiccCardApplication2 != null)
        localSIMRecords = (SIMRecords)localUiccCardApplication2.getIccRecords();
      if (this.mSimRecords != localSIMRecords)
      {
        if (this.mSimRecords != null)
        {
          log("Removing stale SIMRecords object.");
          this.mSimRecords = null;
        }
        if (localSIMRecords != null)
        {
          log("New SIMRecords found");
          this.mSimRecords = localSIMRecords;
        }
      }
      super.onUpdateIccAvailability();
    }
  }

  public void removeReferences()
  {
    super.removeReferences();
  }

  public void requestIsimAuthentication(String paramString, Message paramMessage)
  {
    this.mCi.requestIsimAuthentication(paramString, paramMessage);
  }

  public void selectNetworkManually(OperatorInfo paramOperatorInfo, Message paramMessage)
  {
    NetworkSelectMessage localNetworkSelectMessage = new NetworkSelectMessage(null);
    localNetworkSelectMessage.message = paramMessage;
    localNetworkSelectMessage.operatorNumeric = paramOperatorInfo.getOperatorNumeric();
    localNetworkSelectMessage.operatorAlphaLong = paramOperatorInfo.getOperatorAlphaLong();
    Message localMessage = obtainMessage(16, localNetworkSelectMessage);
    this.mCi.setNetworkSelectionModeManual(paramOperatorInfo.getOperatorNumeric(), localMessage);
  }

  public boolean updateCurrentCarrierInProvider()
  {
    boolean bool;
    if (this.mSimRecords != null)
      try
      {
        Uri localUri = Uri.withAppendedPath(Telephony.Carriers.CONTENT_URI, "current");
        ContentValues localContentValues = new ContentValues();
        String str = this.mSimRecords.getOperatorNumeric();
        localContentValues.put("numeric", str);
        log("updateCurrentCarrierInProvider from UICC: numeric=" + str);
        this.mContext.getContentResolver().insert(localUri, localContentValues);
        bool = true;
        return bool;
      }
      catch (SQLException localSQLException)
      {
        loge("Can't store current operator ret false", localSQLException);
      }
    while (true)
    {
      bool = false;
      break;
      log("updateCurrentCarrierInProvider mIccRecords == null ret false");
    }
  }

  boolean updateCurrentCarrierInProvider(String paramString)
  {
    if (this.mUiccController.getUiccCardApplication(1) == null)
      log("updateCurrentCarrierInProvider APP_FAM_3GPP == null");
    for (boolean bool = super.updateCurrentCarrierInProvider(paramString); ; bool = true)
    {
      log("updateCurrentCarrierInProvider X retVal=" + bool);
      return bool;
      log("updateCurrentCarrierInProvider not updated");
    }
  }

  private static class NetworkSelectMessage
  {
    public Message message;
    public String operatorAlphaLong;
    public String operatorNumeric;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.CDMALTEPhone
 * JD-Core Version:    0.6.2
 */