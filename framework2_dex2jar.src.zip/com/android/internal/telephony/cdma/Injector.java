package com.android.internal.telephony.cdma;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Message;
import com.android.internal.telephony.Injector.PhoneBaseHook;
import com.android.internal.telephony.PhoneBase;

class Injector
{
  static class CDMAPhoneHook
  {
    public static String after_getDeviceId(CDMAPhone paramCDMAPhone, String paramString)
    {
      return Injector.PhoneBaseHook.checkEmptyDeviceId(paramCDMAPhone, paramString);
    }

    public static void before_acceptCall(CDMAPhone paramCDMAPhone)
    {
      paramCDMAPhone.removeMessages(15);
    }

    public static void checkAndNotifyDeviceId(CDMAPhone paramCDMAPhone, Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 21:
      }
      while (true)
      {
        return;
        Injector.PhoneBaseHook.checkAndNotifyDeviceId(paramCDMAPhone.getDeviceId(), paramCDMAPhone, paramCDMAPhone.mCi, paramMessage.arg1);
      }
    }
  }

  static class CdmaServiceStateTrackerHook
  {
    private static BroadcastReceiver sLocalReceiver;

    public static void after_CdmaServiceStateTracker(CdmaServiceStateTracker paramCdmaServiceStateTracker, CDMAPhone paramCDMAPhone)
    {
      IntentFilter localIntentFilter = new IntentFilter("android.intent.action.LOCALE_CHANGED");
      BroadcastReceiver local1 = new BroadcastReceiver()
      {
        public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
        {
          if (!this.val$tracker.mPhone.mIsTheCurrentActivePhone);
          while (true)
          {
            return;
            if ("android.intent.action.LOCALE_CHANGED".equals(paramAnonymousIntent.getAction()))
              this.val$tracker.updateSpnDisplay();
          }
        }
      };
      sLocalReceiver = local1;
      paramCDMAPhone.getContext().registerReceiver(local1, localIntentFilter);
    }

    public static void after_dispose(CdmaServiceStateTracker paramCdmaServiceStateTracker)
    {
      if (sLocalReceiver != null)
        paramCdmaServiceStateTracker.mPhone.getContext().unregisterReceiver(sLocalReceiver);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cdma.Injector
 * JD-Core Version:    0.6.2
 */