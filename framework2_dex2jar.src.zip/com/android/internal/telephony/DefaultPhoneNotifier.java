package com.android.internal.telephony;

import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.CellInfo;
import android.telephony.CellLocation;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import java.util.List;

public class DefaultPhoneNotifier
  implements PhoneNotifier
{
  private ITelephonyRegistry mRegistry = ITelephonyRegistry.Stub.asInterface(ServiceManager.getService("telephony.registry"));

  public static int convertCallState(PhoneConstants.State paramState)
  {
    int i;
    switch (1.$SwitchMap$com$android$internal$telephony$PhoneConstants$State[paramState.ordinal()])
    {
    default:
      i = 0;
    case 1:
    case 2:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 2;
    }
  }

  public static PhoneConstants.State convertCallState(int paramInt)
  {
    PhoneConstants.State localState;
    switch (paramInt)
    {
    default:
      localState = PhoneConstants.State.IDLE;
    case 1:
    case 2:
    }
    while (true)
    {
      return localState;
      localState = PhoneConstants.State.RINGING;
      continue;
      localState = PhoneConstants.State.OFFHOOK;
    }
  }

  public static int convertDataActivityState(Phone.DataActivityState paramDataActivityState)
  {
    int i;
    switch (1.$SwitchMap$com$android$internal$telephony$Phone$DataActivityState[paramDataActivityState.ordinal()])
    {
    default:
      i = 0;
    case 1:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 3;
      continue;
      i = 4;
    }
  }

  public static Phone.DataActivityState convertDataActivityState(int paramInt)
  {
    Phone.DataActivityState localDataActivityState;
    switch (paramInt)
    {
    default:
      localDataActivityState = Phone.DataActivityState.NONE;
    case 1:
    case 2:
    case 3:
    case 4:
    }
    while (true)
    {
      return localDataActivityState;
      localDataActivityState = Phone.DataActivityState.DATAIN;
      continue;
      localDataActivityState = Phone.DataActivityState.DATAOUT;
      continue;
      localDataActivityState = Phone.DataActivityState.DATAINANDOUT;
      continue;
      localDataActivityState = Phone.DataActivityState.DORMANT;
    }
  }

  public static int convertDataState(PhoneConstants.DataState paramDataState)
  {
    int i;
    switch (1.$SwitchMap$com$android$internal$telephony$PhoneConstants$DataState[paramDataState.ordinal()])
    {
    default:
      i = 0;
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return i;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 3;
    }
  }

  public static PhoneConstants.DataState convertDataState(int paramInt)
  {
    PhoneConstants.DataState localDataState;
    switch (paramInt)
    {
    default:
      localDataState = PhoneConstants.DataState.DISCONNECTED;
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return localDataState;
      localDataState = PhoneConstants.DataState.CONNECTING;
      continue;
      localDataState = PhoneConstants.DataState.CONNECTED;
      continue;
      localDataState = PhoneConstants.DataState.SUSPENDED;
    }
  }

  private void doNotifyDataConnection(Phone paramPhone, String paramString1, String paramString2, PhoneConstants.DataState paramDataState)
  {
    TelephonyManager localTelephonyManager = TelephonyManager.getDefault();
    LinkProperties localLinkProperties = null;
    LinkCapabilities localLinkCapabilities = null;
    boolean bool1 = false;
    if (paramDataState == PhoneConstants.DataState.CONNECTED)
    {
      localLinkProperties = paramPhone.getLinkProperties(paramString2);
      localLinkCapabilities = paramPhone.getLinkCapabilities(paramString2);
    }
    ServiceState localServiceState = paramPhone.getServiceState();
    if (localServiceState != null)
      bool1 = localServiceState.getRoaming();
    try
    {
      ITelephonyRegistry localITelephonyRegistry = this.mRegistry;
      int i = convertDataState(paramDataState);
      boolean bool2 = paramPhone.isDataConnectivityPossible(paramString2);
      String str = paramPhone.getActiveApnHost(paramString2);
      if (localTelephonyManager != null);
      for (int j = localTelephonyManager.getNetworkType(); ; j = 0)
      {
        localITelephonyRegistry.notifyDataConnection(i, bool2, paramString1, str, paramString2, localLinkProperties, localLinkCapabilities, j, bool1);
        label126: return;
      }
    }
    catch (RemoteException localRemoteException)
    {
      break label126;
    }
  }

  public void notifyCallForwardingChanged(Phone paramPhone)
  {
    try
    {
      this.mRegistry.notifyCallForwardingChanged(paramPhone.getCallForwardingIndicator());
      label15: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label15;
    }
  }

  public void notifyCellInfo(Phone paramPhone, List<CellInfo> paramList)
  {
    try
    {
      this.mRegistry.notifyCellInfo(paramList);
      label10: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label10;
    }
  }

  public void notifyCellLocation(Phone paramPhone)
  {
    Bundle localBundle = new Bundle();
    paramPhone.getCellLocation().fillInNotifierBundle(localBundle);
    try
    {
      this.mRegistry.notifyCellLocation(localBundle);
      label28: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label28;
    }
  }

  public void notifyDataActivity(Phone paramPhone)
  {
    try
    {
      this.mRegistry.notifyDataActivity(convertDataActivityState(paramPhone.getDataActivityState()));
      label18: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label18;
    }
  }

  public void notifyDataConnection(Phone paramPhone, String paramString1, String paramString2, PhoneConstants.DataState paramDataState)
  {
    doNotifyDataConnection(paramPhone, paramString1, paramString2, paramDataState);
  }

  public void notifyDataConnectionFailed(Phone paramPhone, String paramString1, String paramString2)
  {
    try
    {
      this.mRegistry.notifyDataConnectionFailed(paramString1, paramString2);
      label11: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label11;
    }
  }

  public void notifyMessageWaitingChanged(Phone paramPhone)
  {
    try
    {
      this.mRegistry.notifyMessageWaitingChanged(paramPhone.getMessageWaitingIndicator());
      label15: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label15;
    }
  }

  public void notifyOtaspChanged(Phone paramPhone, int paramInt)
  {
    try
    {
      this.mRegistry.notifyOtaspChanged(paramInt);
      label10: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label10;
    }
  }

  public void notifyPhoneState(Phone paramPhone)
  {
    if (Injector.DefaultPhoneNotifierHook.before_notifyPhoneState(paramPhone));
    while (true)
    {
      return;
      Call localCall = paramPhone.getRingingCall();
      String str = "";
      if ((localCall != null) && (localCall.getEarliestConnection() != null))
        str = localCall.getEarliestConnection().getAddress();
      try
      {
        this.mRegistry.notifyCallState(convertCallState(paramPhone.getState()), str);
      }
      catch (RemoteException localRemoteException)
      {
      }
    }
  }

  public void notifyServiceState(Phone paramPhone)
  {
    ServiceState localServiceState = paramPhone.getServiceState();
    if (localServiceState == null)
    {
      localServiceState = new ServiceState();
      localServiceState.setStateOutOfService();
    }
    try
    {
      this.mRegistry.notifyServiceState(localServiceState);
      label33: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label33;
    }
  }

  public void notifySignalStrength(Phone paramPhone)
  {
    try
    {
      this.mRegistry.notifySignalStrength(paramPhone.getSignalStrength());
      label15: return;
    }
    catch (RemoteException localRemoteException)
    {
      break label15;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.DefaultPhoneNotifier
 * JD-Core Version:    0.6.2
 */