package com.android.internal.telephony;

public class DctConstants
{
  public static final int APN_CBS_ID = 7;
  public static final int APN_DEFAULT_ID = 0;
  public static final int APN_DUN_ID = 3;
  public static final int APN_FOTA_ID = 6;
  public static final int APN_HIPRI_ID = 4;
  public static final int APN_IA_ID = 8;
  public static final int APN_IMS_ID = 5;
  public static final int APN_INVALID_ID = -1;
  public static final int APN_MMS_ID = 1;
  public static final int APN_NUM_TYPES = 9;
  public static final int APN_SUPL_ID = 2;
  public static final String APN_TYPE_KEY = "apnType";
  public static final int BASE = 270336;
  public static final int CMD_ENABLE_MOBILE_PROVISIONING = 270373;
  public static final int CMD_IS_PROVISIONING_APN = 270374;
  public static final int CMD_SET_DEPENDENCY_MET = 270367;
  public static final int CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA = 270372;
  public static final int CMD_SET_POLICY_DATA_ENABLE = 270368;
  public static final int CMD_SET_USER_DATA_ENABLE = 270366;
  public static final int DISABLED = 0;
  public static final int ENABLED = 1;
  public static final int EVENT_APN_CHANGED = 270355;
  public static final int EVENT_CDMA_DATA_DETACHED = 270356;
  public static final int EVENT_CDMA_OTA_PROVISION = 270361;
  public static final int EVENT_CDMA_SUBSCRIPTION_SOURCE_CHANGED = 270357;
  public static final int EVENT_CLEAN_UP_ALL_CONNECTIONS = 270365;
  public static final int EVENT_CLEAN_UP_CONNECTION = 270360;
  public static final int EVENT_DATA_CONNECTION_ATTACHED = 270352;
  public static final int EVENT_DATA_CONNECTION_DETACHED = 270345;
  public static final int EVENT_DATA_SETUP_COMPLETE = 270336;
  public static final int EVENT_DATA_SETUP_COMPLETE_ERROR = 270371;
  public static final int EVENT_DATA_STALL_ALARM = 270353;
  public static final int EVENT_DATA_STATE_CHANGED = 270340;
  public static final int EVENT_DISCONNECT_DC_RETRYING = 270370;
  public static final int EVENT_DISCONNECT_DONE = 270351;
  public static final int EVENT_DO_RECOVERY = 270354;
  public static final int EVENT_ENABLE_NEW_APN = 270349;
  public static final int EVENT_ICC_CHANGED = 270369;
  public static final int EVENT_LINK_STATE_CHANGED = 270346;
  public static final int EVENT_POLL_PDP = 270341;
  public static final int EVENT_PROVISIONING_APN_ALARM = 270375;
  public static final int EVENT_PS_RESTRICT_DISABLED = 270359;
  public static final int EVENT_PS_RESTRICT_ENABLED = 270358;
  public static final int EVENT_RADIO_AVAILABLE = 270337;
  public static final int EVENT_RADIO_OFF_OR_NOT_AVAILABLE = 270342;
  public static final int EVENT_RECORDS_LOADED = 270338;
  public static final int EVENT_RESET_DONE = 270364;
  public static final int EVENT_RESTART_RADIO = 270362;
  public static final int EVENT_RESTORE_DEFAULT_APN = 270350;
  public static final int EVENT_ROAMING_OFF = 270348;
  public static final int EVENT_ROAMING_ON = 270347;
  public static final int EVENT_SET_INTERNAL_DATA_ENABLE = 270363;
  public static final int EVENT_TRY_SETUP_DATA = 270339;
  public static final int EVENT_VOICE_CALL_ENDED = 270344;
  public static final int EVENT_VOICE_CALL_STARTED = 270343;
  public static final String PROVISIONING_URL_KEY = "provisioningUrl";

  public static enum Activity
  {
    static
    {
      DATAIN = new Activity("DATAIN", 1);
      DATAOUT = new Activity("DATAOUT", 2);
      DATAINANDOUT = new Activity("DATAINANDOUT", 3);
      DORMANT = new Activity("DORMANT", 4);
      Activity[] arrayOfActivity = new Activity[5];
      arrayOfActivity[0] = NONE;
      arrayOfActivity[1] = DATAIN;
      arrayOfActivity[2] = DATAOUT;
      arrayOfActivity[3] = DATAINANDOUT;
      arrayOfActivity[4] = DORMANT;
    }
  }

  public static enum State
  {
    static
    {
      CONNECTING = new State("CONNECTING", 1);
      SCANNING = new State("SCANNING", 2);
      CONNECTED = new State("CONNECTED", 3);
      DISCONNECTING = new State("DISCONNECTING", 4);
      FAILED = new State("FAILED", 5);
      RETRYING = new State("RETRYING", 6);
      State[] arrayOfState = new State[7];
      arrayOfState[0] = IDLE;
      arrayOfState[1] = CONNECTING;
      arrayOfState[2] = SCANNING;
      arrayOfState[3] = CONNECTED;
      arrayOfState[4] = DISCONNECTING;
      arrayOfState[5] = FAILED;
      arrayOfState[6] = RETRYING;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.DctConstants
 * JD-Core Version:    0.6.2
 */