package com.android.internal.telephony.cat;

public class CatResponseMessage
{
  int mAdditionalInfo = 0;
  CommandDetails mCmdDet = null;
  boolean mIncludeAdditionalInfo = false;
  ResultCode mResCode = ResultCode.OK;
  boolean mUsersConfirm = false;
  String mUsersInput = null;
  int mUsersMenuSelection = 0;
  boolean mUsersYesNoSelection = false;

  public CatResponseMessage(CatCmdMessage paramCatCmdMessage)
  {
    this.mCmdDet = paramCatCmdMessage.mCmdDet;
  }

  CommandDetails getCmdDetails()
  {
    return this.mCmdDet;
  }

  public void setAdditionalInfo(int paramInt)
  {
    this.mIncludeAdditionalInfo = true;
    this.mAdditionalInfo = paramInt;
  }

  public void setConfirmation(boolean paramBoolean)
  {
    this.mUsersConfirm = paramBoolean;
  }

  public void setInput(String paramString)
  {
    this.mUsersInput = paramString;
  }

  public void setMenuSelection(int paramInt)
  {
    this.mUsersMenuSelection = paramInt;
  }

  public void setResultCode(ResultCode paramResultCode)
  {
    this.mResCode = paramResultCode;
  }

  public void setYesNo(boolean paramBoolean)
  {
    this.mUsersYesNoSelection = paramBoolean;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.CatResponseMessage
 * JD-Core Version:    0.6.2
 */