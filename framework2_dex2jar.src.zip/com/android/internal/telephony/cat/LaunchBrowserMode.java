package com.android.internal.telephony.cat;

public enum LaunchBrowserMode
{
  static
  {
    LAUNCH_NEW_BROWSER = new LaunchBrowserMode("LAUNCH_NEW_BROWSER", 2);
    LaunchBrowserMode[] arrayOfLaunchBrowserMode = new LaunchBrowserMode[3];
    arrayOfLaunchBrowserMode[0] = LAUNCH_IF_NOT_ALREADY_LAUNCHED;
    arrayOfLaunchBrowserMode[1] = USE_EXISTING_BROWSER;
    arrayOfLaunchBrowserMode[2] = LAUNCH_NEW_BROWSER;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.LaunchBrowserMode
 * JD-Core Version:    0.6.2
 */