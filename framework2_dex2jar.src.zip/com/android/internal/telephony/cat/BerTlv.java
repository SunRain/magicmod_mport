package com.android.internal.telephony.cat;

import java.util.List;

class BerTlv
{
  public static final int BER_EVENT_DOWNLOAD_TAG = 214;
  public static final int BER_MENU_SELECTION_TAG = 211;
  public static final int BER_PROACTIVE_COMMAND_TAG = 208;
  public static final int BER_UNKNOWN_TAG;
  private List<ComprehensionTlv> mCompTlvs = null;
  private boolean mLengthValid = true;
  private int mTag = 0;

  private BerTlv(int paramInt, List<ComprehensionTlv> paramList, boolean paramBoolean)
  {
    this.mTag = paramInt;
    this.mCompTlvs = paramList;
    this.mLengthValid = paramBoolean;
  }

  // ERROR //
  public static BerTlv decode(byte[] paramArrayOfByte)
    throws ResultException
  {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: istore_1
    //   3: iconst_0
    //   4: istore_2
    //   5: iconst_1
    //   6: istore_3
    //   7: iconst_0
    //   8: iconst_1
    //   9: iadd
    //   10: istore 4
    //   12: aload_0
    //   13: iconst_0
    //   14: baload
    //   15: istore 9
    //   17: iload 9
    //   19: sipush 255
    //   22: iand
    //   23: istore 10
    //   25: iload 10
    //   27: sipush 208
    //   30: if_icmpne +289 -> 319
    //   33: iload 4
    //   35: iconst_1
    //   36: iadd
    //   37: istore 8
    //   39: aload_0
    //   40: iload 4
    //   42: baload
    //   43: istore 17
    //   45: iload 17
    //   47: sipush 255
    //   50: iand
    //   51: istore 18
    //   53: iload 18
    //   55: sipush 128
    //   58: if_icmpge +63 -> 121
    //   61: iload 18
    //   63: istore_2
    //   64: iload_1
    //   65: iload 8
    //   67: isub
    //   68: iload_2
    //   69: if_icmpge +299 -> 368
    //   72: new 33	com/android/internal/telephony/cat/ResultException
    //   75: dup
    //   76: getstatic 41	com/android/internal/telephony/cat/ResultCode:CMD_DATA_NOT_UNDERSTOOD	Lcom/android/internal/telephony/cat/ResultCode;
    //   79: new 43	java/lang/StringBuilder
    //   82: dup
    //   83: invokespecial 44	java/lang/StringBuilder:<init>	()V
    //   86: ldc 46
    //   88: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: iload_1
    //   92: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   95: ldc 55
    //   97: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: iload 8
    //   102: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   105: ldc 57
    //   107: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: iload_2
    //   111: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   114: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   117: invokespecial 64	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;Ljava/lang/String;)V
    //   120: athrow
    //   121: iload 18
    //   123: sipush 129
    //   126: if_icmpne +135 -> 261
    //   129: iload 8
    //   131: iconst_1
    //   132: iadd
    //   133: istore 4
    //   135: sipush 255
    //   138: aload_0
    //   139: iload 8
    //   141: baload
    //   142: iand
    //   143: istore 19
    //   145: iload 19
    //   147: sipush 128
    //   150: if_icmpge +101 -> 251
    //   153: new 33	com/android/internal/telephony/cat/ResultException
    //   156: dup
    //   157: getstatic 41	com/android/internal/telephony/cat/ResultCode:CMD_DATA_NOT_UNDERSTOOD	Lcom/android/internal/telephony/cat/ResultCode;
    //   160: new 43	java/lang/StringBuilder
    //   163: dup
    //   164: invokespecial 44	java/lang/StringBuilder:<init>	()V
    //   167: ldc 66
    //   169: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: iconst_0
    //   173: invokestatic 72	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   176: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: ldc 55
    //   181: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: iload 4
    //   186: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   189: ldc 74
    //   191: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: iload_1
    //   195: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   198: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   201: invokespecial 64	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;Ljava/lang/String;)V
    //   204: athrow
    //   205: astore 7
    //   207: iload 4
    //   209: istore 8
    //   211: new 33	com/android/internal/telephony/cat/ResultException
    //   214: dup
    //   215: getstatic 77	com/android/internal/telephony/cat/ResultCode:REQUIRED_VALUES_MISSING	Lcom/android/internal/telephony/cat/ResultCode;
    //   218: new 43	java/lang/StringBuilder
    //   221: dup
    //   222: invokespecial 44	java/lang/StringBuilder:<init>	()V
    //   225: ldc 79
    //   227: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   230: iload 8
    //   232: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   235: ldc 74
    //   237: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: iload_1
    //   241: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   244: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   247: invokespecial 64	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;Ljava/lang/String;)V
    //   250: athrow
    //   251: iload 19
    //   253: istore_2
    //   254: iload 4
    //   256: istore 8
    //   258: goto -194 -> 64
    //   261: new 33	com/android/internal/telephony/cat/ResultException
    //   264: dup
    //   265: getstatic 41	com/android/internal/telephony/cat/ResultCode:CMD_DATA_NOT_UNDERSTOOD	Lcom/android/internal/telephony/cat/ResultCode;
    //   268: new 43	java/lang/StringBuilder
    //   271: dup
    //   272: invokespecial 44	java/lang/StringBuilder:<init>	()V
    //   275: ldc 81
    //   277: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: iload 18
    //   282: invokestatic 72	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   285: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: ldc 55
    //   290: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: iload 8
    //   295: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   298: ldc 74
    //   300: invokevirtual 50	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: iload_1
    //   304: invokevirtual 53	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   307: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   310: invokespecial 64	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;Ljava/lang/String;)V
    //   313: athrow
    //   314: astore 16
    //   316: goto -105 -> 211
    //   319: getstatic 87	com/android/internal/telephony/cat/ComprehensionTlvTag:COMMAND_DETAILS	Lcom/android/internal/telephony/cat/ComprehensionTlvTag;
    //   322: invokevirtual 91	com/android/internal/telephony/cat/ComprehensionTlvTag:value	()I
    //   325: istore 11
    //   327: iload 11
    //   329: iload 10
    //   331: sipush -129
    //   334: iand
    //   335: if_icmpne +167 -> 502
    //   338: iconst_0
    //   339: istore 10
    //   341: iconst_0
    //   342: istore 8
    //   344: goto -280 -> 64
    //   347: astore 5
    //   349: iload 4
    //   351: pop
    //   352: new 33	com/android/internal/telephony/cat/ResultException
    //   355: dup
    //   356: getstatic 41	com/android/internal/telephony/cat/ResultCode:CMD_DATA_NOT_UNDERSTOOD	Lcom/android/internal/telephony/cat/ResultCode;
    //   359: aload 5
    //   361: invokevirtual 94	com/android/internal/telephony/cat/ResultException:explanation	()Ljava/lang/String;
    //   364: invokespecial 64	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;Ljava/lang/String;)V
    //   367: athrow
    //   368: aload_0
    //   369: iload 8
    //   371: invokestatic 100	com/android/internal/telephony/cat/ComprehensionTlv:decodeMany	([BI)Ljava/util/List;
    //   374: astore 12
    //   376: iload 10
    //   378: sipush 208
    //   381: if_icmpne +103 -> 484
    //   384: iconst_0
    //   385: istore 13
    //   387: aload 12
    //   389: invokeinterface 106 1 0
    //   394: astore 14
    //   396: aload 14
    //   398: invokeinterface 112 1 0
    //   403: ifeq +73 -> 476
    //   406: aload 14
    //   408: invokeinterface 116 1 0
    //   413: checkcast 96	com/android/internal/telephony/cat/ComprehensionTlv
    //   416: invokevirtual 119	com/android/internal/telephony/cat/ComprehensionTlv:getLength	()I
    //   419: istore 15
    //   421: iload 15
    //   423: sipush 128
    //   426: if_icmplt +23 -> 449
    //   429: iload 15
    //   431: sipush 255
    //   434: if_icmpgt +15 -> 449
    //   437: iload 13
    //   439: iload 15
    //   441: iconst_3
    //   442: iadd
    //   443: iadd
    //   444: istore 13
    //   446: goto -50 -> 396
    //   449: iload 15
    //   451: iflt +23 -> 474
    //   454: iload 15
    //   456: sipush 128
    //   459: if_icmpge +15 -> 474
    //   462: iload 13
    //   464: iload 15
    //   466: iconst_2
    //   467: iadd
    //   468: iadd
    //   469: istore 13
    //   471: goto -75 -> 396
    //   474: iconst_0
    //   475: istore_3
    //   476: iload_2
    //   477: iload 13
    //   479: if_icmpeq +5 -> 484
    //   482: iconst_0
    //   483: istore_3
    //   484: new 2	com/android/internal/telephony/cat/BerTlv
    //   487: dup
    //   488: iload 10
    //   490: aload 12
    //   492: iload_3
    //   493: invokespecial 121	com/android/internal/telephony/cat/BerTlv:<init>	(ILjava/util/List;Z)V
    //   496: areturn
    //   497: astore 5
    //   499: goto -147 -> 352
    //   502: iload 4
    //   504: istore 8
    //   506: goto -442 -> 64
    //
    // Exception table:
    //   from	to	target	type
    //   12	17	205	java/lang/IndexOutOfBoundsException
    //   135	205	205	java/lang/IndexOutOfBoundsException
    //   319	327	205	java/lang/IndexOutOfBoundsException
    //   39	45	314	java/lang/IndexOutOfBoundsException
    //   261	314	314	java/lang/IndexOutOfBoundsException
    //   12	17	347	com/android/internal/telephony/cat/ResultException
    //   135	205	347	com/android/internal/telephony/cat/ResultException
    //   319	327	347	com/android/internal/telephony/cat/ResultException
    //   39	45	497	com/android/internal/telephony/cat/ResultException
    //   261	314	497	com/android/internal/telephony/cat/ResultException
  }

  public List<ComprehensionTlv> getComprehensionTlvs()
  {
    return this.mCompTlvs;
  }

  public int getTag()
  {
    return this.mTag;
  }

  public boolean isLengthValid()
  {
    return this.mLengthValid;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.BerTlv
 * JD-Core Version:    0.6.2
 */