package com.android.internal.telephony.cat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.SystemProperties;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.IccUtils;
import com.android.internal.telephony.uicc.UiccCard;
import com.android.internal.telephony.uicc.UiccCardApplication;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Locale;

public class CatService extends Handler
  implements AppInterface
{
  private static final boolean DBG = false;
  private static final int DEV_ID_KEYPAD = 1;
  private static final int DEV_ID_NETWORK = 131;
  private static final int DEV_ID_TERMINAL = 130;
  private static final int DEV_ID_UICC = 129;
  static final int MSG_ID_CALL_SETUP = 4;
  static final int MSG_ID_EVENT_NOTIFY = 3;
  private static final int MSG_ID_ICC_RECORDS_LOADED = 20;
  static final int MSG_ID_PROACTIVE_COMMAND = 2;
  static final int MSG_ID_REFRESH = 5;
  static final int MSG_ID_RESPONSE = 6;
  static final int MSG_ID_RIL_MSG_DECODED = 10;
  static final int MSG_ID_SESSION_END = 1;
  static final int MSG_ID_SIM_READY = 7;
  static final String STK_DEFAULT = "Default Message";
  private static IccRecords mIccRecords;
  private static UiccCardApplication mUiccApplication;
  private static CatService sInstance;
  private static final Object sInstanceLock = new Object();
  private CommandsInterface mCmdIf;
  private Context mContext;
  private CatCmdMessage mCurrntCmd = null;
  private CatCmdMessage mMenuCmd = null;
  private RilMessageDecoder mMsgDecoder = null;
  private boolean mStkAppInstalled = false;

  private CatService(CommandsInterface paramCommandsInterface, UiccCardApplication paramUiccCardApplication, IccRecords paramIccRecords, Context paramContext, IccFileHandler paramIccFileHandler, UiccCard paramUiccCard)
  {
    if ((paramCommandsInterface == null) || (paramUiccCardApplication == null) || (paramIccRecords == null) || (paramContext == null) || (paramIccFileHandler == null) || (paramUiccCard == null))
      throw new NullPointerException("Service: Input parameters must not be null");
    this.mCmdIf = paramCommandsInterface;
    this.mContext = paramContext;
    this.mMsgDecoder = RilMessageDecoder.getInstance(this, paramIccFileHandler);
    this.mCmdIf.setOnCatSessionEnd(this, 1, null);
    this.mCmdIf.setOnCatProactiveCmd(this, 2, null);
    this.mCmdIf.setOnCatEvent(this, 3, null);
    this.mCmdIf.setOnCatCallSetUp(this, 4, null);
    mIccRecords = paramIccRecords;
    mUiccApplication = paramUiccCardApplication;
    mUiccApplication.registerForReady(this, 7, null);
    mIccRecords.registerForRecordsLoaded(this, 20, null);
    this.mStkAppInstalled = isStkAppInstalled();
    CatLog.d(this, "Running CAT service. STK app installed:" + this.mStkAppInstalled);
  }

  private void encodeOptionalTags(CommandDetails paramCommandDetails, ResultCode paramResultCode, Input paramInput, ByteArrayOutputStream paramByteArrayOutputStream)
  {
    AppInterface.CommandType localCommandType = AppInterface.CommandType.fromInt(paramCommandDetails.typeOfCommand);
    if (localCommandType != null)
      switch (1.$SwitchMap$com$android$internal$telephony$cat$AppInterface$CommandType[localCommandType.ordinal()])
      {
      default:
        CatLog.d(this, "encodeOptionalTags() Unsupported Cmd details=" + paramCommandDetails);
      case 9:
      case 5:
      }
    while (true)
    {
      return;
      if ((paramResultCode.value() == ResultCode.NO_RESPONSE_FROM_USER.value()) && (paramInput != null) && (paramInput.duration != null))
      {
        getInKeyResponse(paramByteArrayOutputStream, paramInput);
        continue;
        if ((paramCommandDetails.commandQualifier == 4) && (paramResultCode.value() == ResultCode.OK.value()))
        {
          getPliResponse(paramByteArrayOutputStream);
          continue;
          CatLog.d(this, "encodeOptionalTags() bad Cmd details=" + paramCommandDetails);
        }
      }
    }
  }

  private void getInKeyResponse(ByteArrayOutputStream paramByteArrayOutputStream, Input paramInput)
  {
    paramByteArrayOutputStream.write(ComprehensionTlvTag.DURATION.value());
    paramByteArrayOutputStream.write(2);
    paramByteArrayOutputStream.write(Duration.TimeUnit.SECOND.value());
    paramByteArrayOutputStream.write(paramInput.duration.timeInterval);
  }

  public static AppInterface getInstance()
  {
    return getInstance(null, null, null);
  }

  // ERROR //
  public static CatService getInstance(CommandsInterface paramCommandsInterface, Context paramContext, UiccCard paramUiccCard)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore 4
    //   5: aconst_null
    //   6: astore 5
    //   8: aconst_null
    //   9: astore 6
    //   11: aload_2
    //   12: ifnull +29 -> 41
    //   15: aload_2
    //   16: iconst_0
    //   17: invokevirtual 245	com/android/internal/telephony/uicc/UiccCard:getApplicationIndex	(I)Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   20: astore 4
    //   22: aload 4
    //   24: ifnull +17 -> 41
    //   27: aload 4
    //   29: invokevirtual 249	com/android/internal/telephony/uicc/UiccCardApplication:getIccFileHandler	()Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   32: astore 5
    //   34: aload 4
    //   36: invokevirtual 253	com/android/internal/telephony/uicc/UiccCardApplication:getIccRecords	()Lcom/android/internal/telephony/uicc/IccRecords;
    //   39: astore 6
    //   41: getstatic 66	com/android/internal/telephony/cat/CatService:sInstanceLock	Ljava/lang/Object;
    //   44: astore 7
    //   46: aload 7
    //   48: monitorenter
    //   49: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   52: ifnonnull +95 -> 147
    //   55: aload_0
    //   56: ifnull +26 -> 82
    //   59: aload 4
    //   61: ifnull +21 -> 82
    //   64: aload 6
    //   66: ifnull +16 -> 82
    //   69: aload_1
    //   70: ifnull +12 -> 82
    //   73: aload 5
    //   75: ifnull +7 -> 82
    //   78: aload_2
    //   79: ifnonnull +9 -> 88
    //   82: aload 7
    //   84: monitorexit
    //   85: goto +172 -> 257
    //   88: new 257	android/os/HandlerThread
    //   91: dup
    //   92: ldc_w 259
    //   95: invokespecial 260	android/os/HandlerThread:<init>	(Ljava/lang/String;)V
    //   98: invokevirtual 263	android/os/HandlerThread:start	()V
    //   101: new 2	com/android/internal/telephony/cat/CatService
    //   104: dup
    //   105: aload_0
    //   106: aload 4
    //   108: aload 6
    //   110: aload_1
    //   111: aload 5
    //   113: aload_2
    //   114: invokespecial 265	com/android/internal/telephony/cat/CatService:<init>	(Lcom/android/internal/telephony/CommandsInterface;Lcom/android/internal/telephony/uicc/UiccCardApplication;Lcom/android/internal/telephony/uicc/IccRecords;Landroid/content/Context;Lcom/android/internal/telephony/uicc/IccFileHandler;Lcom/android/internal/telephony/uicc/UiccCard;)V
    //   117: putstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   120: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   123: ldc_w 267
    //   126: invokestatic 148	com/android/internal/telephony/cat/CatLog:d	(Ljava/lang/Object;Ljava/lang/String;)V
    //   129: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   132: astore_3
    //   133: aload 7
    //   135: monitorexit
    //   136: goto +121 -> 257
    //   139: astore 8
    //   141: aload 7
    //   143: monitorexit
    //   144: aload 8
    //   146: athrow
    //   147: aload 6
    //   149: ifnull +96 -> 245
    //   152: getstatic 110	com/android/internal/telephony/cat/CatService:mIccRecords	Lcom/android/internal/telephony/uicc/IccRecords;
    //   155: aload 6
    //   157: if_acmpeq +88 -> 245
    //   160: getstatic 110	com/android/internal/telephony/cat/CatService:mIccRecords	Lcom/android/internal/telephony/uicc/IccRecords;
    //   163: ifnull +12 -> 175
    //   166: getstatic 110	com/android/internal/telephony/cat/CatService:mIccRecords	Lcom/android/internal/telephony/uicc/IccRecords;
    //   169: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   172: invokevirtual 271	com/android/internal/telephony/uicc/IccRecords:unregisterForRecordsLoaded	(Landroid/os/Handler;)V
    //   175: getstatic 112	com/android/internal/telephony/cat/CatService:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   178: ifnull +12 -> 190
    //   181: getstatic 112	com/android/internal/telephony/cat/CatService:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   184: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   187: invokevirtual 274	com/android/internal/telephony/uicc/UiccCardApplication:unregisterForReady	(Landroid/os/Handler;)V
    //   190: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   193: ldc_w 276
    //   196: invokestatic 148	com/android/internal/telephony/cat/CatLog:d	(Ljava/lang/Object;Ljava/lang/String;)V
    //   199: aload 6
    //   201: putstatic 110	com/android/internal/telephony/cat/CatService:mIccRecords	Lcom/android/internal/telephony/uicc/IccRecords;
    //   204: aload 4
    //   206: putstatic 112	com/android/internal/telephony/cat/CatService:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   209: getstatic 110	com/android/internal/telephony/cat/CatService:mIccRecords	Lcom/android/internal/telephony/uicc/IccRecords;
    //   212: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   215: bipush 20
    //   217: aconst_null
    //   218: invokevirtual 122	com/android/internal/telephony/uicc/IccRecords:registerForRecordsLoaded	(Landroid/os/Handler;ILjava/lang/Object;)V
    //   221: getstatic 112	com/android/internal/telephony/cat/CatService:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   224: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   227: bipush 7
    //   229: aconst_null
    //   230: invokevirtual 117	com/android/internal/telephony/uicc/UiccCardApplication:registerForReady	(Landroid/os/Handler;ILjava/lang/Object;)V
    //   233: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   236: ldc_w 278
    //   239: invokestatic 148	com/android/internal/telephony/cat/CatLog:d	(Ljava/lang/Object;Ljava/lang/String;)V
    //   242: goto -113 -> 129
    //   245: getstatic 255	com/android/internal/telephony/cat/CatService:sInstance	Lcom/android/internal/telephony/cat/CatService;
    //   248: ldc_w 280
    //   251: invokestatic 148	com/android/internal/telephony/cat/CatLog:d	(Ljava/lang/Object;Ljava/lang/String;)V
    //   254: goto -125 -> 129
    //   257: aload_3
    //   258: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   49	144	139	finally
    //   152	254	139	finally
  }

  private void getPliResponse(ByteArrayOutputStream paramByteArrayOutputStream)
  {
    String str = SystemProperties.get("persist.sys.language");
    if (str != null)
    {
      paramByteArrayOutputStream.write(ComprehensionTlvTag.LANGUAGE.value());
      ResponseData.writeLength(paramByteArrayOutputStream, str.length());
      paramByteArrayOutputStream.write(str.getBytes(), 0, str.length());
    }
  }

  private void handleCmdResponse(CatResponseMessage paramCatResponseMessage)
  {
    if (!validateResponse(paramCatResponseMessage));
    Object localObject;
    CommandDetails localCommandDetails;
    AppInterface.CommandType localCommandType;
    while (true)
    {
      return;
      localObject = null;
      i = 0;
      localCommandDetails = paramCatResponseMessage.getCmdDetails();
      localCommandType = AppInterface.CommandType.fromInt(localCommandDetails.typeOfCommand);
      switch (1.$SwitchMap$com$android$internal$telephony$cat$ResultCode[paramCatResponseMessage.mResCode.ordinal()])
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      }
    }
    int i = 1;
    switch (1.$SwitchMap$com$android$internal$telephony$cat$AppInterface$CommandType[localCommandType.ordinal()])
    {
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
    default:
    case 1:
    case 7:
    case 8:
    case 9:
    case 15:
    case 16:
    }
    while (true)
    {
      sendTerminalResponse(localCommandDetails, paramCatResponseMessage.mResCode, paramCatResponseMessage.mIncludeAdditionalInfo, paramCatResponseMessage.mAdditionalInfo, (ResponseData)localObject);
      this.mCurrntCmd = null;
      break;
      if (paramCatResponseMessage.mResCode == ResultCode.HELP_INFO_REQUIRED);
      for (boolean bool = true; ; bool = false)
      {
        sendMenuSelection(paramCatResponseMessage.mUsersMenuSelection, bool);
        break;
      }
      localObject = new SelectItemResponseData(paramCatResponseMessage.mUsersMenuSelection);
      continue;
      Input localInput = this.mCurrntCmd.geInput();
      if (!localInput.yesNo)
      {
        if (i == 0)
          localObject = new GetInkeyInputResponseData(paramCatResponseMessage.mUsersInput, localInput.ucs2, localInput.packed);
      }
      else
      {
        localObject = new GetInkeyInputResponseData(paramCatResponseMessage.mUsersYesNoSelection);
        continue;
        this.mCmdIf.handleCallSetupRequestFromSim(paramCatResponseMessage.mUsersConfirm, null);
        this.mCurrntCmd = null;
        break;
        if ((localCommandType == AppInterface.CommandType.SET_UP_CALL) || (localCommandType == AppInterface.CommandType.OPEN_CHANNEL))
        {
          this.mCmdIf.handleCallSetupRequestFromSim(false, null);
          this.mCurrntCmd = null;
          break;
        }
        localObject = null;
        continue;
        localObject = null;
      }
    }
  }

  private void handleCommand(CommandParams paramCommandParams, boolean paramBoolean)
  {
    CatLog.d(this, paramCommandParams.getCommandType().name());
    CatCmdMessage localCatCmdMessage = new CatCmdMessage(paramCommandParams);
    switch (1.$SwitchMap$com$android$internal$telephony$cat$AppInterface$CommandType[paramCommandParams.getCommandType().ordinal()])
    {
    default:
      CatLog.d(this, "Unsupported command");
      return;
    case 1:
      if (removeMenu(localCatCmdMessage.getMenu()))
      {
        this.mMenuCmd = null;
        label144: sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
      }
      break;
    case 7:
    case 8:
    case 9:
    case 14:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 10:
    case 11:
    case 12:
    case 13:
    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
    }
    while (true)
    {
      while (true)
      {
        this.mCurrntCmd = localCatCmdMessage;
        Intent localIntent = new Intent("android.intent.action.stk.command");
        localIntent.putExtra("STK CMD", localCatCmdMessage);
        this.mContext.sendBroadcast(localIntent);
        break;
        this.mMenuCmd = localCatCmdMessage;
        break label144;
        if (!localCatCmdMessage.geTextMessage().responseNeeded)
        {
          sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
          continue;
          paramCommandParams.mCmdDet.typeOfCommand = AppInterface.CommandType.SET_UP_IDLE_MODE_TEXT.value();
          continue;
          sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
          continue;
          switch (paramCommandParams.mCmdDet.commandQualifier)
          {
          default:
            sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
            break;
          case 3:
            DTTZResponseData localDTTZResponseData = new DTTZResponseData(null);
            sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, localDTTZResponseData);
            break;
          case 4:
            LanguageResponseData localLanguageResponseData = new LanguageResponseData(Locale.getDefault().getLanguage());
            sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, localLanguageResponseData);
            break;
            if ((((LaunchBrowserParams)paramCommandParams).mConfirmMsg.text != null) && (((LaunchBrowserParams)paramCommandParams).mConfirmMsg.text.equals("Default Message")))
            {
              CharSequence localCharSequence3 = this.mContext.getText(17040699);
              ((LaunchBrowserParams)paramCommandParams).mConfirmMsg.text = localCharSequence3.toString();
              continue;
              if ((((DisplayTextParams)paramCommandParams).mTextMsg.text != null) && (((DisplayTextParams)paramCommandParams).mTextMsg.text.equals("Default Message")))
              {
                CharSequence localCharSequence2 = this.mContext.getText(17040698);
                ((DisplayTextParams)paramCommandParams).mTextMsg.text = localCharSequence2.toString();
                continue;
                if ((((CallSetupParams)paramCommandParams).mConfirmMsg.text != null) && (((CallSetupParams)paramCommandParams).mConfirmMsg.text.equals("Default Message")))
                {
                  CharSequence localCharSequence1 = this.mContext.getText(17040700);
                  ((CallSetupParams)paramCommandParams).mConfirmMsg.text = localCharSequence1.toString();
                  continue;
                  BIPClientParams localBIPClientParams = (BIPClientParams)paramCommandParams;
                  try
                  {
                    boolean bool2 = this.mContext.getResources().getBoolean(17891417);
                    bool1 = bool2;
                    if ((localBIPClientParams.mTextMsg.text != null) || ((!localBIPClientParams.mHasAlphaId) && (!bool1)))
                      break label692;
                    CatLog.d(this, "cmd " + paramCommandParams.getCommandType() + " with null alpha id");
                    if (!paramBoolean)
                      break;
                    if (paramCommandParams.getCommandType() == AppInterface.CommandType.OPEN_CHANNEL)
                      this.mCmdIf.handleCallSetupRequestFromSim(true, null);
                  }
                  catch (Resources.NotFoundException localNotFoundException)
                  {
                    while (true)
                      boolean bool1 = false;
                    sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
                  }
                }
              }
            }
            break;
          }
        }
      }
      break;
      label692: if (!this.mStkAppInstalled)
      {
        CatLog.d(this, "No STK application found.");
        if (paramBoolean)
        {
          sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.BEYOND_TERMINAL_CAPABILITY, false, 0, null);
          break;
        }
      }
      if ((paramBoolean) && ((paramCommandParams.getCommandType() == AppInterface.CommandType.CLOSE_CHANNEL) || (paramCommandParams.getCommandType() == AppInterface.CommandType.RECEIVE_DATA) || (paramCommandParams.getCommandType() == AppInterface.CommandType.SEND_DATA)))
        sendTerminalResponse(paramCommandParams.mCmdDet, ResultCode.OK, false, 0, null);
    }
  }

  private void handleRilMsg(RilMessage paramRilMessage)
  {
    if (paramRilMessage == null);
    while (true)
    {
      return;
      switch (paramRilMessage.mId)
      {
      case 4:
      default:
        break;
      case 1:
        handleSessionEnd();
        break;
      case 3:
        if (paramRilMessage.mResCode == ResultCode.OK)
        {
          CommandParams localCommandParams3 = (CommandParams)paramRilMessage.mData;
          if (localCommandParams3 != null)
            handleCommand(localCommandParams3, false);
        }
        break;
      case 2:
        CommandParams localCommandParams2;
        try
        {
          localCommandParams2 = (CommandParams)paramRilMessage.mData;
          if (localCommandParams2 == null)
            continue;
          if (paramRilMessage.mResCode != ResultCode.OK)
            break label157;
          handleCommand(localCommandParams2, true);
        }
        catch (ClassCastException localClassCastException)
        {
          CatLog.d(this, "Fail to parse proactive command");
        }
        if (this.mCurrntCmd != null)
        {
          sendTerminalResponse(this.mCurrntCmd.mCmdDet, ResultCode.CMD_DATA_NOT_UNDERSTOOD, false, 0, null);
          continue;
          sendTerminalResponse(localCommandParams2.mCmdDet, paramRilMessage.mResCode, false, 0, null);
        }
        break;
      case 5:
        label157: CommandParams localCommandParams1 = (CommandParams)paramRilMessage.mData;
        if (localCommandParams1 != null)
          handleCommand(localCommandParams1, false);
        break;
      }
    }
  }

  private void handleSessionEnd()
  {
    CatLog.d(this, "SESSION END");
    this.mCurrntCmd = this.mMenuCmd;
    Intent localIntent = new Intent("android.intent.action.stk.session_end");
    this.mContext.sendBroadcast(localIntent);
  }

  private boolean isStkAppInstalled()
  {
    boolean bool = false;
    Intent localIntent = new Intent("android.intent.action.stk.command");
    List localList = this.mContext.getPackageManager().queryBroadcastReceivers(localIntent, 128);
    if (localList == null);
    for (int i = 0; ; i = localList.size())
    {
      if (i > 0)
        bool = true;
      return bool;
    }
  }

  private boolean removeMenu(Menu paramMenu)
  {
    int i = 1;
    try
    {
      if (paramMenu.items.size() == i)
      {
        Object localObject = paramMenu.items.get(0);
        if (localObject == null)
          return i;
      }
    }
    catch (NullPointerException localNullPointerException)
    {
      while (true)
      {
        CatLog.d(this, "Unable to get Menu's items size");
        continue;
        int j = 0;
      }
    }
  }

  private void sendMenuSelection(int paramInt, boolean paramBoolean)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    localByteArrayOutputStream.write(211);
    localByteArrayOutputStream.write(0);
    localByteArrayOutputStream.write(0x80 | ComprehensionTlvTag.DEVICE_IDENTITIES.value());
    localByteArrayOutputStream.write(2);
    localByteArrayOutputStream.write(1);
    localByteArrayOutputStream.write(129);
    localByteArrayOutputStream.write(0x80 | ComprehensionTlvTag.ITEM_ID.value());
    localByteArrayOutputStream.write(1);
    localByteArrayOutputStream.write(paramInt);
    if (paramBoolean)
    {
      localByteArrayOutputStream.write(ComprehensionTlvTag.HELP_REQUEST.value());
      localByteArrayOutputStream.write(0);
    }
    byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
    arrayOfByte[1] = ((byte)(-2 + arrayOfByte.length));
    String str = IccUtils.bytesToHexString(arrayOfByte);
    this.mCmdIf.sendEnvelope(str, null);
  }

  private void sendTerminalResponse(CommandDetails paramCommandDetails, ResultCode paramResultCode, boolean paramBoolean, int paramInt, ResponseData paramResponseData)
  {
    int i = 2;
    if (paramCommandDetails == null)
      return;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    Input localInput = null;
    if (this.mCurrntCmd != null)
      localInput = this.mCurrntCmd.geInput();
    int j = ComprehensionTlvTag.COMMAND_DETAILS.value();
    if (paramCommandDetails.compRequired)
      j |= 128;
    localByteArrayOutputStream.write(j);
    localByteArrayOutputStream.write(3);
    localByteArrayOutputStream.write(paramCommandDetails.commandNumber);
    localByteArrayOutputStream.write(paramCommandDetails.typeOfCommand);
    localByteArrayOutputStream.write(paramCommandDetails.commandQualifier);
    localByteArrayOutputStream.write(ComprehensionTlvTag.DEVICE_IDENTITIES.value());
    localByteArrayOutputStream.write(i);
    localByteArrayOutputStream.write(130);
    localByteArrayOutputStream.write(129);
    localByteArrayOutputStream.write(0x80 | ComprehensionTlvTag.RESULT.value());
    if (paramBoolean)
    {
      label152: localByteArrayOutputStream.write(i);
      localByteArrayOutputStream.write(paramResultCode.value());
      if (paramBoolean)
        localByteArrayOutputStream.write(paramInt);
      if (paramResponseData == null)
        break label222;
      paramResponseData.format(localByteArrayOutputStream);
    }
    while (true)
    {
      String str = IccUtils.bytesToHexString(localByteArrayOutputStream.toByteArray());
      this.mCmdIf.sendTerminalResponse(str, null);
      break;
      i = 1;
      break label152;
      label222: encodeOptionalTags(paramCommandDetails, paramResultCode, localInput, localByteArrayOutputStream);
    }
  }

  private boolean validateResponse(CatResponseMessage paramCatResponseMessage)
  {
    if (this.mCurrntCmd != null);
    for (boolean bool = paramCatResponseMessage.mCmdDet.compareTo(this.mCurrntCmd.mCmdDet); ; bool = false)
      return bool;
  }

  public void dispose()
  {
    mIccRecords.unregisterForRecordsLoaded(this);
    this.mCmdIf.unSetOnCatSessionEnd(this);
    this.mCmdIf.unSetOnCatProactiveCmd(this);
    this.mCmdIf.unSetOnCatEvent(this);
    this.mCmdIf.unSetOnCatCallSetUp(this);
    removeCallbacksAndMessages(null);
  }

  protected void finalize()
  {
    CatLog.d(this, "Service finalized");
  }

  public void handleMessage(Message paramMessage)
  {
    String str;
    AsyncResult localAsyncResult;
    switch (paramMessage.what)
    {
    case 8:
    case 9:
    case 11:
    case 12:
    case 13:
    case 14:
    case 15:
    case 16:
    case 17:
    case 18:
    case 19:
    default:
      throw new AssertionError("Unrecognized CAT command: " + paramMessage.what);
    case 1:
    case 2:
    case 3:
    case 5:
      CatLog.d(this, "ril message arrived");
      str = null;
      if (paramMessage.obj != null)
      {
        localAsyncResult = (AsyncResult)paramMessage.obj;
        if ((localAsyncResult == null) || (localAsyncResult.result == null))
          break;
      }
      break;
    case 20:
    case 4:
    case 10:
    case 6:
    case 7:
    }
    try
    {
      str = (String)localAsyncResult.result;
      this.mMsgDecoder.sendStartDecodingMessageParams(new RilMessage(paramMessage.what, str));
      return;
    }
    catch (ClassCastException localClassCastException)
    {
      while (true)
      {
        continue;
        this.mMsgDecoder.sendStartDecodingMessageParams(new RilMessage(paramMessage.what, null));
        continue;
        handleRilMsg((RilMessage)paramMessage.obj);
        continue;
        handleCmdResponse((CatResponseMessage)paramMessage.obj);
        continue;
        CatLog.d(this, "SIM ready. Reporting STK service running now...");
        this.mCmdIf.reportStkServiceIsRunning(null);
      }
    }
  }

  public void onCmdResponse(CatResponseMessage paramCatResponseMessage)
  {
    if (paramCatResponseMessage == null);
    while (true)
    {
      return;
      try
      {
        obtainMessage(6, paramCatResponseMessage).sendToTarget();
      }
      finally
      {
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.CatService
 * JD-Core Version:    0.6.2
 */