package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class PlayToneParams extends CommandParams
{
  ToneSettings mSettings;
  TextMessage mTextMsg;

  PlayToneParams(CommandDetails paramCommandDetails, TextMessage paramTextMessage, Tone paramTone, Duration paramDuration, boolean paramBoolean)
  {
    super(paramCommandDetails);
    this.mTextMsg = paramTextMessage;
    this.mSettings = new ToneSettings(paramDuration, paramTone, paramBoolean);
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mTextMsg != null))
      this.mTextMsg.icon = paramBitmap;
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.PlayToneParams
 * JD-Core Version:    0.6.2
 */