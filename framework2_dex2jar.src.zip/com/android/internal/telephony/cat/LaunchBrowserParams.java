package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class LaunchBrowserParams extends CommandParams
{
  TextMessage mConfirmMsg;
  LaunchBrowserMode mMode;
  String mUrl;

  LaunchBrowserParams(CommandDetails paramCommandDetails, TextMessage paramTextMessage, String paramString, LaunchBrowserMode paramLaunchBrowserMode)
  {
    super(paramCommandDetails);
    this.mConfirmMsg = paramTextMessage;
    this.mMode = paramLaunchBrowserMode;
    this.mUrl = paramString;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mConfirmMsg != null))
      this.mConfirmMsg.icon = paramBitmap;
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.LaunchBrowserParams
 * JD-Core Version:    0.6.2
 */