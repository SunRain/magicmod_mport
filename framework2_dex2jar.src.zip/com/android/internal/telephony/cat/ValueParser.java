package com.android.internal.telephony.cat;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import com.android.internal.telephony.GsmAlphabet;
import com.android.internal.telephony.uicc.IccUtils;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

abstract class ValueParser
{
  static String retrieveAlphaId(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    Object localObject = null;
    byte[] arrayOfByte;
    int i;
    int j;
    if (paramComprehensionTlv != null)
    {
      arrayOfByte = paramComprehensionTlv.getRawValue();
      i = paramComprehensionTlv.getValueIndex();
      j = paramComprehensionTlv.getLength();
      if (j == 0);
    }
    while (true)
    {
      try
      {
        String str = IccUtils.adnStringFieldToString(arrayOfByte, i, j);
        localObject = str;
        return localObject;
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
      {
        throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
      }
      CatLog.d("ValueParser", "Alpha Id length=" + j);
      continue;
      Resources localResources = Resources.getSystem();
      try
      {
        boolean bool2 = localResources.getBoolean(17891417);
        bool1 = bool2;
        if (bool1)
          continue;
        localObject = "Default Message";
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        while (true)
          boolean bool1 = false;
      }
    }
  }

  static CommandDetails retrieveCommandDetails(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    CommandDetails localCommandDetails = new CommandDetails();
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    try
    {
      localCommandDetails.compRequired = paramComprehensionTlv.isComprehensionRequired();
      localCommandDetails.commandNumber = (0xFF & arrayOfByte[i]);
      localCommandDetails.typeOfCommand = (0xFF & arrayOfByte[(i + 1)]);
      localCommandDetails.commandQualifier = (0xFF & arrayOfByte[(i + 2)]);
      return localCommandDetails;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
  }

  static DeviceIdentities retrieveDeviceIdentities(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    DeviceIdentities localDeviceIdentities = new DeviceIdentities();
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    try
    {
      localDeviceIdentities.sourceId = (0xFF & arrayOfByte[i]);
      localDeviceIdentities.destinationId = (0xFF & arrayOfByte[(i + 1)]);
      return localDeviceIdentities;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.REQUIRED_VALUES_MISSING);
  }

  static Duration retrieveDuration(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    try
    {
      Duration.TimeUnit localTimeUnit = Duration.TimeUnit.values()[(0xFF & arrayOfByte[i])];
      int j = arrayOfByte[(i + 1)];
      return new Duration(j & 0xFF, localTimeUnit);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
  }

  static IconId retrieveIconId(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    IconId localIconId = new IconId();
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    int j = i + 1;
    try
    {
      if ((0xFF & arrayOfByte[i]) == 0);
      for (boolean bool = true; ; bool = false)
      {
        localIconId.selfExplanatory = bool;
        localIconId.recordNumber = (0xFF & arrayOfByte[j]);
        return localIconId;
      }
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
  }

  static Item retrieveItem(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    Item localItem = null;
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    int j = paramComprehensionTlv.getLength();
    int k;
    if (j != 0)
      k = j - 1;
    try
    {
      localItem = new Item(0xFF & arrayOfByte[i], IccUtils.adnStringFieldToString(arrayOfByte, i + 1, k));
      return localItem;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
  }

  static int retrieveItemId(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    try
    {
      int j = arrayOfByte[i];
      return j & 0xFF;
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
  }

  // ERROR //
  static ItemsIconId retrieveItemsIconId(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    // Byte code:
    //   0: ldc 46
    //   2: ldc 159
    //   4: invokestatic 68	com/android/internal/telephony/cat/CatLog:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   7: new 161	com/android/internal/telephony/cat/ItemsIconId
    //   10: dup
    //   11: invokespecial 162	com/android/internal/telephony/cat/ItemsIconId:<init>	()V
    //   14: astore_1
    //   15: aload_0
    //   16: invokevirtual 22	com/android/internal/telephony/cat/ComprehensionTlv:getRawValue	()[B
    //   19: astore_2
    //   20: aload_0
    //   21: invokevirtual 26	com/android/internal/telephony/cat/ComprehensionTlv:getValueIndex	()I
    //   24: istore_3
    //   25: iconst_m1
    //   26: aload_0
    //   27: invokevirtual 29	com/android/internal/telephony/cat/ComprehensionTlv:getLength	()I
    //   30: iadd
    //   31: istore 4
    //   33: aload_1
    //   34: iload 4
    //   36: newarray int
    //   38: putfield 166	com/android/internal/telephony/cat/ItemsIconId:recordNumbers	[I
    //   41: iload_3
    //   42: iconst_1
    //   43: iadd
    //   44: istore 5
    //   46: sipush 255
    //   49: aload_2
    //   50: iload_3
    //   51: baload
    //   52: iand
    //   53: ifne +60 -> 113
    //   56: iconst_1
    //   57: istore 8
    //   59: aload_1
    //   60: iload 8
    //   62: putfield 167	com/android/internal/telephony/cat/ItemsIconId:selfExplanatory	Z
    //   65: iconst_0
    //   66: istore 9
    //   68: iload 9
    //   70: iload 4
    //   72: if_icmpge +63 -> 135
    //   75: aload_1
    //   76: getfield 166	com/android/internal/telephony/cat/ItemsIconId:recordNumbers	[I
    //   79: astore 10
    //   81: iload 9
    //   83: iconst_1
    //   84: iadd
    //   85: istore 11
    //   87: iload 5
    //   89: iconst_1
    //   90: iadd
    //   91: istore 12
    //   93: aload 10
    //   95: iload 9
    //   97: aload_2
    //   98: iload 5
    //   100: baload
    //   101: iastore
    //   102: iload 11
    //   104: istore 9
    //   106: iload 12
    //   108: istore 5
    //   110: goto -42 -> 68
    //   113: iconst_0
    //   114: istore 8
    //   116: goto -57 -> 59
    //   119: astore 6
    //   121: iload 5
    //   123: pop
    //   124: new 12	com/android/internal/telephony/cat/ResultException
    //   127: dup
    //   128: getstatic 41	com/android/internal/telephony/cat/ResultCode:CMD_DATA_NOT_UNDERSTOOD	Lcom/android/internal/telephony/cat/ResultCode;
    //   131: invokespecial 44	com/android/internal/telephony/cat/ResultException:<init>	(Lcom/android/internal/telephony/cat/ResultCode;)V
    //   134: athrow
    //   135: aload_1
    //   136: areturn
    //   137: astore 13
    //   139: goto -15 -> 124
    //
    // Exception table:
    //   from	to	target	type
    //   46	81	119	java/lang/IndexOutOfBoundsException
    //   93	102	137	java/lang/IndexOutOfBoundsException
  }

  static List<TextAttribute> retrieveTextAttribute(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    ArrayList localArrayList = new ArrayList();
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    int j = paramComprehensionTlv.getLength();
    int m;
    if (j != 0)
    {
      int k = j / 4;
      m = 0;
      if (m >= k)
        break label205;
    }
    while (true)
    {
      int i2;
      boolean bool1;
      boolean bool2;
      boolean bool3;
      boolean bool4;
      try
      {
        int n = 0xFF & arrayOfByte[i];
        int i1 = 0xFF & arrayOfByte[(i + 1)];
        i2 = 0xFF & arrayOfByte[(i + 2)];
        int i3 = 0xFF & arrayOfByte[(i + 3)];
        TextAlignment localTextAlignment = TextAlignment.fromInt(i2 & 0x3);
        FontSize localFontSize = FontSize.fromInt(0x3 & i2 >> 2);
        if (localFontSize != null)
          break label207;
        localFontSize = FontSize.NORMAL;
        break label207;
        TextAttribute localTextAttribute = new TextAttribute(n, i1, localTextAlignment, localFontSize, bool1, bool2, bool3, bool4, TextColor.fromInt(i3));
        localArrayList.add(localTextAttribute);
        m++;
        i += 4;
        break;
        bool1 = false;
        break label218;
        bool2 = false;
        break label229;
        bool3 = false;
        break label240;
        bool4 = false;
        continue;
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
      {
        throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
      }
      localArrayList = null;
      label205: return localArrayList;
      label207: if ((i2 & 0x10) != 0)
      {
        bool1 = true;
        label218: if ((i2 & 0x20) != 0)
        {
          bool2 = true;
          label229: if ((i2 & 0x40) != 0)
          {
            bool3 = true;
            label240: if ((i2 & 0x80) != 0)
              bool4 = true;
          }
        }
      }
    }
  }

  static String retrieveTextString(ComprehensionTlv paramComprehensionTlv)
    throws ResultException
  {
    byte[] arrayOfByte = paramComprehensionTlv.getRawValue();
    int i = paramComprehensionTlv.getValueIndex();
    int j = paramComprehensionTlv.getLength();
    if (j == 0);
    String str;
    for (Object localObject = null; ; localObject = str)
    {
      return localObject;
      int k = j - 1;
      try
      {
        int m = (byte)(0xC & arrayOfByte[i]);
        if (m == 0)
          str = GsmAlphabet.gsm7BitPackedToString(arrayOfByte, i + 1, k * 8 / 7);
        else if (m == 4)
          str = GsmAlphabet.gsm8BitUnpackedToString(arrayOfByte, i + 1, k);
        else if (m == 8)
          str = new String(arrayOfByte, i + 1, k, "UTF-16");
        else
          throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
      }
      catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
      {
        throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        throw new ResultException(ResultCode.CMD_DATA_NOT_UNDERSTOOD);
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.ValueParser
 * JD-Core Version:    0.6.2
 */