package com.android.internal.telephony.cat;

class DeviceIdentities extends ValueObject
{
  public int destinationId;
  public int sourceId;

  ComprehensionTlvTag getTag()
  {
    return ComprehensionTlvTag.DEVICE_IDENTITIES;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.DeviceIdentities
 * JD-Core Version:    0.6.2
 */