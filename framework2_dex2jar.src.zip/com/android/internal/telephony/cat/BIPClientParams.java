package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class BIPClientParams extends CommandParams
{
  boolean mHasAlphaId;
  TextMessage mTextMsg;

  BIPClientParams(CommandDetails paramCommandDetails, TextMessage paramTextMessage, boolean paramBoolean)
  {
    super(paramCommandDetails);
    this.mTextMsg = paramTextMessage;
    this.mHasAlphaId = paramBoolean;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mTextMsg != null))
      this.mTextMsg.icon = paramBitmap;
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.BIPClientParams
 * JD-Core Version:    0.6.2
 */