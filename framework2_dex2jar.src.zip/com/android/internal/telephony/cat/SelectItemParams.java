package com.android.internal.telephony.cat;

import android.graphics.Bitmap;
import java.util.Iterator;
import java.util.List;

class SelectItemParams extends CommandParams
{
  boolean mLoadTitleIcon = false;
  Menu mMenu = null;

  SelectItemParams(CommandDetails paramCommandDetails, Menu paramMenu, boolean paramBoolean)
  {
    super(paramCommandDetails);
    this.mMenu = paramMenu;
    this.mLoadTitleIcon = paramBoolean;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mMenu != null))
      if ((this.mLoadTitleIcon) && (this.mMenu.titleIcon == null))
        this.mMenu.titleIcon = paramBitmap;
    label36: for (boolean bool = true; ; bool = false)
    {
      return bool;
      Iterator localIterator = this.mMenu.items.iterator();
      if (!localIterator.hasNext())
        break label36;
      Item localItem = (Item)localIterator.next();
      if (localItem.icon != null)
        break;
      localItem.icon = paramBitmap;
      break label36;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.SelectItemParams
 * JD-Core Version:    0.6.2
 */