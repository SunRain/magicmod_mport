package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class CallSetupParams extends CommandParams
{
  TextMessage mCallMsg;
  TextMessage mConfirmMsg;

  CallSetupParams(CommandDetails paramCommandDetails, TextMessage paramTextMessage1, TextMessage paramTextMessage2)
  {
    super(paramCommandDetails);
    this.mConfirmMsg = paramTextMessage1;
    this.mCallMsg = paramTextMessage2;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    boolean bool = false;
    if (paramBitmap == null);
    while (true)
    {
      return bool;
      if ((this.mConfirmMsg != null) && (this.mConfirmMsg.icon == null))
      {
        this.mConfirmMsg.icon = paramBitmap;
        bool = true;
      }
      else if ((this.mCallMsg != null) && (this.mCallMsg.icon == null))
      {
        this.mCallMsg.icon = paramBitmap;
        bool = true;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.CallSetupParams
 * JD-Core Version:    0.6.2
 */