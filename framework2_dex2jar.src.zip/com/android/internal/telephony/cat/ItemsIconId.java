package com.android.internal.telephony.cat;

class ItemsIconId extends ValueObject
{
  int[] recordNumbers;
  boolean selfExplanatory;

  ComprehensionTlvTag getTag()
  {
    return ComprehensionTlvTag.ITEM_ICON_ID_LIST;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.ItemsIconId
 * JD-Core Version:    0.6.2
 */