package com.android.internal.telephony.cat;

class IconId extends ValueObject
{
  int recordNumber;
  boolean selfExplanatory;

  ComprehensionTlvTag getTag()
  {
    return ComprehensionTlvTag.ICON_ID;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.IconId
 * JD-Core Version:    0.6.2
 */