package com.android.internal.telephony.cat;

import java.io.ByteArrayOutputStream;

class SelectItemResponseData extends ResponseData
{
  private int mId;

  public SelectItemResponseData(int paramInt)
  {
    this.mId = paramInt;
  }

  public void format(ByteArrayOutputStream paramByteArrayOutputStream)
  {
    paramByteArrayOutputStream.write(0x80 | ComprehensionTlvTag.ITEM_ID.value());
    paramByteArrayOutputStream.write(1);
    paramByteArrayOutputStream.write(this.mId);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.SelectItemResponseData
 * JD-Core Version:    0.6.2
 */