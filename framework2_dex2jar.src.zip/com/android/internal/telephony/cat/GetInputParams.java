package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class GetInputParams extends CommandParams
{
  Input mInput = null;

  GetInputParams(CommandDetails paramCommandDetails, Input paramInput)
  {
    super(paramCommandDetails);
    this.mInput = paramInput;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mInput != null))
      this.mInput.icon = paramBitmap;
    return true;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.GetInputParams
 * JD-Core Version:    0.6.2
 */