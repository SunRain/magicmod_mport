package com.android.internal.telephony.cat;

import android.telephony.Rlog;

public abstract class CatLog
{
  static final boolean DEBUG = true;

  public static void d(Object paramObject, String paramString)
  {
    String str = paramObject.getClass().getName();
    Rlog.d("CAT", str.substring(1 + str.lastIndexOf('.')) + ": " + paramString);
  }

  public static void d(String paramString1, String paramString2)
  {
    Rlog.d("CAT", paramString1 + ": " + paramString2);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.CatLog
 * JD-Core Version:    0.6.2
 */