package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class CommandParams
{
  CommandDetails mCmdDet;

  CommandParams(CommandDetails paramCommandDetails)
  {
    this.mCmdDet = paramCommandDetails;
  }

  AppInterface.CommandType getCommandType()
  {
    return AppInterface.CommandType.fromInt(this.mCmdDet.typeOfCommand);
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    return true;
  }

  public String toString()
  {
    return this.mCmdDet.toString();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.CommandParams
 * JD-Core Version:    0.6.2
 */