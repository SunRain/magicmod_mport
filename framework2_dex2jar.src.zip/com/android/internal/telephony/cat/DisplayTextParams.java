package com.android.internal.telephony.cat;

import android.graphics.Bitmap;

class DisplayTextParams extends CommandParams
{
  TextMessage mTextMsg;

  DisplayTextParams(CommandDetails paramCommandDetails, TextMessage paramTextMessage)
  {
    super(paramCommandDetails);
    this.mTextMsg = paramTextMessage;
  }

  boolean setIcon(Bitmap paramBitmap)
  {
    if ((paramBitmap != null) && (this.mTextMsg != null))
      this.mTextMsg.icon = paramBitmap;
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.cat.DisplayTextParams
 * JD-Core Version:    0.6.2
 */