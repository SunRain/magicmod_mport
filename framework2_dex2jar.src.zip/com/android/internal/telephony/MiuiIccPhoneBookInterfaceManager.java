package com.android.internal.telephony;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.android.internal.telephony.uicc.AdnRecord;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppType;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.MiuiAdnRecord;
import com.android.internal.telephony.uicc.MiuiAdnRecordCache;
import com.android.internal.telephony.uicc.UiccCard;
import com.android.internal.telephony.uicc.UiccCardApplication;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public abstract class MiuiIccPhoneBookInterfaceManager extends IccPhoneBookInterfaceManager
{
  static final boolean ALLOW_SIM_OP_IN_UI_THREAD = false;
  static final int EVENT_GET_SIZE_DONE = 1;
  static final int EVENT_LOAD_DONE = 2;
  static final int EVENT_UPDATE_DONE = 3;
  MiuiAdnRecordCache mAdnCache;
  Handler mBaseHandler;
  UiccCardApplication mCurrentApp = null;
  int mError;
  final Object mLock = new Object();
  PhoneBase mPhone;
  int[] mRecordSize;
  List<AdnRecord> mRecords;
  boolean mSuccess;

  public MiuiIccPhoneBookInterfaceManager(PhoneBase paramPhoneBase)
  {
    super(paramPhoneBase);
    this.mPhone = paramPhoneBase;
    IccRecords localIccRecords = (IccRecords)paramPhoneBase.mIccRecords.get();
    if (localIccRecords != null)
      this.mAdnCache = ((MiuiAdnRecordCache)localIccRecords.getAdnCache());
    this.mBaseHandler = new Handler()
    {
      private void notifyPending(AsyncResult paramAnonymousAsyncResult)
      {
        if (paramAnonymousAsyncResult.userObj == null);
        while (true)
        {
          return;
          ((AtomicBoolean)paramAnonymousAsyncResult.userObj).set(true);
          MiuiIccPhoneBookInterfaceManager.this.mLock.notifyAll();
        }
      }

      // ERROR //
      public void handleMessage(Message paramAnonymousMessage)
      {
        // Byte code:
        //   0: iconst_0
        //   1: istore_2
        //   2: aload_1
        //   3: getfield 47	android/os/Message:what	I
        //   6: tableswitch	default:+26 -> 32, 1:+27->33, 2:+219->225, 3:+120->126
        //   33: aload_1
        //   34: getfield 50	android/os/Message:obj	Ljava/lang/Object;
        //   37: checkcast 21	android/os/AsyncResult
        //   40: astore 11
        //   42: aload_0
        //   43: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   46: getfield 34	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mLock	Ljava/lang/Object;
        //   49: astore 12
        //   51: aload 12
        //   53: monitorenter
        //   54: aload 11
        //   56: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   59: ifnonnull +49 -> 108
        //   62: aload_0
        //   63: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   66: aload 11
        //   68: getfield 57	android/os/AsyncResult:result	Ljava/lang/Object;
        //   71: checkcast 59	[I
        //   74: checkcast 59	[I
        //   77: putfield 62	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mRecordSize	[I
        //   80: aload_0
        //   81: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   84: iconst_0
        //   85: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   88: aload_0
        //   89: aload 11
        //   91: invokespecial 67	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:notifyPending	(Landroid/os/AsyncResult;)V
        //   94: aload 12
        //   96: monitorexit
        //   97: goto -65 -> 32
        //   100: astore 13
        //   102: aload 12
        //   104: monitorexit
        //   105: aload 13
        //   107: athrow
        //   108: aload_0
        //   109: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   112: aload 11
        //   114: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   117: invokestatic 73	com/android/internal/telephony/MiuiIccProviderException:getErrorCauseFromException	(Ljava/lang/Throwable;)I
        //   120: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   123: goto -35 -> 88
        //   126: aload_1
        //   127: getfield 50	android/os/Message:obj	Ljava/lang/Object;
        //   130: checkcast 21	android/os/AsyncResult
        //   133: astore 7
        //   135: aload_0
        //   136: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   139: getfield 34	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mLock	Ljava/lang/Object;
        //   142: astore 8
        //   144: aload 8
        //   146: monitorenter
        //   147: aload_0
        //   148: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   151: astore 10
        //   153: aload 7
        //   155: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   158: ifnonnull +5 -> 163
        //   161: iconst_1
        //   162: istore_2
        //   163: aload 10
        //   165: iload_2
        //   166: putfield 77	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mSuccess	Z
        //   169: aload_0
        //   170: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   173: getfield 77	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mSuccess	Z
        //   176: ifne +38 -> 214
        //   179: aload_0
        //   180: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   183: aload 7
        //   185: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   188: invokestatic 73	com/android/internal/telephony/MiuiIccProviderException:getErrorCauseFromException	(Ljava/lang/Throwable;)I
        //   191: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   194: aload_0
        //   195: aload 7
        //   197: invokespecial 67	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:notifyPending	(Landroid/os/AsyncResult;)V
        //   200: aload 8
        //   202: monitorexit
        //   203: goto -171 -> 32
        //   206: astore 9
        //   208: aload 8
        //   210: monitorexit
        //   211: aload 9
        //   213: athrow
        //   214: aload_0
        //   215: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   218: iconst_0
        //   219: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   222: goto -28 -> 194
        //   225: aload_1
        //   226: getfield 50	android/os/Message:obj	Ljava/lang/Object;
        //   229: checkcast 21	android/os/AsyncResult
        //   232: astore_3
        //   233: aload_0
        //   234: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   237: getfield 34	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mLock	Ljava/lang/Object;
        //   240: astore 4
        //   242: aload 4
        //   244: monitorenter
        //   245: aload_3
        //   246: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   249: ifnonnull +48 -> 297
        //   252: aload_3
        //   253: getfield 57	android/os/AsyncResult:result	Ljava/lang/Object;
        //   256: checkcast 79	java/util/List
        //   259: astore 6
        //   261: aload_0
        //   262: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   265: aload 6
        //   267: putfield 83	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mRecords	Ljava/util/List;
        //   270: aload_0
        //   271: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   274: iconst_0
        //   275: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   278: aload_0
        //   279: aload_3
        //   280: invokespecial 67	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:notifyPending	(Landroid/os/AsyncResult;)V
        //   283: aload 4
        //   285: monitorexit
        //   286: goto -254 -> 32
        //   289: astore 5
        //   291: aload 4
        //   293: monitorexit
        //   294: aload 5
        //   296: athrow
        //   297: aload_0
        //   298: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   301: aconst_null
        //   302: putfield 83	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mRecords	Ljava/util/List;
        //   305: aload_0
        //   306: getfield 14	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager$1:this$0	Lcom/android/internal/telephony/MiuiIccPhoneBookInterfaceManager;
        //   309: aload_3
        //   310: getfield 54	android/os/AsyncResult:exception	Ljava/lang/Throwable;
        //   313: invokestatic 73	com/android/internal/telephony/MiuiIccProviderException:getErrorCauseFromException	(Ljava/lang/Throwable;)I
        //   316: putfield 65	com/android/internal/telephony/MiuiIccPhoneBookInterfaceManager:mError	I
        //   319: goto -41 -> 278
        //
        // Exception table:
        //   from	to	target	type
        //   54	105	100	finally
        //   108	123	100	finally
        //   147	211	206	finally
        //   214	222	206	finally
        //   245	294	289	finally
        //   297	319	289	finally
      }
    };
  }

  private void cleanUp()
  {
    if (this.mAdnCache != null)
    {
      this.mAdnCache.reset();
      this.mAdnCache = null;
    }
    this.mCurrentApp = null;
  }

  private int updateEfForIccType(int paramInt)
  {
    if ((paramInt == 28474) && (isUsimPhoneBookRecords()))
      paramInt = 20272;
    return paramInt;
  }

  protected void checkThread()
  {
    if (this.mBaseHandler.getLooper().equals(Looper.myLooper()))
    {
      loge("query() called on the main UI thread!");
      throw new IllegalStateException("You cannot call query on this provder from the main UI thread.");
    }
  }

  public void dispose()
  {
    cleanUp();
  }

  public int getAdnCapacity()
  {
    return this.mAdnCache.getAdnCapacity(updateEfForIccType(28474));
  }

  public List<AdnRecord> getAdnRecordsInEf(int paramInt)
  {
    if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.READ_CONTACTS") != 0)
      throw new SecurityException("Requires android.permission.READ_CONTACTS permission");
    int i = updateEfForIccType(paramInt);
    logd("getAdnRecordsInEF: efid=" + i);
    synchronized (this.mLock)
    {
      checkThread();
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(2, localAtomicBoolean);
      this.mAdnCache.requestLoadAllAdnLike(i, this.mAdnCache.extensionEfForEf(i), localMessage);
      waitForResult(localAtomicBoolean);
      return this.mRecords;
    }
  }

  public int[] getAdnRecordsSize(int paramInt)
  {
    logd("getAdnRecordsSize: efid=" + paramInt);
    synchronized (this.mLock)
    {
      checkThread();
      this.mRecordSize = new int[3];
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(1, localAtomicBoolean);
      IccFileHandler localIccFileHandler = this.mPhone.getIccFileHandler();
      if (localIccFileHandler != null)
      {
        localIccFileHandler.getEFLinearRecordSize(paramInt, localMessage);
        waitForResult(localAtomicBoolean);
      }
      return this.mRecordSize;
    }
  }

  public int getFreeAdn()
  {
    return this.mAdnCache.getFreeAdn(updateEfForIccType(28474));
  }

  public int getLastError()
  {
    return this.mError;
  }

  public boolean isPhoneBookReady()
  {
    if ((this.mPhone.getIccFileHandler() != null) && (this.mPhone.getIccRecordsLoaded()) && (this.mAdnCache != null));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isUsimPhoneBookRecords()
  {
    boolean bool = false;
    UiccCardApplication localUiccCardApplication = (UiccCardApplication)this.mPhone.mUiccApplication.get();
    if ((localUiccCardApplication != null) && (localUiccCardApplication.getType() == IccCardApplicationStatus.AppType.APPTYPE_USIM))
      bool = true;
    return bool;
  }

  protected void publish()
  {
  }

  public void setIccCard(UiccCard paramUiccCard)
  {
    logd("Card update received: " + paramUiccCard);
    if (paramUiccCard == null)
    {
      logd("Card is null. Cleanup");
      cleanUp();
      return;
    }
    Object localObject = null;
    int i = 0;
    for (int j = 0; ; j++)
    {
      UiccCardApplication localUiccCardApplication = paramUiccCard.getApplicationIndex(j);
      if (localUiccCardApplication != null)
      {
        IccCardApplicationStatus.AppType localAppType = localUiccCardApplication.getType();
        int k = 0;
        if ((localAppType == IccCardApplicationStatus.AppType.APPTYPE_CSIM) || (localAppType == IccCardApplicationStatus.AppType.APPTYPE_USIM) || (localAppType == IccCardApplicationStatus.AppType.APPTYPE_ISIM))
        {
          logd("Card is 3G");
          k = 1;
        }
        if (i == 0)
        {
          if ((localObject == null) && (localAppType != IccCardApplicationStatus.AppType.APPTYPE_UNKNOWN))
            localObject = localUiccCardApplication;
          if (this.mCurrentApp == localUiccCardApplication)
          {
            logd("Existing app found");
            i = 1;
          }
        }
        if ((k == 0) || (i == 0));
      }
      else
      {
        if (((this.mCurrentApp != null) && (i != 0)) || (localObject == null))
          break;
        logd("Setting currentApp: " + localObject);
        this.mCurrentApp = localObject;
        updateIccRecords(this.mCurrentApp.getIccRecords());
        break;
      }
    }
  }

  public boolean updateAdnRecordsInEfByIndex(int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3)
  {
    if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0)
      throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    logd("updateAdnRecordsInEfByIndex: efid=" + paramInt1 + " Index=" + paramInt2 + " ==> " + "(" + paramString1 + "," + paramString2 + ")" + " pin2=" + paramString3);
    synchronized (this.mLock)
    {
      checkThread();
      this.mSuccess = false;
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(3, localAtomicBoolean);
      MiuiAdnRecord localMiuiAdnRecord = new MiuiAdnRecord(paramString1, paramString2);
      this.mAdnCache.updateAdnByIndex(paramInt1, localMiuiAdnRecord, paramInt2, paramString3, localMessage);
      waitForResult(localAtomicBoolean);
      return this.mSuccess;
    }
  }

  public boolean updateAdnRecordsInEfBySearch(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0)
      throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    logd("updateAdnRecordsInEfBySearch: efid=" + paramInt + " (" + paramString1 + "," + paramString2 + ")" + "==>" + " (" + paramString3 + "," + paramString4 + ")" + " pin2=" + paramString5);
    int i = updateEfForIccType(paramInt);
    synchronized (this.mLock)
    {
      checkThread();
      this.mSuccess = false;
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(3, localAtomicBoolean);
      MiuiAdnRecord localMiuiAdnRecord1 = new MiuiAdnRecord(paramString1, paramString2);
      MiuiAdnRecord localMiuiAdnRecord2 = new MiuiAdnRecord(paramString3, paramString4);
      this.mAdnCache.updateAdnBySearch(i, localMiuiAdnRecord1, localMiuiAdnRecord2, paramString5, localMessage);
      waitForResult(localAtomicBoolean);
      return this.mSuccess;
    }
  }

  public void updateIccRecords(IccRecords paramIccRecords)
  {
    if (paramIccRecords != null);
    for (this.mAdnCache = ((MiuiAdnRecordCache)paramIccRecords.getAdnCache()); ; this.mAdnCache = null)
      return;
  }

  public boolean updateUsimPhoneBookRecordsByIndex(int paramInt1, MiuiAdnRecord paramMiuiAdnRecord, int paramInt2)
  {
    if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0)
      throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    int i = updateEfForIccType(paramInt1);
    synchronized (this.mLock)
    {
      checkThread();
      this.mSuccess = false;
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(3, localAtomicBoolean);
      this.mAdnCache.updateAdnByIndex(i, paramMiuiAdnRecord, paramInt2, null, localMessage);
      waitForResult(localAtomicBoolean);
      return this.mSuccess;
    }
  }

  public boolean updateUsimPhoneBookRecordsBySearch(int paramInt, MiuiAdnRecord paramMiuiAdnRecord1, MiuiAdnRecord paramMiuiAdnRecord2)
  {
    if (this.mPhone.getContext().checkCallingOrSelfPermission("android.permission.WRITE_CONTACTS") != 0)
      throw new SecurityException("Requires android.permission.WRITE_CONTACTS permission");
    int i = updateEfForIccType(paramInt);
    synchronized (this.mLock)
    {
      checkThread();
      this.mSuccess = false;
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(3, localAtomicBoolean);
      this.mAdnCache.updateAdnBySearch(i, paramMiuiAdnRecord1, paramMiuiAdnRecord2, null, localMessage);
      waitForResult(localAtomicBoolean);
      return this.mSuccess;
    }
  }

  public boolean updateUsimPhoneBookRecordsInEfByIndex(int paramInt1, String paramString1, String paramString2, String[] paramArrayOfString, String paramString3, int paramInt2)
  {
    return updateUsimPhoneBookRecordsByIndex(paramInt1, new MiuiAdnRecord(paramString1, paramString2, paramArrayOfString, paramString3), paramInt2);
  }

  public boolean updateUsimPhoneBookRecordsInEfBySearch(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String[] paramArrayOfString, String paramString5)
  {
    return updateUsimPhoneBookRecordsBySearch(paramInt, new MiuiAdnRecord(paramString1, paramString2, null, ""), new MiuiAdnRecord(paramString3, paramString4, paramArrayOfString, paramString5));
  }

  protected void waitForResult(AtomicBoolean paramAtomicBoolean)
  {
    while (!paramAtomicBoolean.get())
      try
      {
        this.mLock.wait();
      }
      catch (InterruptedException localInterruptedException)
      {
        logd("interrupted while trying to update by search");
      }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.MiuiIccPhoneBookInterfaceManager
 * JD-Core Version:    0.6.2
 */