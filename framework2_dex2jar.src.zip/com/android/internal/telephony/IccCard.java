package com.android.internal.telephony;

import android.os.Handler;
import android.os.Message;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppType;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.IccRecords;

public abstract interface IccCard
{
  public abstract void changeIccFdnPassword(String paramString1, String paramString2, Message paramMessage);

  public abstract void changeIccLockPassword(String paramString1, String paramString2, Message paramMessage);

  public abstract boolean getIccFdnAvailable();

  public abstract boolean getIccFdnEnabled();

  public abstract IccFileHandler getIccFileHandler();

  public abstract boolean getIccLockEnabled();

  public abstract boolean getIccPin2Blocked();

  public abstract boolean getIccPuk2Blocked();

  public abstract IccRecords getIccRecords();

  public abstract String getServiceProviderName();

  public abstract IccCardConstants.State getState();

  public abstract boolean hasIccCard();

  public abstract boolean isApplicationOnIcc(IccCardApplicationStatus.AppType paramAppType);

  public abstract void registerForAbsent(Handler paramHandler, int paramInt, Object paramObject);

  public abstract void registerForLocked(Handler paramHandler, int paramInt, Object paramObject);

  public abstract void registerForNetworkLocked(Handler paramHandler, int paramInt, Object paramObject);

  public abstract void setIccFdnEnabled(boolean paramBoolean, String paramString, Message paramMessage);

  public abstract void setIccLockEnabled(boolean paramBoolean, String paramString, Message paramMessage);

  public abstract void supplyNetworkDepersonalization(String paramString, Message paramMessage);

  public abstract void supplyPin(String paramString, Message paramMessage);

  public abstract void supplyPin2(String paramString, Message paramMessage);

  public abstract void supplyPuk(String paramString1, String paramString2, Message paramMessage);

  public abstract void supplyPuk2(String paramString1, String paramString2, Message paramMessage);

  public abstract void unregisterForAbsent(Handler paramHandler);

  public abstract void unregisterForLocked(Handler paramHandler);

  public abstract void unregisterForNetworkLocked(Handler paramHandler);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.IccCard
 * JD-Core Version:    0.6.2
 */