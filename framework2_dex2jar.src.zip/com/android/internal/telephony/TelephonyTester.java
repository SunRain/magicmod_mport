package com.android.internal.telephony;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.RegistrantList;
import android.telephony.Rlog;

public class TelephonyTester
{
  private static final boolean DBG = true;
  private static final String LOG_TAG = "TelephonyTester";
  protected BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      TelephonyTester.log("sIntentReceiver.onReceive: action=" + str);
      if (str.equals(TelephonyTester.this.mPhone.getActionDetached()))
      {
        TelephonyTester.log("simulate detaching");
        TelephonyTester.this.mPhone.getServiceStateTracker().mDetachedRegistrants.notifyRegistrants();
      }
      while (true)
      {
        return;
        if (str.equals(TelephonyTester.this.mPhone.getActionAttached()))
        {
          TelephonyTester.log("simulate attaching");
          TelephonyTester.this.mPhone.getServiceStateTracker().mAttachedRegistrants.notifyRegistrants();
        }
        else
        {
          TelephonyTester.log("onReceive: unknown action=" + str);
        }
      }
    }
  };
  private PhoneBase mPhone;

  TelephonyTester(PhoneBase paramPhoneBase)
  {
    this.mPhone = paramPhoneBase;
    if (Build.IS_DEBUGGABLE)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(this.mPhone.getActionDetached());
      log("register for intent action=" + this.mPhone.getActionDetached());
      localIntentFilter.addAction(this.mPhone.getActionAttached());
      log("register for intent action=" + this.mPhone.getActionAttached());
      paramPhoneBase.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter, null, this.mPhone.getHandler());
    }
  }

  private static void log(String paramString)
  {
    Rlog.d("TelephonyTester", paramString);
  }

  void dispose()
  {
    if (Build.IS_DEBUGGABLE)
      this.mPhone.getContext().unregisterReceiver(this.mIntentReceiver);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.TelephonyTester
 * JD-Core Version:    0.6.2
 */