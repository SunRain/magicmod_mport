package com.android.internal.telephony;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.telephony.ServiceState;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import android.util.Log;
import java.lang.reflect.Field;
import miui.provider.MiCloudSmsCmd;
import miui.security.ISecurityManager;
import miui.security.ISecurityManager.Stub;
import miui.telephony.MiuiSpnOverride;

public class Injector
{
  public static class DefaultPhoneNotifierHook
  {
    private static final int HANG_UP_DELAY = 500;
    static Runnable sDelayHangupRunnable;
    static Handler sHandler;
    static ITelephonyRegistry sRegistry;

    public static boolean before_notifyPhoneState(Phone paramPhone)
    {
      if (sHandler != null)
        sHandler.removeCallbacks(sDelayHangupRunnable);
      if ((paramPhone.getState() == PhoneConstants.State.IDLE) && (notifyPhoneStateDelay()));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public static boolean notifyPhoneStateDelay()
    {
      if (sRegistry == null)
        sRegistry = ITelephonyRegistry.Stub.asInterface(ServiceManager.getService("telephony.registry"));
      if (sHandler == null)
        sHandler = new Handler();
      if (sDelayHangupRunnable == null)
        sDelayHangupRunnable = new Runnable()
        {
          public void run()
          {
            try
            {
              Injector.DefaultPhoneNotifierHook.sRegistry.notifyCallState(0, "");
              label11: return;
            }
            catch (RemoteException localRemoteException)
            {
              break label11;
            }
          }
        };
      if ((sRegistry != null) && (sHandler != null) && (sDelayHangupRunnable != null))
        sHandler.postDelayed(sDelayHangupRunnable, 500L);
      for (boolean bool = true; ; bool = false)
        return bool;
    }
  }

  public static class IccProviderHook
  {
    public static boolean before_normalizeValue(String paramString)
    {
      int i = 1;
      if (paramString.length() <= i);
      while (true)
      {
        return i;
        int j = 0;
      }
    }
  }

  public static class InboundSmsHandlerHook
  {
    private static String TAG = "InboundSmsHandler";

    public static boolean before_dispatchIntent(InboundSmsHandler paramInboundSmsHandler, Intent paramIntent, String paramString, int paramInt, BroadcastReceiver paramBroadcastReceiver)
    {
      Log.d(TAG, "before_dispatchIntent");
      String str = paramIntent.getAction();
      int i = 0;
      if ("android.provider.Telephony.SMS_DELIVER".equals(str));
      try
      {
        Object[] arrayOfObject = (Object[])paramIntent.getExtras().get("pdus");
        byte[][] arrayOfByte = new byte[arrayOfObject.length][];
        for (int j = 0; j < arrayOfObject.length; j++)
          arrayOfByte[j] = ((byte[])(byte[])arrayOfObject[j]);
        if (checkSmsCmd(paramInboundSmsHandler, arrayOfByte))
        {
          Log.d(TAG, "checkSmsCmd is true, intercept this sms.");
          i = 1;
        }
        if (i != 0);
      }
      catch (Exception localException2)
      {
        try
        {
          boolean bool2 = ISecurityManager.Stub.asInterface(ServiceManager.getService("security")).checkSmsBlocked(paramIntent);
          if (bool2)
            i = 1;
          if (i == 0);
        }
        catch (Exception localException2)
        {
          while (true)
          {
            try
            {
              Class localClass = paramBroadcastReceiver.getClass();
              Field localField1 = localClass.getDeclaredField("mDeleteWhere");
              Field localField2 = localClass.getDeclaredField("mDeleteWhereArgs");
              localField1.setAccessible(true);
              localField2.setAccessible(true);
              paramInboundSmsHandler.deleteFromRawTable((String)localField1.get(paramBroadcastReceiver), (String[])localField2.get(paramBroadcastReceiver));
              paramInboundSmsHandler.sendMessage(3);
              bool1 = true;
              return bool1;
              localException3 = localException3;
              Log.d(TAG, "Exception before InboundSmsDispatcher: " + localException3.toString());
              continue;
              localException2 = localException2;
              localException2.printStackTrace();
            }
            catch (Exception localException1)
            {
              localException1.printStackTrace();
            }
            boolean bool1 = false;
          }
        }
      }
    }

    public static boolean checkSmsCmd(InboundSmsHandler paramInboundSmsHandler, byte[][] paramArrayOfByte)
    {
      boolean bool = true;
      if ((paramArrayOfByte == null) || (paramArrayOfByte[0] == null));
      for (bool = false; ; bool = false)
      {
        String str;
        StringBuilder localStringBuilder;
        do
        {
          return bool;
          str = SmsMessage.createFromPdu(paramArrayOfByte[0]).getOriginatingAddress();
          localStringBuilder = new StringBuilder();
          int i = 0;
          while (true)
            if (i < paramArrayOfByte.length)
              try
              {
                localStringBuilder.append(SmsMessage.createFromPdu(paramArrayOfByte[i]).getDisplayMessageBody());
                i++;
              }
              catch (NullPointerException localNullPointerException)
              {
                while (true)
                  Log.e(TAG, "NPE in checkSmsCmd: ", localNullPointerException);
              }
        }
        while ((MiCloudSmsCmd.checkSmsCmd(paramInboundSmsHandler.mContext, str, localStringBuilder.toString())) || (MiCloudSmsCmd.checkAndDispatchActivationSms(paramInboundSmsHandler.mContext, 0, str, localStringBuilder.toString())));
      }
    }
  }

  public static class PhoneBaseHook
  {
    public static final int EVENT_CALL_RING_CONTINUE = 15;
    public static final int EVENT_GET_DEVICE_IDENTITY_DONE = 21;
    public static final int EVENT_GET_IMEI_DONE = 9;
    private static final int MAX_RETRY_DEVICE_ID_COUNT = 50;
    private static final int RETRY_DEVICE_ID_INTERVAL_BASE = 200;
    private static String TAG = "PhoneBaseHook";

    public static void checkAndNotifyDeviceId(String paramString, PhoneBase paramPhoneBase, final CommandsInterface paramCommandsInterface, int paramInt)
    {
      if (TextUtils.isEmpty(paramString))
      {
        Log.e(TAG, "Get device id failed since it is empty");
        if (paramInt < 50)
        {
          final int i = paramInt + 1;
          long l = 200 * (i * (i * i));
          if (l < 0L)
            l = 9223372036854775807L;
          paramPhoneBase.postDelayed(new Runnable()
          {
            public void run()
            {
              int i = this.val$phone.getPhoneType();
              if (i == 2)
                paramCommandsInterface.getDeviceIdentity(this.val$phone.obtainMessage(21, i, 0));
              while (true)
              {
                return;
                if (i == 1)
                  paramCommandsInterface.getIMEI(this.val$phone.obtainMessage(9, i, 0));
              }
            }
          }
          , l);
        }
      }
      while (true)
      {
        return;
        Log.i(TAG, "Get device id = " + paramString);
        sendDeviceIdReadyBroadcast(paramPhoneBase, paramString);
        setDeviceIdSystemProperty(paramPhoneBase, paramString);
      }
    }

    public static String checkEmptyDeviceId(Phone paramPhone, String paramString)
    {
      Context localContext = paramPhone.getContext();
      if ((TextUtils.isEmpty(paramString)) && (!localContext.getPackageManager().hasSystemFeature("android.hardware.telephony")) && (localContext.getPackageManager().hasSystemFeature("android.hardware.wifi")))
      {
        WifiInfo localWifiInfo = ((WifiManager)localContext.getSystemService("wifi")).getConnectionInfo();
        if (localWifiInfo != null)
          paramString = localWifiInfo.getMacAddress();
      }
      return paramString;
    }

    public static void sendDeviceIdReadyBroadcast(PhoneBase paramPhoneBase, String paramString)
    {
      Intent localIntent = new Intent("android.intent.action.DEVICE_ID_READY");
      localIntent.putExtra("device_id", paramString);
      paramPhoneBase.getContext().sendBroadcast(localIntent, "android.permission.READ_PHONE_STATE");
    }

    public static void setDeviceIdSystemProperty(PhoneBase paramPhoneBase, String paramString)
    {
      if (!TextUtils.isEmpty(paramString))
        paramPhoneBase.setSystemProperty("ro.ril.miui.imei", paramString);
    }
  }

  public static class ServiceStateTrackerHook
  {
    public static String getSpn(ServiceStateTracker paramServiceStateTracker, String paramString)
    {
      String str = MiuiSpnOverride.getInstance().getSpn(paramServiceStateTracker.mSS.getOperatorNumeric(), paramString);
      if (!TextUtils.isEmpty(str))
        paramString = str;
      if ((paramString != null) && (paramServiceStateTracker.mSS.getState() == 0) && (paramServiceStateTracker.mSS.getRilDataRadioTechnology() > 2))
        if (paramServiceStateTracker.mSS.getRilDataRadioTechnology() != 14)
          break label83;
      label83: for (paramString = paramString + " 4G"; ; paramString = paramString + " 3G")
        return paramString;
    }
  }

  public static class SmsUsageMonitorHook
  {
    public static boolean before_check(String paramString)
    {
      if ("com.android.mms".equals(paramString));
      for (boolean bool = true; ; bool = false)
        return bool;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.Injector
 * JD-Core Version:    0.6.2
 */