package com.android.internal.telephony;

import android.content.ContentValues;
import android.database.Cursor;
import com.android.internal.util.HexDump;
import java.util.Arrays;
import java.util.Date;

public final class InboundSmsTracker
{
  private static final int DEST_PORT_FLAG_3GPP = 131072;
  private static final int DEST_PORT_FLAG_3GPP2 = 262144;
  private static final int DEST_PORT_FLAG_3GPP2_WAP_PDU = 524288;
  private static final int DEST_PORT_FLAG_NO_PORT = 65536;
  private static final int DEST_PORT_MASK = 65535;
  private final String mAddress;
  private String mDeleteWhere;
  private String[] mDeleteWhereArgs;
  private final int mDestPort;
  private final boolean mIs3gpp2;
  private final boolean mIs3gpp2WapPdu;
  private final int mMessageCount;
  private final byte[] mPdu;
  private final int mReferenceNumber;
  private final int mSequenceNumber;
  private final long mTimestamp;

  InboundSmsTracker(Cursor paramCursor, boolean paramBoolean)
  {
    this.mPdu = HexDump.hexStringToByteArray(paramCursor.getString(0));
    String[] arrayOfString2;
    if (paramCursor.isNull(2))
    {
      this.mDestPort = -1;
      this.mIs3gpp2 = paramBoolean;
      this.mIs3gpp2WapPdu = false;
      this.mTimestamp = paramCursor.getLong(3);
      if (!paramCursor.isNull(5))
        break label201;
      long l = paramCursor.getLong(7);
      this.mAddress = null;
      this.mReferenceNumber = -1;
      this.mSequenceNumber = getIndexOffset();
      this.mMessageCount = 1;
      this.mDeleteWhere = "_id=?";
      arrayOfString2 = new String[1];
      arrayOfString2[0] = Long.toString(l);
    }
    label145: label195: label201: String[] arrayOfString1;
    for (this.mDeleteWhereArgs = arrayOfString2; ; this.mDeleteWhereArgs = arrayOfString1)
    {
      return;
      int i = paramCursor.getInt(2);
      if ((0x20000 & i) != 0)
      {
        this.mIs3gpp2 = false;
        if ((0x80000 & i) == 0)
          break label195;
      }
      for (boolean bool = true; ; bool = false)
      {
        this.mIs3gpp2WapPdu = bool;
        this.mDestPort = getRealDestPort(i);
        break;
        if ((0x40000 & i) != 0)
        {
          this.mIs3gpp2 = true;
          break label145;
        }
        this.mIs3gpp2 = paramBoolean;
        break label145;
      }
      this.mAddress = paramCursor.getString(6);
      this.mReferenceNumber = paramCursor.getInt(4);
      this.mMessageCount = paramCursor.getInt(5);
      this.mSequenceNumber = paramCursor.getInt(1);
      int j = this.mSequenceNumber - getIndexOffset();
      if ((j < 0) || (j >= this.mMessageCount))
        throw new IllegalArgumentException("invalid PDU sequence " + this.mSequenceNumber + " of " + this.mMessageCount);
      this.mDeleteWhere = "address=? AND reference_number=? AND count=?";
      arrayOfString1 = new String[3];
      arrayOfString1[0] = this.mAddress;
      arrayOfString1[1] = Integer.toString(this.mReferenceNumber);
      arrayOfString1[2] = Integer.toString(this.mMessageCount);
    }
  }

  public InboundSmsTracker(byte[] paramArrayOfByte, long paramLong, int paramInt1, boolean paramBoolean1, String paramString, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean2)
  {
    this.mPdu = paramArrayOfByte;
    this.mTimestamp = paramLong;
    this.mDestPort = paramInt1;
    this.mIs3gpp2 = paramBoolean1;
    this.mIs3gpp2WapPdu = paramBoolean2;
    this.mAddress = paramString;
    this.mReferenceNumber = paramInt2;
    this.mSequenceNumber = paramInt3;
    this.mMessageCount = paramInt4;
  }

  InboundSmsTracker(byte[] paramArrayOfByte, long paramLong, int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.mPdu = paramArrayOfByte;
    this.mTimestamp = paramLong;
    this.mDestPort = paramInt;
    this.mIs3gpp2 = paramBoolean1;
    this.mIs3gpp2WapPdu = paramBoolean2;
    this.mAddress = null;
    this.mReferenceNumber = -1;
    this.mSequenceNumber = getIndexOffset();
    this.mMessageCount = 1;
  }

  static int getRealDestPort(int paramInt)
  {
    if ((0x10000 & paramInt) != 0);
    for (int i = -1; ; i = 0xFFFF & paramInt)
      return i;
  }

  String getAddress()
  {
    return this.mAddress;
  }

  ContentValues getContentValues()
  {
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("pdu", HexDump.toHexString(this.mPdu));
    localContentValues.put("date", Long.valueOf(this.mTimestamp));
    int i;
    if (this.mDestPort == -1)
    {
      i = 65536;
      if (!this.mIs3gpp2)
        break label148;
    }
    label148: for (int j = i | 0x40000; ; j = i | 0x20000)
    {
      if (this.mIs3gpp2WapPdu)
        j |= 524288;
      localContentValues.put("destination_port", Integer.valueOf(j));
      if (this.mAddress != null)
      {
        localContentValues.put("address", this.mAddress);
        localContentValues.put("reference_number", Integer.valueOf(this.mReferenceNumber));
        localContentValues.put("sequence", Integer.valueOf(this.mSequenceNumber));
        localContentValues.put("count", Integer.valueOf(this.mMessageCount));
      }
      return localContentValues;
      i = 0xFFFF & this.mDestPort;
      break;
    }
  }

  String getDeleteWhere()
  {
    return this.mDeleteWhere;
  }

  String[] getDeleteWhereArgs()
  {
    return this.mDeleteWhereArgs;
  }

  int getDestPort()
  {
    return this.mDestPort;
  }

  String getFormat()
  {
    if (this.mIs3gpp2);
    for (String str = "3gpp2"; ; str = "3gpp")
      return str;
  }

  int getIndexOffset()
  {
    if ((this.mIs3gpp2) && (this.mIs3gpp2WapPdu));
    for (int i = 0; ; i = 1)
      return i;
  }

  int getMessageCount()
  {
    return this.mMessageCount;
  }

  byte[] getPdu()
  {
    return this.mPdu;
  }

  int getReferenceNumber()
  {
    return this.mReferenceNumber;
  }

  int getSequenceNumber()
  {
    return this.mSequenceNumber;
  }

  long getTimestamp()
  {
    return this.mTimestamp;
  }

  boolean is3gpp2()
  {
    return this.mIs3gpp2;
  }

  void setDeleteWhere(String paramString, String[] paramArrayOfString)
  {
    this.mDeleteWhere = paramString;
    this.mDeleteWhereArgs = paramArrayOfString;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("SmsTracker{timestamp=");
    localStringBuilder.append(new Date(this.mTimestamp));
    localStringBuilder.append(" destPort=").append(this.mDestPort);
    localStringBuilder.append(" is3gpp2=").append(this.mIs3gpp2);
    if (this.mAddress != null)
    {
      localStringBuilder.append(" address=").append(this.mAddress);
      localStringBuilder.append(" refNumber=").append(this.mReferenceNumber);
      localStringBuilder.append(" seqNumber=").append(this.mSequenceNumber);
      localStringBuilder.append(" msgCount=").append(this.mMessageCount);
    }
    if (this.mDeleteWhere != null)
    {
      localStringBuilder.append(" deleteWhere(").append(this.mDeleteWhere);
      localStringBuilder.append(") deleteArgs=(").append(Arrays.toString(this.mDeleteWhereArgs));
      localStringBuilder.append(')');
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.InboundSmsTracker
 * JD-Core Version:    0.6.2
 */