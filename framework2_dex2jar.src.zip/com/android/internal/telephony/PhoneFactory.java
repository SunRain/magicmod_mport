package com.android.internal.telephony;

import android.content.Context;
import android.os.Looper;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.cdma.CDMALTEPhone;
import com.android.internal.telephony.cdma.CDMAPhone;
import com.android.internal.telephony.gsm.GSMPhone;
import com.android.internal.telephony.sip.SipPhone;
import com.android.internal.telephony.sip.SipPhoneFactory;

public class PhoneFactory
{
  static final String LOG_TAG = "PhoneFactory";
  static final int SOCKET_OPEN_MAX_RETRY = 3;
  static final int SOCKET_OPEN_RETRY_MILLIS = 2000;
  private static CommandsInterface sCommandsInterface = null;
  private static Context sContext;
  private static Looper sLooper;
  private static boolean sMadeDefaults = false;
  private static PhoneNotifier sPhoneNotifier;
  private static Phone sProxyPhone = null;

  public static Phone getCdmaPhone()
  {
    synchronized (PhoneProxy.lockForRadioTechnologyChange)
    {
      switch (TelephonyManager.getLteOnCdmaModeStatic())
      {
      default:
        localObject3 = new CDMAPhone(sContext, sCommandsInterface, sPhoneNotifier);
        return localObject3;
      case 1:
      }
      Object localObject3 = new CDMALTEPhone(sContext, sCommandsInterface, sPhoneNotifier);
    }
  }

  public static Phone getDefaultPhone()
  {
    if (sLooper != Looper.myLooper())
      throw new RuntimeException("PhoneFactory.getDefaultPhone must be called from Looper thread");
    if (!sMadeDefaults)
      throw new IllegalStateException("Default phones haven't been made yet!");
    return sProxyPhone;
  }

  public static Phone getGsmPhone()
  {
    synchronized (PhoneProxy.lockForRadioTechnologyChange)
    {
      GSMPhone localGSMPhone = new GSMPhone(sContext, sCommandsInterface, sPhoneNotifier);
      return localGSMPhone;
    }
  }

  // ERROR //
  public static void makeDefaultPhone(Context paramContext)
  {
    // Byte code:
    //   0: ldc 95
    //   2: monitorenter
    //   3: getstatic 33	com/android/internal/telephony/PhoneFactory:sMadeDefaults	Z
    //   6: ifne +279 -> 285
    //   9: invokestatic 71	android/os/Looper:myLooper	()Landroid/os/Looper;
    //   12: putstatic 65	com/android/internal/telephony/PhoneFactory:sLooper	Landroid/os/Looper;
    //   15: aload_0
    //   16: putstatic 54	com/android/internal/telephony/PhoneFactory:sContext	Landroid/content/Context;
    //   19: getstatic 65	com/android/internal/telephony/PhoneFactory:sLooper	Landroid/os/Looper;
    //   22: ifnonnull +19 -> 41
    //   25: new 73	java/lang/RuntimeException
    //   28: dup
    //   29: ldc 97
    //   31: invokespecial 78	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   34: athrow
    //   35: astore_1
    //   36: ldc 95
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    //   41: iconst_0
    //   42: istore_2
    //   43: iconst_0
    //   44: istore_3
    //   45: iinc 2 1
    //   48: new 99	android/net/LocalServerSocket
    //   51: dup
    //   52: ldc 101
    //   54: invokespecial 102	android/net/LocalServerSocket:<init>	(Ljava/lang/String;)V
    //   57: pop
    //   58: iload_3
    //   59: ifne +230 -> 289
    //   62: new 104	com/android/internal/telephony/DefaultPhoneNotifier
    //   65: dup
    //   66: invokespecial 105	com/android/internal/telephony/DefaultPhoneNotifier:<init>	()V
    //   69: putstatic 56	com/android/internal/telephony/PhoneFactory:sPhoneNotifier	Lcom/android/internal/telephony/PhoneNotifier;
    //   72: iconst_0
    //   73: istore 6
    //   75: invokestatic 50	android/telephony/TelephonyManager:getLteOnCdmaModeStatic	()I
    //   78: iconst_1
    //   79: if_icmpne +7 -> 86
    //   82: bipush 7
    //   84: istore 6
    //   86: aload_0
    //   87: invokevirtual 111	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   90: ldc 113
    //   92: iload 6
    //   94: invokestatic 119	android/provider/Settings$Global:getInt	(Landroid/content/ContentResolver;Ljava/lang/String;I)I
    //   97: istore 7
    //   99: ldc 8
    //   101: new 121	java/lang/StringBuilder
    //   104: dup
    //   105: invokespecial 122	java/lang/StringBuilder:<init>	()V
    //   108: ldc 124
    //   110: invokevirtual 128	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: iload 7
    //   115: invokestatic 134	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   118: invokevirtual 128	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: invokevirtual 137	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   124: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   127: pop
    //   128: aload_0
    //   129: invokestatic 149	com/android/internal/telephony/cdma/CdmaSubscriptionSourceManager:getDefault	(Landroid/content/Context;)I
    //   132: istore 9
    //   134: ldc 8
    //   136: new 121	java/lang/StringBuilder
    //   139: dup
    //   140: invokespecial 122	java/lang/StringBuilder:<init>	()V
    //   143: ldc 151
    //   145: invokevirtual 128	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: iload 9
    //   150: invokevirtual 154	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   153: invokevirtual 137	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   156: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   159: pop
    //   160: new 156	com/android/internal/telephony/RIL
    //   163: dup
    //   164: aload_0
    //   165: iload 7
    //   167: iload 9
    //   169: invokespecial 159	com/android/internal/telephony/RIL:<init>	(Landroid/content/Context;II)V
    //   172: putstatic 31	com/android/internal/telephony/PhoneFactory:sCommandsInterface	Lcom/android/internal/telephony/CommandsInterface;
    //   175: aload_0
    //   176: getstatic 31	com/android/internal/telephony/PhoneFactory:sCommandsInterface	Lcom/android/internal/telephony/CommandsInterface;
    //   179: invokestatic 165	com/android/internal/telephony/uicc/UiccController:make	(Landroid/content/Context;Lcom/android/internal/telephony/CommandsInterface;)Lcom/android/internal/telephony/uicc/UiccController;
    //   182: pop
    //   183: iload 7
    //   185: invokestatic 169	android/telephony/TelephonyManager:getPhoneType	(I)I
    //   188: istore 12
    //   190: iload 12
    //   192: iconst_1
    //   193: if_icmpne +125 -> 318
    //   196: ldc 8
    //   198: ldc 171
    //   200: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   203: pop
    //   204: new 40	com/android/internal/telephony/PhoneProxy
    //   207: dup
    //   208: new 86	com/android/internal/telephony/gsm/GSMPhone
    //   211: dup
    //   212: aload_0
    //   213: getstatic 31	com/android/internal/telephony/PhoneFactory:sCommandsInterface	Lcom/android/internal/telephony/CommandsInterface;
    //   216: getstatic 56	com/android/internal/telephony/PhoneFactory:sPhoneNotifier	Lcom/android/internal/telephony/PhoneNotifier;
    //   219: invokespecial 87	com/android/internal/telephony/gsm/GSMPhone:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/CommandsInterface;Lcom/android/internal/telephony/PhoneNotifier;)V
    //   222: invokespecial 174	com/android/internal/telephony/PhoneProxy:<init>	(Lcom/android/internal/telephony/PhoneBase;)V
    //   225: putstatic 29	com/android/internal/telephony/PhoneFactory:sProxyPhone	Lcom/android/internal/telephony/Phone;
    //   228: aload_0
    //   229: iconst_1
    //   230: invokestatic 180	com/android/internal/telephony/SmsApplication:getDefaultSmsApplication	(Landroid/content/Context;Z)Landroid/content/ComponentName;
    //   233: astore 14
    //   235: ldc 182
    //   237: astore 15
    //   239: aload 14
    //   241: ifnull +10 -> 251
    //   244: aload 14
    //   246: invokevirtual 187	android/content/ComponentName:getPackageName	()Ljava/lang/String;
    //   249: astore 15
    //   251: ldc 8
    //   253: new 121	java/lang/StringBuilder
    //   256: dup
    //   257: invokespecial 122	java/lang/StringBuilder:<init>	()V
    //   260: ldc 189
    //   262: invokevirtual 128	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: aload 15
    //   267: invokevirtual 128	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: invokevirtual 137	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   273: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   276: pop
    //   277: aload_0
    //   278: invokestatic 192	com/android/internal/telephony/SmsApplication:initSmsPackageMonitor	(Landroid/content/Context;)V
    //   281: iconst_1
    //   282: putstatic 33	com/android/internal/telephony/PhoneFactory:sMadeDefaults	Z
    //   285: ldc 95
    //   287: monitorexit
    //   288: return
    //   289: iload_2
    //   290: iconst_3
    //   291: if_icmple +13 -> 304
    //   294: new 73	java/lang/RuntimeException
    //   297: dup
    //   298: ldc 194
    //   300: invokespecial 78	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   303: athrow
    //   304: ldc2_w 195
    //   307: invokestatic 202	java/lang/Thread:sleep	(J)V
    //   310: goto -267 -> 43
    //   313: astore 5
    //   315: goto -272 -> 43
    //   318: iload 12
    //   320: iconst_2
    //   321: if_icmpne -93 -> 228
    //   324: invokestatic 50	android/telephony/TelephonyManager:getLteOnCdmaModeStatic	()I
    //   327: tableswitch	default:+17 -> 344, 1:+52->379
    //   345: iconst_5
    //   346: ldc 204
    //   348: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   351: pop
    //   352: new 40	com/android/internal/telephony/PhoneProxy
    //   355: dup
    //   356: new 52	com/android/internal/telephony/cdma/CDMAPhone
    //   359: dup
    //   360: aload_0
    //   361: getstatic 31	com/android/internal/telephony/PhoneFactory:sCommandsInterface	Lcom/android/internal/telephony/CommandsInterface;
    //   364: getstatic 56	com/android/internal/telephony/PhoneFactory:sPhoneNotifier	Lcom/android/internal/telephony/PhoneNotifier;
    //   367: invokespecial 59	com/android/internal/telephony/cdma/CDMAPhone:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/CommandsInterface;Lcom/android/internal/telephony/PhoneNotifier;)V
    //   370: invokespecial 174	com/android/internal/telephony/PhoneProxy:<init>	(Lcom/android/internal/telephony/PhoneBase;)V
    //   373: putstatic 29	com/android/internal/telephony/PhoneFactory:sProxyPhone	Lcom/android/internal/telephony/Phone;
    //   376: goto -148 -> 228
    //   379: ldc 8
    //   381: ldc 206
    //   383: invokestatic 143	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   386: pop
    //   387: new 40	com/android/internal/telephony/PhoneProxy
    //   390: dup
    //   391: new 61	com/android/internal/telephony/cdma/CDMALTEPhone
    //   394: dup
    //   395: aload_0
    //   396: getstatic 31	com/android/internal/telephony/PhoneFactory:sCommandsInterface	Lcom/android/internal/telephony/CommandsInterface;
    //   399: getstatic 56	com/android/internal/telephony/PhoneFactory:sPhoneNotifier	Lcom/android/internal/telephony/PhoneNotifier;
    //   402: invokespecial 62	com/android/internal/telephony/cdma/CDMALTEPhone:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/CommandsInterface;Lcom/android/internal/telephony/PhoneNotifier;)V
    //   405: invokespecial 174	com/android/internal/telephony/PhoneProxy:<init>	(Lcom/android/internal/telephony/PhoneBase;)V
    //   408: putstatic 29	com/android/internal/telephony/PhoneFactory:sProxyPhone	Lcom/android/internal/telephony/Phone;
    //   411: goto -183 -> 228
    //   414: astore 19
    //   416: iconst_1
    //   417: istore_3
    //   418: goto -360 -> 58
    //
    // Exception table:
    //   from	to	target	type
    //   3	39	35	finally
    //   48	58	35	finally
    //   62	304	35	finally
    //   304	310	35	finally
    //   324	411	35	finally
    //   304	310	313	java/lang/InterruptedException
    //   48	58	414	java/io/IOException
  }

  public static void makeDefaultPhones(Context paramContext)
  {
    makeDefaultPhone(paramContext);
  }

  public static SipPhone makeSipPhone(String paramString)
  {
    return SipPhoneFactory.makePhone(paramString, sContext, sPhoneNotifier);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.PhoneFactory
 * JD-Core Version:    0.6.2
 */