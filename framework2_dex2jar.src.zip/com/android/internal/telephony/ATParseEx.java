package com.android.internal.telephony;

public class ATParseEx extends RuntimeException
{
  public ATParseEx()
  {
  }

  public ATParseEx(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.ATParseEx
 * JD-Core Version:    0.6.2
 */