package com.android.internal.telephony;

public class ATResponseParser
{
  private String mLine;
  private int mNext = 0;
  private int mTokEnd;
  private int mTokStart;

  public ATResponseParser(String paramString)
  {
    this.mLine = paramString;
  }

  private void nextTok()
  {
    int i = this.mLine.length();
    if (this.mNext == 0)
      skipPrefix();
    if (this.mNext >= i)
      throw new ATParseEx();
    char c1;
    try
    {
      String str1 = this.mLine;
      int j = this.mNext;
      this.mNext = (j + 1);
      c1 = skipWhiteSpace(str1.charAt(j));
      if (c1 != '"')
        break label257;
      if (this.mNext >= i)
        throw new ATParseEx();
    }
    catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
    {
      throw new ATParseEx();
    }
    String str3 = this.mLine;
    int m = this.mNext;
    this.mNext = (m + 1);
    int n = str3.charAt(m);
    this.mTokStart = (-1 + this.mNext);
    while ((n != 34) && (this.mNext < i))
    {
      String str5 = this.mLine;
      int i2 = this.mNext;
      this.mNext = (i2 + 1);
      n = str5.charAt(i2);
    }
    if (n != 34)
      throw new ATParseEx();
    this.mTokEnd = (-1 + this.mNext);
    if (this.mNext < i)
    {
      String str4 = this.mLine;
      int i1 = this.mNext;
      this.mNext = (i1 + 1);
      if (str4.charAt(i1) != ',')
      {
        throw new ATParseEx();
        label257: this.mTokStart = (-1 + this.mNext);
        this.mTokEnd = this.mTokStart;
        while (c1 != ',')
        {
          if (!Character.isWhitespace(c1))
            this.mTokEnd = this.mNext;
          if (this.mNext == i)
            break;
          String str2 = this.mLine;
          int k = this.mNext;
          this.mNext = (k + 1);
          char c2 = str2.charAt(k);
          c1 = c2;
        }
      }
    }
  }

  private void skipPrefix()
  {
    this.mNext = 0;
    int i = this.mLine.length();
    while (this.mNext < i)
    {
      String str = this.mLine;
      int j = this.mNext;
      this.mNext = (j + 1);
      if (str.charAt(j) == ':')
        return;
    }
    throw new ATParseEx("missing prefix");
  }

  private char skipWhiteSpace(char paramChar)
  {
    int i = this.mLine.length();
    while ((this.mNext < i) && (Character.isWhitespace(paramChar)))
    {
      String str = this.mLine;
      int j = this.mNext;
      this.mNext = (j + 1);
      paramChar = str.charAt(j);
    }
    if (Character.isWhitespace(paramChar))
      throw new ATParseEx();
    return paramChar;
  }

  public boolean hasMore()
  {
    if (this.mNext < this.mLine.length());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean nextBoolean()
  {
    int i = 1;
    nextTok();
    if (this.mTokEnd - this.mTokStart > i)
      throw new ATParseEx();
    int j = this.mLine.charAt(this.mTokStart);
    if (j == 48)
      i = 0;
    while (j == 49)
      return i;
    throw new ATParseEx();
  }

  public int nextInt()
  {
    int i = 0;
    nextTok();
    for (int j = this.mTokStart; j < this.mTokEnd; j++)
    {
      int k = this.mLine.charAt(j);
      if ((k < 48) || (k > 57))
        throw new ATParseEx();
      i = i * 10 + (k - 48);
    }
    return i;
  }

  public String nextString()
  {
    nextTok();
    return this.mLine.substring(this.mTokStart, this.mTokEnd);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.ATResponseParser
 * JD-Core Version:    0.6.2
 */