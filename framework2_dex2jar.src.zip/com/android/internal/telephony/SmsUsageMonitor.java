package com.android.internal.telephony;

import android.app.AppGlobals;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.IPackageManager;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.database.ContentObserver;
import android.os.Binder;
import android.os.Handler;
import android.os.RemoteException;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.telephony.Rlog;
import android.util.AtomicFile;
import android.util.Xml;
import com.android.internal.util.FastXmlSerializer;
import com.android.internal.util.XmlUtils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public class SmsUsageMonitor
{
  private static final String ATTR_COUNTRY = "country";
  private static final String ATTR_FREE = "free";
  private static final String ATTR_PACKAGE_NAME = "name";
  private static final String ATTR_PACKAGE_SMS_POLICY = "sms-policy";
  private static final String ATTR_PATTERN = "pattern";
  private static final String ATTR_PREMIUM = "premium";
  private static final String ATTR_STANDARD = "standard";
  static final int CATEGORY_FREE_SHORT_CODE = 1;
  static final int CATEGORY_NOT_SHORT_CODE = 0;
  static final int CATEGORY_POSSIBLE_PREMIUM_SHORT_CODE = 3;
  static final int CATEGORY_PREMIUM_SHORT_CODE = 4;
  static final int CATEGORY_STANDARD_SHORT_CODE = 2;
  private static final boolean DBG = false;
  private static final int DEFAULT_SMS_CHECK_PERIOD = 60000;
  private static final int DEFAULT_SMS_MAX_COUNT = 30;
  public static final int PREMIUM_SMS_PERMISSION_ALWAYS_ALLOW = 3;
  public static final int PREMIUM_SMS_PERMISSION_ASK_USER = 1;
  public static final int PREMIUM_SMS_PERMISSION_NEVER_ALLOW = 2;
  public static final int PREMIUM_SMS_PERMISSION_UNKNOWN = 0;
  private static final String SHORT_CODE_PATH = "/data/misc/sms/codes";
  private static final String SMS_POLICY_FILE_DIRECTORY = "/data/misc/sms";
  private static final String SMS_POLICY_FILE_NAME = "premium_sms_policy.xml";
  private static final String TAG = "SmsUsageMonitor";
  private static final String TAG_PACKAGE = "package";
  private static final String TAG_SHORTCODE = "shortcode";
  private static final String TAG_SHORTCODES = "shortcodes";
  private static final String TAG_SMS_POLICY_BODY = "premium-sms-policy";
  private static final boolean VDBG;
  private final AtomicBoolean mCheckEnabled = new AtomicBoolean(true);
  private final int mCheckPeriod;
  private final Context mContext;
  private String mCurrentCountry;
  private ShortCodePatternMatcher mCurrentPatternMatcher;
  private final int mMaxAllowed;
  private final File mPatternFile = new File("/data/misc/sms/codes");
  private long mPatternFileLastModified = 0L;
  private AtomicFile mPolicyFile;
  private final HashMap<String, Integer> mPremiumSmsPolicy = new HashMap();
  private final SettingsObserverHandler mSettingsObserverHandler;
  private final HashMap<String, ArrayList<Long>> mSmsStamp = new HashMap();

  public SmsUsageMonitor(Context paramContext)
  {
    this.mContext = paramContext;
    ContentResolver localContentResolver = paramContext.getContentResolver();
    this.mMaxAllowed = Settings.Global.getInt(localContentResolver, "sms_outgoing_check_max_count", 30);
    this.mCheckPeriod = Settings.Global.getInt(localContentResolver, "sms_outgoing_check_interval_ms", 60000);
    this.mSettingsObserverHandler = new SettingsObserverHandler(this.mContext, this.mCheckEnabled);
    loadPremiumSmsPolicyDb();
  }

  private static void checkCallerIsSystemOrPhoneApp()
  {
    int i = Binder.getCallingUid();
    int j = UserHandle.getAppId(i);
    if ((j == 1000) || (j == 1001) || (i == 0))
      return;
    throw new SecurityException("Disallowed call for uid " + i);
  }

  private static void checkCallerIsSystemOrSameApp(String paramString)
  {
    int i = Binder.getCallingUid();
    if ((UserHandle.getAppId(i) == 1000) || (i == 0));
    while (true)
    {
      return;
      try
      {
        ApplicationInfo localApplicationInfo = AppGlobals.getPackageManager().getApplicationInfo(paramString, 0, UserHandle.getCallingUserId());
        if (UserHandle.isSameApp(localApplicationInfo.uid, i))
          continue;
        throw new SecurityException("Calling uid " + i + " gave package" + paramString + " which is owned by uid " + localApplicationInfo.uid);
      }
      catch (RemoteException localRemoteException)
      {
        throw new SecurityException("Unknown package " + paramString + "\n" + localRemoteException);
      }
    }
  }

  // ERROR //
  private ShortCodePatternMatcher getPatternMatcherFromFile(String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: new 241	java/io/FileReader
    //   5: dup
    //   6: aload_0
    //   7: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   10: invokespecial 244	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   13: astore_3
    //   14: invokestatic 250	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   17: astore 12
    //   19: aload 12
    //   21: aload_3
    //   22: invokeinterface 256 2 0
    //   27: aload_0
    //   28: aload 12
    //   30: aload_1
    //   31: invokespecial 260	com/android/internal/telephony/SmsUsageMonitor:getPatternMatcherFromXmlParser	(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   34: astore 13
    //   36: aload 13
    //   38: astore 8
    //   40: aload_0
    //   41: aload_0
    //   42: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   45: invokevirtual 264	java/io/File:lastModified	()J
    //   48: putfield 120	com/android/internal/telephony/SmsUsageMonitor:mPatternFileLastModified	J
    //   51: aload_3
    //   52: ifnull +7 -> 59
    //   55: aload_3
    //   56: invokevirtual 267	java/io/FileReader:close	()V
    //   59: aload 8
    //   61: areturn
    //   62: astore 15
    //   64: ldc 59
    //   66: ldc_w 269
    //   69: invokestatic 275	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   72: pop
    //   73: aload_0
    //   74: aload_0
    //   75: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   78: invokevirtual 264	java/io/File:lastModified	()J
    //   81: putfield 120	com/android/internal/telephony/SmsUsageMonitor:mPatternFileLastModified	J
    //   84: aload_2
    //   85: ifnull +7 -> 92
    //   88: aload_2
    //   89: invokevirtual 267	java/io/FileReader:close	()V
    //   92: aconst_null
    //   93: astore 8
    //   95: goto -36 -> 59
    //   98: astore 10
    //   100: ldc 59
    //   102: ldc_w 277
    //   105: aload 10
    //   107: invokestatic 280	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   110: pop
    //   111: aload_0
    //   112: aload_0
    //   113: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   116: invokevirtual 264	java/io/File:lastModified	()J
    //   119: putfield 120	com/android/internal/telephony/SmsUsageMonitor:mPatternFileLastModified	J
    //   122: aload_2
    //   123: ifnull -31 -> 92
    //   126: aload_2
    //   127: invokevirtual 267	java/io/FileReader:close	()V
    //   130: goto -38 -> 92
    //   133: astore 9
    //   135: goto -43 -> 92
    //   138: astore 5
    //   140: aload_0
    //   141: aload_0
    //   142: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   145: invokevirtual 264	java/io/File:lastModified	()J
    //   148: putfield 120	com/android/internal/telephony/SmsUsageMonitor:mPatternFileLastModified	J
    //   151: aload_2
    //   152: ifnull +7 -> 159
    //   155: aload_2
    //   156: invokevirtual 267	java/io/FileReader:close	()V
    //   159: aload 5
    //   161: athrow
    //   162: astore 6
    //   164: goto -5 -> 159
    //   167: astore 14
    //   169: goto -110 -> 59
    //   172: astore 5
    //   174: aload_3
    //   175: astore_2
    //   176: goto -36 -> 140
    //   179: astore 10
    //   181: aload_3
    //   182: astore_2
    //   183: goto -83 -> 100
    //   186: astore 4
    //   188: aload_3
    //   189: astore_2
    //   190: goto -126 -> 64
    //
    // Exception table:
    //   from	to	target	type
    //   2	14	62	java/io/FileNotFoundException
    //   2	14	98	org/xmlpull/v1/XmlPullParserException
    //   88	92	133	java/io/IOException
    //   126	130	133	java/io/IOException
    //   2	14	138	finally
    //   64	73	138	finally
    //   100	111	138	finally
    //   155	159	162	java/io/IOException
    //   55	59	167	java/io/IOException
    //   14	36	172	finally
    //   14	36	179	org/xmlpull/v1/XmlPullParserException
    //   14	36	186	java/io/FileNotFoundException
  }

  private ShortCodePatternMatcher getPatternMatcherFromResource(String paramString)
  {
    XmlResourceParser localXmlResourceParser = null;
    try
    {
      localXmlResourceParser = this.mContext.getResources().getXml(17760271);
      ShortCodePatternMatcher localShortCodePatternMatcher = getPatternMatcherFromXmlParser(localXmlResourceParser, paramString);
      return localShortCodePatternMatcher;
    }
    finally
    {
      if (localXmlResourceParser != null)
        localXmlResourceParser.close();
    }
  }

  private ShortCodePatternMatcher getPatternMatcherFromXmlParser(XmlPullParser paramXmlPullParser, String paramString)
  {
    ShortCodePatternMatcher localShortCodePatternMatcher;
    try
    {
      XmlUtils.beginDocument(paramXmlPullParser, "shortcodes");
      do
      {
        XmlUtils.nextElement(paramXmlPullParser);
        str = paramXmlPullParser.getName();
        if (str == null)
        {
          Rlog.e("SmsUsageMonitor", "Parsing pattern data found null");
          break label166;
        }
        if (!str.equals("shortcode"))
          break;
      }
      while (!paramString.equals(paramXmlPullParser.getAttributeValue(null, "country")));
      localShortCodePatternMatcher = new ShortCodePatternMatcher(paramXmlPullParser.getAttributeValue(null, "pattern"), paramXmlPullParser.getAttributeValue(null, "premium"), paramXmlPullParser.getAttributeValue(null, "free"), paramXmlPullParser.getAttributeValue(null, "standard"));
    }
    catch (XmlPullParserException localXmlPullParserException)
    {
      while (true)
      {
        String str;
        Rlog.e("SmsUsageMonitor", "XML parser exception reading short code patterns", localXmlPullParserException);
        break;
        Rlog.e("SmsUsageMonitor", "Error: skipping unknown XML tag " + str);
      }
    }
    catch (IOException localIOException)
    {
      Rlog.e("SmsUsageMonitor", "I/O exception reading short code patterns", localIOException);
      label166: localShortCodePatternMatcher = null;
    }
    return localShortCodePatternMatcher;
  }

  private boolean isUnderLimit(ArrayList<Long> paramArrayList, int paramInt)
  {
    Long localLong = Long.valueOf(System.currentTimeMillis());
    long l = localLong.longValue() - this.mCheckPeriod;
    while ((!paramArrayList.isEmpty()) && (((Long)paramArrayList.get(0)).longValue() < l))
      paramArrayList.remove(0);
    if (paramInt + paramArrayList.size() <= this.mMaxAllowed)
      for (int i = 0; i < paramInt; i++)
        paramArrayList.add(localLong);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void loadPremiumSmsPolicyDb()
  {
    FileInputStream localFileInputStream;
    synchronized (this.mPremiumSmsPolicy)
    {
      if (this.mPolicyFile == null)
      {
        this.mPolicyFile = new AtomicFile(new File(new File("/data/misc/sms"), "premium_sms_policy.xml"));
        this.mPremiumSmsPolicy.clear();
        localFileInputStream = null;
      }
    }
    try
    {
      localFileInputStream = this.mPolicyFile.openRead();
      localXmlPullParser = Xml.newPullParser();
      localXmlPullParser.setInput(localFileInputStream, null);
      XmlUtils.beginDocument(localXmlPullParser, "premium-sms-policy");
      XmlUtils.nextElement(localXmlPullParser);
      str1 = localXmlPullParser.getName();
      if (str1 != null);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      XmlPullParser localXmlPullParser;
      while (str3 == null)
        Rlog.e("SmsUsageMonitor", "Error: missing package policy attribute");
    }
    catch (IOException localIOException3)
    {
      while (true)
      {
        String str2;
        String str3;
        Rlog.e("SmsUsageMonitor", "Unable to read premium SMS policy database", localIOException3);
        if (localFileInputStream != null)
        {
          localFileInputStream.close();
          continue;
          localObject1 = finally;
          throw localObject1;
          try
          {
            this.mPremiumSmsPolicy.put(str2, Integer.valueOf(Integer.parseInt(str3)));
          }
          catch (NumberFormatException localNumberFormatException2)
          {
            Rlog.e("SmsUsageMonitor", "Error: non-numeric policy type " + str3);
          }
        }
      }
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      while (true)
      {
        String str1;
        Rlog.e("SmsUsageMonitor", "Unable to parse premium SMS policy database", localNumberFormatException1);
        if (localFileInputStream != null)
        {
          localFileInputStream.close();
          continue;
          Rlog.e("SmsUsageMonitor", "Error: skipping unknown XML tag " + str1);
        }
      }
    }
    catch (XmlPullParserException localXmlPullParserException)
    {
      while (true)
      {
        Rlog.e("SmsUsageMonitor", "Unable to parse premium SMS policy database", localXmlPullParserException);
        if (localFileInputStream != null)
          localFileInputStream.close();
      }
    }
    finally
    {
      if (localFileInputStream == null);
    }
    try
    {
      localFileInputStream.close();
      label367: throw localObject2;
    }
    catch (IOException localIOException1)
    {
      break label367;
    }
  }

  private static void log(String paramString)
  {
    Rlog.d("SmsUsageMonitor", paramString);
  }

  public static int mergeShortCodeCategories(int paramInt1, int paramInt2)
  {
    if (paramInt1 > paramInt2);
    while (true)
    {
      return paramInt1;
      paramInt1 = paramInt2;
    }
  }

  // ERROR //
  private void removeExpiredTimestamps()
  {
    // Byte code:
    //   0: invokestatic 338	java/lang/System:currentTimeMillis	()J
    //   3: aload_0
    //   4: getfield 144	com/android/internal/telephony/SmsUsageMonitor:mCheckPeriod	I
    //   7: i2l
    //   8: lsub
    //   9: lstore_1
    //   10: aload_0
    //   11: getfield 104	com/android/internal/telephony/SmsUsageMonitor:mSmsStamp	Ljava/util/HashMap;
    //   14: astore_3
    //   15: aload_3
    //   16: monitorenter
    //   17: aload_0
    //   18: getfield 104	com/android/internal/telephony/SmsUsageMonitor:mSmsStamp	Ljava/util/HashMap;
    //   21: invokevirtual 423	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   24: invokeinterface 429 1 0
    //   29: astore 5
    //   31: aload 5
    //   33: invokeinterface 434 1 0
    //   38: ifeq +71 -> 109
    //   41: aload 5
    //   43: invokeinterface 438 1 0
    //   48: checkcast 440	java/util/Map$Entry
    //   51: invokeinterface 443 1 0
    //   56: checkcast 349	java/util/ArrayList
    //   59: astore 6
    //   61: aload 6
    //   63: invokevirtual 353	java/util/ArrayList:isEmpty	()Z
    //   66: ifne +26 -> 92
    //   69: aload 6
    //   71: iconst_m1
    //   72: aload 6
    //   74: invokevirtual 363	java/util/ArrayList:size	()I
    //   77: iadd
    //   78: invokevirtual 357	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   81: checkcast 340	java/lang/Long
    //   84: invokevirtual 347	java/lang/Long:longValue	()J
    //   87: lload_1
    //   88: lcmp
    //   89: ifge -58 -> 31
    //   92: aload 5
    //   94: invokeinterface 445 1 0
    //   99: goto -68 -> 31
    //   102: astore 4
    //   104: aload_3
    //   105: monitorexit
    //   106: aload 4
    //   108: athrow
    //   109: aload_3
    //   110: monitorexit
    //   111: return
    //
    // Exception table:
    //   from	to	target	type
    //   17	106	102	finally
    //   109	111	102	finally
  }

  private void writePremiumSmsPolicyDb()
  {
    HashMap localHashMap = this.mPremiumSmsPolicy;
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = this.mPolicyFile.startWrite();
      localFastXmlSerializer = new FastXmlSerializer();
      localFastXmlSerializer.setOutput(localFileOutputStream, "utf-8");
      localFastXmlSerializer.startDocument(null, Boolean.valueOf(true));
      localFastXmlSerializer.startTag(null, "premium-sms-policy");
      Iterator localIterator = this.mPremiumSmsPolicy.entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator.next();
        localFastXmlSerializer.startTag(null, "package");
        localFastXmlSerializer.attribute(null, "name", (String)localEntry.getKey());
        localFastXmlSerializer.attribute(null, "sms-policy", ((Integer)localEntry.getValue()).toString());
        localFastXmlSerializer.endTag(null, "package");
      }
    }
    catch (IOException localIOException)
    {
      FastXmlSerializer localFastXmlSerializer;
      Rlog.e("SmsUsageMonitor", "Unable to write premium SMS policy database", localIOException);
      if (localFileOutputStream != null)
        this.mPolicyFile.failWrite(localFileOutputStream);
      while (true)
      {
        return;
        localFastXmlSerializer.endTag(null, "premium-sms-policy");
        localFastXmlSerializer.endDocument();
        this.mPolicyFile.finishWrite(localFileOutputStream);
      }
    }
    finally
    {
    }
  }

  public boolean check(String paramString, int paramInt)
  {
    boolean bool;
    if (Injector.SmsUsageMonitorHook.before_check(paramString))
      bool = true;
    while (true)
    {
      return bool;
      synchronized (this.mSmsStamp)
      {
        removeExpiredTimestamps();
        ArrayList localArrayList = (ArrayList)this.mSmsStamp.get(paramString);
        if (localArrayList == null)
        {
          localArrayList = new ArrayList();
          this.mSmsStamp.put(paramString, localArrayList);
        }
        bool = isUnderLimit(localArrayList, paramInt);
      }
    }
  }

  // ERROR //
  public int checkDestination(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: getfield 151	com/android/internal/telephony/SmsUsageMonitor:mSettingsObserverHandler	Lcom/android/internal/telephony/SmsUsageMonitor$SettingsObserverHandler;
    //   6: astore 4
    //   8: aload 4
    //   10: monitorenter
    //   11: aload_1
    //   12: aload_2
    //   13: invokestatic 519	android/telephony/PhoneNumberUtils:isEmergencyNumber	(Ljava/lang/String;Ljava/lang/String;)Z
    //   16: ifeq +9 -> 25
    //   19: aload 4
    //   21: monitorexit
    //   22: goto +173 -> 195
    //   25: aload_0
    //   26: getfield 111	com/android/internal/telephony/SmsUsageMonitor:mCheckEnabled	Ljava/util/concurrent/atomic/AtomicBoolean;
    //   29: invokevirtual 521	java/util/concurrent/atomic/AtomicBoolean:get	()Z
    //   32: ifne +17 -> 49
    //   35: aload 4
    //   37: monitorexit
    //   38: goto +157 -> 195
    //   41: astore 5
    //   43: aload 4
    //   45: monitorexit
    //   46: aload 5
    //   48: athrow
    //   49: aload_2
    //   50: ifnull +60 -> 110
    //   53: aload_0
    //   54: getfield 523	com/android/internal/telephony/SmsUsageMonitor:mCurrentCountry	Ljava/lang/String;
    //   57: ifnull +29 -> 86
    //   60: aload_2
    //   61: aload_0
    //   62: getfield 523	com/android/internal/telephony/SmsUsageMonitor:mCurrentCountry	Ljava/lang/String;
    //   65: invokevirtual 316	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   68: ifeq +18 -> 86
    //   71: aload_0
    //   72: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   75: invokevirtual 264	java/io/File:lastModified	()J
    //   78: aload_0
    //   79: getfield 120	com/android/internal/telephony/SmsUsageMonitor:mPatternFileLastModified	J
    //   82: lcmp
    //   83: ifeq +27 -> 110
    //   86: aload_0
    //   87: getfield 118	com/android/internal/telephony/SmsUsageMonitor:mPatternFile	Ljava/io/File;
    //   90: invokevirtual 526	java/io/File:exists	()Z
    //   93: ifeq +39 -> 132
    //   96: aload_0
    //   97: aload_0
    //   98: aload_2
    //   99: invokespecial 528	com/android/internal/telephony/SmsUsageMonitor:getPatternMatcherFromFile	(Ljava/lang/String;)Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   102: putfield 530	com/android/internal/telephony/SmsUsageMonitor:mCurrentPatternMatcher	Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   105: aload_0
    //   106: aload_2
    //   107: putfield 523	com/android/internal/telephony/SmsUsageMonitor:mCurrentCountry	Ljava/lang/String;
    //   110: aload_0
    //   111: getfield 530	com/android/internal/telephony/SmsUsageMonitor:mCurrentPatternMatcher	Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   114: ifnull +30 -> 144
    //   117: aload_0
    //   118: getfield 530	com/android/internal/telephony/SmsUsageMonitor:mCurrentPatternMatcher	Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   121: aload_1
    //   122: invokevirtual 533	com/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher:getNumberCategory	(Ljava/lang/String;)I
    //   125: istore_3
    //   126: aload 4
    //   128: monitorexit
    //   129: goto +66 -> 195
    //   132: aload_0
    //   133: aload_0
    //   134: aload_2
    //   135: invokespecial 535	com/android/internal/telephony/SmsUsageMonitor:getPatternMatcherFromResource	(Ljava/lang/String;)Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   138: putfield 530	com/android/internal/telephony/SmsUsageMonitor:mCurrentPatternMatcher	Lcom/android/internal/telephony/SmsUsageMonitor$ShortCodePatternMatcher;
    //   141: goto -36 -> 105
    //   144: ldc 59
    //   146: new 176	java/lang/StringBuilder
    //   149: dup
    //   150: invokespecial 177	java/lang/StringBuilder:<init>	()V
    //   153: ldc_w 537
    //   156: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: aload_2
    //   160: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: ldc_w 539
    //   166: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: invokevirtual 190	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   172: invokestatic 275	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   175: pop
    //   176: aload_1
    //   177: invokevirtual 542	java/lang/String:length	()I
    //   180: iconst_5
    //   181: if_icmpgt +11 -> 192
    //   184: iconst_3
    //   185: istore_3
    //   186: aload 4
    //   188: monitorexit
    //   189: goto +6 -> 195
    //   192: aload 4
    //   194: monitorexit
    //   195: iload_3
    //   196: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   11	46	41	finally
    //   53	195	41	finally
  }

  void dispose()
  {
    this.mSmsStamp.clear();
  }

  public int getPremiumSmsPermission(String paramString)
  {
    checkCallerIsSystemOrSameApp(paramString);
    int i;
    synchronized (this.mPremiumSmsPolicy)
    {
      Integer localInteger = (Integer)this.mPremiumSmsPolicy.get(paramString);
      if (localInteger == null)
        i = 0;
      else
        i = localInteger.intValue();
    }
    return i;
  }

  public void setPremiumSmsPermission(String paramString, int paramInt)
  {
    checkCallerIsSystemOrPhoneApp();
    if ((paramInt < 1) || (paramInt > 3))
      throw new IllegalArgumentException("invalid SMS permission type " + paramInt);
    synchronized (this.mPremiumSmsPolicy)
    {
      this.mPremiumSmsPolicy.put(paramString, Integer.valueOf(paramInt));
      new Thread(new Runnable()
      {
        public void run()
        {
          SmsUsageMonitor.this.writePremiumSmsPolicyDb();
        }
      }).start();
      return;
    }
  }

  private static class SettingsObserver extends ContentObserver
  {
    private final Context mContext;
    private final AtomicBoolean mEnabled;

    SettingsObserver(Handler paramHandler, Context paramContext, AtomicBoolean paramAtomicBoolean)
    {
      super();
      this.mContext = paramContext;
      this.mEnabled = paramAtomicBoolean;
      onChange(false);
    }

    public void onChange(boolean paramBoolean)
    {
      int i = 1;
      AtomicBoolean localAtomicBoolean = this.mEnabled;
      if (Settings.Global.getInt(this.mContext.getContentResolver(), "sms_short_code_confirmation", i) != 0);
      while (true)
      {
        localAtomicBoolean.set(i);
        return;
        int j = 0;
      }
    }
  }

  private static class SettingsObserverHandler extends Handler
  {
    SettingsObserverHandler(Context paramContext, AtomicBoolean paramAtomicBoolean)
    {
      ContentResolver localContentResolver = paramContext.getContentResolver();
      SmsUsageMonitor.SettingsObserver localSettingsObserver = new SmsUsageMonitor.SettingsObserver(this, paramContext, paramAtomicBoolean);
      localContentResolver.registerContentObserver(Settings.Global.getUriFor("sms_short_code_confirmation"), false, localSettingsObserver);
    }
  }

  private static final class ShortCodePatternMatcher
  {
    private final Pattern mFreeShortCodePattern;
    private final Pattern mPremiumShortCodePattern;
    private final Pattern mShortCodePattern;
    private final Pattern mStandardShortCodePattern;

    ShortCodePatternMatcher(String paramString1, String paramString2, String paramString3, String paramString4)
    {
      Pattern localPattern2;
      Pattern localPattern3;
      if (paramString1 != null)
      {
        localPattern2 = Pattern.compile(paramString1);
        this.mShortCodePattern = localPattern2;
        if (paramString2 == null)
          break label80;
        localPattern3 = Pattern.compile(paramString2);
        label33: this.mPremiumShortCodePattern = localPattern3;
        if (paramString3 == null)
          break label86;
      }
      label80: label86: for (Pattern localPattern4 = Pattern.compile(paramString3); ; localPattern4 = null)
      {
        this.mFreeShortCodePattern = localPattern4;
        if (paramString4 != null)
          localPattern1 = Pattern.compile(paramString4);
        this.mStandardShortCodePattern = localPattern1;
        return;
        localPattern2 = null;
        break;
        localPattern3 = null;
        break label33;
      }
    }

    int getNumberCategory(String paramString)
    {
      int i;
      if ((this.mFreeShortCodePattern != null) && (this.mFreeShortCodePattern.matcher(paramString).matches()))
        i = 1;
      while (true)
      {
        return i;
        if ((this.mStandardShortCodePattern != null) && (this.mStandardShortCodePattern.matcher(paramString).matches()))
          i = 2;
        else if ((this.mPremiumShortCodePattern != null) && (this.mPremiumShortCodePattern.matcher(paramString).matches()))
          i = 4;
        else if ((this.mShortCodePattern != null) && (this.mShortCodePattern.matcher(paramString).matches()))
          i = 3;
        else
          i = 0;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsUsageMonitor
 * JD-Core Version:    0.6.2
 */