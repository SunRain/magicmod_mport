package com.android.internal.telephony;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.telephony.Rlog;

public class WapPushOverSms
  implements ServiceConnection
{
  private static final boolean DBG = true;
  private static final String TAG = "WAP PUSH";
  private final Context mContext;
  private volatile IWapPushManager mWapPushManager;

  public WapPushOverSms(Context paramContext)
  {
    this.mContext = paramContext;
    Intent localIntent = new Intent(IWapPushManager.class.getName());
    ComponentName localComponentName = localIntent.resolveSystemService(paramContext.getPackageManager(), 0);
    localIntent.setComponent(localComponentName);
    if ((localComponentName == null) || (!paramContext.bindService(localIntent, this, 1)))
      Rlog.e("WAP PUSH", "bindService() for wappush manager failed");
    while (true)
    {
      return;
      Rlog.v("WAP PUSH", "bindService() for wappush manager succeeded");
    }
  }

  // ERROR //
  public int dispatchWapPdu(byte[] paramArrayOfByte, android.content.BroadcastReceiver paramBroadcastReceiver, InboundSmsHandler paramInboundSmsHandler)
  {
    // Byte code:
    //   0: ldc 13
    //   2: new 76	java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   9: ldc 79
    //   11: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   14: aload_1
    //   15: invokestatic 89	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   18: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   24: invokestatic 95	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   27: pop
    //   28: iconst_0
    //   29: iconst_1
    //   30: iadd
    //   31: istore 5
    //   33: aload_1
    //   34: iconst_0
    //   35: baload
    //   36: istore 10
    //   38: iload 10
    //   40: sipush 255
    //   43: iand
    //   44: istore 11
    //   46: iload 5
    //   48: iconst_1
    //   49: iadd
    //   50: istore 12
    //   52: sipush 255
    //   55: aload_1
    //   56: iload 5
    //   58: baload
    //   59: iand
    //   60: istore 13
    //   62: iload 13
    //   64: bipush 6
    //   66: if_icmpeq +190 -> 256
    //   69: iload 13
    //   71: bipush 7
    //   73: if_icmpeq +183 -> 256
    //   76: aload_0
    //   77: getfield 24	com/android/internal/telephony/WapPushOverSms:mContext	Landroid/content/Context;
    //   80: invokevirtual 99	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   83: ldc 100
    //   85: invokevirtual 106	android/content/res/Resources:getInteger	(I)I
    //   88: istore 58
    //   90: iload 58
    //   92: iconst_m1
    //   93: if_icmpeq +131 -> 224
    //   96: iload 58
    //   98: iconst_1
    //   99: iadd
    //   100: istore 5
    //   102: aload_1
    //   103: iload 58
    //   105: baload
    //   106: istore 60
    //   108: iload 60
    //   110: sipush 255
    //   113: iand
    //   114: istore 11
    //   116: iload 5
    //   118: iconst_1
    //   119: iadd
    //   120: istore 12
    //   122: sipush 255
    //   125: aload_1
    //   126: iload 5
    //   128: baload
    //   129: iand
    //   130: istore 13
    //   132: ldc 13
    //   134: new 76	java/lang/StringBuilder
    //   137: dup
    //   138: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   141: ldc 108
    //   143: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: iload 12
    //   148: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   151: ldc 113
    //   153: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: iload 13
    //   158: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   161: ldc 115
    //   163: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: iload 11
    //   168: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   171: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   174: invokestatic 95	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   177: pop
    //   178: iload 13
    //   180: bipush 6
    //   182: if_icmpeq +74 -> 256
    //   185: iload 13
    //   187: bipush 7
    //   189: if_icmpeq +67 -> 256
    //   192: ldc 13
    //   194: new 76	java/lang/StringBuilder
    //   197: dup
    //   198: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   201: ldc 117
    //   203: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: iload 13
    //   208: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   211: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   214: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   217: pop
    //   218: iconst_1
    //   219: istore 9
    //   221: goto +733 -> 954
    //   224: ldc 13
    //   226: new 76	java/lang/StringBuilder
    //   229: dup
    //   230: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   233: ldc 117
    //   235: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: iload 13
    //   240: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   243: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   246: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   249: pop
    //   250: iconst_1
    //   251: istore 9
    //   253: goto +701 -> 954
    //   256: new 122	com/android/internal/telephony/WspTypeDecoder
    //   259: dup
    //   260: aload_1
    //   261: invokespecial 125	com/android/internal/telephony/WspTypeDecoder:<init>	([B)V
    //   264: astore 14
    //   266: aload 14
    //   268: iload 12
    //   270: invokevirtual 129	com/android/internal/telephony/WspTypeDecoder:decodeUintvarInteger	(I)Z
    //   273: ifne +17 -> 290
    //   276: ldc 13
    //   278: ldc 131
    //   280: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   283: pop
    //   284: iconst_2
    //   285: istore 9
    //   287: goto +667 -> 954
    //   290: aload 14
    //   292: invokevirtual 135	com/android/internal/telephony/WspTypeDecoder:getValue32	()J
    //   295: l2i
    //   296: istore 15
    //   298: iload 12
    //   300: aload 14
    //   302: invokevirtual 139	com/android/internal/telephony/WspTypeDecoder:getDecodedDataLength	()I
    //   305: iadd
    //   306: istore 16
    //   308: aload 14
    //   310: iload 16
    //   312: invokevirtual 142	com/android/internal/telephony/WspTypeDecoder:decodeContentType	(I)Z
    //   315: ifne +17 -> 332
    //   318: ldc 13
    //   320: ldc 144
    //   322: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   325: pop
    //   326: iconst_2
    //   327: istore 9
    //   329: goto +625 -> 954
    //   332: aload 14
    //   334: invokevirtual 147	com/android/internal/telephony/WspTypeDecoder:getValueString	()Ljava/lang/String;
    //   337: astore 17
    //   339: aload 14
    //   341: invokevirtual 135	com/android/internal/telephony/WspTypeDecoder:getValue32	()J
    //   344: lstore 18
    //   346: iload 16
    //   348: aload 14
    //   350: invokevirtual 139	com/android/internal/telephony/WspTypeDecoder:getDecodedDataLength	()I
    //   353: iadd
    //   354: istore 20
    //   356: iload 15
    //   358: newarray byte
    //   360: astore 21
    //   362: aload_1
    //   363: iload 16
    //   365: aload 21
    //   367: iconst_0
    //   368: aload 21
    //   370: arraylength
    //   371: invokestatic 153	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   374: aload 17
    //   376: ifnull +149 -> 525
    //   379: aload 17
    //   381: ldc 155
    //   383: invokevirtual 161	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   386: ifeq +139 -> 525
    //   389: aload_1
    //   390: astore 23
    //   392: aload 14
    //   394: iload 20
    //   396: iconst_m1
    //   397: iload 20
    //   399: iload 15
    //   401: iadd
    //   402: iadd
    //   403: invokevirtual 165	com/android/internal/telephony/WspTypeDecoder:seekXWapApplicationId	(II)Z
    //   406: ifeq +329 -> 735
    //   409: aload 14
    //   411: aload 14
    //   413: invokevirtual 135	com/android/internal/telephony/WspTypeDecoder:getValue32	()J
    //   416: l2i
    //   417: invokevirtual 168	com/android/internal/telephony/WspTypeDecoder:decodeXWapApplicationId	(I)Z
    //   420: pop
    //   421: aload 14
    //   423: invokevirtual 147	com/android/internal/telephony/WspTypeDecoder:getValueString	()Ljava/lang/String;
    //   426: astore 40
    //   428: aload 40
    //   430: ifnonnull +14 -> 444
    //   433: aload 14
    //   435: invokevirtual 135	com/android/internal/telephony/WspTypeDecoder:getValue32	()J
    //   438: l2i
    //   439: invokestatic 173	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   442: astore 40
    //   444: aload 17
    //   446: ifnonnull +148 -> 594
    //   449: lload 18
    //   451: invokestatic 178	java/lang/Long:toString	(J)Ljava/lang/String;
    //   454: astore 41
    //   456: ldc 13
    //   458: new 76	java/lang/StringBuilder
    //   461: dup
    //   462: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   465: ldc 180
    //   467: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   470: aload 40
    //   472: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   475: ldc 182
    //   477: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   480: aload 41
    //   482: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   485: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   488: invokestatic 68	android/telephony/Rlog:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   491: pop
    //   492: iconst_1
    //   493: istore 43
    //   495: aload_0
    //   496: getfield 184	com/android/internal/telephony/WapPushOverSms:mWapPushManager	Lcom/android/internal/telephony/IWapPushManager;
    //   499: astore 46
    //   501: aload 46
    //   503: ifnonnull +98 -> 601
    //   506: ldc 13
    //   508: ldc 186
    //   510: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   513: pop
    //   514: iload 43
    //   516: ifne +219 -> 735
    //   519: iconst_1
    //   520: istore 9
    //   522: goto +432 -> 954
    //   525: iload 16
    //   527: iload 15
    //   529: iadd
    //   530: istore 22
    //   532: aload_1
    //   533: arraylength
    //   534: iload 22
    //   536: isub
    //   537: newarray byte
    //   539: astore 23
    //   541: aload 23
    //   543: arraylength
    //   544: istore 24
    //   546: aload_1
    //   547: iload 22
    //   549: aload 23
    //   551: iconst_0
    //   552: iload 24
    //   554: invokestatic 153	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   557: goto -165 -> 392
    //   560: astore 6
    //   562: ldc 13
    //   564: new 76	java/lang/StringBuilder
    //   567: dup
    //   568: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   571: ldc 188
    //   573: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   576: aload 6
    //   578: invokevirtual 191	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   581: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   584: invokestatic 63	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   587: pop
    //   588: iconst_2
    //   589: istore 9
    //   591: goto +363 -> 954
    //   594: aload 17
    //   596: astore 41
    //   598: goto -142 -> 456
    //   601: new 26	android/content/Intent
    //   604: dup
    //   605: invokespecial 192	android/content/Intent:<init>	()V
    //   608: astore 47
    //   610: aload 47
    //   612: ldc 194
    //   614: iload 11
    //   616: invokevirtual 198	android/content/Intent:putExtra	(Ljava/lang/String;I)Landroid/content/Intent;
    //   619: pop
    //   620: aload 47
    //   622: ldc 200
    //   624: iload 13
    //   626: invokevirtual 198	android/content/Intent:putExtra	(Ljava/lang/String;I)Landroid/content/Intent;
    //   629: pop
    //   630: aload 47
    //   632: ldc 202
    //   634: aload 21
    //   636: invokevirtual 205	android/content/Intent:putExtra	(Ljava/lang/String;[B)Landroid/content/Intent;
    //   639: pop
    //   640: aload 47
    //   642: ldc 207
    //   644: aload 23
    //   646: invokevirtual 205	android/content/Intent:putExtra	(Ljava/lang/String;[B)Landroid/content/Intent;
    //   649: pop
    //   650: aload 47
    //   652: ldc 209
    //   654: aload 14
    //   656: invokevirtual 213	com/android/internal/telephony/WspTypeDecoder:getContentParameters	()Ljava/util/HashMap;
    //   659: invokevirtual 216	android/content/Intent:putExtra	(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;
    //   662: pop
    //   663: aload 46
    //   665: aload 40
    //   667: aload 41
    //   669: aload 47
    //   671: invokeinterface 220 4 0
    //   676: istore 53
    //   678: ldc 13
    //   680: new 76	java/lang/StringBuilder
    //   683: dup
    //   684: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   687: ldc 222
    //   689: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   692: iload 53
    //   694: invokevirtual 111	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   697: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   700: invokestatic 68	android/telephony/Rlog:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   703: pop
    //   704: iload 53
    //   706: iconst_1
    //   707: iand
    //   708: ifle -194 -> 514
    //   711: ldc 223
    //   713: iload 53
    //   715: iand
    //   716: ifne -202 -> 514
    //   719: iconst_0
    //   720: istore 43
    //   722: goto -208 -> 514
    //   725: astore 44
    //   727: ldc 13
    //   729: ldc 225
    //   731: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   734: pop
    //   735: ldc 13
    //   737: ldc 227
    //   739: invokestatic 68	android/telephony/Rlog:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   742: pop
    //   743: aload 17
    //   745: ifnonnull +17 -> 762
    //   748: ldc 13
    //   750: ldc 229
    //   752: invokestatic 120	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   755: pop
    //   756: iconst_2
    //   757: istore 9
    //   759: goto +195 -> 954
    //   762: aload 17
    //   764: ldc 231
    //   766: invokevirtual 161	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   769: ifeq +165 -> 934
    //   772: ldc 233
    //   774: astore 26
    //   776: bipush 18
    //   778: istore 27
    //   780: new 26	android/content/Intent
    //   783: dup
    //   784: ldc 235
    //   786: invokespecial 37	android/content/Intent:<init>	(Ljava/lang/String;)V
    //   789: astore 28
    //   791: aload 28
    //   793: aload 17
    //   795: invokevirtual 239	android/content/Intent:setType	(Ljava/lang/String;)Landroid/content/Intent;
    //   798: pop
    //   799: aload 28
    //   801: ldc 194
    //   803: iload 11
    //   805: invokevirtual 198	android/content/Intent:putExtra	(Ljava/lang/String;I)Landroid/content/Intent;
    //   808: pop
    //   809: aload 28
    //   811: ldc 200
    //   813: iload 13
    //   815: invokevirtual 198	android/content/Intent:putExtra	(Ljava/lang/String;I)Landroid/content/Intent;
    //   818: pop
    //   819: aload 28
    //   821: ldc 202
    //   823: aload 21
    //   825: invokevirtual 205	android/content/Intent:putExtra	(Ljava/lang/String;[B)Landroid/content/Intent;
    //   828: pop
    //   829: aload 28
    //   831: ldc 207
    //   833: aload 23
    //   835: invokevirtual 205	android/content/Intent:putExtra	(Ljava/lang/String;[B)Landroid/content/Intent;
    //   838: pop
    //   839: aload 28
    //   841: ldc 209
    //   843: aload 14
    //   845: invokevirtual 213	com/android/internal/telephony/WspTypeDecoder:getContentParameters	()Ljava/util/HashMap;
    //   848: invokevirtual 216	android/content/Intent:putExtra	(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;
    //   851: pop
    //   852: aload_0
    //   853: getfield 24	com/android/internal/telephony/WapPushOverSms:mContext	Landroid/content/Context;
    //   856: iconst_1
    //   857: invokestatic 245	com/android/internal/telephony/SmsApplication:getDefaultMmsApplication	(Landroid/content/Context;Z)Landroid/content/ComponentName;
    //   860: astore 35
    //   862: aload 35
    //   864: ifnull +53 -> 917
    //   867: aload 28
    //   869: aload 35
    //   871: invokevirtual 51	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   874: pop
    //   875: ldc 13
    //   877: new 76	java/lang/StringBuilder
    //   880: dup
    //   881: invokespecial 77	java/lang/StringBuilder:<init>	()V
    //   884: ldc 247
    //   886: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   889: aload 35
    //   891: invokevirtual 252	android/content/ComponentName:getPackageName	()Ljava/lang/String;
    //   894: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   897: ldc 254
    //   899: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   902: aload 35
    //   904: invokevirtual 257	android/content/ComponentName:getClassName	()Ljava/lang/String;
    //   907: invokevirtual 83	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   910: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   913: invokestatic 68	android/telephony/Rlog:v	(Ljava/lang/String;Ljava/lang/String;)I
    //   916: pop
    //   917: aload_3
    //   918: aload 28
    //   920: aload 26
    //   922: iload 27
    //   924: aload_2
    //   925: invokevirtual 263	com/android/internal/telephony/InboundSmsHandler:dispatchIntent	(Landroid/content/Intent;Ljava/lang/String;ILandroid/content/BroadcastReceiver;)V
    //   928: iconst_m1
    //   929: istore 9
    //   931: goto +23 -> 954
    //   934: ldc_w 265
    //   937: astore 26
    //   939: bipush 19
    //   941: istore 27
    //   943: goto -163 -> 780
    //   946: astore 6
    //   948: iload 5
    //   950: pop
    //   951: goto -389 -> 562
    //   954: iload 9
    //   956: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   52	90	560	java/lang/ArrayIndexOutOfBoundsException
    //   122	492	560	java/lang/ArrayIndexOutOfBoundsException
    //   495	514	560	java/lang/ArrayIndexOutOfBoundsException
    //   532	557	560	java/lang/ArrayIndexOutOfBoundsException
    //   601	704	560	java/lang/ArrayIndexOutOfBoundsException
    //   727	939	560	java/lang/ArrayIndexOutOfBoundsException
    //   495	514	725	android/os/RemoteException
    //   601	704	725	android/os/RemoteException
    //   33	38	946	java/lang/ArrayIndexOutOfBoundsException
    //   102	108	946	java/lang/ArrayIndexOutOfBoundsException
  }

  void dispose()
  {
    if (this.mWapPushManager != null)
    {
      Rlog.v("WAP PUSH", "dispose: unbind wappush manager");
      this.mContext.unbindService(this);
    }
    while (true)
    {
      return;
      Rlog.e("WAP PUSH", "dispose: not bound to a wappush manager");
    }
  }

  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
  {
    this.mWapPushManager = IWapPushManager.Stub.asInterface(paramIBinder);
    Rlog.v("WAP PUSH", "wappush manager connected to " + hashCode());
  }

  public void onServiceDisconnected(ComponentName paramComponentName)
  {
    this.mWapPushManager = null;
    Rlog.v("WAP PUSH", "wappush manager disconnected.");
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.WapPushOverSms
 * JD-Core Version:    0.6.2
 */