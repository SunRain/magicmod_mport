package com.android.internal.telephony;

import android.telephony.CellInfo;
import java.util.List;

public abstract interface PhoneNotifier
{
  public abstract void notifyCallForwardingChanged(Phone paramPhone);

  public abstract void notifyCellInfo(Phone paramPhone, List<CellInfo> paramList);

  public abstract void notifyCellLocation(Phone paramPhone);

  public abstract void notifyDataActivity(Phone paramPhone);

  public abstract void notifyDataConnection(Phone paramPhone, String paramString1, String paramString2, PhoneConstants.DataState paramDataState);

  public abstract void notifyDataConnectionFailed(Phone paramPhone, String paramString1, String paramString2);

  public abstract void notifyMessageWaitingChanged(Phone paramPhone);

  public abstract void notifyOtaspChanged(Phone paramPhone, int paramInt);

  public abstract void notifyPhoneState(Phone paramPhone);

  public abstract void notifyServiceState(Phone paramPhone);

  public abstract void notifySignalStrength(Phone paramPhone);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.PhoneNotifier
 * JD-Core Version:    0.6.2
 */