package com.android.internal.telephony;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ServiceManager;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;
import com.android.internal.telephony.uicc.MiuiAdnRecord;
import java.util.List;

public class MiuiIccProvider extends ContentProvider
{
  public static final int ADDRESS_BOOK_COLUMN_ANR = 4;
  public static final int ADDRESS_BOOK_COLUMN_EMAILS = 2;
  public static final int ADDRESS_BOOK_COLUMN_ID = 3;
  public static final int ADDRESS_BOOK_COLUMN_NAME = 0;
  public static final String[] ADDRESS_BOOK_COLUMN_NAMES = { "name", "number", "emails", "_id", "anr" };
  public static final int ADDRESS_BOOK_COLUMN_NUMBER = 1;
  private static final int ADN = 1;
  private static final int ADN_CAPACITY = 5;
  private static final int ADN_STORAGE = 6;
  static final boolean DBG = false;
  public static final int ERROR_ADN_LIST_NOT_EXIST = -1010;
  public static final int ERROR_ANR_FULL = -1008;
  public static final int ERROR_ANR_TOO_LONG = -1009;
  public static final int ERROR_EMAIL_FULL = -1011;
  public static final int ERROR_EMAIL_TOO_LONG = -1012;
  public static final int ERROR_GENERIC_FAILURE = -1002;
  public static final int ERROR_ICC_CARD_RESET = -1013;
  public static final int ERROR_NOT_READY = -1006;
  public static final int ERROR_NO_ERROR = 0;
  public static final int ERROR_NUMBER_TOO_LONG = -1003;
  public static final int ERROR_PASSWORD_ERROR = -1007;
  public static final int ERROR_STORAGE_FULL = -1005;
  public static final int ERROR_TEXT_TOO_LONG = -1004;
  public static final int ERROR_UNKNOWN = -1001;
  public static final int ERROR_UNKNOWN_EF = -1014;
  private static final int FDN = 2;
  private static final int FREE_ADN = 4;
  private static final int IS_PHONEBOOK_READY = 7;
  private static final int IS_USIM_PHONEBOOK = 8;
  private static final int LAST_ERROR = 9;
  private static final int SDN = 3;
  public static final String STR_ANR = "anr";
  public static final String STR_EMAILS = "emails";
  public static final String STR_ID = "_id";
  public static final String STR_NAME = "name";
  public static final String STR_NEW_ANR = "newAnr";
  public static final String STR_NEW_EMAILS = "newEmails";
  public static final String STR_NEW_NAME = "newName";
  public static final String STR_NEW_NUMBER = "newNumber";
  public static final String STR_NEW_TAG = "newTag";
  public static final String STR_NUMBER = "number";
  public static final String STR_PIN2 = "pin2";
  public static final String STR_TAG = "tag";
  static final String TAG = "IccProvider";
  private static final UriMatcher URL_MATCHER = new UriMatcher(-1);

  static
  {
    URL_MATCHER.addURI("icc", "adn", 1);
    URL_MATCHER.addURI("icc", "fdn", 2);
    URL_MATCHER.addURI("icc", "sdn", 3);
    URL_MATCHER.addURI("icc", "freeadn", 4);
    URL_MATCHER.addURI("icc", "adncapacity", 5);
    URL_MATCHER.addURI("icc", "adnstroage", 6);
    URL_MATCHER.addURI("icc", "isphonebookready", 7);
    URL_MATCHER.addURI("icc", "isusimphonebook", 8);
    URL_MATCHER.addURI("icc", "lasterror", 9);
  }

  private MatrixCursor getAdnCapacity()
  {
    int i = 0;
    MatrixCursor localMatrixCursor = new MatrixCursor(new String[] { "count" }, 1);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        int j = localMiuiIccPhoneBookInterfaceManagerProxy.getAdnCapacity();
        i = j;
      }
      label41: Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(i);
      localMatrixCursor.addRow(arrayOfObject);
      return localMatrixCursor;
    }
    catch (SecurityException localSecurityException)
    {
      break label41;
    }
  }

  private MatrixCursor getFreeAdn()
  {
    int i = 0;
    MatrixCursor localMatrixCursor = new MatrixCursor(new String[] { "count" }, 1);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        int j = localMiuiIccPhoneBookInterfaceManagerProxy.getFreeAdn();
        i = j;
      }
      label41: Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(i);
      localMatrixCursor.addRow(arrayOfObject);
      return localMatrixCursor;
    }
    catch (SecurityException localSecurityException)
    {
      break label41;
    }
  }

  private MiuiIccPhoneBookInterfaceManagerProxy getIccPhoneBookService()
  {
    IIccPhoneBook localIIccPhoneBook = IIccPhoneBook.Stub.asInterface(ServiceManager.getService("simphonebook"));
    if ((localIIccPhoneBook instanceof MiuiIccPhoneBookInterfaceManagerProxy));
    for (MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = (MiuiIccPhoneBookInterfaceManagerProxy)localIIccPhoneBook; ; localMiuiIccPhoneBookInterfaceManagerProxy = null)
      return localMiuiIccPhoneBookInterfaceManagerProxy;
  }

  private MatrixCursor getLastError()
  {
    int i = 0;
    MatrixCursor localMatrixCursor = new MatrixCursor(new String[] { "error" }, 1);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        int j = localMiuiIccPhoneBookInterfaceManagerProxy.getLastError();
        i = j;
      }
      label41: Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(i);
      localMatrixCursor.addRow(arrayOfObject);
      return localMatrixCursor;
    }
    catch (SecurityException localSecurityException)
    {
      break label41;
    }
  }

  private Cursor getStorage()
  {
    int i = 0;
    int j = 0;
    MatrixCursor localMatrixCursor = new MatrixCursor(new String[] { "total", "free" }, 1);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        j = localMiuiIccPhoneBookInterfaceManagerProxy.getAdnCapacity();
        int k = localMiuiIccPhoneBookInterfaceManagerProxy.getFreeAdn();
        i = k;
      }
      label54: Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = Integer.valueOf(j);
      arrayOfObject[1] = Integer.valueOf(i);
      localMatrixCursor.addRow(arrayOfObject);
      return localMatrixCursor;
    }
    catch (SecurityException localSecurityException)
    {
      break label54;
    }
  }

  private MatrixCursor isPhoneBookReady()
  {
    int i = 1;
    int j = 0;
    String[] arrayOfString = new String[i];
    arrayOfString[0] = "ready";
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString, i);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool = localMiuiIccPhoneBookInterfaceManagerProxy.isPhoneBookReady();
        j = bool;
      }
      label46: Object[] arrayOfObject = new Object[i];
      if (j != 0);
      while (true)
      {
        arrayOfObject[0] = Integer.valueOf(i);
        localMatrixCursor.addRow(arrayOfObject);
        return localMatrixCursor;
        i = 0;
      }
    }
    catch (SecurityException localSecurityException)
    {
      break label46;
    }
  }

  private MatrixCursor isUsimPhoneBook()
  {
    int i = 1;
    int j = 0;
    String[] arrayOfString = new String[i];
    arrayOfString[0] = "usimphonebook";
    MatrixCursor localMatrixCursor = new MatrixCursor(arrayOfString, i);
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool = localMiuiIccPhoneBookInterfaceManagerProxy.isUsimPhoneBookRecords();
        j = bool;
      }
      label46: Object[] arrayOfObject = new Object[i];
      if (j != 0);
      while (true)
      {
        arrayOfObject[0] = Integer.valueOf(i);
        localMatrixCursor.addRow(arrayOfObject);
        return localMatrixCursor;
        i = 0;
      }
    }
    catch (SecurityException localSecurityException)
    {
      break label46;
    }
  }

  private Cursor loadFromEf(int paramInt, String paramString, String[] paramArrayOfString)
  {
    Object localObject = null;
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        List localList = (List)localMiuiIccPhoneBookInterfaceManagerProxy.getAdnRecordsInEf(paramInt);
        localObject = localList;
      }
      label29: if (localObject != null)
      {
        String[] arrayOfString = parseSelection(paramString, paramArrayOfString);
        localMatrixCursor = new MatrixCursor(ADDRESS_BOOK_COLUMN_NAMES, localObject.size());
        int i = 0;
        int j = localObject.size();
        while (i < j)
        {
          loadRecord((MiuiAdnRecord)localObject.get(i), localMatrixCursor, i, arrayOfString);
          i++;
        }
      }
      MatrixCursor localMatrixCursor = new MatrixCursor(ADDRESS_BOOK_COLUMN_NAMES);
      return localMatrixCursor;
    }
    catch (SecurityException localSecurityException)
    {
      break label29;
    }
  }

  private void loadRecord(MiuiAdnRecord paramMiuiAdnRecord, MatrixCursor paramMatrixCursor, int paramInt, String[] paramArrayOfString)
  {
    int i = ADDRESS_BOOK_COLUMN_NAMES.length;
    if ((!paramMiuiAdnRecord.isEmpty()) && (match(paramArrayOfString, paramMiuiAdnRecord, paramInt + 1)))
    {
      Object[] arrayOfObject = new Object[i];
      arrayOfObject[3] = Integer.valueOf(paramInt + 1);
      arrayOfObject[0] = paramMiuiAdnRecord.getAlphaTag();
      arrayOfObject[1] = paramMiuiAdnRecord.getNumber();
      if (paramMiuiAdnRecord.getEmails() != null)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(paramMiuiAdnRecord.getEmails()[0]);
        int j = 1;
        int k = paramMiuiAdnRecord.getEmails().length;
        while (j < k)
        {
          localStringBuilder.append(',');
          localStringBuilder.append(paramMiuiAdnRecord.getEmails()[j]);
          j++;
        }
        arrayOfObject[2] = localStringBuilder.toString();
      }
      arrayOfObject[4] = paramMiuiAdnRecord.getAnr();
      paramMatrixCursor.addRow(arrayOfObject);
    }
  }

  private void log(String paramString)
  {
    Log.d("IccProvider", "[IccProvider] " + paramString);
  }

  private boolean match(String[] paramArrayOfString, MiuiAdnRecord paramMiuiAdnRecord, int paramInt)
  {
    boolean bool = true;
    int i;
    if (paramArrayOfString != null)
    {
      i = 0;
      if (i < ADDRESS_BOOK_COLUMN_NAMES.length)
        if (paramArrayOfString[i] != null);
    }
    while (true)
    {
      i++;
      break;
      switch (i)
      {
      default:
      case 0:
      case 1:
      case 3:
      case 2:
      case 4:
      }
      while (!bool)
      {
        return bool;
        bool = TextUtils.equals(paramMiuiAdnRecord.getAlphaTag(), paramArrayOfString[i]);
        continue;
        bool = TextUtils.equals(paramMiuiAdnRecord.getNumber(), paramArrayOfString[i]);
        continue;
        if (paramInt == Integer.parseInt(paramArrayOfString[i]));
        for (bool = true; ; bool = false)
          break;
        if (paramMiuiAdnRecord.getEmails() == null);
        for (bool = "".equals(paramArrayOfString[i]); ; bool = TextUtils.equals(paramMiuiAdnRecord.getEmails()[0], paramArrayOfString[i]))
          break;
        bool = TextUtils.equals(paramMiuiAdnRecord.getAnr(), paramArrayOfString[i]);
      }
    }
  }

  private String normalizeValue(String paramString)
  {
    int i = paramString.length();
    if ((i > 1) && (paramString.charAt(0) == '\'') && (paramString.charAt(i - 1) == '\''))
      paramString = paramString.substring(1, i - 1);
    return paramString;
  }

  private String[] parseSelection(String paramString, String[] paramArrayOfString)
  {
    if (TextUtils.isEmpty(paramString))
    {
      arrayOfString1 = null;
      return arrayOfString1;
    }
    String[] arrayOfString1 = new String[1 + ADDRESS_BOOK_COLUMN_NAMES.length];
    String[] arrayOfString2 = paramString.split("AND");
    int i = 0;
    int j = 0;
    label36: String[] arrayOfString3;
    if (j < arrayOfString2.length)
    {
      arrayOfString3 = arrayOfString2[j].split("=");
      if (arrayOfString3.length == 2)
        break label70;
    }
    while (true)
    {
      j++;
      break label36;
      break;
      label70: String str1 = arrayOfString3[0].trim();
      String str2 = arrayOfString3[1].trim();
      if ("?".equals(str2))
      {
        int k = i + 1;
        str2 = paramArrayOfString[i];
        i = k;
      }
      if ("tag".equals(str1))
        arrayOfString1[0] = normalizeValue(str2);
      else if ("pin2".equals(str1))
        arrayOfString1[ADDRESS_BOOK_COLUMN_NAMES.length] = normalizeValue(str2);
      else if ("number".equals(str1))
        arrayOfString1[1] = PhoneNumberUtils.stripSeparators(normalizeValue(str2));
      else if ("_id".equals(str1))
        arrayOfString1[3] = normalizeValue(str2);
      else if (("name".equals(str1)) && (TextUtils.isEmpty(arrayOfString1[0])))
        arrayOfString1[0] = normalizeValue(str2);
      else if ("emails".equals(str1))
        arrayOfString1[2] = normalizeValue(str2);
      else if ("anr".equals(str1))
        arrayOfString1[4] = normalizeValue(str2);
    }
  }

  private boolean updateAdnRecordsInEfByIndex(int paramInt1, MiuiAdnRecord paramMiuiAdnRecord, int paramInt2)
  {
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool2 = localMiuiIccPhoneBookInterfaceManagerProxy.updateUsimPhoneBookRecordsByIndex(paramInt1, paramMiuiAdnRecord, paramInt2);
        bool1 = bool2;
        return bool1;
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  private boolean updateAdnRecordsInEfByIndex(int paramInt1, String paramString1, String paramString2, String paramString3, int paramInt2)
  {
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool2 = localMiuiIccPhoneBookInterfaceManagerProxy.updateAdnRecordsInEfByIndex(paramInt1, paramString1, paramString2, paramInt2, paramString3);
        bool1 = bool2;
        return bool1;
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  private boolean updateAdnRecordsInEfBySearch(int paramInt, MiuiAdnRecord paramMiuiAdnRecord1, MiuiAdnRecord paramMiuiAdnRecord2)
  {
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool2 = localMiuiIccPhoneBookInterfaceManagerProxy.updateUsimPhoneBookRecordsBySearch(paramInt, paramMiuiAdnRecord1, paramMiuiAdnRecord2);
        bool1 = bool2;
        return bool1;
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  private boolean updateAdnRecordsInEfBySearch(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    try
    {
      MiuiIccPhoneBookInterfaceManagerProxy localMiuiIccPhoneBookInterfaceManagerProxy = getIccPhoneBookService();
      if (localMiuiIccPhoneBookInterfaceManagerProxy != null)
      {
        boolean bool2 = localMiuiIccPhoneBookInterfaceManagerProxy.updateAdnRecordsInEfBySearch(paramInt, paramString1, paramString2, paramString3, paramString4, paramString5);
        bool1 = bool2;
        return bool1;
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString)
  {
    int i;
    String[] arrayOfString;
    int k;
    switch (URL_MATCHER.match(paramUri))
    {
    default:
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    case 1:
      i = 28474;
      arrayOfString = parseSelection(paramString, paramArrayOfString);
      if (arrayOfString == null)
        k = 0;
      break;
    case 2:
    }
    while (true)
    {
      return k;
      i = 28475;
      break;
      int j;
      label104: boolean bool;
      if (arrayOfString[3] != null)
      {
        j = Integer.parseInt(arrayOfString[3]);
        if (i != 28475)
          break label201;
        if (j < 0)
          break label157;
        bool = updateAdnRecordsInEfByIndex(i, "", "", arrayOfString[ADDRESS_BOOK_COLUMN_NAMES.length], j);
      }
      while (true)
      {
        if (bool)
          break label283;
        k = 0;
        break;
        j = -1;
        break label104;
        label157: String str1 = arrayOfString[0];
        String str2 = arrayOfString[1];
        String str3 = arrayOfString[ADDRESS_BOOK_COLUMN_NAMES.length];
        bool = updateAdnRecordsInEfBySearch(i, str1, str2, "", "", str3);
        continue;
        label201: if (j >= 0)
          bool = updateAdnRecordsInEfByIndex(i, new MiuiAdnRecord("", "", null, ""), j);
        else
          bool = updateAdnRecordsInEfBySearch(i, new MiuiAdnRecord(arrayOfString[0], arrayOfString[1], null, ""), new MiuiAdnRecord("", "", null, ""));
      }
      label283: k = 1;
    }
  }

  public String getType(Uri paramUri)
  {
    switch (URL_MATCHER.match(paramUri))
    {
    default:
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    }
    return "vnd.android.cursor.dir/sim-contact";
  }

  public Uri insert(Uri paramUri, ContentValues paramContentValues)
  {
    String str1 = null;
    int i = URL_MATCHER.match(paramUri);
    int j;
    String str2;
    String str3;
    switch (i)
    {
    default:
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    case 1:
      j = 28474;
      str2 = paramContentValues.getAsString("tag");
      if (TextUtils.isEmpty(str2))
        str2 = paramContentValues.getAsString("name");
      str3 = PhoneNumberUtils.stripSeparators(paramContentValues.getAsString("number"));
      if (j != 28475)
        break;
    case 2:
    }
    Uri localUri;
    MiuiAdnRecord localMiuiAdnRecord;
    for (boolean bool = updateAdnRecordsInEfBySearch(j, "", "", str2, str3, str1); ; bool = updateAdnRecordsInEfBySearch(j, new MiuiAdnRecord("", "", null, ""), localMiuiAdnRecord))
    {
      if (bool)
        break label238;
      localUri = null;
      return localUri;
      j = 28475;
      str1 = paramContentValues.getAsString("pin2");
      break;
      String str4 = paramContentValues.getAsString("emails");
      String[] arrayOfString = null;
      if (!TextUtils.isEmpty(str4))
        arrayOfString = new String[] { str4 };
      localMiuiAdnRecord = new MiuiAdnRecord(str2, str3, arrayOfString, paramContentValues.getAsString("anr"));
    }
    label238: StringBuilder localStringBuilder = new StringBuilder("content://icc/");
    switch (i)
    {
    default:
    case 1:
    case 2:
    }
    while (true)
    {
      localStringBuilder.append(0);
      localUri = Uri.parse(localStringBuilder.toString());
      break;
      localStringBuilder.append("adn/");
      continue;
      localStringBuilder.append("fdn/");
    }
  }

  public boolean onCreate()
  {
    return true;
  }

  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    Object localObject;
    switch (URL_MATCHER.match(paramUri))
    {
    default:
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    case 1:
      localObject = loadFromEf(28474, paramString1, paramArrayOfString2);
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    }
    while (true)
    {
      return localObject;
      localObject = loadFromEf(28475, paramString1, paramArrayOfString2);
      continue;
      localObject = loadFromEf(28489, paramString1, paramArrayOfString2);
      continue;
      localObject = getFreeAdn();
      continue;
      localObject = getAdnCapacity();
      continue;
      localObject = getStorage();
      continue;
      localObject = isPhoneBookReady();
      continue;
      localObject = isUsimPhoneBook();
      continue;
      localObject = getLastError();
    }
  }

  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString)
  {
    String str1 = null;
    int i;
    String str2;
    String str3;
    String str4;
    String str5;
    int j;
    label155: boolean bool;
    switch (URL_MATCHER.match(paramUri))
    {
    default:
      throw new IllegalArgumentException("Unknown URI " + paramUri);
    case 1:
      i = 28474;
      str2 = paramContentValues.getAsString("tag");
      if (TextUtils.isEmpty(str2))
        str2 = paramContentValues.getAsString("name");
      str3 = PhoneNumberUtils.stripSeparators(paramContentValues.getAsString("number"));
      str4 = paramContentValues.getAsString("newTag");
      if (TextUtils.isEmpty(str4))
        str4 = paramContentValues.getAsString("newName");
      str5 = PhoneNumberUtils.stripSeparators(paramContentValues.getAsString("newNumber"));
      Integer localInteger = paramContentValues.getAsInteger("_id");
      if (localInteger != null)
      {
        j = localInteger.intValue();
        if (i != 28475)
          break label238;
        if (j < 0)
          break label217;
        bool = updateAdnRecordsInEfByIndex(i, str4, str5, str1, j);
        label184: if (bool)
          break label342;
      }
      break;
    case 2:
    }
    label342: for (int k = 0; ; k = 1)
    {
      return k;
      i = 28475;
      str1 = paramContentValues.getAsString("pin2");
      break;
      j = -1;
      break label155;
      label217: bool = updateAdnRecordsInEfBySearch(i, str2, str3, str4, str5, str1);
      break label184;
      label238: String str6 = paramContentValues.getAsString("newEmails");
      String[] arrayOfString = null;
      if (!TextUtils.isEmpty(str6))
      {
        arrayOfString = new String[1];
        arrayOfString[0] = str6;
      }
      String str7 = paramContentValues.getAsString("newAnr");
      MiuiAdnRecord localMiuiAdnRecord = new MiuiAdnRecord(str4, str5, arrayOfString, str7);
      if (j >= 0)
      {
        bool = updateAdnRecordsInEfByIndex(i, localMiuiAdnRecord, j);
        break label184;
      }
      bool = updateAdnRecordsInEfBySearch(i, new MiuiAdnRecord(str2, str3, null, ""), localMiuiAdnRecord);
      break label184;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.MiuiIccProvider
 * JD-Core Version:    0.6.2
 */