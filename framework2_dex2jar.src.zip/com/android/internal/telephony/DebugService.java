package com.android.internal.telephony;

import android.telephony.Rlog;
import com.android.internal.telephony.dataconnection.DcTrackerBase;
import com.android.internal.telephony.uicc.IccCardProxy;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class DebugService
{
  private static String TAG = "DebugService";

  public DebugService()
  {
    log("DebugService:");
  }

  private static void log(String paramString)
  {
    Rlog.d(TAG, "DebugService " + paramString);
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    log("dump: +");
    try
    {
      localPhoneProxy = (PhoneProxy)PhoneFactory.getDefaultPhone();
    }
    catch (Exception localException8)
    {
      try
      {
        localPhoneBase = (PhoneBase)localPhoneProxy.getActivePhone();
        paramPrintWriter.println();
        paramPrintWriter.println("++++++++++++++++++++++++++++++++");
        paramPrintWriter.flush();
      }
      catch (Exception localException8)
      {
        try
        {
          localPhoneBase.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          paramPrintWriter.flush();
          paramPrintWriter.println("++++++++++++++++++++++++++++++++");
        }
        catch (Exception localException8)
        {
          try
          {
            localPhoneBase.mDcTracker.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
            paramPrintWriter.flush();
            paramPrintWriter.println("++++++++++++++++++++++++++++++++");
          }
          catch (Exception localException8)
          {
            try
            {
              localPhoneBase.getServiceStateTracker().dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
              paramPrintWriter.flush();
              paramPrintWriter.println("++++++++++++++++++++++++++++++++");
            }
            catch (Exception localException8)
            {
              try
              {
                localPhoneBase.getCallTracker().dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
                paramPrintWriter.flush();
                paramPrintWriter.println("++++++++++++++++++++++++++++++++");
              }
              catch (Exception localException8)
              {
                try
                {
                  PhoneBase localPhoneBase;
                  ((RIL)localPhoneBase.mCi).dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
                  paramPrintWriter.flush();
                  paramPrintWriter.println("++++++++++++++++++++++++++++++++");
                }
                catch (Exception localException8)
                {
                  try
                  {
                    UiccController.getInstance().dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
                    paramPrintWriter.flush();
                    paramPrintWriter.println("++++++++++++++++++++++++++++++++");
                  }
                  catch (Exception localException8)
                  {
                    try
                    {
                      while (true)
                      {
                        PhoneProxy localPhoneProxy;
                        ((IccCardProxy)localPhoneProxy.getIccCard()).dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
                        paramPrintWriter.flush();
                        paramPrintWriter.println("++++++++++++++++++++++++++++++++");
                        log("dump: -");
                        while (true)
                        {
                          return;
                          localException1 = localException1;
                          paramPrintWriter.println("Telephony DebugService: Could not getDefaultPhone e=" + localException1);
                          continue;
                          localException2 = localException2;
                          paramPrintWriter.println("Telephony DebugService: Could not PhoneBase e=" + localException2);
                        }
                        localException3 = localException3;
                        localException3.printStackTrace();
                        continue;
                        localException4 = localException4;
                        localException4.printStackTrace();
                        continue;
                        localException5 = localException5;
                        localException5.printStackTrace();
                        continue;
                        localException6 = localException6;
                        localException6.printStackTrace();
                        continue;
                        localException7 = localException7;
                        localException7.printStackTrace();
                      }
                      localException8 = localException8;
                      localException8.printStackTrace();
                    }
                    catch (Exception localException9)
                    {
                      while (true)
                        localException9.printStackTrace();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.DebugService
 * JD-Core Version:    0.6.2
 */