package com.android.internal.telephony.uicc;

import android.os.Message;
import com.android.internal.telephony.CommandsInterface;
import java.util.ArrayList;

public class MiuiIccFileHandler
{
  private IccFileHandler mFh;

  public MiuiIccFileHandler(IccFileHandler paramIccFileHandler)
  {
    this.mFh = paramIccFileHandler;
  }

  public void dispose()
  {
    this.mFh.dispose();
  }

  public void getEFLinearRecordSize(int paramInt, Message paramMessage)
  {
    this.mFh.getEFLinearRecordSize(paramInt, paramMessage);
  }

  public void loadEFImgLinearFixed(int paramInt, Message paramMessage)
  {
    this.mFh.loadEFImgLinearFixed(paramInt, paramMessage);
  }

  public void loadEFImgTransparent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Message paramMessage)
  {
    this.mFh.loadEFImgTransparent(paramInt1, paramInt2, paramInt3, paramInt4, paramMessage);
  }

  public void loadEFLinearFixed(int paramInt1, int paramInt2, int paramInt3, Message paramMessage)
  {
    IccFileHandler.LoadLinearFixedContext localLoadLinearFixedContext = new IccFileHandler.LoadLinearFixedContext(paramInt1, paramInt3, paramMessage);
    localLoadLinearFixedContext.mRecordSize = paramInt2;
    this.mFh.mCi.iccIOForApp(178, localLoadLinearFixedContext.mEfid, this.mFh.getEFPath(localLoadLinearFixedContext.mEfid), localLoadLinearFixedContext.mRecordNum, 4, localLoadLinearFixedContext.mRecordSize, null, null, this.mFh.mAid, this.mFh.obtainMessage(7, localLoadLinearFixedContext));
  }

  public void loadEFLinearFixed(int paramInt1, int paramInt2, Message paramMessage)
  {
    this.mFh.loadEFLinearFixed(paramInt1, paramInt2, paramMessage);
  }

  public void loadEFLinearFixedAll(int paramInt1, int paramInt2, int paramInt3, Message paramMessage)
  {
    IccFileHandler.LoadLinearFixedContext localLoadLinearFixedContext = new IccFileHandler.LoadLinearFixedContext(paramInt1, paramMessage);
    localLoadLinearFixedContext.mRecordSize = paramInt2;
    localLoadLinearFixedContext.mCountRecords = paramInt3;
    localLoadLinearFixedContext.results = new ArrayList(paramInt3);
    this.mFh.mCi.iccIOForApp(178, localLoadLinearFixedContext.mEfid, this.mFh.getEFPath(localLoadLinearFixedContext.mEfid), localLoadLinearFixedContext.mRecordNum, 4, localLoadLinearFixedContext.mRecordSize, null, null, this.mFh.mAid, this.mFh.obtainMessage(7, localLoadLinearFixedContext));
  }

  public void loadEFLinearFixedAll(int paramInt, Message paramMessage)
  {
    this.mFh.loadEFLinearFixedAll(paramInt, paramMessage);
  }

  public void loadEFTransparent(int paramInt1, int paramInt2, Message paramMessage)
  {
    this.mFh.loadEFTransparent(paramInt1, paramInt2, paramMessage);
  }

  public void loadEFTransparent(int paramInt, Message paramMessage)
  {
    this.mFh.loadEFTransparent(paramInt, paramMessage);
  }

  public void updateEFLinearFixed(int paramInt1, int paramInt2, byte[] paramArrayOfByte, String paramString, Message paramMessage)
  {
    this.mFh.updateEFLinearFixed(paramInt1, paramInt2, paramArrayOfByte, paramString, paramMessage);
  }

  public void updateEFTransparent(int paramInt, byte[] paramArrayOfByte, Message paramMessage)
  {
    this.mFh.updateEFTransparent(paramInt, paramArrayOfByte, paramMessage);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.MiuiIccFileHandler
 * JD-Core Version:    0.6.2
 */