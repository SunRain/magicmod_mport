package com.android.internal.telephony.uicc;

import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;

public final class RuimFileHandler extends IccFileHandler
{
  static final String LOG_TAG = "RuimFH";

  public RuimFileHandler(UiccCardApplication paramUiccCardApplication, String paramString, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramString, paramCommandsInterface);
  }

  protected String getEFPath(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 28450:
    case 28456:
    case 28466:
    case 28474:
    case 28476:
    case 28481:
    case 28484:
    case 28506:
    }
    for (String str = getCommonIccEFPath(paramInt); ; str = "3F007F25")
      return str;
  }

  public void loadEFImgTransparent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Message paramMessage)
  {
    Message localMessage = obtainMessage(10, paramInt1, 0, paramMessage);
    this.mCi.iccIOForApp(192, paramInt1, getEFPath(20256), 0, 0, 10, null, null, this.mAid, localMessage);
  }

  protected void logd(String paramString)
  {
    Rlog.d("RuimFH", "[RuimFileHandler] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("RuimFH", "[RuimFileHandler] " + paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.RuimFileHandler
 * JD-Core Version:    0.6.2
 */