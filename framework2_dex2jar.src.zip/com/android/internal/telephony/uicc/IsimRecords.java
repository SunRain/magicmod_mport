package com.android.internal.telephony.uicc;

public abstract interface IsimRecords
{
  public abstract String getIsimDomain();

  public abstract String getIsimImpi();

  public abstract String[] getIsimImpu();
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IsimRecords
 * JD-Core Version:    0.6.2
 */