package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.SmsMessage;
import android.text.TextUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.gsm.SimTlv;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class SIMRecords extends IccRecords
{
  static final int CFF_LINE1_MASK = 15;
  static final int CFF_LINE1_RESET = 240;
  static final int CFF_UNCONDITIONAL_ACTIVE = 10;
  static final int CFF_UNCONDITIONAL_DEACTIVE = 5;
  private static final int CFIS_ADN_CAPABILITY_ID_OFFSET = 14;
  private static final int CFIS_ADN_EXTENSION_ID_OFFSET = 15;
  private static final int CFIS_BCD_NUMBER_LENGTH_OFFSET = 2;
  private static final int CFIS_TON_NPI_OFFSET = 3;
  private static final int CPHS_SST_MBN_ENABLED = 48;
  private static final int CPHS_SST_MBN_MASK = 48;
  private static final boolean CRASH_RIL = false;
  protected static final int EVENT_GET_AD_DONE = 9;
  private static final int EVENT_GET_ALL_SMS_DONE = 18;
  private static final int EVENT_GET_CFF_DONE = 24;
  private static final int EVENT_GET_CFIS_DONE = 32;
  private static final int EVENT_GET_CPHS_MAILBOX_DONE = 11;
  private static final int EVENT_GET_CSP_CPHS_DONE = 33;
  private static final int EVENT_GET_GID1_DONE = 34;
  private static final int EVENT_GET_ICCID_DONE = 4;
  private static final int EVENT_GET_IMSI_DONE = 3;
  private static final int EVENT_GET_INFO_CPHS_DONE = 26;
  private static final int EVENT_GET_MBDN_DONE = 6;
  private static final int EVENT_GET_MBI_DONE = 5;
  protected static final int EVENT_GET_MSISDN_DONE = 10;
  private static final int EVENT_GET_MWIS_DONE = 7;
  private static final int EVENT_GET_PNN_DONE = 15;
  private static final int EVENT_GET_SMS_DONE = 22;
  private static final int EVENT_GET_SPDI_DONE = 13;
  private static final int EVENT_GET_SPN_DONE = 12;
  protected static final int EVENT_GET_SST_DONE = 17;
  private static final int EVENT_GET_VOICE_MAIL_INDICATOR_CPHS_DONE = 8;
  private static final int EVENT_MARK_SMS_READ_DONE = 19;
  private static final int EVENT_SET_CPHS_MAILBOX_DONE = 25;
  private static final int EVENT_SET_MBDN_DONE = 20;
  private static final int EVENT_SIM_REFRESH = 31;
  private static final int EVENT_SMS_ON_SIM = 21;
  private static final int EVENT_UPDATE_DONE = 14;
  protected static final String LOG_TAG = "SIMRecords";
  private static final String[] MCCMNC_CODES_HAVING_3DIGITS_MNC = { "302370", "302720", "310260", "405025", "405026", "405027", "405028", "405029", "405030", "405031", "405032", "405033", "405034", "405035", "405036", "405037", "405038", "405039", "405040", "405041", "405042", "405043", "405044", "405045", "405046", "405047", "405750", "405751", "405752", "405753", "405754", "405755", "405756", "405799", "405800", "405801", "405802", "405803", "405804", "405805", "405806", "405807", "405808", "405809", "405810", "405811", "405812", "405813", "405814", "405815", "405816", "405817", "405818", "405819", "405820", "405821", "405822", "405823", "405824", "405825", "405826", "405827", "405828", "405829", "405830", "405831", "405832", "405833", "405834", "405835", "405836", "405837", "405838", "405839", "405840", "405841", "405842", "405843", "405844", "405845", "405846", "405847", "405848", "405849", "405850", "405851", "405852", "405853", "405875", "405876", "405877", "405878", "405879", "405880", "405881", "405882", "405883", "405884", "405885", "405886", "405908", "405909", "405910", "405911", "405912", "405913", "405914", "405915", "405916", "405917", "405918", "405919", "405920", "405921", "405922", "405923", "405924", "405925", "405926", "405927", "405928", "405929", "405930", "405931", "405932", "502142", "502143", "502145", "502146", "502147", "502148" };
  static final int TAG_FULL_NETWORK_NAME = 67;
  static final int TAG_SHORT_NETWORK_NAME = 69;
  static final int TAG_SPDI = 163;
  static final int TAG_SPDI_PLMN_LIST = 128;
  private boolean mCallForwardingEnabled;
  private byte[] mCphsInfo = null;
  boolean mCspPlmnEnabled = true;
  byte[] mEfCPHS_MWI = null;
  byte[] mEfCff = null;
  byte[] mEfCfis = null;
  byte[] mEfMWIS = null;
  String mPnnHomeName = null;
  ArrayList<String> mSpdiNetworks = null;
  int mSpnDisplayCondition;
  SpnOverride mSpnOverride;
  private GetSpnFsmState mSpnState;
  UsimServiceTable mUsimServiceTable;
  VoiceMailConstants mVmConfig;

  public SIMRecords(UiccCardApplication paramUiccCardApplication, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramContext, paramCommandsInterface);
    this.mAdnCache = new MiuiAdnRecordCache(this.mFh);
    this.mVmConfig = new VoiceMailConstants();
    this.mSpnOverride = new SpnOverride();
    this.mRecordsRequested = false;
    this.mRecordsToLoad = 0;
    this.mCi.setOnSmsOnSim(this, 21, null);
    this.mCi.registerForIccRefresh(this, 31, null);
    resetRecords();
    this.mParentApp.registerForReady(this, 1, null);
    log("SIMRecords X ctor this=" + this);
    Injector.SIMRecordsHook.after_SIMRecords(this);
  }

  private int dispatchGsmMessage(SmsMessage paramSmsMessage)
  {
    this.mNewSmsRegistrants.notifyResult(paramSmsMessage);
    return 0;
  }

  private void getSpnFsm(boolean paramBoolean, AsyncResult paramAsyncResult)
  {
    if (paramBoolean)
      if ((this.mSpnState == GetSpnFsmState.READ_SPN_3GPP) || (this.mSpnState == GetSpnFsmState.READ_SPN_CPHS) || (this.mSpnState == GetSpnFsmState.READ_SPN_SHORT_CPHS) || (this.mSpnState == GetSpnFsmState.INIT))
        this.mSpnState = GetSpnFsmState.INIT;
    while (true)
    {
      return;
      this.mSpnState = GetSpnFsmState.INIT;
      switch (1.$SwitchMap$com$android$internal$telephony$uicc$SIMRecords$GetSpnFsmState[this.mSpnState.ordinal()])
      {
      default:
        this.mSpnState = GetSpnFsmState.IDLE;
        break;
      case 1:
        this.mSpn = null;
        this.mFh.loadEFTransparent(28486, obtainMessage(12));
        this.mRecordsToLoad = (1 + this.mRecordsToLoad);
        this.mSpnState = GetSpnFsmState.READ_SPN_3GPP;
        break;
      case 2:
        if ((paramAsyncResult != null) && (paramAsyncResult.exception == null))
        {
          byte[] arrayOfByte3 = (byte[])paramAsyncResult.result;
          this.mSpnDisplayCondition = (0xFF & arrayOfByte3[0]);
          this.mSpn = IccUtils.adnStringFieldToString(arrayOfByte3, 1, -1 + arrayOfByte3.length);
          log("Load EF_SPN: " + this.mSpn + " spnDisplayCondition: " + this.mSpnDisplayCondition);
          SystemProperties.set("gsm.sim.operator.alpha", this.mSpn);
          this.mSpnState = GetSpnFsmState.IDLE;
        }
        else
        {
          this.mFh.loadEFTransparent(28436, obtainMessage(12));
          this.mRecordsToLoad = (1 + this.mRecordsToLoad);
          this.mSpnState = GetSpnFsmState.READ_SPN_CPHS;
          this.mSpnDisplayCondition = -1;
        }
        break;
      case 3:
        if ((paramAsyncResult != null) && (paramAsyncResult.exception == null))
        {
          byte[] arrayOfByte2 = (byte[])paramAsyncResult.result;
          this.mSpn = IccUtils.adnStringFieldToString(arrayOfByte2, 0, arrayOfByte2.length);
          log("Load EF_SPN_CPHS: " + this.mSpn);
          SystemProperties.set("gsm.sim.operator.alpha", this.mSpn);
          this.mSpnState = GetSpnFsmState.IDLE;
        }
        else
        {
          this.mFh.loadEFTransparent(28440, obtainMessage(12));
          this.mRecordsToLoad = (1 + this.mRecordsToLoad);
          this.mSpnState = GetSpnFsmState.READ_SPN_SHORT_CPHS;
        }
        break;
      case 4:
      }
    }
    if ((paramAsyncResult != null) && (paramAsyncResult.exception == null))
    {
      byte[] arrayOfByte1 = (byte[])paramAsyncResult.result;
      this.mSpn = IccUtils.adnStringFieldToString(arrayOfByte1, 0, arrayOfByte1.length);
      log("Load EF_SPN_SHORT_CPHS: " + this.mSpn);
      SystemProperties.set("gsm.sim.operator.alpha", this.mSpn);
    }
    while (true)
    {
      this.mSpnState = GetSpnFsmState.IDLE;
      break;
      log("No SPN loaded in either CHPS or 3GPP");
    }
  }

  private void handleEfCspData(byte[] paramArrayOfByte)
  {
    int i = paramArrayOfByte.length / 2;
    this.mCspPlmnEnabled = true;
    int j = 0;
    if (j < i)
      if (paramArrayOfByte[(j * 2)] == -64)
      {
        log("[CSP] found ValueAddedServicesGroup, value " + paramArrayOfByte[(1 + j * 2)]);
        if ((0x80 & paramArrayOfByte[(1 + j * 2)]) == 128)
          this.mCspPlmnEnabled = true;
      }
    while (true)
    {
      return;
      this.mCspPlmnEnabled = false;
      log("[CSP] Set Automatic Network Selection");
      this.mNetworkSelectionModeAutomaticRegistrants.notifyRegistrants();
      continue;
      j++;
      break;
      log("[CSP] Value Added Service Group (0xC0), not found!");
    }
  }

  private void handleFileUpdate(int paramInt)
  {
    switch (paramInt)
    {
    default:
      this.mAdnCache.reset();
      fetchSimRecords();
    case 28615:
    case 28439:
    case 28437:
    }
    while (true)
    {
      return;
      this.mRecordsToLoad = (1 + this.mRecordsToLoad);
      new AdnRecordLoader(this.mFh).loadFromEF(28615, 28616, this.mMailboxIndex, obtainMessage(6));
      continue;
      this.mRecordsToLoad = (1 + this.mRecordsToLoad);
      new AdnRecordLoader(this.mFh).loadFromEF(28439, 28490, 1, obtainMessage(11));
      continue;
      this.mRecordsToLoad = (1 + this.mRecordsToLoad);
      log("[CSP] SIM Refresh for EF_CSP_CPHS");
      this.mFh.loadEFTransparent(28437, obtainMessage(33));
    }
  }

  private void handleSimRefresh(IccRefreshResponse paramIccRefreshResponse)
  {
    if (paramIccRefreshResponse == null)
      log("handleSimRefresh received without input");
    while (true)
    {
      return;
      if ((paramIccRefreshResponse.aid == null) || (paramIccRefreshResponse.aid.equals(this.mParentApp.getAid())))
        switch (paramIccRefreshResponse.refreshResult)
        {
        default:
          log("handleSimRefresh with unknown operation");
          break;
        case 0:
          log("handleSimRefresh with SIM_FILE_UPDATED");
          handleFileUpdate(paramIccRefreshResponse.efId);
          break;
        case 1:
          log("handleSimRefresh with SIM_REFRESH_INIT");
          onIccRefreshInit();
          break;
        case 2:
          log("handleSimRefresh with SIM_REFRESH_RESET");
          this.mCi.setRadioPower(false, null);
        }
    }
  }

  private void handleSms(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte[0] != 0)
      Rlog.d("ENF", "status : " + paramArrayOfByte[0]);
    if (paramArrayOfByte[0] == 3)
    {
      int i = paramArrayOfByte.length;
      byte[] arrayOfByte = new byte[i - 1];
      System.arraycopy(paramArrayOfByte, 1, arrayOfByte, 0, i - 1);
      dispatchGsmMessage(SmsMessage.createFromPdu(arrayOfByte, "3gpp"));
    }
  }

  private void handleSmses(ArrayList<byte[]> paramArrayList)
  {
    int i = paramArrayList.size();
    for (int j = 0; j < i; j++)
    {
      byte[] arrayOfByte1 = (byte[])paramArrayList.get(j);
      if (arrayOfByte1[0] != 0)
        Rlog.i("ENF", "status " + j + ": " + arrayOfByte1[0]);
      if (arrayOfByte1[0] == 3)
      {
        int k = arrayOfByte1.length;
        byte[] arrayOfByte2 = new byte[k - 1];
        System.arraycopy(arrayOfByte1, 1, arrayOfByte2, 0, k - 1);
        dispatchGsmMessage(SmsMessage.createFromPdu(arrayOfByte2, "3gpp"));
        arrayOfByte1[0] = 1;
      }
    }
  }

  private boolean isCphsMailboxEnabled()
  {
    boolean bool1 = true;
    boolean bool2 = false;
    if (this.mCphsInfo == null)
      return bool2;
    if ((0x30 & this.mCphsInfo[bool1]) == 48);
    while (true)
    {
      bool2 = bool1;
      break;
      bool1 = false;
    }
  }

  private boolean isOnMatchingPlmn(String paramString)
  {
    boolean bool = true;
    if (Injector.SIMRecordsHook.before_isOnMatchingPlmn(this, paramString));
    while (true)
    {
      return bool;
      if (paramString == null)
      {
        bool = false;
      }
      else if (!paramString.equals(getOperatorNumeric()))
      {
        if (this.mSpdiNetworks != null)
        {
          Iterator localIterator = this.mSpdiNetworks.iterator();
          while (true)
            if (localIterator.hasNext())
              if (paramString.equals((String)localIterator.next()))
                break;
        }
        bool = false;
      }
    }
  }

  private void parseEfSpdi(byte[] paramArrayOfByte)
  {
    SimTlv localSimTlv = new SimTlv(paramArrayOfByte, 0, paramArrayOfByte.length);
    byte[] arrayOfByte = null;
    if (localSimTlv.isValidObject())
    {
      if (localSimTlv.getTag() == 163)
        localSimTlv = new SimTlv(localSimTlv.getData(), 0, localSimTlv.getData().length);
      if (localSimTlv.getTag() == 128)
        arrayOfByte = localSimTlv.getData();
    }
    else
    {
      if (arrayOfByte != null)
        break label77;
    }
    while (true)
    {
      return;
      localSimTlv.nextObject();
      break;
      label77: this.mSpdiNetworks = new ArrayList(arrayOfByte.length / 3);
      for (int i = 0; i + 2 < arrayOfByte.length; i += 3)
      {
        String str = IccUtils.bcdToString(arrayOfByte, i, 3);
        if (str.length() >= 5)
        {
          log("EF_SPDI network: " + str);
          this.mSpdiNetworks.add(str);
        }
      }
    }
  }

  private void setSpnFromConfig(String paramString)
  {
    if (this.mSpnOverride.containsCarrier(paramString));
    Injector.SIMRecordsHook.after_setSpnFromConfig(this);
  }

  private void setVoiceMailByCountry(String paramString)
  {
    if (this.mVmConfig.containsCarrier(paramString))
    {
      this.mIsVoiceMailFixed = true;
      this.mVoiceMailNum = this.mVmConfig.getVoiceMailNumber(paramString);
      this.mVoiceMailTag = this.mVmConfig.getVoiceMailTag(paramString);
    }
  }

  private boolean validEfCfis(byte[] paramArrayOfByte)
  {
    int i = 1;
    if ((paramArrayOfByte != null) && (paramArrayOfByte[0] >= i) && (paramArrayOfByte[0] <= 4));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public void dispose()
  {
    log("Disposing SIMRecords this=" + this);
    this.mCi.unregisterForIccRefresh(this);
    this.mCi.unSetOnSmsOnSim(this);
    this.mParentApp.unregisterForReady(this);
    resetRecords();
    super.dispose();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("SIMRecords: " + this);
    paramPrintWriter.println(" extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mVmConfig=" + this.mVmConfig);
    paramPrintWriter.println(" mSpnOverride=" + this.mSpnOverride);
    paramPrintWriter.println(" mCallForwardingEnabled=" + this.mCallForwardingEnabled);
    paramPrintWriter.println(" mSpnState=" + this.mSpnState);
    paramPrintWriter.println(" mCphsInfo=" + this.mCphsInfo);
    paramPrintWriter.println(" mCspPlmnEnabled=" + this.mCspPlmnEnabled);
    paramPrintWriter.println(" mEfMWIS[]=" + Arrays.toString(this.mEfMWIS));
    paramPrintWriter.println(" mEfCPHS_MWI[]=" + Arrays.toString(this.mEfCPHS_MWI));
    paramPrintWriter.println(" mEfCff[]=" + Arrays.toString(this.mEfCff));
    paramPrintWriter.println(" mEfCfis[]=" + Arrays.toString(this.mEfCfis));
    paramPrintWriter.println(" mSpnDisplayCondition=" + this.mSpnDisplayCondition);
    paramPrintWriter.println(" mSpdiNetworks[]=" + this.mSpdiNetworks);
    paramPrintWriter.println(" mPnnHomeName=" + this.mPnnHomeName);
    paramPrintWriter.println(" mUsimServiceTable=" + this.mUsimServiceTable);
    paramPrintWriter.println(" mGid1=" + this.mGid1);
    paramPrintWriter.flush();
  }

  protected void fetchSimRecords()
  {
    this.mRecordsRequested = true;
    log("fetchSimRecords " + this.mRecordsToLoad);
    this.mCi.getIMSIForApp(this.mParentApp.getAid(), obtainMessage(3));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(12258, obtainMessage(4));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    new AdnRecordLoader(this.mFh).loadFromEF(28480, 28490, 1, obtainMessage(10));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixed(28617, 1, obtainMessage(5));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28589, obtainMessage(9));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixed(28618, 1, obtainMessage(7));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28433, obtainMessage(8));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixed(28619, 1, obtainMessage(32));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28435, obtainMessage(24));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    getSpnFsm(true, null);
    this.mFh.loadEFTransparent(28621, obtainMessage(13));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixed(28613, 1, obtainMessage(15));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28472, obtainMessage(17));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28438, obtainMessage(26));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28437, obtainMessage(33));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28478, obtainMessage(34));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    log("fetchSimRecords " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
  }

  protected void finalize()
  {
    log("finalized");
  }

  public int getDisplayRule(String paramString)
  {
    int i;
    if ((TextUtils.isEmpty(this.mSpn)) || (this.mSpnDisplayCondition == -1))
      i = 2;
    while (true)
    {
      return i;
      if (isOnMatchingPlmn(paramString))
      {
        i = 1;
        if ((0x1 & this.mSpnDisplayCondition) == 1)
          i |= 2;
      }
      else
      {
        i = 2;
        if ((0x2 & this.mSpnDisplayCondition) == 0)
          i |= 1;
      }
    }
  }

  public String getGid1()
  {
    return this.mGid1;
  }

  public String getIMSI()
  {
    return this.mImsi;
  }

  public String getMsisdnAlphaTag()
  {
    return this.mMsisdnTag;
  }

  public String getMsisdnNumber()
  {
    return this.mMsisdn;
  }

  public String getOperatorNumeric()
  {
    String str = null;
    if (this.mImsi == null)
      log("getOperatorNumeric: IMSI == null");
    while (true)
    {
      return str;
      if ((this.mMncLength == -1) || (this.mMncLength == 0))
        log("getSIMOperatorNumeric: bad mncLength");
      else
        str = this.mImsi.substring(0, 3 + this.mMncLength);
    }
  }

  public UsimServiceTable getUsimServiceTable()
  {
    return this.mUsimServiceTable;
  }

  public boolean getVoiceCallForwardingFlag()
  {
    return this.mCallForwardingEnabled;
  }

  public String getVoiceMailAlphaTag()
  {
    return this.mVoiceMailTag;
  }

  public String getVoiceMailNumber()
  {
    return this.mVoiceMailNum;
  }

  // ERROR //
  public void handleMessage(Message paramMessage)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: getfield 917	com/android/internal/telephony/uicc/IccRecords:mDestroyed	Ljava/util/concurrent/atomic/AtomicBoolean;
    //   6: invokevirtual 921	java/util/concurrent/atomic/AtomicBoolean:get	()Z
    //   9: ifeq +53 -> 62
    //   12: aload_0
    //   13: new 453	java/lang/StringBuilder
    //   16: dup
    //   17: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   20: ldc_w 923
    //   23: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: aload_1
    //   27: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   30: ldc_w 925
    //   33: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: aload_1
    //   37: getfield 930	android/os/Message:what	I
    //   40: invokevirtual 559	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   43: ldc_w 932
    //   46: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: ldc_w 934
    //   52: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   58: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   61: return
    //   62: aload_1
    //   63: getfield 930	android/os/Message:what	I
    //   66: tableswitch	default:+150 -> 216, 1:+166->232, 2:+150->216, 3:+191->257, 4:+1306->1372, 5:+511->577, 6:+691->757, 7:+1067->1133, 8:+1212->1278, 9:+1381->1447, 10:+948->1014, 11:+691->757, 12:+2375->2441, 13:+2514->2580, 14:+2555->2621, 15:+2587->2653, 16:+150->216, 17:+2950->3016, 18:+2683->2749, 19:+2717->2783, 20:+3092->3158, 21:+2750->2816, 22:+2882->2948, 23:+150->216, 24:+2392->2458, 25:+3289->3355, 26:+3025->3091, 27:+150->216, 28:+150->216, 29:+150->216, 30:+1015->1081, 31:+3403->3469, 32:+3465->3531, 33:+3630->3696, 34:+3730->3796
    //   217: aload_1
    //   218: invokespecial 939	com/android/internal/telephony/uicc/IccRecords:handleMessage	(Landroid/os/Message;)V
    //   221: iload_2
    //   222: ifeq -161 -> 61
    //   225: aload_0
    //   226: invokevirtual 942	com/android/internal/telephony/uicc/SIMRecords:onRecordLoaded	()V
    //   229: goto -168 -> 61
    //   232: aload_0
    //   233: invokevirtual 945	com/android/internal/telephony/uicc/SIMRecords:onReady	()V
    //   236: goto -15 -> 221
    //   239: astore 4
    //   241: aload_0
    //   242: ldc_w 947
    //   245: aload 4
    //   247: invokevirtual 951	com/android/internal/telephony/uicc/SIMRecords:logw	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   250: iload_2
    //   251: ifeq -190 -> 61
    //   254: goto -29 -> 225
    //   257: iconst_1
    //   258: istore_2
    //   259: aload_1
    //   260: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   263: checkcast 535	android/os/AsyncResult
    //   266: astore 89
    //   268: aload 89
    //   270: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   273: ifnull +45 -> 318
    //   276: aload_0
    //   277: new 453	java/lang/StringBuilder
    //   280: dup
    //   281: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   284: ldc_w 956
    //   287: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   290: aload 89
    //   292: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   295: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   298: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   301: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   304: goto -83 -> 221
    //   307: astore_3
    //   308: iload_2
    //   309: ifeq +7 -> 316
    //   312: aload_0
    //   313: invokevirtual 942	com/android/internal/telephony/uicc/SIMRecords:onRecordLoaded	()V
    //   316: aload_3
    //   317: athrow
    //   318: aload_0
    //   319: aload 89
    //   321: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   324: checkcast 112	java/lang/String
    //   327: putfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   330: aload_0
    //   331: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   334: ifnull +59 -> 393
    //   337: aload_0
    //   338: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   341: invokevirtual 744	java/lang/String:length	()I
    //   344: bipush 6
    //   346: if_icmplt +15 -> 361
    //   349: aload_0
    //   350: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   353: invokevirtual 744	java/lang/String:length	()I
    //   356: bipush 15
    //   358: if_icmple +35 -> 393
    //   361: aload_0
    //   362: new 453	java/lang/StringBuilder
    //   365: dup
    //   366: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   369: ldc_w 958
    //   372: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   375: aload_0
    //   376: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   379: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   385: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   388: aload_0
    //   389: aconst_null
    //   390: putfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   393: aload_0
    //   394: ldc_w 960
    //   397: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   400: aload_0
    //   401: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   404: ifeq +11 -> 415
    //   407: aload_0
    //   408: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   411: iconst_2
    //   412: if_icmpne +72 -> 484
    //   415: aload_0
    //   416: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   419: ifnull +65 -> 484
    //   422: aload_0
    //   423: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   426: invokevirtual 744	java/lang/String:length	()I
    //   429: bipush 6
    //   431: if_icmplt +53 -> 484
    //   434: aload_0
    //   435: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   438: iconst_0
    //   439: bipush 6
    //   441: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   444: astore 92
    //   446: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   449: astore 93
    //   451: aload 93
    //   453: arraylength
    //   454: istore 94
    //   456: iconst_0
    //   457: istore 95
    //   459: iload 95
    //   461: iload 94
    //   463: if_icmpge +21 -> 484
    //   466: aload 93
    //   468: iload 95
    //   470: aaload
    //   471: aload 92
    //   473: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   476: ifeq +3587 -> 4063
    //   479: aload_0
    //   480: iconst_3
    //   481: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   484: aload_0
    //   485: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   488: istore 90
    //   490: iload 90
    //   492: ifne +22 -> 514
    //   495: aload_0
    //   496: aload_0
    //   497: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   500: iconst_0
    //   501: iconst_3
    //   502: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   505: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   508: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   511: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   514: aload_0
    //   515: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   518: ifeq +32 -> 550
    //   521: aload_0
    //   522: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   525: iconst_m1
    //   526: if_icmpeq +24 -> 550
    //   529: aload_0
    //   530: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   533: aload_0
    //   534: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   537: iconst_0
    //   538: iconst_3
    //   539: aload_0
    //   540: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   543: iadd
    //   544: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   547: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   550: aload_0
    //   551: getfield 982	com/android/internal/telephony/uicc/IccRecords:mImsiReadyRegistrants	Landroid/os/RegistrantList;
    //   554: invokevirtual 585	android/os/RegistrantList:notifyRegistrants	()V
    //   557: goto -336 -> 221
    //   560: astore 91
    //   562: aload_0
    //   563: iconst_0
    //   564: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   567: aload_0
    //   568: ldc_w 984
    //   571: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   574: goto -60 -> 514
    //   577: iconst_1
    //   578: istore_2
    //   579: aload_1
    //   580: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   583: checkcast 535	android/os/AsyncResult
    //   586: astore 86
    //   588: aload 86
    //   590: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   593: checkcast 544	[B
    //   596: checkcast 544	[B
    //   599: astore 87
    //   601: iconst_0
    //   602: istore 88
    //   604: aload 86
    //   606: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   609: ifnonnull +70 -> 679
    //   612: aload_0
    //   613: new 453	java/lang/StringBuilder
    //   616: dup
    //   617: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   620: ldc_w 986
    //   623: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   626: aload 87
    //   628: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   631: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   634: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   637: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   640: aload_0
    //   641: sipush 255
    //   644: aload 87
    //   646: iconst_0
    //   647: baload
    //   648: iand
    //   649: putfield 603	com/android/internal/telephony/uicc/IccRecords:mMailboxIndex	I
    //   652: aload_0
    //   653: getfield 603	com/android/internal/telephony/uicc/IccRecords:mMailboxIndex	I
    //   656: ifeq +23 -> 679
    //   659: aload_0
    //   660: getfield 603	com/android/internal/telephony/uicc/IccRecords:mMailboxIndex	I
    //   663: sipush 255
    //   666: if_icmpeq +13 -> 679
    //   669: aload_0
    //   670: ldc_w 991
    //   673: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   676: iconst_1
    //   677: istore 88
    //   679: aload_0
    //   680: iconst_1
    //   681: aload_0
    //   682: getfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   685: iadd
    //   686: putfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   689: iload 88
    //   691: ifeq +36 -> 727
    //   694: new 599	com/android/internal/telephony/uicc/AdnRecordLoader
    //   697: dup
    //   698: aload_0
    //   699: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   702: invokespecial 600	com/android/internal/telephony/uicc/AdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/IccFileHandler;)V
    //   705: sipush 28615
    //   708: sipush 28616
    //   711: aload_0
    //   712: getfield 603	com/android/internal/telephony/uicc/IccRecords:mMailboxIndex	I
    //   715: aload_0
    //   716: bipush 6
    //   718: invokevirtual 527	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(I)Landroid/os/Message;
    //   721: invokevirtual 607	com/android/internal/telephony/uicc/AdnRecordLoader:loadFromEF	(IIILandroid/os/Message;)V
    //   724: goto -503 -> 221
    //   727: new 599	com/android/internal/telephony/uicc/AdnRecordLoader
    //   730: dup
    //   731: aload_0
    //   732: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   735: invokespecial 600	com/android/internal/telephony/uicc/AdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/IccFileHandler;)V
    //   738: sipush 28439
    //   741: sipush 28490
    //   744: iconst_1
    //   745: aload_0
    //   746: bipush 11
    //   748: invokevirtual 527	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(I)Landroid/os/Message;
    //   751: invokevirtual 607	com/android/internal/telephony/uicc/AdnRecordLoader:loadFromEF	(IIILandroid/os/Message;)V
    //   754: goto -533 -> 221
    //   757: aload_0
    //   758: aconst_null
    //   759: putfield 768	com/android/internal/telephony/uicc/IccRecords:mVoiceMailNum	Ljava/lang/String;
    //   762: aload_0
    //   763: aconst_null
    //   764: putfield 774	com/android/internal/telephony/uicc/IccRecords:mVoiceMailTag	Ljava/lang/String;
    //   767: iconst_1
    //   768: istore_2
    //   769: aload_1
    //   770: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   773: checkcast 535	android/os/AsyncResult
    //   776: astore 80
    //   778: aload 80
    //   780: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   783: ifnull +95 -> 878
    //   786: new 453	java/lang/StringBuilder
    //   789: dup
    //   790: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   793: ldc_w 993
    //   796: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   799: astore 84
    //   801: aload_1
    //   802: getfield 930	android/os/Message:what	I
    //   805: bipush 11
    //   807: if_icmpne +3262 -> 4069
    //   810: ldc_w 995
    //   813: astore 85
    //   815: aload_0
    //   816: aload 84
    //   818: aload 85
    //   820: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   826: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   829: aload_1
    //   830: getfield 930	android/os/Message:what	I
    //   833: bipush 6
    //   835: if_icmpne -614 -> 221
    //   838: aload_0
    //   839: iconst_1
    //   840: aload_0
    //   841: getfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   844: iadd
    //   845: putfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   848: new 599	com/android/internal/telephony/uicc/AdnRecordLoader
    //   851: dup
    //   852: aload_0
    //   853: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   856: invokespecial 600	com/android/internal/telephony/uicc/AdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/IccFileHandler;)V
    //   859: sipush 28439
    //   862: sipush 28490
    //   865: iconst_1
    //   866: aload_0
    //   867: bipush 11
    //   869: invokevirtual 527	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(I)Landroid/os/Message;
    //   872: invokevirtual 607	com/android/internal/telephony/uicc/AdnRecordLoader:loadFromEF	(IIILandroid/os/Message;)V
    //   875: goto -654 -> 221
    //   878: aload 80
    //   880: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   883: checkcast 997	com/android/internal/telephony/uicc/AdnRecord
    //   886: astore 81
    //   888: new 453	java/lang/StringBuilder
    //   891: dup
    //   892: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   895: ldc_w 999
    //   898: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   901: aload 81
    //   903: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   906: astore 82
    //   908: aload_1
    //   909: getfield 930	android/os/Message:what	I
    //   912: bipush 11
    //   914: if_icmpne +3163 -> 4077
    //   917: ldc_w 1001
    //   920: astore 83
    //   922: aload_0
    //   923: aload 82
    //   925: aload 83
    //   927: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   930: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   933: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   936: aload 81
    //   938: invokevirtual 1003	com/android/internal/telephony/uicc/AdnRecord:isEmpty	()Z
    //   941: ifeq +52 -> 993
    //   944: aload_1
    //   945: getfield 930	android/os/Message:what	I
    //   948: bipush 6
    //   950: if_icmpne +43 -> 993
    //   953: aload_0
    //   954: iconst_1
    //   955: aload_0
    //   956: getfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   959: iadd
    //   960: putfield 426	com/android/internal/telephony/uicc/IccRecords:mRecordsToLoad	I
    //   963: new 599	com/android/internal/telephony/uicc/AdnRecordLoader
    //   966: dup
    //   967: aload_0
    //   968: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   971: invokespecial 600	com/android/internal/telephony/uicc/AdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/IccFileHandler;)V
    //   974: sipush 28439
    //   977: sipush 28490
    //   980: iconst_1
    //   981: aload_0
    //   982: bipush 11
    //   984: invokevirtual 527	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(I)Landroid/os/Message;
    //   987: invokevirtual 607	com/android/internal/telephony/uicc/AdnRecordLoader:loadFromEF	(IIILandroid/os/Message;)V
    //   990: goto -769 -> 221
    //   993: aload_0
    //   994: aload 81
    //   996: invokevirtual 1006	com/android/internal/telephony/uicc/AdnRecord:getNumber	()Ljava/lang/String;
    //   999: putfield 768	com/android/internal/telephony/uicc/IccRecords:mVoiceMailNum	Ljava/lang/String;
    //   1002: aload_0
    //   1003: aload 81
    //   1005: invokevirtual 1009	com/android/internal/telephony/uicc/AdnRecord:getAlphaTag	()Ljava/lang/String;
    //   1008: putfield 774	com/android/internal/telephony/uicc/IccRecords:mVoiceMailTag	Ljava/lang/String;
    //   1011: goto -790 -> 221
    //   1014: iconst_1
    //   1015: istore_2
    //   1016: aload_1
    //   1017: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1020: checkcast 535	android/os/AsyncResult
    //   1023: astore 78
    //   1025: aload 78
    //   1027: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1030: ifnull +13 -> 1043
    //   1033: aload_0
    //   1034: ldc_w 1011
    //   1037: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1040: goto -819 -> 221
    //   1043: aload 78
    //   1045: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   1048: checkcast 997	com/android/internal/telephony/uicc/AdnRecord
    //   1051: astore 79
    //   1053: aload_0
    //   1054: aload 79
    //   1056: invokevirtual 1006	com/android/internal/telephony/uicc/AdnRecord:getNumber	()Ljava/lang/String;
    //   1059: putfield 892	com/android/internal/telephony/uicc/IccRecords:mMsisdn	Ljava/lang/String;
    //   1062: aload_0
    //   1063: aload 79
    //   1065: invokevirtual 1009	com/android/internal/telephony/uicc/AdnRecord:getAlphaTag	()Ljava/lang/String;
    //   1068: putfield 888	com/android/internal/telephony/uicc/IccRecords:mMsisdnTag	Ljava/lang/String;
    //   1071: aload_0
    //   1072: ldc_w 1013
    //   1075: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1078: goto -857 -> 221
    //   1081: iconst_0
    //   1082: istore_2
    //   1083: aload_1
    //   1084: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1087: checkcast 535	android/os/AsyncResult
    //   1090: astore 77
    //   1092: aload 77
    //   1094: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   1097: ifnull -876 -> 221
    //   1100: aload 77
    //   1102: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   1105: checkcast 927	android/os/Message
    //   1108: invokestatic 1020	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   1111: aload 77
    //   1113: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1116: putfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1119: aload 77
    //   1121: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   1124: checkcast 927	android/os/Message
    //   1127: invokevirtual 1023	android/os/Message:sendToTarget	()V
    //   1130: goto -909 -> 221
    //   1133: iconst_1
    //   1134: istore_2
    //   1135: aload_1
    //   1136: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1139: checkcast 535	android/os/AsyncResult
    //   1142: astore 74
    //   1144: aload 74
    //   1146: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   1149: checkcast 544	[B
    //   1152: checkcast 544	[B
    //   1155: astore 75
    //   1157: aload 74
    //   1159: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1162: ifnonnull -941 -> 221
    //   1165: aload_0
    //   1166: new 453	java/lang/StringBuilder
    //   1169: dup
    //   1170: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   1173: ldc_w 1025
    //   1176: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1179: aload 75
    //   1181: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   1184: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1187: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1190: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1193: aload_0
    //   1194: aload 75
    //   1196: putfield 386	com/android/internal/telephony/uicc/SIMRecords:mEfMWIS	[B
    //   1199: sipush 255
    //   1202: aload 75
    //   1204: iconst_0
    //   1205: baload
    //   1206: iand
    //   1207: sipush 255
    //   1210: if_icmpne +13 -> 1223
    //   1213: aload_0
    //   1214: ldc_w 1027
    //   1217: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1220: goto -999 -> 221
    //   1223: iconst_1
    //   1224: aload 75
    //   1226: iconst_0
    //   1227: baload
    //   1228: iand
    //   1229: ifeq +2856 -> 4085
    //   1232: iconst_1
    //   1233: istore 76
    //   1235: aload_0
    //   1236: sipush 255
    //   1239: aload 75
    //   1241: iconst_1
    //   1242: baload
    //   1243: iand
    //   1244: putfield 1030	com/android/internal/telephony/uicc/IccRecords:mCountVoiceMessages	I
    //   1247: iload 76
    //   1249: ifeq +15 -> 1264
    //   1252: aload_0
    //   1253: getfield 1030	com/android/internal/telephony/uicc/IccRecords:mCountVoiceMessages	I
    //   1256: ifne +8 -> 1264
    //   1259: aload_0
    //   1260: iconst_m1
    //   1261: putfield 1030	com/android/internal/telephony/uicc/IccRecords:mCountVoiceMessages	I
    //   1264: aload_0
    //   1265: getfield 1033	com/android/internal/telephony/uicc/IccRecords:mRecordsEventsRegistrants	Landroid/os/RegistrantList;
    //   1268: iconst_0
    //   1269: invokestatic 1037	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   1272: invokevirtual 489	android/os/RegistrantList:notifyResult	(Ljava/lang/Object;)V
    //   1275: goto -1054 -> 221
    //   1278: iconst_1
    //   1279: istore_2
    //   1280: aload_1
    //   1281: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1284: checkcast 535	android/os/AsyncResult
    //   1287: astore 71
    //   1289: aload 71
    //   1291: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   1294: checkcast 544	[B
    //   1297: checkcast 544	[B
    //   1300: astore 72
    //   1302: aload 71
    //   1304: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1307: ifnonnull -1086 -> 221
    //   1310: aload_0
    //   1311: aload 72
    //   1313: putfield 388	com/android/internal/telephony/uicc/SIMRecords:mEfCPHS_MWI	[B
    //   1316: aload_0
    //   1317: getfield 386	com/android/internal/telephony/uicc/SIMRecords:mEfMWIS	[B
    //   1320: ifnonnull -1099 -> 221
    //   1323: bipush 15
    //   1325: aload 72
    //   1327: iconst_0
    //   1328: baload
    //   1329: iand
    //   1330: istore 73
    //   1332: iload 73
    //   1334: bipush 10
    //   1336: if_icmpne +22 -> 1358
    //   1339: aload_0
    //   1340: iconst_m1
    //   1341: putfield 1030	com/android/internal/telephony/uicc/IccRecords:mCountVoiceMessages	I
    //   1344: aload_0
    //   1345: getfield 1033	com/android/internal/telephony/uicc/IccRecords:mRecordsEventsRegistrants	Landroid/os/RegistrantList;
    //   1348: iconst_0
    //   1349: invokestatic 1037	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   1352: invokevirtual 489	android/os/RegistrantList:notifyResult	(Ljava/lang/Object;)V
    //   1355: goto -1134 -> 221
    //   1358: iload 73
    //   1360: iconst_5
    //   1361: if_icmpne -17 -> 1344
    //   1364: aload_0
    //   1365: iconst_0
    //   1366: putfield 1030	com/android/internal/telephony/uicc/IccRecords:mCountVoiceMessages	I
    //   1369: goto -25 -> 1344
    //   1372: iconst_1
    //   1373: istore_2
    //   1374: aload_1
    //   1375: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1378: checkcast 535	android/os/AsyncResult
    //   1381: astore 69
    //   1383: aload 69
    //   1385: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   1388: checkcast 544	[B
    //   1391: checkcast 544	[B
    //   1394: astore 70
    //   1396: aload 69
    //   1398: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1401: ifnonnull -1180 -> 221
    //   1404: aload_0
    //   1405: aload 70
    //   1407: iconst_0
    //   1408: aload 70
    //   1410: arraylength
    //   1411: invokestatic 1040	com/android/internal/telephony/uicc/IccUtils:parseIccIdToString	([BII)Ljava/lang/String;
    //   1414: putfield 1043	com/android/internal/telephony/uicc/IccRecords:mIccId	Ljava/lang/String;
    //   1417: aload_0
    //   1418: new 453	java/lang/StringBuilder
    //   1421: dup
    //   1422: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   1425: ldc_w 1045
    //   1428: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1431: aload_0
    //   1432: getfield 1043	com/android/internal/telephony/uicc/IccRecords:mIccId	Ljava/lang/String;
    //   1435: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1438: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1441: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1444: goto -1223 -> 221
    //   1447: iconst_1
    //   1448: istore_2
    //   1449: aload_1
    //   1450: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   1453: checkcast 535	android/os/AsyncResult
    //   1456: astore 42
    //   1458: aload 42
    //   1460: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   1463: checkcast 544	[B
    //   1466: checkcast 544	[B
    //   1469: astore 43
    //   1471: aload 42
    //   1473: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   1476: astore 44
    //   1478: aload 44
    //   1480: ifnull +178 -> 1658
    //   1483: aload_0
    //   1484: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1487: iconst_m1
    //   1488: if_icmpeq +18 -> 1506
    //   1491: aload_0
    //   1492: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1495: ifeq +11 -> 1506
    //   1498: aload_0
    //   1499: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1502: iconst_2
    //   1503: if_icmpne +72 -> 1575
    //   1506: aload_0
    //   1507: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1510: ifnull +65 -> 1575
    //   1513: aload_0
    //   1514: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1517: invokevirtual 744	java/lang/String:length	()I
    //   1520: bipush 6
    //   1522: if_icmplt +53 -> 1575
    //   1525: aload_0
    //   1526: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1529: iconst_0
    //   1530: bipush 6
    //   1532: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1535: astore 65
    //   1537: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   1540: astore 66
    //   1542: aload 66
    //   1544: arraylength
    //   1545: istore 67
    //   1547: iconst_0
    //   1548: istore 68
    //   1550: iload 68
    //   1552: iload 67
    //   1554: if_icmpge +21 -> 1575
    //   1557: aload 66
    //   1559: iload 68
    //   1561: aaload
    //   1562: aload 65
    //   1564: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   1567: ifeq +2542 -> 4109
    //   1570: aload_0
    //   1571: iconst_3
    //   1572: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1575: aload_0
    //   1576: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1579: ifeq +11 -> 1590
    //   1582: aload_0
    //   1583: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1586: iconst_m1
    //   1587: if_icmpne +33 -> 1620
    //   1590: aload_0
    //   1591: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1594: astore 63
    //   1596: aload 63
    //   1598: ifnull +2337 -> 3935
    //   1601: aload_0
    //   1602: aload_0
    //   1603: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1606: iconst_0
    //   1607: iconst_3
    //   1608: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1611: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   1614: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   1617: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1620: aload_0
    //   1621: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1624: ifnull -1403 -> 221
    //   1627: aload_0
    //   1628: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1631: ifeq -1410 -> 221
    //   1634: aload_0
    //   1635: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   1638: aload_0
    //   1639: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1642: iconst_0
    //   1643: iconst_3
    //   1644: aload_0
    //   1645: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1648: iadd
    //   1649: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1652: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   1655: goto -1434 -> 221
    //   1658: aload_0
    //   1659: new 453	java/lang/StringBuilder
    //   1662: dup
    //   1663: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   1666: ldc_w 1047
    //   1669: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1672: aload 43
    //   1674: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   1677: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1680: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1683: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1686: aload 43
    //   1688: arraylength
    //   1689: iconst_3
    //   1690: if_icmpge +185 -> 1875
    //   1693: aload_0
    //   1694: ldc_w 1049
    //   1697: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1700: aload_0
    //   1701: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1704: iconst_m1
    //   1705: if_icmpeq +18 -> 1723
    //   1708: aload_0
    //   1709: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1712: ifeq +11 -> 1723
    //   1715: aload_0
    //   1716: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1719: iconst_2
    //   1720: if_icmpne +72 -> 1792
    //   1723: aload_0
    //   1724: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1727: ifnull +65 -> 1792
    //   1730: aload_0
    //   1731: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1734: invokevirtual 744	java/lang/String:length	()I
    //   1737: bipush 6
    //   1739: if_icmplt +53 -> 1792
    //   1742: aload_0
    //   1743: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1746: iconst_0
    //   1747: bipush 6
    //   1749: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1752: astore 59
    //   1754: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   1757: astore 60
    //   1759: aload 60
    //   1761: arraylength
    //   1762: istore 61
    //   1764: iconst_0
    //   1765: istore 62
    //   1767: iload 62
    //   1769: iload 61
    //   1771: if_icmpge +21 -> 1792
    //   1774: aload 60
    //   1776: iload 62
    //   1778: aaload
    //   1779: aload 59
    //   1781: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   1784: ifeq +2331 -> 4115
    //   1787: aload_0
    //   1788: iconst_3
    //   1789: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1792: aload_0
    //   1793: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1796: ifeq +11 -> 1807
    //   1799: aload_0
    //   1800: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1803: iconst_m1
    //   1804: if_icmpne +33 -> 1837
    //   1807: aload_0
    //   1808: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1811: astore 57
    //   1813: aload 57
    //   1815: ifnull +2152 -> 3967
    //   1818: aload_0
    //   1819: aload_0
    //   1820: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1823: iconst_0
    //   1824: iconst_3
    //   1825: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1828: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   1831: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   1834: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1837: aload_0
    //   1838: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1841: ifnull -1620 -> 221
    //   1844: aload_0
    //   1845: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1848: ifeq -1627 -> 221
    //   1851: aload_0
    //   1852: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   1855: aload_0
    //   1856: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1859: iconst_0
    //   1860: iconst_3
    //   1861: aload_0
    //   1862: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1865: iadd
    //   1866: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1869: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   1872: goto -1651 -> 221
    //   1875: aload 43
    //   1877: arraylength
    //   1878: iconst_3
    //   1879: if_icmpne +185 -> 2064
    //   1882: aload_0
    //   1883: ldc_w 1051
    //   1886: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   1889: aload_0
    //   1890: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1893: iconst_m1
    //   1894: if_icmpeq +18 -> 1912
    //   1897: aload_0
    //   1898: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1901: ifeq +11 -> 1912
    //   1904: aload_0
    //   1905: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1908: iconst_2
    //   1909: if_icmpne +72 -> 1981
    //   1912: aload_0
    //   1913: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1916: ifnull +65 -> 1981
    //   1919: aload_0
    //   1920: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1923: invokevirtual 744	java/lang/String:length	()I
    //   1926: bipush 6
    //   1928: if_icmplt +53 -> 1981
    //   1931: aload_0
    //   1932: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   1935: iconst_0
    //   1936: bipush 6
    //   1938: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   1941: astore 53
    //   1943: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   1946: astore 54
    //   1948: aload 54
    //   1950: arraylength
    //   1951: istore 55
    //   1953: iconst_0
    //   1954: istore 56
    //   1956: iload 56
    //   1958: iload 55
    //   1960: if_icmpge +21 -> 1981
    //   1963: aload 54
    //   1965: iload 56
    //   1967: aaload
    //   1968: aload 53
    //   1970: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   1973: ifeq +2148 -> 4121
    //   1976: aload_0
    //   1977: iconst_3
    //   1978: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1981: aload_0
    //   1982: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1985: ifeq +11 -> 1996
    //   1988: aload_0
    //   1989: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   1992: iconst_m1
    //   1993: if_icmpne +33 -> 2026
    //   1996: aload_0
    //   1997: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2000: astore 51
    //   2002: aload 51
    //   2004: ifnull +1995 -> 3999
    //   2007: aload_0
    //   2008: aload_0
    //   2009: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2012: iconst_0
    //   2013: iconst_3
    //   2014: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2017: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   2020: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   2023: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2026: aload_0
    //   2027: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2030: ifnull -1809 -> 221
    //   2033: aload_0
    //   2034: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2037: ifeq -1816 -> 221
    //   2040: aload_0
    //   2041: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   2044: aload_0
    //   2045: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2048: iconst_0
    //   2049: iconst_3
    //   2050: aload_0
    //   2051: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2054: iadd
    //   2055: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2058: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   2061: goto -1840 -> 221
    //   2064: aload_0
    //   2065: bipush 15
    //   2067: aload 43
    //   2069: iconst_3
    //   2070: baload
    //   2071: iand
    //   2072: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2075: aload_0
    //   2076: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2079: bipush 15
    //   2081: if_icmpne +8 -> 2089
    //   2084: aload_0
    //   2085: iconst_0
    //   2086: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2089: aload_0
    //   2090: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2093: iconst_m1
    //   2094: if_icmpeq +18 -> 2112
    //   2097: aload_0
    //   2098: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2101: ifeq +11 -> 2112
    //   2104: aload_0
    //   2105: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2108: iconst_2
    //   2109: if_icmpne +72 -> 2181
    //   2112: aload_0
    //   2113: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2116: ifnull +65 -> 2181
    //   2119: aload_0
    //   2120: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2123: invokevirtual 744	java/lang/String:length	()I
    //   2126: bipush 6
    //   2128: if_icmplt +53 -> 2181
    //   2131: aload_0
    //   2132: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2135: iconst_0
    //   2136: bipush 6
    //   2138: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2141: astore 47
    //   2143: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   2146: astore 48
    //   2148: aload 48
    //   2150: arraylength
    //   2151: istore 49
    //   2153: iconst_0
    //   2154: istore 50
    //   2156: iload 50
    //   2158: iload 49
    //   2160: if_icmpge +21 -> 2181
    //   2163: aload 48
    //   2165: iload 50
    //   2167: aaload
    //   2168: aload 47
    //   2170: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   2173: ifeq +1954 -> 4127
    //   2176: aload_0
    //   2177: iconst_3
    //   2178: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2181: aload_0
    //   2182: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2185: ifeq +11 -> 2196
    //   2188: aload_0
    //   2189: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2192: iconst_m1
    //   2193: if_icmpne +33 -> 2226
    //   2196: aload_0
    //   2197: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2200: astore 45
    //   2202: aload 45
    //   2204: ifnull +1827 -> 4031
    //   2207: aload_0
    //   2208: aload_0
    //   2209: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2212: iconst_0
    //   2213: iconst_3
    //   2214: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2217: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   2220: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   2223: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2226: aload_0
    //   2227: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2230: ifnull -2009 -> 221
    //   2233: aload_0
    //   2234: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2237: ifeq -2016 -> 221
    //   2240: aload_0
    //   2241: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   2244: aload_0
    //   2245: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2248: iconst_0
    //   2249: iconst_3
    //   2250: aload_0
    //   2251: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2254: iadd
    //   2255: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2258: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   2261: goto -2040 -> 221
    //   2264: astore 35
    //   2266: aload_0
    //   2267: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2270: iconst_m1
    //   2271: if_icmpeq +18 -> 2289
    //   2274: aload_0
    //   2275: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2278: ifeq +11 -> 2289
    //   2281: aload_0
    //   2282: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2285: iconst_2
    //   2286: if_icmpne +72 -> 2358
    //   2289: aload_0
    //   2290: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2293: ifnull +65 -> 2358
    //   2296: aload_0
    //   2297: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2300: invokevirtual 744	java/lang/String:length	()I
    //   2303: bipush 6
    //   2305: if_icmplt +53 -> 2358
    //   2308: aload_0
    //   2309: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2312: iconst_0
    //   2313: bipush 6
    //   2315: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2318: astore 38
    //   2320: getstatic 376	com/android/internal/telephony/uicc/SIMRecords:MCCMNC_CODES_HAVING_3DIGITS_MNC	[Ljava/lang/String;
    //   2323: astore 39
    //   2325: aload 39
    //   2327: arraylength
    //   2328: istore 40
    //   2330: iconst_0
    //   2331: istore 41
    //   2333: iload 41
    //   2335: iload 40
    //   2337: if_icmpge +21 -> 2358
    //   2340: aload 39
    //   2342: iload 41
    //   2344: aaload
    //   2345: aload 38
    //   2347: invokevirtual 625	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   2350: ifeq +1753 -> 4103
    //   2353: aload_0
    //   2354: iconst_3
    //   2355: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2358: aload_0
    //   2359: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2362: ifeq +11 -> 2373
    //   2365: aload_0
    //   2366: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2369: iconst_m1
    //   2370: if_icmpne +33 -> 2403
    //   2373: aload_0
    //   2374: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2377: astore 36
    //   2379: aload 36
    //   2381: ifnull +1522 -> 3903
    //   2384: aload_0
    //   2385: aload_0
    //   2386: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2389: iconst_0
    //   2390: iconst_3
    //   2391: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2394: invokestatic 965	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   2397: invokestatic 971	com/android/internal/telephony/MccTable:smallestDigitsMccForMnc	(I)I
    //   2400: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2403: aload_0
    //   2404: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2407: ifnull +31 -> 2438
    //   2410: aload_0
    //   2411: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2414: ifeq +24 -> 2438
    //   2417: aload_0
    //   2418: getfield 975	com/android/internal/telephony/uicc/IccRecords:mContext	Landroid/content/Context;
    //   2421: aload_0
    //   2422: getfield 884	com/android/internal/telephony/uicc/IccRecords:mImsi	Ljava/lang/String;
    //   2425: iconst_0
    //   2426: iconst_3
    //   2427: aload_0
    //   2428: getfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   2431: iadd
    //   2432: invokevirtual 903	java/lang/String:substring	(II)Ljava/lang/String;
    //   2435: invokestatic 979	com/android/internal/telephony/MccTable:updateMccMncConfiguration	(Landroid/content/Context;Ljava/lang/String;)V
    //   2438: aload 35
    //   2440: athrow
    //   2441: iconst_1
    //   2442: istore_2
    //   2443: aload_0
    //   2444: iconst_0
    //   2445: aload_1
    //   2446: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2449: checkcast 535	android/os/AsyncResult
    //   2452: invokespecial 864	com/android/internal/telephony/uicc/SIMRecords:getSpnFsm	(ZLandroid/os/AsyncResult;)V
    //   2455: goto -2234 -> 221
    //   2458: iconst_1
    //   2459: istore_2
    //   2460: aload_1
    //   2461: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2464: checkcast 535	android/os/AsyncResult
    //   2467: astore 32
    //   2469: aload 32
    //   2471: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2474: checkcast 544	[B
    //   2477: checkcast 544	[B
    //   2480: astore 33
    //   2482: aload 32
    //   2484: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2487: ifnonnull -2266 -> 221
    //   2490: aload_0
    //   2491: new 453	java/lang/StringBuilder
    //   2494: dup
    //   2495: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   2498: ldc_w 1053
    //   2501: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2504: aload 33
    //   2506: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   2509: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2512: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   2515: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   2518: aload_0
    //   2519: aload 33
    //   2521: putfield 390	com/android/internal/telephony/uicc/SIMRecords:mEfCff	[B
    //   2524: aload_0
    //   2525: aload_0
    //   2526: getfield 392	com/android/internal/telephony/uicc/SIMRecords:mEfCfis	[B
    //   2529: invokespecial 1055	com/android/internal/telephony/uicc/SIMRecords:validEfCfis	([B)Z
    //   2532: ifne +38 -> 2570
    //   2535: bipush 15
    //   2537: aload 33
    //   2539: iconst_0
    //   2540: baload
    //   2541: iand
    //   2542: bipush 10
    //   2544: if_icmpne +1547 -> 4091
    //   2547: iconst_1
    //   2548: istore 34
    //   2550: aload_0
    //   2551: iload 34
    //   2553: putfield 812	com/android/internal/telephony/uicc/SIMRecords:mCallForwardingEnabled	Z
    //   2556: aload_0
    //   2557: getfield 1033	com/android/internal/telephony/uicc/IccRecords:mRecordsEventsRegistrants	Landroid/os/RegistrantList;
    //   2560: iconst_1
    //   2561: invokestatic 1037	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   2564: invokevirtual 489	android/os/RegistrantList:notifyResult	(Ljava/lang/Object;)V
    //   2567: goto -2346 -> 221
    //   2570: aload_0
    //   2571: ldc_w 1057
    //   2574: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   2577: goto -2356 -> 221
    //   2580: iconst_1
    //   2581: istore_2
    //   2582: aload_1
    //   2583: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2586: checkcast 535	android/os/AsyncResult
    //   2589: astore 30
    //   2591: aload 30
    //   2593: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2596: checkcast 544	[B
    //   2599: checkcast 544	[B
    //   2602: astore 31
    //   2604: aload 30
    //   2606: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2609: ifnonnull -2388 -> 221
    //   2612: aload_0
    //   2613: aload 31
    //   2615: invokespecial 1059	com/android/internal/telephony/uicc/SIMRecords:parseEfSpdi	([B)V
    //   2618: goto -2397 -> 221
    //   2621: aload_1
    //   2622: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2625: checkcast 535	android/os/AsyncResult
    //   2628: astore 29
    //   2630: aload 29
    //   2632: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2635: ifnull -2414 -> 221
    //   2638: aload_0
    //   2639: ldc_w 1061
    //   2642: aload 29
    //   2644: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2647: invokevirtual 951	com/android/internal/telephony/uicc/SIMRecords:logw	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   2650: goto -2429 -> 221
    //   2653: iconst_1
    //   2654: istore_2
    //   2655: aload_1
    //   2656: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2659: checkcast 535	android/os/AsyncResult
    //   2662: astore 25
    //   2664: aload 25
    //   2666: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2669: checkcast 544	[B
    //   2672: checkcast 544	[B
    //   2675: astore 26
    //   2677: aload 25
    //   2679: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2682: ifnonnull -2461 -> 221
    //   2685: new 720	com/android/internal/telephony/gsm/SimTlv
    //   2688: dup
    //   2689: aload 26
    //   2691: iconst_0
    //   2692: aload 26
    //   2694: arraylength
    //   2695: invokespecial 723	com/android/internal/telephony/gsm/SimTlv:<init>	([BII)V
    //   2698: astore 27
    //   2700: aload 27
    //   2702: invokevirtual 726	com/android/internal/telephony/gsm/SimTlv:isValidObject	()Z
    //   2705: ifeq -2484 -> 221
    //   2708: aload 27
    //   2710: invokevirtual 729	com/android/internal/telephony/gsm/SimTlv:getTag	()I
    //   2713: bipush 67
    //   2715: if_icmpne +25 -> 2740
    //   2718: aload_0
    //   2719: aload 27
    //   2721: invokevirtual 733	com/android/internal/telephony/gsm/SimTlv:getData	()[B
    //   2724: iconst_0
    //   2725: aload 27
    //   2727: invokevirtual 733	com/android/internal/telephony/gsm/SimTlv:getData	()[B
    //   2730: arraylength
    //   2731: invokestatic 1064	com/android/internal/telephony/uicc/IccUtils:networkNameToString	([BII)Ljava/lang/String;
    //   2734: putfield 396	com/android/internal/telephony/uicc/SIMRecords:mPnnHomeName	Ljava/lang/String;
    //   2737: goto -2516 -> 221
    //   2740: aload 27
    //   2742: invokevirtual 736	com/android/internal/telephony/gsm/SimTlv:nextObject	()Z
    //   2745: pop
    //   2746: goto -46 -> 2700
    //   2749: iconst_1
    //   2750: istore_2
    //   2751: aload_1
    //   2752: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2755: checkcast 535	android/os/AsyncResult
    //   2758: astore 24
    //   2760: aload 24
    //   2762: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2765: ifnonnull -2544 -> 221
    //   2768: aload_0
    //   2769: aload 24
    //   2771: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2774: checkcast 679	java/util/ArrayList
    //   2777: invokespecial 1066	com/android/internal/telephony/uicc/SIMRecords:handleSmses	(Ljava/util/ArrayList;)V
    //   2780: goto -2559 -> 221
    //   2783: ldc_w 651
    //   2786: new 453	java/lang/StringBuilder
    //   2789: dup
    //   2790: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   2793: ldc_w 1068
    //   2796: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2799: aload_1
    //   2800: getfield 1071	android/os/Message:arg1	I
    //   2803: invokevirtual 559	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   2806: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   2809: invokestatic 693	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   2812: pop
    //   2813: goto -2592 -> 221
    //   2816: iconst_0
    //   2817: istore_2
    //   2818: aload_1
    //   2819: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2822: checkcast 535	android/os/AsyncResult
    //   2825: astore 21
    //   2827: aload 21
    //   2829: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2832: checkcast 1072	[I
    //   2835: checkcast 1072	[I
    //   2838: astore 22
    //   2840: aload 21
    //   2842: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2845: ifnonnull +10 -> 2855
    //   2848: aload 22
    //   2850: arraylength
    //   2851: iconst_1
    //   2852: if_icmpeq +46 -> 2898
    //   2855: aload_0
    //   2856: new 453	java/lang/StringBuilder
    //   2859: dup
    //   2860: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   2863: ldc_w 1074
    //   2866: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2869: aload 21
    //   2871: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2874: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   2877: ldc_w 1076
    //   2880: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2883: aload 22
    //   2885: arraylength
    //   2886: invokevirtual 559	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   2889: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   2892: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   2895: goto -2674 -> 221
    //   2898: aload_0
    //   2899: new 453	java/lang/StringBuilder
    //   2902: dup
    //   2903: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   2906: ldc_w 1078
    //   2909: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2912: aload 22
    //   2914: iconst_0
    //   2915: iaload
    //   2916: invokevirtual 559	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   2919: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   2922: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   2925: aload_0
    //   2926: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   2929: sipush 28476
    //   2932: aload 22
    //   2934: iconst_0
    //   2935: iaload
    //   2936: aload_0
    //   2937: bipush 22
    //   2939: invokevirtual 527	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(I)Landroid/os/Message;
    //   2942: invokevirtual 862	com/android/internal/telephony/uicc/IccFileHandler:loadEFLinearFixed	(IILandroid/os/Message;)V
    //   2945: goto -2724 -> 221
    //   2948: iconst_0
    //   2949: istore_2
    //   2950: aload_1
    //   2951: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   2954: checkcast 535	android/os/AsyncResult
    //   2957: astore 20
    //   2959: aload 20
    //   2961: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   2964: ifnonnull +21 -> 2985
    //   2967: aload_0
    //   2968: aload 20
    //   2970: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   2973: checkcast 544	[B
    //   2976: checkcast 544	[B
    //   2979: invokespecial 1080	com/android/internal/telephony/uicc/SIMRecords:handleSms	([B)V
    //   2982: goto -2761 -> 221
    //   2985: aload_0
    //   2986: new 453	java/lang/StringBuilder
    //   2989: dup
    //   2990: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   2993: ldc_w 1082
    //   2996: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2999: aload 20
    //   3001: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3004: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3007: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3010: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3013: goto -2792 -> 221
    //   3016: iconst_1
    //   3017: istore_2
    //   3018: aload_1
    //   3019: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3022: checkcast 535	android/os/AsyncResult
    //   3025: astore 18
    //   3027: aload 18
    //   3029: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3032: checkcast 544	[B
    //   3035: checkcast 544	[B
    //   3038: astore 19
    //   3040: aload 18
    //   3042: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3045: ifnonnull -2824 -> 221
    //   3048: aload_0
    //   3049: new 1084	com/android/internal/telephony/uicc/UsimServiceTable
    //   3052: dup
    //   3053: aload 19
    //   3055: invokespecial 1086	com/android/internal/telephony/uicc/UsimServiceTable:<init>	([B)V
    //   3058: putfield 844	com/android/internal/telephony/uicc/SIMRecords:mUsimServiceTable	Lcom/android/internal/telephony/uicc/UsimServiceTable;
    //   3061: aload_0
    //   3062: new 453	java/lang/StringBuilder
    //   3065: dup
    //   3066: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3069: ldc_w 1088
    //   3072: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3075: aload_0
    //   3076: getfield 844	com/android/internal/telephony/uicc/SIMRecords:mUsimServiceTable	Lcom/android/internal/telephony/uicc/UsimServiceTable;
    //   3079: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3082: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3085: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3088: goto -2867 -> 221
    //   3091: iconst_1
    //   3092: istore_2
    //   3093: aload_1
    //   3094: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3097: checkcast 535	android/os/AsyncResult
    //   3100: astore 17
    //   3102: aload 17
    //   3104: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3107: ifnonnull -2886 -> 221
    //   3110: aload_0
    //   3111: aload 17
    //   3113: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3116: checkcast 544	[B
    //   3119: checkcast 544	[B
    //   3122: putfield 382	com/android/internal/telephony/uicc/SIMRecords:mCphsInfo	[B
    //   3125: aload_0
    //   3126: new 453	java/lang/StringBuilder
    //   3129: dup
    //   3130: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3133: ldc_w 1090
    //   3136: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3139: aload_0
    //   3140: getfield 382	com/android/internal/telephony/uicc/SIMRecords:mCphsInfo	[B
    //   3143: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   3146: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3149: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3152: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3155: goto -2934 -> 221
    //   3158: iconst_0
    //   3159: istore_2
    //   3160: aload_1
    //   3161: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3164: checkcast 535	android/os/AsyncResult
    //   3167: astore 14
    //   3169: aload 14
    //   3171: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3174: ifnonnull +19 -> 3193
    //   3177: aload_0
    //   3178: aload_0
    //   3179: getfield 1093	com/android/internal/telephony/uicc/IccRecords:mNewVoiceMailNum	Ljava/lang/String;
    //   3182: putfield 768	com/android/internal/telephony/uicc/IccRecords:mVoiceMailNum	Ljava/lang/String;
    //   3185: aload_0
    //   3186: aload_0
    //   3187: getfield 1096	com/android/internal/telephony/uicc/IccRecords:mNewVoiceMailTag	Ljava/lang/String;
    //   3190: putfield 774	com/android/internal/telephony/uicc/IccRecords:mVoiceMailTag	Ljava/lang/String;
    //   3193: aload_0
    //   3194: invokespecial 1098	com/android/internal/telephony/uicc/SIMRecords:isCphsMailboxEnabled	()Z
    //   3197: ifeq +117 -> 3314
    //   3200: new 997	com/android/internal/telephony/uicc/AdnRecord
    //   3203: dup
    //   3204: aload_0
    //   3205: getfield 774	com/android/internal/telephony/uicc/IccRecords:mVoiceMailTag	Ljava/lang/String;
    //   3208: aload_0
    //   3209: getfield 768	com/android/internal/telephony/uicc/IccRecords:mVoiceMailNum	Ljava/lang/String;
    //   3212: invokespecial 1100	com/android/internal/telephony/uicc/AdnRecord:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   3215: astore 15
    //   3217: aload 14
    //   3219: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3222: checkcast 927	android/os/Message
    //   3225: astore 16
    //   3227: aload 14
    //   3229: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3232: ifnonnull +47 -> 3279
    //   3235: aload 14
    //   3237: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3240: ifnull +39 -> 3279
    //   3243: aload 14
    //   3245: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3248: checkcast 927	android/os/Message
    //   3251: invokestatic 1020	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   3254: aconst_null
    //   3255: putfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3258: aload 14
    //   3260: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3263: checkcast 927	android/os/Message
    //   3266: invokevirtual 1023	android/os/Message:sendToTarget	()V
    //   3269: aload_0
    //   3270: ldc_w 1102
    //   3273: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3276: aconst_null
    //   3277: astore 16
    //   3279: new 599	com/android/internal/telephony/uicc/AdnRecordLoader
    //   3282: dup
    //   3283: aload_0
    //   3284: getfield 402	com/android/internal/telephony/uicc/IccRecords:mFh	Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   3287: invokespecial 600	com/android/internal/telephony/uicc/AdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/IccFileHandler;)V
    //   3290: aload 15
    //   3292: sipush 28439
    //   3295: sipush 28490
    //   3298: iconst_1
    //   3299: aconst_null
    //   3300: aload_0
    //   3301: bipush 25
    //   3303: aload 16
    //   3305: invokevirtual 1105	com/android/internal/telephony/uicc/SIMRecords:obtainMessage	(ILjava/lang/Object;)Landroid/os/Message;
    //   3308: invokevirtual 1109	com/android/internal/telephony/uicc/AdnRecordLoader:updateEF	(Lcom/android/internal/telephony/uicc/AdnRecord;IIILjava/lang/String;Landroid/os/Message;)V
    //   3311: goto -3090 -> 221
    //   3314: aload 14
    //   3316: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3319: ifnull -3098 -> 221
    //   3322: aload 14
    //   3324: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3327: checkcast 927	android/os/Message
    //   3330: invokestatic 1020	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   3333: aload 14
    //   3335: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3338: putfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3341: aload 14
    //   3343: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3346: checkcast 927	android/os/Message
    //   3349: invokevirtual 1023	android/os/Message:sendToTarget	()V
    //   3352: goto -3131 -> 221
    //   3355: iconst_0
    //   3356: istore_2
    //   3357: aload_1
    //   3358: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3361: checkcast 535	android/os/AsyncResult
    //   3364: astore 13
    //   3366: aload 13
    //   3368: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3371: ifnonnull +67 -> 3438
    //   3374: aload_0
    //   3375: aload_0
    //   3376: getfield 1093	com/android/internal/telephony/uicc/IccRecords:mNewVoiceMailNum	Ljava/lang/String;
    //   3379: putfield 768	com/android/internal/telephony/uicc/IccRecords:mVoiceMailNum	Ljava/lang/String;
    //   3382: aload_0
    //   3383: aload_0
    //   3384: getfield 1096	com/android/internal/telephony/uicc/IccRecords:mNewVoiceMailTag	Ljava/lang/String;
    //   3387: putfield 774	com/android/internal/telephony/uicc/IccRecords:mVoiceMailTag	Ljava/lang/String;
    //   3390: aload 13
    //   3392: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3395: ifnull -3174 -> 221
    //   3398: aload_0
    //   3399: ldc_w 1111
    //   3402: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3405: aload 13
    //   3407: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3410: checkcast 927	android/os/Message
    //   3413: invokestatic 1020	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   3416: aload 13
    //   3418: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3421: putfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3424: aload 13
    //   3426: getfield 1016	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   3429: checkcast 927	android/os/Message
    //   3432: invokevirtual 1023	android/os/Message:sendToTarget	()V
    //   3435: goto -3214 -> 221
    //   3438: aload_0
    //   3439: new 453	java/lang/StringBuilder
    //   3442: dup
    //   3443: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3446: ldc_w 1113
    //   3449: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3452: aload 13
    //   3454: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3457: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3460: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3463: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3466: goto -76 -> 3390
    //   3469: iconst_0
    //   3470: istore_2
    //   3471: aload_1
    //   3472: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3475: checkcast 535	android/os/AsyncResult
    //   3478: astore 12
    //   3480: aload_0
    //   3481: new 453	java/lang/StringBuilder
    //   3484: dup
    //   3485: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3488: ldc_w 1115
    //   3491: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3494: aload 12
    //   3496: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3499: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3502: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3505: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3508: aload 12
    //   3510: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3513: ifnonnull -3292 -> 221
    //   3516: aload_0
    //   3517: aload 12
    //   3519: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3522: checkcast 615	com/android/internal/telephony/uicc/IccRefreshResponse
    //   3525: invokespecial 1117	com/android/internal/telephony/uicc/SIMRecords:handleSimRefresh	(Lcom/android/internal/telephony/uicc/IccRefreshResponse;)V
    //   3528: goto -3307 -> 221
    //   3531: iconst_1
    //   3532: istore_2
    //   3533: aload_1
    //   3534: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3537: checkcast 535	android/os/AsyncResult
    //   3540: astore 9
    //   3542: aload 9
    //   3544: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3547: checkcast 544	[B
    //   3550: checkcast 544	[B
    //   3553: astore 10
    //   3555: aload 9
    //   3557: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3560: ifnonnull -3339 -> 221
    //   3563: aload_0
    //   3564: new 453	java/lang/StringBuilder
    //   3567: dup
    //   3568: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3571: ldc_w 1119
    //   3574: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3577: aload 10
    //   3579: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   3582: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3585: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3588: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3591: aload_0
    //   3592: aload 10
    //   3594: invokespecial 1055	com/android/internal/telephony/uicc/SIMRecords:validEfCfis	([B)Z
    //   3597: ifeq +68 -> 3665
    //   3600: aload_0
    //   3601: aload 10
    //   3603: putfield 392	com/android/internal/telephony/uicc/SIMRecords:mEfCfis	[B
    //   3606: iconst_1
    //   3607: aload 10
    //   3609: iconst_1
    //   3610: baload
    //   3611: iand
    //   3612: ifeq +485 -> 4097
    //   3615: iconst_1
    //   3616: istore 11
    //   3618: aload_0
    //   3619: iload 11
    //   3621: putfield 812	com/android/internal/telephony/uicc/SIMRecords:mCallForwardingEnabled	Z
    //   3624: aload_0
    //   3625: new 453	java/lang/StringBuilder
    //   3628: dup
    //   3629: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3632: ldc_w 1121
    //   3635: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3638: aload_0
    //   3639: getfield 812	com/android/internal/telephony/uicc/SIMRecords:mCallForwardingEnabled	Z
    //   3642: invokevirtual 815	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   3645: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3648: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3651: aload_0
    //   3652: getfield 1033	com/android/internal/telephony/uicc/IccRecords:mRecordsEventsRegistrants	Landroid/os/RegistrantList;
    //   3655: iconst_1
    //   3656: invokestatic 1037	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   3659: invokevirtual 489	android/os/RegistrantList:notifyResult	(Ljava/lang/Object;)V
    //   3662: goto -3441 -> 221
    //   3665: aload_0
    //   3666: new 453	java/lang/StringBuilder
    //   3669: dup
    //   3670: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3673: ldc_w 1123
    //   3676: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3679: aload 10
    //   3681: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   3684: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3687: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3690: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3693: goto -3472 -> 221
    //   3696: iconst_1
    //   3697: istore_2
    //   3698: aload_1
    //   3699: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3702: checkcast 535	android/os/AsyncResult
    //   3705: astore 7
    //   3707: aload 7
    //   3709: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3712: ifnull +34 -> 3746
    //   3715: aload_0
    //   3716: new 453	java/lang/StringBuilder
    //   3719: dup
    //   3720: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3723: ldc_w 1125
    //   3726: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3729: aload 7
    //   3731: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3734: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3737: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3740: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3743: goto -3522 -> 221
    //   3746: aload 7
    //   3748: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3751: checkcast 544	[B
    //   3754: checkcast 544	[B
    //   3757: astore 8
    //   3759: aload_0
    //   3760: new 453	java/lang/StringBuilder
    //   3763: dup
    //   3764: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3767: ldc_w 1127
    //   3770: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3773: aload 8
    //   3775: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   3778: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3781: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3784: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3787: aload_0
    //   3788: aload 8
    //   3790: invokespecial 1129	com/android/internal/telephony/uicc/SIMRecords:handleEfCspData	([B)V
    //   3793: goto -3572 -> 221
    //   3796: iconst_1
    //   3797: istore_2
    //   3798: aload_1
    //   3799: getfield 954	android/os/Message:obj	Ljava/lang/Object;
    //   3802: checkcast 535	android/os/AsyncResult
    //   3805: astore 5
    //   3807: aload 5
    //   3809: getfield 543	android/os/AsyncResult:result	Ljava/lang/Object;
    //   3812: checkcast 544	[B
    //   3815: checkcast 544	[B
    //   3818: astore 6
    //   3820: aload 5
    //   3822: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3825: ifnull +39 -> 3864
    //   3828: aload_0
    //   3829: new 453	java/lang/StringBuilder
    //   3832: dup
    //   3833: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3836: ldc_w 1131
    //   3839: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3842: aload 5
    //   3844: getfield 539	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   3847: invokevirtual 463	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   3850: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3853: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3856: aload_0
    //   3857: aconst_null
    //   3858: putfield 849	com/android/internal/telephony/uicc/IccRecords:mGid1	Ljava/lang/String;
    //   3861: goto -3640 -> 221
    //   3864: aload_0
    //   3865: aload 6
    //   3867: invokestatic 989	com/android/internal/telephony/uicc/IccUtils:bytesToHexString	([B)Ljava/lang/String;
    //   3870: putfield 849	com/android/internal/telephony/uicc/IccRecords:mGid1	Ljava/lang/String;
    //   3873: aload_0
    //   3874: new 453	java/lang/StringBuilder
    //   3877: dup
    //   3878: invokespecial 454	java/lang/StringBuilder:<init>	()V
    //   3881: ldc_w 1133
    //   3884: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3887: aload_0
    //   3888: getfield 849	com/android/internal/telephony/uicc/IccRecords:mGid1	Ljava/lang/String;
    //   3891: invokevirtual 460	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   3894: invokevirtual 467	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   3897: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3900: goto -3679 -> 221
    //   3903: aload_0
    //   3904: iconst_0
    //   3905: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3908: aload_0
    //   3909: ldc_w 1051
    //   3912: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3915: goto -1512 -> 2403
    //   3918: astore 37
    //   3920: aload_0
    //   3921: iconst_0
    //   3922: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3925: aload_0
    //   3926: ldc_w 984
    //   3929: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3932: goto -1529 -> 2403
    //   3935: aload_0
    //   3936: iconst_0
    //   3937: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3940: aload_0
    //   3941: ldc_w 1051
    //   3944: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3947: goto -2327 -> 1620
    //   3950: astore 64
    //   3952: aload_0
    //   3953: iconst_0
    //   3954: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3957: aload_0
    //   3958: ldc_w 984
    //   3961: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3964: goto -2344 -> 1620
    //   3967: aload_0
    //   3968: iconst_0
    //   3969: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3972: aload_0
    //   3973: ldc_w 1051
    //   3976: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   3979: goto -2142 -> 1837
    //   3982: astore 58
    //   3984: aload_0
    //   3985: iconst_0
    //   3986: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   3989: aload_0
    //   3990: ldc_w 984
    //   3993: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   3996: goto -2159 -> 1837
    //   3999: aload_0
    //   4000: iconst_0
    //   4001: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   4004: aload_0
    //   4005: ldc_w 1051
    //   4008: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   4011: goto -1985 -> 2026
    //   4014: astore 52
    //   4016: aload_0
    //   4017: iconst_0
    //   4018: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   4021: aload_0
    //   4022: ldc_w 984
    //   4025: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   4028: goto -2002 -> 2026
    //   4031: aload_0
    //   4032: iconst_0
    //   4033: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   4036: aload_0
    //   4037: ldc_w 1051
    //   4040: invokevirtual 471	com/android/internal/telephony/uicc/SIMRecords:log	(Ljava/lang/String;)V
    //   4043: goto -1817 -> 2226
    //   4046: astore 46
    //   4048: aload_0
    //   4049: iconst_0
    //   4050: putfield 897	com/android/internal/telephony/uicc/IccRecords:mMncLength	I
    //   4053: aload_0
    //   4054: ldc_w 984
    //   4057: invokevirtual 937	com/android/internal/telephony/uicc/SIMRecords:loge	(Ljava/lang/String;)V
    //   4060: goto -1834 -> 2226
    //   4063: iinc 95 1
    //   4066: goto -3607 -> 459
    //   4069: ldc_w 1135
    //   4072: astore 85
    //   4074: goto -3259 -> 815
    //   4077: ldc_w 1137
    //   4080: astore 83
    //   4082: goto -3160 -> 922
    //   4085: iconst_0
    //   4086: istore 76
    //   4088: goto -2853 -> 1235
    //   4091: iconst_0
    //   4092: istore 34
    //   4094: goto -1544 -> 2550
    //   4097: iconst_0
    //   4098: istore 11
    //   4100: goto -482 -> 3618
    //   4103: iinc 41 1
    //   4106: goto -1773 -> 2333
    //   4109: iinc 68 1
    //   4112: goto -2562 -> 1550
    //   4115: iinc 62 1
    //   4118: goto -2351 -> 1767
    //   4121: iinc 56 1
    //   4124: goto -2168 -> 1956
    //   4127: iinc 50 1
    //   4130: goto -1974 -> 2156
    //
    // Exception table:
    //   from	to	target	type
    //   62	221	239	java/lang/RuntimeException
    //   232	236	239	java/lang/RuntimeException
    //   259	304	239	java/lang/RuntimeException
    //   318	490	239	java/lang/RuntimeException
    //   495	514	239	java/lang/RuntimeException
    //   514	1444	239	java/lang/RuntimeException
    //   1483	1596	239	java/lang/RuntimeException
    //   1601	1620	239	java/lang/RuntimeException
    //   1620	1655	239	java/lang/RuntimeException
    //   1700	1813	239	java/lang/RuntimeException
    //   1818	1837	239	java/lang/RuntimeException
    //   1837	1872	239	java/lang/RuntimeException
    //   1889	2002	239	java/lang/RuntimeException
    //   2007	2026	239	java/lang/RuntimeException
    //   2026	2061	239	java/lang/RuntimeException
    //   2089	2202	239	java/lang/RuntimeException
    //   2207	2226	239	java/lang/RuntimeException
    //   2226	2379	239	java/lang/RuntimeException
    //   2384	2403	239	java/lang/RuntimeException
    //   2403	4060	239	java/lang/RuntimeException
    //   62	221	307	finally
    //   232	236	307	finally
    //   241	250	307	finally
    //   259	304	307	finally
    //   318	490	307	finally
    //   495	514	307	finally
    //   514	1444	307	finally
    //   1483	1596	307	finally
    //   1601	1620	307	finally
    //   1620	1655	307	finally
    //   1700	1813	307	finally
    //   1818	1837	307	finally
    //   1837	1872	307	finally
    //   1889	2002	307	finally
    //   2007	2026	307	finally
    //   2026	2061	307	finally
    //   2089	2202	307	finally
    //   2207	2226	307	finally
    //   2226	2379	307	finally
    //   2384	2403	307	finally
    //   2403	4060	307	finally
    //   495	514	560	java/lang/NumberFormatException
    //   1449	1478	2264	finally
    //   1658	1700	2264	finally
    //   1875	1889	2264	finally
    //   2064	2089	2264	finally
    //   2384	2403	3918	java/lang/NumberFormatException
    //   1601	1620	3950	java/lang/NumberFormatException
    //   1818	1837	3982	java/lang/NumberFormatException
    //   2007	2026	4014	java/lang/NumberFormatException
    //   2207	2226	4046	java/lang/NumberFormatException
  }

  public boolean isCspPlmnEnabled()
  {
    return this.mCspPlmnEnabled;
  }

  protected void log(String paramString)
  {
    Rlog.d("SIMRecords", "[SIMRecords] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("SIMRecords", "[SIMRecords] " + paramString);
  }

  protected void logv(String paramString)
  {
    Rlog.v("SIMRecords", "[SIMRecords] " + paramString);
  }

  protected void logw(String paramString, Throwable paramThrowable)
  {
    Rlog.w("SIMRecords", "[SIMRecords] " + paramString, paramThrowable);
  }

  protected void onAllRecordsLoaded()
  {
    log("record load complete");
    String str = getOperatorNumeric();
    if (!TextUtils.isEmpty(str))
    {
      log("onAllRecordsLoaded set 'gsm.sim.operator.numeric' to operator='" + str + "'");
      SystemProperties.set("gsm.sim.operator.numeric", str);
      if (TextUtils.isEmpty(this.mImsi))
        break label152;
      log("onAllRecordsLoaded set mcc imsi=" + this.mImsi);
      SystemProperties.set("gsm.sim.operator.iso-country", MccTable.countryCodeForMcc(Integer.parseInt(this.mImsi.substring(0, 3))));
    }
    while (true)
    {
      setVoiceMailByCountry(str);
      setSpnFromConfig(str);
      this.mRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
      return;
      log("onAllRecordsLoaded empty 'gsm.sim.operator.numeric' skipping");
      break;
      label152: log("onAllRecordsLoaded empty imsi skipping setting mcc");
    }
  }

  public void onReady()
  {
    fetchSimRecords();
  }

  protected void onRecordLoaded()
  {
    this.mRecordsToLoad = (-1 + this.mRecordsToLoad);
    log("onRecordLoaded " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
    if ((this.mRecordsToLoad == 0) && (this.mRecordsRequested == true))
      onAllRecordsLoaded();
    while (true)
    {
      return;
      if (this.mRecordsToLoad < 0)
      {
        loge("recordsToLoad <0, programmer error suspected");
        this.mRecordsToLoad = 0;
      }
    }
  }

  public void onRefresh(boolean paramBoolean, int[] paramArrayOfInt)
  {
    if (paramBoolean)
      fetchSimRecords();
  }

  protected void resetRecords()
  {
    this.mImsi = null;
    this.mMsisdn = null;
    this.mVoiceMailNum = null;
    this.mCountVoiceMessages = 0;
    this.mMncLength = -1;
    this.mIccId = null;
    this.mSpnDisplayCondition = -1;
    this.mEfMWIS = null;
    this.mEfCPHS_MWI = null;
    this.mSpdiNetworks = null;
    this.mPnnHomeName = null;
    this.mGid1 = null;
    this.mAdnCache.reset();
    log("SIMRecords: onRadioOffOrNotAvailable set 'gsm.sim.operator.numeric' to operator=null");
    SystemProperties.set("gsm.sim.operator.numeric", null);
    SystemProperties.set("gsm.sim.operator.alpha", null);
    SystemProperties.set("gsm.sim.operator.iso-country", null);
    this.mRecordsRequested = false;
  }

  public void setMsisdnNumber(String paramString1, String paramString2, Message paramMessage)
  {
    this.mMsisdn = paramString2;
    this.mMsisdnTag = paramString1;
    log("Set MSISDN: " + this.mMsisdnTag + " " + "xxxxxxx");
    AdnRecord localAdnRecord = new AdnRecord(this.mMsisdnTag, this.mMsisdn);
    new AdnRecordLoader(this.mFh).updateEF(localAdnRecord, 28480, 28490, 1, null, obtainMessage(30, paramMessage));
  }

  public void setVoiceCallForwardingFlag(int paramInt, boolean paramBoolean, String paramString)
  {
    if (paramInt != 1)
      return;
    this.mCallForwardingEnabled = paramBoolean;
    this.mRecordsEventsRegistrants.notifyResult(Integer.valueOf(1));
    while (true)
    {
      try
      {
        if (!validEfCfis(this.mEfCfis))
          break label299;
        if (!paramBoolean)
          break label277;
        byte[] arrayOfByte3 = this.mEfCfis;
        arrayOfByte3[1] = ((byte)(0x1 | arrayOfByte3[1]));
        log("setVoiceCallForwardingFlag: enable=" + paramBoolean + " mEfCfis=" + IccUtils.bytesToHexString(this.mEfCfis));
        if ((paramBoolean) && (!TextUtils.isEmpty(paramString)))
        {
          log("EF_CFIS: updating cf number, " + paramString);
          byte[] arrayOfByte2 = PhoneNumberUtils.numberToCalledPartyBCD(paramString);
          System.arraycopy(arrayOfByte2, 0, this.mEfCfis, 3, arrayOfByte2.length);
          this.mEfCfis[2] = ((byte)arrayOfByte2.length);
          this.mEfCfis[14] = -1;
          this.mEfCfis[15] = -1;
        }
        this.mFh.updateEFLinearFixed(28619, 1, this.mEfCfis, null, obtainMessage(14, Integer.valueOf(28619)));
        if (this.mEfCff == null)
          break;
        if (!paramBoolean)
          break label342;
        this.mEfCff[0] = ((byte)(0xA | 0xF0 & this.mEfCff[0]));
        this.mFh.updateEFTransparent(28435, this.mEfCff, obtainMessage(14, Integer.valueOf(28435)));
      }
      catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
      {
        logw("Error saving call forwarding flag to SIM. Probably malformed SIM record", localArrayIndexOutOfBoundsException);
      }
      break;
      label277: byte[] arrayOfByte1 = this.mEfCfis;
      arrayOfByte1[1] = ((byte)(0xFE & arrayOfByte1[1]));
      continue;
      label299: log("setVoiceCallForwardingFlag: ignoring enable=" + paramBoolean + " invalid mEfCfis=" + IccUtils.bytesToHexString(this.mEfCfis));
      continue;
      label342: this.mEfCff[0] = ((byte)(0x5 | 0xF0 & this.mEfCff[0]));
    }
  }

  public void setVoiceMailNumber(String paramString1, String paramString2, Message paramMessage)
  {
    if (this.mIsVoiceMailFixed)
    {
      AsyncResult.forMessage(paramMessage).exception = new IccVmFixedException("Voicemail number is fixed by operator");
      paramMessage.sendToTarget();
    }
    while (true)
    {
      return;
      this.mNewVoiceMailNum = paramString2;
      this.mNewVoiceMailTag = paramString1;
      AdnRecord localAdnRecord = new AdnRecord(this.mNewVoiceMailTag, this.mNewVoiceMailNum);
      if ((this.mMailboxIndex != 0) && (this.mMailboxIndex != 255))
      {
        new AdnRecordLoader(this.mFh).updateEF(localAdnRecord, 28615, 28616, this.mMailboxIndex, null, obtainMessage(20, paramMessage));
      }
      else if (isCphsMailboxEnabled())
      {
        new AdnRecordLoader(this.mFh).updateEF(localAdnRecord, 28439, 28490, 1, null, obtainMessage(25, paramMessage));
      }
      else
      {
        AsyncResult.forMessage(paramMessage).exception = new IccVmNotSupportedException("Update SIM voice mailbox error");
        paramMessage.sendToTarget();
      }
    }
  }

  public void setVoiceMessageWaiting(int paramInt1, int paramInt2)
  {
    int i = 0;
    if (paramInt1 != 1)
      return;
    if (paramInt2 < 0)
    {
      paramInt2 = -1;
      label14: this.mCountVoiceMessages = paramInt2;
      this.mRecordsEventsRegistrants.notifyResult(Integer.valueOf(0));
    }
    while (true)
    {
      try
      {
        if (this.mEfMWIS != null)
        {
          byte[] arrayOfByte2 = this.mEfMWIS;
          int m = 0xFE & this.mEfMWIS[0];
          if (this.mCountVoiceMessages != 0)
            break label212;
          arrayOfByte2[0] = ((byte)(i | m));
          if (paramInt2 >= 0)
            break label217;
          this.mEfMWIS[1] = 0;
          this.mFh.updateEFLinearFixed(28618, 1, this.mEfMWIS, null, obtainMessage(14, Integer.valueOf(28618)));
        }
        if (this.mEfCPHS_MWI == null)
          break;
        byte[] arrayOfByte1 = this.mEfCPHS_MWI;
        int j = 0xF0 & this.mEfCPHS_MWI[0];
        if (this.mCountVoiceMessages != 0)
          break label228;
        k = 5;
        arrayOfByte1[0] = ((byte)(k | j));
        this.mFh.updateEFTransparent(28433, this.mEfCPHS_MWI, obtainMessage(14, Integer.valueOf(28433)));
      }
      catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
      {
        logw("Error saving voice mail state to SIM. Probably malformed SIM record", localArrayIndexOutOfBoundsException);
      }
      break;
      if (paramInt2 <= 255)
        break label14;
      paramInt2 = 255;
      break label14;
      label212: i = 1;
      continue;
      label217: this.mEfMWIS[1] = ((byte)paramInt2);
      continue;
      label228: int k = 10;
    }
  }

  public String toString()
  {
    return "SimRecords: " + super.toString() + " mVmConfig" + this.mVmConfig + " mSpnOverride=" + "mSpnOverride" + " callForwardingEnabled=" + this.mCallForwardingEnabled + " spnState=" + this.mSpnState + " mCphsInfo=" + this.mCphsInfo + " mCspPlmnEnabled=" + this.mCspPlmnEnabled + " efMWIS=" + this.mEfMWIS + " efCPHS_MWI=" + this.mEfCPHS_MWI + " mEfCff=" + this.mEfCff + " mEfCfis=" + this.mEfCfis + " getOperatorNumeric=" + getOperatorNumeric();
  }

  private static enum GetSpnFsmState
  {
    static
    {
      GetSpnFsmState[] arrayOfGetSpnFsmState = new GetSpnFsmState[5];
      arrayOfGetSpnFsmState[0] = IDLE;
      arrayOfGetSpnFsmState[1] = INIT;
      arrayOfGetSpnFsmState[2] = READ_SPN_3GPP;
      arrayOfGetSpnFsmState[3] = READ_SPN_CPHS;
      arrayOfGetSpnFsmState[4] = READ_SPN_SHORT_CPHS;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.SIMRecords
 * JD-Core Version:    0.6.2
 */