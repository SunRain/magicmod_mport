package com.android.internal.telephony.uicc;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.Registrant;
import android.os.RegistrantList;
import android.telephony.Rlog;
import android.view.Window;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.cat.CatService;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class UiccCard
{
  protected static final boolean DBG = true;
  private static final int EVENT_CARD_ADDED = 14;
  private static final int EVENT_CARD_REMOVED = 13;
  protected static final String LOG_TAG = "UiccCard";
  private RegistrantList mAbsentRegistrants = new RegistrantList();
  private IccCardStatus.CardState mCardState;
  private CatService mCatService;
  private int mCdmaSubscriptionAppIndex;
  private CommandsInterface mCi;
  private Context mContext;
  private boolean mDestroyed = false;
  private int mGsmUmtsSubscriptionAppIndex;
  protected Handler mHandler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      if (UiccCard.this.mDestroyed)
        UiccCard.this.loge("Received message " + paramAnonymousMessage + "[" + paramAnonymousMessage.what + "] while being destroyed. Ignoring.");
      while (true)
      {
        return;
        switch (paramAnonymousMessage.what)
        {
        default:
          UiccCard.this.loge("Unknown Event " + paramAnonymousMessage.what);
          break;
        case 13:
          UiccCard.this.onIccSwap(false);
          break;
        case 14:
          UiccCard.this.onIccSwap(true);
        }
      }
    }
  };
  private int mImsSubscriptionAppIndex;
  private CommandsInterface.RadioState mLastRadioState = CommandsInterface.RadioState.RADIO_UNAVAILABLE;
  private final Object mLock = new Object();
  private UiccCardApplication[] mUiccApplications = new UiccCardApplication[8];
  private IccCardStatus.PinState mUniversalPinState;

  public UiccCard(Context paramContext, CommandsInterface paramCommandsInterface, IccCardStatus paramIccCardStatus)
  {
    log("Creating");
    this.mCardState = paramIccCardStatus.mCardState;
    update(paramContext, paramCommandsInterface, paramIccCardStatus);
  }

  private int checkIndex(int paramInt, IccCardApplicationStatus.AppType paramAppType1, IccCardApplicationStatus.AppType paramAppType2)
  {
    if ((this.mUiccApplications == null) || (paramInt >= this.mUiccApplications.length))
    {
      loge("App index " + paramInt + " is invalid since there are no applications");
      paramInt = -1;
    }
    while (true)
    {
      return paramInt;
      if (paramInt < 0)
      {
        paramInt = -1;
      }
      else if ((this.mUiccApplications[paramInt].getType() != paramAppType1) && (this.mUiccApplications[paramInt].getType() != paramAppType2))
      {
        loge("App index " + paramInt + " is invalid since it's not " + paramAppType1 + " and not " + paramAppType2);
        paramInt = -1;
      }
    }
  }

  private void log(String paramString)
  {
    Rlog.d("UiccCard", paramString);
  }

  private void loge(String paramString)
  {
    Rlog.e("UiccCard", paramString);
  }

  private void onIccSwap(boolean paramBoolean)
  {
    if (Injector.UiccCardHook.before_onIccSwap(this.mContext, this.mLock, paramBoolean));
    while (true)
    {
      return;
      synchronized (this.mLock)
      {
        DialogInterface.OnClickListener local1 = new DialogInterface.OnClickListener()
        {
          public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
          {
            Object localObject1 = UiccCard.this.mLock;
            if (paramAnonymousInt == -1);
            try
            {
              UiccCard.this.log("Reboot due to SIM swap");
              ((PowerManager)UiccCard.this.mContext.getSystemService("power")).reboot("SIM is added.");
              return;
            }
            finally
            {
              localObject2 = finally;
              throw localObject2;
            }
          }
        };
        Resources localResources;
        while (true)
        {
          try
          {
            localResources = Resources.getSystem();
            if (!paramBoolean)
              break label134;
            str1 = localResources.getString(17040469);
            if (!paramBoolean)
              break label146;
            localObject4 = localResources.getString(17040470);
            String str3 = localResources.getString(17040471);
            AlertDialog localAlertDialog = new AlertDialog.Builder(this.mContext, 101515326).setTitle(str1).setMessage((CharSequence)localObject4).setPositiveButton(str3, local1).create();
            localAlertDialog.getWindow().setType(2003);
            localAlertDialog.show();
            break;
          }
          finally
          {
          }
          throw localObject2;
          label134: String str1 = localResources.getString(17040466);
        }
        label146: String str2 = localResources.getString(17040467);
        Object localObject4 = str2;
      }
    }
  }

  private void sanitizeApplicationIndexes()
  {
    this.mGsmUmtsSubscriptionAppIndex = checkIndex(this.mGsmUmtsSubscriptionAppIndex, IccCardApplicationStatus.AppType.APPTYPE_SIM, IccCardApplicationStatus.AppType.APPTYPE_USIM);
    this.mCdmaSubscriptionAppIndex = checkIndex(this.mCdmaSubscriptionAppIndex, IccCardApplicationStatus.AppType.APPTYPE_RUIM, IccCardApplicationStatus.AppType.APPTYPE_CSIM);
    this.mImsSubscriptionAppIndex = checkIndex(this.mImsSubscriptionAppIndex, IccCardApplicationStatus.AppType.APPTYPE_ISIM, null);
  }

  public void dispose()
  {
    while (true)
    {
      int j;
      synchronized (this.mLock)
      {
        log("Disposing card");
        if (this.mCatService != null)
          this.mCatService.dispose();
        UiccCardApplication[] arrayOfUiccCardApplication = this.mUiccApplications;
        int i = arrayOfUiccCardApplication.length;
        j = 0;
        if (j < i)
        {
          UiccCardApplication localUiccCardApplication = arrayOfUiccCardApplication[j];
          if (localUiccCardApplication != null)
            localUiccCardApplication.dispose();
        }
        else
        {
          this.mCatService = null;
          this.mUiccApplications = null;
          return;
        }
      }
      j++;
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("UiccCard:");
    paramPrintWriter.println(" mCi=" + this.mCi);
    paramPrintWriter.println(" mDestroyed=" + this.mDestroyed);
    paramPrintWriter.println(" mLastRadioState=" + this.mLastRadioState);
    paramPrintWriter.println(" mCatService=" + this.mCatService);
    paramPrintWriter.println(" mAbsentRegistrants: size=" + this.mAbsentRegistrants.size());
    for (int i = 0; i < this.mAbsentRegistrants.size(); i++)
      paramPrintWriter.println("  mAbsentRegistrants[" + i + "]=" + ((Registrant)this.mAbsentRegistrants.get(i)).getHandler());
    paramPrintWriter.println(" mCardState=" + this.mCardState);
    paramPrintWriter.println(" mUniversalPinState=" + this.mUniversalPinState);
    paramPrintWriter.println(" mGsmUmtsSubscriptionAppIndex=" + this.mGsmUmtsSubscriptionAppIndex);
    paramPrintWriter.println(" mCdmaSubscriptionAppIndex=" + this.mCdmaSubscriptionAppIndex);
    paramPrintWriter.println(" mImsSubscriptionAppIndex=" + this.mImsSubscriptionAppIndex);
    paramPrintWriter.println(" mImsSubscriptionAppIndex=" + this.mImsSubscriptionAppIndex);
    paramPrintWriter.println(" mUiccApplications: length=" + this.mUiccApplications.length);
    int j = 0;
    if (j < this.mUiccApplications.length)
    {
      if (this.mUiccApplications[j] == null)
        paramPrintWriter.println("  mUiccApplications[" + j + "]=" + null);
      while (true)
      {
        j++;
        break;
        paramPrintWriter.println("  mUiccApplications[" + j + "]=" + this.mUiccApplications[j].getType() + " " + this.mUiccApplications[j]);
      }
    }
    paramPrintWriter.println();
    for (UiccCardApplication localUiccCardApplication2 : this.mUiccApplications)
      if (localUiccCardApplication2 != null)
      {
        localUiccCardApplication2.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
        paramPrintWriter.println();
      }
    for (UiccCardApplication localUiccCardApplication1 : this.mUiccApplications)
      if (localUiccCardApplication1 != null)
      {
        IccRecords localIccRecords = localUiccCardApplication1.getIccRecords();
        if (localIccRecords != null)
        {
          localIccRecords.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          paramPrintWriter.println();
        }
      }
    paramPrintWriter.flush();
  }

  protected void finalize()
  {
    log("UiccCard finalized");
  }

  public UiccCardApplication getApplication(int paramInt)
  {
    Object localObject1 = this.mLock;
    int i = 8;
    switch (paramInt)
    {
    default:
    case 1:
    case 2:
    case 3:
    }
    UiccCardApplication localUiccCardApplication;
    while (true)
    {
      if (i >= 0);
      try
      {
        if (i < this.mUiccApplications.length)
        {
          localUiccCardApplication = this.mUiccApplications[i];
          break;
          i = this.mGsmUmtsSubscriptionAppIndex;
          continue;
          i = this.mCdmaSubscriptionAppIndex;
          continue;
          i = this.mImsSubscriptionAppIndex;
        }
        else
        {
          localUiccCardApplication = null;
        }
      }
      finally
      {
        localObject2 = finally;
        throw localObject2;
      }
    }
    return localUiccCardApplication;
  }

  public UiccCardApplication getApplicationIndex(int paramInt)
  {
    Object localObject1 = this.mLock;
    if (paramInt >= 0);
    UiccCardApplication localUiccCardApplication;
    try
    {
      if (paramInt < this.mUiccApplications.length)
        localUiccCardApplication = this.mUiccApplications[paramInt];
      else
        localUiccCardApplication = null;
    }
    finally
    {
      localObject2 = finally;
      throw localObject2;
    }
    return localUiccCardApplication;
  }

  public IccCardStatus.CardState getCardState()
  {
    synchronized (this.mLock)
    {
      IccCardStatus.CardState localCardState = this.mCardState;
      return localCardState;
    }
  }

  Context getContext()
  {
    return this.mContext;
  }

  Object getLock()
  {
    return this.mLock;
  }

  public IccCardStatus.PinState getUniversalPinState()
  {
    synchronized (this.mLock)
    {
      IccCardStatus.PinState localPinState = this.mUniversalPinState;
      return localPinState;
    }
  }

  public boolean isApplicationOnIcc(IccCardApplicationStatus.AppType paramAppType)
  {
    Object localObject1 = this.mLock;
    for (int i = 0; ; i++)
    {
      boolean bool;
      try
      {
        if (i < this.mUiccApplications.length)
        {
          if ((this.mUiccApplications[i] == null) || (this.mUiccApplications[i].getType() != paramAppType))
            continue;
          bool = true;
        }
        else
        {
          bool = false;
        }
      }
      finally
      {
        localObject2 = finally;
        throw localObject2;
      }
      return bool;
    }
  }

  public void registerForAbsent(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mAbsentRegistrants.add(localRegistrant);
      if (this.mCardState == IccCardStatus.CardState.CARDSTATE_ABSENT)
        localRegistrant.notifyRegistrant();
      return;
    }
  }

  public void unregisterForAbsent(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mAbsentRegistrants.remove(paramHandler);
      return;
    }
  }

  public void update(Context paramContext, CommandsInterface paramCommandsInterface, IccCardStatus paramIccCardStatus)
  {
    while (true)
    {
      IccCardStatus.CardState localCardState;
      int i;
      CommandsInterface.RadioState localRadioState;
      synchronized (this.mLock)
      {
        if (this.mDestroyed)
        {
          loge("Updated after destroyed! Fix me!");
        }
        else
        {
          localCardState = this.mCardState;
          this.mCardState = paramIccCardStatus.mCardState;
          this.mUniversalPinState = paramIccCardStatus.mUniversalPinState;
          this.mGsmUmtsSubscriptionAppIndex = paramIccCardStatus.mGsmUmtsSubscriptionAppIndex;
          this.mCdmaSubscriptionAppIndex = paramIccCardStatus.mCdmaSubscriptionAppIndex;
          this.mImsSubscriptionAppIndex = paramIccCardStatus.mImsSubscriptionAppIndex;
          this.mContext = paramContext;
          this.mCi = paramCommandsInterface;
          log(paramIccCardStatus.mApplications.length + " applications");
          i = 0;
          if (i < this.mUiccApplications.length)
            if (this.mUiccApplications[i] == null)
            {
              if (i < paramIccCardStatus.mApplications.length)
                this.mUiccApplications[i] = new UiccCardApplication(this, paramIccCardStatus.mApplications[i], this.mContext, this.mCi);
            }
            else if (i >= paramIccCardStatus.mApplications.length)
            {
              this.mUiccApplications[i].dispose();
              this.mUiccApplications[i] = null;
            }
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.UiccCard
 * JD-Core Version:    0.6.2
 */