package com.android.internal.telephony.uicc;

public final class IccVmFixedException extends IccException
{
  IccVmFixedException()
  {
  }

  public IccVmFixedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IccVmFixedException
 * JD-Core Version:    0.6.2
 */