package com.android.internal.telephony.uicc;

import android.os.AsyncResult;
import android.os.Message;
import android.util.SparseArray;
import com.android.internal.telephony.MiuiIccProviderException;
import com.android.internal.telephony.gsm.MiuiUsimPhoneBookManager;
import java.util.ArrayList;
import java.util.Iterator;

public class MiuiAdnRecordCache extends AdnRecordCache
{
  static final int EVENT_WAIT_ADN_ALL_LOAD_DONE = 101;
  static final int MAX_PHB_ANR_LENGTH = 20;
  static final int MAX_PHB_NAME_LENGTH = 60;
  static final int MAX_PHB_NUMBER_LENGTH = 40;
  SparseArray<ArrayList<MiuiAdnRecord>> mAdnLikeFiles = new SparseArray();
  SparseArray<ArrayList<Message>> mAdnLikeWaiters = new SparseArray();
  MiuiIccFileHandler mFh;
  private Object mLock = new Object();
  SparseArray<Message> mUserWriteResponse = new SparseArray();
  MiuiUsimPhoneBookManager mUsimPhoneBookManager;

  public MiuiAdnRecordCache(IccFileHandler paramIccFileHandler)
  {
    super(paramIccFileHandler);
    this.mFh = new MiuiIccFileHandler(paramIccFileHandler);
    this.mUsimPhoneBookManager = new MiuiUsimPhoneBookManager(paramIccFileHandler, this);
  }

  void clearUserWriters()
  {
    synchronized (this.mLock)
    {
      int i = this.mUserWriteResponse.size();
      for (int j = 0; j < i; j++)
        sendErrorResponse((Message)this.mUserWriteResponse.valueAt(j), -1013);
      this.mUserWriteResponse.clear();
      return;
    }
  }

  void clearWaiters()
  {
    synchronized (this.mLock)
    {
      int i = this.mAdnLikeWaiters.size();
      for (int j = 0; j < i; j++)
        notifyWaitersLocked((ArrayList)this.mAdnLikeWaiters.valueAt(j), new AsyncResult(null, null, new MiuiIccProviderException(-1013)));
      this.mAdnLikeWaiters.clear();
      return;
    }
  }

  public int getAdnCapacity(int paramInt)
  {
    ArrayList localArrayList = loadAllAdn(paramInt);
    if (localArrayList == null);
    for (int i = 0; ; i = localArrayList.size())
      return i;
  }

  public int getFreeAdn(int paramInt)
  {
    ArrayList localArrayList = loadAllAdn(paramInt);
    int i;
    if (localArrayList == null)
      i = 0;
    while (true)
    {
      return i;
      i = 0;
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
        if (((MiuiAdnRecord)localIterator.next()).isEmpty())
          i++;
    }
  }

  public ArrayList<AdnRecord> getRecordsIfLoaded(int paramInt)
  {
    return (ArrayList)this.mAdnLikeFiles.get(paramInt);
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 1:
    case 2:
    case 101:
    }
    while (true)
    {
      return;
      AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
      int k = paramMessage.arg1;
      synchronized (this.mLock)
      {
        ArrayList localArrayList1 = (ArrayList)this.mAdnLikeWaiters.get(k);
        this.mAdnLikeWaiters.delete(k);
        if (localAsyncResult2.exception == null)
        {
          ArrayList localArrayList2 = (ArrayList)localAsyncResult2.result;
          this.mAdnLikeFiles.put(k, localArrayList2);
        }
        notifyWaitersLocked(localArrayList1, localAsyncResult2);
      }
      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
      int i = paramMessage.arg1;
      synchronized (this.mLock)
      {
        int j = paramMessage.arg2;
        MiuiAdnRecord localMiuiAdnRecord = (MiuiAdnRecord)localAsyncResult1.userObj;
        if (localAsyncResult1.exception == null)
        {
          if (localMiuiAdnRecord != null)
          {
            localMiuiAdnRecord.mRecordNumber = j;
            if (localMiuiAdnRecord.mEfid <= 0)
              localMiuiAdnRecord.mEfid = i;
          }
          if (this.mAdnLikeFiles.get(i) != null)
          {
            localMiuiAdnRecord.setEmails(null);
            localMiuiAdnRecord.setAnr("");
            ((ArrayList)this.mAdnLikeFiles.get(i)).set(j - 1, localMiuiAdnRecord);
          }
        }
        Message localMessage = (Message)this.mUserWriteResponse.get(i);
        this.mUserWriteResponse.delete(i);
        if (localMessage != null)
        {
          AsyncResult.forMessage(localMessage, null, localAsyncResult1.exception);
          localMessage.sendToTarget();
        }
      }
      synchronized (this.mLock)
      {
        this.mLock.notify();
      }
    }
  }

  ArrayList<MiuiAdnRecord> loadAllAdn(int paramInt)
  {
    if (paramInt == 20272);
    for (ArrayList localArrayList = this.mUsimPhoneBookManager.getAdnRecordsIfLoaded(); ; localArrayList = (ArrayList)this.mAdnLikeFiles.get(paramInt))
      return localArrayList;
  }

  void notifyWaitersLocked(ArrayList<Message> paramArrayList, AsyncResult paramAsyncResult)
  {
    if (paramArrayList == null);
    while (true)
    {
      return;
      Iterator localIterator = paramArrayList.iterator();
      while (localIterator.hasNext())
      {
        Message localMessage = (Message)localIterator.next();
        if (localMessage != null)
        {
          AsyncResult.forMessage(localMessage, paramAsyncResult.result, paramAsyncResult.exception);
          localMessage.sendToTarget();
        }
      }
    }
  }

  // ERROR //
  public void requestLoadAllAdnLike(int paramInt1, int paramInt2, Message paramMessage)
  {
    // Byte code:
    //   0: iload_1
    //   1: sipush 20272
    //   4: if_icmpne +35 -> 39
    //   7: aload_0
    //   8: getfield 58	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mUsimPhoneBookManager	Lcom/android/internal/telephony/gsm/MiuiUsimPhoneBookManager;
    //   11: invokevirtual 196	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:loadEfFilesFromUsim	()Ljava/util/ArrayList;
    //   14: astore 4
    //   16: aload 4
    //   18: ifnull +37 -> 55
    //   21: aload_3
    //   22: ifnull +16 -> 38
    //   25: aload_3
    //   26: invokestatic 199	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   29: aload 4
    //   31: putfield 145	android/os/AsyncResult:result	Ljava/lang/Object;
    //   34: aload_3
    //   35: invokevirtual 184	android/os/Message:sendToTarget	()V
    //   38: return
    //   39: aload_0
    //   40: getfield 37	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mAdnLikeFiles	Landroid/util/SparseArray;
    //   43: iload_1
    //   44: invokevirtual 124	android/util/SparseArray:get	(I)Ljava/lang/Object;
    //   47: checkcast 79	java/util/ArrayList
    //   50: astore 4
    //   52: goto -36 -> 16
    //   55: iload_2
    //   56: ifge +31 -> 87
    //   59: aload_3
    //   60: ifnull -22 -> 38
    //   63: aload_3
    //   64: invokestatic 199	android/os/AsyncResult:forMessage	(Landroid/os/Message;)Landroid/os/AsyncResult;
    //   67: new 83	com/android/internal/telephony/MiuiIccProviderException
    //   70: dup
    //   71: sipush -1014
    //   74: invokespecial 86	com/android/internal/telephony/MiuiIccProviderException:<init>	(I)V
    //   77: putfield 142	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   80: aload_3
    //   81: invokevirtual 184	android/os/Message:sendToTarget	()V
    //   84: goto -46 -> 38
    //   87: aload_0
    //   88: getfield 46	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mLock	Ljava/lang/Object;
    //   91: astore 5
    //   93: aload 5
    //   95: monitorenter
    //   96: aload_0
    //   97: getfield 39	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mAdnLikeWaiters	Landroid/util/SparseArray;
    //   100: iload_1
    //   101: invokevirtual 124	android/util/SparseArray:get	(I)Ljava/lang/Object;
    //   104: checkcast 79	java/util/ArrayList
    //   107: astore 7
    //   109: aload 7
    //   111: ifnull +24 -> 135
    //   114: aload 7
    //   116: aload_3
    //   117: invokevirtual 203	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   120: pop
    //   121: aload 5
    //   123: monitorexit
    //   124: goto -86 -> 38
    //   127: astore 6
    //   129: aload 5
    //   131: monitorexit
    //   132: aload 6
    //   134: athrow
    //   135: new 79	java/util/ArrayList
    //   138: dup
    //   139: invokespecial 204	java/util/ArrayList:<init>	()V
    //   142: astore 8
    //   144: aload 8
    //   146: aload_3
    //   147: invokevirtual 203	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   150: pop
    //   151: aload_0
    //   152: getfield 39	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mAdnLikeWaiters	Landroid/util/SparseArray;
    //   155: iload_1
    //   156: aload 8
    //   158: invokevirtual 149	android/util/SparseArray:put	(ILjava/lang/Object;)V
    //   161: new 206	com/android/internal/telephony/uicc/MiuiAdnRecordLoader
    //   164: dup
    //   165: aload_0
    //   166: getfield 51	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mFh	Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;
    //   169: invokespecial 209	com/android/internal/telephony/uicc/MiuiAdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;)V
    //   172: iload_1
    //   173: iload_2
    //   174: aload_0
    //   175: iconst_1
    //   176: iload_1
    //   177: iconst_0
    //   178: invokevirtual 213	com/android/internal/telephony/uicc/MiuiAdnRecordCache:obtainMessage	(III)Landroid/os/Message;
    //   181: invokevirtual 216	com/android/internal/telephony/uicc/MiuiAdnRecordLoader:loadAllFromEF	(IILandroid/os/Message;)V
    //   184: aload 5
    //   186: monitorexit
    //   187: goto -149 -> 38
    //
    // Exception table:
    //   from	to	target	type
    //   96	132	127	finally
    //   135	187	127	finally
  }

  public void reset()
  {
    super.reset();
    this.mAdnLikeFiles.clear();
    this.mUsimPhoneBookManager.reset();
    clearWaiters();
    clearUserWriters();
  }

  void sendErrorResponse(Message paramMessage, int paramInt)
  {
    if (paramMessage != null)
    {
      AsyncResult.forMessage(paramMessage).exception = new MiuiIccProviderException(paramInt);
      paramMessage.sendToTarget();
    }
  }

  // ERROR //
  public void updateAdnByIndex(int paramInt1, AdnRecord paramAdnRecord, int paramInt2, String paramString, Message paramMessage)
  {
    // Byte code:
    //   0: aload_0
    //   1: iload_1
    //   2: invokevirtual 229	com/android/internal/telephony/uicc/MiuiAdnRecordCache:extensionEfForEf	(I)I
    //   5: istore 6
    //   7: iload 6
    //   9: ifge +13 -> 22
    //   12: aload_0
    //   13: aload 5
    //   15: sipush -1014
    //   18: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   21: return
    //   22: aload_2
    //   23: getfield 233	com/android/internal/telephony/uicc/AdnRecord:mAlphaTag	Ljava/lang/String;
    //   26: invokevirtual 238	java/lang/String:length	()I
    //   29: bipush 60
    //   31: if_icmple +15 -> 46
    //   34: aload_0
    //   35: aload 5
    //   37: sipush -1004
    //   40: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   43: goto -22 -> 21
    //   46: aload_2
    //   47: getfield 241	com/android/internal/telephony/uicc/AdnRecord:mNumber	Ljava/lang/String;
    //   50: invokevirtual 238	java/lang/String:length	()I
    //   53: istore 7
    //   55: iload 7
    //   57: ifle +19 -> 76
    //   60: aload_2
    //   61: getfield 241	com/android/internal/telephony/uicc/AdnRecord:mNumber	Ljava/lang/String;
    //   64: iconst_0
    //   65: invokevirtual 245	java/lang/String:charAt	(I)C
    //   68: bipush 43
    //   70: if_icmpne +6 -> 76
    //   73: iinc 7 255
    //   76: iload 7
    //   78: bipush 40
    //   80: if_icmple +15 -> 95
    //   83: aload_0
    //   84: aload 5
    //   86: sipush -1003
    //   89: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   92: goto -71 -> 21
    //   95: iload_1
    //   96: sipush 20272
    //   99: if_icmpne +88 -> 187
    //   102: aload_2
    //   103: checkcast 117	com/android/internal/telephony/uicc/MiuiAdnRecord
    //   106: astore 10
    //   108: aload 10
    //   110: getfield 248	com/android/internal/telephony/uicc/MiuiAdnRecord:mAnr	Ljava/lang/String;
    //   113: ifnull +28 -> 141
    //   116: aload 10
    //   118: getfield 248	com/android/internal/telephony/uicc/MiuiAdnRecord:mAnr	Ljava/lang/String;
    //   121: invokevirtual 238	java/lang/String:length	()I
    //   124: bipush 20
    //   126: if_icmple +15 -> 141
    //   129: aload_0
    //   130: aload 5
    //   132: sipush -1009
    //   135: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   138: goto -117 -> 21
    //   141: aload_0
    //   142: getfield 58	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mUsimPhoneBookManager	Lcom/android/internal/telephony/gsm/MiuiUsimPhoneBookManager;
    //   145: iload_3
    //   146: aload_2
    //   147: checkcast 117	com/android/internal/telephony/uicc/MiuiAdnRecord
    //   150: invokevirtual 252	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:update	(ILcom/android/internal/telephony/uicc/MiuiAdnRecord;)I
    //   153: istore 11
    //   155: iload 11
    //   157: ifeq +14 -> 171
    //   160: aload_0
    //   161: aload 5
    //   163: iload 11
    //   165: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   168: goto -147 -> 21
    //   171: aload 5
    //   173: aconst_null
    //   174: aconst_null
    //   175: invokestatic 181	android/os/AsyncResult:forMessage	(Landroid/os/Message;Ljava/lang/Object;Ljava/lang/Throwable;)Landroid/os/AsyncResult;
    //   178: pop
    //   179: aload 5
    //   181: invokevirtual 184	android/os/Message:sendToTarget	()V
    //   184: goto -163 -> 21
    //   187: aload_0
    //   188: getfield 46	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mLock	Ljava/lang/Object;
    //   191: astore 8
    //   193: aload 8
    //   195: monitorenter
    //   196: aload_0
    //   197: getfield 41	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mUserWriteResponse	Landroid/util/SparseArray;
    //   200: iload_1
    //   201: invokevirtual 124	android/util/SparseArray:get	(I)Ljava/lang/Object;
    //   204: ifnull +26 -> 230
    //   207: aload_0
    //   208: aload 5
    //   210: sipush -1006
    //   213: invokevirtual 73	com/android/internal/telephony/uicc/MiuiAdnRecordCache:sendErrorResponse	(Landroid/os/Message;I)V
    //   216: aload 8
    //   218: monitorexit
    //   219: goto -198 -> 21
    //   222: astore 9
    //   224: aload 8
    //   226: monitorexit
    //   227: aload 9
    //   229: athrow
    //   230: aload_0
    //   231: getfield 41	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mUserWriteResponse	Landroid/util/SparseArray;
    //   234: iload_1
    //   235: aload 5
    //   237: invokevirtual 149	android/util/SparseArray:put	(ILjava/lang/Object;)V
    //   240: new 206	com/android/internal/telephony/uicc/MiuiAdnRecordLoader
    //   243: dup
    //   244: aload_0
    //   245: getfield 51	com/android/internal/telephony/uicc/MiuiAdnRecordCache:mFh	Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;
    //   248: invokespecial 209	com/android/internal/telephony/uicc/MiuiAdnRecordLoader:<init>	(Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;)V
    //   251: aload_2
    //   252: iload_1
    //   253: iload 6
    //   255: iload_3
    //   256: aload 4
    //   258: aload_0
    //   259: iconst_2
    //   260: iload_1
    //   261: iload_3
    //   262: aload_2
    //   263: invokevirtual 255	com/android/internal/telephony/uicc/MiuiAdnRecordCache:obtainMessage	(IIILjava/lang/Object;)Landroid/os/Message;
    //   266: invokevirtual 259	com/android/internal/telephony/uicc/MiuiAdnRecordLoader:updateEF	(Lcom/android/internal/telephony/uicc/AdnRecord;IIILjava/lang/String;Landroid/os/Message;)V
    //   269: aload 8
    //   271: monitorexit
    //   272: goto -251 -> 21
    //
    // Exception table:
    //   from	to	target	type
    //   196	227	222	finally
    //   230	272	222	finally
  }

  public void updateAdnBySearch(int paramInt, AdnRecord paramAdnRecord1, AdnRecord paramAdnRecord2, String paramString, Message paramMessage)
  {
    ArrayList localArrayList = loadAllAdn(paramInt);
    if (localArrayList == null)
      sendErrorResponse(paramMessage, -1010);
    while (true)
    {
      return;
      int i = -1;
      int j = 1;
      Iterator localIterator = localArrayList.iterator();
      while (true)
      {
        if (localIterator.hasNext())
        {
          if (paramAdnRecord1.isEqual((AdnRecord)localIterator.next()))
            i = j;
        }
        else
        {
          if (i != -1)
            break label90;
          sendErrorResponse(paramMessage, -1010);
          break;
        }
        j++;
      }
      label90: if (extensionEfForEf(paramInt) < 0)
        sendErrorResponse(paramMessage, -1014);
      else if (paramInt == 20272)
      {
        if (paramAdnRecord2.mAlphaTag.length() > 60)
        {
          sendErrorResponse(paramMessage, -1004);
        }
        else
        {
          int k = paramAdnRecord2.mNumber.length();
          if ((k > 0) && (paramAdnRecord2.mNumber.charAt(0) == '+'))
            k--;
          if (k > 40)
          {
            sendErrorResponse(paramMessage, -1003);
          }
          else
          {
            MiuiAdnRecord localMiuiAdnRecord = (MiuiAdnRecord)paramAdnRecord2;
            if ((localMiuiAdnRecord.mAnr != null) && (localMiuiAdnRecord.mAnr.length() > 20))
            {
              sendErrorResponse(paramMessage, -1009);
            }
            else
            {
              int m = this.mUsimPhoneBookManager.update((MiuiAdnRecord)paramAdnRecord1, i, (MiuiAdnRecord)paramAdnRecord2);
              if (m != 0)
              {
                sendErrorResponse(paramMessage, m);
              }
              else
              {
                AsyncResult.forMessage(paramMessage, null, null);
                paramMessage.sendToTarget();
              }
            }
          }
        }
      }
      else
        updateAdnByIndex(paramInt, paramAdnRecord2, i, paramString, paramMessage);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.MiuiAdnRecordCache
 * JD-Core Version:    0.6.2
 */