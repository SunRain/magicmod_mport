package com.android.internal.telephony.uicc;

import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;

public final class UsimFileHandler extends IccFileHandler
  implements IccConstants
{
  static final String LOG_TAG = "UsimFH";

  public UsimFileHandler(UiccCardApplication paramUiccCardApplication, String paramString, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramString, paramCommandsInterface);
  }

  protected String getEFPath(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = getCommonIccEFPath(paramInt);
      if (str == null)
        str = "3F007F105F3A";
      break;
    case 28433:
    case 28435:
    case 28436:
    case 28437:
    case 28438:
    case 28439:
    case 28440:
    case 28472:
    case 28475:
    case 28476:
    case 28478:
    case 28480:
    case 28486:
    case 28491:
    case 28589:
    case 28613:
    case 28614:
    case 28615:
    case 28616:
    case 28617:
    case 28618:
    case 28619:
    case 28621:
    case 20272:
    }
    while (true)
    {
      return str;
      str = "3F007FFF";
      continue;
      str = "3F007F105F3A";
    }
  }

  protected void logd(String paramString)
  {
    Rlog.d("UsimFH", paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("UsimFH", paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.UsimFileHandler
 * JD-Core Version:    0.6.2
 */