package com.android.internal.telephony.uicc;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;
import android.view.Window;
import com.android.internal.telephony.EncodeException;
import com.android.internal.telephony.GsmAlphabet;
import java.io.UnsupportedEncodingException;
import java.util.Timer;
import java.util.TimerTask;
import miui.telephony.MiuiSpnOverride;

class Injector
{
  static class AdnRecordHook
  {
    public static boolean encodeAlphaTag(String paramString1, byte[] paramArrayOfByte, String paramString2, int paramInt)
    {
      int i = 1;
      try
      {
        GsmAlphabet.stringToGsm7BitPacked(paramString2);
        byte[] arrayOfByte4 = GsmAlphabet.stringToGsm8BitPacked(paramString2);
        arrayOfByte3 = arrayOfByte4;
        if (arrayOfByte3.length > paramInt)
        {
          System.arraycopy(arrayOfByte3, 0, paramArrayOfByte, 0, paramInt);
          return i;
        }
      }
      catch (EncodeException localEncodeException)
      {
        while (true)
        {
          byte[] arrayOfByte3;
          Log.w(paramString1, "[buildAdnString]  can't encode with GSM alphabet, try utf-16be");
          byte[] arrayOfByte1 = new byte[i];
          arrayOfByte1[0] = -128;
          try
          {
            byte[] arrayOfByte2 = paramString2.getBytes("utf-16be");
            arrayOfByte3 = new byte[1 + arrayOfByte2.length];
            System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, i);
            System.arraycopy(arrayOfByte2, 0, arrayOfByte3, i, arrayOfByte2.length);
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException)
          {
            Log.e(paramString1, "Implausible UnsupportedEncodingException ", localUnsupportedEncodingException);
            int j = 0;
          }
          continue;
          paramInt = arrayOfByte3.length;
        }
      }
    }
  }

  static class IccCardProxyHook
  {
    public static boolean isUiccCardReady(UiccCard paramUiccCard, boolean paramBoolean)
    {
      if ((paramBoolean) && (paramUiccCard != null));
      for (boolean bool = true; ; bool = false)
        return bool;
    }
  }

  static class SIMRecordsHook
  {
    public static void after_SIMRecords(SIMRecords paramSIMRecords)
    {
      paramSIMRecords.mSpnOverride = MiuiSpnOverride.getImpl();
    }

    public static void after_setSpnFromConfig(SIMRecords paramSIMRecords)
    {
      if (!TextUtils.isEmpty(paramSIMRecords.mSpn))
        paramSIMRecords.mSpnDisplayCondition = 0;
    }

    public static boolean before_isOnMatchingPlmn(SIMRecords paramSIMRecords, String paramString)
    {
      boolean bool = true;
      String str1;
      if (paramString != null)
      {
        str1 = paramSIMRecords.getOperatorNumeric();
        if (!paramString.equals(str1));
      }
      while (true)
      {
        return bool;
        MiuiSpnOverride localMiuiSpnOverride = MiuiSpnOverride.getInstance();
        String str2 = localMiuiSpnOverride.getEquivalentOperatorNumeric(paramString);
        if ((str2 == null) || (!str2.equals(localMiuiSpnOverride.getEquivalentOperatorNumeric(str1))))
          bool = false;
      }
    }
  }

  static class UiccCardHook
  {
    private static final int DISMISS_DIALOG_TIME = 10000;

    public static boolean before_onIccSwap(Context paramContext, Object paramObject, boolean paramBoolean)
    {
      boolean bool = true;
      if (paramBoolean);
      while (true)
      {
        return bool;
        if ((paramObject == null) || (paramContext == null))
        {
          bool = false;
          continue;
        }
        try
        {
          String str = Resources.getSystem().getString(17040466);
          AlertDialog localAlertDialog = new AlertDialog.Builder(paramContext, 101515326).setTitle(str).setPositiveButton(17039370, null).create();
          localAlertDialog.getWindow().setType(2003);
          localAlertDialog.show();
          final Timer localTimer = new Timer();
          localTimer.schedule(new TimerTask()
          {
            public void run()
            {
              if (this.val$dialog != null)
                this.val$dialog.dismiss();
              localTimer.cancel();
            }
          }
          , 10000L);
        }
        finally
        {
          localObject = finally;
          throw localObject;
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.Injector
 * JD-Core Version:    0.6.2
 */