package com.android.internal.telephony.uicc;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.AsyncResult;
import android.os.Message;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.telephony.Rlog;
import android.text.TextUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.GsmAlphabet;
import com.android.internal.telephony.MccTable;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RuimRecords extends IccRecords
{
  private static final int EVENT_GET_ALL_SMS_DONE = 18;
  private static final int EVENT_GET_CDMA_SUBSCRIPTION_DONE = 10;
  private static final int EVENT_GET_DEVICE_IDENTITY_DONE = 4;
  private static final int EVENT_GET_ICCID_DONE = 5;
  private static final int EVENT_GET_IMSI_DONE = 3;
  private static final int EVENT_GET_SMS_DONE = 22;
  private static final int EVENT_GET_SST_DONE = 17;
  private static final int EVENT_MARK_SMS_READ_DONE = 19;
  private static final int EVENT_RUIM_REFRESH = 31;
  private static final int EVENT_SMS_ON_RUIM = 21;
  private static final int EVENT_UPDATE_DONE = 14;
  static final String LOG_TAG = "RuimRecords";
  boolean mCsimSpnDisplayCondition = false;
  private byte[] mEFli = null;
  private byte[] mEFpl = null;
  private String mHomeNetworkId;
  private String mHomeSystemId;
  private String mMdn;
  private String mMin;
  private String mMin2Min1;
  private String mMyMobileNumber;
  private boolean mOtaCommited = false;
  private String mPrlVersion;

  public RuimRecords(UiccCardApplication paramUiccCardApplication, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramContext, paramCommandsInterface);
    this.mAdnCache = new MiuiAdnRecordCache(this.mFh);
    this.mRecordsRequested = false;
    this.mRecordsToLoad = 0;
    this.mCi.registerForIccRefresh(this, 31, null);
    resetRecords();
    this.mParentApp.registerForReady(this, 1, null);
    log("RuimRecords X ctor this=" + this);
  }

  private int adjstMinDigits(int paramInt)
  {
    int i = paramInt + 111;
    if (i % 10 == 0)
      i -= 10;
    if (i / 10 % 10 == 0)
      i -= 100;
    if (i / 100 % 10 == 0)
      i -= 1000;
    return i;
  }

  private void fetchRuimRecords()
  {
    this.mRecordsRequested = true;
    log("fetchRuimRecords " + this.mRecordsToLoad);
    this.mCi.getIMSIForApp(this.mParentApp.getAid(), obtainMessage(3));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(12258, obtainMessage(5));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(12037, obtainMessage(100, new EfPlLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28474, obtainMessage(100, new EfCsimLiLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28481, obtainMessage(100, new EfCsimSpnLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixed(28484, 1, obtainMessage(100, new EfCsimMdnLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28450, obtainMessage(100, new EfCsimImsimLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixedAll(28456, obtainMessage(100, new EfCsimCdmaHomeLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28506, 4, obtainMessage(100, new EfCsimEprlLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    log("fetchRuimRecords " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
  }

  private String findBestLanguage(byte[] paramArrayOfByte)
  {
    String[] arrayOfString = this.mContext.getAssets().getLocales();
    String str;
    if ((paramArrayOfByte == null) || (arrayOfString == null))
    {
      str = null;
      return str;
    }
    int i = 0;
    while (true)
      while (true)
      {
        if (i + 1 < paramArrayOfByte.length);
        try
        {
          str = new String(paramArrayOfByte, i, 2, "ISO-8859-1");
          for (int j = 0; ; j++)
          {
            if (j >= arrayOfString.length)
              break label103;
            if ((arrayOfString[j] != null) && (arrayOfString[j].length() >= 2))
            {
              boolean bool = arrayOfString[j].substring(0, 2).equals(str);
              if (bool)
                break;
            }
          }
          label103: if (0 != 0)
            str = null;
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          log("Failed to parse SIM language records");
          i += 2;
        }
      }
  }

  private void handleRuimRefresh(IccRefreshResponse paramIccRefreshResponse)
  {
    if (paramIccRefreshResponse == null)
      log("handleRuimRefresh received without input");
    while (true)
    {
      return;
      if ((paramIccRefreshResponse.aid == null) || (paramIccRefreshResponse.aid.equals(this.mParentApp.getAid())))
        switch (paramIccRefreshResponse.refreshResult)
        {
        default:
          log("handleRuimRefresh with unknown operation");
          break;
        case 0:
          log("handleRuimRefresh with SIM_REFRESH_FILE_UPDATED");
          this.mAdnCache.reset();
          fetchRuimRecords();
          break;
        case 1:
          log("handleRuimRefresh with SIM_REFRESH_INIT");
          onIccRefreshInit();
          break;
        case 2:
          log("handleRuimRefresh with SIM_REFRESH_RESET");
          this.mCi.setRadioPower(false, null);
        }
    }
  }

  private void onGetCSimEprlDone(AsyncResult paramAsyncResult)
  {
    byte[] arrayOfByte = (byte[])paramAsyncResult.result;
    log("CSIM_EPRL=" + IccUtils.bytesToHexString(arrayOfByte));
    if (arrayOfByte.length > 3)
      this.mPrlVersion = Integer.toString((0xFF & arrayOfByte[2]) << 8 | 0xFF & arrayOfByte[3]);
    log("CSIM PRL version=" + this.mPrlVersion);
  }

  private void setLocaleFromCsim()
  {
    String str1 = findBestLanguage(this.mEFli);
    if (str1 == null)
      str1 = findBestLanguage(this.mEFpl);
    if (str1 != null)
    {
      String str2 = getIMSI();
      String str3 = null;
      if (str2 != null)
        str3 = MccTable.countryCodeForMcc(Integer.parseInt(str2.substring(0, 3)));
      log("Setting locale to " + str1 + "_" + str3);
      MccTable.setSystemLocale(this.mContext, str1, str3);
    }
    while (true)
    {
      return;
      log("No suitable CSIM selected locale");
    }
  }

  public void dispose()
  {
    log("Disposing RuimRecords " + this);
    this.mCi.unregisterForIccRefresh(this);
    this.mParentApp.unregisterForReady(this);
    resetRecords();
    super.dispose();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("RuimRecords: " + this);
    paramPrintWriter.println(" extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mOtaCommited=" + this.mOtaCommited);
    paramPrintWriter.println(" mMyMobileNumber=" + this.mMyMobileNumber);
    paramPrintWriter.println(" mMin2Min1=" + this.mMin2Min1);
    paramPrintWriter.println(" mPrlVersion=" + this.mPrlVersion);
    paramPrintWriter.println(" mEFpl[]=" + Arrays.toString(this.mEFpl));
    paramPrintWriter.println(" mEFli[]=" + Arrays.toString(this.mEFli));
    paramPrintWriter.println(" mCsimSpnDisplayCondition=" + this.mCsimSpnDisplayCondition);
    paramPrintWriter.println(" mMdn=" + this.mMdn);
    paramPrintWriter.println(" mMin=" + this.mMin);
    paramPrintWriter.println(" mHomeSystemId=" + this.mHomeSystemId);
    paramPrintWriter.println(" mHomeNetworkId=" + this.mHomeNetworkId);
    paramPrintWriter.flush();
  }

  protected void finalize()
  {
    log("RuimRecords finalized");
  }

  public String getCdmaMin()
  {
    return this.mMin2Min1;
  }

  public boolean getCsimSpnDisplayCondition()
  {
    return this.mCsimSpnDisplayCondition;
  }

  public int getDisplayRule(String paramString)
  {
    return 0;
  }

  public String getIMSI()
  {
    return this.mImsi;
  }

  public String getMdn()
  {
    return this.mMdn;
  }

  public String getMdnNumber()
  {
    return this.mMyMobileNumber;
  }

  public String getMin()
  {
    return this.mMin;
  }

  public String getNid()
  {
    return this.mHomeNetworkId;
  }

  public String getPrlVersion()
  {
    return this.mPrlVersion;
  }

  public String getRUIMOperatorNumeric()
  {
    String str;
    if (this.mImsi == null)
      str = null;
    while (true)
    {
      return str;
      if ((this.mMncLength != -1) && (this.mMncLength != 0))
      {
        str = this.mImsi.substring(0, 3 + this.mMncLength);
      }
      else
      {
        int i = Integer.parseInt(this.mImsi.substring(0, 3));
        str = this.mImsi.substring(0, 3 + MccTable.smallestDigitsMccForMnc(i));
      }
    }
  }

  public String getSid()
  {
    return this.mHomeSystemId;
  }

  public void handleMessage(Message paramMessage)
  {
    int i = 0;
    if (this.mDestroyed.get())
    {
      loge("Received message " + paramMessage + "[" + paramMessage.what + "] while being destroyed. Ignoring.");
      return;
    }
    while (true)
    {
      try
      {
        switch (paramMessage.what)
        {
        default:
          super.handleMessage(paramMessage);
          if (i == 0)
            break;
          onRecordLoaded();
          break;
        case 1:
          onReady();
          continue;
        case 4:
        case 3:
        case 10:
        case 5:
        case 14:
        case 18:
        case 19:
        case 21:
        case 22:
        case 17:
        case 31:
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        Rlog.w("RuimRecords", "Exception parsing RUIM record", localRuntimeException);
        if (i == 0)
          break;
        continue;
        log("Event EVENT_GET_DEVICE_IDENTITY_DONE Received");
        continue;
      }
      finally
      {
        if (i != 0)
          onRecordLoaded();
      }
      i = 1;
      AsyncResult localAsyncResult5 = (AsyncResult)paramMessage.obj;
      if (localAsyncResult5.exception != null)
      {
        loge("Exception querying IMSI, Exception:" + localAsyncResult5.exception);
      }
      else
      {
        this.mImsi = ((String)localAsyncResult5.result);
        if ((this.mImsi != null) && ((this.mImsi.length() < 6) || (this.mImsi.length() > 15)))
        {
          loge("invalid IMSI " + this.mImsi);
          this.mImsi = null;
        }
        log("IMSI: " + this.mImsi.substring(0, 6) + "xxxxxxxxx");
        String str = getRUIMOperatorNumeric();
        if ((str != null) && (str.length() <= 6))
        {
          MccTable.updateMccMncConfiguration(this.mContext, str);
          continue;
          AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
          String[] arrayOfString = (String[])localAsyncResult4.result;
          if (localAsyncResult4.exception == null)
          {
            this.mMyMobileNumber = arrayOfString[0];
            this.mMin2Min1 = arrayOfString[3];
            this.mPrlVersion = arrayOfString[4];
            log("MDN: " + this.mMyMobileNumber + " MIN: " + this.mMin2Min1);
            continue;
            i = 1;
            AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
            byte[] arrayOfByte = (byte[])localAsyncResult3.result;
            if (localAsyncResult3.exception == null)
            {
              this.mIccId = IccUtils.bcdToString(arrayOfByte, 0, arrayOfByte.length);
              log("iccid: " + this.mIccId);
              continue;
              AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
              if (localAsyncResult2.exception != null)
              {
                Rlog.i("RuimRecords", "RuimRecords update failed", localAsyncResult2.exception);
                continue;
                Rlog.w("RuimRecords", "Event not supported: " + paramMessage.what);
                continue;
                log("Event EVENT_GET_SST_DONE Received");
                continue;
                i = 0;
                AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
                if (localAsyncResult1.exception == null)
                  handleRuimRefresh((IccRefreshResponse)localAsyncResult1.result);
              }
            }
          }
        }
      }
    }
  }

  public boolean isProvisioned()
  {
    boolean bool = true;
    if (SystemProperties.getBoolean("persist.radio.test-csim", false));
    while (true)
    {
      return bool;
      if (this.mParentApp == null)
        bool = false;
      else if ((this.mParentApp.getType() == IccCardApplicationStatus.AppType.APPTYPE_CSIM) && ((this.mMdn == null) || (this.mMin == null)))
        bool = false;
    }
  }

  protected void log(String paramString)
  {
    Rlog.d("RuimRecords", "[RuimRecords] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("RuimRecords", "[RuimRecords] " + paramString);
  }

  protected void onAllRecordsLoaded()
  {
    log("record load complete");
    String str = getRUIMOperatorNumeric();
    if (!TextUtils.isEmpty(str))
    {
      log("onAllRecordsLoaded set 'gsm.sim.operator.numeric' to operator='" + str + "'");
      SystemProperties.set("gsm.sim.operator.numeric", str);
      if (TextUtils.isEmpty(this.mImsi))
        break label146;
      log("onAllRecordsLoaded set mcc imsi=" + this.mImsi);
      SystemProperties.set("gsm.sim.operator.iso-country", MccTable.countryCodeForMcc(Integer.parseInt(this.mImsi.substring(0, 3))));
    }
    while (true)
    {
      setLocaleFromCsim();
      this.mRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
      return;
      log("onAllRecordsLoaded empty 'gsm.sim.operator.numeric' skipping");
      break;
      label146: log("onAllRecordsLoaded empty imsi skipping setting mcc");
    }
  }

  public void onReady()
  {
    fetchRuimRecords();
    this.mCi.getCDMASubscription(obtainMessage(10));
  }

  protected void onRecordLoaded()
  {
    this.mRecordsToLoad = (-1 + this.mRecordsToLoad);
    log("onRecordLoaded " + this.mRecordsToLoad + " requested: " + this.mRecordsRequested);
    if ((this.mRecordsToLoad == 0) && (this.mRecordsRequested == true))
      onAllRecordsLoaded();
    while (true)
    {
      return;
      if (this.mRecordsToLoad < 0)
      {
        loge("recordsToLoad <0, programmer error suspected");
        this.mRecordsToLoad = 0;
      }
    }
  }

  public void onRefresh(boolean paramBoolean, int[] paramArrayOfInt)
  {
    if (paramBoolean)
      fetchRuimRecords();
  }

  protected void resetRecords()
  {
    this.mCountVoiceMessages = 0;
    this.mMncLength = -1;
    this.mIccId = null;
    this.mAdnCache.reset();
    this.mRecordsRequested = false;
  }

  public void setVoiceMailNumber(String paramString1, String paramString2, Message paramMessage)
  {
    AsyncResult.forMessage(paramMessage).exception = new IccException("setVoiceMailNumber not implemented");
    paramMessage.sendToTarget();
    loge("method setVoiceMailNumber is not implemented");
  }

  public void setVoiceMessageWaiting(int paramInt1, int paramInt2)
  {
    if (paramInt1 != 1)
      return;
    if (paramInt2 < 0)
      paramInt2 = -1;
    while (true)
    {
      this.mCountVoiceMessages = paramInt2;
      this.mRecordsEventsRegistrants.notifyResult(Integer.valueOf(0));
      break;
      if (paramInt2 > 255)
        paramInt2 = 255;
    }
  }

  public String toString()
  {
    return "RuimRecords: " + super.toString() + " m_ota_commited" + this.mOtaCommited + " mMyMobileNumber=" + "xxxx" + " mMin2Min1=" + this.mMin2Min1 + " mPrlVersion=" + this.mPrlVersion + " mEFpl=" + this.mEFpl + " mEFli=" + this.mEFli + " mCsimSpnDisplayCondition=" + this.mCsimSpnDisplayCondition + " mMdn=" + this.mMdn + " mMin=" + this.mMin + " mHomeSystemId=" + this.mHomeSystemId + " mHomeNetworkId=" + this.mHomeNetworkId;
  }

  private class EfCsimCdmaHomeLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimCdmaHomeLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_CDMAHOME";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      ArrayList localArrayList = (ArrayList)paramAsyncResult.result;
      RuimRecords.this.log("CSIM_CDMAHOME data size=" + localArrayList.size());
      if (localArrayList.isEmpty());
      while (true)
      {
        return;
        StringBuilder localStringBuilder1 = new StringBuilder();
        StringBuilder localStringBuilder2 = new StringBuilder();
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext())
        {
          byte[] arrayOfByte = (byte[])localIterator.next();
          if (arrayOfByte.length == 5)
          {
            int i = (0xFF & arrayOfByte[1]) << 8 | 0xFF & arrayOfByte[0];
            int j = (0xFF & arrayOfByte[3]) << 8 | 0xFF & arrayOfByte[2];
            localStringBuilder1.append(i).append(',');
            localStringBuilder2.append(j).append(',');
          }
        }
        localStringBuilder1.setLength(-1 + localStringBuilder1.length());
        localStringBuilder2.setLength(-1 + localStringBuilder2.length());
        RuimRecords.access$502(RuimRecords.this, localStringBuilder1.toString());
        RuimRecords.access$602(RuimRecords.this, localStringBuilder2.toString());
      }
    }
  }

  private class EfCsimEprlLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimEprlLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_EPRL";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      RuimRecords.this.onGetCSimEprlDone(paramAsyncResult);
    }
  }

  private class EfCsimImsimLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimImsimLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_IMSIM";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      byte[] arrayOfByte = (byte[])paramAsyncResult.result;
      RuimRecords.this.log("CSIM_IMSIM=" + IccUtils.bytesToHexString(arrayOfByte));
      int i;
      if ((0x80 & arrayOfByte[7]) == 128)
      {
        i = 1;
        if (i == 0)
          break label372;
        int j = ((0x3 & arrayOfByte[2]) << 8) + (0xFF & arrayOfByte[1]);
        int k = ((0xFF & arrayOfByte[5]) << 8 | 0xFF & arrayOfByte[4]) >> 6;
        int m = 0xF & arrayOfByte[4] >> 2;
        if (m > 9)
          m = 0;
        int n = (0x3 & arrayOfByte[4]) << 8 | 0xFF & arrayOfByte[3];
        int i1 = RuimRecords.this.adjstMinDigits(j);
        int i2 = RuimRecords.this.adjstMinDigits(k);
        int i3 = RuimRecords.this.adjstMinDigits(n);
        StringBuilder localStringBuilder = new StringBuilder();
        Locale localLocale1 = Locale.US;
        Object[] arrayOfObject1 = new Object[1];
        arrayOfObject1[0] = Integer.valueOf(i1);
        localStringBuilder.append(String.format(localLocale1, "%03d", arrayOfObject1));
        Locale localLocale2 = Locale.US;
        Object[] arrayOfObject2 = new Object[1];
        arrayOfObject2[0] = Integer.valueOf(i2);
        localStringBuilder.append(String.format(localLocale2, "%03d", arrayOfObject2));
        Locale localLocale3 = Locale.US;
        Object[] arrayOfObject3 = new Object[1];
        arrayOfObject3[0] = Integer.valueOf(m);
        localStringBuilder.append(String.format(localLocale3, "%d", arrayOfObject3));
        Locale localLocale4 = Locale.US;
        Object[] arrayOfObject4 = new Object[1];
        arrayOfObject4[0] = Integer.valueOf(i3);
        localStringBuilder.append(String.format(localLocale4, "%03d", arrayOfObject4));
        RuimRecords.access$402(RuimRecords.this, localStringBuilder.toString());
        RuimRecords.this.log("min present=" + RuimRecords.this.mMin);
      }
      while (true)
      {
        return;
        i = 0;
        break;
        label372: RuimRecords.this.log("min not present");
      }
    }
  }

  private class EfCsimLiLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimLiLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_LI";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      RuimRecords.access$102(RuimRecords.this, (byte[])paramAsyncResult.result);
      int i = 0;
      if (i < RuimRecords.this.mEFli.length)
      {
        switch (RuimRecords.this.mEFli[(i + 1)])
        {
        default:
          RuimRecords.this.mEFli[i] = 32;
          RuimRecords.this.mEFli[(i + 1)] = 32;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        }
        while (true)
        {
          i += 2;
          break;
          RuimRecords.this.mEFli[i] = 101;
          RuimRecords.this.mEFli[(i + 1)] = 110;
          continue;
          RuimRecords.this.mEFli[i] = 102;
          RuimRecords.this.mEFli[(i + 1)] = 114;
          continue;
          RuimRecords.this.mEFli[i] = 101;
          RuimRecords.this.mEFli[(i + 1)] = 115;
          continue;
          RuimRecords.this.mEFli[i] = 106;
          RuimRecords.this.mEFli[(i + 1)] = 97;
          continue;
          RuimRecords.this.mEFli[i] = 107;
          RuimRecords.this.mEFli[(i + 1)] = 111;
          continue;
          RuimRecords.this.mEFli[i] = 122;
          RuimRecords.this.mEFli[(i + 1)] = 104;
          continue;
          RuimRecords.this.mEFli[i] = 104;
          RuimRecords.this.mEFli[(i + 1)] = 101;
        }
      }
      RuimRecords.this.log("EF_LI=" + IccUtils.bytesToHexString(RuimRecords.this.mEFli));
    }
  }

  private class EfCsimMdnLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimMdnLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_MDN";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      byte[] arrayOfByte = (byte[])paramAsyncResult.result;
      RuimRecords.this.log("CSIM_MDN=" + IccUtils.bytesToHexString(arrayOfByte));
      int i = 0xF & arrayOfByte[0];
      RuimRecords.access$202(RuimRecords.this, IccUtils.cdmaBcdToString(arrayOfByte, 1, i));
      RuimRecords.this.log("CSIM MDN=" + RuimRecords.this.mMdn);
    }
  }

  private class EfCsimSpnLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfCsimSpnLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_CSIM_SPN";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      int i = 32;
      byte[] arrayOfByte1 = (byte[])paramAsyncResult.result;
      RuimRecords.this.log("CSIM_SPN=" + IccUtils.bytesToHexString(arrayOfByte1));
      RuimRecords localRuimRecords = RuimRecords.this;
      boolean bool;
      int j;
      byte[] arrayOfByte2;
      int k;
      if ((0x1 & arrayOfByte1[0]) != 0)
      {
        bool = true;
        localRuimRecords.mCsimSpnDisplayCondition = bool;
        j = arrayOfByte1[1];
        arrayOfByte1[2];
        arrayOfByte2 = new byte[i];
        if (-3 + arrayOfByte1.length < i)
          i = -3 + arrayOfByte1.length;
        System.arraycopy(arrayOfByte1, 3, arrayOfByte2, 0, i);
        k = 0;
        label108: if ((k < arrayOfByte2.length) && ((0xFF & arrayOfByte2[k]) != 255))
          break label152;
        if (k != 0)
          break label158;
        RuimRecords.this.mSpn = "";
      }
      while (true)
      {
        return;
        bool = false;
        break;
        label152: k++;
        break label108;
        label158: switch (j)
        {
        case 1:
        case 5:
        case 6:
        case 7:
        default:
        case 0:
        case 8:
        case 2:
        case 3:
        case 9:
        case 4:
        }
        try
        {
          RuimRecords.this.log("SPN encoding not supported");
          while (true)
          {
            RuimRecords.this.log("spn=" + RuimRecords.this.mSpn);
            RuimRecords.this.log("spnCondition=" + RuimRecords.this.mCsimSpnDisplayCondition);
            SystemProperties.set("gsm.sim.operator.alpha", RuimRecords.this.mSpn);
            break;
            RuimRecords.this.mSpn = new String(arrayOfByte2, 0, k, "ISO-8859-1");
          }
        }
        catch (Exception localException)
        {
          while (true)
          {
            RuimRecords.this.log("spn decode error: " + localException);
            continue;
            RuimRecords.this.mSpn = GsmAlphabet.gsm7BitPackedToString(arrayOfByte2, 0, k * 8 / 7);
            continue;
            RuimRecords.this.mSpn = new String(arrayOfByte2, 0, k, "utf-16");
          }
        }
      }
    }
  }

  private class EfPlLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfPlLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_PL";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      RuimRecords.access$002(RuimRecords.this, (byte[])paramAsyncResult.result);
      RuimRecords.this.log("EF_PL=" + IccUtils.bytesToHexString(RuimRecords.this.mEFpl));
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.RuimRecords
 * JD-Core Version:    0.6.2
 */