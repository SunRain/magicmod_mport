package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import android.os.RegistrantList;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.gsm.SimTlv;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;

public final class IsimUiccRecords extends IccRecords
  implements IsimRecords
{
  private static final boolean DBG = true;
  private static final boolean DUMP_RECORDS = false;
  private static final int EVENT_APP_READY = 1;
  protected static final String LOG_TAG = "IsimUiccRecords";
  private static final int TAG_ISIM_VALUE = 128;
  private String mIsimDomain;
  private String mIsimImpi;
  private String[] mIsimImpu;

  public IsimUiccRecords(UiccCardApplication paramUiccCardApplication, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramContext, paramCommandsInterface);
    this.mRecordsRequested = false;
    this.mRecordsToLoad = 0;
    this.mParentApp.registerForReady(this, 1, null);
    log("IsimUiccRecords X ctor this=" + this);
  }

  private static String isimTlvToString(byte[] paramArrayOfByte)
  {
    SimTlv localSimTlv = new SimTlv(paramArrayOfByte, 0, paramArrayOfByte.length);
    if (localSimTlv.getTag() == 128);
    for (String str = new String(localSimTlv.getData(), Charset.forName("UTF-8")); ; str = null)
    {
      return str;
      if (localSimTlv.nextObject())
        break;
      Rlog.e("IsimUiccRecords", "[ISIM] can't find TLV tag in ISIM record, returning null");
    }
  }

  public void dispose()
  {
    log("Disposing " + this);
    this.mParentApp.unregisterForReady(this);
    resetRecords();
    super.dispose();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("IsimRecords: " + this);
    paramPrintWriter.println(" extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mIsimImpi=" + this.mIsimImpi);
    paramPrintWriter.println(" mIsimDomain=" + this.mIsimDomain);
    paramPrintWriter.println(" mIsimImpu[]=" + Arrays.toString(this.mIsimImpu));
    paramPrintWriter.flush();
  }

  protected void fetchIsimRecords()
  {
    this.mRecordsRequested = true;
    this.mFh.loadEFTransparent(28418, obtainMessage(100, new EfIsimImpiLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFLinearFixedAll(28420, obtainMessage(100, new EfIsimImpuLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    this.mFh.loadEFTransparent(28419, obtainMessage(100, new EfIsimDomainLoaded(null)));
    this.mRecordsToLoad = (1 + this.mRecordsToLoad);
    log("fetchIsimRecords " + this.mRecordsToLoad);
  }

  public int getDisplayRule(String paramString)
  {
    return 0;
  }

  public String getIsimDomain()
  {
    return this.mIsimDomain;
  }

  public String getIsimImpi()
  {
    return this.mIsimImpi;
  }

  public String[] getIsimImpu()
  {
    if (this.mIsimImpu != null);
    for (String[] arrayOfString = (String[])this.mIsimImpu.clone(); ; arrayOfString = null)
      return arrayOfString;
  }

  public void handleMessage(Message paramMessage)
  {
    if (this.mDestroyed.get())
      Rlog.e("IsimUiccRecords", "Received message " + paramMessage + "[" + paramMessage.what + "] while being destroyed. Ignoring.");
    while (true)
    {
      return;
      try
      {
        switch (paramMessage.what)
        {
        default:
          super.handleMessage(paramMessage);
        case 1:
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        Rlog.w("IsimUiccRecords", "Exception parsing SIM record", localRuntimeException);
      }
      continue;
      onReady();
    }
  }

  protected void log(String paramString)
  {
    Rlog.d("IsimUiccRecords", "[ISIM] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("IsimUiccRecords", "[ISIM] " + paramString);
  }

  protected void onAllRecordsLoaded()
  {
    this.mRecordsLoadedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
  }

  public void onReady()
  {
    fetchIsimRecords();
  }

  protected void onRecordLoaded()
  {
    this.mRecordsToLoad = (-1 + this.mRecordsToLoad);
    if ((this.mRecordsToLoad == 0) && (this.mRecordsRequested == true))
      onAllRecordsLoaded();
    while (true)
    {
      return;
      if (this.mRecordsToLoad < 0)
      {
        loge("recordsToLoad <0, programmer error suspected");
        this.mRecordsToLoad = 0;
      }
    }
  }

  public void onRefresh(boolean paramBoolean, int[] paramArrayOfInt)
  {
  }

  protected void resetRecords()
  {
    this.mRecordsRequested = false;
  }

  public void setVoiceMailNumber(String paramString1, String paramString2, Message paramMessage)
  {
  }

  public void setVoiceMessageWaiting(int paramInt1, int paramInt2)
  {
  }

  public String toString()
  {
    return "IsimUiccRecords: " + super.toString() + " mIsimImpi=" + this.mIsimImpi + " mIsimDomain=" + this.mIsimDomain + " mIsimImpu=" + this.mIsimImpu;
  }

  private class EfIsimDomainLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfIsimDomainLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_ISIM_DOMAIN";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      byte[] arrayOfByte = (byte[])paramAsyncResult.result;
      IsimUiccRecords.access$602(IsimUiccRecords.this, IsimUiccRecords.isimTlvToString(arrayOfByte));
    }
  }

  private class EfIsimImpiLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfIsimImpiLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_ISIM_IMPI";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      byte[] arrayOfByte = (byte[])paramAsyncResult.result;
      IsimUiccRecords.access$302(IsimUiccRecords.this, IsimUiccRecords.isimTlvToString(arrayOfByte));
    }
  }

  private class EfIsimImpuLoaded
    implements IccRecords.IccRecordLoaded
  {
    private EfIsimImpuLoaded()
    {
    }

    public String getEfName()
    {
      return "EF_ISIM_IMPU";
    }

    public void onRecordLoaded(AsyncResult paramAsyncResult)
    {
      ArrayList localArrayList = (ArrayList)paramAsyncResult.result;
      IsimUiccRecords.this.log("EF_IMPU record count: " + localArrayList.size());
      IsimUiccRecords.access$502(IsimUiccRecords.this, new String[localArrayList.size()]);
      int i = 0;
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        String str = IsimUiccRecords.isimTlvToString((byte[])localIterator.next());
        String[] arrayOfString = IsimUiccRecords.this.mIsimImpu;
        int j = i + 1;
        arrayOfString[i] = str;
        i = j;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IsimUiccRecords
 * JD-Core Version:    0.6.2
 */