package com.android.internal.telephony.uicc;

import android.app.ActivityManagerNative;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.IccCard;
import com.android.internal.telephony.IccCardConstants.State;
import com.android.internal.telephony.cdma.CdmaSubscriptionSourceManager;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class IccCardProxy extends Handler
  implements IccCard
{
  private static final boolean DBG = true;
  private static final int EVENT_APP_READY = 6;
  private static final int EVENT_CDMA_SUBSCRIPTION_SOURCE_CHANGED = 11;
  private static final int EVENT_ICC_ABSENT = 4;
  private static final int EVENT_ICC_CHANGED = 3;
  private static final int EVENT_ICC_LOCKED = 5;
  private static final int EVENT_IMSI_READY = 8;
  private static final int EVENT_NETWORK_LOCKED = 9;
  private static final int EVENT_RADIO_OFF_OR_UNAVAILABLE = 1;
  private static final int EVENT_RADIO_ON = 2;
  private static final int EVENT_RECORDS_LOADED = 7;
  private static final String LOG_TAG = "IccCardProxy";
  private RegistrantList mAbsentRegistrants = new RegistrantList();
  private CdmaSubscriptionSourceManager mCdmaSSM = null;
  private CommandsInterface mCi;
  private Context mContext;
  private int mCurrentAppType = 1;
  private IccCardConstants.State mExternalState = IccCardConstants.State.UNKNOWN;
  private IccRecords mIccRecords = null;
  private boolean mInitialized = false;
  private final Object mLock = new Object();
  private RegistrantList mNetworkLockedRegistrants = new RegistrantList();
  private RegistrantList mPinLockedRegistrants = new RegistrantList();
  private boolean mQuietMode = false;
  private boolean mRadioOn = false;
  private UiccCardApplication mUiccApplication = null;
  private UiccCard mUiccCard = null;
  private UiccController mUiccController = null;

  public IccCardProxy(Context paramContext, CommandsInterface paramCommandsInterface)
  {
    log("Creating");
    this.mContext = paramContext;
    this.mCi = paramCommandsInterface;
    this.mCdmaSSM = CdmaSubscriptionSourceManager.getInstance(paramContext, paramCommandsInterface, this, 11, null);
    this.mUiccController = UiccController.getInstance();
    this.mUiccController.registerForIccChanged(this, 3, null);
    paramCommandsInterface.registerForOn(this, 2, null);
    paramCommandsInterface.registerForOffOrNotAvailable(this, 1, null);
    setExternalState(IccCardConstants.State.NOT_READY);
  }

  private void broadcastIccStateChangedIntent(String paramString1, String paramString2)
  {
    synchronized (this.mLock)
    {
      if (this.mQuietMode)
      {
        log("QuietMode: NOT Broadcasting intent ACTION_SIM_STATE_CHANGED " + paramString1 + " reason " + paramString2);
      }
      else
      {
        Intent localIntent = new Intent("android.intent.action.SIM_STATE_CHANGED");
        localIntent.addFlags(536870912);
        localIntent.putExtra("phoneName", "Phone");
        localIntent.putExtra("ss", paramString1);
        localIntent.putExtra("reason", paramString2);
        log("Broadcasting intent ACTION_SIM_STATE_CHANGED " + paramString1 + " reason " + paramString2);
        ActivityManagerNative.broadcastStickyIntent(localIntent, "android.permission.READ_PHONE_STATE", -1);
      }
    }
  }

  private String getIccStateIntentString(IccCardConstants.State paramState)
  {
    String str;
    switch (1.$SwitchMap$com$android$internal$telephony$IccCardConstants$State[paramState.ordinal()])
    {
    default:
      str = "UNKNOWN";
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      return str;
      str = "ABSENT";
      continue;
      str = "LOCKED";
      continue;
      str = "LOCKED";
      continue;
      str = "LOCKED";
      continue;
      str = "READY";
      continue;
      str = "NOT_READY";
      continue;
      str = "LOCKED";
    }
  }

  private String getIccStateReason(IccCardConstants.State paramState)
  {
    String str;
    switch (1.$SwitchMap$com$android$internal$telephony$IccCardConstants$State[paramState.ordinal()])
    {
    case 5:
    case 6:
    default:
      str = null;
    case 2:
    case 3:
    case 4:
    case 7:
    }
    while (true)
    {
      return str;
      str = "PIN";
      continue;
      str = "PUK";
      continue;
      str = "NETWORK";
      continue;
      str = "PERM_DISABLED";
    }
  }

  private void log(String paramString)
  {
    Rlog.d("IccCardProxy", paramString);
  }

  private void loge(String paramString)
  {
    Rlog.e("IccCardProxy", paramString);
  }

  // ERROR //
  private void processLockedState()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 69	com/android/internal/telephony/uicc/IccCardProxy:mLock	Ljava/lang/Object;
    //   4: astore_1
    //   5: aload_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 86	com/android/internal/telephony/uicc/IccCardProxy:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   11: ifnonnull +8 -> 19
    //   14: aload_1
    //   15: monitorexit
    //   16: goto +104 -> 120
    //   19: aload_0
    //   20: getfield 86	com/android/internal/telephony/uicc/IccCardProxy:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   23: invokevirtual 239	com/android/internal/telephony/uicc/UiccCardApplication:getPin1State	()Lcom/android/internal/telephony/uicc/IccCardStatus$PinState;
    //   26: getstatic 245	com/android/internal/telephony/uicc/IccCardStatus$PinState:PINSTATE_ENABLED_PERM_BLOCKED	Lcom/android/internal/telephony/uicc/IccCardStatus$PinState;
    //   29: if_acmpne +20 -> 49
    //   32: aload_0
    //   33: getstatic 247	com/android/internal/telephony/IccCardConstants$State:PERM_DISABLED	Lcom/android/internal/telephony/IccCardConstants$State;
    //   36: invokespecial 143	com/android/internal/telephony/uicc/IccCardProxy:setExternalState	(Lcom/android/internal/telephony/IccCardConstants$State;)V
    //   39: aload_1
    //   40: monitorexit
    //   41: goto +79 -> 120
    //   44: astore_2
    //   45: aload_1
    //   46: monitorexit
    //   47: aload_2
    //   48: athrow
    //   49: aload_0
    //   50: getfield 86	com/android/internal/telephony/uicc/IccCardProxy:mUiccApplication	Lcom/android/internal/telephony/uicc/UiccCardApplication;
    //   53: invokevirtual 251	com/android/internal/telephony/uicc/UiccCardApplication:getState	()Lcom/android/internal/telephony/uicc/IccCardApplicationStatus$AppState;
    //   56: astore_3
    //   57: getstatic 254	com/android/internal/telephony/uicc/IccCardProxy$1:$SwitchMap$com$android$internal$telephony$uicc$IccCardApplicationStatus$AppState	[I
    //   60: aload_3
    //   61: invokevirtual 257	com/android/internal/telephony/uicc/IccCardApplicationStatus$AppState:ordinal	()I
    //   64: iaload
    //   65: tableswitch	default:+23 -> 88, 3:+28->93, 4:+45->110
    //   89: monitorexit
    //   90: goto +30 -> 120
    //   93: aload_0
    //   94: getfield 76	com/android/internal/telephony/uicc/IccCardProxy:mPinLockedRegistrants	Landroid/os/RegistrantList;
    //   97: invokevirtual 260	android/os/RegistrantList:notifyRegistrants	()V
    //   100: aload_0
    //   101: getstatic 263	com/android/internal/telephony/IccCardConstants$State:PIN_REQUIRED	Lcom/android/internal/telephony/IccCardConstants$State;
    //   104: invokespecial 143	com/android/internal/telephony/uicc/IccCardProxy:setExternalState	(Lcom/android/internal/telephony/IccCardConstants$State;)V
    //   107: goto -19 -> 88
    //   110: aload_0
    //   111: getstatic 266	com/android/internal/telephony/IccCardConstants$State:PUK_REQUIRED	Lcom/android/internal/telephony/IccCardConstants$State;
    //   114: invokespecial 143	com/android/internal/telephony/uicc/IccCardProxy:setExternalState	(Lcom/android/internal/telephony/IccCardConstants$State;)V
    //   117: goto -29 -> 88
    //   120: return
    //
    // Exception table:
    //   from	to	target	type
    //   7	47	44	finally
    //   49	117	44	finally
  }

  private void registerUiccCardEvents()
  {
    if (this.mUiccCard != null)
      this.mUiccCard.registerForAbsent(this, 4, null);
    if (this.mUiccApplication != null)
    {
      this.mUiccApplication.registerForReady(this, 6, null);
      this.mUiccApplication.registerForLocked(this, 5, null);
      this.mUiccApplication.registerForNetworkLocked(this, 9, null);
    }
    if (this.mIccRecords != null)
    {
      this.mIccRecords.registerForImsiReady(this, 8, null);
      this.mIccRecords.registerForRecordsLoaded(this, 7, null);
    }
  }

  private void setExternalState(IccCardConstants.State paramState)
  {
    setExternalState(paramState, false);
  }

  private void setExternalState(IccCardConstants.State paramState, boolean paramBoolean)
  {
    Object localObject1 = this.mLock;
    if (!paramBoolean);
    try
    {
      if (paramState == this.mExternalState)
        return;
      this.mExternalState = paramState;
      SystemProperties.set("gsm.sim.state", this.mExternalState.toString());
      broadcastIccStateChangedIntent(getIccStateIntentString(this.mExternalState), getIccStateReason(this.mExternalState));
    }
    finally
    {
      localObject2 = finally;
      throw localObject2;
    }
  }

  private void unregisterUiccCardEvents()
  {
    if (this.mUiccCard != null)
      this.mUiccCard.unregisterForAbsent(this);
    if (this.mUiccApplication != null)
      this.mUiccApplication.unregisterForReady(this);
    if (this.mUiccApplication != null)
      this.mUiccApplication.unregisterForLocked(this);
    if (this.mUiccApplication != null)
      this.mUiccApplication.unregisterForNetworkLocked(this);
    if (this.mIccRecords != null)
      this.mIccRecords.unregisterForImsiReady(this);
    if (this.mIccRecords != null)
      this.mIccRecords.unregisterForRecordsLoaded(this);
  }

  private void updateExternalState()
  {
    if ((this.mUiccCard == null) || (this.mUiccCard.getCardState() == IccCardStatus.CardState.CARDSTATE_ABSENT))
      if (Injector.IccCardProxyHook.isUiccCardReady(this.mUiccCard, this.mRadioOn))
        setExternalState(IccCardConstants.State.ABSENT);
    while (true)
    {
      return;
      setExternalState(IccCardConstants.State.NOT_READY);
      continue;
      if ((this.mUiccCard.getCardState() == IccCardStatus.CardState.CARDSTATE_ERROR) || (this.mUiccApplication == null))
        setExternalState(IccCardConstants.State.UNKNOWN);
      else
        switch (1.$SwitchMap$com$android$internal$telephony$uicc$IccCardApplicationStatus$AppState[this.mUiccApplication.getState().ordinal()])
        {
        default:
          break;
        case 1:
        case 2:
          setExternalState(IccCardConstants.State.UNKNOWN);
          break;
        case 3:
          setExternalState(IccCardConstants.State.PIN_REQUIRED);
          break;
        case 4:
          setExternalState(IccCardConstants.State.PUK_REQUIRED);
          break;
        case 5:
          if (this.mUiccApplication.getPersoSubState() == IccCardApplicationStatus.PersoSubState.PERSOSUBSTATE_SIM_NETWORK)
            setExternalState(IccCardConstants.State.NETWORK_LOCKED);
          else
            setExternalState(IccCardConstants.State.UNKNOWN);
          break;
        case 6:
          setExternalState(IccCardConstants.State.READY);
        }
    }
  }

  private void updateIccAvailability()
  {
    synchronized (this.mLock)
    {
      UiccCard localUiccCard = this.mUiccController.getUiccCard();
      UiccCardApplication localUiccCardApplication = null;
      IccRecords localIccRecords = null;
      if (localUiccCard != null)
      {
        localUiccCard.getCardState();
        localUiccCardApplication = localUiccCard.getApplication(this.mCurrentAppType);
        if (localUiccCardApplication != null)
          localIccRecords = localUiccCardApplication.getIccRecords();
      }
      if ((this.mIccRecords != localIccRecords) || (this.mUiccApplication != localUiccCardApplication) || (this.mUiccCard != localUiccCard))
      {
        log("Icc changed. Reregestering.");
        unregisterUiccCardEvents();
        this.mUiccCard = localUiccCard;
        this.mUiccApplication = localUiccCardApplication;
        this.mIccRecords = localIccRecords;
        registerUiccCardEvents();
      }
      updateExternalState();
      return;
    }
  }

  private void updateQuietMode()
  {
    boolean bool1 = false;
    while (true)
    {
      boolean bool2;
      synchronized (this.mLock)
      {
        i = -1;
        if (TelephonyManager.getLteOnCdmaModeStatic() == 1)
        {
          bool2 = true;
          if (this.mCurrentAppType == 1)
          {
            bool1 = false;
            log("updateQuietMode: 3GPP subscription -> newQuietMode=" + false);
            if ((!this.mQuietMode) && (bool1 == true))
            {
              log("Switching to QuietMode.");
              setExternalState(IccCardConstants.State.READY);
              this.mQuietMode = bool1;
              log("updateQuietMode: QuietMode is " + this.mQuietMode + " (app_type=" + this.mCurrentAppType + " isLteOnCdmaMode=" + bool2 + " cdmaSource=" + i + ")");
              this.mInitialized = true;
              sendMessage(obtainMessage(3));
            }
          }
          else
          {
            if (bool2)
            {
              log("updateQuietMode: is cdma/lte device, force IccCardProxy into 3gpp mode");
              this.mCurrentAppType = 1;
            }
            if (this.mCdmaSSM == null)
              break label305;
            i = this.mCdmaSSM.getCdmaSubscriptionSource();
            if ((i != 1) || (this.mCurrentAppType != 2) || (bool2))
              break label302;
            bool1 = true;
            break label302;
          }
          if ((this.mQuietMode != true) || (bool1))
            continue;
          log("updateQuietMode: Switching out from QuietMode. Force broadcast of current state=" + this.mExternalState);
          this.mQuietMode = bool1;
          setExternalState(this.mExternalState, true);
        }
      }
      continue;
      label302: continue;
      label305: int i = -1;
    }
  }

  public void changeIccFdnPassword(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.changeIccFdnPassword(paramString1, paramString2, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void changeIccLockPassword(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.changeIccLockPassword(paramString1, paramString2, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void dispose()
  {
    synchronized (this.mLock)
    {
      log("Disposing");
      this.mUiccController.unregisterForIccChanged(this);
      this.mUiccController = null;
      this.mCi.unregisterForOn(this);
      this.mCi.unregisterForOffOrNotAvailable(this);
      this.mCdmaSSM.dispose(this);
      return;
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("IccCardProxy: " + this);
    paramPrintWriter.println(" mContext=" + this.mContext);
    paramPrintWriter.println(" mCi=" + this.mCi);
    paramPrintWriter.println(" mAbsentRegistrants: size=" + this.mAbsentRegistrants.size());
    for (int i = 0; i < this.mAbsentRegistrants.size(); i++)
      paramPrintWriter.println("  mAbsentRegistrants[" + i + "]=" + ((Registrant)this.mAbsentRegistrants.get(i)).getHandler());
    paramPrintWriter.println(" mPinLockedRegistrants: size=" + this.mPinLockedRegistrants.size());
    for (int j = 0; j < this.mPinLockedRegistrants.size(); j++)
      paramPrintWriter.println("  mPinLockedRegistrants[" + j + "]=" + ((Registrant)this.mPinLockedRegistrants.get(j)).getHandler());
    paramPrintWriter.println(" mNetworkLockedRegistrants: size=" + this.mNetworkLockedRegistrants.size());
    for (int k = 0; k < this.mNetworkLockedRegistrants.size(); k++)
      paramPrintWriter.println("  mNetworkLockedRegistrants[" + k + "]=" + ((Registrant)this.mNetworkLockedRegistrants.get(k)).getHandler());
    paramPrintWriter.println(" mCurrentAppType=" + this.mCurrentAppType);
    paramPrintWriter.println(" mUiccController=" + this.mUiccController);
    paramPrintWriter.println(" mUiccCard=" + this.mUiccCard);
    paramPrintWriter.println(" mUiccApplication=" + this.mUiccApplication);
    paramPrintWriter.println(" mIccRecords=" + this.mIccRecords);
    paramPrintWriter.println(" mCdmaSSM=" + this.mCdmaSSM);
    paramPrintWriter.println(" mRadioOn=" + this.mRadioOn);
    paramPrintWriter.println(" mQuietMode=" + this.mQuietMode);
    paramPrintWriter.println(" mInitialized=" + this.mInitialized);
    paramPrintWriter.println(" mExternalState=" + this.mExternalState);
    paramPrintWriter.flush();
  }

  public boolean getIccFdnAvailable()
  {
    if (this.mUiccApplication != null);
    for (boolean bool = this.mUiccApplication.getIccFdnAvailable(); ; bool = false)
      return bool;
  }

  public boolean getIccFdnEnabled()
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mUiccApplication != null)
        {
          bool1 = this.mUiccApplication.getIccFdnEnabled();
          boolean bool2 = Boolean.valueOf(bool1).booleanValue();
          return bool2;
        }
      }
      boolean bool1 = false;
    }
  }

  public IccFileHandler getIccFileHandler()
  {
    IccFileHandler localIccFileHandler;
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        localIccFileHandler = this.mUiccApplication.getIccFileHandler();
      else
        localIccFileHandler = null;
    }
    return localIccFileHandler;
  }

  public boolean getIccLockEnabled()
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mUiccApplication != null)
        {
          bool1 = this.mUiccApplication.getIccLockEnabled();
          boolean bool2 = Boolean.valueOf(bool1).booleanValue();
          return bool2;
        }
      }
      boolean bool1 = false;
    }
  }

  public boolean getIccPin2Blocked()
  {
    if (this.mUiccApplication != null);
    for (boolean bool = this.mUiccApplication.getIccPin2Blocked(); ; bool = false)
      return Boolean.valueOf(bool).booleanValue();
  }

  public boolean getIccPuk2Blocked()
  {
    if (this.mUiccApplication != null);
    for (boolean bool = this.mUiccApplication.getIccPuk2Blocked(); ; bool = false)
      return Boolean.valueOf(bool).booleanValue();
  }

  public IccRecords getIccRecords()
  {
    synchronized (this.mLock)
    {
      IccRecords localIccRecords = this.mIccRecords;
      return localIccRecords;
    }
  }

  public boolean getIccRecordsLoaded()
  {
    boolean bool;
    synchronized (this.mLock)
    {
      if (this.mIccRecords != null)
        bool = this.mIccRecords.getRecordsLoaded();
      else
        bool = false;
    }
    return bool;
  }

  public String getServiceProviderName()
  {
    String str;
    synchronized (this.mLock)
    {
      if (this.mIccRecords != null)
        str = this.mIccRecords.getServiceProviderName();
      else
        str = null;
    }
    return str;
  }

  public IccCardConstants.State getState()
  {
    synchronized (this.mLock)
    {
      IccCardConstants.State localState = this.mExternalState;
      return localState;
    }
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    case 10:
    default:
      loge("Unhandled message with number: " + paramMessage.what);
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 11:
    }
    while (true)
    {
      return;
      this.mRadioOn = false;
      continue;
      this.mRadioOn = true;
      if (!this.mInitialized)
      {
        updateQuietMode();
        continue;
        if (this.mInitialized)
        {
          updateIccAvailability();
          continue;
          this.mAbsentRegistrants.notifyRegistrants();
          setExternalState(IccCardConstants.State.ABSENT);
          continue;
          processLockedState();
          continue;
          setExternalState(IccCardConstants.State.READY);
          continue;
          broadcastIccStateChangedIntent("LOADED", null);
          continue;
          broadcastIccStateChangedIntent("IMSI", null);
          continue;
          this.mNetworkLockedRegistrants.notifyRegistrants();
          setExternalState(IccCardConstants.State.NETWORK_LOCKED);
          continue;
          updateQuietMode();
        }
      }
    }
  }

  public boolean hasIccCard()
  {
    boolean bool;
    synchronized (this.mLock)
    {
      if ((this.mUiccCard != null) && (this.mUiccCard.getCardState() != IccCardStatus.CardState.CARDSTATE_ABSENT))
        bool = true;
      else
        bool = false;
    }
    return bool;
  }

  public boolean isApplicationOnIcc(IccCardApplicationStatus.AppType paramAppType)
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mUiccCard != null)
        {
          bool1 = this.mUiccCard.isApplicationOnIcc(paramAppType);
          boolean bool2 = Boolean.valueOf(bool1).booleanValue();
          return bool2;
        }
      }
      boolean bool1 = false;
    }
  }

  public void registerForAbsent(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mAbsentRegistrants.add(localRegistrant);
      if (getState() == IccCardConstants.State.ABSENT)
        localRegistrant.notifyRegistrant();
      return;
    }
  }

  public void registerForLocked(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mPinLockedRegistrants.add(localRegistrant);
      if (getState().isPinLocked())
        localRegistrant.notifyRegistrant();
      return;
    }
  }

  public void registerForNetworkLocked(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mNetworkLockedRegistrants.add(localRegistrant);
      if (getState() == IccCardConstants.State.NETWORK_LOCKED)
        localRegistrant.notifyRegistrant();
      return;
    }
  }

  public void setIccFdnEnabled(boolean paramBoolean, String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.setIccFdnEnabled(paramBoolean, paramString, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void setIccLockEnabled(boolean paramBoolean, String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.setIccLockEnabled(paramBoolean, paramString, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void setVoiceRadioTech(int paramInt)
  {
    synchronized (this.mLock)
    {
      log("Setting radio tech " + ServiceState.rilRadioTechnologyToString(paramInt));
      if (ServiceState.isGsm(paramInt))
      {
        this.mCurrentAppType = 1;
        updateQuietMode();
        return;
      }
      this.mCurrentAppType = 2;
    }
  }

  public void supplyNetworkDepersonalization(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.supplyNetworkDepersonalization(paramString, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("CommandsInterface is not set.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void supplyPin(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.supplyPin(paramString, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void supplyPin2(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.supplyPin2(paramString, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void supplyPuk(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.supplyPuk(paramString1, paramString2, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void supplyPuk2(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      if (this.mUiccApplication != null)
        this.mUiccApplication.supplyPuk2(paramString1, paramString2, paramMessage);
      while (true)
      {
        break;
        if (paramMessage != null)
        {
          RuntimeException localRuntimeException = new RuntimeException("ICC card is absent.");
          AsyncResult.forMessage(paramMessage).exception = localRuntimeException;
          paramMessage.sendToTarget();
        }
      }
    }
  }

  public void unregisterForAbsent(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mAbsentRegistrants.remove(paramHandler);
      return;
    }
  }

  public void unregisterForLocked(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mPinLockedRegistrants.remove(paramHandler);
      return;
    }
  }

  public void unregisterForNetworkLocked(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mNetworkLockedRegistrants.remove(paramHandler);
      return;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IccCardProxy
 * JD-Core Version:    0.6.2
 */