package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class UiccCardApplication
{
  private static final boolean DBG = true;
  private static final int EVENT_CHANGE_FACILITY_FDN_DONE = 5;
  private static final int EVENT_CHANGE_FACILITY_LOCK_DONE = 7;
  private static final int EVENT_CHANGE_PIN1_DONE = 2;
  private static final int EVENT_CHANGE_PIN2_DONE = 3;
  private static final int EVENT_PIN1_PUK1_DONE = 1;
  private static final int EVENT_PIN2_PUK2_DONE = 8;
  private static final int EVENT_QUERY_FACILITY_FDN_DONE = 4;
  private static final int EVENT_QUERY_FACILITY_LOCK_DONE = 6;
  private static final String LOG_TAG = "UiccCardApplication";
  private String mAid;
  private String mAppLabel;
  private IccCardApplicationStatus.AppState mAppState;
  private IccCardApplicationStatus.AppType mAppType;
  private CommandsInterface mCi;
  private Context mContext;
  private boolean mDesiredFdnEnabled;
  private boolean mDesiredPinLocked;
  private boolean mDestroyed;
  private Handler mHandler;
  private boolean mIccFdnAvailable;
  private boolean mIccFdnEnabled;
  private IccFileHandler mIccFh;
  private boolean mIccLockEnabled;
  private IccRecords mIccRecords;
  private final Object mLock = new Object();
  private RegistrantList mNetworkLockedRegistrants;
  private IccCardApplicationStatus.PersoSubState mPersoSubState;
  private boolean mPin1Replaced;
  private IccCardStatus.PinState mPin1State;
  private IccCardStatus.PinState mPin2State;
  private RegistrantList mPinLockedRegistrants;
  private RegistrantList mReadyRegistrants;
  private UiccCard mUiccCard;

  UiccCardApplication(UiccCard paramUiccCard, IccCardApplicationStatus paramIccCardApplicationStatus, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    this.mIccFdnAvailable = bool;
    this.mReadyRegistrants = new RegistrantList();
    this.mPinLockedRegistrants = new RegistrantList();
    this.mNetworkLockedRegistrants = new RegistrantList();
    this.mHandler = new Handler()
    {
      public void handleMessage(Message paramAnonymousMessage)
      {
        if (UiccCardApplication.this.mDestroyed)
          UiccCardApplication.this.loge("Received message " + paramAnonymousMessage + "[" + paramAnonymousMessage.what + "] while being destroyed. Ignoring.");
        while (true)
        {
          return;
          switch (paramAnonymousMessage.what)
          {
          default:
            UiccCardApplication.this.loge("Unknown Event " + paramAnonymousMessage.what);
            break;
          case 1:
          case 2:
          case 3:
          case 8:
            int i = -1;
            AsyncResult localAsyncResult5 = (AsyncResult)paramAnonymousMessage.obj;
            if ((localAsyncResult5.exception != null) && (localAsyncResult5.result != null))
              i = UiccCardApplication.this.parsePinPukErrorResult(localAsyncResult5);
            Message localMessage = (Message)localAsyncResult5.userObj;
            AsyncResult.forMessage(localMessage).exception = localAsyncResult5.exception;
            localMessage.arg1 = i;
            localMessage.sendToTarget();
            break;
          case 4:
            AsyncResult localAsyncResult4 = (AsyncResult)paramAnonymousMessage.obj;
            UiccCardApplication.this.onQueryFdnEnabled(localAsyncResult4);
            break;
          case 5:
            AsyncResult localAsyncResult3 = (AsyncResult)paramAnonymousMessage.obj;
            UiccCardApplication.this.onChangeFdnDone(localAsyncResult3);
            break;
          case 6:
            AsyncResult localAsyncResult2 = (AsyncResult)paramAnonymousMessage.obj;
            UiccCardApplication.this.onQueryFacilityLock(localAsyncResult2);
            break;
          case 7:
            AsyncResult localAsyncResult1 = (AsyncResult)paramAnonymousMessage.obj;
            UiccCardApplication.this.onChangeFacilityLock(localAsyncResult1);
          }
        }
      }
    };
    log("Creating UiccApp: " + paramIccCardApplicationStatus);
    this.mUiccCard = paramUiccCard;
    this.mAppState = paramIccCardApplicationStatus.app_state;
    this.mAppType = paramIccCardApplicationStatus.app_type;
    this.mPersoSubState = paramIccCardApplicationStatus.perso_substate;
    this.mAid = paramIccCardApplicationStatus.aid;
    this.mAppLabel = paramIccCardApplicationStatus.app_label;
    if (paramIccCardApplicationStatus.pin1_replaced != 0);
    while (true)
    {
      this.mPin1Replaced = bool;
      this.mPin1State = paramIccCardApplicationStatus.pin1;
      this.mPin2State = paramIccCardApplicationStatus.pin2;
      this.mContext = paramContext;
      this.mCi = paramCommandsInterface;
      this.mIccFh = createIccFileHandler(paramIccCardApplicationStatus.app_type);
      this.mIccRecords = createIccRecords(paramIccCardApplicationStatus.app_type, this.mContext, this.mCi);
      if (this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_READY)
      {
        queryFdn();
        queryPin1State();
      }
      return;
      bool = false;
    }
  }

  private IccFileHandler createIccFileHandler(IccCardApplicationStatus.AppType paramAppType)
  {
    Object localObject;
    switch (2.$SwitchMap$com$android$internal$telephony$uicc$IccCardApplicationStatus$AppType[paramAppType.ordinal()])
    {
    default:
      localObject = null;
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    }
    while (true)
    {
      return localObject;
      localObject = new SIMFileHandler(this, this.mAid, this.mCi);
      continue;
      localObject = new RuimFileHandler(this, this.mAid, this.mCi);
      continue;
      localObject = new UsimFileHandler(this, this.mAid, this.mCi);
      continue;
      localObject = new CsimFileHandler(this, this.mAid, this.mCi);
      continue;
      localObject = new IsimFileHandler(this, this.mAid, this.mCi);
    }
  }

  private IccRecords createIccRecords(IccCardApplicationStatus.AppType paramAppType, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    Object localObject;
    if ((paramAppType == IccCardApplicationStatus.AppType.APPTYPE_USIM) || (paramAppType == IccCardApplicationStatus.AppType.APPTYPE_SIM))
      localObject = new SIMRecords(this, paramContext, paramCommandsInterface);
    while (true)
    {
      return localObject;
      if ((paramAppType == IccCardApplicationStatus.AppType.APPTYPE_RUIM) || (paramAppType == IccCardApplicationStatus.AppType.APPTYPE_CSIM))
        localObject = new RuimRecords(this, paramContext, paramCommandsInterface);
      else if (paramAppType == IccCardApplicationStatus.AppType.APPTYPE_ISIM)
        localObject = new IsimUiccRecords(this, paramContext, paramCommandsInterface);
      else
        localObject = null;
    }
  }

  private void log(String paramString)
  {
    Rlog.d("UiccCardApplication", paramString);
  }

  private void loge(String paramString)
  {
    Rlog.e("UiccCardApplication", paramString);
  }

  private void notifyNetworkLockedRegistrantsIfNeeded(Registrant paramRegistrant)
  {
    if (this.mDestroyed);
    while (true)
    {
      return;
      if ((this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_SUBSCRIPTION_PERSO) && (this.mPersoSubState == IccCardApplicationStatus.PersoSubState.PERSOSUBSTATE_SIM_NETWORK))
        if (paramRegistrant == null)
        {
          log("Notifying registrants: NETWORK_LOCKED");
          this.mNetworkLockedRegistrants.notifyRegistrants();
        }
        else
        {
          log("Notifying 1 registrant: NETWORK_LOCED");
          paramRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
        }
    }
  }

  private void notifyPinLockedRegistrantsIfNeeded(Registrant paramRegistrant)
  {
    if (this.mDestroyed);
    while (true)
    {
      return;
      if ((this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_PIN) || (this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_PUK))
        if ((this.mPin1State == IccCardStatus.PinState.PINSTATE_ENABLED_VERIFIED) || (this.mPin1State == IccCardStatus.PinState.PINSTATE_DISABLED))
        {
          loge("Sanity check failed! APPSTATE is locked while PIN1 is not!!!");
        }
        else if (paramRegistrant == null)
        {
          log("Notifying registrants: LOCKED");
          this.mPinLockedRegistrants.notifyRegistrants();
        }
        else
        {
          log("Notifying 1 registrant: LOCKED");
          paramRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
        }
    }
  }

  private void notifyReadyRegistrantsIfNeeded(Registrant paramRegistrant)
  {
    if (this.mDestroyed);
    while (true)
    {
      return;
      if (this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_READY)
        if ((this.mPin1State == IccCardStatus.PinState.PINSTATE_ENABLED_NOT_VERIFIED) || (this.mPin1State == IccCardStatus.PinState.PINSTATE_ENABLED_BLOCKED) || (this.mPin1State == IccCardStatus.PinState.PINSTATE_ENABLED_PERM_BLOCKED))
        {
          loge("Sanity check failed! APPSTATE is ready while PIN1 is not verified!!!");
        }
        else if (paramRegistrant == null)
        {
          log("Notifying registrants: READY");
          this.mReadyRegistrants.notifyRegistrants();
        }
        else
        {
          log("Notifying 1 registrant: READY");
          paramRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
        }
    }
  }

  private void onChangeFacilityLock(AsyncResult paramAsyncResult)
  {
    Object localObject1 = this.mLock;
    int i = -1;
    try
    {
      if (paramAsyncResult.exception == null)
      {
        this.mIccLockEnabled = this.mDesiredPinLocked;
        log("EVENT_CHANGE_FACILITY_LOCK_DONE: mIccLockEnabled= " + this.mIccLockEnabled);
        Message localMessage = (Message)paramAsyncResult.userObj;
        AsyncResult.forMessage(localMessage).exception = paramAsyncResult.exception;
        localMessage.arg1 = i;
        localMessage.sendToTarget();
        return;
      }
      i = parsePinPukErrorResult(paramAsyncResult);
      loge("Error change facility lock with exception " + paramAsyncResult.exception);
    }
    finally
    {
    }
  }

  private void onChangeFdnDone(AsyncResult paramAsyncResult)
  {
    Object localObject1 = this.mLock;
    int i = -1;
    try
    {
      if (paramAsyncResult.exception == null)
      {
        this.mIccFdnEnabled = this.mDesiredFdnEnabled;
        log("EVENT_CHANGE_FACILITY_FDN_DONE: mIccFdnEnabled=" + this.mIccFdnEnabled);
        Message localMessage = (Message)paramAsyncResult.userObj;
        localMessage.arg1 = i;
        AsyncResult.forMessage(localMessage).exception = paramAsyncResult.exception;
        localMessage.sendToTarget();
        return;
      }
      i = parsePinPukErrorResult(paramAsyncResult);
      loge("Error change facility fdn with exception " + paramAsyncResult.exception);
    }
    finally
    {
    }
  }

  // ERROR //
  private void onQueryFacilityLock(AsyncResult paramAsyncResult)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 70	com/android/internal/telephony/uicc/UiccCardApplication:mLock	Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_1
    //   8: getfield 344	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   11: ifnull +35 -> 46
    //   14: aload_0
    //   15: new 90	java/lang/StringBuilder
    //   18: dup
    //   19: invokespecial 91	java/lang/StringBuilder:<init>	()V
    //   22: ldc_w 380
    //   25: invokevirtual 97	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: aload_1
    //   29: getfield 344	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   32: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   35: invokevirtual 104	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   38: invokespecial 108	com/android/internal/telephony/uicc/UiccCardApplication:log	(Ljava/lang/String;)V
    //   41: aload_2
    //   42: monitorexit
    //   43: goto +212 -> 255
    //   46: aload_1
    //   47: getfield 383	android/os/AsyncResult:result	Ljava/lang/Object;
    //   50: checkcast 384	[I
    //   53: checkcast 384	[I
    //   56: astore 4
    //   58: aload 4
    //   60: arraylength
    //   61: ifeq +184 -> 245
    //   64: aload_0
    //   65: new 90	java/lang/StringBuilder
    //   68: dup
    //   69: invokespecial 91	java/lang/StringBuilder:<init>	()V
    //   72: ldc_w 386
    //   75: invokevirtual 97	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   78: aload 4
    //   80: iconst_0
    //   81: iaload
    //   82: invokevirtual 389	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   85: invokevirtual 104	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   88: invokespecial 108	com/android/internal/telephony/uicc/UiccCardApplication:log	(Ljava/lang/String;)V
    //   91: aload 4
    //   93: iconst_0
    //   94: iaload
    //   95: ifeq +110 -> 205
    //   98: iconst_1
    //   99: istore 5
    //   101: aload_0
    //   102: iload 5
    //   104: putfield 348	com/android/internal/telephony/uicc/UiccCardApplication:mIccLockEnabled	Z
    //   107: aload_0
    //   108: getfield 348	com/android/internal/telephony/uicc/UiccCardApplication:mIccLockEnabled	Z
    //   111: ifeq +10 -> 121
    //   114: aload_0
    //   115: getfield 79	com/android/internal/telephony/uicc/UiccCardApplication:mPinLockedRegistrants	Landroid/os/RegistrantList;
    //   118: invokevirtual 291	android/os/RegistrantList:notifyRegistrants	()V
    //   121: getstatic 392	com/android/internal/telephony/uicc/UiccCardApplication$2:$SwitchMap$com$android$internal$telephony$uicc$IccCardStatus$PinState	[I
    //   124: aload_0
    //   125: getfield 147	com/android/internal/telephony/uicc/UiccCardApplication:mPin1State	Lcom/android/internal/telephony/uicc/IccCardStatus$PinState;
    //   128: invokevirtual 393	com/android/internal/telephony/uicc/IccCardStatus$PinState:ordinal	()I
    //   131: iaload
    //   132: tableswitch	default:+36 -> 168, 1:+79->211, 2:+96->228, 3:+96->228, 4:+96->228, 5:+96->228
    //   169: new 90	java/lang/StringBuilder
    //   172: dup
    //   173: invokespecial 91	java/lang/StringBuilder:<init>	()V
    //   176: ldc_w 395
    //   179: invokevirtual 97	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: aload_0
    //   183: getfield 147	com/android/internal/telephony/uicc/UiccCardApplication:mPin1State	Lcom/android/internal/telephony/uicc/IccCardStatus$PinState;
    //   186: invokevirtual 100	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   189: invokevirtual 104	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   192: invokespecial 108	com/android/internal/telephony/uicc/UiccCardApplication:log	(Ljava/lang/String;)V
    //   195: aload_2
    //   196: monitorexit
    //   197: goto +58 -> 255
    //   200: astore_3
    //   201: aload_2
    //   202: monitorexit
    //   203: aload_3
    //   204: athrow
    //   205: iconst_0
    //   206: istore 5
    //   208: goto -107 -> 101
    //   211: aload_0
    //   212: getfield 348	com/android/internal/telephony/uicc/UiccCardApplication:mIccLockEnabled	Z
    //   215: ifeq -20 -> 195
    //   218: aload_0
    //   219: ldc_w 397
    //   222: invokespecial 188	com/android/internal/telephony/uicc/UiccCardApplication:loge	(Ljava/lang/String;)V
    //   225: goto -30 -> 195
    //   228: aload_0
    //   229: getfield 348	com/android/internal/telephony/uicc/UiccCardApplication:mIccLockEnabled	Z
    //   232: ifne -64 -> 168
    //   235: aload_0
    //   236: ldc_w 399
    //   239: invokespecial 188	com/android/internal/telephony/uicc/UiccCardApplication:loge	(Ljava/lang/String;)V
    //   242: goto -74 -> 168
    //   245: aload_0
    //   246: ldc_w 401
    //   249: invokespecial 188	com/android/internal/telephony/uicc/UiccCardApplication:loge	(Ljava/lang/String;)V
    //   252: goto -57 -> 195
    //   255: return
    //
    // Exception table:
    //   from	to	target	type
    //   7	203	200	finally
    //   211	252	200	finally
  }

  private void onQueryFdnEnabled(AsyncResult paramAsyncResult)
  {
    while (true)
    {
      int[] arrayOfInt;
      synchronized (this.mLock)
      {
        if (paramAsyncResult.exception != null)
        {
          log("Error in querying facility lock:" + paramAsyncResult.exception);
        }
        else
        {
          arrayOfInt = (int[])paramAsyncResult.result;
          if (arrayOfInt.length != 0)
            if (arrayOfInt[0] == 2)
            {
              this.mIccFdnEnabled = false;
              this.mIccFdnAvailable = false;
              log("Query facility FDN : FDN service available: " + this.mIccFdnAvailable + " enabled: " + this.mIccFdnEnabled);
            }
        }
      }
      boolean bool = false;
    }
  }

  private int parsePinPukErrorResult(AsyncResult paramAsyncResult)
  {
    int[] arrayOfInt = (int[])paramAsyncResult.result;
    int j;
    if (arrayOfInt == null)
      j = -1;
    while (true)
    {
      return j;
      int i = arrayOfInt.length;
      j = -1;
      if (i > 0)
        j = arrayOfInt[0];
      log("parsePinPukErrorResult: attemptsRemaining=" + j);
    }
  }

  private void queryFdn()
  {
    this.mCi.queryFacilityLockForApp("FD", "", 7, this.mAid, this.mHandler.obtainMessage(4));
  }

  private void queryPin1State()
  {
    this.mCi.queryFacilityLockForApp("SC", "", 7, this.mAid, this.mHandler.obtainMessage(6));
  }

  public void changeIccFdnPassword(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      log("changeIccFdnPassword");
      this.mCi.changeIccPin2ForApp(paramString1, paramString2, this.mAid, this.mHandler.obtainMessage(3, paramMessage));
      return;
    }
  }

  public void changeIccLockPassword(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      log("changeIccLockPassword");
      this.mCi.changeIccPinForApp(paramString1, paramString2, this.mAid, this.mHandler.obtainMessage(2, paramMessage));
      return;
    }
  }

  void dispose()
  {
    synchronized (this.mLock)
    {
      log(this.mAppType + " being Disposed");
      this.mDestroyed = true;
      if (this.mIccRecords != null)
        this.mIccRecords.dispose();
      if (this.mIccFh != null)
        this.mIccFh.dispose();
      this.mIccRecords = null;
      this.mIccFh = null;
      return;
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("UiccCardApplication: " + this);
    paramPrintWriter.println(" mUiccCard=" + this.mUiccCard);
    paramPrintWriter.println(" mAppState=" + this.mAppState);
    paramPrintWriter.println(" mAppType=" + this.mAppType);
    paramPrintWriter.println(" mPersoSubState=" + this.mPersoSubState);
    paramPrintWriter.println(" mAid=" + this.mAid);
    paramPrintWriter.println(" mAppLabel=" + this.mAppLabel);
    paramPrintWriter.println(" mPin1Replaced=" + this.mPin1Replaced);
    paramPrintWriter.println(" mPin1State=" + this.mPin1State);
    paramPrintWriter.println(" mPin2State=" + this.mPin2State);
    paramPrintWriter.println(" mIccFdnEnabled=" + this.mIccFdnEnabled);
    paramPrintWriter.println(" mDesiredFdnEnabled=" + this.mDesiredFdnEnabled);
    paramPrintWriter.println(" mIccLockEnabled=" + this.mIccLockEnabled);
    paramPrintWriter.println(" mDesiredPinLocked=" + this.mDesiredPinLocked);
    paramPrintWriter.println(" mCi=" + this.mCi);
    paramPrintWriter.println(" mIccRecords=" + this.mIccRecords);
    paramPrintWriter.println(" mIccFh=" + this.mIccFh);
    paramPrintWriter.println(" mDestroyed=" + this.mDestroyed);
    paramPrintWriter.println(" mReadyRegistrants: size=" + this.mReadyRegistrants.size());
    for (int i = 0; i < this.mReadyRegistrants.size(); i++)
      paramPrintWriter.println("  mReadyRegistrants[" + i + "]=" + ((Registrant)this.mReadyRegistrants.get(i)).getHandler());
    paramPrintWriter.println(" mPinLockedRegistrants: size=" + this.mPinLockedRegistrants.size());
    for (int j = 0; j < this.mPinLockedRegistrants.size(); j++)
      paramPrintWriter.println("  mPinLockedRegistrants[" + j + "]=" + ((Registrant)this.mPinLockedRegistrants.get(j)).getHandler());
    paramPrintWriter.println(" mNetworkLockedRegistrants: size=" + this.mNetworkLockedRegistrants.size());
    for (int k = 0; k < this.mNetworkLockedRegistrants.size(); k++)
      paramPrintWriter.println("  mNetworkLockedRegistrants[" + k + "]=" + ((Registrant)this.mNetworkLockedRegistrants.get(k)).getHandler());
    paramPrintWriter.flush();
  }

  public String getAid()
  {
    synchronized (this.mLock)
    {
      String str = this.mAid;
      return str;
    }
  }

  public boolean getIccFdnAvailable()
  {
    return this.mIccFdnAvailable;
  }

  public boolean getIccFdnEnabled()
  {
    synchronized (this.mLock)
    {
      boolean bool = this.mIccFdnEnabled;
      return bool;
    }
  }

  public IccFileHandler getIccFileHandler()
  {
    synchronized (this.mLock)
    {
      IccFileHandler localIccFileHandler = this.mIccFh;
      return localIccFileHandler;
    }
  }

  public boolean getIccLockEnabled()
  {
    return this.mIccLockEnabled;
  }

  public boolean getIccPin2Blocked()
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mPin2State == IccCardStatus.PinState.PINSTATE_ENABLED_BLOCKED)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }

  public boolean getIccPuk2Blocked()
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mPin2State == IccCardStatus.PinState.PINSTATE_ENABLED_PERM_BLOCKED)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }

  public IccRecords getIccRecords()
  {
    synchronized (this.mLock)
    {
      IccRecords localIccRecords = this.mIccRecords;
      return localIccRecords;
    }
  }

  public IccCardApplicationStatus.PersoSubState getPersoSubState()
  {
    synchronized (this.mLock)
    {
      IccCardApplicationStatus.PersoSubState localPersoSubState = this.mPersoSubState;
      return localPersoSubState;
    }
  }

  public IccCardStatus.PinState getPin1State()
  {
    IccCardStatus.PinState localPinState;
    synchronized (this.mLock)
    {
      if (this.mPin1Replaced)
        localPinState = this.mUiccCard.getUniversalPinState();
      else
        localPinState = this.mPin1State;
    }
    return localPinState;
  }

  public IccCardApplicationStatus.AppState getState()
  {
    synchronized (this.mLock)
    {
      IccCardApplicationStatus.AppState localAppState = this.mAppState;
      return localAppState;
    }
  }

  public IccCardApplicationStatus.AppType getType()
  {
    synchronized (this.mLock)
    {
      IccCardApplicationStatus.AppType localAppType = this.mAppType;
      return localAppType;
    }
  }

  public void registerForLocked(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mPinLockedRegistrants.add(localRegistrant);
      notifyPinLockedRegistrantsIfNeeded(localRegistrant);
      return;
    }
  }

  public void registerForNetworkLocked(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mNetworkLockedRegistrants.add(localRegistrant);
      notifyNetworkLockedRegistrantsIfNeeded(localRegistrant);
      return;
    }
  }

  public void registerForReady(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (this.mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mReadyRegistrants.add(localRegistrant);
      notifyReadyRegistrantsIfNeeded(localRegistrant);
      return;
    }
  }

  public void setIccFdnEnabled(boolean paramBoolean, String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mDesiredFdnEnabled = paramBoolean;
      this.mCi.setFacilityLockForApp("FD", paramBoolean, paramString, 15, this.mAid, this.mHandler.obtainMessage(5, paramMessage));
      return;
    }
  }

  public void setIccLockEnabled(boolean paramBoolean, String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mDesiredPinLocked = paramBoolean;
      this.mCi.setFacilityLockForApp("SC", paramBoolean, paramString, 7, this.mAid, this.mHandler.obtainMessage(7, paramMessage));
      return;
    }
  }

  public void supplyNetworkDepersonalization(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      log("supplyNetworkDepersonalization");
      this.mCi.supplyNetworkDepersonalization(paramString, paramMessage);
      return;
    }
  }

  public void supplyPin(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mCi.supplyIccPinForApp(paramString, this.mAid, this.mHandler.obtainMessage(1, paramMessage));
      return;
    }
  }

  public void supplyPin2(String paramString, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mCi.supplyIccPin2ForApp(paramString, this.mAid, this.mHandler.obtainMessage(8, paramMessage));
      return;
    }
  }

  public void supplyPuk(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mCi.supplyIccPukForApp(paramString1, paramString2, this.mAid, this.mHandler.obtainMessage(1, paramMessage));
      return;
    }
  }

  public void supplyPuk2(String paramString1, String paramString2, Message paramMessage)
  {
    synchronized (this.mLock)
    {
      this.mCi.supplyIccPuk2ForApp(paramString1, paramString2, this.mAid, this.mHandler.obtainMessage(8, paramMessage));
      return;
    }
  }

  public void unregisterForLocked(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mPinLockedRegistrants.remove(paramHandler);
      return;
    }
  }

  public void unregisterForNetworkLocked(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mNetworkLockedRegistrants.remove(paramHandler);
      return;
    }
  }

  public void unregisterForReady(Handler paramHandler)
  {
    synchronized (this.mLock)
    {
      this.mReadyRegistrants.remove(paramHandler);
      return;
    }
  }

  void update(IccCardApplicationStatus paramIccCardApplicationStatus, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    while (true)
    {
      synchronized (this.mLock)
      {
        if (this.mDestroyed)
        {
          loge("Application updated after destroyed! Fix me!");
          break;
        }
        log(this.mAppType + " update. New " + paramIccCardApplicationStatus);
        this.mContext = paramContext;
        this.mCi = paramCommandsInterface;
        IccCardApplicationStatus.AppType localAppType = this.mAppType;
        IccCardApplicationStatus.AppState localAppState = this.mAppState;
        IccCardApplicationStatus.PersoSubState localPersoSubState = this.mPersoSubState;
        this.mAppType = paramIccCardApplicationStatus.app_type;
        this.mAppState = paramIccCardApplicationStatus.app_state;
        this.mPersoSubState = paramIccCardApplicationStatus.perso_substate;
        this.mAid = paramIccCardApplicationStatus.aid;
        this.mAppLabel = paramIccCardApplicationStatus.app_label;
        if (paramIccCardApplicationStatus.pin1_replaced != 0)
        {
          bool = true;
          this.mPin1Replaced = bool;
          this.mPin1State = paramIccCardApplicationStatus.pin1;
          this.mPin2State = paramIccCardApplicationStatus.pin2;
          if (this.mAppType != localAppType)
          {
            if (this.mIccFh != null)
              this.mIccFh.dispose();
            if (this.mIccRecords != null)
              this.mIccRecords.dispose();
            this.mIccFh = createIccFileHandler(paramIccCardApplicationStatus.app_type);
            this.mIccRecords = createIccRecords(paramIccCardApplicationStatus.app_type, paramContext, paramCommandsInterface);
          }
          if ((this.mPersoSubState != localPersoSubState) && (this.mPersoSubState == IccCardApplicationStatus.PersoSubState.PERSOSUBSTATE_SIM_NETWORK))
            notifyNetworkLockedRegistrantsIfNeeded(null);
          if (this.mAppState != localAppState)
          {
            log(localAppType + " changed state: " + localAppState + " -> " + this.mAppState);
            if (this.mAppState == IccCardApplicationStatus.AppState.APPSTATE_READY)
            {
              queryFdn();
              queryPin1State();
            }
            notifyPinLockedRegistrantsIfNeeded(null);
            notifyReadyRegistrantsIfNeeded(null);
          }
        }
      }
      boolean bool = false;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.UiccCardApplication
 * JD-Core Version:    0.6.2
 */