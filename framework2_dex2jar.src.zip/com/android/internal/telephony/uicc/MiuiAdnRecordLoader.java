package com.android.internal.telephony.uicc;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.SparseArray;
import com.android.internal.telephony.MiuiIccProviderException;
import java.util.ArrayList;

public class MiuiAdnRecordLoader extends Handler
{
  static final int EVENT_ADN_LOAD_ALL_DONE = 4;
  static final int EVENT_ADN_SIZE_LOAD_DONE = 1;
  static final int EVENT_EF_LINEAR_RECORD_SIZE_DONE = 5;
  static final int EVENT_EXT_RECORD_LOAD_DONE = 3;
  static final int EVENT_EXT_SIZE_LOAD_DONE = 2;
  static final int EVENT_UPDATE_RECORD_DONE = 6;
  static final String LOG_TAG = "MiuiAdnRecordLoader";
  ArrayList<MiuiAdnRecord> adns;
  int ef;
  int extensionEF;
  private MiuiIccFileHandler mFh;
  int pendingExtLoads;
  String pin2;
  int recordNumber;
  Object result;
  SparseArray<int[]> sRecordSizes = new SparseArray();
  Message userResponse;

  public MiuiAdnRecordLoader(MiuiIccFileHandler paramMiuiIccFileHandler)
  {
    super(Looper.getMainLooper());
    this.mFh = paramMiuiIccFileHandler;
  }

  public void handleMessage(Message paramMessage)
  {
    int i = 0;
    switch (paramMessage.what)
    {
    default:
    case 1:
    case 2:
    case 5:
    case 6:
    case 3:
    case 4:
    }
    while (true)
    {
      if ((this.userResponse != null) && (this.pendingExtLoads == 0))
      {
        AsyncResult.forMessage(this.userResponse).result = this.result;
        this.userResponse.sendToTarget();
        this.userResponse = null;
      }
      ArrayList localArrayList;
      while (true)
      {
        return;
        AsyncResult localAsyncResult6 = (AsyncResult)paramMessage.obj;
        if (saveRecordSize(this.ef, localAsyncResult6) != null)
        {
          if (this.extensionEF != 0)
            this.mFh.getEFLinearRecordSize(this.extensionEF, obtainMessage(2));
          while (true)
          {
            this.pendingExtLoads = 1;
            break;
            int[] arrayOfInt3 = (int[])this.sRecordSizes.get(this.ef);
            this.mFh.loadEFLinearFixedAll(this.ef, arrayOfInt3[0], arrayOfInt3[2], obtainMessage(4));
          }
          AsyncResult localAsyncResult5 = (AsyncResult)paramMessage.obj;
          if (saveRecordSize(this.extensionEF, localAsyncResult5) != null)
          {
            int[] arrayOfInt2 = (int[])this.sRecordSizes.get(this.ef);
            this.mFh.loadEFLinearFixedAll(this.ef, arrayOfInt2[0], arrayOfInt2[2], obtainMessage(4));
            this.pendingExtLoads = 1;
            break;
            AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
            MiuiAdnRecord localMiuiAdnRecord3 = (MiuiAdnRecord)localAsyncResult4.userObj;
            int[] arrayOfInt1 = saveRecordSize(this.ef, localAsyncResult4);
            if (arrayOfInt1 != null)
              if (this.recordNumber > arrayOfInt1[2])
              {
                sendErrorResponse(new MiuiIccProviderException(-1001));
              }
              else
              {
                byte[] arrayOfByte2 = localMiuiAdnRecord3.buildAdnString(arrayOfInt1[0]);
                if (arrayOfByte2 == null)
                {
                  sendErrorResponse(new MiuiIccProviderException(-1001));
                }
                else
                {
                  this.pendingExtLoads = 1;
                  this.mFh.updateEFLinearFixed(this.ef, this.recordNumber, arrayOfByte2, this.pin2, obtainMessage(6));
                  break;
                  AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
                  if (localAsyncResult3.exception != null)
                  {
                    sendErrorResponse(localAsyncResult3.exception);
                  }
                  else
                  {
                    this.pendingExtLoads = 0;
                    this.result = null;
                    break;
                    AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
                    byte[] arrayOfByte1 = (byte[])localAsyncResult2.result;
                    MiuiAdnRecord localMiuiAdnRecord2 = (MiuiAdnRecord)localAsyncResult2.userObj;
                    if (localAsyncResult2.exception != null)
                    {
                      sendErrorResponse(localAsyncResult2.exception);
                    }
                    else
                    {
                      localMiuiAdnRecord2.appendExtRecord(arrayOfByte1);
                      this.pendingExtLoads = (-1 + this.pendingExtLoads);
                      break;
                      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
                      localArrayList = (ArrayList)localAsyncResult1.result;
                      if (localAsyncResult1.exception == null)
                        break label556;
                      sendErrorResponse(localAsyncResult1.exception);
                    }
                  }
                }
              }
          }
        }
      }
      label556: this.adns = new ArrayList(localArrayList.size());
      this.result = this.adns;
      this.pendingExtLoads = 0;
      if (this.extensionEF > 0)
        i = ((int[])this.sRecordSizes.get(this.extensionEF))[0];
      int j = 0;
      int k = localArrayList.size();
      while (j < k)
      {
        MiuiAdnRecord localMiuiAdnRecord1 = new MiuiAdnRecord(this.ef, j + 1, (byte[])localArrayList.get(j));
        this.adns.add(localMiuiAdnRecord1);
        if (localMiuiAdnRecord1.hasExtendedRecord())
        {
          this.pendingExtLoads = (1 + this.pendingExtLoads);
          this.mFh.loadEFLinearFixed(this.extensionEF, i, localMiuiAdnRecord1.mExtRecord, obtainMessage(3, localMiuiAdnRecord1));
        }
        j++;
      }
    }
  }

  public void loadAllFromEF(int paramInt1, int paramInt2, Message paramMessage)
  {
    this.ef = paramInt1;
    this.extensionEF = paramInt2;
    this.userResponse = paramMessage;
    int[] arrayOfInt = (int[])this.sRecordSizes.get(paramInt1);
    if (arrayOfInt != null)
      this.mFh.loadEFLinearFixedAll(paramInt1, arrayOfInt[0], arrayOfInt[2], obtainMessage(4));
    while (true)
    {
      return;
      this.mFh.getEFLinearRecordSize(paramInt1, obtainMessage(1));
    }
  }

  int[] saveRecordSize(int paramInt, AsyncResult paramAsyncResult)
  {
    int[] arrayOfInt;
    if (paramAsyncResult.exception != null)
    {
      sendErrorResponse(paramAsyncResult.exception);
      arrayOfInt = null;
    }
    while (true)
    {
      return arrayOfInt;
      arrayOfInt = (int[])paramAsyncResult.result;
      if (arrayOfInt.length != 3)
      {
        sendErrorResponse(new MiuiIccProviderException(-1001));
        arrayOfInt = null;
      }
      else
      {
        this.sRecordSizes.put(paramInt, arrayOfInt);
      }
    }
  }

  void sendErrorResponse(Throwable paramThrowable)
  {
    if (this.userResponse != null)
    {
      AsyncResult.forMessage(this.userResponse).exception = paramThrowable;
      this.userResponse.sendToTarget();
      this.userResponse = null;
    }
  }

  public void updateEF(AdnRecord paramAdnRecord, int paramInt1, int paramInt2, int paramInt3, String paramString, Message paramMessage)
  {
    this.ef = paramInt1;
    this.extensionEF = paramInt2;
    this.recordNumber = paramInt3;
    this.userResponse = paramMessage;
    this.pin2 = paramString;
    if (this.sRecordSizes.get(paramInt1) == null)
      this.mFh.getEFLinearRecordSize(paramInt1, obtainMessage(5, paramAdnRecord));
    while (true)
    {
      return;
      byte[] arrayOfByte = paramAdnRecord.buildAdnString(((int[])this.sRecordSizes.get(paramInt1))[0]);
      if (arrayOfByte == null)
      {
        sendErrorResponse(new MiuiIccProviderException(-1001));
      }
      else
      {
        this.pendingExtLoads = 1;
        this.mFh.updateEFLinearFixed(paramInt1, paramInt3, arrayOfByte, paramString, obtainMessage(6));
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.MiuiAdnRecordLoader
 * JD-Core Version:    0.6.2
 */