package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import com.android.internal.telephony.CommandsInterface;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class IccRecords extends Handler
  implements IccConstants
{
  protected static final boolean DBG = true;
  protected static final int EVENT_APP_READY = 1;
  public static final int EVENT_CFI = 1;
  public static final int EVENT_GET_ICC_RECORD_DONE = 100;
  public static final int EVENT_MWI = 0;
  protected static final int EVENT_SET_MSISDN_DONE = 30;
  public static final int EVENT_SPN = 2;
  public static final int SPN_RULE_SHOW_PLMN = 2;
  public static final int SPN_RULE_SHOW_SPN = 1;
  protected static final int UNINITIALIZED = -1;
  protected static final int UNKNOWN;
  protected AdnRecordCache mAdnCache;
  protected CommandsInterface mCi;
  protected Context mContext;
  protected int mCountVoiceMessages = 0;
  protected AtomicBoolean mDestroyed = new AtomicBoolean(false);
  protected IccFileHandler mFh;
  protected String mGid1;
  protected String mIccId;
  protected String mImsi;
  protected RegistrantList mImsiReadyRegistrants = new RegistrantList();
  protected boolean mIsVoiceMailFixed = false;
  protected int mMailboxIndex = 0;
  protected int mMncLength = -1;
  protected String mMsisdn = null;
  protected String mMsisdnTag = null;
  protected RegistrantList mNetworkSelectionModeAutomaticRegistrants = new RegistrantList();
  protected RegistrantList mNewSmsRegistrants = new RegistrantList();
  protected String mNewVoiceMailNum = null;
  protected String mNewVoiceMailTag = null;
  protected UiccCardApplication mParentApp;
  protected RegistrantList mRecordsEventsRegistrants = new RegistrantList();
  protected RegistrantList mRecordsLoadedRegistrants = new RegistrantList();
  protected boolean mRecordsRequested = false;
  protected int mRecordsToLoad;
  protected String mSpn;
  protected String mVoiceMailNum = null;
  protected String mVoiceMailTag = null;

  public IccRecords(UiccCardApplication paramUiccCardApplication, Context paramContext, CommandsInterface paramCommandsInterface)
  {
    this.mContext = paramContext;
    this.mCi = paramCommandsInterface;
    this.mFh = paramUiccCardApplication.getIccFileHandler();
    this.mParentApp = paramUiccCardApplication;
  }

  public void dispose()
  {
    this.mDestroyed.set(true);
    this.mParentApp = null;
    this.mFh = null;
    this.mCi = null;
    this.mContext = null;
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("IccRecords: " + this);
    paramPrintWriter.println(" mDestroyed=" + this.mDestroyed);
    paramPrintWriter.println(" mCi=" + this.mCi);
    paramPrintWriter.println(" mFh=" + this.mFh);
    paramPrintWriter.println(" mParentApp=" + this.mParentApp);
    paramPrintWriter.println(" recordsLoadedRegistrants: size=" + this.mRecordsLoadedRegistrants.size());
    for (int i = 0; i < this.mRecordsLoadedRegistrants.size(); i++)
      paramPrintWriter.println("  recordsLoadedRegistrants[" + i + "]=" + ((Registrant)this.mRecordsLoadedRegistrants.get(i)).getHandler());
    paramPrintWriter.println(" mImsiReadyRegistrants: size=" + this.mImsiReadyRegistrants.size());
    for (int j = 0; j < this.mImsiReadyRegistrants.size(); j++)
      paramPrintWriter.println("  mImsiReadyRegistrants[" + j + "]=" + ((Registrant)this.mImsiReadyRegistrants.get(j)).getHandler());
    paramPrintWriter.println(" mRecordsEventsRegistrants: size=" + this.mRecordsEventsRegistrants.size());
    for (int k = 0; k < this.mRecordsEventsRegistrants.size(); k++)
      paramPrintWriter.println("  mRecordsEventsRegistrants[" + k + "]=" + ((Registrant)this.mRecordsEventsRegistrants.get(k)).getHandler());
    paramPrintWriter.println(" mNewSmsRegistrants: size=" + this.mNewSmsRegistrants.size());
    for (int m = 0; m < this.mNewSmsRegistrants.size(); m++)
      paramPrintWriter.println("  mNewSmsRegistrants[" + m + "]=" + ((Registrant)this.mNewSmsRegistrants.get(m)).getHandler());
    paramPrintWriter.println(" mNetworkSelectionModeAutomaticRegistrants: size=" + this.mNetworkSelectionModeAutomaticRegistrants.size());
    for (int n = 0; n < this.mNetworkSelectionModeAutomaticRegistrants.size(); n++)
      paramPrintWriter.println("  mNetworkSelectionModeAutomaticRegistrants[" + n + "]=" + ((Registrant)this.mNetworkSelectionModeAutomaticRegistrants.get(n)).getHandler());
    paramPrintWriter.println(" mRecordsRequested=" + this.mRecordsRequested);
    paramPrintWriter.println(" mRecordsToLoad=" + this.mRecordsToLoad);
    paramPrintWriter.println(" mRdnCache=" + this.mAdnCache);
    paramPrintWriter.println(" iccid=" + this.mIccId);
    paramPrintWriter.println(" mMsisdn=" + this.mMsisdn);
    paramPrintWriter.println(" mMsisdnTag=" + this.mMsisdnTag);
    paramPrintWriter.println(" mVoiceMailNum=" + this.mVoiceMailNum);
    paramPrintWriter.println(" mVoiceMailTag=" + this.mVoiceMailTag);
    paramPrintWriter.println(" mNewVoiceMailNum=" + this.mNewVoiceMailNum);
    paramPrintWriter.println(" mNewVoiceMailTag=" + this.mNewVoiceMailTag);
    paramPrintWriter.println(" mIsVoiceMailFixed=" + this.mIsVoiceMailFixed);
    paramPrintWriter.println(" mCountVoiceMessages=" + this.mCountVoiceMessages);
    paramPrintWriter.println(" mImsi=" + this.mImsi);
    paramPrintWriter.println(" mMncLength=" + this.mMncLength);
    paramPrintWriter.println(" mMailboxIndex=" + this.mMailboxIndex);
    paramPrintWriter.println(" mSpn=" + this.mSpn);
    paramPrintWriter.flush();
  }

  public AdnRecordCache getAdnCache()
  {
    return this.mAdnCache;
  }

  public abstract int getDisplayRule(String paramString);

  public String getGid1()
  {
    return null;
  }

  public String getIMSI()
  {
    return null;
  }

  public String getIccId()
  {
    return this.mIccId;
  }

  public IsimRecords getIsimRecords()
  {
    return null;
  }

  public String getMsisdnAlphaTag()
  {
    return this.mMsisdnTag;
  }

  public String getMsisdnNumber()
  {
    return this.mMsisdn;
  }

  public String getOperatorNumeric()
  {
    return null;
  }

  public boolean getRecordsLoaded()
  {
    boolean bool = true;
    if ((this.mRecordsToLoad == 0) && (this.mRecordsRequested == bool));
    while (true)
    {
      return bool;
      bool = false;
    }
  }

  public String getServiceProviderName()
  {
    return this.mSpn;
  }

  public UsimServiceTable getUsimServiceTable()
  {
    return null;
  }

  public boolean getVoiceCallForwardingFlag()
  {
    return false;
  }

  public String getVoiceMailAlphaTag()
  {
    return this.mVoiceMailTag;
  }

  public String getVoiceMailNumber()
  {
    return this.mVoiceMailNum;
  }

  public int getVoiceMessageCount()
  {
    return this.mCountVoiceMessages;
  }

  public boolean getVoiceMessageWaiting()
  {
    if (this.mCountVoiceMessages != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 100:
    }
    while (true)
    {
      return;
      try
      {
        AsyncResult localAsyncResult = (AsyncResult)paramMessage.obj;
        IccRecordLoaded localIccRecordLoaded = (IccRecordLoaded)localAsyncResult.userObj;
        log(localIccRecordLoaded.getEfName() + " LOADED");
        if (localAsyncResult.exception != null)
          loge("Record Load Exception: " + localAsyncResult.exception);
        while (true)
        {
          onRecordLoaded();
          break;
          localIccRecordLoaded.onRecordLoaded(localAsyncResult);
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        while (true)
          loge("Exception parsing SIM record: " + localRuntimeException);
      }
      finally
      {
        onRecordLoaded();
      }
    }
  }

  public boolean isCspPlmnEnabled()
  {
    return false;
  }

  public boolean isProvisioned()
  {
    return true;
  }

  protected abstract void log(String paramString);

  protected abstract void loge(String paramString);

  protected abstract void onAllRecordsLoaded();

  protected void onIccRefreshInit()
  {
    this.mAdnCache.reset();
    if (this.mParentApp.getState() == IccCardApplicationStatus.AppState.APPSTATE_READY)
      sendMessage(obtainMessage(1));
  }

  public abstract void onReady();

  protected abstract void onRecordLoaded();

  public abstract void onRefresh(boolean paramBoolean, int[] paramArrayOfInt);

  public void registerForImsiReady(Handler paramHandler, int paramInt, Object paramObject)
  {
    if (this.mDestroyed.get());
    while (true)
    {
      return;
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mImsiReadyRegistrants.add(localRegistrant);
      if (this.mImsi != null)
        localRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
    }
  }

  public void registerForNetworkSelectionModeAutomatic(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mNetworkSelectionModeAutomaticRegistrants.add(localRegistrant);
  }

  public void registerForNewSms(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mNewSmsRegistrants.add(localRegistrant);
  }

  public void registerForRecordsEvents(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mRecordsEventsRegistrants.add(localRegistrant);
  }

  public void registerForRecordsLoaded(Handler paramHandler, int paramInt, Object paramObject)
  {
    if (this.mDestroyed.get());
    while (true)
    {
      return;
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mRecordsLoadedRegistrants.add(localRegistrant);
      if ((this.mRecordsToLoad == 0) && (this.mRecordsRequested == true))
        localRegistrant.notifyRegistrant(new AsyncResult(null, null, null));
    }
  }

  public void setImsi(String paramString)
  {
    this.mImsi = paramString;
    this.mImsiReadyRegistrants.notifyRegistrants();
  }

  public void setMsisdnNumber(String paramString1, String paramString2, Message paramMessage)
  {
    this.mMsisdn = paramString2;
    this.mMsisdnTag = paramString1;
    log("Set MSISDN: " + this.mMsisdnTag + " " + this.mMsisdn);
    AdnRecord localAdnRecord = new AdnRecord(this.mMsisdnTag, this.mMsisdn);
    new AdnRecordLoader(this.mFh).updateEF(localAdnRecord, 28480, 28490, 1, null, obtainMessage(30, paramMessage));
  }

  public void setVoiceCallForwardingFlag(int paramInt, boolean paramBoolean, String paramString)
  {
  }

  public abstract void setVoiceMailNumber(String paramString1, String paramString2, Message paramMessage);

  public abstract void setVoiceMessageWaiting(int paramInt1, int paramInt2);

  public String toString()
  {
    return "mDestroyed=" + this.mDestroyed + " mContext=" + this.mContext + " mCi=" + this.mCi + " mFh=" + this.mFh + " mParentApp=" + this.mParentApp + " recordsLoadedRegistrants=" + this.mRecordsLoadedRegistrants + " mImsiReadyRegistrants=" + this.mImsiReadyRegistrants + " mRecordsEventsRegistrants=" + this.mRecordsEventsRegistrants + " mNewSmsRegistrants=" + this.mNewSmsRegistrants + " mNetworkSelectionModeAutomaticRegistrants=" + this.mNetworkSelectionModeAutomaticRegistrants + " recordsToLoad=" + this.mRecordsToLoad + " adnCache=" + this.mAdnCache + " recordsRequested=" + this.mRecordsRequested + " iccid=" + this.mIccId + " msisdn=" + this.mMsisdn + " msisdnTag=" + this.mMsisdnTag + " voiceMailNum=" + this.mVoiceMailNum + " voiceMailTag=" + this.mVoiceMailTag + " newVoiceMailNum=" + this.mNewVoiceMailNum + " newVoiceMailTag=" + this.mNewVoiceMailTag + " isVoiceMailFixed=" + this.mIsVoiceMailFixed + " countVoiceMessages=" + this.mCountVoiceMessages + " mImsi=" + this.mImsi + " mncLength=" + this.mMncLength + " mailboxIndex=" + this.mMailboxIndex + " spn=" + this.mSpn;
  }

  public void unregisterForImsiReady(Handler paramHandler)
  {
    this.mImsiReadyRegistrants.remove(paramHandler);
  }

  public void unregisterForNetworkSelectionModeAutomatic(Handler paramHandler)
  {
    this.mNetworkSelectionModeAutomaticRegistrants.remove(paramHandler);
  }

  public void unregisterForNewSms(Handler paramHandler)
  {
    this.mNewSmsRegistrants.remove(paramHandler);
  }

  public void unregisterForRecordsEvents(Handler paramHandler)
  {
    this.mRecordsEventsRegistrants.remove(paramHandler);
  }

  public void unregisterForRecordsLoaded(Handler paramHandler)
  {
    this.mRecordsLoadedRegistrants.remove(paramHandler);
  }

  public static abstract interface IccRecordLoaded
  {
    public abstract String getEfName();

    public abstract void onRecordLoaded(AsyncResult paramAsyncResult);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IccRecords
 * JD-Core Version:    0.6.2
 */