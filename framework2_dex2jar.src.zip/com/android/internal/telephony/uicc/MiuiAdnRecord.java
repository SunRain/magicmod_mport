package com.android.internal.telephony.uicc;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;

public class MiuiAdnRecord extends AdnRecord
{
  public static final Parcelable.Creator<MiuiAdnRecord> CREATOR = new Parcelable.Creator()
  {
    public MiuiAdnRecord createFromParcel(Parcel paramAnonymousParcel)
    {
      return new MiuiAdnRecord(paramAnonymousParcel.readInt(), paramAnonymousParcel.readInt(), paramAnonymousParcel.readString(), paramAnonymousParcel.readString(), paramAnonymousParcel.readStringArray(), paramAnonymousParcel.readString());
    }

    public MiuiAdnRecord[] newArray(int paramAnonymousInt)
    {
      return new MiuiAdnRecord[paramAnonymousInt];
    }
  };
  String mAnr = "";

  public MiuiAdnRecord(int paramInt1, int paramInt2, String paramString1, String paramString2, String[] paramArrayOfString, String paramString3)
  {
    super(paramInt1, paramInt2, paramString1, paramString2, paramArrayOfString);
    this.mAnr = paramString3;
  }

  public MiuiAdnRecord(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    super(paramInt1, paramInt2, paramArrayOfByte);
  }

  public MiuiAdnRecord(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }

  public MiuiAdnRecord(String paramString1, String paramString2, String[] paramArrayOfString, String paramString3)
  {
    this(0, 0, paramString1, paramString2, paramArrayOfString, paramString3);
  }

  private static boolean stringCompareNullEqualsEmpty(String paramString1, String paramString2)
  {
    if (paramString1 == paramString2);
    for (boolean bool = true; ; bool = paramString1.equals(paramString2))
    {
      return bool;
      if (paramString1 == null)
        paramString1 = "";
      if (paramString2 == null)
        paramString2 = "";
    }
  }

  public byte[] buildAdnString(int paramInt)
  {
    int i = paramInt - 14;
    byte[] arrayOfByte1 = new byte[paramInt];
    for (int j = 0; j < paramInt; j++)
      arrayOfByte1[j] = -1;
    if (isEmpty());
    label205: 
    while (true)
    {
      return arrayOfByte1;
      if ((this.mNumber != null) && (this.mNumber.length() > 20))
      {
        Log.w("AdnRecord", "[buildAdnString] Max length of dialing number is 20");
        arrayOfByte1 = null;
      }
      else if ((this.mAlphaTag != null) && (this.mAlphaTag.length() > i))
      {
        Log.w("AdnRecord", "[buildAdnString] Max length of tag is " + i);
        arrayOfByte1 = null;
      }
      else
      {
        if (!TextUtils.isEmpty(this.mNumber))
        {
          byte[] arrayOfByte2 = PhoneNumberUtils.numberToCalledPartyBCD(this.mNumber);
          System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i + 1, arrayOfByte2.length);
          arrayOfByte1[(i + 0)] = ((byte)arrayOfByte2.length);
          arrayOfByte1[(i + 12)] = -1;
          arrayOfByte1[(i + 13)] = -1;
        }
        while (true)
        {
          if (TextUtils.isEmpty(this.mAlphaTag))
            break label205;
          Injector.AdnRecordHook.encodeAlphaTag("AdnRecord", arrayOfByte1, this.mAlphaTag, i);
          break;
          arrayOfByte1[(i + 0)] = 0;
        }
      }
    }
  }

  public String getAnr()
  {
    return this.mAnr;
  }

  public boolean isEmpty()
  {
    if ((TextUtils.isEmpty(this.mAlphaTag)) && (TextUtils.isEmpty(this.mNumber)) && (this.mEmails == null) && (TextUtils.isEmpty(this.mAnr)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isEqual(AdnRecord paramAdnRecord)
  {
    if ((stringCompareNullEqualsEmpty(this.mAlphaTag, paramAdnRecord.mAlphaTag)) && (stringCompareNullEqualsEmpty(this.mNumber, paramAdnRecord.mNumber)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void setAlphaTag(String paramString)
  {
    this.mAlphaTag = paramString;
  }

  public void setAnr(String paramString)
  {
    this.mAnr = paramString;
  }

  public void setNumber(String paramString)
  {
    this.mNumber = paramString;
  }

  public String toString()
  {
    return "ADN Record '" + this.mAlphaTag + " " + this.mNumber + " " + this.mEmails + " " + this.mAnr + "'";
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    super.writeToParcel(paramParcel, paramInt);
    paramParcel.writeString(this.mAnr);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.MiuiAdnRecord
 * JD-Core Version:    0.6.2
 */