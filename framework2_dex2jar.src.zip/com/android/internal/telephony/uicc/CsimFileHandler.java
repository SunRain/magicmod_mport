package com.android.internal.telephony.uicc;

import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;

public final class CsimFileHandler extends IccFileHandler
  implements IccConstants
{
  static final String LOG_TAG = "CsimFH";

  public CsimFileHandler(UiccCardApplication paramUiccCardApplication, String paramString, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramString, paramCommandsInterface);
  }

  protected String getEFPath(int paramInt)
  {
    switch (paramInt)
    {
    default:
      str = getCommonIccEFPath(paramInt);
      if (str != null)
        break;
    case 28450:
    case 28456:
    case 28466:
    case 28474:
    case 28475:
    case 28476:
    case 28480:
    case 28481:
    case 28484:
    case 28506:
    }
    for (String str = "3F007F105F3A"; ; str = "3F007FFF")
      return str;
  }

  protected void logd(String paramString)
  {
    Rlog.d("CsimFH", paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("CsimFH", paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.CsimFileHandler
 * JD-Core Version:    0.6.2
 */