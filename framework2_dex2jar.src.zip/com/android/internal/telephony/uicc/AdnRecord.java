package com.android.internal.telephony.uicc;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.text.TextUtils;
import java.util.Arrays;

public class AdnRecord
  implements Parcelable
{
  static final int ADN_BCD_NUMBER_LENGTH = 0;
  static final int ADN_CAPABILITY_ID = 12;
  static final int ADN_DIALING_NUMBER_END = 11;
  static final int ADN_DIALING_NUMBER_START = 2;
  static final int ADN_EXTENSION_ID = 13;
  static final int ADN_TON_AND_NPI = 1;
  public static final Parcelable.Creator<AdnRecord> CREATOR = new Parcelable.Creator()
  {
    public AdnRecord createFromParcel(Parcel paramAnonymousParcel)
    {
      return new AdnRecord(paramAnonymousParcel.readInt(), paramAnonymousParcel.readInt(), paramAnonymousParcel.readString(), paramAnonymousParcel.readString(), paramAnonymousParcel.readStringArray());
    }

    public AdnRecord[] newArray(int paramAnonymousInt)
    {
      return new AdnRecord[paramAnonymousInt];
    }
  };
  static final int EXT_RECORD_LENGTH_BYTES = 13;
  static final int EXT_RECORD_TYPE_ADDITIONAL_DATA = 2;
  static final int EXT_RECORD_TYPE_MASK = 3;
  static final int FOOTER_SIZE_BYTES = 14;
  static final String LOG_TAG = "AdnRecord";
  static final int MAX_EXT_CALLED_PARTY_LENGTH = 10;
  static final int MAX_NUMBER_SIZE_BYTES = 255;
  String mAlphaTag = null;
  int mEfid;
  String[] mEmails;
  int mExtRecord = 255;
  String mNumber = null;
  int mRecordNumber;

  public AdnRecord(int paramInt1, int paramInt2, String paramString1, String paramString2)
  {
    this.mEfid = paramInt1;
    this.mRecordNumber = paramInt2;
    this.mAlphaTag = paramString1;
    this.mNumber = paramString2;
    this.mEmails = null;
  }

  public AdnRecord(int paramInt1, int paramInt2, String paramString1, String paramString2, String[] paramArrayOfString)
  {
    this.mEfid = paramInt1;
    this.mRecordNumber = paramInt2;
    this.mAlphaTag = paramString1;
    this.mNumber = paramString2;
    this.mEmails = paramArrayOfString;
  }

  public AdnRecord(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    this.mEfid = paramInt1;
    this.mRecordNumber = paramInt2;
    parseRecord(paramArrayOfByte);
  }

  public AdnRecord(String paramString1, String paramString2)
  {
    this(0, 0, paramString1, paramString2);
  }

  public AdnRecord(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    this(0, 0, paramString1, paramString2, paramArrayOfString);
  }

  public AdnRecord(byte[] paramArrayOfByte)
  {
    this(0, 0, paramArrayOfByte);
  }

  private void parseRecord(byte[] paramArrayOfByte)
  {
    try
    {
      this.mAlphaTag = IccUtils.adnStringFieldToString(paramArrayOfByte, 0, -14 + paramArrayOfByte.length);
      int i = -14 + paramArrayOfByte.length;
      int j = 0xFF & paramArrayOfByte[i];
      if (j > 255)
      {
        this.mNumber = "";
      }
      else
      {
        this.mNumber = PhoneNumberUtils.calledPartyBCDToString(paramArrayOfByte, i + 1, j);
        this.mExtRecord = (0xFF & paramArrayOfByte[(-1 + paramArrayOfByte.length)]);
        this.mEmails = null;
      }
    }
    catch (RuntimeException localRuntimeException)
    {
      Rlog.w("AdnRecord", "Error parsing AdnRecord", localRuntimeException);
      this.mNumber = "";
      this.mAlphaTag = "";
      this.mEmails = null;
    }
  }

  private static boolean stringCompareNullEqualsEmpty(String paramString1, String paramString2)
  {
    if (paramString1 == paramString2);
    for (boolean bool = true; ; bool = paramString1.equals(paramString2))
    {
      return bool;
      if (paramString1 == null)
        paramString1 = "";
      if (paramString2 == null)
        paramString2 = "";
    }
  }

  public void appendExtRecord(byte[] paramArrayOfByte)
  {
    try
    {
      if ((paramArrayOfByte.length == 13) && ((0x3 & paramArrayOfByte[0]) == 2) && ((0xFF & paramArrayOfByte[1]) <= 10))
        this.mNumber += PhoneNumberUtils.calledPartyBCDFragmentToString(paramArrayOfByte, 2, 0xFF & paramArrayOfByte[1]);
    }
    catch (RuntimeException localRuntimeException)
    {
      Rlog.w("AdnRecord", "Error parsing AdnRecord ext record", localRuntimeException);
    }
  }

  public byte[] buildAdnString(int paramInt)
  {
    int i = paramInt - 14;
    byte[] arrayOfByte1 = new byte[paramInt];
    for (int j = 0; j < paramInt; j++)
      arrayOfByte1[j] = -1;
    if (TextUtils.isEmpty(this.mNumber))
      Rlog.w("AdnRecord", "[buildAdnString] Empty dialing number");
    while (true)
    {
      return arrayOfByte1;
      if (this.mNumber.length() > 20)
      {
        Rlog.w("AdnRecord", "[buildAdnString] Max length of dialing number is 20");
        arrayOfByte1 = null;
      }
      else if ((this.mAlphaTag != null) && (this.mAlphaTag.length() > i))
      {
        Rlog.w("AdnRecord", "[buildAdnString] Max length of tag is " + i);
        arrayOfByte1 = null;
      }
      else
      {
        byte[] arrayOfByte2 = PhoneNumberUtils.numberToCalledPartyBCD(this.mNumber);
        System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i + 1, arrayOfByte2.length);
        arrayOfByte1[(i + 0)] = ((byte)arrayOfByte2.length);
        arrayOfByte1[(i + 12)] = -1;
        arrayOfByte1[(i + 13)] = -1;
        if (!TextUtils.isEmpty(this.mAlphaTag))
          Injector.AdnRecordHook.encodeAlphaTag("AdnRecord", arrayOfByte1, this.mAlphaTag, i);
      }
    }
  }

  public int describeContents()
  {
    return 0;
  }

  public String getAlphaTag()
  {
    return this.mAlphaTag;
  }

  public String[] getEmails()
  {
    return this.mEmails;
  }

  public String getNumber()
  {
    return this.mNumber;
  }

  public boolean hasExtendedRecord()
  {
    if ((this.mExtRecord != 0) && (this.mExtRecord != 255));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isEmpty()
  {
    if ((TextUtils.isEmpty(this.mAlphaTag)) && (TextUtils.isEmpty(this.mNumber)) && (this.mEmails == null));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isEqual(AdnRecord paramAdnRecord)
  {
    if ((stringCompareNullEqualsEmpty(this.mAlphaTag, paramAdnRecord.mAlphaTag)) && (stringCompareNullEqualsEmpty(this.mNumber, paramAdnRecord.mNumber)) && (Arrays.equals(this.mEmails, paramAdnRecord.mEmails)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void setEmails(String[] paramArrayOfString)
  {
    this.mEmails = paramArrayOfString;
  }

  public String toString()
  {
    return "ADN Record '" + this.mAlphaTag + "' '" + this.mNumber + " " + this.mEmails + "'";
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.mEfid);
    paramParcel.writeInt(this.mRecordNumber);
    paramParcel.writeString(this.mAlphaTag);
    paramParcel.writeString(this.mNumber);
    paramParcel.writeStringArray(this.mEmails);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.AdnRecord
 * JD-Core Version:    0.6.2
 */