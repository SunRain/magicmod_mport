package com.android.internal.telephony.uicc;

import android.app.ActivityThread;
import android.app.Application;
import android.content.res.Resources;
import android.provider.Settings.System;
import android.text.TextUtils;

public class MiuiSpnOverrideImpl extends SpnOverride
{
  private static final String SETTING_PREFIX = "MOBILE_OPERATOR_NAME_";
  private final String[] mNumericEquivalencies = Resources.getSystem().getStringArray(101056525);
  private final String[] mNumericValues = Resources.getSystem().getStringArray(101056526);

  private String getFromSettings(String paramString)
  {
    return Settings.System.getString(ActivityThread.currentApplication().getContentResolver(), "MOBILE_OPERATOR_NAME_" + paramString);
  }

  private int getIndex(String paramString)
  {
    int i = 0;
    if (i < this.mNumericValues.length)
      if (!this.mNumericValues[i].equals(paramString));
    while (true)
    {
      return i;
      i++;
      break;
      i = -1;
    }
  }

  public boolean containsCarrier(String paramString)
  {
    if ((getIndex(paramString) >= 0) || (super.containsCarrier(paramString)) || (!TextUtils.isEmpty(getFromSettings(paramString))));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public String getEquivalentOperatorNumeric(String paramString)
  {
    int i = getIndex(paramString);
    if (i >= 0)
      paramString = this.mNumericEquivalencies[i];
    return paramString;
  }

  public String getSpn(String paramString)
  {
    return getSpn(paramString, null);
  }

  public String getSpn(String paramString1, String paramString2)
  {
    String str = getFromSettings(paramString1);
    int i;
    String[] arrayOfString;
    if (TextUtils.isEmpty(str))
    {
      i = getIndex(paramString2);
      if (i == -1)
        i = getIndex(paramString1);
      if (i >= 0)
        arrayOfString = Resources.getSystem().getStringArray(101056524);
    }
    try
    {
      str = arrayOfString[i];
      label54: if (TextUtils.isEmpty(str))
        str = super.getSpn(paramString1);
      return str;
    }
    catch (Exception localException)
    {
      break label54;
    }
  }

  public String getSpnFromConfig(String paramString)
  {
    return super.getSpn(paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.MiuiSpnOverrideImpl
 * JD-Core Version:    0.6.2
 */