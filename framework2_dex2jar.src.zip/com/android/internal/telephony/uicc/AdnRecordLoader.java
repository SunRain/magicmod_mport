package com.android.internal.telephony.uicc;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telephony.Rlog;
import java.util.ArrayList;

public class AdnRecordLoader extends Handler
{
  static final int EVENT_ADN_LOAD_ALL_DONE = 3;
  static final int EVENT_ADN_LOAD_DONE = 1;
  static final int EVENT_EF_LINEAR_RECORD_SIZE_DONE = 4;
  static final int EVENT_EXT_RECORD_LOAD_DONE = 2;
  static final int EVENT_UPDATE_RECORD_DONE = 5;
  static final String LOG_TAG = "AdnRecordLoader";
  static final boolean VDBG;
  ArrayList<AdnRecord> mAdns;
  int mEf;
  int mExtensionEF;
  private IccFileHandler mFh;
  int mPendingExtLoads;
  String mPin2;
  int mRecordNumber;
  Object mResult;
  Message mUserResponse;

  AdnRecordLoader(IccFileHandler paramIccFileHandler)
  {
    super(Looper.getMainLooper());
    this.mFh = paramIccFileHandler;
  }

  public void handleMessage(Message paramMessage)
  {
    ArrayList localArrayList;
    int j;
    int k;
    try
    {
      int i = paramMessage.what;
      switch (i)
      {
      default:
        if ((this.mUserResponse != null) && (this.mPendingExtLoads == 0))
        {
          AsyncResult.forMessage(this.mUserResponse).result = this.mResult;
          this.mUserResponse.sendToTarget();
          this.mUserResponse = null;
        }
        return;
      case 4:
        localAsyncResult5 = (AsyncResult)paramMessage.obj;
        localAdnRecord4 = (AdnRecord)localAsyncResult5.userObj;
        if (localAsyncResult5.exception != null)
          throw new RuntimeException("get EF record size failed", localAsyncResult5.exception);
        break;
      case 5:
      case 1:
      case 2:
      case 3:
      }
    }
    catch (RuntimeException localRuntimeException)
    {
      while (true)
      {
        AsyncResult localAsyncResult5;
        AdnRecord localAdnRecord4;
        if (this.mUserResponse != null)
        {
          AsyncResult.forMessage(this.mUserResponse).exception = localRuntimeException;
          this.mUserResponse.sendToTarget();
          this.mUserResponse = null;
          continue;
          int[] arrayOfInt = (int[])localAsyncResult5.result;
          if ((arrayOfInt.length != 3) || (this.mRecordNumber > arrayOfInt[2]))
            throw new RuntimeException("get wrong EF record size format", localAsyncResult5.exception);
          byte[] arrayOfByte3 = localAdnRecord4.buildAdnString(arrayOfInt[0]);
          if (arrayOfByte3 == null)
            throw new RuntimeException("wrong ADN format", localAsyncResult5.exception);
          this.mFh.updateEFLinearFixed(this.mEf, this.mRecordNumber, arrayOfByte3, this.mPin2, obtainMessage(5));
          this.mPendingExtLoads = 1;
          continue;
          AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
          if (localAsyncResult4.exception != null)
            throw new RuntimeException("update EF adn record failed", localAsyncResult4.exception);
          this.mPendingExtLoads = 0;
          this.mResult = null;
          continue;
          AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
          byte[] arrayOfByte2 = (byte[])localAsyncResult3.result;
          if (localAsyncResult3.exception != null)
            throw new RuntimeException("load failed", localAsyncResult3.exception);
          AdnRecord localAdnRecord3 = new AdnRecord(this.mEf, this.mRecordNumber, arrayOfByte2);
          this.mResult = localAdnRecord3;
          if (localAdnRecord3.hasExtendedRecord())
          {
            this.mPendingExtLoads = 1;
            this.mFh.loadEFLinearFixed(this.mExtensionEF, localAdnRecord3.mExtRecord, obtainMessage(2, localAdnRecord3));
            continue;
            AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
            byte[] arrayOfByte1 = (byte[])localAsyncResult2.result;
            AdnRecord localAdnRecord2 = (AdnRecord)localAsyncResult2.userObj;
            if (localAsyncResult2.exception != null)
              throw new RuntimeException("load failed", localAsyncResult2.exception);
            Rlog.d("AdnRecordLoader", "ADN extension EF: 0x" + Integer.toHexString(this.mExtensionEF) + ":" + localAdnRecord2.mExtRecord + "\n" + IccUtils.bytesToHexString(arrayOfByte1));
            localAdnRecord2.appendExtRecord(arrayOfByte1);
            this.mPendingExtLoads = (-1 + this.mPendingExtLoads);
          }
        }
      }
      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
      localArrayList = (ArrayList)localAsyncResult1.result;
      if (localAsyncResult1.exception != null)
        throw new RuntimeException("load failed", localAsyncResult1.exception);
      this.mAdns = new ArrayList(localArrayList.size());
      this.mResult = this.mAdns;
      this.mPendingExtLoads = 0;
      j = 0;
      k = localArrayList.size();
    }
    while (j < k)
    {
      AdnRecord localAdnRecord1 = new AdnRecord(this.mEf, j + 1, (byte[])localArrayList.get(j));
      this.mAdns.add(localAdnRecord1);
      if (localAdnRecord1.hasExtendedRecord())
      {
        this.mPendingExtLoads = (1 + this.mPendingExtLoads);
        this.mFh.loadEFLinearFixed(this.mExtensionEF, localAdnRecord1.mExtRecord, obtainMessage(2, localAdnRecord1));
      }
      j++;
    }
  }

  public void loadAllFromEF(int paramInt1, int paramInt2, Message paramMessage)
  {
    this.mEf = paramInt1;
    this.mExtensionEF = paramInt2;
    this.mUserResponse = paramMessage;
    this.mFh.loadEFLinearFixedAll(paramInt1, obtainMessage(3));
  }

  public void loadFromEF(int paramInt1, int paramInt2, int paramInt3, Message paramMessage)
  {
    this.mEf = paramInt1;
    this.mExtensionEF = paramInt2;
    this.mRecordNumber = paramInt3;
    this.mUserResponse = paramMessage;
    this.mFh.loadEFLinearFixed(paramInt1, paramInt3, obtainMessage(1));
  }

  public void updateEF(AdnRecord paramAdnRecord, int paramInt1, int paramInt2, int paramInt3, String paramString, Message paramMessage)
  {
    this.mEf = paramInt1;
    this.mExtensionEF = paramInt2;
    this.mRecordNumber = paramInt3;
    this.mUserResponse = paramMessage;
    this.mPin2 = paramString;
    this.mFh.getEFLinearRecordSize(paramInt1, obtainMessage(4, paramAdnRecord));
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.AdnRecordLoader
 * JD-Core Version:    0.6.2
 */