package com.android.internal.telephony.uicc;

public final class IccVmNotSupportedException extends IccException
{
  IccVmNotSupportedException()
  {
  }

  public IccVmNotSupportedException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IccVmNotSupportedException
 * JD-Core Version:    0.6.2
 */