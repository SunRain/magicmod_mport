package com.android.internal.telephony.uicc;

import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;

public final class IsimFileHandler extends IccFileHandler
  implements IccConstants
{
  static final String LOG_TAG = "IsimFH";

  public IsimFileHandler(UiccCardApplication paramUiccCardApplication, String paramString, CommandsInterface paramCommandsInterface)
  {
    super(paramUiccCardApplication, paramString, paramCommandsInterface);
  }

  protected String getEFPath(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 28418:
    case 28419:
    case 28420:
    }
    for (String str = getCommonIccEFPath(paramInt); ; str = "3F007FFF")
      return str;
  }

  protected void logd(String paramString)
  {
    Rlog.d("IsimFH", paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("IsimFH", paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.IsimFileHandler
 * JD-Core Version:    0.6.2
 */