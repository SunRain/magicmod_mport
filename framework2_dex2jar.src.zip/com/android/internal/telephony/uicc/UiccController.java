package com.android.internal.telephony.uicc;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Registrant;
import android.os.RegistrantList;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class UiccController extends Handler
{
  public static final int APP_FAM_3GPP = 1;
  public static final int APP_FAM_3GPP2 = 2;
  public static final int APP_FAM_IMS = 3;
  private static final boolean DBG = true;
  private static final int EVENT_GET_ICC_STATUS_DONE = 2;
  private static final int EVENT_ICC_STATUS_CHANGED = 1;
  private static final String LOG_TAG = "UiccController";
  private static UiccController mInstance;
  private static final Object mLock = new Object();
  private CommandsInterface mCi;
  private Context mContext;
  private RegistrantList mIccChangedRegistrants = new RegistrantList();
  private UiccCard mUiccCard;

  private UiccController(Context paramContext, CommandsInterface paramCommandsInterface)
  {
    log("Creating UiccController");
    this.mContext = paramContext;
    this.mCi = paramCommandsInterface;
    this.mCi.registerForIccStatusChanged(this, 1, null);
    this.mCi.registerForOn(this, 1, null);
  }

  // ERROR //
  public static UiccController getInstance()
  {
    // Byte code:
    //   0: getstatic 40	com/android/internal/telephony/uicc/UiccController:mLock	Ljava/lang/Object;
    //   3: astore_0
    //   4: aload_0
    //   5: monitorenter
    //   6: getstatic 70	com/android/internal/telephony/uicc/UiccController:mInstance	Lcom/android/internal/telephony/uicc/UiccController;
    //   9: ifnonnull +18 -> 27
    //   12: new 72	java/lang/RuntimeException
    //   15: dup
    //   16: ldc 74
    //   18: invokespecial 76	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   21: athrow
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    //   27: getstatic 70	com/android/internal/telephony/uicc/UiccController:mInstance	Lcom/android/internal/telephony/uicc/UiccController;
    //   30: astore_2
    //   31: aload_0
    //   32: monitorexit
    //   33: aload_2
    //   34: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   6	25	22	finally
    //   27	33	22	finally
  }

  private void log(String paramString)
  {
    Rlog.d("UiccController", paramString);
  }

  // ERROR //
  public static UiccController make(Context paramContext, CommandsInterface paramCommandsInterface)
  {
    // Byte code:
    //   0: getstatic 40	com/android/internal/telephony/uicc/UiccController:mLock	Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: getstatic 70	com/android/internal/telephony/uicc/UiccController:mInstance	Lcom/android/internal/telephony/uicc/UiccController;
    //   9: ifnull +18 -> 27
    //   12: new 72	java/lang/RuntimeException
    //   15: dup
    //   16: ldc 86
    //   18: invokespecial 76	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   21: athrow
    //   22: astore_3
    //   23: aload_2
    //   24: monitorexit
    //   25: aload_3
    //   26: athrow
    //   27: new 2	com/android/internal/telephony/uicc/UiccController
    //   30: dup
    //   31: aload_0
    //   32: aload_1
    //   33: invokespecial 88	com/android/internal/telephony/uicc/UiccController:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/CommandsInterface;)V
    //   36: putstatic 70	com/android/internal/telephony/uicc/UiccController:mInstance	Lcom/android/internal/telephony/uicc/UiccController;
    //   39: getstatic 70	com/android/internal/telephony/uicc/UiccController:mInstance	Lcom/android/internal/telephony/uicc/UiccController;
    //   42: astore 4
    //   44: aload_2
    //   45: monitorexit
    //   46: aload 4
    //   48: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   6	25	22	finally
    //   27	46	22	finally
  }

  private void onGetIccCardStatusDone(AsyncResult paramAsyncResult)
  {
    while (true)
    {
      IccCardStatus localIccCardStatus;
      try
      {
        if (paramAsyncResult.exception != null)
        {
          Rlog.e("UiccController", "Error getting ICC status. RIL_REQUEST_GET_ICC_STATUS should never return an error", paramAsyncResult.exception);
          return;
        }
        localIccCardStatus = (IccCardStatus)paramAsyncResult.result;
        if (this.mUiccCard == null)
        {
          this.mUiccCard = new UiccCard(this.mContext, this.mCi, localIccCardStatus);
          log("Notifying IccChangedRegistrants");
          this.mIccChangedRegistrants.notifyRegistrants();
          continue;
        }
      }
      finally
      {
      }
      this.mUiccCard.update(this.mContext, this.mCi, localIccCardStatus);
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("UiccController: " + this);
    paramPrintWriter.println(" mContext=" + this.mContext);
    paramPrintWriter.println(" mInstance=" + mInstance);
    paramPrintWriter.println(" mCi=" + this.mCi);
    paramPrintWriter.println(" mUiccCard=" + this.mUiccCard);
    paramPrintWriter.println(" mIccChangedRegistrants: size=" + this.mIccChangedRegistrants.size());
    for (int i = 0; i < this.mIccChangedRegistrants.size(); i++)
      paramPrintWriter.println("  mIccChangedRegistrants[" + i + "]=" + ((Registrant)this.mIccChangedRegistrants.get(i)).getHandler());
    paramPrintWriter.println();
    paramPrintWriter.flush();
    if (this.mUiccCard != null)
      this.mUiccCard.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }

  public IccFileHandler getIccFileHandler(int paramInt)
  {
    IccFileHandler localIccFileHandler;
    synchronized (mLock)
    {
      if (this.mUiccCard != null)
      {
        UiccCardApplication localUiccCardApplication = this.mUiccCard.getApplication(paramInt);
        if (localUiccCardApplication != null)
        {
          localIccFileHandler = localUiccCardApplication.getIccFileHandler();
          break label53;
        }
      }
      localIccFileHandler = null;
    }
    label53: return localIccFileHandler;
  }

  public IccRecords getIccRecords(int paramInt)
  {
    IccRecords localIccRecords;
    synchronized (mLock)
    {
      if (this.mUiccCard != null)
      {
        UiccCardApplication localUiccCardApplication = this.mUiccCard.getApplication(paramInt);
        if (localUiccCardApplication != null)
        {
          localIccRecords = localUiccCardApplication.getIccRecords();
          break label53;
        }
      }
      localIccRecords = null;
    }
    label53: return localIccRecords;
  }

  public UiccCard getUiccCard()
  {
    synchronized (mLock)
    {
      UiccCard localUiccCard = this.mUiccCard;
      return localUiccCard;
    }
  }

  public UiccCardApplication getUiccCardApplication(int paramInt)
  {
    UiccCardApplication localUiccCardApplication;
    synchronized (mLock)
    {
      if (this.mUiccCard != null)
        localUiccCardApplication = this.mUiccCard.getApplication(paramInt);
      else
        localUiccCardApplication = null;
    }
    return localUiccCardApplication;
  }

  // ERROR //
  public void handleMessage(android.os.Message paramMessage)
  {
    // Byte code:
    //   0: getstatic 40	com/android/internal/telephony/uicc/UiccController:mLock	Ljava/lang/Object;
    //   3: astore_2
    //   4: aload_2
    //   5: monitorenter
    //   6: aload_1
    //   7: getfield 209	android/os/Message:what	I
    //   10: tableswitch	default:+22 -> 32, 1:+53->63, 2:+81->91
    //   33: ldc_w -17664
    //   36: iand
    //   37: dup
    //   38: invokespecial 127	java/lang/StringBuilder:<init>	()V
    //   41: ldc 211
    //   43: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: aload_1
    //   47: getfield 209	android/os/Message:what	I
    //   50: invokevirtual 162	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   53: invokevirtual 140	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   56: invokestatic 213	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   59: pop
    //   60: aload_2
    //   61: monitorexit
    //   62: return
    //   63: aload_0
    //   64: ldc 215
    //   66: invokespecial 53	com/android/internal/telephony/uicc/UiccController:log	(Ljava/lang/String;)V
    //   69: aload_0
    //   70: getfield 57	com/android/internal/telephony/uicc/UiccController:mCi	Lcom/android/internal/telephony/CommandsInterface;
    //   73: aload_0
    //   74: iconst_2
    //   75: invokevirtual 219	com/android/internal/telephony/uicc/UiccController:obtainMessage	(I)Landroid/os/Message;
    //   78: invokeinterface 222 2 0
    //   83: goto -23 -> 60
    //   86: astore_3
    //   87: aload_2
    //   88: monitorexit
    //   89: aload_3
    //   90: athrow
    //   91: aload_0
    //   92: ldc 224
    //   94: invokespecial 53	com/android/internal/telephony/uicc/UiccController:log	(Ljava/lang/String;)V
    //   97: aload_0
    //   98: aload_1
    //   99: getfield 227	android/os/Message:obj	Ljava/lang/Object;
    //   102: checkcast 92	android/os/AsyncResult
    //   105: invokespecial 229	com/android/internal/telephony/uicc/UiccController:onGetIccCardStatusDone	(Landroid/os/AsyncResult;)V
    //   108: goto -48 -> 60
    //
    // Exception table:
    //   from	to	target	type
    //   6	89	86	finally
    //   91	108	86	finally
  }

  public void registerForIccChanged(Handler paramHandler, int paramInt, Object paramObject)
  {
    synchronized (mLock)
    {
      Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
      this.mIccChangedRegistrants.add(localRegistrant);
      localRegistrant.notifyRegistrant();
      return;
    }
  }

  public void unregisterForIccChanged(Handler paramHandler)
  {
    synchronized (mLock)
    {
      this.mIccChangedRegistrants.remove(paramHandler);
      return;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.UiccController
 * JD-Core Version:    0.6.2
 */