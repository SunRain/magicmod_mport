package com.android.internal.telephony.uicc;

import android.os.Environment;
import android.telephony.Rlog;
import android.util.Xml;
import com.android.internal.util.XmlUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class SpnOverride
{
  static final String LOG_TAG = "SpnOverride";
  static final String PARTNER_SPN_OVERRIDE_PATH = "etc/spn-conf.xml";
  private HashMap<String, String> mCarrierSpnMap = new HashMap();

  SpnOverride()
  {
    loadSpnOverrides();
  }

  private void loadSpnOverrides()
  {
    File localFile = new File(Environment.getRootDirectory(), "etc/spn-conf.xml");
    try
    {
      localFileReader = new FileReader(localFile);
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      try
      {
        FileReader localFileReader;
        XmlPullParser localXmlPullParser = Xml.newPullParser();
        localXmlPullParser.setInput(localFileReader);
        XmlUtils.beginDocument(localXmlPullParser, "spnOverrides");
        while (true)
        {
          XmlUtils.nextElement(localXmlPullParser);
          boolean bool = "spnOverride".equals(localXmlPullParser.getName());
          if (!bool)
          {
            Injector.closeSpnReader(localFileReader);
            while (true)
            {
              return;
              localFileNotFoundException = localFileNotFoundException;
              Rlog.w("SpnOverride", "Can not open " + Environment.getRootDirectory() + "/" + "etc/spn-conf.xml");
            }
          }
          String str1 = localXmlPullParser.getAttributeValue(null, "numeric");
          String str2 = localXmlPullParser.getAttributeValue(null, "spn");
          this.mCarrierSpnMap.put(str1, str2);
        }
      }
      catch (XmlPullParserException localXmlPullParserException)
      {
        while (true)
          Rlog.w("SpnOverride", "Exception in spn-conf parser " + localXmlPullParserException);
      }
      catch (IOException localIOException)
      {
        while (true)
          Rlog.w("SpnOverride", "Exception in spn-conf parser " + localIOException);
      }
    }
  }

  boolean containsCarrier(String paramString)
  {
    return this.mCarrierSpnMap.containsKey(paramString);
  }

  String getSpn(String paramString)
  {
    return (String)this.mCarrierSpnMap.get(paramString);
  }

  public String getSpn(String paramString1, String paramString2)
  {
    return getSpn(paramString1);
  }

  static class Injector
  {
    static void closeSpnReader(FileReader paramFileReader)
    {
      if (paramFileReader != null);
      try
      {
        paramFileReader.close();
        label8: return;
      }
      catch (IOException localIOException)
      {
        break label8;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.SpnOverride
 * JD-Core Version:    0.6.2
 */