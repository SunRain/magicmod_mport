package com.android.internal.telephony.uicc;

import java.util.HashMap;

class VoiceMailConstants
{
  static final String LOG_TAG = "VoiceMailConstants";
  static final int NAME = 0;
  static final int NUMBER = 1;
  static final String PARTNER_VOICEMAIL_PATH = "etc/voicemail-conf.xml";
  static final int SIZE = 3;
  static final int TAG = 2;
  private HashMap<String, String[]> CarrierVmMap = new HashMap();

  VoiceMailConstants()
  {
    loadVoiceMail();
  }

  // ERROR //
  private void loadVoiceMail()
  {
    // Byte code:
    //   0: new 43	java/io/File
    //   3: dup
    //   4: invokestatic 49	android/os/Environment:getRootDirectory	()Ljava/io/File;
    //   7: ldc 16
    //   9: invokespecial 52	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   12: astore_1
    //   13: new 54	java/io/FileReader
    //   16: dup
    //   17: aload_1
    //   18: invokespecial 57	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   21: astore_2
    //   22: invokestatic 63	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   25: astore 10
    //   27: aload 10
    //   29: aload_2
    //   30: invokeinterface 69 2 0
    //   35: aload 10
    //   37: ldc 71
    //   39: invokestatic 77	com/android/internal/util/XmlUtils:beginDocument	(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)V
    //   42: aload 10
    //   44: invokestatic 81	com/android/internal/util/XmlUtils:nextElement	(Lorg/xmlpull/v1/XmlPullParser;)V
    //   47: ldc 71
    //   49: aload 10
    //   51: invokeinterface 85 1 0
    //   56: invokevirtual 91	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   59: istore 11
    //   61: iload 11
    //   63: ifne +54 -> 117
    //   66: aload_2
    //   67: ifnull +7 -> 74
    //   70: aload_2
    //   71: invokevirtual 94	java/io/FileReader:close	()V
    //   74: return
    //   75: astore 15
    //   77: ldc 8
    //   79: new 96	java/lang/StringBuilder
    //   82: dup
    //   83: invokespecial 97	java/lang/StringBuilder:<init>	()V
    //   86: ldc 99
    //   88: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: invokestatic 49	android/os/Environment:getRootDirectory	()Ljava/io/File;
    //   94: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   97: ldc 108
    //   99: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: ldc 16
    //   104: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: invokevirtual 111	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   110: invokestatic 117	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   113: pop
    //   114: goto -40 -> 74
    //   117: iconst_3
    //   118: anewarray 87	java/lang/String
    //   121: astore 12
    //   123: aload 10
    //   125: aconst_null
    //   126: ldc 119
    //   128: invokeinterface 123 3 0
    //   133: astore 13
    //   135: aload 12
    //   137: iconst_0
    //   138: aload 10
    //   140: aconst_null
    //   141: ldc 125
    //   143: invokeinterface 123 3 0
    //   148: aastore
    //   149: aload 12
    //   151: iconst_1
    //   152: aload 10
    //   154: aconst_null
    //   155: ldc 127
    //   157: invokeinterface 123 3 0
    //   162: aastore
    //   163: aload 12
    //   165: iconst_2
    //   166: aload 10
    //   168: aconst_null
    //   169: ldc 129
    //   171: invokeinterface 123 3 0
    //   176: aastore
    //   177: aload_0
    //   178: getfield 32	com/android/internal/telephony/uicc/VoiceMailConstants:CarrierVmMap	Ljava/util/HashMap;
    //   181: aload 13
    //   183: aload 12
    //   185: invokevirtual 133	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   188: pop
    //   189: goto -147 -> 42
    //   192: astore 8
    //   194: ldc 8
    //   196: new 96	java/lang/StringBuilder
    //   199: dup
    //   200: invokespecial 97	java/lang/StringBuilder:<init>	()V
    //   203: ldc 135
    //   205: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload 8
    //   210: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   213: invokevirtual 111	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   216: invokestatic 117	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   219: pop
    //   220: aload_2
    //   221: ifnull -147 -> 74
    //   224: aload_2
    //   225: invokevirtual 94	java/io/FileReader:close	()V
    //   228: goto -154 -> 74
    //   231: astore 7
    //   233: goto -159 -> 74
    //   236: astore 5
    //   238: ldc 8
    //   240: new 96	java/lang/StringBuilder
    //   243: dup
    //   244: invokespecial 97	java/lang/StringBuilder:<init>	()V
    //   247: ldc 135
    //   249: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: aload 5
    //   254: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   257: invokevirtual 111	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   260: invokestatic 117	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   263: pop
    //   264: aload_2
    //   265: ifnull -191 -> 74
    //   268: aload_2
    //   269: invokevirtual 94	java/io/FileReader:close	()V
    //   272: goto -198 -> 74
    //   275: astore_3
    //   276: aload_2
    //   277: ifnull +7 -> 284
    //   280: aload_2
    //   281: invokevirtual 94	java/io/FileReader:close	()V
    //   284: aload_3
    //   285: athrow
    //   286: astore 4
    //   288: goto -4 -> 284
    //
    // Exception table:
    //   from	to	target	type
    //   13	22	75	java/io/FileNotFoundException
    //   22	61	192	org/xmlpull/v1/XmlPullParserException
    //   117	189	192	org/xmlpull/v1/XmlPullParserException
    //   70	74	231	java/io/IOException
    //   224	228	231	java/io/IOException
    //   268	272	231	java/io/IOException
    //   22	61	236	java/io/IOException
    //   117	189	236	java/io/IOException
    //   22	61	275	finally
    //   117	189	275	finally
    //   194	220	275	finally
    //   238	264	275	finally
    //   280	284	286	java/io/IOException
  }

  boolean containsCarrier(String paramString)
  {
    return this.CarrierVmMap.containsKey(paramString);
  }

  String getCarrierName(String paramString)
  {
    return ((String[])this.CarrierVmMap.get(paramString))[0];
  }

  String getVoiceMailNumber(String paramString)
  {
    return ((String[])this.CarrierVmMap.get(paramString))[1];
  }

  String getVoiceMailTag(String paramString)
  {
    return ((String[])this.CarrierVmMap.get(paramString))[2];
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.uicc.VoiceMailConstants
 * JD-Core Version:    0.6.2
 */