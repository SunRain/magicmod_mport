package com.android.internal.telephony;

import com.android.internal.telephony.uicc.AdnRecord;
import com.android.internal.telephony.uicc.MiuiAdnRecord;
import java.util.List;

public class MiuiIccPhoneBookInterfaceManagerProxy extends IccPhoneBookInterfaceManagerProxy
{
  public MiuiIccPhoneBookInterfaceManagerProxy(IccPhoneBookInterfaceManager paramIccPhoneBookInterfaceManager)
  {
    super(paramIccPhoneBookInterfaceManager);
  }

  public int getAdnCapacity()
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).getAdnCapacity();
  }

  public List<AdnRecord> getAdnRecordsInEf(int paramInt)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).getAdnRecordsInEf(paramInt);
  }

  public int[] getAdnRecordsSize(int paramInt)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).getAdnRecordsSize(paramInt);
  }

  public int getFreeAdn()
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).getFreeAdn();
  }

  public int getLastError()
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).getLastError();
  }

  public boolean isPhoneBookReady()
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).isPhoneBookReady();
  }

  public boolean isUsimPhoneBookRecords()
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).isUsimPhoneBookRecords();
  }

  public boolean updateAdnRecordsInEfByIndex(int paramInt1, String paramString1, String paramString2, int paramInt2, String paramString3)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateAdnRecordsInEfByIndex(paramInt1, paramString1, paramString2, paramInt2, paramString3);
  }

  public boolean updateAdnRecordsInEfBySearch(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateAdnRecordsInEfBySearch(paramInt, paramString1, paramString2, paramString3, paramString4, paramString5);
  }

  public boolean updateUsimPhoneBookRecordsByIndex(int paramInt1, MiuiAdnRecord paramMiuiAdnRecord, int paramInt2)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateUsimPhoneBookRecordsByIndex(paramInt1, paramMiuiAdnRecord, paramInt2);
  }

  public boolean updateUsimPhoneBookRecordsBySearch(int paramInt, MiuiAdnRecord paramMiuiAdnRecord1, MiuiAdnRecord paramMiuiAdnRecord2)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateUsimPhoneBookRecordsBySearch(paramInt, paramMiuiAdnRecord1, paramMiuiAdnRecord2);
  }

  public boolean updateUsimPhoneBookRecordsInEfByIndex(int paramInt1, String paramString1, String paramString2, String[] paramArrayOfString, String paramString3, int paramInt2)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateUsimPhoneBookRecordsInEfByIndex(paramInt1, paramString1, paramString2, paramArrayOfString, paramString3, paramInt2);
  }

  public boolean updateUsimPhoneBookRecordsInEfBySearch(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String[] paramArrayOfString, String paramString5)
  {
    return ((MiuiIccPhoneBookInterfaceManager)getIccPhoneBookInterfaceManager()).updateUsimPhoneBookRecordsInEfBySearch(paramInt, paramString1, paramString2, paramString3, paramString4, paramArrayOfString, paramString5);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.MiuiIccPhoneBookInterfaceManagerProxy
 * JD-Core Version:    0.6.2
 */