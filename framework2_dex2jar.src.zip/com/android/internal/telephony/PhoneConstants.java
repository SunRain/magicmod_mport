package com.android.internal.telephony;

public class PhoneConstants
{
  public static final int APN_ALREADY_ACTIVE = 0;
  public static final int APN_ALREADY_INACTIVE = 4;
  public static final int APN_REQUEST_FAILED = 3;
  public static final int APN_REQUEST_STARTED = 1;
  public static final String APN_TYPE_ALL = "*";
  public static final String APN_TYPE_CBS = "cbs";
  public static final String APN_TYPE_DEFAULT = "default";
  public static final String APN_TYPE_DUN = "dun";
  public static final String APN_TYPE_FOTA = "fota";
  public static final String APN_TYPE_HIPRI = "hipri";
  public static final String APN_TYPE_IA = "ia";
  public static final String APN_TYPE_IMS = "ims";
  public static final String APN_TYPE_MMS = "mms";
  public static final int APN_TYPE_NOT_AVAILABLE = 2;
  public static final String APN_TYPE_SUPL = "supl";
  public static final String DATA_APN_KEY = "apn";
  public static final String DATA_APN_TYPE_KEY = "apnType";
  public static final String DATA_IFACE_NAME_KEY = "iface";
  public static final String DATA_LINK_CAPABILITIES_KEY = "linkCapabilities";
  public static final String DATA_LINK_PROPERTIES_KEY = "linkProperties";
  public static final String DATA_NETWORK_ROAMING_KEY = "networkRoaming";
  public static final String FAILURE_REASON_KEY = "reason";
  public static final int LTE_ON_CDMA_FALSE = 0;
  public static final int LTE_ON_CDMA_TRUE = 1;
  public static final int LTE_ON_CDMA_UNKNOWN = -1;
  public static final String NETWORK_UNAVAILABLE_KEY = "networkUnvailable";
  public static final String PHONE_IN_ECM_STATE = "phoneinECMState";
  public static final String PHONE_NAME_KEY = "phoneName";
  public static final int PHONE_TYPE_CDMA = 2;
  public static final int PHONE_TYPE_GSM = 1;
  public static final int PHONE_TYPE_NONE = 0;
  public static final int PHONE_TYPE_SIP = 3;
  public static final int PIN_GENERAL_FAILURE = 2;
  public static final int PIN_PASSWORD_INCORRECT = 1;
  public static final int PIN_RESULT_SUCCESS = 0;
  public static int PRESENTATION_ALLOWED = 0;
  public static int PRESENTATION_PAYPHONE = 0;
  public static int PRESENTATION_RESTRICTED = 0;
  public static int PRESENTATION_UNKNOWN = 0;
  public static final String REASON_LINK_PROPERTIES_CHANGED = "linkPropertiesChanged";
  public static final String STATE_CHANGE_REASON_KEY = "reason";
  public static final String STATE_KEY = "state";

  public static enum DataState
  {
    static
    {
      DataState[] arrayOfDataState = new DataState[4];
      arrayOfDataState[0] = CONNECTED;
      arrayOfDataState[1] = CONNECTING;
      arrayOfDataState[2] = DISCONNECTED;
      arrayOfDataState[3] = SUSPENDED;
    }
  }

  public static enum State
  {
    static
    {
      OFFHOOK = new State("OFFHOOK", 2);
      State[] arrayOfState = new State[3];
      arrayOfState[0] = IDLE;
      arrayOfState[1] = RINGING;
      arrayOfState[2] = OFFHOOK;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.PhoneConstants
 * JD-Core Version:    0.6.2
 */