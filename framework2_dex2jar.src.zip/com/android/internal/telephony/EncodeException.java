package com.android.internal.telephony;

public class EncodeException extends Exception
{
  public EncodeException()
  {
  }

  public EncodeException(char paramChar)
  {
    super("Unencodable char: '" + paramChar + "'");
  }

  public EncodeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.EncodeException
 * JD-Core Version:    0.6.2
 */