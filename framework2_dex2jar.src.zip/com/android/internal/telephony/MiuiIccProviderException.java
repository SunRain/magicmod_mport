package com.android.internal.telephony;

public class MiuiIccProviderException extends RuntimeException
{
  private static final long serialVersionUID = 1L;
  private int mError;

  public MiuiIccProviderException(int paramInt)
  {
    this.mError = paramInt;
  }

  public static int getErrorCauseFromException(Throwable paramThrowable)
  {
    int i = 0;
    if (paramThrowable != null)
    {
      if (!(paramThrowable instanceof CommandException))
        break label76;
      CommandException localCommandException = (CommandException)paramThrowable;
      switch (1.$SwitchMap$com$android$internal$telephony$CommandException$Error[localCommandException.getCommandError().ordinal()])
      {
      default:
        i = -1001;
      case 1:
      case 2:
      case 3:
      }
    }
    while (true)
    {
      return i;
      i = -1002;
      continue;
      i = -1007;
      continue;
      label76: if ((paramThrowable instanceof MiuiIccProviderException))
        i = ((MiuiIccProviderException)paramThrowable).getError();
    }
  }

  int getError()
  {
    return this.mError;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.MiuiIccProviderException
 * JD-Core Version:    0.6.2
 */