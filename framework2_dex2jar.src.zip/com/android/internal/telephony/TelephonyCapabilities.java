package com.android.internal.telephony;

import android.telephony.Rlog;

public class TelephonyCapabilities
{
  private static final String LOG_TAG = "TelephonyCapabilities";

  public static boolean canDistinguishDialingAndConnected(int paramInt)
  {
    int i = 1;
    if (paramInt == i);
    while (true)
    {
      return i;
      i = 0;
    }
  }

  public static int getDeviceIdLabel(Phone paramPhone)
  {
    int i;
    if (paramPhone.getPhoneType() == 1)
      i = 17039458;
    while (true)
    {
      return i;
      if (paramPhone.getPhoneType() == 2)
      {
        i = 17039459;
      }
      else
      {
        Rlog.w("TelephonyCapabilities", "getDeviceIdLabel: no known label for phone " + paramPhone.getPhoneName());
        i = 0;
      }
    }
  }

  public static boolean supportsAdn(int paramInt)
  {
    int i = 1;
    if (paramInt == i);
    while (true)
    {
      return i;
      i = 0;
    }
  }

  public static boolean supportsAnswerAndHold(Phone paramPhone)
  {
    int i = 1;
    if ((paramPhone.getPhoneType() == i) || (paramPhone.getPhoneType() == 3));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public static boolean supportsConferenceCallManagement(Phone paramPhone)
  {
    int i = 1;
    if ((paramPhone.getPhoneType() == i) || (paramPhone.getPhoneType() == 3));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public static boolean supportsEcm(Phone paramPhone)
  {
    if (paramPhone.getPhoneType() == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean supportsHoldAndUnhold(Phone paramPhone)
  {
    int i = 1;
    if ((paramPhone.getPhoneType() == i) || (paramPhone.getPhoneType() == 3));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public static boolean supportsNetworkSelection(Phone paramPhone)
  {
    int i = 1;
    if (paramPhone.getPhoneType() == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public static boolean supportsOtasp(Phone paramPhone)
  {
    if (paramPhone.getPhoneType() == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public static boolean supportsVoiceMessageCount(Phone paramPhone)
  {
    if (paramPhone.getPhoneType() == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.TelephonyCapabilities
 * JD-Core Version:    0.6.2
 */