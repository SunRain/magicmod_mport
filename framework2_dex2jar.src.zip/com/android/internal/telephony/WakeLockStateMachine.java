package com.android.internal.telephony;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.telephony.Rlog;
import com.android.internal.util.State;
import com.android.internal.util.StateMachine;

public abstract class WakeLockStateMachine extends StateMachine
{
  protected static final boolean DBG = true;
  protected static final int EVENT_BROADCAST_COMPLETE = 2;
  public static final int EVENT_NEW_SMS_MESSAGE = 1;
  static final int EVENT_RELEASE_WAKE_LOCK = 3;
  static final int EVENT_UPDATE_PHONE_OBJECT = 4;
  private static final int WAKE_LOCK_TIMEOUT = 3000;
  protected Context mContext;
  private final DefaultState mDefaultState = new DefaultState();
  private final IdleState mIdleState = new IdleState();
  protected PhoneBase mPhone;
  protected final BroadcastReceiver mReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      WakeLockStateMachine.this.sendMessage(2);
    }
  };
  private final WaitingState mWaitingState = new WaitingState();
  private final PowerManager.WakeLock mWakeLock;

  protected WakeLockStateMachine(String paramString, Context paramContext, PhoneBase paramPhoneBase)
  {
    super(paramString);
    this.mContext = paramContext;
    this.mPhone = paramPhoneBase;
    this.mWakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, paramString);
    this.mWakeLock.acquire();
    addState(this.mDefaultState);
    addState(this.mIdleState, this.mDefaultState);
    addState(this.mWaitingState, this.mDefaultState);
    setInitialState(this.mIdleState);
  }

  public final void dispatchSmsMessage(Object paramObject)
  {
    sendMessage(1, paramObject);
  }

  public final void dispose()
  {
    quit();
  }

  protected abstract boolean handleSmsMessage(Message paramMessage);

  protected void log(String paramString)
  {
    Rlog.d(getName(), paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e(getName(), paramString);
  }

  protected void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e(getName(), paramString, paramThrowable);
  }

  protected void onQuitting()
  {
    while (this.mWakeLock.isHeld())
      this.mWakeLock.release();
  }

  public void updatePhoneObject(PhoneBase paramPhoneBase)
  {
    sendMessage(4, paramPhoneBase);
  }

  class DefaultState extends State
  {
    DefaultState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      String str;
      switch (paramMessage.what)
      {
      default:
        str = "processMessage: unhandled message type " + paramMessage.what;
        if (Build.IS_DEBUGGABLE)
          throw new RuntimeException(str);
        break;
      case 4:
        WakeLockStateMachine.this.mPhone = ((PhoneBase)paramMessage.obj);
        WakeLockStateMachine.this.log("updatePhoneObject: phone=" + WakeLockStateMachine.this.mPhone.getClass().getSimpleName());
      }
      while (true)
      {
        return true;
        WakeLockStateMachine.this.loge(str);
      }
    }
  }

  class IdleState extends State
  {
    IdleState()
    {
    }

    public void enter()
    {
      WakeLockStateMachine.this.sendMessageDelayed(3, 3000L);
    }

    public void exit()
    {
      WakeLockStateMachine.this.mWakeLock.acquire();
      WakeLockStateMachine.this.log("acquired wakelock, leaving Idle state");
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool = true;
      switch (paramMessage.what)
      {
      case 2:
      default:
        bool = false;
      case 1:
      case 3:
      }
      while (true)
      {
        return bool;
        if (WakeLockStateMachine.this.handleSmsMessage(paramMessage))
        {
          WakeLockStateMachine.this.transitionTo(WakeLockStateMachine.this.mWaitingState);
          continue;
          WakeLockStateMachine.this.mWakeLock.release();
          if (WakeLockStateMachine.this.mWakeLock.isHeld())
            WakeLockStateMachine.this.log("mWakeLock is still held after release");
          else
            WakeLockStateMachine.this.log("mWakeLock released");
        }
      }
    }
  }

  class WaitingState extends State
  {
    WaitingState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool = true;
      switch (paramMessage.what)
      {
      default:
        bool = false;
      case 1:
      case 2:
      case 3:
      }
      while (true)
      {
        return bool;
        WakeLockStateMachine.this.log("deferring message until return to idle");
        WakeLockStateMachine.this.deferMessage(paramMessage);
        continue;
        WakeLockStateMachine.this.log("broadcast complete, returning to idle");
        WakeLockStateMachine.this.transitionTo(WakeLockStateMachine.this.mIdleState);
        continue;
        WakeLockStateMachine.this.mWakeLock.release();
        if (!WakeLockStateMachine.this.mWakeLock.isHeld())
          WakeLockStateMachine.this.loge("mWakeLock released while still in WaitingState!");
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.WakeLockStateMachine
 * JD-Core Version:    0.6.2
 */