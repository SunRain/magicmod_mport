package com.android.internal.telephony;

public class IccCardConstants
{
  public static final String INTENT_KEY_ICC_STATE = "ss";
  public static final String INTENT_KEY_LOCKED_REASON = "reason";
  public static final String INTENT_VALUE_ABSENT_ON_PERM_DISABLED = "PERM_DISABLED";
  public static final String INTENT_VALUE_ICC_ABSENT = "ABSENT";
  public static final String INTENT_VALUE_ICC_IMSI = "IMSI";
  public static final String INTENT_VALUE_ICC_LOADED = "LOADED";
  public static final String INTENT_VALUE_ICC_LOCKED = "LOCKED";
  public static final String INTENT_VALUE_ICC_NOT_READY = "NOT_READY";
  public static final String INTENT_VALUE_ICC_READY = "READY";
  public static final String INTENT_VALUE_ICC_UNKNOWN = "UNKNOWN";
  public static final String INTENT_VALUE_LOCKED_NETWORK = "NETWORK";
  public static final String INTENT_VALUE_LOCKED_ON_PIN = "PIN";
  public static final String INTENT_VALUE_LOCKED_ON_PUK = "PUK";

  public static enum State
  {
    static
    {
      ABSENT = new State("ABSENT", 1);
      PIN_REQUIRED = new State("PIN_REQUIRED", 2);
      PUK_REQUIRED = new State("PUK_REQUIRED", 3);
      NETWORK_LOCKED = new State("NETWORK_LOCKED", 4);
      READY = new State("READY", 5);
      NOT_READY = new State("NOT_READY", 6);
      PERM_DISABLED = new State("PERM_DISABLED", 7);
      State[] arrayOfState = new State[8];
      arrayOfState[0] = UNKNOWN;
      arrayOfState[1] = ABSENT;
      arrayOfState[2] = PIN_REQUIRED;
      arrayOfState[3] = PUK_REQUIRED;
      arrayOfState[4] = NETWORK_LOCKED;
      arrayOfState[5] = READY;
      arrayOfState[6] = NOT_READY;
      arrayOfState[7] = PERM_DISABLED;
    }

    public boolean iccCardExist()
    {
      if ((this == PIN_REQUIRED) || (this == PUK_REQUIRED) || (this == NETWORK_LOCKED) || (this == READY) || (this == PERM_DISABLED));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    public boolean isPinLocked()
    {
      if ((this == PIN_REQUIRED) || (this == PUK_REQUIRED));
      for (boolean bool = true; ; bool = false)
        return bool;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.IccCardConstants
 * JD-Core Version:    0.6.2
 */