package com.android.internal.telephony;

import android.content.Context;
import android.content.Intent;
import android.os.Message;
import android.telephony.SmsCbMessage;

public class CellBroadcastHandler extends WakeLockStateMachine
{
  private CellBroadcastHandler(Context paramContext)
  {
    this("CellBroadcastHandler", paramContext, null);
  }

  protected CellBroadcastHandler(String paramString, Context paramContext, PhoneBase paramPhoneBase)
  {
    super(paramString, paramContext, paramPhoneBase);
  }

  public static CellBroadcastHandler makeCellBroadcastHandler(Context paramContext)
  {
    CellBroadcastHandler localCellBroadcastHandler = new CellBroadcastHandler(paramContext);
    localCellBroadcastHandler.start();
    return localCellBroadcastHandler;
  }

  protected void handleBroadcastSms(SmsCbMessage paramSmsCbMessage)
  {
    Intent localIntent;
    String str;
    if (paramSmsCbMessage.isEmergencyMessage())
    {
      log("Dispatching emergency SMS CB");
      localIntent = new Intent("android.provider.Telephony.SMS_EMERGENCY_CB_RECEIVED");
      str = "android.permission.RECEIVE_EMERGENCY_BROADCAST";
    }
    for (int i = 17; ; i = 16)
    {
      localIntent.putExtra("message", paramSmsCbMessage);
      this.mContext.sendOrderedBroadcast(localIntent, str, i, this.mReceiver, getHandler(), -1, null, null);
      return;
      log("Dispatching SMS CB");
      localIntent = new Intent("android.provider.Telephony.SMS_CB_RECEIVED");
      str = "android.permission.RECEIVE_SMS";
    }
  }

  protected boolean handleSmsMessage(Message paramMessage)
  {
    if ((paramMessage.obj instanceof SmsCbMessage))
      handleBroadcastSms((SmsCbMessage)paramMessage.obj);
    for (boolean bool = true; ; bool = false)
    {
      return bool;
      loge("handleMessage got object of type: " + paramMessage.obj.getClass().getName());
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.CellBroadcastHandler
 * JD-Core Version:    0.6.2
 */