package com.android.internal.telephony;

public class SmsConstants
{
  public static final int ENCODING_16BIT = 3;
  public static final int ENCODING_7BIT = 1;
  public static final int ENCODING_8BIT = 2;
  public static final int ENCODING_KSC5601 = 4;
  public static final int ENCODING_UNKNOWN = 0;
  public static final String FORMAT_3GPP = "3gpp";
  public static final String FORMAT_3GPP2 = "3gpp2";
  public static final String FORMAT_UNKNOWN = "unknown";
  public static final int MAX_USER_DATA_BYTES = 140;
  public static final int MAX_USER_DATA_BYTES_WITH_HEADER = 134;
  public static final int MAX_USER_DATA_SEPTETS = 160;
  public static final int MAX_USER_DATA_SEPTETS_WITH_HEADER = 153;

  public static enum MessageClass
  {
    static
    {
      CLASS_0 = new MessageClass("CLASS_0", 1);
      CLASS_1 = new MessageClass("CLASS_1", 2);
      CLASS_2 = new MessageClass("CLASS_2", 3);
      CLASS_3 = new MessageClass("CLASS_3", 4);
      MessageClass[] arrayOfMessageClass = new MessageClass[5];
      arrayOfMessageClass[0] = UNKNOWN;
      arrayOfMessageClass[1] = CLASS_0;
      arrayOfMessageClass[2] = CLASS_1;
      arrayOfMessageClass[3] = CLASS_2;
      arrayOfMessageClass[4] = CLASS_3;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsConstants
 * JD-Core Version:    0.6.2
 */