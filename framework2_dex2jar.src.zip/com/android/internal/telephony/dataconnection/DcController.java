package com.android.internal.telephony.dataconnection;

import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.LinkProperties.CompareResult;
import android.net.NetworkUtils;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.util.State;
import com.android.internal.util.StateMachine;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

class DcController extends StateMachine
{
  static final int DATA_CONNECTION_ACTIVE_PH_LINK_DORMANT = 1;
  static final int DATA_CONNECTION_ACTIVE_PH_LINK_INACTIVE = 0;
  static final int DATA_CONNECTION_ACTIVE_PH_LINK_UP = 2;
  private static final boolean DBG = true;
  private static final boolean VDBG;
  private HashMap<Integer, DataConnection> mDcListActiveByCid = new HashMap();
  ArrayList<DataConnection> mDcListAll = new ArrayList();
  private DcTesterDeactivateAll mDcTesterDeactivateAll;
  private DccDefaultState mDccDefaultState = new DccDefaultState(null);
  private DcTrackerBase mDct;
  private PhoneBase mPhone;

  private DcController(String paramString, PhoneBase paramPhoneBase, DcTrackerBase paramDcTrackerBase, Handler paramHandler)
  {
    super(paramString, paramHandler);
    setLogRecSize(300);
    log("E ctor");
    this.mPhone = paramPhoneBase;
    this.mDct = paramDcTrackerBase;
    addState(this.mDccDefaultState);
    setInitialState(this.mDccDefaultState);
    log("X ctor");
  }

  private void lr(String paramString)
  {
    logAndAddLogRec(paramString);
  }

  static DcController makeDcc(PhoneBase paramPhoneBase, DcTrackerBase paramDcTrackerBase, Handler paramHandler)
  {
    DcController localDcController = new DcController("Dcc", paramPhoneBase, paramDcTrackerBase, paramHandler);
    localDcController.start();
    return localDcController;
  }

  void addActiveDcByCid(DataConnection paramDataConnection)
  {
    if (paramDataConnection.mCid < 0)
      log("addActiveDcByCid dc.mCid < 0 dc=" + paramDataConnection);
    this.mDcListActiveByCid.put(Integer.valueOf(paramDataConnection.mCid), paramDataConnection);
  }

  void addDc(DataConnection paramDataConnection)
  {
    this.mDcListAll.add(paramDataConnection);
  }

  void dispose()
  {
    log("dispose: call quiteNow()");
    quitNow();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.println(" mDcListAll=" + this.mDcListAll);
    paramPrintWriter.println(" mDcListActiveByCid=" + this.mDcListActiveByCid);
  }

  protected String getWhatToString(int paramInt)
  {
    String str = DataConnection.cmdToString(paramInt);
    if (str == null)
      str = DcAsyncChannel.cmdToString(paramInt);
    return str;
  }

  protected void log(String paramString)
  {
    Rlog.d(getName(), paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e(getName(), paramString);
  }

  void removeActiveDcByCid(DataConnection paramDataConnection)
  {
    if ((DataConnection)this.mDcListActiveByCid.remove(Integer.valueOf(paramDataConnection.mCid)) == null)
      log("removeActiveDcByCid removedDc=null dc=" + paramDataConnection);
  }

  void removeDc(DataConnection paramDataConnection)
  {
    this.mDcListActiveByCid.remove(Integer.valueOf(paramDataConnection.mCid));
    this.mDcListAll.remove(paramDataConnection);
  }

  public String toString()
  {
    return "mDcListAll=" + this.mDcListAll + " mDcListActiveByCid=" + this.mDcListActiveByCid;
  }

  private class DccDefaultState extends State
  {
    private DccDefaultState()
    {
    }

    private void onDataStateChanged(ArrayList<DataCallResponse> paramArrayList)
    {
      DcController.this.lr("onDataStateChanged: dcsList=" + paramArrayList + " mDcListActiveByCid=" + DcController.this.mDcListActiveByCid);
      HashMap localHashMap = new HashMap();
      Iterator localIterator1 = paramArrayList.iterator();
      while (localIterator1.hasNext())
      {
        DataCallResponse localDataCallResponse2 = (DataCallResponse)localIterator1.next();
        localHashMap.put(Integer.valueOf(localDataCallResponse2.cid), localDataCallResponse2);
      }
      ArrayList localArrayList1 = new ArrayList();
      Iterator localIterator2 = DcController.this.mDcListActiveByCid.values().iterator();
      while (localIterator2.hasNext())
      {
        DataConnection localDataConnection3 = (DataConnection)localIterator2.next();
        if (localHashMap.get(Integer.valueOf(localDataConnection3.mCid)) == null)
        {
          DcController.this.log("onDataStateChanged: add to retry dc=" + localDataConnection3);
          localArrayList1.add(localDataConnection3);
        }
      }
      DcController.this.log("onDataStateChanged: dcsToRetry=" + localArrayList1);
      ArrayList localArrayList2 = new ArrayList();
      Iterator localIterator3 = paramArrayList.iterator();
      while (localIterator3.hasNext())
      {
        DataCallResponse localDataCallResponse1 = (DataCallResponse)localIterator3.next();
        DataConnection localDataConnection2 = (DataConnection)DcController.this.mDcListActiveByCid.get(Integer.valueOf(localDataCallResponse1.cid));
        if (localDataConnection2 == null)
        {
          DcController.this.loge("onDataStateChanged: no associated DC yet, ignore");
        }
        else if (localDataConnection2.mApnContexts.size() == 0)
        {
          DcController.this.loge("onDataStateChanged: no connected apns, ignore");
        }
        else
        {
          DcController.this.log("onDataStateChanged: Found ConnId=" + localDataCallResponse1.cid + " newState=" + localDataCallResponse1.toString());
          if (localDataCallResponse1.active == 0)
          {
            DcFailCause localDcFailCause = DcFailCause.fromInt(localDataCallResponse1.status);
            DcController.this.log("onDataStateChanged: inactive failCause=" + localDcFailCause);
            if (localDcFailCause.isRestartRadioFail())
            {
              DcController.this.log("onDataStateChanged: X restart radio");
              DcController.this.mDct.sendRestartRadio();
            }
            else if (localDcFailCause.isPermanentFail())
            {
              DcController.this.log("onDataStateChanged: inactive, add to cleanup list");
              localArrayList2.addAll(localDataConnection2.mApnContexts);
            }
            else
            {
              DcController.this.log("onDataStateChanged: inactive, add to retry list");
              localArrayList1.add(localDataConnection2);
            }
          }
          else
          {
            DataConnection.UpdateLinkPropertyResult localUpdateLinkPropertyResult = localDataConnection2.updateLinkProperty(localDataCallResponse1);
            if (localUpdateLinkPropertyResult.oldLp.equals(localUpdateLinkPropertyResult.newLp))
            {
              DcController.this.log("onDataStateChanged: no change");
            }
            else if (localUpdateLinkPropertyResult.oldLp.isIdenticalInterfaceName(localUpdateLinkPropertyResult.newLp))
            {
              if ((!localUpdateLinkPropertyResult.oldLp.isIdenticalDnses(localUpdateLinkPropertyResult.newLp)) || (!localUpdateLinkPropertyResult.oldLp.isIdenticalRoutes(localUpdateLinkPropertyResult.newLp)) || (!localUpdateLinkPropertyResult.oldLp.isIdenticalHttpProxy(localUpdateLinkPropertyResult.newLp)) || (!localUpdateLinkPropertyResult.oldLp.isIdenticalAddresses(localUpdateLinkPropertyResult.newLp)))
              {
                LinkProperties.CompareResult localCompareResult = localUpdateLinkPropertyResult.oldLp.compareAddresses(localUpdateLinkPropertyResult.newLp);
                DcController.this.log("onDataStateChanged: oldLp=" + localUpdateLinkPropertyResult.oldLp + " newLp=" + localUpdateLinkPropertyResult.newLp + " car=" + localCompareResult);
                int i = 0;
                Iterator localIterator6 = localCompareResult.added.iterator();
                while (true)
                {
                  if (!localIterator6.hasNext())
                    break label765;
                  LinkAddress localLinkAddress = (LinkAddress)localIterator6.next();
                  Iterator localIterator8 = localCompareResult.removed.iterator();
                  if (localIterator8.hasNext())
                  {
                    if (!NetworkUtils.addressTypeMatches(((LinkAddress)localIterator8.next()).getAddress(), localLinkAddress.getAddress()))
                      break;
                    i = 1;
                  }
                }
                label765: if (i != 0)
                {
                  DcController.this.log("onDataStateChanged: addr change, cleanup apns=" + localDataConnection2.mApnContexts + " oldLp=" + localUpdateLinkPropertyResult.oldLp + " newLp=" + localUpdateLinkPropertyResult.newLp);
                  localArrayList2.addAll(localDataConnection2.mApnContexts);
                }
                else
                {
                  DcController.this.log("onDataStateChanged: simple change");
                  Iterator localIterator7 = localDataConnection2.mApnContexts.iterator();
                  while (localIterator7.hasNext())
                  {
                    ApnContext localApnContext2 = (ApnContext)localIterator7.next();
                    DcController.this.mPhone.notifyDataConnection("linkPropertiesChanged", localApnContext2.getApnType());
                  }
                }
              }
              else
              {
                DcController.this.log("onDataStateChanged: no changes");
              }
            }
            else
            {
              localArrayList2.addAll(localDataConnection2.mApnContexts);
              DcController.this.log("onDataStateChanged: interface change, cleanup apns=" + localDataConnection2.mApnContexts);
            }
          }
        }
      }
      DcController.this.mPhone.notifyDataActivity();
      DcController.this.lr("onDataStateChanged: dcsToRetry=" + localArrayList1 + " apnsToCleanup=" + localArrayList2);
      Iterator localIterator4 = localArrayList2.iterator();
      while (localIterator4.hasNext())
      {
        ApnContext localApnContext1 = (ApnContext)localIterator4.next();
        DcController.this.mDct.sendCleanUpConnection(true, localApnContext1);
      }
      Iterator localIterator5 = localArrayList1.iterator();
      while (localIterator5.hasNext())
      {
        DataConnection localDataConnection1 = (DataConnection)localIterator5.next();
        DcController.this.log("onDataStateChanged: send EVENT_LOST_CONNECTION dc.mTag=" + localDataConnection1.mTag);
        localDataConnection1.sendMessage(262153, localDataConnection1.mTag);
      }
      DcController.this.log("onDataStateChanged: X");
    }

    public void enter()
    {
      DcController.this.mPhone.mCi.registerForRilConnected(DcController.this.getHandler(), 262149, null);
      DcController.this.mPhone.mCi.registerForDataNetworkStateChanged(DcController.this.getHandler(), 262151, null);
      if (Build.IS_DEBUGGABLE)
        DcController.access$202(DcController.this, new DcTesterDeactivateAll(DcController.this.mPhone, DcController.this, DcController.this.getHandler()));
    }

    public void exit()
    {
      if (DcController.this.mPhone != null)
      {
        DcController.this.mPhone.mCi.unregisterForRilConnected(DcController.this.getHandler());
        DcController.this.mPhone.mCi.unregisterForDataNetworkStateChanged(DcController.this.getHandler());
      }
      if (DcController.this.mDcTesterDeactivateAll != null)
        DcController.this.mDcTesterDeactivateAll.dispose();
    }

    public boolean processMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      case 262150:
      default:
      case 262149:
      case 262151:
      }
      while (true)
      {
        return true;
        AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
        if (localAsyncResult2.exception == null)
        {
          DcController.this.log("DccDefaultState: msg.what=EVENT_RIL_CONNECTED mRilVersion=" + localAsyncResult2.result);
        }
        else
        {
          DcController.this.log("DccDefaultState: Unexpected exception on EVENT_RIL_CONNECTED");
          continue;
          AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
          if (localAsyncResult1.exception == null)
            onDataStateChanged((ArrayList)localAsyncResult1.result);
          else
            DcController.this.log("DccDefaultState: EVENT_DATA_STATE_CHANGED: exception; likely radio not available, ignore");
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcController
 * JD-Core Version:    0.6.2
 */