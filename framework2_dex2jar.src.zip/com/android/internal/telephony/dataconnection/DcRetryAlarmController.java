package com.android.internal.telephony.dataconnection;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncResult;
import android.os.SystemClock;
import android.telephony.Rlog;
import android.text.TextUtils;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.RetryManager;

public class DcRetryAlarmController
{
  private static final boolean DBG = true;
  private static final String INTENT_RETRY_ALARM_TAG = "tag";
  private static final String INTENT_RETRY_ALARM_WHAT = "what";
  private String mActionRetry;
  private AlarmManager mAlarmManager;
  private DataConnection mDc;
  private BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      if (TextUtils.isEmpty(str))
        DcRetryAlarmController.this.log("onReceive: ignore empty action='" + str + "'");
      while (true)
      {
        return;
        if (TextUtils.equals(str, DcRetryAlarmController.this.mActionRetry))
        {
          if (!paramAnonymousIntent.hasExtra("what"))
            throw new RuntimeException(DcRetryAlarmController.this.mActionRetry + " has no INTENT_RETRY_ALRAM_WHAT");
          if (!paramAnonymousIntent.hasExtra("tag"))
            throw new RuntimeException(DcRetryAlarmController.this.mActionRetry + " has no INTENT_RETRY_ALRAM_TAG");
          int i = paramAnonymousIntent.getIntExtra("what", 2147483647);
          int j = paramAnonymousIntent.getIntExtra("tag", 2147483647);
          DcRetryAlarmController.this.log("onReceive: action=" + str + " sendMessage(what:" + DcRetryAlarmController.this.mDc.getWhatToString(i) + ", tag:" + j + ")");
          DcRetryAlarmController.this.mDc.sendMessage(DcRetryAlarmController.this.mDc.obtainMessage(i, j, 0));
        }
        else
        {
          DcRetryAlarmController.this.log("onReceive: unknown action=" + str);
        }
      }
    }
  };
  private String mLogTag = "DcRac";
  private PhoneBase mPhone;

  DcRetryAlarmController(PhoneBase paramPhoneBase, DataConnection paramDataConnection)
  {
    this.mLogTag = paramDataConnection.getName();
    this.mPhone = paramPhoneBase;
    this.mDc = paramDataConnection;
    this.mAlarmManager = ((AlarmManager)this.mPhone.getContext().getSystemService("alarm"));
    this.mActionRetry = (this.mDc.getClass().getCanonicalName() + "." + this.mDc.getName() + ".action_retry");
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction(this.mActionRetry);
    log("DcRetryAlarmController: register for intent action=" + this.mActionRetry);
    this.mPhone.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter, null, this.mDc.getHandler());
  }

  private void log(String paramString)
  {
    Rlog.d(this.mLogTag, "[dcRac] " + paramString);
  }

  void dispose()
  {
    log("dispose");
    this.mPhone.getContext().unregisterReceiver(this.mIntentReceiver);
    this.mPhone = null;
    this.mDc = null;
    this.mAlarmManager = null;
    this.mActionRetry = null;
  }

  int getSuggestedRetryTime(DataConnection paramDataConnection, AsyncResult paramAsyncResult)
  {
    DataCallResponse localDataCallResponse = (DataCallResponse)paramAsyncResult.result;
    int i = localDataCallResponse.suggestedRetryTime;
    if (i == 2147483647)
    {
      log("getSuggestedRetryTime: suggestedRetryTime is MAX_INT, retry NOT needed");
      i = -1;
    }
    while (true)
    {
      log("getSuggestedRetryTime: " + i + " response=" + localDataCallResponse + " dc=" + paramDataConnection);
      return i;
      if (i >= 0)
      {
        log("getSuggestedRetryTime: suggestedRetryTime is >= 0 use it");
      }
      else if (paramDataConnection.mRetryManager.isRetryNeeded())
      {
        i = paramDataConnection.mRetryManager.getRetryTimer();
        if (i < 0)
          i = 0;
        log("getSuggestedRetryTime: retry is needed");
      }
      else
      {
        log("getSuggestedRetryTime: retry is NOT needed");
        i = -1;
      }
    }
  }

  public void startRetryAlarm(int paramInt1, int paramInt2, int paramInt3)
  {
    Intent localIntent = new Intent(this.mActionRetry);
    localIntent.putExtra("what", paramInt1);
    localIntent.putExtra("tag", paramInt2);
    log("startRetryAlarm: next attempt in " + paramInt3 / 1000 + "s" + " what=" + paramInt1 + " tag=" + paramInt2);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, localIntent, 134217728);
    this.mAlarmManager.set(2, SystemClock.elapsedRealtime() + paramInt3, localPendingIntent);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(this.mLogTag).append(" [dcRac] ");
    localStringBuilder.append(" mPhone=").append(this.mPhone);
    localStringBuilder.append(" mDc=").append(this.mDc);
    localStringBuilder.append(" mAlaramManager=").append(this.mAlarmManager);
    localStringBuilder.append(" mActionRetry=").append(this.mActionRetry);
    return localStringBuilder.toString();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcRetryAlarmController
 * JD-Core Version:    0.6.2
 */