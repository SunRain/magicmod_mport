package com.android.internal.telephony.dataconnection;

import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.net.NetworkConfig;
import android.telephony.Rlog;
import com.android.internal.telephony.DctConstants.State;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class ApnContext
{
  protected static final boolean DBG;
  public final String LOG_TAG;
  private ApnSetting mApnSetting;
  private final String mApnType;
  private final Context mContext;
  AtomicBoolean mDataEnabled;
  DcAsyncChannel mDcAc;
  AtomicBoolean mDependencyMet;
  String mReason;
  PendingIntent mReconnectAlarmIntent;
  private DctConstants.State mState;
  private ArrayList<ApnSetting> mWaitingApns = null;
  private AtomicInteger mWaitingApnsPermanentFailureCountDown;
  public final int priority;

  public ApnContext(Context paramContext, String paramString1, String paramString2, NetworkConfig paramNetworkConfig)
  {
    this.mContext = paramContext;
    this.mApnType = paramString1;
    this.mState = DctConstants.State.IDLE;
    setReason("dataEnabled");
    this.mDataEnabled = new AtomicBoolean(false);
    this.mDependencyMet = new AtomicBoolean(paramNetworkConfig.dependencyMet);
    this.mWaitingApnsPermanentFailureCountDown = new AtomicInteger(0);
    this.priority = paramNetworkConfig.priority;
    this.LOG_TAG = paramString2;
  }

  public void decWaitingApnsPermFailCount()
  {
    this.mWaitingApnsPermanentFailureCountDown.decrementAndGet();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("ApnContext: " + toString());
  }

  public ApnSetting getApnSetting()
  {
    try
    {
      log("getApnSetting: apnSetting=" + this.mApnSetting);
      ApnSetting localApnSetting = this.mApnSetting;
      return localApnSetting;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public String getApnType()
  {
    return this.mApnType;
  }

  public DcAsyncChannel getDcAc()
  {
    try
    {
      DcAsyncChannel localDcAsyncChannel = this.mDcAc;
      return localDcAsyncChannel;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public boolean getDependencyMet()
  {
    return this.mDependencyMet.get();
  }

  public ApnSetting getNextWaitingApn()
  {
    try
    {
      ArrayList localArrayList = this.mWaitingApns;
      ApnSetting localApnSetting = null;
      if ((localArrayList != null) && (!localArrayList.isEmpty()))
        localApnSetting = (ApnSetting)localArrayList.get(0);
      return localApnSetting;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public String getReason()
  {
    try
    {
      String str = this.mReason;
      return str;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public PendingIntent getReconnectIntent()
  {
    try
    {
      PendingIntent localPendingIntent = this.mReconnectAlarmIntent;
      return localPendingIntent;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public DctConstants.State getState()
  {
    try
    {
      DctConstants.State localState = this.mState;
      return localState;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public ArrayList<ApnSetting> getWaitingApns()
  {
    try
    {
      ArrayList localArrayList = this.mWaitingApns;
      return localArrayList;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public int getWaitingApnsPermFailCount()
  {
    return this.mWaitingApnsPermanentFailureCountDown.get();
  }

  public boolean isConnectable()
  {
    if ((isReady()) && ((this.mState == DctConstants.State.IDLE) || (this.mState == DctConstants.State.SCANNING) || (this.mState == DctConstants.State.RETRYING) || (this.mState == DctConstants.State.FAILED)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isConnectedOrConnecting()
  {
    if ((isReady()) && ((this.mState == DctConstants.State.CONNECTED) || (this.mState == DctConstants.State.CONNECTING) || (this.mState == DctConstants.State.SCANNING) || (this.mState == DctConstants.State.RETRYING)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isDisconnected()
  {
    DctConstants.State localState = getState();
    if ((localState == DctConstants.State.IDLE) || (localState == DctConstants.State.FAILED));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isEnabled()
  {
    return this.mDataEnabled.get();
  }

  public boolean isProvisioningApn()
  {
    String str = this.mContext.getResources().getString(17039397);
    if ((this.mApnSetting != null) && (this.mApnSetting.apn != null));
    for (boolean bool = this.mApnSetting.apn.equals(str); ; bool = false)
      return bool;
  }

  public boolean isReady()
  {
    if ((this.mDataEnabled.get()) && (this.mDependencyMet.get()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected void log(String paramString)
  {
    Rlog.d(this.LOG_TAG, "[ApnContext:" + this.mApnType + "] " + paramString);
  }

  public void removeWaitingApn(ApnSetting paramApnSetting)
  {
    try
    {
      if (this.mWaitingApns != null)
        this.mWaitingApns.remove(paramApnSetting);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setApnSetting(ApnSetting paramApnSetting)
  {
    try
    {
      log("setApnSetting: apnSetting=" + paramApnSetting);
      this.mApnSetting = paramApnSetting;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setDataConnectionAc(DcAsyncChannel paramDcAsyncChannel)
  {
    try
    {
      this.mDcAc = paramDcAsyncChannel;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setDependencyMet(boolean paramBoolean)
  {
    this.mDependencyMet.set(paramBoolean);
  }

  public void setEnabled(boolean paramBoolean)
  {
    this.mDataEnabled.set(paramBoolean);
  }

  public void setReason(String paramString)
  {
    try
    {
      this.mReason = paramString;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setReconnectIntent(PendingIntent paramPendingIntent)
  {
    try
    {
      this.mReconnectAlarmIntent = paramPendingIntent;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setState(DctConstants.State paramState)
  {
    try
    {
      this.mState = paramState;
      if ((this.mState == DctConstants.State.FAILED) && (this.mWaitingApns != null))
        this.mWaitingApns.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setWaitingApns(ArrayList<ApnSetting> paramArrayList)
  {
    try
    {
      this.mWaitingApns = paramArrayList;
      this.mWaitingApnsPermanentFailureCountDown.set(this.mWaitingApns.size());
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public String toString()
  {
    try
    {
      String str = "{mApnType=" + this.mApnType + " mState=" + getState() + " mWaitingApns={" + this.mWaitingApns + "} mWaitingApnsPermanentFailureCountDown=" + this.mWaitingApnsPermanentFailureCountDown + " mApnSetting={" + this.mApnSetting + "} mReason=" + this.mReason + " mDataEnabled=" + this.mDataEnabled + " mDependencyMet=" + this.mDependencyMet + "}";
      return str;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.ApnContext
 * JD-Core Version:    0.6.2
 */