package com.android.internal.telephony.dataconnection;

import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.ProxyProperties;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.util.AsyncChannel;

public class DcAsyncChannel extends AsyncChannel
{
  public static final int BASE = 266240;
  private static final int CMD_TO_STRING_COUNT = 14;
  private static final boolean DBG = false;
  public static final int REQ_GET_APNSETTING = 266244;
  public static final int REQ_GET_CID = 266242;
  public static final int REQ_GET_LINK_CAPABILITIES = 266250;
  public static final int REQ_GET_LINK_PROPERTIES = 266246;
  public static final int REQ_IS_INACTIVE = 266240;
  public static final int REQ_RESET = 266252;
  public static final int REQ_SET_LINK_PROPERTIES_HTTP_PROXY = 266248;
  public static final int RSP_GET_APNSETTING = 266245;
  public static final int RSP_GET_CID = 266243;
  public static final int RSP_GET_LINK_CAPABILITIES = 266251;
  public static final int RSP_GET_LINK_PROPERTIES = 266247;
  public static final int RSP_IS_INACTIVE = 266241;
  public static final int RSP_RESET = 266253;
  public static final int RSP_SET_LINK_PROPERTIES_HTTP_PROXY = 266249;
  private static String[] sCmdToString = new String[14];
  private DataConnection mDc;
  private long mDcThreadId;
  private String mLogTag;

  static
  {
    sCmdToString[0] = "REQ_IS_INACTIVE";
    sCmdToString[1] = "RSP_IS_INACTIVE";
    sCmdToString[2] = "REQ_GET_CID";
    sCmdToString[3] = "RSP_GET_CID";
    sCmdToString[4] = "REQ_GET_APNSETTING";
    sCmdToString[5] = "RSP_GET_APNSETTING";
    sCmdToString[6] = "REQ_GET_LINK_PROPERTIES";
    sCmdToString[7] = "RSP_GET_LINK_PROPERTIES";
    sCmdToString[8] = "REQ_SET_LINK_PROPERTIES_HTTP_PROXY";
    sCmdToString[9] = "RSP_SET_LINK_PROPERTIES_HTTP_PROXY";
    sCmdToString[10] = "REQ_GET_LINK_CAPABILITIES";
    sCmdToString[11] = "RSP_GET_LINK_CAPABILITIES";
    sCmdToString[12] = "REQ_RESET";
    sCmdToString[13] = "RSP_RESET";
  }

  public DcAsyncChannel(DataConnection paramDataConnection, String paramString)
  {
    this.mDc = paramDataConnection;
    this.mDcThreadId = this.mDc.getHandler().getLooper().getThread().getId();
    this.mLogTag = paramString;
  }

  protected static String cmdToString(int paramInt)
  {
    int i = paramInt - 266240;
    if ((i >= 0) && (i < sCmdToString.length));
    for (String str = sCmdToString[i]; ; str = AsyncChannel.cmdToString(i + 266240))
      return str;
  }

  private boolean isCallerOnDifferentThread()
  {
    long l = Thread.currentThread().getId();
    if (this.mDcThreadId != l);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void log(String paramString)
  {
    Rlog.d(this.mLogTag, "DataConnectionAc " + paramString);
  }

  public void bringUp(ApnContext paramApnContext, int paramInt1, int paramInt2, int paramInt3, Message paramMessage)
  {
    sendMessage(262144, new DataConnection.ConnectionParams(paramApnContext, paramInt1, paramInt2, paramInt3, paramMessage));
  }

  public ApnSetting getApnSettingSync()
  {
    Message localMessage;
    ApnSetting localApnSetting;
    if (isCallerOnDifferentThread())
    {
      localMessage = sendMessageSynchronously(266244);
      if ((localMessage != null) && (localMessage.what == 266245))
        localApnSetting = rspApnSetting(localMessage);
    }
    while (true)
    {
      return localApnSetting;
      log("getApnSetting error response=" + localMessage);
      localApnSetting = null;
      continue;
      localApnSetting = this.mDc.getApnSetting();
    }
  }

  public int getCidSync()
  {
    Message localMessage;
    int i;
    if (isCallerOnDifferentThread())
    {
      localMessage = sendMessageSynchronously(266242);
      if ((localMessage != null) && (localMessage.what == 266243))
        i = rspCid(localMessage);
    }
    while (true)
    {
      return i;
      log("rspCid error response=" + localMessage);
      i = -1;
      continue;
      i = this.mDc.getCid();
    }
  }

  public int getDataConnectionIdSync()
  {
    return this.mDc.getDataConnectionId();
  }

  public LinkCapabilities getLinkCapabilitiesSync()
  {
    LinkCapabilities localLinkCapabilities;
    if (isCallerOnDifferentThread())
    {
      Message localMessage = sendMessageSynchronously(266250);
      if ((localMessage != null) && (localMessage.what == 266251))
        localLinkCapabilities = rspLinkCapabilities(localMessage);
    }
    while (true)
    {
      return localLinkCapabilities;
      localLinkCapabilities = null;
      continue;
      localLinkCapabilities = this.mDc.getCopyLinkCapabilities();
    }
  }

  public LinkProperties getLinkPropertiesSync()
  {
    Message localMessage;
    LinkProperties localLinkProperties;
    if (isCallerOnDifferentThread())
    {
      localMessage = sendMessageSynchronously(266246);
      if ((localMessage != null) && (localMessage.what == 266247))
        localLinkProperties = rspLinkProperties(localMessage);
    }
    while (true)
    {
      return localLinkProperties;
      log("getLinkProperties error response=" + localMessage);
      localLinkProperties = null;
      continue;
      localLinkProperties = this.mDc.getCopyLinkProperties();
    }
  }

  public boolean isInactiveSync()
  {
    Message localMessage;
    boolean bool;
    if (isCallerOnDifferentThread())
    {
      localMessage = sendMessageSynchronously(266240);
      if ((localMessage != null) && (localMessage.what == 266241))
        bool = rspIsInactive(localMessage);
    }
    while (true)
    {
      return bool;
      log("rspIsInactive error response=" + localMessage);
      bool = false;
      continue;
      bool = this.mDc.getIsInactive();
    }
  }

  public void reqApnSetting()
  {
    sendMessage(266244);
  }

  public void reqCid()
  {
    sendMessage(266242);
  }

  public void reqIsInactive()
  {
    sendMessage(266240);
  }

  public void reqLinkCapabilities()
  {
    sendMessage(266250);
  }

  public void reqLinkProperties()
  {
    sendMessage(266246);
  }

  public void reqReset()
  {
    sendMessage(266252);
  }

  public void reqSetLinkPropertiesHttpProxy(ProxyProperties paramProxyProperties)
  {
    sendMessage(266248, paramProxyProperties);
  }

  public ApnSetting rspApnSetting(Message paramMessage)
  {
    return (ApnSetting)paramMessage.obj;
  }

  public int rspCid(Message paramMessage)
  {
    return paramMessage.arg1;
  }

  public boolean rspIsInactive(Message paramMessage)
  {
    int i = 1;
    if (paramMessage.arg1 == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public LinkCapabilities rspLinkCapabilities(Message paramMessage)
  {
    return (LinkCapabilities)paramMessage.obj;
  }

  public LinkProperties rspLinkProperties(Message paramMessage)
  {
    return (LinkProperties)paramMessage.obj;
  }

  public void setLinkPropertiesHttpProxySync(ProxyProperties paramProxyProperties)
  {
    Message localMessage;
    if (isCallerOnDifferentThread())
    {
      localMessage = sendMessageSynchronously(266248, paramProxyProperties);
      if ((localMessage == null) || (localMessage.what != 266249));
    }
    while (true)
    {
      return;
      log("setLinkPropertiesHttpPoxy error response=" + localMessage);
      continue;
      this.mDc.setLinkPropertiesHttpProxy(paramProxyProperties);
    }
  }

  public void tearDown(ApnContext paramApnContext, String paramString, Message paramMessage)
  {
    sendMessage(262148, new DataConnection.DisconnectParams(paramApnContext, paramString, paramMessage));
  }

  public void tearDownAll(String paramString, Message paramMessage)
  {
    sendMessage(262150, new DataConnection.DisconnectParams(null, paramString, paramMessage));
  }

  public String toString()
  {
    return this.mDc.getName();
  }

  public static enum LinkPropertyChangeAction
  {
    static
    {
      CHANGED = new LinkPropertyChangeAction("CHANGED", 1);
      RESET = new LinkPropertyChangeAction("RESET", 2);
      LinkPropertyChangeAction[] arrayOfLinkPropertyChangeAction = new LinkPropertyChangeAction[3];
      arrayOfLinkPropertyChangeAction[0] = NONE;
      arrayOfLinkPropertyChangeAction[1] = CHANGED;
      arrayOfLinkPropertyChangeAction[2] = RESET;
    }

    public static LinkPropertyChangeAction fromInt(int paramInt)
    {
      LinkPropertyChangeAction localLinkPropertyChangeAction;
      if (paramInt == NONE.ordinal())
        localLinkPropertyChangeAction = NONE;
      while (true)
      {
        return localLinkPropertyChangeAction;
        if (paramInt == CHANGED.ordinal())
        {
          localLinkPropertyChangeAction = CHANGED;
        }
        else
        {
          if (paramInt != RESET.ordinal())
            break;
          localLinkPropertyChangeAction = RESET;
        }
      }
      throw new RuntimeException("LinkPropertyChangeAction.fromInt: bad value=" + paramInt);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcAsyncChannel
 * JD-Core Version:    0.6.2
 */