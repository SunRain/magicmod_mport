package com.android.internal.telephony.dataconnection;

public class DataCallResponse
{
  private final boolean DBG = true;
  private final String LOG_TAG = "DataCallResponse";
  public int active = 0;
  public String[] addresses = new String[0];
  public int cid = 0;
  public String[] dnses = new String[0];
  public String[] gateways = new String[0];
  public String ifname = "";
  public int status = 0;
  public int suggestedRetryTime = -1;
  public String type = "";
  public int version = 0;

  // ERROR //
  public SetupResult setLinkProperties(android.net.LinkProperties paramLinkProperties, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull +129 -> 130
    //   4: new 62	android/net/LinkProperties
    //   7: dup
    //   8: invokespecial 63	android/net/LinkProperties:<init>	()V
    //   11: astore_1
    //   12: aload_0
    //   13: getfield 34	com/android/internal/telephony/dataconnection/DataCallResponse:status	I
    //   16: getstatic 69	com/android/internal/telephony/dataconnection/DcFailCause:NONE	Lcom/android/internal/telephony/dataconnection/DcFailCause;
    //   19: invokevirtual 73	com/android/internal/telephony/dataconnection/DcFailCause:getErrorCode	()I
    //   22: if_icmpne +856 -> 878
    //   25: new 75	java/lang/StringBuilder
    //   28: dup
    //   29: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   32: ldc 78
    //   34: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: aload_0
    //   38: getfield 44	com/android/internal/telephony/dataconnection/DataCallResponse:ifname	Ljava/lang/String;
    //   41: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: ldc 84
    //   46: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   52: astore 5
    //   54: aload_0
    //   55: getfield 44	com/android/internal/telephony/dataconnection/DataCallResponse:ifname	Ljava/lang/String;
    //   58: astore 8
    //   60: aload_1
    //   61: aload 8
    //   63: invokevirtual 92	android/net/LinkProperties:setInterfaceName	(Ljava/lang/String;)V
    //   66: aload_0
    //   67: getfield 48	com/android/internal/telephony/dataconnection/DataCallResponse:addresses	[Ljava/lang/String;
    //   70: ifnull +316 -> 386
    //   73: aload_0
    //   74: getfield 48	com/android/internal/telephony/dataconnection/DataCallResponse:addresses	[Ljava/lang/String;
    //   77: arraylength
    //   78: ifle +308 -> 386
    //   81: aload_0
    //   82: getfield 48	com/android/internal/telephony/dataconnection/DataCallResponse:addresses	[Ljava/lang/String;
    //   85: astore 9
    //   87: aload 9
    //   89: arraylength
    //   90: istore 10
    //   92: iconst_0
    //   93: istore 11
    //   95: iload 11
    //   97: iload 10
    //   99: if_icmpge +317 -> 416
    //   102: aload 9
    //   104: iload 11
    //   106: aaload
    //   107: invokevirtual 95	java/lang/String:trim	()Ljava/lang/String;
    //   110: astore 34
    //   112: aload 34
    //   114: invokevirtual 99	java/lang/String:isEmpty	()Z
    //   117: istore 35
    //   119: iload 35
    //   121: ifeq +16 -> 137
    //   124: iinc 11 1
    //   127: goto -32 -> 95
    //   130: aload_1
    //   131: invokevirtual 102	android/net/LinkProperties:clear	()V
    //   134: goto -122 -> 12
    //   137: aload 34
    //   139: ldc 104
    //   141: invokevirtual 108	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   144: astore 36
    //   146: aload 36
    //   148: arraylength
    //   149: iconst_2
    //   150: if_icmpne +200 -> 350
    //   153: aload 36
    //   155: iconst_0
    //   156: aaload
    //   157: astore 34
    //   159: aload 36
    //   161: iconst_1
    //   162: aaload
    //   163: invokestatic 114	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   166: istore 43
    //   168: iload 43
    //   170: istore 37
    //   172: aload 34
    //   174: invokestatic 120	android/net/NetworkUtils:numericToInetAddress	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   177: astore 39
    //   179: aload 39
    //   181: invokevirtual 125	java/net/InetAddress:isAnyLocalAddress	()Z
    //   184: ifne -60 -> 124
    //   187: iload 37
    //   189: ifne +15 -> 204
    //   192: aload 39
    //   194: instanceof 127
    //   197: ifeq +703 -> 900
    //   200: bipush 32
    //   202: istore 37
    //   204: ldc 28
    //   206: new 75	java/lang/StringBuilder
    //   209: dup
    //   210: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   213: ldc 129
    //   215: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   218: aload 34
    //   220: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: ldc 104
    //   225: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: iload 37
    //   230: invokevirtual 132	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   233: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   236: invokestatic 138	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   239: pop
    //   240: new 140	android/net/LinkAddress
    //   243: dup
    //   244: aload 39
    //   246: iload 37
    //   248: invokespecial 143	android/net/LinkAddress:<init>	(Ljava/net/InetAddress;I)V
    //   251: astore 41
    //   253: aload_1
    //   254: aload 41
    //   256: invokevirtual 147	android/net/LinkProperties:addLinkAddress	(Landroid/net/LinkAddress;)Z
    //   259: pop
    //   260: goto -136 -> 124
    //   263: astore 6
    //   265: ldc 28
    //   267: new 75	java/lang/StringBuilder
    //   270: dup
    //   271: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   274: ldc 149
    //   276: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: aload 6
    //   281: invokevirtual 152	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   284: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   287: invokestatic 138	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   290: pop
    //   291: aload 6
    //   293: invokevirtual 155	java/net/UnknownHostException:printStackTrace	()V
    //   296: getstatic 161	com/android/internal/telephony/dataconnection/DataCallResponse$SetupResult:ERR_UnacceptableParameter	Lcom/android/internal/telephony/dataconnection/DataCallResponse$SetupResult;
    //   299: astore_3
    //   300: aload_3
    //   301: getstatic 164	com/android/internal/telephony/dataconnection/DataCallResponse$SetupResult:SUCCESS	Lcom/android/internal/telephony/dataconnection/DataCallResponse$SetupResult;
    //   304: if_acmpeq +44 -> 348
    //   307: ldc 28
    //   309: new 75	java/lang/StringBuilder
    //   312: dup
    //   313: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   316: ldc 166
    //   318: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: aload_0
    //   322: getfield 34	com/android/internal/telephony/dataconnection/DataCallResponse:status	I
    //   325: invokevirtual 132	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   328: ldc 168
    //   330: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: aload_3
    //   334: invokevirtual 152	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   337: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   340: invokestatic 138	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   343: pop
    //   344: aload_1
    //   345: invokevirtual 102	android/net/LinkProperties:clear	()V
    //   348: aload_3
    //   349: areturn
    //   350: iconst_0
    //   351: istore 37
    //   353: goto -181 -> 172
    //   356: astore 38
    //   358: new 58	java/net/UnknownHostException
    //   361: dup
    //   362: new 75	java/lang/StringBuilder
    //   365: dup
    //   366: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   369: ldc 170
    //   371: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: aload 34
    //   376: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   379: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   382: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   385: athrow
    //   386: new 58	java/net/UnknownHostException
    //   389: dup
    //   390: new 75	java/lang/StringBuilder
    //   393: dup
    //   394: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   397: ldc 174
    //   399: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: aload_0
    //   403: getfield 44	com/android/internal/telephony/dataconnection/DataCallResponse:ifname	Ljava/lang/String;
    //   406: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   409: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   412: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   415: athrow
    //   416: aload_0
    //   417: getfield 50	com/android/internal/telephony/dataconnection/DataCallResponse:dnses	[Ljava/lang/String;
    //   420: ifnull +114 -> 534
    //   423: aload_0
    //   424: getfield 50	com/android/internal/telephony/dataconnection/DataCallResponse:dnses	[Ljava/lang/String;
    //   427: arraylength
    //   428: ifle +106 -> 534
    //   431: aload_0
    //   432: getfield 50	com/android/internal/telephony/dataconnection/DataCallResponse:dnses	[Ljava/lang/String;
    //   435: astore 27
    //   437: aload 27
    //   439: arraylength
    //   440: istore 28
    //   442: iconst_0
    //   443: istore 29
    //   445: iload 29
    //   447: iload 28
    //   449: if_icmpge +256 -> 705
    //   452: aload 27
    //   454: iload 29
    //   456: aaload
    //   457: invokevirtual 95	java/lang/String:trim	()Ljava/lang/String;
    //   460: astore 30
    //   462: aload 30
    //   464: invokevirtual 99	java/lang/String:isEmpty	()Z
    //   467: istore 31
    //   469: iload 31
    //   471: ifeq +9 -> 480
    //   474: iinc 29 1
    //   477: goto -32 -> 445
    //   480: aload 30
    //   482: invokestatic 120	android/net/NetworkUtils:numericToInetAddress	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   485: astore 33
    //   487: aload 33
    //   489: invokevirtual 125	java/net/InetAddress:isAnyLocalAddress	()Z
    //   492: ifne -18 -> 474
    //   495: aload_1
    //   496: aload 33
    //   498: invokevirtual 178	android/net/LinkProperties:addDns	(Ljava/net/InetAddress;)V
    //   501: goto -27 -> 474
    //   504: astore 32
    //   506: new 58	java/net/UnknownHostException
    //   509: dup
    //   510: new 75	java/lang/StringBuilder
    //   513: dup
    //   514: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   517: ldc 180
    //   519: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   522: aload 30
    //   524: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   527: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   530: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   533: athrow
    //   534: iload_2
    //   535: ifeq +160 -> 695
    //   538: iconst_2
    //   539: anewarray 46	java/lang/String
    //   542: astore 12
    //   544: aload 12
    //   546: iconst_0
    //   547: new 75	java/lang/StringBuilder
    //   550: dup
    //   551: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   554: aload 5
    //   556: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: ldc 182
    //   561: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   567: invokestatic 188	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   570: aastore
    //   571: aload 12
    //   573: iconst_1
    //   574: new 75	java/lang/StringBuilder
    //   577: dup
    //   578: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   581: aload 5
    //   583: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   586: ldc 190
    //   588: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   591: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   594: invokestatic 188	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   597: aastore
    //   598: aload 12
    //   600: arraylength
    //   601: istore 13
    //   603: iconst_0
    //   604: istore 14
    //   606: iload 14
    //   608: iload 13
    //   610: if_icmpge +95 -> 705
    //   613: aload 12
    //   615: iload 14
    //   617: aaload
    //   618: invokevirtual 95	java/lang/String:trim	()Ljava/lang/String;
    //   621: astore 23
    //   623: aload 23
    //   625: invokevirtual 99	java/lang/String:isEmpty	()Z
    //   628: istore 24
    //   630: iload 24
    //   632: ifeq +9 -> 641
    //   635: iinc 14 1
    //   638: goto -32 -> 606
    //   641: aload 23
    //   643: invokestatic 120	android/net/NetworkUtils:numericToInetAddress	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   646: astore 26
    //   648: aload 26
    //   650: invokevirtual 125	java/net/InetAddress:isAnyLocalAddress	()Z
    //   653: ifne -18 -> 635
    //   656: aload_1
    //   657: aload 26
    //   659: invokevirtual 178	android/net/LinkProperties:addDns	(Ljava/net/InetAddress;)V
    //   662: goto -27 -> 635
    //   665: astore 25
    //   667: new 58	java/net/UnknownHostException
    //   670: dup
    //   671: new 75	java/lang/StringBuilder
    //   674: dup
    //   675: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   678: ldc 180
    //   680: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   683: aload 23
    //   685: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   688: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   691: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   694: athrow
    //   695: new 58	java/net/UnknownHostException
    //   698: dup
    //   699: ldc 192
    //   701: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   704: athrow
    //   705: aload_0
    //   706: getfield 52	com/android/internal/telephony/dataconnection/DataCallResponse:gateways	[Ljava/lang/String;
    //   709: ifnull +11 -> 720
    //   712: aload_0
    //   713: getfield 52	com/android/internal/telephony/dataconnection/DataCallResponse:gateways	[Ljava/lang/String;
    //   716: arraylength
    //   717: ifne +44 -> 761
    //   720: new 75	java/lang/StringBuilder
    //   723: dup
    //   724: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   727: aload 5
    //   729: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   732: ldc 194
    //   734: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   740: invokestatic 188	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   743: astore 15
    //   745: aload 15
    //   747: ifnull +56 -> 803
    //   750: aload_0
    //   751: aload 15
    //   753: ldc 196
    //   755: invokevirtual 108	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   758: putfield 52	com/android/internal/telephony/dataconnection/DataCallResponse:gateways	[Ljava/lang/String;
    //   761: aload_0
    //   762: getfield 52	com/android/internal/telephony/dataconnection/DataCallResponse:gateways	[Ljava/lang/String;
    //   765: astore 16
    //   767: aload 16
    //   769: arraylength
    //   770: istore 17
    //   772: iconst_0
    //   773: istore 18
    //   775: iload 18
    //   777: iload 17
    //   779: if_icmpge +92 -> 871
    //   782: aload 16
    //   784: iload 18
    //   786: aaload
    //   787: invokevirtual 95	java/lang/String:trim	()Ljava/lang/String;
    //   790: astore 19
    //   792: aload 19
    //   794: invokevirtual 99	java/lang/String:isEmpty	()Z
    //   797: ifeq +17 -> 814
    //   800: goto +108 -> 908
    //   803: aload_0
    //   804: iconst_0
    //   805: anewarray 46	java/lang/String
    //   808: putfield 52	com/android/internal/telephony/dataconnection/DataCallResponse:gateways	[Ljava/lang/String;
    //   811: goto -50 -> 761
    //   814: aload 19
    //   816: invokestatic 120	android/net/NetworkUtils:numericToInetAddress	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   819: astore 21
    //   821: new 198	android/net/RouteInfo
    //   824: dup
    //   825: aload 21
    //   827: invokespecial 200	android/net/RouteInfo:<init>	(Ljava/net/InetAddress;)V
    //   830: astore 22
    //   832: aload_1
    //   833: aload 22
    //   835: invokevirtual 204	android/net/LinkProperties:addRoute	(Landroid/net/RouteInfo;)V
    //   838: goto +70 -> 908
    //   841: astore 20
    //   843: new 58	java/net/UnknownHostException
    //   846: dup
    //   847: new 75	java/lang/StringBuilder
    //   850: dup
    //   851: invokespecial 76	java/lang/StringBuilder:<init>	()V
    //   854: ldc 206
    //   856: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   859: aload 19
    //   861: invokevirtual 82	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   864: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   867: invokespecial 172	java/net/UnknownHostException:<init>	(Ljava/lang/String;)V
    //   870: athrow
    //   871: getstatic 164	com/android/internal/telephony/dataconnection/DataCallResponse$SetupResult:SUCCESS	Lcom/android/internal/telephony/dataconnection/DataCallResponse$SetupResult;
    //   874: astore_3
    //   875: goto -575 -> 300
    //   878: aload_0
    //   879: getfield 32	com/android/internal/telephony/dataconnection/DataCallResponse:version	I
    //   882: iconst_4
    //   883: if_icmpge +10 -> 893
    //   886: getstatic 209	com/android/internal/telephony/dataconnection/DataCallResponse$SetupResult:ERR_GetLastErrorFromRil	Lcom/android/internal/telephony/dataconnection/DataCallResponse$SetupResult;
    //   889: astore_3
    //   890: goto -590 -> 300
    //   893: getstatic 212	com/android/internal/telephony/dataconnection/DataCallResponse$SetupResult:ERR_RilError	Lcom/android/internal/telephony/dataconnection/DataCallResponse$SetupResult;
    //   896: astore_3
    //   897: goto -597 -> 300
    //   900: sipush 128
    //   903: istore 37
    //   905: goto -701 -> 204
    //   908: iinc 18 1
    //   911: goto -136 -> 775
    //
    // Exception table:
    //   from	to	target	type
    //   54	119	263	java/net/UnknownHostException
    //   137	168	263	java/net/UnknownHostException
    //   172	179	263	java/net/UnknownHostException
    //   179	260	263	java/net/UnknownHostException
    //   358	469	263	java/net/UnknownHostException
    //   480	487	263	java/net/UnknownHostException
    //   487	630	263	java/net/UnknownHostException
    //   641	648	263	java/net/UnknownHostException
    //   648	811	263	java/net/UnknownHostException
    //   814	821	263	java/net/UnknownHostException
    //   821	875	263	java/net/UnknownHostException
    //   172	179	356	java/lang/IllegalArgumentException
    //   480	487	504	java/lang/IllegalArgumentException
    //   641	648	665	java/lang/IllegalArgumentException
    //   814	821	841	java/lang/IllegalArgumentException
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("DataCallResponse: {").append("version=").append(this.version).append(" status=").append(this.status).append(" retry=").append(this.suggestedRetryTime).append(" cid=").append(this.cid).append(" active=").append(this.active).append(" type=").append(this.type).append("' ifname='").append(this.ifname);
    localStringBuffer.append("' addresses=[");
    String[] arrayOfString1 = this.addresses;
    int i = arrayOfString1.length;
    for (int j = 0; j < i; j++)
    {
      localStringBuffer.append(arrayOfString1[j]);
      localStringBuffer.append(",");
    }
    if (this.addresses.length > 0)
      localStringBuffer.deleteCharAt(-1 + localStringBuffer.length());
    localStringBuffer.append("] dnses=[");
    String[] arrayOfString2 = this.dnses;
    int k = arrayOfString2.length;
    for (int m = 0; m < k; m++)
    {
      localStringBuffer.append(arrayOfString2[m]);
      localStringBuffer.append(",");
    }
    if (this.dnses.length > 0)
      localStringBuffer.deleteCharAt(-1 + localStringBuffer.length());
    localStringBuffer.append("] gateways=[");
    String[] arrayOfString3 = this.gateways;
    int n = arrayOfString3.length;
    for (int i1 = 0; i1 < n; i1++)
    {
      localStringBuffer.append(arrayOfString3[i1]);
      localStringBuffer.append(",");
    }
    if (this.gateways.length > 0)
      localStringBuffer.deleteCharAt(-1 + localStringBuffer.length());
    localStringBuffer.append("]}");
    return localStringBuffer.toString();
  }

  public static enum SetupResult
  {
    public DcFailCause mFailCause = DcFailCause.fromInt(0);

    static
    {
      ERR_BadCommand = new SetupResult("ERR_BadCommand", 1);
      ERR_UnacceptableParameter = new SetupResult("ERR_UnacceptableParameter", 2);
      ERR_GetLastErrorFromRil = new SetupResult("ERR_GetLastErrorFromRil", 3);
      ERR_Stale = new SetupResult("ERR_Stale", 4);
      ERR_RilError = new SetupResult("ERR_RilError", 5);
      SetupResult[] arrayOfSetupResult = new SetupResult[6];
      arrayOfSetupResult[0] = SUCCESS;
      arrayOfSetupResult[1] = ERR_BadCommand;
      arrayOfSetupResult[2] = ERR_UnacceptableParameter;
      arrayOfSetupResult[3] = ERR_GetLastErrorFromRil;
      arrayOfSetupResult[4] = ERR_Stale;
      arrayOfSetupResult[5] = ERR_RilError;
    }

    public String toString()
    {
      return name() + "  SetupResult.mFailCause=" + this.mFailCause;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DataCallResponse
 * JD-Core Version:    0.6.2
 */