package com.android.internal.telephony.dataconnection;

import android.content.Intent;
import android.telephony.Rlog;

class DcFailBringUp
{
  static final String ACTION_FAIL_BRINGUP = "action_fail_bringup";
  static final String COUNTER = "counter";
  private static final boolean DBG = true;
  static final int DEFAULT_COUNTER = 1;
  static final DcFailCause DEFAULT_FAIL_CAUSE = DcFailCause.ERROR_UNSPECIFIED;
  static final int DEFAULT_SUGGESTED_RETRY_TIME = -1;
  static final String FAIL_CAUSE = "fail_cause";
  static final String INTENT_BASE = DataConnection.class.getPackage().getName();
  private static final String LOG_TAG = "DcFailBringUp";
  static final String SUGGESTED_RETRY_TIME = "suggested_retry_time";
  int mCounter;
  DcFailCause mFailCause;
  int mSuggestedRetryTime;

  private static void log(String paramString)
  {
    Rlog.d("DcFailBringUp", paramString);
  }

  void saveParameters(int paramInt1, int paramInt2, int paramInt3)
  {
    this.mCounter = paramInt1;
    this.mFailCause = DcFailCause.fromInt(paramInt2);
    this.mSuggestedRetryTime = paramInt3;
  }

  void saveParameters(Intent paramIntent, String paramString)
  {
    log(paramString + ".saveParameters: action=" + paramIntent.getAction());
    this.mCounter = paramIntent.getIntExtra("counter", 1);
    this.mFailCause = DcFailCause.fromInt(paramIntent.getIntExtra("fail_cause", DEFAULT_FAIL_CAUSE.getErrorCode()));
    this.mSuggestedRetryTime = paramIntent.getIntExtra("suggested_retry_time", -1);
    log(paramString + ".saveParameters: " + this);
  }

  public String toString()
  {
    return "{mCounter=" + this.mCounter + " mFailCause=" + this.mFailCause + " mSuggestedRetryTime=" + this.mSuggestedRetryTime + "}";
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcFailBringUp
 * JD-Core Version:    0.6.2
 */