package com.android.internal.telephony.dataconnection;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.telephony.Rlog;
import com.android.internal.telephony.PhoneBase;
import java.util.ArrayList;
import java.util.Iterator;

public class DcTesterDeactivateAll
{
  private static final boolean DBG = true;
  private static final String LOG_TAG = "DcTesterDeacativeAll";
  public static String sActionDcTesterDeactivateAll = "com.android.internal.telephony.dataconnection.action_deactivate_all";
  private DcController mDcc;
  private PhoneBase mPhone;
  protected BroadcastReceiver sIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      DcTesterDeactivateAll.log("sIntentReceiver.onReceive: action=" + str);
      if ((str.equals(DcTesterDeactivateAll.sActionDcTesterDeactivateAll)) || (str.equals(DcTesterDeactivateAll.this.mPhone.getActionDetached())))
      {
        DcTesterDeactivateAll.log("Send DEACTIVATE to all Dcc's");
        if (DcTesterDeactivateAll.this.mDcc != null)
        {
          Iterator localIterator = DcTesterDeactivateAll.this.mDcc.mDcListAll.iterator();
          while (localIterator.hasNext())
            ((DataConnection)localIterator.next()).tearDownNow();
        }
        DcTesterDeactivateAll.log("onReceive: mDcc is null, ignoring");
      }
      while (true)
      {
        return;
        DcTesterDeactivateAll.log("onReceive: unknown action=" + str);
      }
    }
  };

  DcTesterDeactivateAll(PhoneBase paramPhoneBase, DcController paramDcController, Handler paramHandler)
  {
    this.mPhone = paramPhoneBase;
    this.mDcc = paramDcController;
    if (Build.IS_DEBUGGABLE)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(sActionDcTesterDeactivateAll);
      log("register for intent action=" + sActionDcTesterDeactivateAll);
      localIntentFilter.addAction(this.mPhone.getActionDetached());
      log("register for intent action=" + this.mPhone.getActionDetached());
      paramPhoneBase.getContext().registerReceiver(this.sIntentReceiver, localIntentFilter, null, paramHandler);
    }
  }

  private static void log(String paramString)
  {
    Rlog.d("DcTesterDeacativeAll", paramString);
  }

  void dispose()
  {
    if (Build.IS_DEBUGGABLE)
      this.mPhone.getContext().unregisterReceiver(this.sIntentReceiver);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcTesterDeactivateAll
 * JD-Core Version:    0.6.2
 */