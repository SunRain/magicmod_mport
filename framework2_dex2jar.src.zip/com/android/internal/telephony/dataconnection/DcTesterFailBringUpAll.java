package com.android.internal.telephony.dataconnection;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.telephony.Rlog;
import com.android.internal.telephony.PhoneBase;

public class DcTesterFailBringUpAll
{
  private static final boolean DBG = true;
  private static final String LOG_TAG = "DcTesterFailBrinupAll";
  private String mActionFailBringUp = DcFailBringUp.INTENT_BASE + "." + "action_fail_bringup";
  private DcFailBringUp mFailBringUp = new DcFailBringUp();
  private BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      String str = paramAnonymousIntent.getAction();
      DcTesterFailBringUpAll.this.log("sIntentReceiver.onReceive: action=" + str);
      if (str.equals(DcTesterFailBringUpAll.this.mActionFailBringUp))
        DcTesterFailBringUpAll.this.mFailBringUp.saveParameters(paramAnonymousIntent, "sFailBringUp");
      while (true)
      {
        return;
        if (str.equals(DcTesterFailBringUpAll.this.mPhone.getActionDetached()))
        {
          DcTesterFailBringUpAll.this.log("simulate detaching");
          DcTesterFailBringUpAll.this.mFailBringUp.saveParameters(2147483647, DcFailCause.LOST_CONNECTION.getErrorCode(), -1);
        }
        else if (str.equals(DcTesterFailBringUpAll.this.mPhone.getActionAttached()))
        {
          DcTesterFailBringUpAll.this.log("simulate attaching");
          DcTesterFailBringUpAll.this.mFailBringUp.saveParameters(0, DcFailCause.NONE.getErrorCode(), -1);
        }
        else
        {
          DcTesterFailBringUpAll.this.log("onReceive: unknown action=" + str);
        }
      }
    }
  };
  private PhoneBase mPhone;

  DcTesterFailBringUpAll(PhoneBase paramPhoneBase, Handler paramHandler)
  {
    this.mPhone = paramPhoneBase;
    if (Build.IS_DEBUGGABLE)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(this.mActionFailBringUp);
      log("register for intent action=" + this.mActionFailBringUp);
      localIntentFilter.addAction(this.mPhone.getActionDetached());
      log("register for intent action=" + this.mPhone.getActionDetached());
      localIntentFilter.addAction(this.mPhone.getActionAttached());
      log("register for intent action=" + this.mPhone.getActionAttached());
      paramPhoneBase.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter, null, paramHandler);
    }
  }

  private void log(String paramString)
  {
    Rlog.d("DcTesterFailBrinupAll", paramString);
  }

  void dispose()
  {
    if (Build.IS_DEBUGGABLE)
      this.mPhone.getContext().unregisterReceiver(this.mIntentReceiver);
  }

  DcFailBringUp getDcFailBringUp()
  {
    return this.mFailBringUp;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcTesterFailBringUpAll
 * JD-Core Version:    0.6.2
 */