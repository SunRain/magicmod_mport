package com.android.internal.telephony.dataconnection;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.net.ConnectivityManager;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.NetworkInfo;
import android.net.TrafficStats;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.provider.Settings.Global;
import android.provider.Settings.SettingNotFoundException;
import android.provider.Settings.System;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import android.util.EventLog;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.DctConstants.Activity;
import com.android.internal.telephony.DctConstants.State;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.DataState;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccController;
import com.android.internal.util.ArrayUtils;
import com.android.internal.util.AsyncChannel;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public abstract class DcTrackerBase extends Handler
{
  protected static final int APN_DELAY_DEFAULT_MILLIS = 20000;
  protected static final int APN_FAIL_FAST_DELAY_DEFAULT_MILLIS = 3000;
  protected static final String APN_RESTORE_DELAY_PROP_NAME = "android.telephony.apn-restore";
  protected static final int DATA_CONNECTION_ACTIVE_PH_LINK_DOWN = 1;
  protected static final int DATA_CONNECTION_ACTIVE_PH_LINK_INACTIVE = 0;
  protected static final int DATA_CONNECTION_ACTIVE_PH_LINK_UP = 2;
  protected static final int DATA_STALL_ALARM_AGGRESSIVE_DELAY_IN_MS_DEFAULT = 60000;
  protected static final int DATA_STALL_ALARM_NON_AGGRESSIVE_DELAY_IN_MS_DEFAULT = 360000;
  protected static final String DATA_STALL_ALARM_TAG_EXTRA = "data.stall.alram.tag";
  protected static final boolean DATA_STALL_NOT_SUSPECTED = false;
  protected static final int DATA_STALL_NO_RECV_POLL_LIMIT = 1;
  protected static final boolean DATA_STALL_SUSPECTED = true;
  protected static final boolean DBG = true;
  protected static final String DEBUG_PROV_APN_ALARM = "persist.debug.prov_apn_alarm";
  protected static final String DEFALUT_DATA_ON_BOOT_PROP = "net.def_data_on_boot";
  protected static final String DEFAULT_DATA_RETRY_CONFIG = "default_randomization=2000,5000,10000,20000,40000,80000:5000,160000:5000,320000:5000,640000:5000,1280000:5000,1800000:5000";
  protected static final int DEFAULT_MAX_PDP_RESET_FAIL = 3;
  private static final int DEFAULT_MDC_INITIAL_RETRY = 1;
  protected static final String INTENT_DATA_STALL_ALARM = "com.android.internal.telephony.data-stall";
  protected static final String INTENT_PROVISIONING_APN_ALARM = "com.android.internal.telephony.provisioning_apn_alarm";
  protected static final String INTENT_RECONNECT_ALARM = "com.android.internal.telephony.data-reconnect";
  protected static final String INTENT_RECONNECT_ALARM_EXTRA_REASON = "reconnect_alarm_extra_reason";
  protected static final String INTENT_RECONNECT_ALARM_EXTRA_TYPE = "reconnect_alarm_extra_type";
  protected static final String INTENT_RESTART_TRYSETUP_ALARM = "com.android.internal.telephony.data-restart-trysetup";
  protected static final String INTENT_RESTART_TRYSETUP_ALARM_EXTRA_TYPE = "restart_trysetup_alarm_extra_type";
  protected static final int NO_RECV_POLL_LIMIT = 24;
  protected static final String NULL_IP = "0.0.0.0";
  protected static final int NUMBER_SENT_PACKETS_OF_HANG = 10;
  protected static final int POLL_LONGEST_RTT = 120000;
  protected static final int POLL_NETSTAT_MILLIS = 1000;
  protected static final int POLL_NETSTAT_SCREEN_OFF_MILLIS = 600000;
  protected static final int POLL_NETSTAT_SLOW_MILLIS = 5000;
  protected static final int PROVISIONING_APN_ALARM_DELAY_IN_MS_DEFAULT = 900000;
  protected static final String PROVISIONING_APN_ALARM_TAG_EXTRA = "provisioning.apn.alarm.tag";
  protected static final boolean RADIO_TESTS = false;
  protected static final int RESTORE_DEFAULT_APN_DELAY = 60000;
  protected static final String SECONDARY_DATA_RETRY_CONFIG = "max_retries=3, 5000, 5000, 5000";
  protected static final boolean VDBG = false;
  protected static final boolean VDBG_STALL = true;
  protected static int sEnableFailFastRefCounter = 0;
  protected static boolean sPolicyDataEnabled = true;
  protected String RADIO_RESET_PROPERTY = "gsm.radioreset";
  protected ApnSetting mActiveApn;
  protected DctConstants.Activity mActivity = DctConstants.Activity.NONE;
  AlarmManager mAlarmManager;
  protected ArrayList<ApnSetting> mAllApnSettings = null;
  protected final ConcurrentHashMap<String, ApnContext> mApnContexts = new ConcurrentHashMap();
  protected HashMap<String, Integer> mApnToDataConnectionId = new HashMap();
  protected boolean mAutoAttachOnCreation = false;
  protected int mCidActive;
  ConnectivityManager mCm;
  protected HashMap<Integer, DcAsyncChannel> mDataConnectionAcHashMap = new HashMap();
  protected Handler mDataConnectionTracker = null;
  protected HashMap<Integer, DataConnection> mDataConnections = new HashMap();
  private boolean[] mDataEnabled = new boolean[9];
  protected Object mDataEnabledLock = new Object();
  private final DataRoamingSettingObserver mDataRoamingSettingObserver;
  protected PendingIntent mDataStallAlarmIntent = null;
  protected int mDataStallAlarmTag = (int)SystemClock.elapsedRealtime();
  protected volatile boolean mDataStallDetectionEnabled = true;
  protected TxRxSum mDataStallTxRxSum = new TxRxSum(0L, 0L);
  protected DcTesterFailBringUpAll mDcTesterFailBringUpAll;
  protected DcController mDcc;
  private int mEnabledCount = 0;
  protected volatile boolean mFailFast = false;
  protected AtomicReference<IccRecords> mIccRecords = new AtomicReference();
  protected boolean mInVoiceCall = false;
  protected BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      boolean bool1 = true;
      String str = paramAnonymousIntent.getAction();
      DcTrackerBase.this.log("onReceive: action=" + str);
      if (str.equals("android.intent.action.SCREEN_ON"))
      {
        DcTrackerBase.this.mIsScreenOn = bool1;
        DcTrackerBase.this.stopNetStatPoll();
        DcTrackerBase.this.startNetStatPoll();
        DcTrackerBase.this.restartDataStallAlarm();
      }
      do
      {
        while (true)
        {
          return;
          if (str.equals("android.intent.action.SCREEN_OFF"))
          {
            DcTrackerBase.this.mIsScreenOn = false;
            DcTrackerBase.this.stopNetStatPoll();
            DcTrackerBase.this.startNetStatPoll();
            DcTrackerBase.this.restartDataStallAlarm();
          }
          else if (str.startsWith("com.android.internal.telephony.data-reconnect"))
          {
            DcTrackerBase.this.log("Reconnect alarm. Previous state was " + DcTrackerBase.this.mState);
            DcTrackerBase.this.onActionIntentReconnectAlarm(paramAnonymousIntent);
          }
          else if (str.startsWith("com.android.internal.telephony.data-restart-trysetup"))
          {
            DcTrackerBase.this.log("Restart trySetup alarm");
            DcTrackerBase.this.onActionIntentRestartTrySetupAlarm(paramAnonymousIntent);
          }
          else if (str.equals("com.android.internal.telephony.data-stall"))
          {
            DcTrackerBase.this.onActionIntentDataStallAlarm(paramAnonymousIntent);
          }
          else
          {
            if (!str.equals("com.android.internal.telephony.provisioning_apn_alarm"))
              break;
            DcTrackerBase.this.onActionIntentProvisioningApnAlarm(paramAnonymousIntent);
          }
        }
        if (str.equals("android.net.wifi.STATE_CHANGE"))
        {
          NetworkInfo localNetworkInfo = (NetworkInfo)paramAnonymousIntent.getParcelableExtra("networkInfo");
          DcTrackerBase localDcTrackerBase = DcTrackerBase.this;
          if ((localNetworkInfo != null) && (localNetworkInfo.isConnected()));
          while (true)
          {
            localDcTrackerBase.mIsWifiConnected = bool1;
            DcTrackerBase.this.log("NETWORK_STATE_CHANGED_ACTION: mIsWifiConnected=" + DcTrackerBase.this.mIsWifiConnected);
            break;
            bool1 = false;
          }
        }
      }
      while (!str.equals("android.net.wifi.WIFI_STATE_CHANGED"));
      if (paramAnonymousIntent.getIntExtra("wifi_state", 4) == 3);
      for (boolean bool2 = bool1; ; bool2 = false)
      {
        if (!bool2)
          DcTrackerBase.this.mIsWifiConnected = false;
        DcTrackerBase.this.log("WIFI_STATE_CHANGED_ACTION: enabled=" + bool2 + " mIsWifiConnected=" + DcTrackerBase.this.mIsWifiConnected);
        break;
      }
    }
  };
  protected boolean mInternalDataEnabled = true;
  protected boolean mIsDisposed = false;
  protected boolean mIsProvisioning = false;
  protected boolean mIsPsRestricted = false;
  protected boolean mIsScreenOn = true;
  protected boolean mIsWifiConnected = false;
  protected boolean mNetStatPollEnabled = false;
  protected int mNetStatPollPeriod;
  protected int mNoRecvPollCount = 0;
  protected PhoneBase mPhone;
  private Runnable mPollNetStat = new Runnable()
  {
    public void run()
    {
      DcTrackerBase.this.updateDataActivity();
      if (DcTrackerBase.this.mIsScreenOn);
      for (DcTrackerBase.this.mNetStatPollPeriod = Settings.Global.getInt(DcTrackerBase.this.mResolver, "pdp_watchdog_poll_interval_ms", 1000); ; DcTrackerBase.this.mNetStatPollPeriod = Settings.Global.getInt(DcTrackerBase.this.mResolver, "pdp_watchdog_long_poll_interval_ms", 600000))
      {
        if (DcTrackerBase.this.mNetStatPollEnabled)
          DcTrackerBase.this.mDataConnectionTracker.postDelayed(this, DcTrackerBase.this.mNetStatPollPeriod);
        return;
      }
    }
  };
  protected ApnSetting mPreferredApn = null;
  protected final PriorityQueue<ApnContext> mPrioritySortedApnContexts = new PriorityQueue(5, new Comparator()
  {
    public int compare(ApnContext paramAnonymousApnContext1, ApnContext paramAnonymousApnContext2)
    {
      return paramAnonymousApnContext2.priority - paramAnonymousApnContext1.priority;
    }
  });
  protected PendingIntent mProvisioningApnAlarmIntent = null;
  protected int mProvisioningApnAlarmTag = (int)SystemClock.elapsedRealtime();
  protected String mProvisioningUrl = null;
  protected PendingIntent mReconnectIntent = null;
  protected AsyncChannel mReplyAc = new AsyncChannel();
  protected String mRequestedApnType = "default";
  protected ContentResolver mResolver;
  protected long mRxPkts;
  protected long mSentSinceLastRecv;
  protected DctConstants.State mState = DctConstants.State.IDLE;
  protected long mTxPkts;
  protected UiccController mUiccController;
  protected AtomicInteger mUniqueIdGenerator = new AtomicInteger(0);
  protected boolean mUserDataEnabled = true;

  protected DcTrackerBase(PhoneBase paramPhoneBase)
  {
    log("DCT.constructor");
    this.mPhone = paramPhoneBase;
    this.mResolver = this.mPhone.getContext().getContentResolver();
    this.mUiccController = UiccController.getInstance();
    this.mUiccController.registerForIccChanged(this, 270369, null);
    this.mAlarmManager = ((AlarmManager)this.mPhone.getContext().getSystemService("alarm"));
    this.mCm = ((ConnectivityManager)this.mPhone.getContext().getSystemService("connectivity"));
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.intent.action.SCREEN_ON");
    localIntentFilter.addAction("android.intent.action.SCREEN_OFF");
    localIntentFilter.addAction("android.net.wifi.STATE_CHANGE");
    localIntentFilter.addAction("android.net.wifi.WIFI_STATE_CHANGED");
    localIntentFilter.addAction("com.android.internal.telephony.data-stall");
    localIntentFilter.addAction("com.android.internal.telephony.provisioning_apn_alarm");
    if (Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "mobile_data", 1) == 1);
    for (boolean bool = true; ; bool = false)
    {
      this.mUserDataEnabled = bool;
      this.mPhone.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter, null, this.mPhone);
      this.mDataEnabled[0] = SystemProperties.getBoolean("net.def_data_on_boot", true);
      if (this.mDataEnabled[0] != 0)
        this.mEnabledCount = (1 + this.mEnabledCount);
      this.mAutoAttachOnCreation = PreferenceManager.getDefaultSharedPreferences(this.mPhone.getContext()).getBoolean("disabled_on_boot_key", false);
      this.mDataRoamingSettingObserver = new DataRoamingSettingObserver(this.mPhone, this.mPhone.getContext());
      this.mDataRoamingSettingObserver.register();
      HandlerThread localHandlerThread = new HandlerThread("DcHandlerThread");
      localHandlerThread.start();
      Handler localHandler = new Handler(localHandlerThread.getLooper());
      this.mDcc = DcController.makeDcc(this.mPhone, this, localHandler);
      this.mDcTesterFailBringUpAll = new DcTesterFailBringUpAll(this.mPhone, localHandler);
      return;
    }
  }

  private void notifyApnIdDisconnected(String paramString, int paramInt)
  {
    this.mPhone.notifyDataConnection(paramString, apnIdToType(paramInt), PhoneConstants.DataState.DISCONNECTED);
  }

  private void notifyApnIdUpToCurrent(String paramString, int paramInt)
  {
    switch (4.$SwitchMap$com$android$internal$telephony$DctConstants$State[this.mState.ordinal()])
    {
    case 1:
    default:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      return;
      this.mPhone.notifyDataConnection(paramString, apnIdToType(paramInt), PhoneConstants.DataState.CONNECTING);
      continue;
      this.mPhone.notifyDataConnection(paramString, apnIdToType(paramInt), PhoneConstants.DataState.CONNECTING);
      this.mPhone.notifyDataConnection(paramString, apnIdToType(paramInt), PhoneConstants.DataState.CONNECTED);
    }
  }

  private void updateDataStallInfo()
  {
    TxRxSum localTxRxSum = new TxRxSum(this.mDataStallTxRxSum);
    this.mDataStallTxRxSum.updateTxRxSum();
    log("updateDataStallInfo: mDataStallTxRxSum=" + this.mDataStallTxRxSum + " preTxRxSum=" + localTxRxSum);
    long l1 = this.mDataStallTxRxSum.txPkts - localTxRxSum.txPkts;
    long l2 = this.mDataStallTxRxSum.rxPkts - localTxRxSum.rxPkts;
    if ((l1 > 0L) && (l2 > 0L))
    {
      log("updateDataStallInfo: IN/OUT");
      this.mSentSinceLastRecv = 0L;
      putRecoveryAction(0);
    }
    while (true)
    {
      return;
      if ((l1 > 0L) && (l2 == 0L))
      {
        if (this.mPhone.getState() == PhoneConstants.State.IDLE);
        for (this.mSentSinceLastRecv = (l1 + this.mSentSinceLastRecv); ; this.mSentSinceLastRecv = 0L)
        {
          log("updateDataStallInfo: OUT sent=" + l1 + " mSentSinceLastRecv=" + this.mSentSinceLastRecv);
          break;
        }
      }
      if ((l1 == 0L) && (l2 > 0L))
      {
        log("updateDataStallInfo: IN");
        this.mSentSinceLastRecv = 0L;
        putRecoveryAction(0);
      }
      else
      {
        log("updateDataStallInfo: NONE");
      }
    }
  }

  protected String apnIdToType(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      log("Unknown id (" + paramInt + ") in apnIdToType");
      str = "default";
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    }
    while (true)
    {
      return str;
      str = "default";
      continue;
      str = "mms";
      continue;
      str = "supl";
      continue;
      str = "dun";
      continue;
      str = "hipri";
      continue;
      str = "ims";
      continue;
      str = "fota";
      continue;
      str = "cbs";
      continue;
      str = "ia";
    }
  }

  protected int apnTypeToId(String paramString)
  {
    int i;
    if (TextUtils.equals(paramString, "default"))
      i = 0;
    while (true)
    {
      return i;
      if (TextUtils.equals(paramString, "mms"))
        i = 1;
      else if (TextUtils.equals(paramString, "supl"))
        i = 2;
      else if (TextUtils.equals(paramString, "dun"))
        i = 3;
      else if (TextUtils.equals(paramString, "hipri"))
        i = 4;
      else if (TextUtils.equals(paramString, "ims"))
        i = 5;
      else if (TextUtils.equals(paramString, "fota"))
        i = 6;
      else if (TextUtils.equals(paramString, "cbs"))
        i = 7;
      else if (TextUtils.equals(paramString, "ia"))
        i = 8;
      else
        i = -1;
    }
  }

  public void cleanUpAllConnections(String paramString)
  {
    Message localMessage = obtainMessage(270365);
    localMessage.obj = paramString;
    sendMessage(localMessage);
  }

  protected abstract void completeConnection(ApnContext paramApnContext);

  public int disableApnType(String paramString)
  {
    int i = 3;
    try
    {
      log("disableApnType(" + paramString + ")");
      int j = apnTypeToId(paramString);
      if (j == -1);
      while (true)
      {
        return i;
        if (isApnIdEnabled(j))
        {
          setEnabled(j, false);
          if (isApnTypeActive("default"))
          {
            int k = this.mDataEnabled[0];
            if (k != 0)
              i = 0;
            else
              i = 1;
          }
          else
          {
            i = 1;
          }
        }
      }
    }
    finally
    {
    }
  }

  public void dispose()
  {
    log("DCT.dispose");
    Iterator localIterator = this.mDataConnectionAcHashMap.values().iterator();
    while (localIterator.hasNext())
      ((DcAsyncChannel)localIterator.next()).disconnect();
    this.mDataConnectionAcHashMap.clear();
    this.mIsDisposed = true;
    this.mPhone.getContext().unregisterReceiver(this.mIntentReceiver);
    this.mUiccController.unregisterForIccChanged(this);
    this.mDataRoamingSettingObserver.unregister();
    this.mDcc.dispose();
    this.mDcTesterFailBringUpAll.dispose();
  }

  protected void doRecovery()
  {
    if (getOverallState() == DctConstants.State.CONNECTED)
    {
      int i = getRecoveryAction();
      switch (i)
      {
      default:
        throw new RuntimeException("doRecovery: Invalid recoveryAction=" + i);
      case 0:
        EventLog.writeEvent(50118, this.mSentSinceLastRecv);
        log("doRecovery() get data call list");
        this.mPhone.mCi.getDataCallList(obtainMessage(270340));
        putRecoveryAction(1);
      case 1:
      case 2:
      case 3:
      case 4:
      }
    }
    while (true)
    {
      this.mSentSinceLastRecv = 0L;
      return;
      EventLog.writeEvent(50119, this.mSentSinceLastRecv);
      log("doRecovery() cleanup all connections");
      cleanUpAllConnections("pdpReset");
      putRecoveryAction(2);
      continue;
      EventLog.writeEvent(50120, this.mSentSinceLastRecv);
      log("doRecovery() re-register");
      this.mPhone.getServiceStateTracker().reRegisterNetwork(null);
      putRecoveryAction(3);
      continue;
      EventLog.writeEvent(50121, this.mSentSinceLastRecv);
      log("restarting radio");
      putRecoveryAction(4);
      restartRadio();
      continue;
      EventLog.writeEvent(50122, -1);
      log("restarting radio with gsm.radioreset to true");
      SystemProperties.set(this.RADIO_RESET_PROPERTY, "true");
      try
      {
        Thread.sleep(1000L);
        label259: restartRadio();
        putRecoveryAction(0);
      }
      catch (InterruptedException localInterruptedException)
      {
        break label259;
      }
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("DataConnectionTrackerBase:");
    paramPrintWriter.println(" RADIO_TESTS=false");
    paramPrintWriter.println(" mInternalDataEnabled=" + this.mInternalDataEnabled);
    paramPrintWriter.println(" mUserDataEnabled=" + this.mUserDataEnabled);
    paramPrintWriter.println(" sPolicyDataEnabed=" + sPolicyDataEnabled);
    paramPrintWriter.println(" mDataEnabled:");
    for (int i = 0; i < this.mDataEnabled.length; i++)
    {
      Object[] arrayOfObject4 = new Object[2];
      arrayOfObject4[0] = Integer.valueOf(i);
      arrayOfObject4[1] = Boolean.valueOf(this.mDataEnabled[i]);
      paramPrintWriter.printf("  mDataEnabled[%d]=%b\n", arrayOfObject4);
    }
    paramPrintWriter.flush();
    paramPrintWriter.println(" mEnabledCount=" + this.mEnabledCount);
    paramPrintWriter.println(" mRequestedApnType=" + this.mRequestedApnType);
    paramPrintWriter.println(" mPhone=" + this.mPhone.getPhoneName());
    paramPrintWriter.println(" mActivity=" + this.mActivity);
    paramPrintWriter.println(" mState=" + this.mState);
    paramPrintWriter.println(" mTxPkts=" + this.mTxPkts);
    paramPrintWriter.println(" mRxPkts=" + this.mRxPkts);
    paramPrintWriter.println(" mNetStatPollPeriod=" + this.mNetStatPollPeriod);
    paramPrintWriter.println(" mNetStatPollEnabled=" + this.mNetStatPollEnabled);
    paramPrintWriter.println(" mDataStallTxRxSum=" + this.mDataStallTxRxSum);
    paramPrintWriter.println(" mDataStallAlarmTag=" + this.mDataStallAlarmTag);
    paramPrintWriter.println(" mDataStallDetectionEanbled=" + this.mDataStallDetectionEnabled);
    paramPrintWriter.println(" mSentSinceLastRecv=" + this.mSentSinceLastRecv);
    paramPrintWriter.println(" mNoRecvPollCount=" + this.mNoRecvPollCount);
    paramPrintWriter.println(" mResolver=" + this.mResolver);
    paramPrintWriter.println(" mIsWifiConnected=" + this.mIsWifiConnected);
    paramPrintWriter.println(" mReconnectIntent=" + this.mReconnectIntent);
    paramPrintWriter.println(" mCidActive=" + this.mCidActive);
    paramPrintWriter.println(" mAutoAttachOnCreation=" + this.mAutoAttachOnCreation);
    paramPrintWriter.println(" mIsScreenOn=" + this.mIsScreenOn);
    paramPrintWriter.println(" mUniqueIdGenerator=" + this.mUniqueIdGenerator);
    paramPrintWriter.flush();
    paramPrintWriter.println(" ***************************************");
    DcController localDcController = this.mDcc;
    if (localDcController != null)
      localDcController.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    while (true)
    {
      paramPrintWriter.println(" ***************************************");
      if (this.mDataConnections == null)
        break;
      Set localSet3 = this.mDataConnections.entrySet();
      paramPrintWriter.println(" mDataConnections: count=" + localSet3.size());
      Iterator localIterator3 = localSet3.iterator();
      while (localIterator3.hasNext())
      {
        Map.Entry localEntry2 = (Map.Entry)localIterator3.next();
        Object[] arrayOfObject3 = new Object[1];
        arrayOfObject3[0] = localEntry2.getKey();
        paramPrintWriter.printf(" *** mDataConnection[%d] \n", arrayOfObject3);
        ((DataConnection)localEntry2.getValue()).dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      }
      paramPrintWriter.println(" mDcc=null");
    }
    paramPrintWriter.println("mDataConnections=null");
    paramPrintWriter.println(" ***************************************");
    paramPrintWriter.flush();
    HashMap localHashMap = this.mApnToDataConnectionId;
    if (localHashMap != null)
    {
      Set localSet2 = localHashMap.entrySet();
      paramPrintWriter.println(" mApnToDataConnectonId size=" + localSet2.size());
      Iterator localIterator2 = localSet2.iterator();
      while (localIterator2.hasNext())
      {
        Map.Entry localEntry1 = (Map.Entry)localIterator2.next();
        Object[] arrayOfObject2 = new Object[2];
        arrayOfObject2[0] = localEntry1.getKey();
        arrayOfObject2[1] = localEntry1.getValue();
        paramPrintWriter.printf(" mApnToDataConnectonId[%s]=%d\n", arrayOfObject2);
      }
    }
    paramPrintWriter.println("mApnToDataConnectionId=null");
    paramPrintWriter.println(" ***************************************");
    paramPrintWriter.flush();
    ConcurrentHashMap localConcurrentHashMap = this.mApnContexts;
    if (localConcurrentHashMap != null)
    {
      Set localSet1 = localConcurrentHashMap.entrySet();
      paramPrintWriter.println(" mApnContexts size=" + localSet1.size());
      Iterator localIterator1 = localSet1.iterator();
      while (localIterator1.hasNext())
        ((ApnContext)((Map.Entry)localIterator1.next()).getValue()).dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      paramPrintWriter.println(" ***************************************");
    }
    while (true)
    {
      paramPrintWriter.flush();
      paramPrintWriter.println(" mActiveApn=" + this.mActiveApn);
      ArrayList localArrayList = this.mAllApnSettings;
      if (localArrayList == null)
        break label1439;
      paramPrintWriter.println(" mAllApnSettings size=" + localArrayList.size());
      for (int j = 0; j < localArrayList.size(); j++)
      {
        Object[] arrayOfObject1 = new Object[2];
        arrayOfObject1[0] = Integer.valueOf(j);
        arrayOfObject1[1] = localArrayList.get(j);
        paramPrintWriter.printf(" mAllApnSettings[%d]: %s\n", arrayOfObject1);
      }
      paramPrintWriter.println(" mApnContexts=null");
    }
    paramPrintWriter.flush();
    while (true)
    {
      paramPrintWriter.println(" mPreferredApn=" + this.mPreferredApn);
      paramPrintWriter.println(" mIsPsRestricted=" + this.mIsPsRestricted);
      paramPrintWriter.println(" mIsDisposed=" + this.mIsDisposed);
      paramPrintWriter.println(" mIntentReceiver=" + this.mIntentReceiver);
      paramPrintWriter.println(" mDataRoamingSettingObserver=" + this.mDataRoamingSettingObserver);
      paramPrintWriter.flush();
      return;
      label1439: paramPrintWriter.println(" mAllApnSettings=null");
    }
  }

  public int enableApnType(String paramString)
  {
    int i = 1;
    try
    {
      int j = apnTypeToId(paramString);
      if (j == -1)
        i = 3;
      while (true)
      {
        return i;
        log("enableApnType(" + paramString + "), isApnTypeActive = " + isApnTypeActive(paramString) + ", isApnIdEnabled =" + isApnIdEnabled(j) + " and state = " + this.mState);
        if (!isApnTypeAvailable(paramString))
        {
          log("enableApnType: not available, type=" + paramString);
          i = 2;
        }
        else if (isApnIdEnabled(j))
        {
          log("enableApnType: already active, type=" + paramString);
          i = 0;
        }
        else
        {
          setEnabled(j, true);
        }
      }
    }
    finally
    {
    }
  }

  protected ApnSetting fetchDunApn()
  {
    ApnSetting localApnSetting;
    if (SystemProperties.getBoolean("net.tethering.noprovisioning", false))
    {
      log("fetchDunApn: net.tethering.noprovisioning=true ret: null");
      localApnSetting = null;
    }
    label97: label103: 
    while (true)
    {
      return localApnSetting;
      Context localContext = this.mPhone.getContext();
      localApnSetting = ApnSetting.fromString(Settings.Global.getString(localContext.getContentResolver(), "tether_dun_apn"));
      IccRecords localIccRecords;
      if (localApnSetting != null)
      {
        localIccRecords = (IccRecords)this.mIccRecords.get();
        if (localIccRecords == null)
          break label97;
      }
      for (String str = localIccRecords.getOperatorNumeric(); ; str = "")
      {
        if (localApnSetting.numeric.equals(str))
          break label103;
        localApnSetting = ApnSetting.fromString(localContext.getResources().getString(17039385));
        break;
      }
    }
  }

  public String getActiveApnString(String paramString)
  {
    String str = null;
    if (this.mActiveApn != null)
      str = this.mActiveApn.apn;
    return str;
  }

  public String[] getActiveApnTypes()
  {
    if (this.mActiveApn != null);
    for (String[] arrayOfString = this.mActiveApn.types; ; arrayOfString = new String[] { "default" })
      return arrayOfString;
  }

  public DctConstants.Activity getActivity()
  {
    return this.mActivity;
  }

  public boolean getAnyDataEnabled()
  {
    synchronized (this.mDataEnabledLock)
    {
      if ((this.mInternalDataEnabled) && (this.mUserDataEnabled) && (sPolicyDataEnabled) && (this.mEnabledCount != 0))
      {
        bool = true;
        if (!bool)
          log("getAnyDataEnabled " + bool);
        return bool;
      }
      boolean bool = false;
    }
  }

  public boolean getDataOnRoamingEnabled()
  {
    boolean bool = false;
    try
    {
      int i = Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "data_roaming");
      if (i != 0)
        bool = true;
      label25: return bool;
    }
    catch (Settings.SettingNotFoundException localSettingNotFoundException)
    {
      break label25;
    }
  }

  protected int getInitialMaxRetry()
  {
    if (this.mFailFast);
    int i;
    for (int j = 0; ; j = Settings.Global.getInt(this.mResolver, "mdc_initial_max_retry", i))
    {
      return j;
      i = SystemProperties.getInt("mdc_initial_max_retry", 1);
    }
  }

  public LinkCapabilities getLinkCapabilities(String paramString)
  {
    if (isApnIdEnabled(apnTypeToId(paramString)));
    for (LinkCapabilities localLinkCapabilities = ((DcAsyncChannel)this.mDataConnectionAcHashMap.get(Integer.valueOf(0))).getLinkCapabilitiesSync(); ; localLinkCapabilities = new LinkCapabilities())
      return localLinkCapabilities;
  }

  public LinkProperties getLinkProperties(String paramString)
  {
    if (isApnIdEnabled(apnTypeToId(paramString)));
    for (LinkProperties localLinkProperties = ((DcAsyncChannel)this.mDataConnectionAcHashMap.get(Integer.valueOf(0))).getLinkPropertiesSync(); ; localLinkProperties = new LinkProperties())
      return localLinkProperties;
  }

  protected abstract DctConstants.State getOverallState();

  public int getRecoveryAction()
  {
    int i = Settings.System.getInt(this.mPhone.getContext().getContentResolver(), "radio.data.stall.recovery.action", 0);
    log("getRecoveryAction: " + i);
    return i;
  }

  protected String getReryConfig(boolean paramBoolean)
  {
    int i = this.mPhone.getServiceState().getNetworkType();
    String str;
    if ((i == 4) || (i == 7) || (i == 5) || (i == 6) || (i == 12) || (i == 14))
      str = SystemProperties.get("ro.cdma.data_retry_config");
    while (true)
    {
      return str;
      if (paramBoolean)
        str = SystemProperties.get("ro.gsm.data_retry_config");
      else
        str = SystemProperties.get("ro.gsm.2nd_data_retry_config");
    }
  }

  public abstract DctConstants.State getState(String paramString);

  protected abstract void gotoIdleAndNotifyDataConnection(String paramString);

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      Rlog.e("DATA", "Unidentified event msg=" + paramMessage);
    case 69636:
    case 270349:
    case 270339:
    case 270353:
    case 270348:
    case 270347:
    case 270337:
    case 270342:
    case 270336:
    case 270371:
    case 270351:
    case 270370:
    case 270343:
    case 270344:
    case 270365:
    case 270360:
    case 270363:
    case 270364:
    case 270366:
    case 270367:
    case 270368:
    case 270372:
    case 270373:
    case 270375:
    case 270374:
    case 270369:
    case 270362:
    }
    while (true)
    {
      return;
      log("DISCONNECTED_CONNECTED: msg=" + paramMessage);
      DcAsyncChannel localDcAsyncChannel = (DcAsyncChannel)paramMessage.obj;
      this.mDataConnectionAcHashMap.remove(Integer.valueOf(localDcAsyncChannel.getDataConnectionIdSync()));
      localDcAsyncChannel.disconnected();
      continue;
      onEnableApn(paramMessage.arg1, paramMessage.arg2);
      continue;
      String str3 = null;
      if ((paramMessage.obj instanceof String))
        str3 = (String)paramMessage.obj;
      onTrySetupData(str3);
      continue;
      onDataStallAlarm(paramMessage.arg1);
      continue;
      onRoamingOff();
      continue;
      onRoamingOn();
      continue;
      onRadioAvailable();
      continue;
      onRadioOffOrNotAvailable();
      continue;
      this.mCidActive = paramMessage.arg1;
      onDataSetupComplete((AsyncResult)paramMessage.obj);
      continue;
      onDataSetupCompleteError((AsyncResult)paramMessage.obj);
      continue;
      log("DataConnectionTracker.handleMessage: EVENT_DISCONNECT_DONE msg=" + paramMessage);
      onDisconnectDone(paramMessage.arg1, (AsyncResult)paramMessage.obj);
      continue;
      log("DataConnectionTracker.handleMessage: EVENT_DISCONNECT_DC_RETRYING msg=" + paramMessage);
      onDisconnectDcRetrying(paramMessage.arg1, (AsyncResult)paramMessage.obj);
      continue;
      onVoiceCallStarted();
      continue;
      onVoiceCallEnded();
      continue;
      onCleanUpAllConnections((String)paramMessage.obj);
      continue;
      if (paramMessage.arg1 == 0);
      for (boolean bool9 = false; ; bool9 = true)
      {
        onCleanUpConnection(bool9, paramMessage.arg2, (String)paramMessage.obj);
        break;
      }
      if (paramMessage.arg1 == 1);
      for (boolean bool8 = true; ; bool8 = false)
      {
        onSetInternalDataEnabled(bool8);
        break;
      }
      log("EVENT_RESET_DONE");
      onResetDone((AsyncResult)paramMessage.obj);
      continue;
      if (paramMessage.arg1 == 1);
      for (boolean bool7 = true; ; bool7 = false)
      {
        log("CMD_SET_USER_DATA_ENABLE enabled=" + bool7);
        onSetUserDataEnabled(bool7);
        break;
      }
      if (paramMessage.arg1 == 1);
      for (boolean bool6 = true; ; bool6 = false)
      {
        log("CMD_SET_DEPENDENCY_MET met=" + bool6);
        Bundle localBundle3 = paramMessage.getData();
        if (localBundle3 == null)
          break;
        String str2 = (String)localBundle3.get("apnType");
        if (str2 == null)
          break;
        onSetDependencyMet(str2, bool6);
        break;
      }
      if (paramMessage.arg1 == 1);
      for (boolean bool5 = true; ; bool5 = false)
      {
        onSetPolicyDataEnabled(bool5);
        break;
      }
      int j = sEnableFailFastRefCounter;
      int k;
      label809: boolean bool3;
      if (paramMessage.arg1 == 1)
      {
        k = 1;
        sEnableFailFastRefCounter = k + j;
        log("CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA:  sEnableFailFastRefCounter=" + sEnableFailFastRefCounter);
        if (sEnableFailFastRefCounter < 0)
        {
          loge("CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA: sEnableFailFastRefCounter:" + sEnableFailFastRefCounter + " < 0");
          sEnableFailFastRefCounter = 0;
        }
        if (sEnableFailFastRefCounter > 0)
        {
          bool3 = true;
          label894: log("CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA: enabled=" + bool3 + " sEnableFailFastRefCounter=" + sEnableFailFastRefCounter);
          if (this.mFailFast == bool3)
            continue;
          this.mFailFast = bool3;
          if (bool3)
            break label1028;
        }
      }
      else
      {
        label1028: for (boolean bool4 = true; ; bool4 = false)
        {
          this.mDataStallDetectionEnabled = bool4;
          if ((!this.mDataStallDetectionEnabled) || (getOverallState() != DctConstants.State.CONNECTED) || ((this.mInVoiceCall) && (!this.mPhone.getServiceStateTracker().isConcurrentVoiceAndDataAllowed())))
            break label1034;
          log("CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA: start data stall");
          stopDataStallAlarm();
          startDataStallAlarm(false);
          break;
          k = -1;
          break label809;
          bool3 = false;
          break label894;
        }
        label1034: log("CMD_SET_ENABLE_FAIL_FAST_MOBILE_DATA: stop data stall");
        stopDataStallAlarm();
        continue;
        Bundle localBundle2 = paramMessage.getData();
        if (localBundle2 != null);
        try
        {
          this.mProvisioningUrl = ((String)localBundle2.get("provisioningUrl"));
          if (TextUtils.isEmpty(this.mProvisioningUrl))
          {
            loge("CMD_ENABLE_MOBILE_PROVISIONING: provisioning url is empty, ignoring");
            this.mIsProvisioning = false;
            this.mProvisioningUrl = null;
          }
        }
        catch (ClassCastException localClassCastException2)
        {
          while (true)
          {
            loge("CMD_ENABLE_MOBILE_PROVISIONING: provisioning url not a string" + localClassCastException2);
            this.mProvisioningUrl = null;
          }
          ApnContext localApnContext2 = (ApnContext)this.mApnContexts.get("default");
          if ((localApnContext2.isProvisioningApn()) && (localApnContext2.getState() == DctConstants.State.CONNECTED))
          {
            log("CMD_ENABLE_MOBILE_PROVISIONING: mIsProvisioning=true url=" + this.mProvisioningUrl);
            this.mIsProvisioning = true;
            startProvisioningApnAlarm();
            completeConnection((ApnContext)this.mApnContexts.get("default"));
            continue;
          }
          log("CMD_ENABLE_MOBILE_PROVISIONING: No longer connected");
          this.mIsProvisioning = false;
          this.mProvisioningUrl = null;
        }
        continue;
        log("EVENT_PROVISIONING_APN_ALARM");
        ApnContext localApnContext1 = (ApnContext)this.mApnContexts.get("default");
        if ((localApnContext1.isProvisioningApn()) && (localApnContext1.isConnectedOrConnecting()))
        {
          if (this.mProvisioningApnAlarmTag == paramMessage.arg1)
          {
            log("EVENT_PROVISIONING_APN_ALARM: Disconnecting");
            this.mIsProvisioning = false;
            this.mProvisioningUrl = null;
            stopProvisioningApnAlarm();
            sendCleanUpConnection(true, localApnContext1);
          }
          else
          {
            log("EVENT_PROVISIONING_APN_ALARM: ignore stale tag, mProvisioningApnAlarmTag:" + this.mProvisioningApnAlarmTag + " != arg1:" + paramMessage.arg1);
          }
        }
        else
        {
          log("EVENT_PROVISIONING_APN_ALARM: Not connected ignore");
          continue;
          log("CMD_IS_PROVISIONING_APN");
          String str1 = null;
          try
          {
            Bundle localBundle1 = paramMessage.getData();
            if (localBundle1 != null)
              str1 = (String)localBundle1.get("apnType");
            if (TextUtils.isEmpty(str1))
              loge("CMD_IS_PROVISIONING_APN: apnType is empty");
            boolean bool2;
            for (bool1 = false; ; bool1 = bool2)
            {
              log("CMD_IS_PROVISIONING_APN: ret=" + bool1);
              AsyncChannel localAsyncChannel = this.mReplyAc;
              if (!bool1)
                break label1509;
              i = 1;
              localAsyncChannel.replyToMessage(paramMessage, 270374, i);
              break;
              bool2 = isProvisioningApn(str1);
            }
          }
          catch (ClassCastException localClassCastException1)
          {
            while (true)
            {
              loge("CMD_IS_PROVISIONING_APN: NO provisioning url ignoring");
              boolean bool1 = false;
              continue;
              label1509: int i = 0;
            }
          }
          onUpdateIcc();
          continue;
          restartRadio();
        }
      }
    }
  }

  protected boolean isApnIdEnabled(int paramInt)
  {
    if (paramInt != -1);
    try
    {
      int i = this.mDataEnabled[paramInt];
      return i;
      int j = 0;
    }
    finally
    {
    }
  }

  public boolean isApnTypeActive(String paramString)
  {
    boolean bool = true;
    if ("dun".equals(paramString))
    {
      ApnSetting localApnSetting = fetchDunApn();
      if (localApnSetting != null)
        if ((this.mActiveApn == null) || (!localApnSetting.toString().equals(this.mActiveApn.toString())));
    }
    while (true)
    {
      return bool;
      bool = false;
      continue;
      if ((this.mActiveApn == null) || (!this.mActiveApn.canHandleType(paramString)))
        bool = false;
    }
  }

  protected abstract boolean isApnTypeAvailable(String paramString);

  public boolean isApnTypeEnabled(String paramString)
  {
    if (paramString == null);
    for (boolean bool = false; ; bool = isApnIdEnabled(apnTypeToId(paramString)))
      return bool;
  }

  protected boolean isConnected()
  {
    return false;
  }

  protected abstract boolean isDataAllowed();

  public abstract boolean isDataPossible(String paramString);

  public abstract boolean isDisconnected();

  protected boolean isEmergency()
  {
    while (true)
    {
      synchronized (this.mDataEnabledLock)
      {
        if (!this.mPhone.isInEcm())
          if (this.mPhone.isInEmergencyCall())
          {
            break label68;
            log("isEmergency: result=" + bool);
            return bool;
          }
          else
          {
            bool = false;
          }
      }
      label68: boolean bool = true;
    }
  }

  protected abstract boolean isProvisioningApn(String paramString);

  protected abstract void log(String paramString);

  protected abstract void loge(String paramString);

  protected void notifyDataConnection(String paramString)
  {
    for (int i = 0; i < 9; i++)
      if (this.mDataEnabled[i] != 0)
        this.mPhone.notifyDataConnection(paramString, apnIdToType(i));
    notifyOffApnsOfAvailability(paramString);
  }

  protected void notifyOffApnsOfAvailability(String paramString)
  {
    log("notifyOffApnsOfAvailability - reason= " + paramString);
    for (int i = 0; i < 9; i++)
      if (!isApnIdEnabled(i))
        notifyApnIdDisconnected(paramString, i);
  }

  protected void onActionIntentDataStallAlarm(Intent paramIntent)
  {
    log("onActionIntentDataStallAlarm: action=" + paramIntent.getAction());
    Message localMessage = obtainMessage(270353, paramIntent.getAction());
    localMessage.arg1 = paramIntent.getIntExtra("data.stall.alram.tag", 0);
    sendMessage(localMessage);
  }

  protected void onActionIntentProvisioningApnAlarm(Intent paramIntent)
  {
    log("onActionIntentProvisioningApnAlarm: action=" + paramIntent.getAction());
    Message localMessage = obtainMessage(270375, paramIntent.getAction());
    localMessage.arg1 = paramIntent.getIntExtra("provisioning.apn.alarm.tag", 0);
    sendMessage(localMessage);
  }

  protected void onActionIntentReconnectAlarm(Intent paramIntent)
  {
    String str1 = paramIntent.getStringExtra("reconnect_alarm_extra_reason");
    String str2 = paramIntent.getStringExtra("reconnect_alarm_extra_type");
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(str2);
    log("onActionIntentReconnectAlarm: mState=" + this.mState + " reason=" + str1 + " apnType=" + str2 + " apnContext=" + localApnContext + " mDataConnectionAsyncChannels=" + this.mDataConnectionAcHashMap);
    if ((localApnContext != null) && (localApnContext.isEnabled()))
    {
      localApnContext.setReason(str1);
      DctConstants.State localState = localApnContext.getState();
      log("onActionIntentReconnectAlarm: apnContext state=" + localState);
      if ((localState != DctConstants.State.FAILED) && (localState != DctConstants.State.IDLE))
        break label230;
      log("onActionIntentReconnectAlarm: state is FAILED|IDLE, disassociate");
      DcAsyncChannel localDcAsyncChannel = localApnContext.getDcAc();
      if (localDcAsyncChannel != null)
        localDcAsyncChannel.tearDown(localApnContext, "", null);
      localApnContext.setDataConnectionAc(null);
      localApnContext.setState(DctConstants.State.IDLE);
    }
    while (true)
    {
      sendMessage(obtainMessage(270339, localApnContext));
      localApnContext.setReconnectIntent(null);
      return;
      label230: log("onActionIntentReconnectAlarm: keep associated");
    }
  }

  protected void onActionIntentRestartTrySetupAlarm(Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("restart_trysetup_alarm_extra_type");
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(str);
    log("onActionIntentRestartTrySetupAlarm: mState=" + this.mState + " apnType=" + str + " apnContext=" + localApnContext + " mDataConnectionAsyncChannels=" + this.mDataConnectionAcHashMap);
    sendMessage(obtainMessage(270339, localApnContext));
  }

  protected abstract void onCleanUpAllConnections(String paramString);

  protected abstract void onCleanUpConnection(boolean paramBoolean, int paramInt, String paramString);

  protected abstract void onDataSetupComplete(AsyncResult paramAsyncResult);

  protected abstract void onDataSetupCompleteError(AsyncResult paramAsyncResult);

  protected void onDataStallAlarm(int paramInt)
  {
    if (this.mDataStallAlarmTag != paramInt)
    {
      log("onDataStallAlarm: ignore, tag=" + paramInt + " expecting " + this.mDataStallAlarmTag);
      return;
    }
    updateDataStallInfo();
    int i = Settings.Global.getInt(this.mResolver, "pdp_watchdog_trigger_packet_count", 10);
    boolean bool = false;
    if (this.mSentSinceLastRecv >= i)
    {
      log("onDataStallAlarm: tag=" + paramInt + " do recovery action=" + getRecoveryAction());
      bool = true;
      sendMessage(obtainMessage(270354));
    }
    while (true)
    {
      startDataStallAlarm(bool);
      break;
      log("onDataStallAlarm: tag=" + paramInt + " Sent " + String.valueOf(this.mSentSinceLastRecv) + " pkts since last received, < watchdogTrigger=" + i);
    }
  }

  protected abstract void onDisconnectDcRetrying(int paramInt, AsyncResult paramAsyncResult);

  protected abstract void onDisconnectDone(int paramInt, AsyncResult paramAsyncResult);

  protected void onEnableApn(int paramInt1, int paramInt2)
  {
    log("EVENT_APN_ENABLE_REQUEST apnId=" + paramInt1 + ", apnType=" + apnIdToType(paramInt1) + ", enabled=" + paramInt2 + ", dataEnabled = " + this.mDataEnabled[paramInt1] + ", enabledCount = " + this.mEnabledCount + ", isApnTypeActive = " + isApnTypeActive(apnIdToType(paramInt1)));
    if (paramInt2 == 1);
    while (true)
    {
      try
      {
        if (this.mDataEnabled[paramInt1] == 0)
        {
          this.mDataEnabled[paramInt1] = true;
          this.mEnabledCount = (1 + this.mEnabledCount);
        }
        String str = apnIdToType(paramInt1);
        if (!isApnTypeActive(str))
        {
          this.mRequestedApnType = str;
          onEnableNewApn();
          return;
        }
      }
      finally
      {
      }
      notifyApnIdUpToCurrent("apnSwitched", paramInt1);
      continue;
      int i = 0;
      try
      {
        if (this.mDataEnabled[paramInt1] != 0)
        {
          this.mDataEnabled[paramInt1] = false;
          this.mEnabledCount = (-1 + this.mEnabledCount);
          i = 1;
        }
        if (i == 0)
          continue;
        if ((this.mEnabledCount == 0) || (paramInt1 == 3))
        {
          this.mRequestedApnType = "default";
          onCleanUpConnection(true, paramInt1, "dataDisabled");
        }
        notifyApnIdDisconnected("dataDisabled", paramInt1);
        if ((this.mDataEnabled[0] != 1) || (isApnTypeActive("default")))
          continue;
        this.mRequestedApnType = "default";
        onEnableNewApn();
      }
      finally
      {
      }
    }
  }

  protected void onEnableNewApn()
  {
  }

  protected abstract void onRadioAvailable();

  protected abstract void onRadioOffOrNotAvailable();

  protected void onResetDone(AsyncResult paramAsyncResult)
  {
    log("EVENT_RESET_DONE");
    String str = null;
    if ((paramAsyncResult.userObj instanceof String))
      str = (String)paramAsyncResult.userObj;
    gotoIdleAndNotifyDataConnection(str);
  }

  protected abstract void onRoamingOff();

  protected abstract void onRoamingOn();

  protected void onSetDependencyMet(String paramString, boolean paramBoolean)
  {
  }

  protected void onSetInternalDataEnabled(boolean paramBoolean)
  {
    synchronized (this.mDataEnabledLock)
    {
      this.mInternalDataEnabled = paramBoolean;
      if (paramBoolean)
      {
        log("onSetInternalDataEnabled: changed to enabled, try to setup data call");
        onTrySetupData("dataEnabled");
        return;
      }
      log("onSetInternalDataEnabled: changed to disabled, cleanUpAllConnections");
      cleanUpAllConnections(null);
    }
  }

  protected void onSetPolicyDataEnabled(boolean paramBoolean)
  {
    synchronized (this.mDataEnabledLock)
    {
      boolean bool = getAnyDataEnabled();
      if (sPolicyDataEnabled != paramBoolean)
      {
        sPolicyDataEnabled = paramBoolean;
        if (bool != getAnyDataEnabled())
        {
          if (bool)
            break label49;
          onTrySetupData("dataEnabled");
        }
      }
      return;
      label49: onCleanUpAllConnections("dataDisabled");
    }
  }

  // ERROR //
  protected void onSetUserDataEnabled(boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 195	com/android/internal/telephony/dataconnection/DcTrackerBase:mDataEnabledLock	Ljava/lang/Object;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: aload_0
    //   8: invokevirtual 1423	com/android/internal/telephony/dataconnection/DcTrackerBase:getAnyDataEnabled	()Z
    //   11: istore 4
    //   13: aload_0
    //   14: getfield 199	com/android/internal/telephony/dataconnection/DcTrackerBase:mUserDataEnabled	Z
    //   17: iload_1
    //   18: if_icmpeq +92 -> 110
    //   21: aload_0
    //   22: iload_1
    //   23: putfield 199	com/android/internal/telephony/dataconnection/DcTrackerBase:mUserDataEnabled	Z
    //   26: aload_0
    //   27: getfield 339	com/android/internal/telephony/dataconnection/DcTrackerBase:mPhone	Lcom/android/internal/telephony/PhoneBase;
    //   30: invokevirtual 345	com/android/internal/telephony/PhoneBase:getContext	()Landroid/content/Context;
    //   33: invokevirtual 351	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   36: astore 5
    //   38: iload_1
    //   39: ifeq +99 -> 138
    //   42: iconst_1
    //   43: istore 6
    //   45: aload 5
    //   47: ldc_w 398
    //   50: iload 6
    //   52: invokestatic 1427	android/provider/Settings$Global:putInt	(Landroid/content/ContentResolver;Ljava/lang/String;I)Z
    //   55: pop
    //   56: aload_0
    //   57: invokevirtual 1429	com/android/internal/telephony/dataconnection/DcTrackerBase:getDataOnRoamingEnabled	()Z
    //   60: ifne +28 -> 88
    //   63: aload_0
    //   64: getfield 339	com/android/internal/telephony/dataconnection/DcTrackerBase:mPhone	Lcom/android/internal/telephony/PhoneBase;
    //   67: invokevirtual 1042	com/android/internal/telephony/PhoneBase:getServiceState	()Landroid/telephony/ServiceState;
    //   70: invokevirtual 1432	android/telephony/ServiceState:getRoaming	()Z
    //   73: iconst_1
    //   74: if_icmpne +14 -> 88
    //   77: iload_1
    //   78: ifeq +35 -> 113
    //   81: aload_0
    //   82: ldc_w 1434
    //   85: invokevirtual 1292	com/android/internal/telephony/dataconnection/DcTrackerBase:notifyOffApnsOfAvailability	(Ljava/lang/String;)V
    //   88: iload 4
    //   90: aload_0
    //   91: invokevirtual 1423	com/android/internal/telephony/dataconnection/DcTrackerBase:getAnyDataEnabled	()Z
    //   94: if_icmpeq +16 -> 110
    //   97: iload 4
    //   99: ifne +29 -> 128
    //   102: aload_0
    //   103: ldc_w 1419
    //   106: invokevirtual 1097	com/android/internal/telephony/dataconnection/DcTrackerBase:onTrySetupData	(Ljava/lang/String;)Z
    //   109: pop
    //   110: aload_2
    //   111: monitorexit
    //   112: return
    //   113: aload_0
    //   114: ldc_w 1410
    //   117: invokevirtual 1292	com/android/internal/telephony/dataconnection/DcTrackerBase:notifyOffApnsOfAvailability	(Ljava/lang/String;)V
    //   120: goto -32 -> 88
    //   123: astore_3
    //   124: aload_2
    //   125: monitorexit
    //   126: aload_3
    //   127: athrow
    //   128: aload_0
    //   129: ldc_w 1410
    //   132: invokevirtual 1141	com/android/internal/telephony/dataconnection/DcTrackerBase:onCleanUpAllConnections	(Ljava/lang/String;)V
    //   135: goto -25 -> 110
    //   138: iconst_0
    //   139: istore 6
    //   141: goto -96 -> 45
    //
    // Exception table:
    //   from	to	target	type
    //   7	126	123	finally
    //   128	135	123	finally
  }

  protected abstract boolean onTrySetupData(String paramString);

  protected abstract void onUpdateIcc();

  protected abstract void onVoiceCallEnded();

  protected abstract void onVoiceCallStarted();

  public void putRecoveryAction(int paramInt)
  {
    Settings.System.putInt(this.mPhone.getContext().getContentResolver(), "radio.data.stall.recovery.action", paramInt);
    log("putRecoveryAction: " + paramInt);
  }

  protected void resetPollStats()
  {
    this.mTxPkts = -1L;
    this.mRxPkts = -1L;
    this.mNetStatPollPeriod = 1000;
  }

  protected void restartDataStallAlarm()
  {
    if (!isConnected());
    while (true)
    {
      return;
      if (RecoveryAction.isAggressiveRecovery(getRecoveryAction()))
      {
        log("restartDataStallAlarm: action is pending. not resetting the alarm.");
      }
      else
      {
        log("restartDataStallAlarm: stop then start.");
        stopDataStallAlarm();
        startDataStallAlarm(false);
      }
    }
  }

  protected abstract void restartRadio();

  void sendCleanUpConnection(boolean paramBoolean, ApnContext paramApnContext)
  {
    log("sendCleanUpConnection: tearDown=" + paramBoolean + " apnContext=" + paramApnContext);
    Message localMessage = obtainMessage(270360);
    if (paramBoolean);
    for (int i = 1; ; i = 0)
    {
      localMessage.arg1 = i;
      localMessage.arg2 = 0;
      localMessage.obj = paramApnContext;
      sendMessage(localMessage);
      return;
    }
  }

  void sendRestartRadio()
  {
    log("sendRestartRadio:");
    sendMessage(obtainMessage(270362));
  }

  public void setDataOnRoamingEnabled(boolean paramBoolean)
  {
    ContentResolver localContentResolver;
    if (getDataOnRoamingEnabled() != paramBoolean)
    {
      localContentResolver = this.mPhone.getContext().getContentResolver();
      if (!paramBoolean)
        break label35;
    }
    label35: for (int i = 1; ; i = 0)
    {
      Settings.Global.putInt(localContentResolver, "data_roaming", i);
      return;
    }
  }

  protected void setEnabled(int paramInt, boolean paramBoolean)
  {
    log("setEnabled(" + paramInt + ", " + paramBoolean + ") with old state = " + this.mDataEnabled[paramInt] + " and enabledCount = " + this.mEnabledCount);
    Message localMessage = obtainMessage(270349);
    localMessage.arg1 = paramInt;
    if (paramBoolean);
    for (int i = 1; ; i = 0)
    {
      localMessage.arg2 = i;
      sendMessage(localMessage);
      return;
    }
  }

  protected void setInitialAttachApn()
  {
    Object localObject1 = null;
    Object localObject2 = null;
    ApnSetting localApnSetting1 = null;
    log("setInitialApn: E mPreferredApn=" + this.mPreferredApn);
    Iterator localIterator;
    if ((this.mAllApnSettings != null) && (!this.mAllApnSettings.isEmpty()))
    {
      localApnSetting1 = (ApnSetting)this.mAllApnSettings.get(0);
      log("setInitialApn: firstApnSetting=" + localApnSetting1);
      localIterator = this.mAllApnSettings.iterator();
    }
    label176: label355: 
    while (true)
    {
      ApnSetting localApnSetting2;
      Object localObject3;
      if (localIterator.hasNext())
      {
        localApnSetting2 = (ApnSetting)localIterator.next();
        if (ArrayUtils.contains(localApnSetting2.types, "ia"))
        {
          log("setInitialApn: iaApnSetting=" + localApnSetting2);
          localObject1 = localApnSetting2;
        }
      }
      else
      {
        localObject3 = null;
        if (localObject1 == null)
          break label234;
        log("setInitialAttachApn: using iaApnSetting");
        localObject3 = localObject1;
        if (localObject3 != null)
          break label291;
        log("setInitialAttachApn: X There in no available apn");
      }
      while (true)
      {
        return;
        if ((localObject2 != null) || (!localApnSetting2.canHandleType("default")))
          break label355;
        log("setInitialApn: defaultApnSetting=" + localApnSetting2);
        localObject2 = localApnSetting2;
        break;
        label234: if (this.mPreferredApn != null)
        {
          log("setInitialAttachApn: using mPreferredApn");
          localObject3 = this.mPreferredApn;
          break label176;
        }
        if (localObject2 != null)
        {
          log("setInitialAttachApn: using defaultApnSetting");
          localObject3 = localObject2;
          break label176;
        }
        if (localApnSetting1 == null)
          break label176;
        log("setInitialAttachApn: using firstApnSetting");
        localObject3 = localApnSetting1;
        break label176;
        log("setInitialAttachApn: X selected Apn=" + localObject3);
        this.mPhone.mCi.setInitialAttachApn(((ApnSetting)localObject3).apn, ((ApnSetting)localObject3).protocol, ((ApnSetting)localObject3).authType, ((ApnSetting)localObject3).user, ((ApnSetting)localObject3).password, null);
      }
    }
  }

  public boolean setInternalDataEnabled(boolean paramBoolean)
  {
    log("setInternalDataEnabled(" + paramBoolean + ")");
    Message localMessage = obtainMessage(270363);
    if (paramBoolean);
    for (int i = 1; ; i = 0)
    {
      localMessage.arg1 = i;
      sendMessage(localMessage);
      return true;
    }
  }

  protected abstract void setState(DctConstants.State paramState);

  protected void startDataStallAlarm(boolean paramBoolean)
  {
    int i = getRecoveryAction();
    int j;
    if ((this.mDataStallDetectionEnabled) && (getOverallState() == DctConstants.State.CONNECTED))
      if ((this.mIsScreenOn) || (paramBoolean) || (RecoveryAction.isAggressiveRecovery(i)))
      {
        j = Settings.Global.getInt(this.mResolver, "data_stall_alarm_aggressive_delay_in_ms", 60000);
        this.mDataStallAlarmTag = (1 + this.mDataStallAlarmTag);
        log("startDataStallAlarm: tag=" + this.mDataStallAlarmTag + " delay=" + j / 1000 + "s");
        Intent localIntent = new Intent("com.android.internal.telephony.data-stall");
        localIntent.putExtra("data.stall.alram.tag", this.mDataStallAlarmTag);
        this.mDataStallAlarmIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, localIntent, 134217728);
        this.mAlarmManager.set(2, SystemClock.elapsedRealtime() + j, this.mDataStallAlarmIntent);
      }
    while (true)
    {
      return;
      j = Settings.Global.getInt(this.mResolver, "data_stall_alarm_non_aggressive_delay_in_ms", 360000);
      break;
      log("startDataStallAlarm: NOT started, no connection tag=" + this.mDataStallAlarmTag);
    }
  }

  protected void startNetStatPoll()
  {
    if ((getOverallState() == DctConstants.State.CONNECTED) && (!this.mNetStatPollEnabled))
    {
      log("startNetStatPoll");
      resetPollStats();
      this.mNetStatPollEnabled = true;
      this.mPollNetStat.run();
    }
  }

  protected void startProvisioningApnAlarm()
  {
    int i = Settings.Global.getInt(this.mResolver, "provisioning_apn_alarm_delay_in_ms", 900000);
    String str;
    if (Build.IS_DEBUGGABLE)
      str = System.getProperty("persist.debug.prov_apn_alarm", Integer.toString(i));
    try
    {
      int j = Integer.parseInt(str);
      i = j;
      this.mProvisioningApnAlarmTag = (1 + this.mProvisioningApnAlarmTag);
      log("startProvisioningApnAlarm: tag=" + this.mProvisioningApnAlarmTag + " delay=" + i / 1000 + "s");
      Intent localIntent = new Intent("com.android.internal.telephony.provisioning_apn_alarm");
      localIntent.putExtra("provisioning.apn.alarm.tag", this.mProvisioningApnAlarmTag);
      this.mProvisioningApnAlarmIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, localIntent, 134217728);
      this.mAlarmManager.set(2, SystemClock.elapsedRealtime() + i, this.mProvisioningApnAlarmIntent);
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
        loge("startProvisioningApnAlarm: e=" + localNumberFormatException);
    }
  }

  protected void stopDataStallAlarm()
  {
    log("stopDataStallAlarm: current tag=" + this.mDataStallAlarmTag + " mDataStallAlarmIntent=" + this.mDataStallAlarmIntent);
    this.mDataStallAlarmTag = (1 + this.mDataStallAlarmTag);
    if (this.mDataStallAlarmIntent != null)
    {
      this.mAlarmManager.cancel(this.mDataStallAlarmIntent);
      this.mDataStallAlarmIntent = null;
    }
  }

  protected void stopNetStatPoll()
  {
    this.mNetStatPollEnabled = false;
    removeCallbacks(this.mPollNetStat);
    log("stopNetStatPoll");
  }

  protected void stopProvisioningApnAlarm()
  {
    log("stopProvisioningApnAlarm: current tag=" + this.mProvisioningApnAlarmTag + " mProvsioningApnAlarmIntent=" + this.mProvisioningApnAlarmIntent);
    this.mProvisioningApnAlarmTag = (1 + this.mProvisioningApnAlarmTag);
    if (this.mProvisioningApnAlarmIntent != null)
    {
      this.mAlarmManager.cancel(this.mProvisioningApnAlarmIntent);
      this.mProvisioningApnAlarmIntent = null;
    }
  }

  public void updateDataActivity()
  {
    TxRxSum localTxRxSum1 = new TxRxSum(this.mTxPkts, this.mRxPkts);
    TxRxSum localTxRxSum2 = new TxRxSum();
    localTxRxSum2.updateTxRxSum();
    this.mTxPkts = localTxRxSum2.txPkts;
    this.mRxPkts = localTxRxSum2.rxPkts;
    long l1;
    long l2;
    if ((this.mNetStatPollEnabled) && ((localTxRxSum1.txPkts > 0L) || (localTxRxSum1.rxPkts > 0L)))
    {
      l1 = this.mTxPkts - localTxRxSum1.txPkts;
      l2 = this.mRxPkts - localTxRxSum1.rxPkts;
      if ((l1 <= 0L) || (l2 <= 0L))
        break label140;
      localActivity = DctConstants.Activity.DATAINANDOUT;
    }
    while (true)
    {
      if ((this.mActivity != localActivity) && (this.mIsScreenOn))
      {
        this.mActivity = localActivity;
        this.mPhone.notifyDataActivity();
      }
      return;
      label140: if ((l1 > 0L) && (l2 == 0L))
      {
        localActivity = DctConstants.Activity.DATAOUT;
      }
      else
      {
        if ((l1 != 0L) || (l2 <= 0L))
          break;
        localActivity = DctConstants.Activity.DATAIN;
      }
    }
    if (this.mActivity == DctConstants.Activity.DORMANT);
    for (DctConstants.Activity localActivity = this.mActivity; ; localActivity = DctConstants.Activity.NONE)
      break;
  }

  private class DataRoamingSettingObserver extends ContentObserver
  {
    public DataRoamingSettingObserver(Handler paramContext, Context arg3)
    {
      super();
      Object localObject;
      DcTrackerBase.this.mResolver = localObject.getContentResolver();
    }

    public void onChange(boolean paramBoolean)
    {
      if (DcTrackerBase.this.mPhone.getServiceState().getRoaming())
        DcTrackerBase.this.sendMessage(DcTrackerBase.this.obtainMessage(270347));
    }

    public void register()
    {
      DcTrackerBase.this.mResolver.registerContentObserver(Settings.Global.getUriFor("data_roaming"), false, this);
    }

    public void unregister()
    {
      DcTrackerBase.this.mResolver.unregisterContentObserver(this);
    }
  }

  protected static class RecoveryAction
  {
    public static final int CLEANUP = 1;
    public static final int GET_DATA_CALL_LIST = 0;
    public static final int RADIO_RESTART = 3;
    public static final int RADIO_RESTART_WITH_PROP = 4;
    public static final int REREGISTER = 2;

    private static boolean isAggressiveRecovery(int paramInt)
    {
      int i = 1;
      if ((paramInt == i) || (paramInt == 2) || (paramInt == 3) || (paramInt == 4));
      while (true)
      {
        return i;
        i = 0;
      }
    }
  }

  public class TxRxSum
  {
    public long rxPkts;
    public long txPkts;

    public TxRxSum()
    {
      reset();
    }

    public TxRxSum(long arg2, long arg4)
    {
      this.txPkts = ???;
      Object localObject;
      this.rxPkts = localObject;
    }

    public TxRxSum(TxRxSum arg2)
    {
      Object localObject;
      this.txPkts = localObject.txPkts;
      this.rxPkts = localObject.rxPkts;
    }

    public void reset()
    {
      this.txPkts = -1L;
      this.rxPkts = -1L;
    }

    public String toString()
    {
      return "{txSum=" + this.txPkts + " rxSum=" + this.rxPkts + "}";
    }

    public void updateTxRxSum()
    {
      this.txPkts = TrafficStats.getMobileTxPackets();
      this.rxPkts = TrafficStats.getMobileRxPackets();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcTrackerBase
 * JD-Core Version:    0.6.2
 */