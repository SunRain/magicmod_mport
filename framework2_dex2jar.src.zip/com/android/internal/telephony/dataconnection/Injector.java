package com.android.internal.telephony.dataconnection;

import android.content.Context;
import android.net.LinkProperties;
import android.provider.Settings.System;
import com.android.internal.telephony.DctConstants.State;
import com.android.internal.telephony.PhoneBase;
import java.util.concurrent.ConcurrentHashMap;
import miui.net.FirewallManager;

class Injector
{
  static class DcTrackerHook
  {
    public static boolean isMmsDataEnabled(DcTracker paramDcTracker)
    {
      int i = 1;
      ApnContext localApnContext = (ApnContext)paramDcTracker.mApnContexts.get("mms");
      if ((localApnContext != null) && (localApnContext.isEnabled()) && (Settings.System.getInt(paramDcTracker.mPhone.getContext().getContentResolver(), "always_enable_mms", i) == i));
      while (true)
      {
        return i;
        int j = 0;
      }
    }

    public static void onDataSetupComplete(ApnContext paramApnContext, ApnSetting paramApnSetting)
    {
      if ((paramApnSetting != null) && (paramApnContext.getState() == DctConstants.State.CONNECTED))
      {
        DcAsyncChannel localDcAsyncChannel = paramApnContext.getDcAc();
        if (localDcAsyncChannel != null)
          FirewallManager.getInstance().onDataConnected(0, FirewallManager.encodeApnSetting(paramApnSetting), localDcAsyncChannel.getLinkPropertiesSync().getInterfaceName());
      }
    }

    public static void onDisconnectDone(ApnContext paramApnContext, ApnSetting paramApnSetting)
    {
      if ((paramApnSetting != null) && (paramApnContext.getState() != DctConstants.State.CONNECTED) && (paramApnContext.getDcAc() != null))
        FirewallManager.getInstance().onDataDisconnected(0, FirewallManager.encodeApnSetting(paramApnSetting));
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.Injector
 * JD-Core Version:    0.6.2
 */