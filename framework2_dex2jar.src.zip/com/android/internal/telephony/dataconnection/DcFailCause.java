package com.android.internal.telephony.dataconnection;

import java.util.HashMap;

public enum DcFailCause
{
  private static final HashMap<Integer, DcFailCause> sErrorCodeToFailCauseMap;
  private final int mErrorCode;

  static
  {
    INSUFFICIENT_RESOURCES = new DcFailCause("INSUFFICIENT_RESOURCES", 2, 26);
    MISSING_UNKNOWN_APN = new DcFailCause("MISSING_UNKNOWN_APN", 3, 27);
    UNKNOWN_PDP_ADDRESS_TYPE = new DcFailCause("UNKNOWN_PDP_ADDRESS_TYPE", 4, 28);
    USER_AUTHENTICATION = new DcFailCause("USER_AUTHENTICATION", 5, 29);
    ACTIVATION_REJECT_GGSN = new DcFailCause("ACTIVATION_REJECT_GGSN", 6, 30);
    ACTIVATION_REJECT_UNSPECIFIED = new DcFailCause("ACTIVATION_REJECT_UNSPECIFIED", 7, 31);
    SERVICE_OPTION_NOT_SUPPORTED = new DcFailCause("SERVICE_OPTION_NOT_SUPPORTED", 8, 32);
    SERVICE_OPTION_NOT_SUBSCRIBED = new DcFailCause("SERVICE_OPTION_NOT_SUBSCRIBED", 9, 33);
    SERVICE_OPTION_OUT_OF_ORDER = new DcFailCause("SERVICE_OPTION_OUT_OF_ORDER", 10, 34);
    NSAPI_IN_USE = new DcFailCause("NSAPI_IN_USE", 11, 35);
    REGULAR_DEACTIVATION = new DcFailCause("REGULAR_DEACTIVATION", 12, 36);
    ONLY_IPV4_ALLOWED = new DcFailCause("ONLY_IPV4_ALLOWED", 13, 50);
    ONLY_IPV6_ALLOWED = new DcFailCause("ONLY_IPV6_ALLOWED", 14, 51);
    ONLY_SINGLE_BEARER_ALLOWED = new DcFailCause("ONLY_SINGLE_BEARER_ALLOWED", 15, 52);
    PROTOCOL_ERRORS = new DcFailCause("PROTOCOL_ERRORS", 16, 111);
    REGISTRATION_FAIL = new DcFailCause("REGISTRATION_FAIL", 17, -1);
    GPRS_REGISTRATION_FAIL = new DcFailCause("GPRS_REGISTRATION_FAIL", 18, -2);
    SIGNAL_LOST = new DcFailCause("SIGNAL_LOST", 19, -3);
    PREF_RADIO_TECH_CHANGED = new DcFailCause("PREF_RADIO_TECH_CHANGED", 20, -4);
    RADIO_POWER_OFF = new DcFailCause("RADIO_POWER_OFF", 21, -5);
    TETHERED_CALL_ACTIVE = new DcFailCause("TETHERED_CALL_ACTIVE", 22, -6);
    ERROR_UNSPECIFIED = new DcFailCause("ERROR_UNSPECIFIED", 23, 65535);
    UNKNOWN = new DcFailCause("UNKNOWN", 24, 65536);
    RADIO_NOT_AVAILABLE = new DcFailCause("RADIO_NOT_AVAILABLE", 25, 65537);
    UNACCEPTABLE_NETWORK_PARAMETER = new DcFailCause("UNACCEPTABLE_NETWORK_PARAMETER", 26, 65538);
    CONNECTION_TO_DATACONNECTIONAC_BROKEN = new DcFailCause("CONNECTION_TO_DATACONNECTIONAC_BROKEN", 27, 65539);
    LOST_CONNECTION = new DcFailCause("LOST_CONNECTION", 28, 65540);
    RESET_BY_FRAMEWORK = new DcFailCause("RESET_BY_FRAMEWORK", 29, 65541);
    DcFailCause[] arrayOfDcFailCause1 = new DcFailCause[30];
    arrayOfDcFailCause1[0] = NONE;
    arrayOfDcFailCause1[1] = OPERATOR_BARRED;
    arrayOfDcFailCause1[2] = INSUFFICIENT_RESOURCES;
    arrayOfDcFailCause1[3] = MISSING_UNKNOWN_APN;
    arrayOfDcFailCause1[4] = UNKNOWN_PDP_ADDRESS_TYPE;
    arrayOfDcFailCause1[5] = USER_AUTHENTICATION;
    arrayOfDcFailCause1[6] = ACTIVATION_REJECT_GGSN;
    arrayOfDcFailCause1[7] = ACTIVATION_REJECT_UNSPECIFIED;
    arrayOfDcFailCause1[8] = SERVICE_OPTION_NOT_SUPPORTED;
    arrayOfDcFailCause1[9] = SERVICE_OPTION_NOT_SUBSCRIBED;
    arrayOfDcFailCause1[10] = SERVICE_OPTION_OUT_OF_ORDER;
    arrayOfDcFailCause1[11] = NSAPI_IN_USE;
    arrayOfDcFailCause1[12] = REGULAR_DEACTIVATION;
    arrayOfDcFailCause1[13] = ONLY_IPV4_ALLOWED;
    arrayOfDcFailCause1[14] = ONLY_IPV6_ALLOWED;
    arrayOfDcFailCause1[15] = ONLY_SINGLE_BEARER_ALLOWED;
    arrayOfDcFailCause1[16] = PROTOCOL_ERRORS;
    arrayOfDcFailCause1[17] = REGISTRATION_FAIL;
    arrayOfDcFailCause1[18] = GPRS_REGISTRATION_FAIL;
    arrayOfDcFailCause1[19] = SIGNAL_LOST;
    arrayOfDcFailCause1[20] = PREF_RADIO_TECH_CHANGED;
    arrayOfDcFailCause1[21] = RADIO_POWER_OFF;
    arrayOfDcFailCause1[22] = TETHERED_CALL_ACTIVE;
    arrayOfDcFailCause1[23] = ERROR_UNSPECIFIED;
    arrayOfDcFailCause1[24] = UNKNOWN;
    arrayOfDcFailCause1[25] = RADIO_NOT_AVAILABLE;
    arrayOfDcFailCause1[26] = UNACCEPTABLE_NETWORK_PARAMETER;
    arrayOfDcFailCause1[27] = CONNECTION_TO_DATACONNECTIONAC_BROKEN;
    arrayOfDcFailCause1[28] = LOST_CONNECTION;
    arrayOfDcFailCause1[29] = RESET_BY_FRAMEWORK;
    $VALUES = arrayOfDcFailCause1;
    sErrorCodeToFailCauseMap = new HashMap();
    for (DcFailCause localDcFailCause : values())
      sErrorCodeToFailCauseMap.put(Integer.valueOf(localDcFailCause.getErrorCode()), localDcFailCause);
  }

  private DcFailCause(int paramInt)
  {
    this.mErrorCode = paramInt;
  }

  public static DcFailCause fromInt(int paramInt)
  {
    DcFailCause localDcFailCause = (DcFailCause)sErrorCodeToFailCauseMap.get(Integer.valueOf(paramInt));
    if (localDcFailCause == null)
      localDcFailCause = UNKNOWN;
    return localDcFailCause;
  }

  public int getErrorCode()
  {
    return this.mErrorCode;
  }

  public boolean isEventLoggable()
  {
    if ((this == OPERATOR_BARRED) || (this == INSUFFICIENT_RESOURCES) || (this == UNKNOWN_PDP_ADDRESS_TYPE) || (this == USER_AUTHENTICATION) || (this == ACTIVATION_REJECT_GGSN) || (this == ACTIVATION_REJECT_UNSPECIFIED) || (this == SERVICE_OPTION_NOT_SUBSCRIBED) || (this == SERVICE_OPTION_NOT_SUPPORTED) || (this == SERVICE_OPTION_OUT_OF_ORDER) || (this == NSAPI_IN_USE) || (this == ONLY_IPV4_ALLOWED) || (this == ONLY_IPV6_ALLOWED) || (this == PROTOCOL_ERRORS) || (this == SIGNAL_LOST) || (this == RADIO_POWER_OFF) || (this == TETHERED_CALL_ACTIVE) || (this == UNACCEPTABLE_NETWORK_PARAMETER));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isPermanentFail()
  {
    if ((this == OPERATOR_BARRED) || (this == MISSING_UNKNOWN_APN) || (this == UNKNOWN_PDP_ADDRESS_TYPE) || (this == USER_AUTHENTICATION) || (this == ACTIVATION_REJECT_GGSN) || (this == SERVICE_OPTION_NOT_SUPPORTED) || (this == SERVICE_OPTION_NOT_SUBSCRIBED) || (this == NSAPI_IN_USE) || (this == ONLY_IPV4_ALLOWED) || (this == ONLY_IPV6_ALLOWED) || (this == PROTOCOL_ERRORS) || (this == RADIO_POWER_OFF) || (this == TETHERED_CALL_ACTIVE) || (this == RADIO_NOT_AVAILABLE) || (this == UNACCEPTABLE_NETWORK_PARAMETER));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isRestartRadioFail()
  {
    if (this == REGULAR_DEACTIVATION);
    for (boolean bool = true; ; bool = false)
      return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcFailCause
 * JD-Core Version:    0.6.2
 */