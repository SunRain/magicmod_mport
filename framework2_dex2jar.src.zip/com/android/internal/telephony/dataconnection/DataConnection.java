package com.android.internal.telephony.dataconnection;

import android.app.PendingIntent;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.ProxyProperties;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Message;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import android.util.Pair;
import android.util.Patterns;
import android.util.TimeUtils;
import com.android.internal.telephony.CommandException;
import com.android.internal.telephony.CommandException.Error;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.RetryManager;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.util.AsyncChannel;
import com.android.internal.util.IState;
import com.android.internal.util.State;
import com.android.internal.util.StateMachine;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DataConnection extends StateMachine
{
  static final int BASE = 262144;
  private static final int CMD_TO_STRING_COUNT = 12;
  private static final boolean DBG = true;
  private static final String DEFAULT_DATA_RETRY_CONFIG = "default_randomization=2000,5000,10000,20000,40000,80000:5000,160000:5000,320000:5000,640000:5000,1280000:5000,1800000:5000";
  static final int EVENT_CONNECT = 262144;
  static final int EVENT_DATA_CONNECTION_DRS_OR_RAT_CHANGED = 262155;
  static final int EVENT_DATA_STATE_CHANGED = 262151;
  static final int EVENT_DEACTIVATE_DONE = 262147;
  static final int EVENT_DISCONNECT = 262148;
  static final int EVENT_DISCONNECT_ALL = 262150;
  static final int EVENT_GET_LAST_FAIL_DONE = 262146;
  static final int EVENT_LOST_CONNECTION = 262153;
  static final int EVENT_RETRY_CONNECTION = 262154;
  static final int EVENT_RIL_CONNECTED = 262149;
  static final int EVENT_SETUP_DATA_CONNECTION_DONE = 262145;
  static final int EVENT_TEAR_DOWN_NOW = 262152;
  private static final String NULL_IP = "0.0.0.0";
  private static final String SECONDARY_DATA_RETRY_CONFIG = "max_retries=3, 5000, 5000, 5000";
  private static final boolean VDBG = true;
  private static AtomicInteger mInstanceNumber = new AtomicInteger(0);
  private static String[] sCmdToString = new String[12];
  private AsyncChannel mAc;
  private DcActivatingState mActivatingState = new DcActivatingState(null);
  private DcActiveState mActiveState = new DcActiveState(null);
  List<ApnContext> mApnContexts = null;
  private ApnSetting mApnSetting;
  int mCid;
  private ConnectionParams mConnectionParams;
  private long mCreateTime;
  private int mDataRegState = 2147483647;
  private DcController mDcController;
  private DcFailCause mDcFailCause;
  private DcRetryAlarmController mDcRetryAlarmController;
  private DcTesterFailBringUpAll mDcTesterFailBringUpAll;
  private DcTrackerBase mDct = null;
  private DcDefaultState mDefaultState = new DcDefaultState(null);
  private DisconnectParams mDisconnectParams;
  private DcDisconnectionErrorCreatingConnection mDisconnectingErrorCreatingConnection = new DcDisconnectionErrorCreatingConnection(null);
  private DcDisconnectingState mDisconnectingState = new DcDisconnectingState(null);
  private int mId;
  private DcInactiveState mInactiveState = new DcInactiveState(null);
  private DcFailCause mLastFailCause;
  private long mLastFailTime;
  private LinkCapabilities mLinkCapabilities = new LinkCapabilities();
  private LinkProperties mLinkProperties = new LinkProperties();
  private PhoneBase mPhone;
  PendingIntent mReconnectIntent = null;
  RetryManager mRetryManager = new RetryManager();
  private DcRetryingState mRetryingState = new DcRetryingState(null);
  private int mRilRat = 2147483647;
  int mTag;
  private Object mUserData;

  static
  {
    sCmdToString[0] = "EVENT_CONNECT";
    sCmdToString[1] = "EVENT_SETUP_DATA_CONNECTION_DONE";
    sCmdToString[2] = "EVENT_GET_LAST_FAIL_DONE";
    sCmdToString[3] = "EVENT_DEACTIVATE_DONE";
    sCmdToString[4] = "EVENT_DISCONNECT";
    sCmdToString[5] = "EVENT_RIL_CONNECTED";
    sCmdToString[6] = "EVENT_DISCONNECT_ALL";
    sCmdToString[7] = "EVENT_DATA_STATE_CHANGED";
    sCmdToString[8] = "EVENT_TEAR_DOWN_NOW";
    sCmdToString[9] = "EVENT_LOST_CONNECTION";
    sCmdToString[10] = "EVENT_RETRY_CONNECTION";
    sCmdToString[11] = "EVENT_DATA_CONNECTION_DRS_OR_RAT_CHANGED";
  }

  private DataConnection(PhoneBase paramPhoneBase, String paramString, int paramInt, DcTrackerBase paramDcTrackerBase, DcTesterFailBringUpAll paramDcTesterFailBringUpAll, DcController paramDcController)
  {
    super(paramString, paramDcController.getHandler());
    setLogRecSize(300);
    setLogOnlyTransitions(true);
    log("DataConnection constructor E");
    this.mPhone = paramPhoneBase;
    this.mDct = paramDcTrackerBase;
    this.mDcTesterFailBringUpAll = paramDcTesterFailBringUpAll;
    this.mDcController = paramDcController;
    this.mId = paramInt;
    this.mCid = -1;
    this.mDcRetryAlarmController = new DcRetryAlarmController(this.mPhone, this);
    this.mRilRat = this.mPhone.getServiceState().getRilDataRadioTechnology();
    this.mDataRegState = this.mPhone.getServiceState().getDataRegState();
    addState(this.mDefaultState);
    addState(this.mInactiveState, this.mDefaultState);
    addState(this.mActivatingState, this.mDefaultState);
    addState(this.mRetryingState, this.mDefaultState);
    addState(this.mActiveState, this.mDefaultState);
    addState(this.mDisconnectingState, this.mDefaultState);
    addState(this.mDisconnectingErrorCreatingConnection, this.mDefaultState);
    setInitialState(this.mInactiveState);
    this.mApnContexts = new ArrayList();
    log("DataConnection constructor X");
  }

  private void clearSettings()
  {
    log("clearSettings");
    this.mCreateTime = -1L;
    this.mLastFailTime = -1L;
    this.mLastFailCause = DcFailCause.NONE;
    this.mCid = -1;
    this.mLinkProperties = new LinkProperties();
    this.mApnContexts.clear();
    this.mApnSetting = null;
    this.mDcFailCause = null;
  }

  static String cmdToString(int paramInt)
  {
    int i = paramInt - 262144;
    if ((i >= 0) && (i < sCmdToString.length));
    for (String str = sCmdToString[i]; ; str = DcAsyncChannel.cmdToString(i + 262144))
    {
      if (str == null)
        str = "0x" + Integer.toHexString(i + 262144);
      return str;
    }
  }

  private void configureRetry(boolean paramBoolean)
  {
    String str = getRetryConfig(paramBoolean);
    if (!this.mRetryManager.configure(str))
    {
      if (!paramBoolean)
        break label93;
      if (!this.mRetryManager.configure("default_randomization=2000,5000,10000,20000,40000,80000:5000,160000:5000,320000:5000,640000:5000,1280000:5000,1800000:5000"))
      {
        loge("configureRetry: Could not configure using DEFAULT_DATA_RETRY_CONFIG=default_randomization=2000,5000,10000,20000,40000,80000:5000,160000:5000,320000:5000,640000:5000,1280000:5000,1800000:5000");
        this.mRetryManager.configure(5, 2000, 1000);
      }
    }
    while (true)
    {
      log("configureRetry: forDefault=" + paramBoolean + " mRetryManager=" + this.mRetryManager);
      return;
      label93: if (!this.mRetryManager.configure("max_retries=3, 5000, 5000, 5000"))
      {
        loge("configureRetry: Could note configure using SECONDARY_DATA_RETRY_CONFIG=max_retries=3, 5000, 5000, 5000");
        this.mRetryManager.configure(5, 2000, 1000);
      }
    }
  }

  private String getRetryConfig(boolean paramBoolean)
  {
    int i = this.mPhone.getServiceState().getNetworkType();
    String str;
    if (Build.IS_DEBUGGABLE)
    {
      str = SystemProperties.get("test.data_retry_config");
      if (TextUtils.isEmpty(str));
    }
    while (true)
    {
      return str;
      if ((i == 4) || (i == 7) || (i == 5) || (i == 6) || (i == 12) || (i == 14))
        str = SystemProperties.get("ro.cdma.data_retry_config");
      else if (paramBoolean)
        str = SystemProperties.get("ro.gsm.data_retry_config");
      else
        str = SystemProperties.get("ro.gsm.2nd_data_retry_config");
    }
  }

  private boolean initConnection(ConnectionParams paramConnectionParams)
  {
    boolean bool = false;
    ApnContext localApnContext = paramConnectionParams.mApnContext;
    if (this.mApnSetting == null)
    {
      this.mApnSetting = localApnContext.getApnSetting();
      this.mTag = (1 + this.mTag);
      this.mConnectionParams = paramConnectionParams;
      this.mConnectionParams.mTag = this.mTag;
      if (!this.mApnContexts.contains(localApnContext))
        this.mApnContexts.add(localApnContext);
      configureRetry(this.mApnSetting.canHandleType("default"));
      this.mRetryManager.setRetryCount(0);
      this.mRetryManager.setCurMaxRetryCount(this.mConnectionParams.mInitialMaxRetry);
      this.mRetryManager.setRetryForever(false);
      log("initConnection:  RefCount=" + this.mApnContexts.size() + " mApnList=" + this.mApnContexts + " mConnectionParams=" + this.mConnectionParams);
      bool = true;
    }
    while (true)
    {
      return bool;
      if (this.mApnSetting.canHandleType(localApnContext.getApnType()))
        break;
      log("initConnection: incompatible apnSetting in ConnectionParams cp=" + paramConnectionParams + " dc=" + this);
    }
  }

  private boolean isDnsOk(String[] paramArrayOfString)
  {
    boolean bool = false;
    if (("0.0.0.0".equals(paramArrayOfString[0])) && ("0.0.0.0".equals(paramArrayOfString[1])) && (!this.mPhone.isDnsCheckDisabled()) && ((!this.mApnSetting.types[0].equals("mms")) || (!isIpAddress(this.mApnSetting.mmsProxy))))
    {
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = this.mApnSetting.types[0];
      arrayOfObject[1] = "mms";
      arrayOfObject[2] = this.mApnSetting.mmsProxy;
      arrayOfObject[3] = Boolean.valueOf(isIpAddress(this.mApnSetting.mmsProxy));
      log(String.format("isDnsOk: return false apn.types[0]=%s APN_TYPE_MMS=%s isIpAddress(%s)=%s", arrayOfObject));
    }
    while (true)
    {
      return bool;
      bool = true;
    }
  }

  private boolean isIpAddress(String paramString)
  {
    if (paramString == null);
    for (boolean bool = false; ; bool = Patterns.IP_ADDRESS.matcher(paramString).matches())
      return bool;
  }

  static DataConnection makeDataConnection(PhoneBase paramPhoneBase, int paramInt, DcTrackerBase paramDcTrackerBase, DcTesterFailBringUpAll paramDcTesterFailBringUpAll, DcController paramDcController)
  {
    DataConnection localDataConnection = new DataConnection(paramPhoneBase, "DC-" + mInstanceNumber.incrementAndGet(), paramInt, paramDcTrackerBase, paramDcTesterFailBringUpAll, paramDcController);
    localDataConnection.start();
    localDataConnection.log("Made " + localDataConnection.getName());
    return localDataConnection;
  }

  private static String msgToString(Message paramMessage)
  {
    if (paramMessage == null);
    StringBuilder localStringBuilder;
    for (String str = "null"; ; str = localStringBuilder.toString())
    {
      return str;
      localStringBuilder = new StringBuilder();
      localStringBuilder.append("{what=");
      localStringBuilder.append(cmdToString(paramMessage.what));
      localStringBuilder.append(" when=");
      TimeUtils.formatDuration(paramMessage.getWhen() - SystemClock.uptimeMillis(), localStringBuilder);
      if (paramMessage.arg1 != 0)
      {
        localStringBuilder.append(" arg1=");
        localStringBuilder.append(paramMessage.arg1);
      }
      if (paramMessage.arg2 != 0)
      {
        localStringBuilder.append(" arg2=");
        localStringBuilder.append(paramMessage.arg2);
      }
      if (paramMessage.obj != null)
      {
        localStringBuilder.append(" obj=");
        localStringBuilder.append(paramMessage.obj);
      }
      localStringBuilder.append(" target=");
      localStringBuilder.append(paramMessage.getTarget());
      localStringBuilder.append(" replyTo=");
      localStringBuilder.append(paramMessage.replyTo);
      localStringBuilder.append("}");
    }
  }

  private void notifyAllDisconnectCompleted(DcFailCause paramDcFailCause)
  {
    notifyAllWithEvent(null, 270351, paramDcFailCause.toString());
  }

  private void notifyAllOfConnected(String paramString)
  {
    notifyAllWithEvent(null, 270336, paramString);
  }

  private void notifyAllOfDisconnectDcRetrying(String paramString)
  {
    notifyAllWithEvent(null, 270370, paramString);
  }

  private void notifyAllWithEvent(ApnContext paramApnContext, int paramInt, String paramString)
  {
    Iterator localIterator = this.mApnContexts.iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if (localApnContext != paramApnContext)
      {
        if (paramString != null)
          localApnContext.setReason(paramString);
        Message localMessage = this.mDct.obtainMessage(paramInt, localApnContext);
        AsyncResult.forMessage(localMessage);
        localMessage.sendToTarget();
      }
    }
  }

  private void notifyConnectCompleted(ConnectionParams paramConnectionParams, DcFailCause paramDcFailCause, boolean paramBoolean)
  {
    ApnContext localApnContext = null;
    Message localMessage;
    long l;
    if ((paramConnectionParams != null) && (paramConnectionParams.mOnCompletedMsg != null))
    {
      localMessage = paramConnectionParams.mOnCompletedMsg;
      paramConnectionParams.mOnCompletedMsg = null;
      if ((localMessage.obj instanceof ApnContext))
        localApnContext = (ApnContext)localMessage.obj;
      l = System.currentTimeMillis();
      localMessage.arg1 = this.mCid;
      if (paramDcFailCause != DcFailCause.NONE)
        break label151;
      this.mCreateTime = l;
      AsyncResult.forMessage(localMessage);
    }
    while (true)
    {
      log("notifyConnectCompleted at " + l + " cause=" + paramDcFailCause + " connectionCompletedMsg=" + msgToString(localMessage));
      localMessage.sendToTarget();
      if (paramBoolean)
        notifyAllWithEvent(localApnContext, 270371, paramDcFailCause.toString());
      return;
      label151: this.mLastFailCause = paramDcFailCause;
      this.mLastFailTime = l;
      if (paramDcFailCause == null)
        paramDcFailCause = DcFailCause.UNKNOWN;
      AsyncResult.forMessage(localMessage, paramDcFailCause, new Throwable(paramDcFailCause.toString()));
    }
  }

  private void notifyDisconnectCompleted(DisconnectParams paramDisconnectParams, boolean paramBoolean)
  {
    log("NotifyDisconnectCompleted");
    ApnContext localApnContext = null;
    String str1 = null;
    Message localMessage;
    Object[] arrayOfObject;
    if ((paramDisconnectParams != null) && (paramDisconnectParams.mOnCompletedMsg != null))
    {
      localMessage = paramDisconnectParams.mOnCompletedMsg;
      paramDisconnectParams.mOnCompletedMsg = null;
      if ((localMessage.obj instanceof ApnContext))
        localApnContext = (ApnContext)localMessage.obj;
      str1 = paramDisconnectParams.mReason;
      arrayOfObject = new Object[2];
      arrayOfObject[0] = localMessage.toString();
      if (!(localMessage.obj instanceof String))
        break label177;
    }
    label177: for (String str2 = (String)localMessage.obj; ; str2 = "<no-reason>")
    {
      arrayOfObject[1] = str2;
      log(String.format("msg=%s msg.obj=%s", arrayOfObject));
      AsyncResult.forMessage(localMessage);
      localMessage.sendToTarget();
      if (paramBoolean)
      {
        if (str1 == null)
          str1 = DcFailCause.UNKNOWN.toString();
        notifyAllWithEvent(localApnContext, 270351, str1);
      }
      log("NotifyDisconnectCompleted DisconnectParams=" + paramDisconnectParams);
      return;
    }
  }

  private void onConnect(ConnectionParams paramConnectionParams)
  {
    log("onConnect: carrier='" + this.mApnSetting.carrier + "' APN='" + this.mApnSetting.apn + "' proxy='" + this.mApnSetting.proxy + "' port='" + this.mApnSetting.port + "'");
    if (this.mDcTesterFailBringUpAll.getDcFailBringUp().mCounter > 0)
    {
      DataCallResponse localDataCallResponse = new DataCallResponse();
      localDataCallResponse.version = this.mPhone.mCi.getRilVersion();
      localDataCallResponse.status = this.mDcTesterFailBringUpAll.getDcFailBringUp().mFailCause.getErrorCode();
      localDataCallResponse.cid = 0;
      localDataCallResponse.active = 0;
      localDataCallResponse.type = "";
      localDataCallResponse.ifname = "";
      localDataCallResponse.addresses = new String[0];
      localDataCallResponse.dnses = new String[0];
      localDataCallResponse.gateways = new String[0];
      localDataCallResponse.suggestedRetryTime = this.mDcTesterFailBringUpAll.getDcFailBringUp().mSuggestedRetryTime;
      Message localMessage1 = obtainMessage(262145, paramConnectionParams);
      AsyncResult.forMessage(localMessage1, localDataCallResponse, null);
      sendMessage(localMessage1);
      log("onConnect: FailBringUpAll=" + this.mDcTesterFailBringUpAll.getDcFailBringUp() + " send error response=" + localDataCallResponse);
      DcFailBringUp localDcFailBringUp = this.mDcTesterFailBringUpAll.getDcFailBringUp();
      localDcFailBringUp.mCounter = (-1 + localDcFailBringUp.mCounter);
      return;
    }
    this.mCreateTime = -1L;
    this.mLastFailTime = -1L;
    this.mLastFailCause = DcFailCause.NONE;
    Message localMessage2 = obtainMessage(262145, paramConnectionParams);
    localMessage2.obj = paramConnectionParams;
    int i = this.mApnSetting.authType;
    if (i == -1)
    {
      if (TextUtils.isEmpty(this.mApnSetting.user))
        i = 0;
    }
    else
      label349: if (!this.mPhone.getServiceState().getRoaming())
        break label438;
    label438: for (String str = this.mApnSetting.roamingProtocol; ; str = this.mApnSetting.protocol)
    {
      this.mPhone.mCi.setupDataCall(Integer.toString(2 + paramConnectionParams.mRilRat), Integer.toString(paramConnectionParams.mProfileId), this.mApnSetting.apn, this.mApnSetting.user, this.mApnSetting.password, Integer.toString(i), str, localMessage2);
      break;
      i = 3;
      break label349;
    }
  }

  private DataCallResponse.SetupResult onSetupConnectionCompleted(AsyncResult paramAsyncResult)
  {
    DataCallResponse localDataCallResponse = (DataCallResponse)paramAsyncResult.result;
    ConnectionParams localConnectionParams = (ConnectionParams)paramAsyncResult.userObj;
    DataCallResponse.SetupResult localSetupResult;
    if (localConnectionParams.mTag != this.mTag)
    {
      log("onSetupConnectionCompleted stale cp.tag=" + localConnectionParams.mTag + ", mtag=" + this.mTag);
      localSetupResult = DataCallResponse.SetupResult.ERR_Stale;
    }
    while (true)
    {
      return localSetupResult;
      if (paramAsyncResult.exception != null)
      {
        log("onSetupConnectionCompleted failed, ar.exception=" + paramAsyncResult.exception + " response=" + localDataCallResponse);
        if (((paramAsyncResult.exception instanceof CommandException)) && (((CommandException)paramAsyncResult.exception).getCommandError() == CommandException.Error.RADIO_NOT_AVAILABLE))
        {
          localSetupResult = DataCallResponse.SetupResult.ERR_BadCommand;
          localSetupResult.mFailCause = DcFailCause.RADIO_NOT_AVAILABLE;
        }
        else if ((localDataCallResponse == null) || (localDataCallResponse.version < 4))
        {
          localSetupResult = DataCallResponse.SetupResult.ERR_GetLastErrorFromRil;
        }
        else
        {
          localSetupResult = DataCallResponse.SetupResult.ERR_RilError;
          localSetupResult.mFailCause = DcFailCause.fromInt(localDataCallResponse.status);
        }
      }
      else if (localDataCallResponse.status != 0)
      {
        localSetupResult = DataCallResponse.SetupResult.ERR_RilError;
        localSetupResult.mFailCause = DcFailCause.fromInt(localDataCallResponse.status);
      }
      else
      {
        log("onSetupConnectionCompleted received DataCallResponse: " + localDataCallResponse);
        this.mCid = localDataCallResponse.cid;
        localSetupResult = updateLinkProperty(localDataCallResponse).setupResult;
      }
    }
  }

  private DataCallResponse.SetupResult setLinkProperties(DataCallResponse paramDataCallResponse, LinkProperties paramLinkProperties)
  {
    String str = "net." + paramDataCallResponse.ifname + ".";
    String[] arrayOfString = new String[2];
    arrayOfString[0] = SystemProperties.get(str + "dns1");
    arrayOfString[1] = SystemProperties.get(str + "dns2");
    return paramDataCallResponse.setLinkProperties(paramLinkProperties, isDnsOk(arrayOfString));
  }

  static void slog(String paramString)
  {
    Rlog.d("DC", paramString);
  }

  private void tearDownData(Object paramObject)
  {
    int i = 0;
    DisconnectParams localDisconnectParams;
    if ((paramObject != null) && ((paramObject instanceof DisconnectParams)))
    {
      localDisconnectParams = (DisconnectParams)paramObject;
      if (!TextUtils.equals(localDisconnectParams.mReason, "radioTurnedOff"))
        break label90;
      i = 1;
    }
    label144: 
    while (true)
    {
      if (this.mPhone.mCi.getRadioState().isOn())
      {
        log("tearDownData radio is on, call deactivateDataCall");
        this.mPhone.mCi.deactivateDataCall(this.mCid, i, obtainMessage(262147, this.mTag, 0, paramObject));
      }
      while (true)
      {
        return;
        label90: if (!TextUtils.equals(localDisconnectParams.mReason, "pdpReset"))
          break label144;
        i = 2;
        break;
        log("tearDownData radio is off sendMessage EVENT_DEACTIVATE_DONE immediately");
        AsyncResult localAsyncResult = new AsyncResult(paramObject, null, null);
        sendMessage(obtainMessage(262147, this.mTag, 0, localAsyncResult));
      }
    }
  }

  void dispose()
  {
    log("dispose: call quiteNow()");
    quitNow();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print("DataConnection ");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mApnContexts.size=" + this.mApnContexts.size());
    paramPrintWriter.println(" mApnContexts=" + this.mApnContexts);
    paramPrintWriter.flush();
    paramPrintWriter.println(" mDataConnectionTracker=" + this.mDct);
    paramPrintWriter.println(" mApnSetting=" + this.mApnSetting);
    paramPrintWriter.println(" mTag=" + this.mTag);
    paramPrintWriter.println(" mCid=" + this.mCid);
    paramPrintWriter.println(" mRetryManager=" + this.mRetryManager);
    paramPrintWriter.println(" mConnectionParams=" + this.mConnectionParams);
    paramPrintWriter.println(" mDisconnectParams=" + this.mDisconnectParams);
    paramPrintWriter.println(" mDcFailCause=" + this.mDcFailCause);
    paramPrintWriter.flush();
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.flush();
    paramPrintWriter.println(" mLinkProperties=" + this.mLinkProperties);
    paramPrintWriter.flush();
    paramPrintWriter.println(" mDataRegState=" + this.mDataRegState);
    paramPrintWriter.println(" mRilRat=" + this.mRilRat);
    paramPrintWriter.println(" mLinkCapabilities=" + this.mLinkCapabilities);
    paramPrintWriter.println(" mCreateTime=" + TimeUtils.logTimeOfDay(this.mCreateTime));
    paramPrintWriter.println(" mLastFailTime=" + TimeUtils.logTimeOfDay(this.mLastFailTime));
    paramPrintWriter.println(" mLastFailCause=" + this.mLastFailCause);
    paramPrintWriter.flush();
    paramPrintWriter.println(" mUserData=" + this.mUserData);
    paramPrintWriter.println(" mInstanceNumber=" + mInstanceNumber);
    paramPrintWriter.println(" mAc=" + this.mAc);
    paramPrintWriter.println(" mDcRetryAlarmController=" + this.mDcRetryAlarmController);
    paramPrintWriter.flush();
  }

  ApnSetting getApnSetting()
  {
    return this.mApnSetting;
  }

  int getCid()
  {
    return this.mCid;
  }

  LinkCapabilities getCopyLinkCapabilities()
  {
    return new LinkCapabilities(this.mLinkCapabilities);
  }

  LinkProperties getCopyLinkProperties()
  {
    return new LinkProperties(this.mLinkProperties);
  }

  public int getDataConnectionId()
  {
    return this.mId;
  }

  boolean getIsInactive()
  {
    if (getCurrentState() == this.mInactiveState);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected String getWhatToString(int paramInt)
  {
    return cmdToString(paramInt);
  }

  protected void log(String paramString)
  {
    Rlog.d(getName(), paramString);
  }

  protected void logd(String paramString)
  {
    Rlog.d(getName(), paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e(getName(), paramString);
  }

  protected void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e(getName(), paramString, paramThrowable);
  }

  protected void logi(String paramString)
  {
    Rlog.i(getName(), paramString);
  }

  protected void logv(String paramString)
  {
    Rlog.v(getName(), paramString);
  }

  protected void logw(String paramString)
  {
    Rlog.w(getName(), paramString);
  }

  void setLinkPropertiesHttpProxy(ProxyProperties paramProxyProperties)
  {
    this.mLinkProperties.setHttpProxy(paramProxyProperties);
  }

  void tearDownNow()
  {
    log("tearDownNow()");
    sendMessage(obtainMessage(262152));
  }

  public String toString()
  {
    return "{" + toStringSimple() + " mApnContexts=" + this.mApnContexts + "}";
  }

  public String toStringSimple()
  {
    return getName() + ": State=" + getCurrentState().getName() + " mApnSetting=" + this.mApnSetting + " RefCount=" + this.mApnContexts.size() + " mCid=" + this.mCid + " mCreateTime=" + this.mCreateTime + " mLastastFailTime=" + this.mLastFailTime + " mLastFailCause=" + this.mLastFailCause + " mTag=" + this.mTag + " mRetryManager=" + this.mRetryManager + " mLinkProperties=" + this.mLinkProperties + " mLinkCapabilities=" + this.mLinkCapabilities;
  }

  UpdateLinkPropertyResult updateLinkProperty(DataCallResponse paramDataCallResponse)
  {
    UpdateLinkPropertyResult localUpdateLinkPropertyResult = new UpdateLinkPropertyResult(this.mLinkProperties);
    if (paramDataCallResponse == null);
    while (true)
    {
      return localUpdateLinkPropertyResult;
      localUpdateLinkPropertyResult.newLp = new LinkProperties();
      localUpdateLinkPropertyResult.setupResult = setLinkProperties(paramDataCallResponse, localUpdateLinkPropertyResult.newLp);
      if (localUpdateLinkPropertyResult.setupResult != DataCallResponse.SetupResult.SUCCESS)
      {
        log("updateLinkProperty failed : " + localUpdateLinkPropertyResult.setupResult);
      }
      else
      {
        localUpdateLinkPropertyResult.newLp.setHttpProxy(this.mLinkProperties.getHttpProxy());
        if (!localUpdateLinkPropertyResult.oldLp.equals(localUpdateLinkPropertyResult.newLp))
        {
          log("updateLinkProperty old LP=" + localUpdateLinkPropertyResult.oldLp);
          log("updateLinkProperty new LP=" + localUpdateLinkPropertyResult.newLp);
        }
        this.mLinkProperties = localUpdateLinkPropertyResult.newLp;
      }
    }
  }

  static class ConnectionParams
  {
    ApnContext mApnContext;
    int mInitialMaxRetry;
    Message mOnCompletedMsg;
    int mProfileId;
    int mRilRat;
    int mTag;

    ConnectionParams(ApnContext paramApnContext, int paramInt1, int paramInt2, int paramInt3, Message paramMessage)
    {
      this.mApnContext = paramApnContext;
      this.mInitialMaxRetry = paramInt1;
      this.mProfileId = paramInt2;
      this.mRilRat = paramInt3;
      this.mOnCompletedMsg = paramMessage;
    }

    public String toString()
    {
      return "{mTag=" + this.mTag + " mApnContext=" + this.mApnContext + " mInitialMaxRetry=" + this.mInitialMaxRetry + " mProfileId=" + this.mProfileId + " mRat=" + this.mRilRat + " mOnCompletedMsg=" + DataConnection.msgToString(this.mOnCompletedMsg) + "}";
    }
  }

  private class DcActivatingState extends State
  {
    private DcActivatingState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      DataConnection.this.log("DcActivatingState: msg=" + DataConnection.msgToString(paramMessage));
      boolean bool;
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcActivatingState not handled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what) + " RefCount=" + DataConnection.this.mApnContexts.size());
      case 262144:
      case 262155:
        for (bool = false; ; bool = true)
        {
          return bool;
          DataConnection.this.deferMessage(paramMessage);
        }
      case 262145:
        AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
        DataConnection.ConnectionParams localConnectionParams2 = (DataConnection.ConnectionParams)localAsyncResult2.userObj;
        DataCallResponse.SetupResult localSetupResult = DataConnection.this.onSetupConnectionCompleted(localAsyncResult2);
        if ((localSetupResult != DataCallResponse.SetupResult.ERR_Stale) && (DataConnection.this.mConnectionParams != localConnectionParams2))
          DataConnection.this.loge("DcActivatingState: WEIRD mConnectionsParams:" + DataConnection.this.mConnectionParams + " != cp:" + localConnectionParams2);
        DataConnection.this.log("DcActivatingState onSetupConnectionCompleted result=" + localSetupResult + " dc=" + DataConnection.this);
        switch (DataConnection.1.$SwitchMap$com$android$internal$telephony$dataconnection$DataCallResponse$SetupResult[localSetupResult.ordinal()])
        {
        default:
          throw new RuntimeException("Unknown SetupResult, should not happen");
        case 1:
          DataConnection.access$2602(DataConnection.this, DcFailCause.NONE);
          DataConnection.this.transitionTo(DataConnection.this.mActiveState);
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        }
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams2, localSetupResult.mFailCause);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          continue;
          DataConnection.this.tearDownData(localConnectionParams2);
          DataConnection.this.transitionTo(DataConnection.this.mDisconnectingErrorCreatingConnection);
          continue;
          DataConnection.this.mPhone.mCi.getLastDataCallFailCause(DataConnection.this.obtainMessage(262146, localConnectionParams2));
          continue;
          int j = DataConnection.this.mDcRetryAlarmController.getSuggestedRetryTime(DataConnection.this, localAsyncResult2);
          DataConnection.this.log("DcActivatingState: ERR_RilError  delay=" + j + " isRetryNeeded=" + DataConnection.this.mRetryManager.isRetryNeeded() + " result=" + localSetupResult + " result.isRestartRadioFail=" + localSetupResult.mFailCause.isRestartRadioFail() + " result.isPermanentFail=" + localSetupResult.mFailCause.isPermanentFail());
          if (localSetupResult.mFailCause.isRestartRadioFail())
          {
            DataConnection.this.log("DcActivatingState: ERR_RilError restart radio");
            DataConnection.this.mDct.sendRestartRadio();
            DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams2, localSetupResult.mFailCause);
            DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          }
          else if (localSetupResult.mFailCause.isPermanentFail())
          {
            DataConnection.this.log("DcActivatingState: ERR_RilError perm error");
            DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams2, localSetupResult.mFailCause);
            DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          }
          else if (j >= 0)
          {
            DataConnection.this.log("DcActivatingState: ERR_RilError retry");
            DataConnection.this.mDcRetryAlarmController.startRetryAlarm(262154, DataConnection.this.mTag, j);
            DataConnection.this.transitionTo(DataConnection.this.mRetryingState);
          }
          else
          {
            DataConnection.this.log("DcActivatingState: ERR_RilError no retry");
            DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams2, localSetupResult.mFailCause);
            DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
            continue;
            DataConnection.this.loge("DcActivatingState: stale EVENT_SETUP_DATA_CONNECTION_DONE tag:" + localConnectionParams2.mTag + " != mTag:" + DataConnection.this.mTag);
          }
        }
      case 262146:
      }
      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
      DataConnection.ConnectionParams localConnectionParams1 = (DataConnection.ConnectionParams)localAsyncResult1.userObj;
      DcFailCause localDcFailCause;
      int i;
      if (localConnectionParams1.mTag == DataConnection.this.mTag)
      {
        if (DataConnection.this.mConnectionParams != localConnectionParams1)
          DataConnection.this.loge("DcActivatingState: WEIRD mConnectionsParams:" + DataConnection.this.mConnectionParams + " != cp:" + localConnectionParams1);
        localDcFailCause = DcFailCause.UNKNOWN;
        if (localAsyncResult1.exception == null)
        {
          localDcFailCause = DcFailCause.fromInt(((int[])(int[])localAsyncResult1.result)[0]);
          if (localDcFailCause == DcFailCause.NONE)
          {
            DataConnection.this.log("DcActivatingState msg.what=EVENT_GET_LAST_FAIL_DONE BAD: error was NONE, change to UNKNOWN");
            localDcFailCause = DcFailCause.UNKNOWN;
          }
        }
        DataConnection.access$2602(DataConnection.this, localDcFailCause);
        i = DataConnection.this.mRetryManager.getRetryTimer();
        DataConnection.this.log("DcActivatingState msg.what=EVENT_GET_LAST_FAIL_DONE cause=" + localDcFailCause + " retryDelay=" + i + " isRetryNeeded=" + DataConnection.this.mRetryManager.isRetryNeeded() + " dc=" + DataConnection.this);
        if (localDcFailCause.isRestartRadioFail())
        {
          DataConnection.this.log("DcActivatingState: EVENT_GET_LAST_FAIL_DONE restart radio");
          DataConnection.this.mDct.sendRestartRadio();
          DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams1, localDcFailCause);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
        }
      }
      while (true)
      {
        bool = true;
        break;
        if (localDcFailCause.isPermanentFail())
        {
          DataConnection.this.log("DcActivatingState: EVENT_GET_LAST_FAIL_DONE perm er");
          DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams1, localDcFailCause);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
        }
        else if ((i >= 0) && (DataConnection.this.mRetryManager.isRetryNeeded()))
        {
          DataConnection.this.log("DcActivatingState: EVENT_GET_LAST_FAIL_DONE retry");
          DataConnection.this.mDcRetryAlarmController.startRetryAlarm(262154, DataConnection.this.mTag, i);
          DataConnection.this.transitionTo(DataConnection.this.mRetryingState);
        }
        else
        {
          DataConnection.this.log("DcActivatingState: EVENT_GET_LAST_FAIL_DONE no retry");
          DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams1, localDcFailCause);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          continue;
          DataConnection.this.loge("DcActivatingState: stale EVENT_GET_LAST_FAIL_DONE tag:" + localConnectionParams1.mTag + " != mTag:" + DataConnection.this.mTag);
        }
      }
    }
  }

  private class DcActiveState extends State
  {
    private DcActiveState()
    {
    }

    public void enter()
    {
      DataConnection.this.log("DcActiveState: enter dc=" + DataConnection.this);
      if (DataConnection.this.mRetryManager.getRetryCount() != 0)
      {
        DataConnection.this.log("DcActiveState: connected after retrying call notifyAllOfConnected");
        DataConnection.this.mRetryManager.setRetryCount(0);
      }
      DataConnection.this.notifyAllOfConnected("connected");
      DataConnection.this.mRetryManager.restoreCurMaxRetryCount();
      DataConnection.this.mDcController.addActiveDcByCid(DataConnection.this);
    }

    public void exit()
    {
      DataConnection.this.log("DcActiveState: exit dc=" + this);
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcActiveState not handled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
        bool = false;
      case 262144:
      case 262148:
      case 262150:
        while (true)
        {
          return bool;
          DataConnection.ConnectionParams localConnectionParams = (DataConnection.ConnectionParams)paramMessage.obj;
          DataConnection.this.log("DcActiveState: EVENT_CONNECT cp=" + localConnectionParams + " dc=" + DataConnection.this);
          if (DataConnection.this.mApnContexts.contains(localConnectionParams.mApnContext))
            DataConnection.this.log("DcActiveState ERROR already added apnContext=" + localConnectionParams.mApnContext);
          while (true)
          {
            DataConnection.this.notifyConnectCompleted(localConnectionParams, DcFailCause.NONE, false);
            bool = true;
            break;
            DataConnection.this.mApnContexts.add(localConnectionParams.mApnContext);
            DataConnection.this.log("DcActiveState msg.what=EVENT_CONNECT RefCount=" + DataConnection.this.mApnContexts.size());
          }
          DataConnection.DisconnectParams localDisconnectParams2 = (DataConnection.DisconnectParams)paramMessage.obj;
          DataConnection.this.log("DcActiveState: EVENT_DISCONNECT dp=" + localDisconnectParams2 + " dc=" + DataConnection.this);
          if (DataConnection.this.mApnContexts.contains(localDisconnectParams2.mApnContext))
          {
            DataConnection.this.log("DcActiveState msg.what=EVENT_DISCONNECT RefCount=" + DataConnection.this.mApnContexts.size());
            if (DataConnection.this.mApnContexts.size() == 1)
            {
              DataConnection.this.mApnContexts.clear();
              DataConnection.access$2502(DataConnection.this, localDisconnectParams2);
              DataConnection.access$2402(DataConnection.this, null);
              localDisconnectParams2.mTag = DataConnection.this.mTag;
              DataConnection.this.tearDownData(localDisconnectParams2);
              DataConnection.this.transitionTo(DataConnection.this.mDisconnectingState);
            }
          }
          while (true)
          {
            bool = true;
            break;
            DataConnection.this.mApnContexts.remove(localDisconnectParams2.mApnContext);
            DataConnection.this.notifyDisconnectCompleted(localDisconnectParams2, false);
            continue;
            DataConnection.this.log("DcActiveState ERROR no such apnContext=" + localDisconnectParams2.mApnContext + " in this dc=" + DataConnection.this);
            DataConnection.this.notifyDisconnectCompleted(localDisconnectParams2, false);
          }
          DataConnection.this.log("DcActiveState EVENT_DISCONNECT clearing apn contexts, dc=" + DataConnection.this);
          DataConnection.DisconnectParams localDisconnectParams1 = (DataConnection.DisconnectParams)paramMessage.obj;
          DataConnection.access$2502(DataConnection.this, localDisconnectParams1);
          DataConnection.access$2402(DataConnection.this, null);
          localDisconnectParams1.mTag = DataConnection.this.mTag;
          DataConnection.this.tearDownData(localDisconnectParams1);
          DataConnection.this.transitionTo(DataConnection.this.mDisconnectingState);
          bool = true;
        }
      case 262153:
      }
      DataConnection.this.log("DcActiveState EVENT_LOST_CONNECTION dc=" + DataConnection.this);
      if (DataConnection.this.mRetryManager.isRetryNeeded())
      {
        int i = DataConnection.this.mRetryManager.getRetryTimer();
        DataConnection.this.log("DcActiveState EVENT_LOST_CONNECTION startRetryAlarm mTag=" + DataConnection.this.mTag + " delay=" + i + "ms");
        DataConnection.this.mDcRetryAlarmController.startRetryAlarm(262154, DataConnection.this.mTag, i);
        DataConnection.this.transitionTo(DataConnection.this.mRetryingState);
      }
      while (true)
      {
        bool = true;
        break;
        DataConnection.this.mInactiveState.setEnterNotificationParams(DcFailCause.LOST_CONNECTION);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
      }
    }
  }

  private class DcDefaultState extends State
  {
    private DcDefaultState()
    {
    }

    public void enter()
    {
      DataConnection.this.log("DcDefaultState: enter");
      DataConnection.this.mPhone.getServiceStateTracker().registerForDataRegStateOrRatChanged(DataConnection.this.getHandler(), 262155, null);
      DataConnection.this.mDcController.addDc(DataConnection.this);
    }

    public void exit()
    {
      DataConnection.this.log("DcDefaultState: exit");
      DataConnection.this.mPhone.getServiceStateTracker().unregisterForDataRegStateOrRatChanged(DataConnection.this.getHandler());
      DataConnection.this.mDcController.removeDc(DataConnection.this);
      if (DataConnection.this.mAc != null)
      {
        DataConnection.this.mAc.disconnected();
        DataConnection.access$302(DataConnection.this, null);
      }
      DataConnection.this.mDcRetryAlarmController.dispose();
      DataConnection.access$402(DataConnection.this, null);
      DataConnection.this.mApnContexts = null;
      DataConnection.this.mReconnectIntent = null;
      DataConnection.access$502(DataConnection.this, null);
      DataConnection.access$602(DataConnection.this, null);
      DataConnection.access$102(DataConnection.this, null);
      DataConnection.access$702(DataConnection.this, null);
      DataConnection.access$802(DataConnection.this, null);
      DataConnection.access$902(DataConnection.this, null);
      DataConnection.access$1002(DataConnection.this, null);
      DataConnection.access$202(DataConnection.this, null);
      DataConnection.access$1102(DataConnection.this, null);
    }

    public boolean processMessage(Message paramMessage)
    {
      DataConnection.this.log("DcDefault msg=" + DataConnection.this.getWhatToString(paramMessage.what) + " RefCount=" + DataConnection.this.mApnContexts.size());
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcDefaultState: shouldn't happen but ignore msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
      case 69633:
      case 69636:
      case 266240:
      case 266242:
      case 266244:
      case 266246:
      case 266248:
      case 266250:
      case 266252:
      case 262144:
      case 262148:
      case 262150:
      case 262152:
      case 262153:
      case 262154:
      case 262155:
      }
      while (true)
      {
        return true;
        if (DataConnection.this.mAc != null)
        {
          DataConnection.this.log("Disconnecting to previous connection mAc=" + DataConnection.this.mAc);
          DataConnection.this.mAc.replyToMessage(paramMessage, 69634, 3);
        }
        else
        {
          DataConnection.access$302(DataConnection.this, new AsyncChannel());
          DataConnection.this.mAc.connected(null, DataConnection.this.getHandler(), paramMessage.replyTo);
          DataConnection.this.log("DcDefaultState: FULL_CONNECTION reply connected");
          DataConnection.this.mAc.replyToMessage(paramMessage, 69634, 0, DataConnection.this.mId, "hi");
          continue;
          DataConnection.this.log("CMD_CHANNEL_DISCONNECTED");
          DataConnection.this.quit();
          continue;
          boolean bool = DataConnection.this.getIsInactive();
          DataConnection.this.log("REQ_IS_INACTIVE  isInactive=" + bool);
          AsyncChannel localAsyncChannel = DataConnection.this.mAc;
          if (bool);
          for (int j = 1; ; j = 0)
          {
            localAsyncChannel.replyToMessage(paramMessage, 266241, j);
            break;
          }
          int i = DataConnection.this.getCid();
          DataConnection.this.log("REQ_GET_CID  cid=" + i);
          DataConnection.this.mAc.replyToMessage(paramMessage, 266243, i);
          continue;
          ApnSetting localApnSetting = DataConnection.this.getApnSetting();
          DataConnection.this.log("REQ_GET_APNSETTING  mApnSetting=" + localApnSetting);
          DataConnection.this.mAc.replyToMessage(paramMessage, 266245, localApnSetting);
          continue;
          LinkProperties localLinkProperties = DataConnection.this.getCopyLinkProperties();
          DataConnection.this.log("REQ_GET_LINK_PROPERTIES linkProperties" + localLinkProperties);
          DataConnection.this.mAc.replyToMessage(paramMessage, 266247, localLinkProperties);
          continue;
          ProxyProperties localProxyProperties = (ProxyProperties)paramMessage.obj;
          DataConnection.this.log("REQ_SET_LINK_PROPERTIES_HTTP_PROXY proxy=" + localProxyProperties);
          DataConnection.this.setLinkPropertiesHttpProxy(localProxyProperties);
          DataConnection.this.mAc.replyToMessage(paramMessage, 266249);
          continue;
          LinkCapabilities localLinkCapabilities = DataConnection.this.getCopyLinkCapabilities();
          DataConnection.this.log("REQ_GET_LINK_CAPABILITIES linkCapabilities" + localLinkCapabilities);
          DataConnection.this.mAc.replyToMessage(paramMessage, 266251, localLinkCapabilities);
          continue;
          DataConnection.this.log("DcDefaultState: msg.what=REQ_RESET");
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          continue;
          DataConnection.this.log("DcDefaultState: msg.what=EVENT_CONNECT, fail not expected");
          DataConnection.ConnectionParams localConnectionParams = (DataConnection.ConnectionParams)paramMessage.obj;
          DataConnection.this.notifyConnectCompleted(localConnectionParams, DcFailCause.UNKNOWN, false);
          continue;
          DataConnection.this.log("DcDefaultState deferring msg.what=EVENT_DISCONNECT RefCount=" + DataConnection.this.mApnContexts.size());
          DataConnection.this.deferMessage(paramMessage);
          continue;
          DataConnection.this.log("DcDefaultState deferring msg.what=EVENT_DISCONNECT_ALL RefCount=" + DataConnection.this.mApnContexts.size());
          DataConnection.this.deferMessage(paramMessage);
          continue;
          DataConnection.this.log("DcDefaultState EVENT_TEAR_DOWN_NOW");
          DataConnection.this.mPhone.mCi.deactivateDataCall(DataConnection.this.mCid, 0, null);
          continue;
          String str2 = "DcDefaultState ignore EVENT_LOST_CONNECTION tag=" + paramMessage.arg1 + ":mTag=" + DataConnection.this.mTag;
          DataConnection.this.logAndAddLogRec(str2);
          continue;
          String str1 = "DcDefaultState ignore EVENT_RETRY_CONNECTION tag=" + paramMessage.arg1 + ":mTag=" + DataConnection.this.mTag;
          DataConnection.this.logAndAddLogRec(str1);
          continue;
          Pair localPair = (Pair)((AsyncResult)paramMessage.obj).result;
          DataConnection.access$2102(DataConnection.this, ((Integer)localPair.first).intValue());
          DataConnection.access$2202(DataConnection.this, ((Integer)localPair.second).intValue());
          DataConnection.this.log("DcDefaultState: EVENT_DATA_CONNECTION_DRS_OR_RAT_CHANGED drs=" + DataConnection.this.mDataRegState + " mRilRat=" + DataConnection.this.mRilRat);
        }
      }
    }
  }

  private class DcDisconnectingState extends State
  {
    private DcDisconnectingState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      case 262145:
      case 262146:
      default:
        DataConnection.this.log("DcDisconnectingState not handled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
      case 262144:
        for (bool = false; ; bool = true)
        {
          return bool;
          DataConnection.this.log("DcDisconnectingState msg.what=EVENT_CONNECT. Defer. RefCount = " + DataConnection.this.mApnContexts.size());
          DataConnection.this.deferMessage(paramMessage);
        }
      case 262147:
      }
      DataConnection.this.log("DcDisconnectingState msg.what=EVENT_DEACTIVATE_DONE RefCount=" + DataConnection.this.mApnContexts.size());
      AsyncResult localAsyncResult = (AsyncResult)paramMessage.obj;
      DataConnection.DisconnectParams localDisconnectParams = (DataConnection.DisconnectParams)localAsyncResult.userObj;
      if (localDisconnectParams.mTag == DataConnection.this.mTag)
      {
        DataConnection.this.mInactiveState.setEnterNotificationParams((DataConnection.DisconnectParams)localAsyncResult.userObj);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
      }
      while (true)
      {
        bool = true;
        break;
        DataConnection.this.log("DcDisconnectState stale EVENT_DEACTIVATE_DONE dp.tag=" + localDisconnectParams.mTag + " mTag=" + DataConnection.this.mTag);
      }
    }
  }

  private class DcDisconnectionErrorCreatingConnection extends State
  {
    private DcDisconnectionErrorCreatingConnection()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcDisconnectionErrorCreatingConnection not handled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
        bool = false;
        return bool;
      case 262147:
      }
      DataConnection.ConnectionParams localConnectionParams = (DataConnection.ConnectionParams)((AsyncResult)paramMessage.obj).userObj;
      if (localConnectionParams.mTag == DataConnection.this.mTag)
      {
        DataConnection.this.log("DcDisconnectionErrorCreatingConnection msg.what=EVENT_DEACTIVATE_DONE");
        DataConnection.this.mInactiveState.setEnterNotificationParams(localConnectionParams, DcFailCause.UNACCEPTABLE_NETWORK_PARAMETER);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
      }
      while (true)
      {
        bool = true;
        break;
        DataConnection.this.log("DcDisconnectionErrorCreatingConnection stale EVENT_DEACTIVATE_DONE dp.tag=" + localConnectionParams.mTag + ", mTag=" + DataConnection.this.mTag);
      }
    }
  }

  private class DcInactiveState extends State
  {
    private DcInactiveState()
    {
    }

    public void enter()
    {
      DataConnection localDataConnection = DataConnection.this;
      localDataConnection.mTag = (1 + localDataConnection.mTag);
      DataConnection.this.log("DcInactiveState: enter() mTag=" + DataConnection.this.mTag);
      if (DataConnection.this.mConnectionParams != null)
      {
        DataConnection.this.log("DcInactiveState: enter notifyConnectCompleted +ALL failCause=" + DataConnection.this.mDcFailCause);
        DataConnection.this.notifyConnectCompleted(DataConnection.this.mConnectionParams, DataConnection.this.mDcFailCause, true);
      }
      if (DataConnection.this.mDisconnectParams != null)
      {
        DataConnection.this.log("DcInactiveState: enter notifyDisconnectCompleted +ALL failCause=" + DataConnection.this.mDcFailCause);
        DataConnection.this.notifyDisconnectCompleted(DataConnection.this.mDisconnectParams, true);
      }
      if ((DataConnection.this.mDisconnectParams == null) && (DataConnection.this.mConnectionParams == null) && (DataConnection.this.mDcFailCause != null))
      {
        DataConnection.this.log("DcInactiveState: enter notifyAllDisconnectCompleted failCause=" + DataConnection.this.mDcFailCause);
        DataConnection.this.notifyAllDisconnectCompleted(DataConnection.this.mDcFailCause);
      }
      DataConnection.this.mDcController.removeActiveDcByCid(DataConnection.this);
      DataConnection.this.clearSettings();
    }

    public void exit()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcInactiveState nothandled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
        bool = false;
      case 266252:
      case 262144:
      case 262148:
      case 262150:
      }
      while (true)
      {
        return bool;
        DataConnection.this.log("DcInactiveState: msg.what=RSP_RESET, ignore we're already reset");
        bool = true;
        continue;
        DataConnection.this.log("DcInactiveState: mag.what=EVENT_CONNECT");
        DataConnection.ConnectionParams localConnectionParams = (DataConnection.ConnectionParams)paramMessage.obj;
        if (DataConnection.this.initConnection(localConnectionParams))
        {
          DataConnection.this.onConnect(DataConnection.this.mConnectionParams);
          DataConnection.this.transitionTo(DataConnection.this.mActivatingState);
        }
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.log("DcInactiveState: msg.what=EVENT_CONNECT initConnection failed");
          DataConnection.this.notifyConnectCompleted(localConnectionParams, DcFailCause.UNACCEPTABLE_NETWORK_PARAMETER, false);
        }
        DataConnection.this.log("DcInactiveState: msg.what=EVENT_DISCONNECT");
        DataConnection.this.notifyDisconnectCompleted((DataConnection.DisconnectParams)paramMessage.obj, false);
        bool = true;
        continue;
        DataConnection.this.log("DcInactiveState: msg.what=EVENT_DISCONNECT_ALL");
        DataConnection.this.notifyDisconnectCompleted((DataConnection.DisconnectParams)paramMessage.obj, false);
        bool = true;
      }
    }

    public void setEnterNotificationParams(DataConnection.ConnectionParams paramConnectionParams, DcFailCause paramDcFailCause)
    {
      DataConnection.this.log("DcInactiveState: setEnterNoticationParams cp,cause");
      DataConnection.access$2402(DataConnection.this, paramConnectionParams);
      DataConnection.access$2502(DataConnection.this, null);
      DataConnection.access$2602(DataConnection.this, paramDcFailCause);
    }

    public void setEnterNotificationParams(DataConnection.DisconnectParams paramDisconnectParams)
    {
      DataConnection.this.log("DcInactiveState: setEnterNoticationParams dp");
      DataConnection.access$2402(DataConnection.this, null);
      DataConnection.access$2502(DataConnection.this, paramDisconnectParams);
      DataConnection.access$2602(DataConnection.this, DcFailCause.NONE);
    }

    public void setEnterNotificationParams(DcFailCause paramDcFailCause)
    {
      DataConnection.access$2402(DataConnection.this, null);
      DataConnection.access$2502(DataConnection.this, null);
      DataConnection.access$2602(DataConnection.this, paramDcFailCause);
    }
  }

  private class DcRetryingState extends State
  {
    private DcRetryingState()
    {
    }

    public void enter()
    {
      if ((DataConnection.this.mConnectionParams.mRilRat != DataConnection.this.mRilRat) || (DataConnection.this.mDataRegState != 0))
      {
        String str = "DcRetryingState: enter() not retrying rat changed, mConnectionParams.mRilRat=" + DataConnection.this.mConnectionParams.mRilRat + " != mRilRat:" + DataConnection.this.mRilRat + " transitionTo(mInactiveState)";
        DataConnection.this.logAndAddLogRec(str);
        DataConnection.this.mInactiveState.setEnterNotificationParams(DcFailCause.LOST_CONNECTION);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
      }
      while (true)
      {
        return;
        DataConnection.this.log("DcRetryingState: enter() mTag=" + DataConnection.this.mTag + ", call notifyAllOfDisconnectDcRetrying lostConnection");
        DataConnection.this.notifyAllOfDisconnectDcRetrying("lostDataConnection");
        DataConnection.this.mDcController.removeActiveDcByCid(DataConnection.this);
        DataConnection.this.mCid = -1;
      }
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      default:
        DataConnection.this.log("DcRetryingState nothandled msg.what=" + DataConnection.this.getWhatToString(paramMessage.what));
        bool = false;
      case 262155:
      case 262154:
      case 266252:
      case 262144:
      case 262148:
      case 262150:
      }
      while (true)
      {
        return bool;
        Pair localPair = (Pair)((AsyncResult)paramMessage.obj).result;
        int i = ((Integer)localPair.first).intValue();
        int j = ((Integer)localPair.second).intValue();
        if ((j == DataConnection.this.mRilRat) && (i == DataConnection.this.mDataRegState))
          DataConnection.this.log("DcRetryingState: EVENT_DATA_CONNECTION_DRS_OR_RAT_CHANGED strange no change in drs=" + i + " rat=" + j + " ignoring");
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.mInactiveState.setEnterNotificationParams(DcFailCause.LOST_CONNECTION);
          DataConnection.this.deferMessage(paramMessage);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
          String str = "DcRetryingState: EVENT_DATA_CONNECTION_DRS_OR_RAT_CHANGED giving up changed from " + DataConnection.this.mRilRat + " to rat=" + j + " or drs changed from " + DataConnection.this.mDataRegState + " to drs=" + i;
          DataConnection.this.logAndAddLogRec(str);
          DataConnection.access$2102(DataConnection.this, i);
          DataConnection.access$2202(DataConnection.this, j);
        }
        if (paramMessage.arg1 == DataConnection.this.mTag)
        {
          DataConnection.this.mRetryManager.increaseRetryCount();
          DataConnection.this.log("DcRetryingState EVENT_RETRY_CONNECTION RetryCount=" + DataConnection.this.mRetryManager.getRetryCount() + " mConnectionParams=" + DataConnection.this.mConnectionParams);
          DataConnection.this.onConnect(DataConnection.this.mConnectionParams);
          DataConnection.this.transitionTo(DataConnection.this.mActivatingState);
        }
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.log("DcRetryingState stale EVENT_RETRY_CONNECTION tag:" + paramMessage.arg1 + " != mTag:" + DataConnection.this.mTag);
        }
        DataConnection.this.log("DcRetryingState: msg.what=RSP_RESET, ignore we're already reset");
        DataConnection.this.mInactiveState.setEnterNotificationParams(DataConnection.this.mConnectionParams, DcFailCause.RESET_BY_FRAMEWORK);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
        bool = true;
        continue;
        DataConnection.ConnectionParams localConnectionParams = (DataConnection.ConnectionParams)paramMessage.obj;
        DataConnection.this.log("DcRetryingState: msg.what=EVENT_CONNECT RefCount=" + DataConnection.this.mApnContexts.size() + " cp=" + localConnectionParams + " mConnectionParams=" + DataConnection.this.mConnectionParams);
        if (DataConnection.this.initConnection(localConnectionParams))
        {
          DataConnection.this.onConnect(DataConnection.this.mConnectionParams);
          DataConnection.this.transitionTo(DataConnection.this.mActivatingState);
        }
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.log("DcRetryingState: msg.what=EVENT_CONNECT initConnection failed");
          DataConnection.this.notifyConnectCompleted(localConnectionParams, DcFailCause.UNACCEPTABLE_NETWORK_PARAMETER, false);
        }
        DataConnection.DisconnectParams localDisconnectParams = (DataConnection.DisconnectParams)paramMessage.obj;
        if ((DataConnection.this.mApnContexts.remove(localDisconnectParams.mApnContext)) && (DataConnection.this.mApnContexts.size() == 0))
        {
          DataConnection.this.log("DcRetryingState msg.what=EVENT_DISCONNECT  RefCount=" + DataConnection.this.mApnContexts.size() + " dp=" + localDisconnectParams);
          DataConnection.this.mInactiveState.setEnterNotificationParams(localDisconnectParams);
          DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
        }
        while (true)
        {
          bool = true;
          break;
          DataConnection.this.log("DcRetryingState: msg.what=EVENT_DISCONNECT");
          DataConnection.this.notifyDisconnectCompleted(localDisconnectParams, false);
        }
        DataConnection.this.log("DcRetryingState msg.what=EVENT_DISCONNECT/DISCONNECT_ALL RefCount=" + DataConnection.this.mApnContexts.size());
        DataConnection.this.mInactiveState.setEnterNotificationParams(DcFailCause.LOST_CONNECTION);
        DataConnection.this.transitionTo(DataConnection.this.mInactiveState);
        bool = true;
      }
    }
  }

  static class DisconnectParams
  {
    ApnContext mApnContext;
    Message mOnCompletedMsg;
    String mReason;
    int mTag;

    DisconnectParams(ApnContext paramApnContext, String paramString, Message paramMessage)
    {
      this.mApnContext = paramApnContext;
      this.mReason = paramString;
      this.mOnCompletedMsg = paramMessage;
    }

    public String toString()
    {
      return "{mTag=" + this.mTag + " mApnContext=" + this.mApnContext + " mReason=" + this.mReason + " mOnCompletedMsg=" + DataConnection.msgToString(this.mOnCompletedMsg) + "}";
    }
  }

  static class UpdateLinkPropertyResult
  {
    public LinkProperties newLp;
    public LinkProperties oldLp;
    public DataCallResponse.SetupResult setupResult = DataCallResponse.SetupResult.SUCCESS;

    public UpdateLinkPropertyResult(LinkProperties paramLinkProperties)
    {
      this.oldLp = paramLinkProperties;
      this.newLp = paramLinkProperties;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DataConnection
 * JD-Core Version:    0.6.2
 */