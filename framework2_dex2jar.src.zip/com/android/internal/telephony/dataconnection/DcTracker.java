package com.android.internal.telephony.dataconnection;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.LinkCapabilities;
import android.net.LinkProperties;
import android.net.NetworkConfig;
import android.net.NetworkUtils;
import android.net.ProxyProperties;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Message;
import android.os.Messenger;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.provider.Telephony.Carriers;
import android.telephony.CellLocation;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.text.TextUtils;
import android.util.EventLog;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.DctConstants.Activity;
import com.android.internal.telephony.DctConstants.State;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.DataState;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.gsm.GSMPhone;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public final class DcTracker extends DcTrackerBase
{
  static final String APN_ID = "apn_id";
  private static final int POLL_PDP_MILLIS = 5000;
  static final Uri PREFERAPN_NO_UPDATE_URI = Uri.parse("content://telephony/carriers/preferapn_no_update");
  private static final String PUPPET_MASTER_RADIO_STRESS_TEST = "gsm.defaultpdpcontext.active";
  protected final String LOG_TAG = "DCT";
  private ApnChangeObserver mApnObserver;
  private AtomicBoolean mAttached = new AtomicBoolean(false);
  private boolean mCanSetPreferApn = false;
  private boolean mReregisterOnReconnectFailure = false;

  public DcTracker(PhoneBase paramPhoneBase)
  {
    super(paramPhoneBase);
    log("GsmDCT.constructor");
    paramPhoneBase.mCi.registerForAvailable(this, 270337, null);
    paramPhoneBase.mCi.registerForOffOrNotAvailable(this, 270342, null);
    paramPhoneBase.mCi.registerForDataNetworkStateChanged(this, 270340, null);
    paramPhoneBase.getCallTracker().registerForVoiceCallEnded(this, 270344, null);
    paramPhoneBase.getCallTracker().registerForVoiceCallStarted(this, 270343, null);
    paramPhoneBase.getServiceStateTracker().registerForDataConnectionAttached(this, 270352, null);
    paramPhoneBase.getServiceStateTracker().registerForDataConnectionDetached(this, 270345, null);
    paramPhoneBase.getServiceStateTracker().registerForRoamingOn(this, 270347, null);
    paramPhoneBase.getServiceStateTracker().registerForRoamingOff(this, 270348, null);
    paramPhoneBase.getServiceStateTracker().registerForPsRestrictedEnabled(this, 270358, null);
    paramPhoneBase.getServiceStateTracker().registerForPsRestrictedDisabled(this, 270359, null);
    this.mDataConnectionTracker = this;
    this.mApnObserver = new ApnChangeObserver();
    paramPhoneBase.getContext().getContentResolver().registerContentObserver(Telephony.Carriers.CONTENT_URI, true, this.mApnObserver);
    initApnContexts();
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction("com.android.internal.telephony.data-reconnect." + localApnContext.getApnType());
      localIntentFilter.addAction("com.android.internal.telephony.data-restart-trysetup." + localApnContext.getApnType());
      this.mPhone.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter, null, this.mPhone);
    }
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramPhoneBase.getContext().getSystemService("connectivity");
    localConnectivityManager.supplyMessenger(0, new Messenger(this));
    localConnectivityManager.supplyMessenger(2, new Messenger(this));
    localConnectivityManager.supplyMessenger(3, new Messenger(this));
    localConnectivityManager.supplyMessenger(4, new Messenger(this));
    localConnectivityManager.supplyMessenger(5, new Messenger(this));
    localConnectivityManager.supplyMessenger(10, new Messenger(this));
    localConnectivityManager.supplyMessenger(11, new Messenger(this));
    localConnectivityManager.supplyMessenger(12, new Messenger(this));
  }

  private ApnContext addApnContext(String paramString, NetworkConfig paramNetworkConfig)
  {
    ApnContext localApnContext = new ApnContext(this.mPhone.getContext(), paramString, "DCT", paramNetworkConfig);
    this.mApnContexts.put(paramString, localApnContext);
    this.mPrioritySortedApnContexts.add(localApnContext);
    return localApnContext;
  }

  private String apnListToString(ArrayList<ApnSetting> paramArrayList)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 0;
    int j = paramArrayList.size();
    while (i < j)
    {
      localStringBuilder.append('[').append(((ApnSetting)paramArrayList.get(i)).toString()).append(']');
      i++;
    }
    return localStringBuilder.toString();
  }

  private void applyNewState(ApnContext paramApnContext, boolean paramBoolean1, boolean paramBoolean2)
  {
    int i = 0;
    int j = 0;
    log("applyNewState(" + paramApnContext.getApnType() + ", " + paramBoolean1 + "(" + paramApnContext.isEnabled() + "), " + paramBoolean2 + "(" + paramApnContext.getDependencyMet() + "))");
    if (paramApnContext.isReady())
      if ((paramBoolean1) && (paramBoolean2))
      {
        localState = paramApnContext.getState();
        switch (1.$SwitchMap$com$android$internal$telephony$DctConstants$State[localState.ordinal()])
        {
        default:
          i = 1;
        case 1:
        case 2:
        case 4:
        case 6:
        case 3:
        case 5:
        case 7:
        }
      }
    while ((!paramBoolean1) || (!paramBoolean2))
      while (true)
      {
        DctConstants.State localState;
        paramApnContext.setEnabled(paramBoolean1);
        paramApnContext.setDependencyMet(paramBoolean2);
        if (i != 0)
          cleanUpConnection(true, paramApnContext);
        if (j != 0)
          trySetupData(paramApnContext);
        while (true)
        {
          return;
          log("applyNewState: 'ready' so return");
        }
        j = 1;
        paramApnContext.setReason("dataEnabled");
        continue;
        if (!paramBoolean1)
          paramApnContext.setReason("dataDisabled");
        else
          paramApnContext.setReason("dependencyUnmet");
      }
    if (paramApnContext.isEnabled())
      paramApnContext.setReason("dependencyMet");
    while (true)
    {
      if (paramApnContext.getState() == DctConstants.State.FAILED)
        paramApnContext.setState(DctConstants.State.IDLE);
      j = 1;
      break;
      paramApnContext.setReason("dataEnabled");
    }
  }

  private ArrayList<ApnSetting> buildWaitingApns(String paramString, int paramInt)
  {
    log("buildWaitingApns: E requestedApnType=" + paramString);
    ArrayList localArrayList = new ArrayList();
    if (paramString.equals("dun"))
    {
      ApnSetting localApnSetting2 = fetchDunApn();
      if (localApnSetting2 != null)
      {
        localArrayList.add(localApnSetting2);
        log("buildWaitingApns: X added APN_TYPE_DUN apnList=" + localArrayList);
      }
    }
    while (true)
    {
      return localArrayList;
      IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
      String str;
      if (localIccRecords != null)
        str = localIccRecords.getOperatorNumeric();
      try
      {
        label110: boolean bool2 = this.mPhone.getContext().getResources().getBoolean(17891412);
        if (!bool2);
        for (bool1 = true; ; bool1 = false)
        {
          log("buildWaitingApns: usePreferred=" + bool1 + " canSetPreferApn=" + this.mCanSetPreferApn + " mPreferredApn=" + this.mPreferredApn + " operator=" + str + " radioTech=" + paramInt + " IccRecords r=" + localIccRecords);
          if ((!bool1) || (!this.mCanSetPreferApn) || (this.mPreferredApn == null) || (!this.mPreferredApn.canHandleType(paramString)))
            break label421;
          log("buildWaitingApns: Preferred APN:" + str + ":" + this.mPreferredApn.numeric + ":" + this.mPreferredApn);
          if (!this.mPreferredApn.numeric.equals(str))
            break label575;
          if ((this.mPreferredApn.bearer != 0) && (this.mPreferredApn.bearer != paramInt))
            break label404;
          localArrayList.add(this.mPreferredApn);
          log("buildWaitingApns: X added preferred apnList=" + localArrayList);
          break;
          str = "";
          break label110;
        }
      }
      catch (Resources.NotFoundException localNotFoundException)
      {
        while (true)
        {
          log("buildWaitingApns: usePreferred NotFoundException set to true");
          boolean bool1 = true;
        }
        label404: log("buildWaitingApns: no preferred APN");
        setPreferredApn(-1);
        this.mPreferredApn = null;
        label421: if (this.mAllApnSettings != null)
        {
          log("buildWaitingApns: mAllApnSettings=" + this.mAllApnSettings);
          Iterator localIterator = this.mAllApnSettings.iterator();
          while (true)
          {
            if (!localIterator.hasNext())
              break label676;
            ApnSetting localApnSetting1 = (ApnSetting)localIterator.next();
            log("buildWaitingApns: apn=" + localApnSetting1);
            if (localApnSetting1.canHandleType(paramString))
            {
              if ((localApnSetting1.bearer == 0) || (localApnSetting1.bearer == paramInt))
              {
                log("buildWaitingApns: adding apn=" + localApnSetting1.toString());
                localArrayList.add(localApnSetting1);
                continue;
                label575: log("buildWaitingApns: no preferred APN");
                setPreferredApn(-1);
                this.mPreferredApn = null;
                break;
              }
              log("buildWaitingApns: bearer:" + localApnSetting1.bearer + " != " + "radioTech:" + paramInt);
              continue;
            }
            log("buildWaitingApns: couldn't handle requesedApnType=" + paramString);
          }
        }
        loge("mAllApnSettings is empty!");
        label676: log("buildWaitingApns: X apnList=" + localArrayList);
      }
    }
  }

  private void cancelReconnectAlarm(ApnContext paramApnContext)
  {
    if (paramApnContext == null);
    while (true)
    {
      return;
      PendingIntent localPendingIntent = paramApnContext.getReconnectIntent();
      if (localPendingIntent != null)
      {
        ((AlarmManager)this.mPhone.getContext().getSystemService("alarm")).cancel(localPendingIntent);
        paramApnContext.setReconnectIntent(null);
      }
    }
  }

  private DcAsyncChannel checkForCompatibleConnectedApnContext(ApnContext paramApnContext)
  {
    String str = paramApnContext.getApnType();
    ApnSetting localApnSetting1 = null;
    if ("dun".equals(str))
      localApnSetting1 = fetchDunApn();
    log("checkForCompatibleConnectedApnContext: apnContext=" + paramApnContext);
    Object localObject1 = null;
    Object localObject2 = null;
    Iterator localIterator = this.mApnContexts.values().iterator();
    ApnContext localApnContext;
    Object localObject3;
    ApnSetting localApnSetting2;
    while (true)
      if (localIterator.hasNext())
      {
        localApnContext = (ApnContext)localIterator.next();
        localObject3 = localApnContext.getDcAc();
        if (localObject3 != null)
        {
          localApnSetting2 = localApnContext.getApnSetting();
          if (localApnSetting1 != null)
          {
            if (!localApnSetting1.equals(localApnSetting2))
              continue;
            switch (1.$SwitchMap$com$android$internal$telephony$DctConstants$State[localApnContext.getState().ordinal()])
            {
            case 2:
            default:
              break;
            case 1:
              log("checkForCompatibleConnectedApnContext: found dun conn=" + localObject3 + " curApnCtx=" + localApnContext);
            case 3:
            case 4:
            }
          }
        }
      }
    while (true)
    {
      return localObject3;
      localObject1 = localObject3;
      localObject2 = localApnContext;
      break;
      if ((localApnSetting2 == null) || (!localApnSetting2.canHandleType(str)))
        break;
      switch (1.$SwitchMap$com$android$internal$telephony$DctConstants$State[localApnContext.getState().ordinal()])
      {
      case 2:
      default:
        break;
      case 1:
        log("checkForCompatibleConnectedApnContext: found canHandle conn=" + localObject3 + " curApnCtx=" + localApnContext);
        break;
      case 3:
      case 4:
        localObject1 = localObject3;
        localObject2 = localApnContext;
        break;
        if (localObject1 != null)
        {
          log("checkForCompatibleConnectedApnContext: found potential conn=" + localObject1 + " curApnCtx=" + localObject2);
          localObject3 = localObject1;
        }
        else
        {
          log("checkForCompatibleConnectedApnContext: NO conn apnContext=" + paramApnContext);
          localObject3 = null;
        }
        break;
      }
    }
  }

  private void cleanUpConnection(boolean paramBoolean, ApnContext paramApnContext)
  {
    if (paramApnContext == null)
    {
      log("cleanUpConnection: apn context is null");
      return;
    }
    DcAsyncChannel localDcAsyncChannel = paramApnContext.getDcAc();
    log("cleanUpConnection: E tearDown=" + paramBoolean + " reason=" + paramApnContext.getReason() + " apnContext=" + paramApnContext);
    if (paramBoolean)
      if (paramApnContext.isDisconnected())
      {
        paramApnContext.setState(DctConstants.State.IDLE);
        if (!paramApnContext.isReady())
        {
          if (localDcAsyncChannel != null)
            localDcAsyncChannel.tearDown(paramApnContext, "", null);
          paramApnContext.setDataConnectionAc(null);
        }
      }
    while (true)
    {
      if (localDcAsyncChannel != null)
        cancelReconnectAlarm(paramApnContext);
      log("cleanUpConnection: X tearDown=" + paramBoolean + " reason=" + paramApnContext.getReason() + " apnContext=" + paramApnContext + " dcac=" + paramApnContext.getDcAc());
      break;
      if (localDcAsyncChannel != null)
      {
        if (paramApnContext.getState() != DctConstants.State.DISCONNECTING)
        {
          int i = 0;
          if ("dun".equals(paramApnContext.getApnType()))
          {
            ApnSetting localApnSetting = fetchDunApn();
            if ((localApnSetting != null) && (localApnSetting.equals(paramApnContext.getApnSetting())))
            {
              log("tearing down dedicated DUN connection");
              i = 1;
            }
          }
          StringBuilder localStringBuilder = new StringBuilder().append("cleanUpConnection: tearing down");
          String str;
          label267: Message localMessage;
          if (i != 0)
          {
            str = " all";
            log(str);
            localMessage = obtainMessage(270351, paramApnContext);
            if (i == 0)
              break label327;
            paramApnContext.getDcAc().tearDownAll(paramApnContext.getReason(), localMessage);
          }
          while (true)
          {
            paramApnContext.setState(DctConstants.State.DISCONNECTING);
            break;
            str = "";
            break label267;
            label327: paramApnContext.getDcAc().tearDown(paramApnContext, paramApnContext.getReason(), localMessage);
          }
        }
      }
      else
      {
        paramApnContext.setState(DctConstants.State.IDLE);
        this.mPhone.notifyDataConnection(paramApnContext.getReason(), paramApnContext.getApnType());
        continue;
        if (localDcAsyncChannel != null)
          localDcAsyncChannel.reqReset();
        paramApnContext.setState(DctConstants.State.IDLE);
        this.mPhone.notifyDataConnection(paramApnContext.getReason(), paramApnContext.getApnType());
        paramApnContext.setDataConnectionAc(null);
      }
    }
  }

  private void createAllApnList()
  {
    this.mAllApnSettings = new ArrayList();
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    String str1;
    if (localIccRecords != null)
    {
      str1 = localIccRecords.getOperatorNumeric();
      if (str1 != null)
      {
        String str2 = "numeric = '" + str1 + "'";
        String str3 = str2 + " and carrier_enabled = 1";
        log("createAllApnList: selection=" + str3);
        Cursor localCursor = this.mPhone.getContext().getContentResolver().query(Telephony.Carriers.CONTENT_URI, null, str3, null, null);
        if (localCursor != null)
        {
          if (localCursor.getCount() > 0)
            this.mAllApnSettings = createApnList(localCursor);
          localCursor.close();
        }
      }
      if (!this.mAllApnSettings.isEmpty())
        break label238;
      log("createAllApnList: No APN found for carrier: " + str1);
      this.mPreferredApn = null;
    }
    while (true)
    {
      log("createAllApnList: X mAllApnSettings=" + this.mAllApnSettings);
      return;
      str1 = "";
      break;
      label238: this.mPreferredApn = getPreferredApn();
      if ((this.mPreferredApn != null) && (!this.mPreferredApn.numeric.equals(str1)))
      {
        this.mPreferredApn = null;
        setPreferredApn(-1);
      }
      log("createAllApnList: mPreferredApn=" + this.mPreferredApn);
    }
  }

  private ArrayList<ApnSetting> createApnList(Cursor paramCursor)
  {
    ArrayList localArrayList = new ArrayList();
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    Object localObject1;
    Object localObject2;
    if (paramCursor.moveToFirst())
    {
      localObject1 = null;
      localObject2 = null;
    }
    while (true)
    {
      String str1 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("mvno_type"));
      String str2 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("mvno_match_data"));
      if (localObject1 != null)
        if ((localObject1.equals(str1)) && (localObject2.equals(str2)))
          localArrayList.add(makeApnSetting(paramCursor));
      while (!paramCursor.moveToNext())
      {
        log("createApnList: X result=" + localArrayList);
        return localArrayList;
        if (mvnoMatches(localIccRecords, str1, str2))
        {
          localArrayList.clear();
          localObject1 = str1;
          localObject2 = str2;
          localArrayList.add(makeApnSetting(paramCursor));
        }
        else if (str1.equals(""))
        {
          localArrayList.add(makeApnSetting(paramCursor));
        }
      }
    }
  }

  private DcAsyncChannel createDataConnection()
  {
    log("createDataConnection E");
    int i = this.mUniqueIdGenerator.getAndIncrement();
    DataConnection localDataConnection = DataConnection.makeDataConnection(this.mPhone, i, this, this.mDcTesterFailBringUpAll, this.mDcc);
    this.mDataConnections.put(Integer.valueOf(i), localDataConnection);
    DcAsyncChannel localDcAsyncChannel = new DcAsyncChannel(localDataConnection, "DCT");
    int j = localDcAsyncChannel.fullyConnectSync(this.mPhone.getContext(), this, localDataConnection.getHandler());
    if (j == 0)
      this.mDataConnectionAcHashMap.put(Integer.valueOf(localDcAsyncChannel.getDataConnectionIdSync()), localDcAsyncChannel);
    while (true)
    {
      log("createDataConnection() X id=" + i + " dc=" + localDataConnection);
      return localDcAsyncChannel;
      loge("createDataConnection: Could not connect to dcac=" + localDcAsyncChannel + " status=" + j);
    }
  }

  private boolean dataConnectionNotInUse(DcAsyncChannel paramDcAsyncChannel)
  {
    log("dataConnectionNotInUse: check if dcac is inuse dcac=" + paramDcAsyncChannel);
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if (localApnContext.getDcAc() == paramDcAsyncChannel)
        log("dataConnectionNotInUse: in use by apnContext=" + localApnContext);
    }
    for (boolean bool = false; ; bool = true)
    {
      return bool;
      log("dataConnectionNotInUse: tearDownAll");
      paramDcAsyncChannel.tearDownAll("No connection", null);
      log("dataConnectionNotInUse: not in use return true");
    }
  }

  private void destroyDataConnections()
  {
    if (this.mDataConnections != null)
    {
      log("destroyDataConnections: clear mDataConnectionList");
      this.mDataConnections.clear();
    }
    while (true)
    {
      return;
      log("destroyDataConnections: mDataConnecitonList is empty, ignore");
    }
  }

  private DcAsyncChannel findDataConnectionAcByCid(int paramInt)
  {
    Iterator localIterator = this.mDataConnectionAcHashMap.values().iterator();
    DcAsyncChannel localDcAsyncChannel;
    do
    {
      if (!localIterator.hasNext())
        break;
      localDcAsyncChannel = (DcAsyncChannel)localIterator.next();
    }
    while (localDcAsyncChannel.getCidSync() != paramInt);
    while (true)
    {
      return localDcAsyncChannel;
      localDcAsyncChannel = null;
    }
  }

  private DcAsyncChannel findFreeDataConnection()
  {
    Iterator localIterator = this.mDataConnectionAcHashMap.values().iterator();
    DcAsyncChannel localDcAsyncChannel;
    while (localIterator.hasNext())
    {
      localDcAsyncChannel = (DcAsyncChannel)localIterator.next();
      if ((localDcAsyncChannel.isInactiveSync()) && (dataConnectionNotInUse(localDcAsyncChannel)))
        log("findFreeDataConnection: found free DataConnection= dcac=" + localDcAsyncChannel);
    }
    while (true)
    {
      return localDcAsyncChannel;
      log("findFreeDataConnection: NO free DataConnection");
      localDcAsyncChannel = null;
    }
  }

  private int getApnDelay()
  {
    if (this.mFailFast);
    for (int i = SystemProperties.getInt("persist.radio.apn_ff_delay", 3000); ; i = SystemProperties.getInt("persist.radio.apn_delay", 20000))
      return i;
  }

  private int getCellLocationId()
  {
    int i = -1;
    CellLocation localCellLocation = this.mPhone.getCellLocation();
    if (localCellLocation != null)
    {
      if (!(localCellLocation instanceof GsmCellLocation))
        break label31;
      i = ((GsmCellLocation)localCellLocation).getCid();
    }
    while (true)
    {
      return i;
      label31: if ((localCellLocation instanceof CdmaCellLocation))
        i = ((CdmaCellLocation)localCellLocation).getBaseStationId();
    }
  }

  private ApnSetting getPreferredApn()
  {
    Object localObject = null;
    if (this.mAllApnSettings.isEmpty())
      log("getPreferredApn: X not found mAllApnSettings.isEmpty");
    while (true)
    {
      return localObject;
      Cursor localCursor = this.mPhone.getContext().getContentResolver().query(PREFERAPN_NO_UPDATE_URI, new String[] { "_id", "name", "apn" }, null, null, "name ASC");
      label74: StringBuilder localStringBuilder;
      if (localCursor != null)
      {
        this.mCanSetPreferApn = true;
        localStringBuilder = new StringBuilder().append("getPreferredApn: mRequestedApnType=").append(this.mRequestedApnType).append(" cursor=").append(localCursor).append(" cursor.count=");
        if (localCursor == null)
          break label299;
      }
      label299: for (int i = localCursor.getCount(); ; i = 0)
      {
        log(i);
        if ((!this.mCanSetPreferApn) || (localCursor.getCount() <= 0))
          break label305;
        localCursor.moveToFirst();
        int j = localCursor.getInt(localCursor.getColumnIndexOrThrow("_id"));
        Iterator localIterator = this.mAllApnSettings.iterator();
        ApnSetting localApnSetting;
        do
        {
          if (!localIterator.hasNext())
            break;
          localApnSetting = (ApnSetting)localIterator.next();
          log("getPreferredApn: apnSetting=" + localApnSetting);
        }
        while ((localApnSetting.id != j) || (!localApnSetting.canHandleType(this.mRequestedApnType)));
        log("getPreferredApn: X found apnSetting" + localApnSetting);
        localCursor.close();
        localObject = localApnSetting;
        break;
        this.mCanSetPreferApn = false;
        break label74;
      }
      label305: if (localCursor != null)
        localCursor.close();
      log("getPreferredApn: X not found");
    }
  }

  private boolean imsiMatches(String paramString1, String paramString2)
  {
    boolean bool = false;
    int i = paramString1.length();
    if (i <= 0);
    while (true)
    {
      return bool;
      if (i <= paramString2.length())
      {
        for (int j = 0; ; j++)
        {
          if (j >= i)
            break label73;
          int k = paramString1.charAt(j);
          if ((k != 120) && (k != 88) && (k != paramString2.charAt(j)))
            break;
        }
        label73: bool = true;
      }
    }
  }

  private boolean isDataAllowed(ApnContext paramApnContext)
  {
    if ((paramApnContext.isReady()) && (isDataAllowed()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isHigherPriorityApnContextActive(ApnContext paramApnContext)
  {
    boolean bool = false;
    Iterator localIterator = this.mPrioritySortedApnContexts.iterator();
    ApnContext localApnContext;
    if (localIterator.hasNext())
    {
      localApnContext = (ApnContext)localIterator.next();
      if (!paramApnContext.getApnType().equalsIgnoreCase(localApnContext.getApnType()))
        break label47;
    }
    while (true)
    {
      return bool;
      label47: if ((!localApnContext.isEnabled()) || (localApnContext.getState() == DctConstants.State.FAILED))
        break;
      bool = true;
    }
  }

  private boolean isOnlySingleDcAllowed(int paramInt)
  {
    int[] arrayOfInt = this.mPhone.getContext().getResources().getIntArray(17236008);
    boolean bool = false;
    if ((Build.IS_DEBUGGABLE) && (SystemProperties.getBoolean("persist.telephony.test.singleDc", false)))
      bool = true;
    if (arrayOfInt != null)
      for (int i = 0; (i < arrayOfInt.length) && (!bool); i++)
        if (paramInt == arrayOfInt[i])
          bool = true;
    log("isOnlySingleDcAllowed(" + paramInt + "): " + bool);
    return bool;
  }

  private ApnSetting makeApnSetting(Cursor paramCursor)
  {
    String[] arrayOfString = parseTypes(paramCursor.getString(paramCursor.getColumnIndexOrThrow("type")));
    int i = paramCursor.getInt(paramCursor.getColumnIndexOrThrow("_id"));
    String str1 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("numeric"));
    String str2 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("name"));
    String str3 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("apn"));
    String str4 = NetworkUtils.trimV4AddrZeros(paramCursor.getString(paramCursor.getColumnIndexOrThrow("proxy")));
    String str5 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("port"));
    String str6 = NetworkUtils.trimV4AddrZeros(paramCursor.getString(paramCursor.getColumnIndexOrThrow("mmsc")));
    String str7 = NetworkUtils.trimV4AddrZeros(paramCursor.getString(paramCursor.getColumnIndexOrThrow("mmsproxy")));
    String str8 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("mmsport"));
    String str9 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("user"));
    String str10 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("password"));
    int j = paramCursor.getInt(paramCursor.getColumnIndexOrThrow("authtype"));
    String str11 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("protocol"));
    String str12 = paramCursor.getString(paramCursor.getColumnIndexOrThrow("roaming_protocol"));
    if (paramCursor.getInt(paramCursor.getColumnIndexOrThrow("carrier_enabled")) == 1);
    for (boolean bool = true; ; bool = false)
      return new ApnSetting(i, str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, j, arrayOfString, str11, str12, bool, paramCursor.getInt(paramCursor.getColumnIndexOrThrow("bearer")));
  }

  private boolean mvnoMatches(IccRecords paramIccRecords, String paramString1, String paramString2)
  {
    boolean bool = true;
    if (paramString1.equalsIgnoreCase("spn"))
      if ((paramIccRecords.getServiceProviderName() == null) || (!paramIccRecords.getServiceProviderName().equalsIgnoreCase(paramString2)))
        break label65;
    while (true)
    {
      return bool;
      if (paramString1.equalsIgnoreCase("imsi"))
      {
        String str2 = paramIccRecords.getIMSI();
        if ((str2 != null) && (imsiMatches(paramString2, str2)));
      }
      else
      {
        label65: String str1;
        int i;
        do
        {
          do
          {
            bool = false;
            break;
          }
          while (!paramString1.equalsIgnoreCase("gid"));
          str1 = paramIccRecords.getGid1();
          i = paramString2.length();
        }
        while ((str1 == null) || (str1.length() < i) || (!str1.substring(0, i).equalsIgnoreCase(paramString2)));
      }
    }
  }

  private void notifyNoData(DcFailCause paramDcFailCause, ApnContext paramApnContext)
  {
    log("notifyNoData: type=" + paramApnContext.getApnType());
    if ((paramDcFailCause.isPermanentFail()) && (!paramApnContext.getApnType().equals("default")))
      this.mPhone.notifyDataConnectionFailed(paramApnContext.getReason(), paramApnContext.getApnType());
  }

  private void onApnChanged()
  {
    boolean bool1 = true;
    DctConstants.State localState = getOverallState();
    boolean bool2;
    if ((localState == DctConstants.State.IDLE) || (localState == DctConstants.State.FAILED))
    {
      bool2 = bool1;
      if ((this.mPhone instanceof GSMPhone))
        ((GSMPhone)this.mPhone).updateCurrentCarrierInProvider();
      log("onApnChanged: createAllApnList and cleanUpAllConnections");
      createAllApnList();
      setInitialAttachApn();
      if (bool2)
        break label89;
    }
    while (true)
    {
      cleanUpAllConnections(bool1, "apnChanged");
      if (bool2)
        setupDataOnConnectableApns("apnChanged");
      return;
      bool2 = false;
      break;
      label89: bool1 = false;
    }
  }

  private void onDataConnectionAttached()
  {
    log("onDataConnectionAttached");
    this.mAttached.set(true);
    if (getOverallState() == DctConstants.State.CONNECTED)
    {
      log("onDataConnectionAttached: start polling notify attached");
      startNetStatPoll();
      startDataStallAlarm(false);
      notifyDataConnection("dataAttached");
    }
    while (true)
    {
      this.mAutoAttachOnCreation = true;
      setupDataOnConnectableApns("dataAttached");
      return;
      notifyOffApnsOfAvailability("dataAttached");
    }
  }

  private void onDataStateChanged(AsyncResult paramAsyncResult)
  {
    log("onDataStateChanged(ar): E");
    ArrayList localArrayList = (ArrayList)paramAsyncResult.result;
    if (paramAsyncResult.exception != null)
    {
      log("onDataStateChanged(ar): exception; likely radio not available, ignore");
      return;
    }
    log("onDataStateChanged(ar): DataCallResponse size=" + localArrayList.size());
    HashMap localHashMap = new HashMap();
    Iterator localIterator1 = localArrayList.iterator();
    while (localIterator1.hasNext())
    {
      DataCallResponse localDataCallResponse2 = (DataCallResponse)localIterator1.next();
      DcAsyncChannel localDcAsyncChannel = findDataConnectionAcByCid(localDataCallResponse2.cid);
      if (localDcAsyncChannel != null)
        localHashMap.put(localDataCallResponse2, localDcAsyncChannel);
    }
    boolean bool1 = false;
    boolean bool2 = false;
    Iterator localIterator2 = localArrayList.iterator();
    while (localIterator2.hasNext())
    {
      DataCallResponse localDataCallResponse1 = (DataCallResponse)localIterator2.next();
      if (localDataCallResponse1.active == 2)
        bool2 = true;
      if (localDataCallResponse1.active == 1)
        bool1 = true;
    }
    if ((bool1) && (!bool2))
    {
      this.mActivity = DctConstants.Activity.DORMANT;
      log("onDataStateChanged: Data Activity updated to DORMANT. stopNetStatePoll");
      stopNetStatPoll();
    }
    while (true)
    {
      log("onDataStateChanged(ar): X");
      break;
      this.mActivity = DctConstants.Activity.NONE;
      log("onDataStateChanged: Data Activity updated to NONE. isAnyDataCallActive = " + bool2 + " isAnyDataCallDormant = " + bool1);
      if (bool2)
        startNetStatPoll();
    }
  }

  private void onRecordsLoaded()
  {
    log("onRecordsLoaded: createAllApnList");
    createAllApnList();
    setInitialAttachApn();
    if (this.mPhone.mCi.getRadioState().isOn())
    {
      log("onRecordsLoaded: notifying data availability");
      notifyOffApnsOfAvailability("simLoaded");
    }
    setupDataOnConnectableApns("simLoaded");
  }

  private String[] parseTypes(String paramString)
  {
    if ((paramString == null) || (paramString.equals("")));
    for (String[] arrayOfString = { "*" }; ; arrayOfString = paramString.split(","))
      return arrayOfString;
  }

  private boolean retryAfterDisconnected(ApnContext paramApnContext)
  {
    boolean bool = true;
    if (("radioTurnedOff".equals(paramApnContext.getReason())) || ((isOnlySingleDcAllowed(this.mPhone.getServiceState().getRilDataRadioTechnology())) && (isHigherPriorityApnContextActive(paramApnContext))))
      bool = false;
    return bool;
  }

  private void setPreferredApn(int paramInt)
  {
    if (!this.mCanSetPreferApn)
      log("setPreferredApn: X !canSEtPreferApn");
    while (true)
    {
      return;
      log("setPreferredApn: delete");
      ContentResolver localContentResolver = this.mPhone.getContext().getContentResolver();
      localContentResolver.delete(PREFERAPN_NO_UPDATE_URI, null, null);
      if (paramInt >= 0)
      {
        log("setPreferredApn: insert");
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("apn_id", Integer.valueOf(paramInt));
        localContentResolver.insert(PREFERAPN_NO_UPDATE_URI, localContentValues);
      }
    }
  }

  private boolean setupData(ApnContext paramApnContext, int paramInt)
  {
    boolean bool = false;
    log("setupData: apnContext=" + paramApnContext);
    int i = getApnProfileID(paramApnContext.getApnType());
    Object localObject = paramApnContext.getNextWaitingApn();
    if (localObject == null)
      log("setupData: return for no apn found!");
    while (true)
    {
      return bool;
      DcAsyncChannel localDcAsyncChannel = checkForCompatibleConnectedApnContext(paramApnContext);
      if (localDcAsyncChannel != null)
      {
        ApnSetting localApnSetting = localDcAsyncChannel.getApnSettingSync();
        if (localApnSetting != null)
          localObject = localApnSetting;
      }
      if (localDcAsyncChannel == null)
      {
        if (isOnlySingleDcAllowed(paramInt))
        {
          if (isHigherPriorityApnContextActive(paramApnContext))
            log("setupData: Higher priority ApnContext active.  Ignoring call");
          else if (cleanUpAllConnections(true, "SinglePdnArbitration"))
            log("setupData: Some calls are disconnecting first.  Wait and retry");
          else
            log("setupData: Single pdp. Continue setting up data call.");
        }
        else
        {
          localDcAsyncChannel = findFreeDataConnection();
          if (localDcAsyncChannel == null)
            localDcAsyncChannel = createDataConnection();
          if (localDcAsyncChannel == null)
            log("setupData: No free DataConnection and couldn't create one, WEIRD");
        }
      }
      else
      {
        log("setupData: dcac=" + localDcAsyncChannel + " apnSetting=" + localObject);
        paramApnContext.setDataConnectionAc(localDcAsyncChannel);
        paramApnContext.setApnSetting((ApnSetting)localObject);
        paramApnContext.setState(DctConstants.State.CONNECTING);
        this.mPhone.notifyDataConnection(paramApnContext.getReason(), paramApnContext.getApnType());
        Message localMessage = obtainMessage();
        localMessage.what = 270336;
        localMessage.obj = paramApnContext;
        localDcAsyncChannel.bringUp(paramApnContext, getInitialMaxRetry(), i, paramInt, localMessage);
        log("setupData: initing!");
        bool = true;
      }
    }
  }

  private void setupDataOnConnectableApns(String paramString)
  {
    log("setupDataOnConnectableApns: " + paramString);
    Iterator localIterator = this.mPrioritySortedApnContexts.iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      log("setupDataOnConnectableApns: apnContext " + localApnContext);
      if (localApnContext.getState() == DctConstants.State.FAILED)
        localApnContext.setState(DctConstants.State.IDLE);
      if (localApnContext.isConnectable())
      {
        log("setupDataOnConnectableApns: isConnectable() call trySetupData");
        localApnContext.setReason(paramString);
        trySetupData(localApnContext);
      }
    }
  }

  private void startAlarmForReconnect(int paramInt, ApnContext paramApnContext)
  {
    String str = paramApnContext.getApnType();
    Intent localIntent = new Intent("com.android.internal.telephony.data-reconnect." + str);
    localIntent.putExtra("reconnect_alarm_extra_reason", paramApnContext.getReason());
    localIntent.putExtra("reconnect_alarm_extra_type", str);
    log("startAlarmForReconnect: delay=" + paramInt + " action=" + localIntent.getAction() + " apn=" + paramApnContext);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, localIntent, 134217728);
    paramApnContext.setReconnectIntent(localPendingIntent);
    this.mAlarmManager.set(2, SystemClock.elapsedRealtime() + paramInt, localPendingIntent);
  }

  private void startAlarmForRestartTrySetup(int paramInt, ApnContext paramApnContext)
  {
    String str = paramApnContext.getApnType();
    Intent localIntent = new Intent("com.android.internal.telephony.data-restart-trysetup." + str);
    localIntent.putExtra("restart_trysetup_alarm_extra_type", str);
    log("startAlarmForRestartTrySetup: delay=" + paramInt + " action=" + localIntent.getAction() + " apn=" + paramApnContext);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this.mPhone.getContext(), 0, localIntent, 134217728);
    paramApnContext.setReconnectIntent(localPendingIntent);
    this.mAlarmManager.set(2, SystemClock.elapsedRealtime() + paramInt, localPendingIntent);
  }

  private boolean trySetupData(ApnContext paramApnContext)
  {
    boolean bool = false;
    log("trySetupData for type:" + paramApnContext.getApnType() + " due to " + paramApnContext.getReason() + " apnContext=" + paramApnContext);
    log("trySetupData with mIsPsRestricted=" + this.mIsPsRestricted);
    if (this.mPhone.getSimulatedRadioControl() != null)
    {
      paramApnContext.setState(DctConstants.State.CONNECTED);
      this.mPhone.notifyDataConnection(paramApnContext.getReason(), paramApnContext.getApnType());
      log("trySetupData: X We're on the simulator; assuming connected retValue=true");
      bool = true;
    }
    while (true)
    {
      return bool;
      this.mPhone.getServiceStateTracker().getDesiredPowerState();
      if ((paramApnContext.isConnectable()) && (isDataAllowed(paramApnContext)) && (getAnyDataEnabled()) && (!isEmergency()))
      {
        if (paramApnContext.getState() == DctConstants.State.FAILED)
        {
          log("trySetupData: make a FAILED ApnContext IDLE so its reusable");
          paramApnContext.setState(DctConstants.State.IDLE);
        }
        int i = this.mPhone.getServiceState().getRilDataRadioTechnology();
        if (paramApnContext.getState() == DctConstants.State.IDLE)
        {
          ArrayList localArrayList = buildWaitingApns(paramApnContext.getApnType(), i);
          if (localArrayList.isEmpty())
          {
            notifyNoData(DcFailCause.MISSING_UNKNOWN_APN, paramApnContext);
            notifyOffApnsOfAvailability(paramApnContext.getReason());
            log("trySetupData: X No APN found retValue=false");
          }
          else
          {
            paramApnContext.setWaitingApns(localArrayList);
            log("trySetupData: Create from mAllApnSettings : " + apnListToString(this.mAllApnSettings));
          }
        }
        else
        {
          log("trySetupData: call setupData, waitingApns : " + apnListToString(paramApnContext.getWaitingApns()));
          bool = setupData(paramApnContext, i);
          notifyOffApnsOfAvailability(paramApnContext.getReason());
          log("trySetupData: X retValue=" + bool);
        }
      }
      else
      {
        if ((!paramApnContext.getApnType().equals("default")) && (paramApnContext.isConnectable()))
          this.mPhone.notifyDataConnectionFailed(paramApnContext.getReason(), paramApnContext.getApnType());
        notifyOffApnsOfAvailability(paramApnContext.getReason());
        log("trySetupData: X apnContext not 'ready' retValue=false");
      }
    }
  }

  protected boolean cleanUpAllConnections(boolean paramBoolean, String paramString)
  {
    log("cleanUpAllConnections: tearDown=" + paramBoolean + " reason=" + paramString);
    boolean bool = false;
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if (!localApnContext.isDisconnected())
        bool = true;
      localApnContext.setReason(paramString);
      cleanUpConnection(paramBoolean, localApnContext);
    }
    stopNetStatPoll();
    stopDataStallAlarm();
    this.mRequestedApnType = "default";
    return bool;
  }

  protected void completeConnection(ApnContext paramApnContext)
  {
    paramApnContext.isProvisioningApn();
    log("completeConnection: successful, notify the world apnContext=" + paramApnContext);
    Intent localIntent;
    if ((this.mIsProvisioning) && (!TextUtils.isEmpty(this.mProvisioningUrl)))
    {
      log("completeConnection: MOBILE_PROVISIONING_ACTION url=" + this.mProvisioningUrl);
      localIntent = Intent.makeMainSelectorActivity("android.intent.action.MAIN", "android.intent.category.APP_BROWSER");
      localIntent.setData(Uri.parse(this.mProvisioningUrl));
      localIntent.setFlags(272629760);
    }
    try
    {
      this.mPhone.getContext().startActivity(localIntent);
      this.mIsProvisioning = false;
      this.mProvisioningUrl = null;
      this.mPhone.notifyDataConnection(paramApnContext.getReason(), paramApnContext.getApnType());
      startNetStatPoll();
      startDataStallAlarm(false);
      return;
    }
    catch (ActivityNotFoundException localActivityNotFoundException)
    {
      while (true)
        loge("completeConnection: startActivityAsUser failed" + localActivityNotFoundException);
    }
  }

  public int disableApnType(String paramString)
  {
    try
    {
      log("disableApnType:" + paramString);
      ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
      int i;
      if (localApnContext != null)
      {
        setEnabled(apnTypeToId(paramString), false);
        if ((localApnContext.getState() != DctConstants.State.IDLE) && (localApnContext.getState() != DctConstants.State.FAILED))
        {
          log("diableApnType: return APN_REQUEST_STARTED");
          i = 1;
        }
      }
      while (true)
      {
        return i;
        log("disableApnType: return APN_ALREADY_INACTIVE");
        i = 4;
        continue;
        log("disableApnType: no apn context was found, return APN_REQUEST_FAILED");
        i = 3;
      }
    }
    finally
    {
    }
  }

  public void dispose()
  {
    log("GsmDCT.dispose");
    cleanUpAllConnections(true, null);
    super.dispose();
    this.mPhone.mCi.unregisterForAvailable(this);
    this.mPhone.mCi.unregisterForOffOrNotAvailable(this);
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null)
      localIccRecords.unregisterForRecordsLoaded(this);
    this.mPhone.mCi.unregisterForDataNetworkStateChanged(this);
    this.mPhone.getCallTracker().unregisterForVoiceCallEnded(this);
    this.mPhone.getCallTracker().unregisterForVoiceCallStarted(this);
    this.mPhone.getServiceStateTracker().unregisterForDataConnectionAttached(this);
    this.mPhone.getServiceStateTracker().unregisterForDataConnectionDetached(this);
    this.mPhone.getServiceStateTracker().unregisterForRoamingOn(this);
    this.mPhone.getServiceStateTracker().unregisterForRoamingOff(this);
    this.mPhone.getServiceStateTracker().unregisterForPsRestrictedEnabled(this);
    this.mPhone.getServiceStateTracker().unregisterForPsRestrictedDisabled(this);
    this.mPhone.getContext().getContentResolver().unregisterContentObserver(this.mApnObserver);
    this.mApnContexts.clear();
    this.mPrioritySortedApnContexts.clear();
    destroyDataConnections();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("DataConnectionTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mReregisterOnReconnectFailure=" + this.mReregisterOnReconnectFailure);
    paramPrintWriter.println(" canSetPreferApn=" + this.mCanSetPreferApn);
    paramPrintWriter.println(" mApnObserver=" + this.mApnObserver);
    paramPrintWriter.println(" getOverallState=" + getOverallState());
    paramPrintWriter.println(" mDataConnectionAsyncChannels=%s\n" + this.mDataConnectionAcHashMap);
    paramPrintWriter.println(" mAttached=" + this.mAttached.get());
  }

  public int enableApnType(String paramString)
  {
    int i = 1;
    try
    {
      ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
      if ((localApnContext == null) || (!isApnTypeAvailable(paramString)))
      {
        log("enableApnType: " + paramString + " is type not available");
        i = 2;
      }
      while (true)
      {
        return i;
        log("enableApnType: " + paramString + " mState(" + localApnContext.getState() + ")");
        if (localApnContext.getState() == DctConstants.State.CONNECTED)
        {
          log("enableApnType: return APN_ALREADY_ACTIVE");
          i = 0;
        }
        else
        {
          setEnabled(apnTypeToId(paramString), true);
          log("enableApnType: new apn request for type " + paramString + " return APN_REQUEST_STARTED");
        }
      }
    }
    finally
    {
    }
  }

  protected void finalize()
  {
    log("finalize");
  }

  public String getActiveApnString(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    ApnSetting localApnSetting;
    if (localApnContext != null)
    {
      localApnSetting = localApnContext.getApnSetting();
      if (localApnSetting == null);
    }
    for (String str = localApnSetting.apn; ; str = null)
      return str;
  }

  public String[] getActiveApnTypes()
  {
    log("get all active apn types");
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if ((this.mAttached.get()) && (localApnContext.isReady()))
        localArrayList.add(localApnContext.getApnType());
    }
    return (String[])localArrayList.toArray(new String[0]);
  }

  // ERROR //
  public boolean getAnyDataEnabled()
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: getfield 1421	com/android/internal/telephony/dataconnection/DcTrackerBase:mDataEnabledLock	Ljava/lang/Object;
    //   6: astore_2
    //   7: aload_2
    //   8: monitorenter
    //   9: aload_0
    //   10: invokestatic 1427	com/android/internal/telephony/dataconnection/Injector$DcTrackerHook:isMmsDataEnabled	(Lcom/android/internal/telephony/dataconnection/DcTracker;)Z
    //   13: ifeq +8 -> 21
    //   16: aload_2
    //   17: monitorexit
    //   18: goto +85 -> 103
    //   21: aload_0
    //   22: getfield 1430	com/android/internal/telephony/dataconnection/DcTrackerBase:mInternalDataEnabled	Z
    //   25: ifeq +16 -> 41
    //   28: aload_0
    //   29: getfield 1433	com/android/internal/telephony/dataconnection/DcTrackerBase:mUserDataEnabled	Z
    //   32: ifeq +9 -> 41
    //   35: getstatic 1436	com/android/internal/telephony/dataconnection/DcTracker:sPolicyDataEnabled	Z
    //   38: ifne +10 -> 48
    //   41: aload_2
    //   42: monitorexit
    //   43: iconst_0
    //   44: istore_1
    //   45: goto +58 -> 103
    //   48: aload_0
    //   49: getfield 165	com/android/internal/telephony/dataconnection/DcTrackerBase:mApnContexts	Ljava/util/concurrent/ConcurrentHashMap;
    //   52: invokevirtual 171	java/util/concurrent/ConcurrentHashMap:values	()Ljava/util/Collection;
    //   55: invokeinterface 177 1 0
    //   60: astore 4
    //   62: aload 4
    //   64: invokeinterface 183 1 0
    //   69: ifeq +30 -> 99
    //   72: aload_0
    //   73: aload 4
    //   75: invokeinterface 187 1 0
    //   80: checkcast 189	com/android/internal/telephony/dataconnection/ApnContext
    //   83: invokespecial 1209	com/android/internal/telephony/dataconnection/DcTracker:isDataAllowed	(Lcom/android/internal/telephony/dataconnection/ApnContext;)Z
    //   86: ifeq -24 -> 62
    //   89: aload_2
    //   90: monitorexit
    //   91: goto +12 -> 103
    //   94: astore_3
    //   95: aload_2
    //   96: monitorexit
    //   97: aload_3
    //   98: athrow
    //   99: aload_2
    //   100: monitorexit
    //   101: iconst_0
    //   102: istore_1
    //   103: iload_1
    //   104: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   9	97	94	finally
    //   99	101	94	finally
  }

  protected int getApnProfileID(String paramString)
  {
    int i = 0;
    if (TextUtils.equals(paramString, "ims"))
      i = 2;
    while (true)
    {
      return i;
      if (TextUtils.equals(paramString, "fota"))
        i = 3;
      else if (TextUtils.equals(paramString, "cbs"))
        i = 4;
      else if ((!TextUtils.equals(paramString, "ia")) && (TextUtils.equals(paramString, "dun")))
        i = 1;
    }
  }

  public LinkCapabilities getLinkCapabilities(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    DcAsyncChannel localDcAsyncChannel;
    if (localApnContext != null)
    {
      localDcAsyncChannel = localApnContext.getDcAc();
      if (localDcAsyncChannel != null)
        log("get active pdp is not null, return link Capabilities for " + paramString);
    }
    for (LinkCapabilities localLinkCapabilities = localDcAsyncChannel.getLinkCapabilitiesSync(); ; localLinkCapabilities = new LinkCapabilities())
    {
      return localLinkCapabilities;
      log("return new LinkCapabilities");
    }
  }

  public LinkProperties getLinkProperties(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    DcAsyncChannel localDcAsyncChannel;
    if (localApnContext != null)
    {
      localDcAsyncChannel = localApnContext.getDcAc();
      if (localDcAsyncChannel != null)
        log("return link properites for " + paramString);
    }
    for (LinkProperties localLinkProperties = localDcAsyncChannel.getLinkPropertiesSync(); ; localLinkProperties = new LinkProperties())
    {
      return localLinkProperties;
      log("return new LinkProperties");
    }
  }

  public DctConstants.State getOverallState()
  {
    int i = 0;
    int j = 1;
    int k = 0;
    Iterator localIterator = this.mApnContexts.values().iterator();
    DctConstants.State localState;
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if (localApnContext.isEnabled())
      {
        k = 1;
        switch (1.$SwitchMap$com$android$internal$telephony$DctConstants$State[localApnContext.getState().ordinal()])
        {
        default:
          k = 1;
          break;
        case 1:
        case 2:
          log("overall state is CONNECTED");
          localState = DctConstants.State.CONNECTED;
        case 3:
        case 4:
        case 5:
        case 6:
        }
      }
    }
    while (true)
    {
      return localState;
      i = 1;
      j = 0;
      break;
      j = 0;
      break;
      if (k == 0)
      {
        log("overall state is IDLE");
        localState = DctConstants.State.IDLE;
      }
      else if (i != 0)
      {
        log("overall state is CONNECTING");
        localState = DctConstants.State.CONNECTING;
      }
      else if (j == 0)
      {
        log("overall state is IDLE");
        localState = DctConstants.State.IDLE;
      }
      else
      {
        log("overall state is FAILED");
        localState = DctConstants.State.FAILED;
      }
    }
  }

  public DctConstants.State getState(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    if (localApnContext != null);
    for (DctConstants.State localState = localApnContext.getState(); ; localState = DctConstants.State.FAILED)
      return localState;
  }

  protected void gotoIdleAndNotifyDataConnection(String paramString)
  {
    log("gotoIdleAndNotifyDataConnection: reason=" + paramString);
    notifyDataConnection(paramString);
    this.mActiveApn = null;
  }

  public void handleMessage(Message paramMessage)
  {
    boolean bool = false;
    log("handleMessage msg=" + paramMessage);
    if ((!this.mPhone.mIsTheCurrentActivePhone) || (this.mIsDisposed))
      loge("handleMessage: Ignore GSM msgs since GSM phone is inactive");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      case 270342:
      case 270343:
      case 270344:
      case 270346:
      case 270347:
      case 270348:
      case 270349:
      case 270350:
      case 270351:
      case 270353:
      case 270356:
      case 270357:
      default:
        super.handleMessage(paramMessage);
        break;
      case 270338:
        onRecordsLoaded();
        break;
      case 270345:
        onDataConnectionDetached();
        break;
      case 270352:
        onDataConnectionAttached();
        break;
      case 270340:
        onDataStateChanged((AsyncResult)paramMessage.obj);
        break;
      case 270341:
        onPollPdp();
        break;
      case 270354:
        doRecovery();
        break;
      case 270355:
        onApnChanged();
        break;
      case 270358:
        log("EVENT_PS_RESTRICT_ENABLED " + this.mIsPsRestricted);
        stopNetStatPoll();
        stopDataStallAlarm();
        this.mIsPsRestricted = true;
        break;
      case 270359:
        log("EVENT_PS_RESTRICT_DISABLED " + this.mIsPsRestricted);
        this.mIsPsRestricted = false;
        if (isConnected())
        {
          startNetStatPoll();
          startDataStallAlarm(false);
        }
        else
        {
          if (this.mState == DctConstants.State.FAILED)
          {
            cleanUpAllConnections(false, "psRestrictEnabled");
            this.mReregisterOnReconnectFailure = false;
          }
          ApnContext localApnContext = (ApnContext)this.mApnContexts.get("default");
          if (localApnContext != null)
          {
            localApnContext.setReason("psRestrictEnabled");
            trySetupData(localApnContext);
          }
          else
          {
            loge("**** Default ApnContext not found ****");
            if (Build.IS_DEBUGGABLE)
              throw new RuntimeException("Default ApnContext not found");
          }
        }
        break;
      case 270339:
        if ((paramMessage.obj instanceof ApnContext))
          onTrySetupData((ApnContext)paramMessage.obj);
        else if ((paramMessage.obj instanceof String))
          onTrySetupData((String)paramMessage.obj);
        else
          loge("EVENT_TRY_SETUP request w/o apnContext or String");
        break;
      case 270360:
        if (paramMessage.arg1 == 0);
        while (true)
        {
          log("EVENT_CLEAN_UP_CONNECTION tearDown=" + bool);
          if (!(paramMessage.obj instanceof ApnContext))
            break label525;
          cleanUpConnection(bool, (ApnContext)paramMessage.obj);
          break;
          bool = true;
        }
        label525: loge("EVENT_CLEAN_UP_CONNECTION request w/o apn context, call super");
        super.handleMessage(paramMessage);
      }
    }
  }

  protected void initApnContexts()
  {
    log("initApnContexts: E");
    boolean bool = SystemProperties.getBoolean("net.def_data_on_boot", true);
    String[] arrayOfString = this.mPhone.getContext().getResources().getStringArray(17235979);
    int i = arrayOfString.length;
    int j = 0;
    while (j < i)
    {
      NetworkConfig localNetworkConfig = new NetworkConfig(arrayOfString[j]);
      ApnContext localApnContext;
      switch (localNetworkConfig.type)
      {
      case 1:
      case 6:
      case 7:
      case 8:
      case 9:
      case 13:
      default:
        log("initApnContexts: skipping unknown type=" + localNetworkConfig.type);
        j++;
        break;
      case 0:
        localApnContext = addApnContext("default", localNetworkConfig);
        localApnContext.setEnabled(bool);
      case 2:
      case 3:
      case 4:
      case 5:
      case 10:
      case 11:
      case 12:
      case 14:
        while (true)
        {
          log("initApnContexts: apnContext=" + localApnContext);
          break;
          localApnContext = addApnContext("mms", localNetworkConfig);
          continue;
          localApnContext = addApnContext("supl", localNetworkConfig);
          continue;
          localApnContext = addApnContext("dun", localNetworkConfig);
          continue;
          localApnContext = addApnContext("hipri", localNetworkConfig);
          continue;
          localApnContext = addApnContext("fota", localNetworkConfig);
          continue;
          localApnContext = addApnContext("ims", localNetworkConfig);
          continue;
          localApnContext = addApnContext("cbs", localNetworkConfig);
          continue;
          localApnContext = addApnContext("ia", localNetworkConfig);
        }
      }
    }
    log("initApnContexts: X mApnContexts=" + this.mApnContexts);
  }

  public boolean isApnTypeActive(String paramString)
  {
    boolean bool = false;
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    if (localApnContext == null);
    while (true)
    {
      return bool;
      if (localApnContext.getDcAc() != null)
        bool = true;
    }
  }

  protected boolean isApnTypeAvailable(String paramString)
  {
    boolean bool = true;
    if ((paramString.equals("dun")) && (fetchDunApn() != null));
    while (true)
    {
      return bool;
      if (this.mAllApnSettings != null)
      {
        Iterator localIterator = this.mAllApnSettings.iterator();
        while (true)
          if (localIterator.hasNext())
            if (((ApnSetting)localIterator.next()).canHandleType(paramString))
              break;
      }
      bool = false;
    }
  }

  public boolean isApnTypeEnabled(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    if (localApnContext == null);
    for (boolean bool = false; ; bool = localApnContext.isEnabled())
      return bool;
  }

  protected boolean isConnected()
  {
    Iterator localIterator = this.mApnContexts.values().iterator();
    do
      if (!localIterator.hasNext())
        break;
    while (((ApnContext)localIterator.next()).getState() != DctConstants.State.CONNECTED);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected boolean isDataAllowed()
  {
    boolean bool1 = false;
    while (true)
    {
      synchronized (this.mDataEnabledLock)
      {
        boolean bool2 = this.mInternalDataEnabled;
        boolean bool3 = this.mAttached.get();
        boolean bool4 = this.mPhone.getServiceStateTracker().getDesiredPowerState();
        IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
        if (localIccRecords != null)
        {
          bool5 = localIccRecords.getRecordsLoaded();
          if (((bool3) || (this.mAutoAttachOnCreation)) && (bool5) && ((this.mPhone.getState() == PhoneConstants.State.IDLE) || (this.mPhone.getServiceStateTracker().isConcurrentVoiceAndDataAllowed())) && (bool2) && ((!this.mPhone.getServiceState().getRoaming()) || (getDataOnRoamingEnabled())) && (!this.mIsPsRestricted) && (bool4))
            bool1 = true;
          if (!bool1)
          {
            String str1 = "";
            if ((!bool3) && (!this.mAutoAttachOnCreation))
              str1 = str1 + " - Attached= " + bool3;
            if (!bool5)
              str1 = str1 + " - SIM not loaded";
            if ((this.mPhone.getState() != PhoneConstants.State.IDLE) && (!this.mPhone.getServiceStateTracker().isConcurrentVoiceAndDataAllowed()))
            {
              String str2 = str1 + " - PhoneState= " + this.mPhone.getState();
              str1 = str2 + " - Concurrent voice and data not allowed";
            }
            if (!bool2)
              str1 = str1 + " - mInternalDataEnabled= false";
            if ((this.mPhone.getServiceState().getRoaming()) && (!getDataOnRoamingEnabled()))
              str1 = str1 + " - Roaming and data roaming not enabled";
            if (this.mIsPsRestricted)
              str1 = str1 + " - mIsPsRestricted= true";
            if (!bool4)
              str1 = str1 + " - desiredPowerState= false";
            log("isDataAllowed: not allowed due to" + str1);
          }
          return bool1;
        }
      }
      boolean bool5 = false;
    }
  }

  public boolean isDataPossible(String paramString)
  {
    boolean bool1 = false;
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    if (localApnContext == null)
      return bool1;
    boolean bool2 = localApnContext.isEnabled();
    DctConstants.State localState = localApnContext.getState();
    int i;
    if ((!bool2) || (localState != DctConstants.State.FAILED))
    {
      i = 1;
      label48: if ((!isDataAllowed()) || (i == 0))
        break label75;
    }
    label75: for (boolean bool3 = true; ; bool3 = false)
    {
      bool1 = bool3;
      break;
      i = 0;
      break label48;
    }
  }

  public boolean isDisconnected()
  {
    Iterator localIterator = this.mApnContexts.values().iterator();
    do
      if (!localIterator.hasNext())
        break;
    while (((ApnContext)localIterator.next()).isDisconnected());
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  protected boolean isProvisioningApn(String paramString)
  {
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(paramString);
    if (localApnContext != null);
    for (boolean bool = localApnContext.isProvisioningApn(); ; bool = false)
      return bool;
  }

  protected void log(String paramString)
  {
    Rlog.d("DCT", paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("DCT", paramString);
  }

  protected void notifyDataConnection(String paramString)
  {
    log("notifyDataConnection: reason=" + paramString);
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if ((this.mAttached.get()) && (localApnContext.isReady()))
      {
        log("notifyDataConnection: type:" + localApnContext.getApnType());
        PhoneBase localPhoneBase = this.mPhone;
        if (paramString != null);
        for (String str = paramString; ; str = localApnContext.getReason())
        {
          localPhoneBase.notifyDataConnection(str, localApnContext.getApnType());
          break;
        }
      }
    }
    notifyOffApnsOfAvailability(paramString);
  }

  protected void notifyOffApnsOfAvailability(String paramString)
  {
    Iterator localIterator = this.mApnContexts.values().iterator();
    while (localIterator.hasNext())
    {
      ApnContext localApnContext = (ApnContext)localIterator.next();
      if ((!this.mAttached.get()) || (!localApnContext.isReady()))
      {
        PhoneBase localPhoneBase = this.mPhone;
        if (paramString != null);
        for (String str = paramString; ; str = localApnContext.getReason())
        {
          localPhoneBase.notifyDataConnection(str, localApnContext.getApnType(), PhoneConstants.DataState.DISCONNECTED);
          break;
        }
      }
    }
  }

  protected void onCleanUpAllConnections(String paramString)
  {
    cleanUpAllConnections(true, paramString);
  }

  protected void onCleanUpConnection(boolean paramBoolean, int paramInt, String paramString)
  {
    log("onCleanUpConnection");
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(apnIdToType(paramInt));
    if (localApnContext != null)
    {
      localApnContext.setReason(paramString);
      cleanUpConnection(paramBoolean, localApnContext);
    }
  }

  protected void onDataConnectionDetached()
  {
    log("onDataConnectionDetached: stop polling and notify detached");
    stopNetStatPoll();
    stopDataStallAlarm();
    notifyDataConnection("dataDetached");
    this.mAttached.set(false);
  }

  protected void onDataSetupComplete(AsyncResult paramAsyncResult)
  {
    int i = 0;
    ApnContext localApnContext;
    DcAsyncChannel localDcAsyncChannel;
    if ((paramAsyncResult.userObj instanceof ApnContext))
    {
      localApnContext = (ApnContext)paramAsyncResult.userObj;
      if (paramAsyncResult.exception != null)
        break label600;
      localDcAsyncChannel = localApnContext.getDcAc();
      if (localDcAsyncChannel != null)
        break label78;
      log("onDataSetupComplete: no connection to DC, handle as error");
      i = 1;
    }
    while (true)
    {
      if (i != 0)
        onDataSetupCompleteError(paramAsyncResult);
      return;
      throw new RuntimeException("onDataSetupComplete: No apnContext");
      label78: ApnSetting localApnSetting2 = localApnContext.getApnSetting();
      StringBuilder localStringBuilder = new StringBuilder().append("onDataSetupComplete: success apn=");
      String str2;
      if (localApnSetting2 == null)
      {
        str2 = "unknown";
        log(str2);
        if ((localApnSetting2 == null) || (localApnSetting2.proxy == null) || (localApnSetting2.proxy.length() == 0));
      }
      try
      {
        String str5 = localApnSetting2.port;
        if (TextUtils.isEmpty(str5))
          str5 = "8080";
        localDcAsyncChannel.setLinkPropertiesHttpProxySync(new ProxyProperties(localApnSetting2.proxy, Integer.parseInt(str5), null));
        Injector.DcTrackerHook.onDataSetupComplete(localApnContext, localApnContext.getApnSetting());
        if (TextUtils.equals(localApnContext.getApnType(), "default"))
        {
          SystemProperties.set("gsm.defaultpdpcontext.active", "true");
          if ((this.mCanSetPreferApn) && (this.mPreferredApn == null))
          {
            log("onDataSetupComplete: PREFERED APN is null");
            this.mPreferredApn = localApnSetting2;
            if (this.mPreferredApn != null)
              setPreferredApn(this.mPreferredApn.id);
          }
          localApnContext.setState(DctConstants.State.CONNECTED);
          bool = localApnContext.isProvisioningApn();
          if ((bool) && (!this.mIsProvisioning))
            break label411;
          completeConnection(localApnContext);
          log("onDataSetupComplete: SETUP complete type=" + localApnContext.getApnType() + ", reason:" + localApnContext.getReason());
          continue;
          str2 = localApnSetting2.apn;
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        while (true)
        {
          boolean bool;
          loge("onDataSetupComplete: NumberFormatException making ProxyProperties (" + localApnSetting2.port + "): " + localNumberFormatException);
          continue;
          SystemProperties.set("gsm.defaultpdpcontext.active", "false");
          continue;
          label411: log("onDataSetupComplete: successful, BUT send connected to prov apn as mIsProvisioning:" + this.mIsProvisioning + " == false" + " && (isProvisioningApn:" + bool + " == true");
          Intent localIntent = new Intent("android.intent.action.DATA_CONNECTION_CONNECTED_TO_PROVISIONING_APN");
          localIntent.putExtra("apn", localApnContext.getApnSetting().apn);
          localIntent.putExtra("apnType", localApnContext.getApnType());
          String str3 = localApnContext.getApnType();
          LinkProperties localLinkProperties = getLinkProperties(str3);
          if (localLinkProperties != null)
          {
            localIntent.putExtra("linkProperties", localLinkProperties);
            String str4 = localLinkProperties.getInterfaceName();
            if (str4 != null)
              localIntent.putExtra("iface", str4);
          }
          LinkCapabilities localLinkCapabilities = getLinkCapabilities(str3);
          if (localLinkCapabilities != null)
            localIntent.putExtra("linkCapabilities", localLinkCapabilities);
          this.mPhone.getContext().sendBroadcastAsUser(localIntent, UserHandle.ALL);
        }
      }
    }
    label600: DcFailCause localDcFailCause = (DcFailCause)paramAsyncResult.result;
    ApnSetting localApnSetting1 = localApnContext.getApnSetting();
    Object[] arrayOfObject1 = new Object[2];
    if (localApnSetting1 == null);
    for (String str1 = "unknown"; ; str1 = localApnSetting1.apn)
    {
      arrayOfObject1[0] = str1;
      arrayOfObject1[1] = localDcFailCause;
      log(String.format("onDataSetupComplete: error apn=%s cause=%s", arrayOfObject1));
      if (localDcFailCause.isEventLoggable())
      {
        int j = getCellLocationId();
        Object[] arrayOfObject3 = new Object[3];
        arrayOfObject3[0] = Integer.valueOf(localDcFailCause.ordinal());
        arrayOfObject3[1] = Integer.valueOf(j);
        arrayOfObject3[2] = Integer.valueOf(TelephonyManager.getDefault().getNetworkType());
        EventLog.writeEvent(50105, arrayOfObject3);
      }
      if (localDcFailCause.isPermanentFail())
        localApnContext.decWaitingApnsPermFailCount();
      localApnContext.removeWaitingApn(localApnContext.getApnSetting());
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(localApnContext.getWaitingApns().size());
      arrayOfObject2[1] = Integer.valueOf(localApnContext.getWaitingApnsPermFailCount());
      log(String.format("onDataSetupComplete: WaitingApns.size=%d WaitingApnsPermFailureCountDown=%d", arrayOfObject2));
      i = 1;
      break;
    }
  }

  protected void onDataSetupCompleteError(AsyncResult paramAsyncResult)
  {
    ApnContext localApnContext;
    if ((paramAsyncResult.userObj instanceof ApnContext))
    {
      localApnContext = (ApnContext)paramAsyncResult.userObj;
      if (!localApnContext.getWaitingApns().isEmpty())
        break label118;
      localApnContext.setState(DctConstants.State.FAILED);
      this.mPhone.notifyDataConnection("apnFailed", localApnContext.getApnType());
      localApnContext.setDataConnectionAc(null);
      if (localApnContext.getWaitingApnsPermFailCount() != 0)
        break label80;
      log("onDataSetupCompleteError: All APN's had permanent failures, stop retrying");
    }
    while (true)
    {
      return;
      throw new RuntimeException("onDataSetupCompleteError: No apnContext");
      label80: int i = getApnDelay();
      log("onDataSetupCompleteError: Not all APN's had permanent failures delay=" + i);
      startAlarmForRestartTrySetup(i, localApnContext);
      continue;
      label118: log("onDataSetupCompleteError: Try next APN");
      localApnContext.setState(DctConstants.State.SCANNING);
      startAlarmForReconnect(getApnDelay(), localApnContext);
    }
  }

  protected void onDisconnectDcRetrying(int paramInt, AsyncResult paramAsyncResult)
  {
    if ((paramAsyncResult.userObj instanceof ApnContext))
    {
      ApnContext localApnContext = (ApnContext)paramAsyncResult.userObj;
      localApnContext.setState(DctConstants.State.RETRYING);
      log("onDisconnectDcRetrying: apnContext=" + localApnContext);
      this.mPhone.notifyDataConnection(localApnContext.getReason(), localApnContext.getApnType());
    }
    while (true)
    {
      return;
      loge("onDisconnectDcRetrying: Invalid ar in onDisconnectDone, ignore");
    }
  }

  protected void onDisconnectDone(int paramInt, AsyncResult paramAsyncResult)
  {
    ApnContext localApnContext;
    if ((paramAsyncResult.userObj instanceof ApnContext))
    {
      localApnContext = (ApnContext)paramAsyncResult.userObj;
      log("onDisconnectDone: EVENT_DISCONNECT_DONE apnContext=" + localApnContext);
      localApnContext.setState(DctConstants.State.IDLE);
      Injector.DcTrackerHook.onDisconnectDone(localApnContext, localApnContext.getApnSetting());
      this.mPhone.notifyDataConnection(localApnContext.getReason(), localApnContext.getApnType());
      if ((!isDisconnected()) || (!this.mPhone.getServiceStateTracker().processPendingRadioPowerOffAfterDataOff()))
        break label120;
      log("onDisconnectDone: radio will be turned off, no retries");
      localApnContext.setApnSetting(null);
      localApnContext.setDataConnectionAc(null);
    }
    while (true)
    {
      return;
      loge("onDisconnectDone: Invalid ar in onDisconnectDone, ignore");
      continue;
      label120: if ((this.mAttached.get()) && (localApnContext.isReady()) && (retryAfterDisconnected(localApnContext)))
      {
        SystemProperties.set("gsm.defaultpdpcontext.active", "false");
        log("onDisconnectDone: attached, ready and retry after disconnect");
        startAlarmForReconnect(getApnDelay(), localApnContext);
      }
      else
      {
        boolean bool = this.mPhone.getContext().getResources().getBoolean(17891413);
        if ((localApnContext.isProvisioningApn()) && (bool))
        {
          log("onDisconnectDone: restartRadio after provisioning");
          restartRadio();
        }
        localApnContext.setApnSetting(null);
        localApnContext.setDataConnectionAc(null);
        if (isOnlySingleDcAllowed(this.mPhone.getServiceState().getRilDataRadioTechnology()))
        {
          log("onDisconnectDone: isOnlySigneDcAllowed true so setup single apn");
          setupDataOnConnectableApns("SinglePdnArbitration");
        }
        else
        {
          log("onDisconnectDone: not retrying");
        }
      }
    }
  }

  protected void onEnableApn(int paramInt1, int paramInt2)
  {
    int i = 1;
    ApnContext localApnContext = (ApnContext)this.mApnContexts.get(apnIdToType(paramInt1));
    if (localApnContext == null)
    {
      loge("onEnableApn(" + paramInt1 + ", " + paramInt2 + "): NO ApnContext");
      return;
    }
    log("onEnableApn: apnContext=" + localApnContext + " call applyNewState");
    if (paramInt2 == i);
    while (true)
    {
      applyNewState(localApnContext, i, localApnContext.getDependencyMet());
      break;
      i = 0;
    }
  }

  protected void onPollPdp()
  {
    if (getOverallState() == DctConstants.State.CONNECTED)
    {
      this.mPhone.mCi.getDataCallList(obtainMessage(270340));
      sendMessageDelayed(obtainMessage(270341), 5000L);
    }
  }

  protected void onRadioAvailable()
  {
    log("onRadioAvailable");
    if (this.mPhone.getSimulatedRadioControl() != null)
    {
      notifyDataConnection(null);
      log("onRadioAvailable: We're on the simulator; assuming data is connected");
    }
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if ((localIccRecords != null) && (localIccRecords.getRecordsLoaded()))
      notifyOffApnsOfAvailability(null);
    if (getOverallState() != DctConstants.State.IDLE)
      cleanUpConnection(true, null);
  }

  protected void onRadioOffOrNotAvailable()
  {
    this.mReregisterOnReconnectFailure = false;
    if (this.mPhone.getSimulatedRadioControl() != null)
      log("We're on the simulator; assuming radio off is meaningless");
    while (true)
    {
      notifyOffApnsOfAvailability(null);
      return;
      log("onRadioOffOrNotAvailable: is off and clean up all connections");
      cleanUpAllConnections(false, "radioTurnedOff");
    }
  }

  protected void onRoamingOff()
  {
    log("onRoamingOff");
    if (!this.mUserDataEnabled);
    while (true)
    {
      return;
      if (!getDataOnRoamingEnabled())
      {
        notifyOffApnsOfAvailability("roamingOff");
        setupDataOnConnectableApns("roamingOff");
      }
      else
      {
        notifyDataConnection("roamingOff");
      }
    }
  }

  protected void onRoamingOn()
  {
    if (!this.mUserDataEnabled);
    while (true)
    {
      return;
      if (getDataOnRoamingEnabled())
      {
        log("onRoamingOn: setup data on roaming");
        setupDataOnConnectableApns("roamingOn");
        notifyDataConnection("roamingOn");
      }
      else
      {
        log("onRoamingOn: Tear down data connection on roaming.");
        cleanUpAllConnections(true, "roamingOn");
        notifyOffApnsOfAvailability("roamingOn");
      }
    }
  }

  protected void onSetDependencyMet(String paramString, boolean paramBoolean)
  {
    if ("hipri".equals(paramString));
    while (true)
    {
      return;
      ApnContext localApnContext1 = (ApnContext)this.mApnContexts.get(paramString);
      if (localApnContext1 == null)
      {
        loge("onSetDependencyMet: ApnContext not found in onSetDependencyMet(" + paramString + ", " + paramBoolean + ")");
      }
      else
      {
        applyNewState(localApnContext1, localApnContext1.isEnabled(), paramBoolean);
        if ("default".equals(paramString))
        {
          ApnContext localApnContext2 = (ApnContext)this.mApnContexts.get("hipri");
          if (localApnContext2 != null)
            applyNewState(localApnContext2, localApnContext2.isEnabled(), paramBoolean);
        }
      }
    }
  }

  protected boolean onTrySetupData(ApnContext paramApnContext)
  {
    log("onTrySetupData: apnContext=" + paramApnContext);
    return trySetupData(paramApnContext);
  }

  protected boolean onTrySetupData(String paramString)
  {
    log("onTrySetupData: reason=" + paramString);
    setupDataOnConnectableApns(paramString);
    return true;
  }

  protected void onUpdateIcc()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      IccRecords localIccRecords1 = this.mUiccController.getIccRecords(1);
      IccRecords localIccRecords2 = (IccRecords)this.mIccRecords.get();
      if (localIccRecords2 != localIccRecords1)
      {
        if (localIccRecords2 != null)
        {
          log("Removing stale icc objects.");
          localIccRecords2.unregisterForRecordsLoaded(this);
          this.mIccRecords.set(null);
        }
        if (localIccRecords1 != null)
        {
          log("New records found");
          this.mIccRecords.set(localIccRecords1);
          localIccRecords1.registerForRecordsLoaded(this, 270338, null);
        }
      }
    }
  }

  protected void onVoiceCallEnded()
  {
    log("onVoiceCallEnded");
    this.mInVoiceCall = false;
    if (isConnected())
    {
      if (this.mPhone.getServiceStateTracker().isConcurrentVoiceAndDataAllowed())
        break label56;
      startNetStatPoll();
      startDataStallAlarm(false);
      notifyDataConnection("2GVoiceCallEnded");
    }
    while (true)
    {
      setupDataOnConnectableApns("2GVoiceCallEnded");
      return;
      label56: resetPollStats();
    }
  }

  protected void onVoiceCallStarted()
  {
    log("onVoiceCallStarted");
    this.mInVoiceCall = true;
    if ((isConnected()) && (!this.mPhone.getServiceStateTracker().isConcurrentVoiceAndDataAllowed()))
    {
      log("onVoiceCallStarted stop polling");
      stopNetStatPoll();
      stopDataStallAlarm();
      notifyDataConnection("2GVoiceCallStarted");
    }
  }

  protected void restartRadio()
  {
    log("restartRadio: ************TURN OFF RADIO**************");
    cleanUpAllConnections(true, "radioTurnedOff");
    this.mPhone.getServiceStateTracker().powerOffRadioSafely(this);
    SystemProperties.set("net.ppp.reset-by-timeout", String.valueOf(1 + Integer.parseInt(SystemProperties.get("net.ppp.reset-by-timeout", "0"))));
  }

  protected void setState(DctConstants.State paramState)
  {
    log("setState should not be used in GSM" + paramState);
  }

  private class ApnChangeObserver extends ContentObserver
  {
    public ApnChangeObserver()
    {
      super();
    }

    public void onChange(boolean paramBoolean)
    {
      DcTracker.this.sendMessage(DcTracker.this.obtainMessage(270355));
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.dataconnection.DcTracker
 * JD-Core Version:    0.6.2
 */