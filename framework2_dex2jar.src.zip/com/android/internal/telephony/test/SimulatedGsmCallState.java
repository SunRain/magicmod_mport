package com.android.internal.telephony.test;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import com.android.internal.telephony.DriverCall;
import java.util.ArrayList;
import java.util.List;

class SimulatedGsmCallState extends Handler
{
  static final int CONNECTING_PAUSE_MSEC = 500;
  static final int EVENT_PROGRESS_CALL_STATE = 1;
  static final int MAX_CALLS = 7;
  private boolean mAutoProgressConnecting = true;
  CallInfo[] mCalls = new CallInfo[7];
  private boolean mNextDialFailImmediately;

  public SimulatedGsmCallState(Looper paramLooper)
  {
    super(paramLooper);
  }

  private int countActiveLines()
    throws InvalidStateEx
  {
    boolean bool1 = false;
    int i = 0;
    int j = 0;
    boolean bool2 = false;
    boolean bool3 = false;
    int k = 0;
    int m = 0;
    if (m < this.mCalls.length)
    {
      CallInfo localCallInfo = this.mCalls[m];
      label68: int i1;
      if (localCallInfo != null)
      {
        if ((bool1) || (!localCallInfo.mIsMpty))
          break label146;
        if (localCallInfo.mState != CallInfo.State.HOLDING)
          break label140;
        k = 1;
        bool1 |= localCallInfo.mIsMpty;
        if (localCallInfo.mState != CallInfo.State.HOLDING)
          break label230;
        i1 = 1;
        label90: i |= i1;
        if (localCallInfo.mState != CallInfo.State.ACTIVE)
          break label236;
      }
      label140: label146: label230: label236: for (int i2 = 1; ; i2 = 0)
      {
        j |= i2;
        bool2 |= localCallInfo.isConnecting();
        bool3 |= localCallInfo.isRinging();
        m++;
        break;
        k = 0;
        break label68;
        if ((localCallInfo.mIsMpty) && (k != 0) && (localCallInfo.mState == CallInfo.State.ACTIVE))
        {
          Rlog.e("ModelInterpreter", "Invalid state");
          throw new InvalidStateEx();
        }
        if ((localCallInfo.mIsMpty) || (!bool1) || (k == 0) || (localCallInfo.mState != CallInfo.State.HOLDING))
          break label68;
        Rlog.e("ModelInterpreter", "Invalid state");
        throw new InvalidStateEx();
        i1 = 0;
        break label90;
      }
    }
    int n = 0;
    if (i != 0)
      n = 0 + 1;
    if (j != 0)
      n++;
    if (bool2)
      n++;
    if (bool3)
      n++;
    return n;
  }

  public boolean conference()
  {
    boolean bool = true;
    int i = 0;
    int j = 0;
    if (j < this.mCalls.length)
    {
      CallInfo localCallInfo2 = this.mCalls[j];
      if (localCallInfo2 != null)
      {
        i++;
        if (localCallInfo2.isConnecting())
          bool = false;
      }
    }
    while (true)
    {
      return bool;
      j++;
      break;
      for (int k = 0; k < this.mCalls.length; k++)
      {
        CallInfo localCallInfo1 = this.mCalls[k];
        if (localCallInfo1 != null)
        {
          localCallInfo1.mState = CallInfo.State.ACTIVE;
          if (i > 0)
            localCallInfo1.mIsMpty = bool;
        }
      }
    }
  }

  public boolean explicitCallTransfer()
  {
    int i = 0;
    int j = 0;
    if (j < this.mCalls.length)
    {
      CallInfo localCallInfo = this.mCalls[j];
      if (localCallInfo != null)
      {
        i++;
        if (!localCallInfo.isConnecting());
      }
    }
    for (boolean bool = false; ; bool = triggerHangupAll())
    {
      return bool;
      j++;
      break;
    }
  }

  public List<String> getClccLines()
  {
    ArrayList localArrayList = new ArrayList(this.mCalls.length);
    for (int i = 0; i < this.mCalls.length; i++)
    {
      CallInfo localCallInfo = this.mCalls[i];
      if (localCallInfo != null)
        localArrayList.add(localCallInfo.toCLCCLine(i + 1));
    }
    return localArrayList;
  }

  public List<DriverCall> getDriverCalls()
  {
    ArrayList localArrayList = new ArrayList(this.mCalls.length);
    for (int i = 0; i < this.mCalls.length; i++)
    {
      CallInfo localCallInfo = this.mCalls[i];
      if (localCallInfo != null)
        localArrayList.add(localCallInfo.toDriverCall(i + 1));
    }
    Rlog.d("GSM", "SC< getDriverCalls " + localArrayList);
    return localArrayList;
  }

  public void handleMessage(Message paramMessage)
  {
    try
    {
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
      }
      progressConnectingCallState();
    }
    finally
    {
    }
  }

  public boolean onAnswer()
  {
    for (int i = 0; ; i++)
    {
      boolean bool;
      try
      {
        if (i < this.mCalls.length)
        {
          CallInfo localCallInfo = this.mCalls[i];
          if ((localCallInfo == null) || ((localCallInfo.mState != CallInfo.State.INCOMING) && (localCallInfo.mState != CallInfo.State.WAITING)))
            continue;
          bool = switchActiveAndHeldOrWaiting();
        }
        else
        {
          bool = false;
        }
      }
      finally
      {
      }
    }
  }

  public boolean onChld(char paramChar1, char paramChar2)
  {
    int i = 0;
    boolean bool;
    if (paramChar2 != 0)
    {
      i = paramChar2 - '1';
      if ((i < 0) || (i >= this.mCalls.length))
        bool = false;
    }
    while (true)
    {
      return bool;
      switch (paramChar1)
      {
      default:
        bool = false;
        break;
      case '0':
        bool = releaseHeldOrUDUB();
        break;
      case '1':
        if (paramChar2 <= 0)
        {
          bool = releaseActiveAcceptHeldOrWaiting();
        }
        else if (this.mCalls[i] == null)
        {
          bool = false;
        }
        else
        {
          this.mCalls[i] = null;
          bool = true;
        }
        break;
      case '2':
        if (paramChar2 <= 0)
          bool = switchActiveAndHeldOrWaiting();
        else
          bool = separateCall(i);
        break;
      case '3':
        bool = conference();
        break;
      case '4':
        bool = explicitCallTransfer();
        break;
      case '5':
        bool = false;
      }
    }
  }

  public boolean onDial(String paramString)
  {
    boolean bool = false;
    int i = -1;
    Rlog.d("GSM", "SC> dial '" + paramString + "'");
    if (this.mNextDialFailImmediately)
    {
      this.mNextDialFailImmediately = false;
      Rlog.d("GSM", "SC< dial fail (per request)");
    }
    while (true)
    {
      return bool;
      String str = PhoneNumberUtils.extractNetworkPortion(paramString);
      if (str.length() == 0)
      {
        Rlog.d("GSM", "SC< dial fail (invalid ph num)");
      }
      else if ((str.startsWith("*99")) && (str.endsWith("#")))
      {
        Rlog.d("GSM", "SC< dial ignored (gprs)");
        bool = true;
      }
      else
      {
        try
        {
          if (countActiveLines() <= 1)
            break label146;
          Rlog.d("GSM", "SC< dial fail (invalid call state)");
        }
        catch (InvalidStateEx localInvalidStateEx)
        {
          Rlog.d("GSM", "SC< dial fail (invalid call state)");
        }
        continue;
        label146: for (int j = 0; ; j++)
        {
          if (j >= this.mCalls.length)
            break label255;
          if ((i < 0) && (this.mCalls[j] == null))
            i = j;
          if ((this.mCalls[j] != null) && (!this.mCalls[j].isActiveOrHeld()))
          {
            Rlog.d("GSM", "SC< dial fail (invalid call state)");
            break;
          }
          if ((this.mCalls[j] != null) && (this.mCalls[j].mState == CallInfo.State.ACTIVE))
            this.mCalls[j].mState = CallInfo.State.HOLDING;
        }
        label255: if (i < 0)
        {
          Rlog.d("GSM", "SC< dial fail (invalid call state)");
        }
        else
        {
          this.mCalls[i] = CallInfo.createOutgoingCall(str);
          if (this.mAutoProgressConnecting)
            sendMessageDelayed(obtainMessage(1, this.mCalls[i]), 500L);
          Rlog.d("GSM", "SC< dial (slot = " + i + ")");
          bool = true;
        }
      }
    }
  }

  public boolean onHangup()
  {
    boolean bool = false;
    for (int i = 0; i < this.mCalls.length; i++)
    {
      CallInfo localCallInfo = this.mCalls[i];
      if ((localCallInfo != null) && (localCallInfo.mState != CallInfo.State.WAITING))
      {
        this.mCalls[i] = null;
        bool = true;
      }
    }
    return bool;
  }

  public void progressConnectingCallState()
  {
    int i = 0;
    while (true)
      try
      {
        CallInfo localCallInfo;
        if (i < this.mCalls.length)
        {
          localCallInfo = this.mCalls[i];
          if ((localCallInfo == null) || (localCallInfo.mState != CallInfo.State.DIALING))
            continue;
          localCallInfo.mState = CallInfo.State.ALERTING;
          if (this.mAutoProgressConnecting)
            sendMessageDelayed(obtainMessage(1, localCallInfo), 500L);
        }
        return;
        if (localCallInfo != null)
        {
          if (localCallInfo.mState != CallInfo.State.ALERTING)
            continue;
          localCallInfo.mState = CallInfo.State.ACTIVE;
        }
      }
      finally
      {
      }
  }

  public void progressConnectingToActive()
  {
    for (int i = 0; ; i++)
      try
      {
        if (i < this.mCalls.length)
        {
          CallInfo localCallInfo = this.mCalls[i];
          if ((localCallInfo != null) && ((localCallInfo.mState == CallInfo.State.DIALING) || (localCallInfo.mState == CallInfo.State.ALERTING)))
            localCallInfo.mState = CallInfo.State.ACTIVE;
        }
        else
        {
          return;
        }
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
  }

  public boolean releaseActiveAcceptHeldOrWaiting()
  {
    int i = 0;
    int j = 0;
    for (int k = 0; k < this.mCalls.length; k++)
    {
      CallInfo localCallInfo4 = this.mCalls[k];
      if ((localCallInfo4 != null) && (localCallInfo4.mState == CallInfo.State.ACTIVE))
      {
        this.mCalls[k] = null;
        j = 1;
      }
    }
    if (j == 0)
      for (int i1 = 0; i1 < this.mCalls.length; i1++)
      {
        CallInfo localCallInfo3 = this.mCalls[i1];
        if ((localCallInfo3 != null) && ((localCallInfo3.mState == CallInfo.State.DIALING) || (localCallInfo3.mState == CallInfo.State.ALERTING)))
          this.mCalls[i1] = null;
      }
    for (int m = 0; m < this.mCalls.length; m++)
    {
      CallInfo localCallInfo2 = this.mCalls[m];
      if ((localCallInfo2 != null) && (localCallInfo2.mState == CallInfo.State.HOLDING))
      {
        localCallInfo2.mState = CallInfo.State.ACTIVE;
        i = 1;
      }
    }
    if (i != 0);
    label231: 
    while (true)
    {
      return true;
      for (int n = 0; ; n++)
      {
        if (n >= this.mCalls.length)
          break label231;
        CallInfo localCallInfo1 = this.mCalls[n];
        if ((localCallInfo1 != null) && (localCallInfo1.isRinging()))
        {
          localCallInfo1.mState = CallInfo.State.ACTIVE;
          break;
        }
      }
    }
  }

  public boolean releaseHeldOrUDUB()
  {
    int i = 0;
    for (int j = 0; ; j++)
      if (j < this.mCalls.length)
      {
        CallInfo localCallInfo2 = this.mCalls[j];
        if ((localCallInfo2 != null) && (localCallInfo2.isRinging()))
        {
          i = 1;
          this.mCalls[j] = null;
        }
      }
      else
      {
        if (i != 0)
          break;
        for (int k = 0; k < this.mCalls.length; k++)
        {
          CallInfo localCallInfo1 = this.mCalls[k];
          if ((localCallInfo1 != null) && (localCallInfo1.mState == CallInfo.State.HOLDING))
            this.mCalls[k] = null;
        }
      }
    return true;
  }

  public boolean separateCall(int paramInt)
  {
    int i = 1;
    try
    {
      CallInfo localCallInfo1 = this.mCalls[paramInt];
      if ((localCallInfo1 != null) && (!localCallInfo1.isConnecting()) && (countActiveLines() == i))
      {
        localCallInfo1.mState = CallInfo.State.ACTIVE;
        localCallInfo1.mIsMpty = false;
        for (int j = 0; j < this.mCalls.length; j++)
        {
          int k = 0;
          int m = 0;
          if (j != paramInt)
          {
            CallInfo localCallInfo2 = this.mCalls[j];
            if ((localCallInfo2 != null) && (localCallInfo2.mState == CallInfo.State.ACTIVE))
            {
              localCallInfo2.mState = CallInfo.State.HOLDING;
              k = 0 + 1;
              m = j;
            }
          }
          if (k == i)
            this.mCalls[m].mIsMpty = false;
        }
      }
    }
    catch (InvalidStateEx localInvalidStateEx)
    {
      i = 0;
      break label146;
      i = 0;
    }
    label146: return i;
  }

  public void setAutoProgressConnectingCall(boolean paramBoolean)
  {
    this.mAutoProgressConnecting = paramBoolean;
  }

  public void setNextDialFailImmediately(boolean paramBoolean)
  {
    this.mNextDialFailImmediately = paramBoolean;
  }

  public boolean switchActiveAndHeldOrWaiting()
  {
    int i = 0;
    int j = 0;
    int k;
    label41: CallInfo localCallInfo1;
    if (j < this.mCalls.length)
    {
      CallInfo localCallInfo2 = this.mCalls[j];
      if ((localCallInfo2 != null) && (localCallInfo2.mState == CallInfo.State.HOLDING))
        i = 1;
    }
    else
    {
      k = 0;
      if (k >= this.mCalls.length)
        break label139;
      localCallInfo1 = this.mCalls[k];
      if (localCallInfo1 != null)
      {
        if (localCallInfo1.mState != CallInfo.State.ACTIVE)
          break label94;
        localCallInfo1.mState = CallInfo.State.HOLDING;
      }
    }
    while (true)
    {
      k++;
      break label41;
      j++;
      break;
      label94: if (localCallInfo1.mState == CallInfo.State.HOLDING)
        localCallInfo1.mState = CallInfo.State.ACTIVE;
      else if ((i == 0) && (localCallInfo1.isRinging()))
        localCallInfo1.mState = CallInfo.State.ACTIVE;
    }
    label139: return true;
  }

  public boolean triggerHangupAll()
  {
    boolean bool = false;
    int i = 0;
    try
    {
      while (i < this.mCalls.length)
      {
        this.mCalls[i];
        if (this.mCalls[i] != null)
          bool = true;
        this.mCalls[i] = null;
        i++;
      }
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public boolean triggerHangupBackground()
  {
    boolean bool = false;
    for (int i = 0; ; i++)
      try
      {
        if (i < this.mCalls.length)
        {
          CallInfo localCallInfo = this.mCalls[i];
          if ((localCallInfo != null) && (localCallInfo.mState == CallInfo.State.HOLDING))
          {
            this.mCalls[i] = null;
            bool = true;
          }
        }
        else
        {
          return bool;
        }
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
  }

  public boolean triggerHangupForeground()
  {
    boolean bool = false;
    int i = 0;
    while (true)
    {
      try
      {
        if (i >= this.mCalls.length)
          break label147;
        CallInfo localCallInfo2 = this.mCalls[i];
        if ((localCallInfo2 != null) && ((localCallInfo2.mState == CallInfo.State.INCOMING) || (localCallInfo2.mState == CallInfo.State.WAITING)))
        {
          this.mCalls[i] = null;
          bool = true;
          break label141;
          if (j < this.mCalls.length)
          {
            CallInfo localCallInfo1 = this.mCalls[j];
            if ((localCallInfo1 == null) || ((localCallInfo1.mState != CallInfo.State.DIALING) && (localCallInfo1.mState != CallInfo.State.ACTIVE) && (localCallInfo1.mState != CallInfo.State.ALERTING)))
              break label153;
            this.mCalls[j] = null;
            bool = true;
            break label153;
          }
          return bool;
        }
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
      label141: i++;
      continue;
      label147: int j = 0;
      continue;
      label153: j++;
    }
  }

  public boolean triggerRing(String paramString)
  {
    boolean bool = false;
    int i = -1;
    int j = 0;
    int k = 0;
    while (true)
    {
      CallInfo localCallInfo;
      try
      {
        if (k < this.mCalls.length)
        {
          localCallInfo = this.mCalls[k];
          if ((localCallInfo == null) && (i < 0))
          {
            i = k;
          }
          else
          {
            if ((localCallInfo == null) || ((localCallInfo.mState != CallInfo.State.INCOMING) && (localCallInfo.mState != CallInfo.State.WAITING)))
              break label155;
            Rlog.w("ModelInterpreter", "triggerRing failed; phone already ringing");
            continue;
          }
        }
        else if (i < 0)
        {
          Rlog.w("ModelInterpreter", "triggerRing failed; all full");
        }
      }
      finally
      {
        throw localObject;
        this.mCalls[i] = CallInfo.createIncomingCall(PhoneNumberUtils.extractNetworkPortion(paramString));
        if (j != 0)
          this.mCalls[i].mState = CallInfo.State.WAITING;
        bool = true;
        continue;
        k++;
      }
      label155: if (localCallInfo != null)
        j = 1;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.test.SimulatedGsmCallState
 * JD-Core Version:    0.6.2
 */