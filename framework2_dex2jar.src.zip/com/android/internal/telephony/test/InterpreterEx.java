package com.android.internal.telephony.test;

class InterpreterEx extends Exception
{
  String mResult;

  public InterpreterEx(String paramString)
  {
    this.mResult = paramString;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.test.InterpreterEx
 * JD-Core Version:    0.6.2
 */