package com.android.internal.telephony.test;

class InvalidStateEx extends Exception
{
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.test.InvalidStateEx
 * JD-Core Version:    0.6.2
 */