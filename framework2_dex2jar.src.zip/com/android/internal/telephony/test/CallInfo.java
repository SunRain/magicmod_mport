package com.android.internal.telephony.test;

import com.android.internal.telephony.ATParseEx;
import com.android.internal.telephony.DriverCall;

class CallInfo
{
  boolean mIsMT;
  boolean mIsMpty;
  String mNumber;
  State mState;
  int mTOA;

  CallInfo(boolean paramBoolean1, State paramState, boolean paramBoolean2, String paramString)
  {
    this.mIsMT = paramBoolean1;
    this.mState = paramState;
    this.mIsMpty = paramBoolean2;
    this.mNumber = paramString;
    if ((paramString.length() > 0) && (paramString.charAt(0) == '+'));
    for (this.mTOA = 145; ; this.mTOA = 129)
      return;
  }

  static CallInfo createIncomingCall(String paramString)
  {
    return new CallInfo(true, State.INCOMING, false, paramString);
  }

  static CallInfo createOutgoingCall(String paramString)
  {
    return new CallInfo(false, State.DIALING, false, paramString);
  }

  boolean isActiveOrHeld()
  {
    if ((this.mState == State.ACTIVE) || (this.mState == State.HOLDING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isConnecting()
  {
    if ((this.mState == State.DIALING) || (this.mState == State.ALERTING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isRinging()
  {
    if ((this.mState == State.INCOMING) || (this.mState == State.WAITING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  String toCLCCLine(int paramInt)
  {
    StringBuilder localStringBuilder1 = new StringBuilder().append("+CLCC: ").append(paramInt).append(",");
    String str1;
    StringBuilder localStringBuilder2;
    if (this.mIsMT)
    {
      str1 = "1";
      localStringBuilder2 = localStringBuilder1.append(str1).append(",").append(this.mState.value()).append(",0,");
      if (!this.mIsMpty)
        break label111;
    }
    label111: for (String str2 = "1"; ; str2 = "0")
    {
      return str2 + ",\"" + this.mNumber + "\"," + this.mTOA;
      str1 = "0";
      break;
    }
  }

  DriverCall toDriverCall(int paramInt)
  {
    DriverCall localDriverCall = new DriverCall();
    localDriverCall.index = paramInt;
    localDriverCall.isMT = this.mIsMT;
    try
    {
      localDriverCall.state = DriverCall.stateFromCLCC(this.mState.value());
      localDriverCall.isMpty = this.mIsMpty;
      localDriverCall.number = this.mNumber;
      localDriverCall.TOA = this.mTOA;
      localDriverCall.isVoice = true;
      localDriverCall.als = 0;
      return localDriverCall;
    }
    catch (ATParseEx localATParseEx)
    {
      throw new RuntimeException("should never happen", localATParseEx);
    }
  }

  static enum State
  {
    private final int mValue;

    static
    {
      DIALING = new State("DIALING", 2, 2);
      ALERTING = new State("ALERTING", 3, 3);
      INCOMING = new State("INCOMING", 4, 4);
      WAITING = new State("WAITING", 5, 5);
      State[] arrayOfState = new State[6];
      arrayOfState[0] = ACTIVE;
      arrayOfState[1] = HOLDING;
      arrayOfState[2] = DIALING;
      arrayOfState[3] = ALERTING;
      arrayOfState[4] = INCOMING;
      arrayOfState[5] = WAITING;
    }

    private State(int paramInt)
    {
      this.mValue = paramInt;
    }

    public int value()
    {
      return this.mValue;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.test.CallInfo
 * JD-Core Version:    0.6.2
 */