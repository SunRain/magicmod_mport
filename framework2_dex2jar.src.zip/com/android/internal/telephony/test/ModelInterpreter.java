package com.android.internal.telephony.test;

import android.os.HandlerThread;
import android.os.Looper;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.util.List;

public class ModelInterpreter
  implements Runnable, SimulatedRadioControl
{
  static final int CONNECTING_PAUSE_MSEC = 500;
  static final String LOG_TAG = "ModelInterpreter";
  static final int MAX_CALLS = 6;
  static final int PROGRESS_CALL_STATE = 1;
  static final String[][] sDefaultResponses = { { "E0Q0V1", null }, { "+CMEE=2", null }, { "+CREG=2", null }, { "+CGREG=2", null }, { "+CCWA=1", null }, { "+COPS=0", null }, { "+CFUN=1", null }, { "+CGMI", "+CGMI: Android Model AT Interpreter\r" }, { "+CGMM", "+CGMM: Android Model AT Interpreter\r" }, { "+CGMR", "+CGMR: 1.0\r" }, { "+CGSN", "000000000000000\r" }, { "+CIMI", "320720000000000\r" }, { "+CSCS=?", "+CSCS: (\"HEX\",\"UCS2\")\r" }, { "+CFUN?", "+CFUN: 1\r" }, { "+COPS=3,0;+COPS?;+COPS=3,1;+COPS?;+COPS=3,2;+COPS?", "+COPS: 0,0,\"Android\"\r+COPS: 0,1,\"Android\"\r+COPS: 0,2,\"310995\"\r" }, { "+CREG?", "+CREG: 2,5, \"0113\", \"6614\"\r" }, { "+CGREG?", "+CGREG: 2,0\r" }, { "+CSQ", "+CSQ: 16,99\r" }, { "+CNMI?", "+CNMI: 1,2,2,1,1\r" }, { "+CLIR?", "+CLIR: 1,3\r" }, { "%CPVWI=2", "%CPVWI: 0\r" }, { "+CUSD=1,\"#646#\"", "+CUSD=0,\"You have used 23 minutes\"\r" }, { "+CRSM=176,12258,0,0,10", "+CRSM: 144,0,981062200050259429F6\r" }, { "+CRSM=192,12258,0,0,15", "+CRSM: 144,0,0000000A2FE204000FF55501020000\r" }, { "+CRSM=192,28474,0,0,15", "+CRSM: 144,0,0000005a6f3a040011f5220102011e\r" }, { "+CRSM=178,28474,1,4,30", "+CRSM: 144,0,437573746f6d65722043617265ffffff07818100398799f7ffffffffffff\r" }, { "+CRSM=178,28474,2,4,30", "+CRSM: 144,0,566f696365204d61696cffffffffffff07918150367742f3ffffffffffff\r" }, { "+CRSM=178,28474,3,4,30", "+CRSM: 144,0,4164676a6dffffffffffffffffffffff0b918188551512c221436587ff01\r" }, { "+CRSM=178,28474,4,4,30", "+CRSM: 144,0,810101c1ffffffffffffffffffffffff068114455245f8ffffffffffffff\r" }, { "+CRSM=192,28490,0,0,15", "+CRSM: 144,0,000000416f4a040011f5550102010d\r" }, { "+CRSM=178,28490,1,4,13", "+CRSM: 144,0,0206092143658709ffffffffff\r" } };
  private String mFinalResponse;
  HandlerThread mHandlerThread;
  InputStream mIn;
  LineReader mLineReader;
  OutputStream mOut;
  int mPausedResponseCount;
  Object mPausedResponseMonitor = new Object();
  ServerSocket mSS;
  SimulatedGsmCallState mSimulatedCallState;

  public ModelInterpreter(InputStream paramInputStream, OutputStream paramOutputStream)
  {
    this.mIn = paramInputStream;
    this.mOut = paramOutputStream;
    init();
  }

  public ModelInterpreter(InetSocketAddress paramInetSocketAddress)
    throws IOException
  {
    this.mSS = new ServerSocket();
    this.mSS.setReuseAddress(true);
    this.mSS.bind(paramInetSocketAddress);
    init();
  }

  private void init()
  {
    new Thread(this, "ModelInterpreter").start();
    this.mHandlerThread = new HandlerThread("ModelInterpreter");
    this.mHandlerThread.start();
    this.mSimulatedCallState = new SimulatedGsmCallState(this.mHandlerThread.getLooper());
  }

  private void onAnswer()
    throws InterpreterEx
  {
    if (!this.mSimulatedCallState.onAnswer())
      throw new InterpreterEx("ERROR");
  }

  private void onCHLD(String paramString)
    throws InterpreterEx
  {
    char c1 = '\000';
    char c2 = paramString.charAt(6);
    if (paramString.length() >= 8)
      c1 = paramString.charAt(7);
    if (!this.mSimulatedCallState.onChld(c2, c1))
      throw new InterpreterEx("ERROR");
  }

  private void onCLCC()
  {
    List localList = this.mSimulatedCallState.getClccLines();
    int i = 0;
    int j = localList.size();
    while (i < j)
    {
      println((String)localList.get(i));
      i++;
    }
  }

  private void onDial(String paramString)
    throws InterpreterEx
  {
    if (!this.mSimulatedCallState.onDial(paramString.substring(1)))
      throw new InterpreterEx("ERROR");
  }

  private void onHangup()
    throws InterpreterEx
  {
    if (!this.mSimulatedCallState.onAnswer())
      throw new InterpreterEx("ERROR");
    this.mFinalResponse = "NO CARRIER";
  }

  private void onSMSSend(String paramString)
  {
    print("> ");
    this.mLineReader.getNextLineCtrlZ();
    println("+CMGS: 1");
  }

  public void pauseResponses()
  {
    synchronized (this.mPausedResponseMonitor)
    {
      this.mPausedResponseCount = (1 + this.mPausedResponseCount);
      return;
    }
  }

  void print(String paramString)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("US-ASCII");
      this.mOut.write(arrayOfByte);
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        localIOException.printStackTrace();
    }
    finally
    {
    }
  }

  void println(String paramString)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("US-ASCII");
      this.mOut.write(arrayOfByte);
      this.mOut.write(13);
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        localIOException.printStackTrace();
    }
    finally
    {
    }
  }

  void processLine(String paramString)
    throws InterpreterEx
  {
    String[] arrayOfString = splitCommands(paramString);
    int i = 0;
    if (i < arrayOfString.length)
    {
      String str1 = arrayOfString[i];
      if (str1.equals("A"))
        onAnswer();
      while (true)
      {
        i++;
        break;
        if (str1.equals("H"))
        {
          onHangup();
        }
        else if (str1.startsWith("+CHLD="))
        {
          onCHLD(str1);
        }
        else if (str1.equals("+CLCC"))
        {
          onCLCC();
        }
        else if (str1.startsWith("D"))
        {
          onDial(str1);
        }
        else
        {
          if (!str1.startsWith("+CMGS="))
            break label136;
          onSMSSend(str1);
        }
      }
      label136: int j = 0;
      for (int k = 0; ; k++)
        if (k < sDefaultResponses.length)
        {
          if (str1.equals(sDefaultResponses[k][0]))
          {
            String str2 = sDefaultResponses[k][1];
            if (str2 != null)
              println(str2);
            j = 1;
          }
        }
        else
        {
          if (j != 0)
            break;
          throw new InterpreterEx("ERROR");
        }
    }
  }

  public void progressConnectingCallState()
  {
    this.mSimulatedCallState.progressConnectingCallState();
  }

  public void progressConnectingToActive()
  {
    this.mSimulatedCallState.progressConnectingToActive();
  }

  public void resumeResponses()
  {
    synchronized (this.mPausedResponseMonitor)
    {
      this.mPausedResponseCount = (-1 + this.mPausedResponseCount);
      if (this.mPausedResponseCount == 0)
        this.mPausedResponseMonitor.notifyAll();
      return;
    }
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 176	com/android/internal/telephony/test/ModelInterpreter:mSS	Ljava/net/ServerSocket;
    //   4: ifnull +39 -> 43
    //   7: aload_0
    //   8: getfield 176	com/android/internal/telephony/test/ModelInterpreter:mSS	Ljava/net/ServerSocket;
    //   11: invokevirtual 355	java/net/ServerSocket:accept	()Ljava/net/Socket;
    //   14: astore 12
    //   16: aload_0
    //   17: aload 12
    //   19: invokevirtual 361	java/net/Socket:getInputStream	()Ljava/io/InputStream;
    //   22: putfield 163	com/android/internal/telephony/test/ModelInterpreter:mIn	Ljava/io/InputStream;
    //   25: aload_0
    //   26: aload 12
    //   28: invokevirtual 365	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
    //   31: putfield 165	com/android/internal/telephony/test/ModelInterpreter:mOut	Ljava/io/OutputStream;
    //   34: ldc 15
    //   36: ldc_w 367
    //   39: invokestatic 373	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   42: pop
    //   43: aload_0
    //   44: new 273	com/android/internal/telephony/test/LineReader
    //   47: dup
    //   48: aload_0
    //   49: getfield 163	com/android/internal/telephony/test/ModelInterpreter:mIn	Ljava/io/InputStream;
    //   52: invokespecial 376	com/android/internal/telephony/test/LineReader:<init>	(Ljava/io/InputStream;)V
    //   55: putfield 271	com/android/internal/telephony/test/ModelInterpreter:mLineReader	Lcom/android/internal/telephony/test/LineReader;
    //   58: aload_0
    //   59: ldc_w 378
    //   62: invokevirtual 250	com/android/internal/telephony/test/ModelInterpreter:println	(Ljava/lang/String;)V
    //   65: aload_0
    //   66: getfield 271	com/android/internal/telephony/test/ModelInterpreter:mLineReader	Lcom/android/internal/telephony/test/LineReader;
    //   69: invokevirtual 381	com/android/internal/telephony/test/LineReader:getNextLine	()Ljava/lang/String;
    //   72: astore_1
    //   73: aload_1
    //   74: ifnonnull +52 -> 126
    //   77: ldc 15
    //   79: ldc_w 383
    //   82: invokestatic 373	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   85: pop
    //   86: aload_0
    //   87: getfield 176	com/android/internal/telephony/test/ModelInterpreter:mSS	Ljava/net/ServerSocket;
    //   90: ifnonnull -90 -> 0
    //   93: return
    //   94: astore 10
    //   96: ldc 15
    //   98: ldc_w 385
    //   101: aload 10
    //   103: invokestatic 389	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   106: pop
    //   107: goto -14 -> 93
    //   110: astore 13
    //   112: ldc 15
    //   114: ldc_w 391
    //   117: aload 13
    //   119: invokestatic 389	android/telephony/Rlog:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   122: pop
    //   123: goto -123 -> 0
    //   126: aload_0
    //   127: getfield 161	com/android/internal/telephony/test/ModelInterpreter:mPausedResponseMonitor	Ljava/lang/Object;
    //   130: astore_2
    //   131: aload_2
    //   132: monitorenter
    //   133: aload_0
    //   134: getfield 282	com/android/internal/telephony/test/ModelInterpreter:mPausedResponseCount	I
    //   137: istore 4
    //   139: iload 4
    //   141: ifle +18 -> 159
    //   144: aload_0
    //   145: getfield 161	com/android/internal/telephony/test/ModelInterpreter:mPausedResponseMonitor	Ljava/lang/Object;
    //   148: invokevirtual 394	java/lang/Object:wait	()V
    //   151: goto -18 -> 133
    //   154: astore 8
    //   156: goto -23 -> 133
    //   159: aload_2
    //   160: monitorexit
    //   161: aload_0
    //   162: monitorenter
    //   163: aload_0
    //   164: ldc_w 396
    //   167: putfield 263	com/android/internal/telephony/test/ModelInterpreter:mFinalResponse	Ljava/lang/String;
    //   170: aload_0
    //   171: aload_1
    //   172: invokevirtual 398	com/android/internal/telephony/test/ModelInterpreter:processLine	(Ljava/lang/String;)V
    //   175: aload_0
    //   176: aload_0
    //   177: getfield 263	com/android/internal/telephony/test/ModelInterpreter:mFinalResponse	Ljava/lang/String;
    //   180: invokevirtual 250	com/android/internal/telephony/test/ModelInterpreter:println	(Ljava/lang/String;)V
    //   183: aload_0
    //   184: monitorexit
    //   185: goto -120 -> 65
    //   188: astore 6
    //   190: aload_0
    //   191: monitorexit
    //   192: aload 6
    //   194: athrow
    //   195: astore_3
    //   196: aload_2
    //   197: monitorexit
    //   198: aload_3
    //   199: athrow
    //   200: astore 7
    //   202: aload_0
    //   203: aload 7
    //   205: getfield 401	com/android/internal/telephony/test/InterpreterEx:mResult	Ljava/lang/String;
    //   208: invokevirtual 250	com/android/internal/telephony/test/ModelInterpreter:println	(Ljava/lang/String;)V
    //   211: goto -28 -> 183
    //   214: astore 5
    //   216: aload 5
    //   218: invokevirtual 402	java/lang/RuntimeException:printStackTrace	()V
    //   221: aload_0
    //   222: ldc 219
    //   224: invokevirtual 250	com/android/internal/telephony/test/ModelInterpreter:println	(Ljava/lang/String;)V
    //   227: goto -44 -> 183
    //
    // Exception table:
    //   from	to	target	type
    //   7	16	94	java/io/IOException
    //   16	34	110	java/io/IOException
    //   144	151	154	java/lang/InterruptedException
    //   163	183	188	finally
    //   183	192	188	finally
    //   202	227	188	finally
    //   133	139	195	finally
    //   144	151	195	finally
    //   159	161	195	finally
    //   196	198	195	finally
    //   163	183	200	com/android/internal/telephony/test/InterpreterEx
    //   163	183	214	java/lang/RuntimeException
  }

  public void sendUnsolicited(String paramString)
  {
    try
    {
      println(paramString);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void setAutoProgressConnectingCall(boolean paramBoolean)
  {
    this.mSimulatedCallState.setAutoProgressConnectingCall(paramBoolean);
  }

  public void setNextCallFailCause(int paramInt)
  {
  }

  public void setNextDialFailImmediately(boolean paramBoolean)
  {
    this.mSimulatedCallState.setNextDialFailImmediately(paramBoolean);
  }

  public void shutdown()
  {
    Looper localLooper = this.mHandlerThread.getLooper();
    if (localLooper != null)
      localLooper.quit();
    try
    {
      this.mIn.close();
      try
      {
        label23: this.mOut.close();
        label30: return;
      }
      catch (IOException localIOException2)
      {
        break label30;
      }
    }
    catch (IOException localIOException1)
    {
      break label23;
    }
  }

  String[] splitCommands(String paramString)
    throws InterpreterEx
  {
    if (!paramString.startsWith("AT"))
      throw new InterpreterEx("ERROR");
    String[] arrayOfString;
    if (paramString.length() == 2)
      arrayOfString = new String[0];
    while (true)
    {
      return arrayOfString;
      arrayOfString = new String[1];
      arrayOfString[0] = paramString.substring(2);
    }
  }

  public void triggerHangupAll()
  {
    if (this.mSimulatedCallState.triggerHangupAll())
      println("NO CARRIER");
  }

  public void triggerHangupBackground()
  {
    if (this.mSimulatedCallState.triggerHangupBackground())
      println("NO CARRIER");
  }

  public void triggerHangupForeground()
  {
    if (this.mSimulatedCallState.triggerHangupForeground())
      println("NO CARRIER");
  }

  public void triggerIncomingSMS(String paramString)
  {
  }

  public void triggerIncomingUssd(String paramString1, String paramString2)
  {
  }

  public void triggerRing(String paramString)
  {
    try
    {
      if (this.mSimulatedCallState.triggerRing(paramString))
        println("RING");
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void triggerSsn(int paramInt1, int paramInt2)
  {
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.test.ModelInterpreter
 * JD-Core Version:    0.6.2
 */