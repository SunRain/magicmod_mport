package com.android.internal.telephony;

import android.app.AppOpsManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Process;
import android.provider.Settings.Secure;
import android.telephony.Rlog;
import android.telephony.TelephonyManager;
import com.android.internal.content.PackageMonitor;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public final class SmsApplication
{
  private static final String BLUETOOTH_PACKAGE_NAME = "com.android.bluetooth";
  static final String LOG_TAG = "SmsApplication";
  private static final String PHONE_PACKAGE_NAME = "com.android.phone";
  private static final String SCHEME_MMS = "mms";
  private static final String SCHEME_MMSTO = "mmsto";
  private static final String SCHEME_SMS = "sms";
  private static final String SCHEME_SMSTO = "smsto";
  private static SmsPackageMonitor sSmsPackageMonitor = null;

  private static void configurePreferredActivity(PackageManager paramPackageManager, ComponentName paramComponentName)
  {
    replacePreferredActivity(paramPackageManager, paramComponentName, "sms");
    replacePreferredActivity(paramPackageManager, paramComponentName, "smsto");
    replacePreferredActivity(paramPackageManager, paramComponentName, "mms");
    replacePreferredActivity(paramPackageManager, paramComponentName, "mmsto");
  }

  private static SmsApplicationData getApplication(Context paramContext, boolean paramBoolean)
  {
    SmsApplicationData localSmsApplicationData;
    if (((TelephonyManager)paramContext.getSystemService("phone")).getPhoneType() == 0)
      localSmsApplicationData = null;
    while (true)
    {
      return localSmsApplicationData;
      Collection localCollection = getApplicationCollection(paramContext);
      String str1 = Settings.Secure.getString(paramContext.getContentResolver(), "sms_default_application");
      localSmsApplicationData = null;
      if (str1 != null)
        localSmsApplicationData = getApplicationForPackage(localCollection, str1);
      if ((paramBoolean) && (localSmsApplicationData == null))
      {
        localSmsApplicationData = getApplicationForPackage(localCollection, paramContext.getResources().getString(17039395));
        if ((localSmsApplicationData == null) && (localCollection.size() != 0))
          localSmsApplicationData = (SmsApplicationData)localCollection.toArray()[0];
        if (localSmsApplicationData != null)
          setDefaultApplication(localSmsApplicationData.mPackageName, paramContext);
      }
      if (localSmsApplicationData == null)
        continue;
      AppOpsManager localAppOpsManager = (AppOpsManager)paramContext.getSystemService("appops");
      String str2;
      label196: PackageManager localPackageManager;
      if (((paramBoolean) || (localSmsApplicationData.mUid == Process.myUid())) && (localAppOpsManager.checkOp(15, localSmsApplicationData.mUid, localSmsApplicationData.mPackageName) != 0))
      {
        StringBuilder localStringBuilder = new StringBuilder().append(localSmsApplicationData.mPackageName).append(" lost OP_WRITE_SMS: ");
        if (paramBoolean)
        {
          str2 = " (fixing)";
          Rlog.e("SmsApplication", str2);
          if (!paramBoolean)
            break label401;
          localAppOpsManager.setMode(15, localSmsApplicationData.mUid, localSmsApplicationData.mPackageName, 0);
        }
      }
      else
      {
        if (!paramBoolean)
          continue;
        localPackageManager = paramContext.getPackageManager();
        configurePreferredActivity(localPackageManager, new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mSendToClass));
      }
      try
      {
        PackageInfo localPackageInfo2 = localPackageManager.getPackageInfo("com.android.phone", 0);
        if (localAppOpsManager.checkOp(15, localPackageInfo2.applicationInfo.uid, "com.android.phone") != 0)
        {
          Rlog.e("SmsApplication", "com.android.phone lost OP_WRITE_SMS:  (fixing)");
          localAppOpsManager.setMode(15, localPackageInfo2.applicationInfo.uid, "com.android.phone", 0);
        }
        try
        {
          PackageInfo localPackageInfo1 = localPackageManager.getPackageInfo("com.android.bluetooth", 0);
          if (localAppOpsManager.checkOp(15, localPackageInfo1.applicationInfo.uid, "com.android.bluetooth") == 0)
            continue;
          Rlog.e("SmsApplication", "com.android.bluetooth lost OP_WRITE_SMS:  (fixing)");
          localAppOpsManager.setMode(15, localPackageInfo1.applicationInfo.uid, "com.android.bluetooth", 0);
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException2)
        {
          Rlog.e("SmsApplication", "Bluetooth package not found: com.android.bluetooth");
        }
        continue;
        str2 = " (no permission to fix)";
        break label196;
        label401: localSmsApplicationData = null;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException1)
      {
        while (true)
        {
          Rlog.e("SmsApplication", "Phone package not found: com.android.phone");
          localSmsApplicationData = null;
        }
      }
    }
  }

  public static Collection<SmsApplicationData> getApplicationCollection(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    List localList = localPackageManager.queryBroadcastReceivers(new Intent("android.provider.Telephony.SMS_DELIVER"), 0);
    HashMap localHashMap = new HashMap();
    Iterator localIterator1 = localList.iterator();
    while (localIterator1.hasNext())
    {
      ResolveInfo localResolveInfo = (ResolveInfo)localIterator1.next();
      ActivityInfo localActivityInfo4 = localResolveInfo.activityInfo;
      if ((localActivityInfo4 != null) && ("android.permission.BROADCAST_SMS".equals(localActivityInfo4.permission)))
      {
        String str2 = localActivityInfo4.packageName;
        if (!localHashMap.containsKey(str2))
        {
          SmsApplicationData localSmsApplicationData5 = new SmsApplicationData(localResolveInfo.loadLabel(localPackageManager).toString(), str2, localActivityInfo4.applicationInfo.uid);
          localSmsApplicationData5.mSmsReceiverClass = localActivityInfo4.name;
          localHashMap.put(str2, localSmsApplicationData5);
        }
      }
    }
    Intent localIntent = new Intent("android.provider.Telephony.WAP_PUSH_DELIVER");
    localIntent.setDataAndType(null, "application/vnd.wap.mms-message");
    Iterator localIterator2 = localPackageManager.queryBroadcastReceivers(localIntent, 0).iterator();
    while (localIterator2.hasNext())
    {
      ActivityInfo localActivityInfo3 = ((ResolveInfo)localIterator2.next()).activityInfo;
      if ((localActivityInfo3 != null) && ("android.permission.BROADCAST_WAP_PUSH".equals(localActivityInfo3.permission)))
      {
        SmsApplicationData localSmsApplicationData4 = (SmsApplicationData)localHashMap.get(localActivityInfo3.packageName);
        if (localSmsApplicationData4 != null)
          localSmsApplicationData4.mMmsReceiverClass = localActivityInfo3.name;
      }
    }
    Iterator localIterator3 = localPackageManager.queryIntentServices(new Intent("android.intent.action.RESPOND_VIA_MESSAGE", Uri.fromParts("smsto", "", null)), 0).iterator();
    while (localIterator3.hasNext())
    {
      ServiceInfo localServiceInfo = ((ResolveInfo)localIterator3.next()).serviceInfo;
      if ((localServiceInfo != null) && ("android.permission.SEND_RESPOND_VIA_MESSAGE".equals(localServiceInfo.permission)))
      {
        SmsApplicationData localSmsApplicationData3 = (SmsApplicationData)localHashMap.get(localServiceInfo.packageName);
        if (localSmsApplicationData3 != null)
          localSmsApplicationData3.mRespondViaMessageClass = localServiceInfo.name;
      }
    }
    Iterator localIterator4 = localPackageManager.queryIntentActivities(new Intent("android.intent.action.SENDTO", Uri.fromParts("smsto", "", null)), 0).iterator();
    while (localIterator4.hasNext())
    {
      ActivityInfo localActivityInfo2 = ((ResolveInfo)localIterator4.next()).activityInfo;
      if (localActivityInfo2 != null)
      {
        SmsApplicationData localSmsApplicationData2 = (SmsApplicationData)localHashMap.get(localActivityInfo2.packageName);
        if (localSmsApplicationData2 != null)
          localSmsApplicationData2.mSendToClass = localActivityInfo2.name;
      }
    }
    Iterator localIterator5 = localList.iterator();
    while (localIterator5.hasNext())
    {
      ActivityInfo localActivityInfo1 = ((ResolveInfo)localIterator5.next()).activityInfo;
      if (localActivityInfo1 != null)
      {
        String str1 = localActivityInfo1.packageName;
        SmsApplicationData localSmsApplicationData1 = (SmsApplicationData)localHashMap.get(str1);
        if ((localSmsApplicationData1 != null) && (!localSmsApplicationData1.isComplete()))
          localHashMap.remove(str1);
      }
    }
    return localHashMap.values();
  }

  private static SmsApplicationData getApplicationForPackage(Collection<SmsApplicationData> paramCollection, String paramString)
  {
    SmsApplicationData localSmsApplicationData;
    if (paramString == null)
      localSmsApplicationData = null;
    while (true)
    {
      return localSmsApplicationData;
      Iterator localIterator = paramCollection.iterator();
      while (true)
        if (localIterator.hasNext())
        {
          localSmsApplicationData = (SmsApplicationData)localIterator.next();
          if (localSmsApplicationData.mPackageName.contentEquals(paramString))
            break;
        }
      localSmsApplicationData = null;
    }
  }

  public static ComponentName getDefaultMmsApplication(Context paramContext, boolean paramBoolean)
  {
    ComponentName localComponentName = null;
    SmsApplicationData localSmsApplicationData = getApplication(paramContext, paramBoolean);
    if (localSmsApplicationData != null)
      localComponentName = new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mMmsReceiverClass);
    return localComponentName;
  }

  public static ComponentName getDefaultRespondViaMessageApplication(Context paramContext, boolean paramBoolean)
  {
    ComponentName localComponentName = null;
    SmsApplicationData localSmsApplicationData = getApplication(paramContext, paramBoolean);
    if (localSmsApplicationData != null)
      localComponentName = new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mRespondViaMessageClass);
    return localComponentName;
  }

  public static ComponentName getDefaultSendToApplication(Context paramContext, boolean paramBoolean)
  {
    ComponentName localComponentName = null;
    SmsApplicationData localSmsApplicationData = getApplication(paramContext, paramBoolean);
    if (localSmsApplicationData != null)
      localComponentName = new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mSendToClass);
    return localComponentName;
  }

  public static ComponentName getDefaultSmsApplication(Context paramContext, boolean paramBoolean)
  {
    ComponentName localComponentName = null;
    SmsApplicationData localSmsApplicationData = getApplication(paramContext, paramBoolean);
    if (localSmsApplicationData != null)
      localComponentName = new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mSmsReceiverClass);
    return localComponentName;
  }

  public static SmsApplicationData getSmsApplicationData(String paramString, Context paramContext)
  {
    return getApplicationForPackage(getApplicationCollection(paramContext), paramString);
  }

  public static void initSmsPackageMonitor(Context paramContext)
  {
    sSmsPackageMonitor = new SmsPackageMonitor(paramContext);
    sSmsPackageMonitor.register(paramContext, paramContext.getMainLooper(), false);
  }

  private static void replacePreferredActivity(PackageManager paramPackageManager, ComponentName paramComponentName, String paramString)
  {
    List localList = paramPackageManager.queryIntentActivities(new Intent("android.intent.action.SENDTO", Uri.fromParts(paramString, "", null)), 65600);
    int i = localList.size();
    ComponentName[] arrayOfComponentName = new ComponentName[i];
    for (int j = 0; j < i; j++)
    {
      ResolveInfo localResolveInfo = (ResolveInfo)localList.get(j);
      arrayOfComponentName[j] = new ComponentName(localResolveInfo.activityInfo.packageName, localResolveInfo.activityInfo.name);
    }
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.intent.action.SENDTO");
    localIntentFilter.addCategory("android.intent.category.DEFAULT");
    localIntentFilter.addDataScheme(paramString);
    paramPackageManager.replacePreferredActivity(localIntentFilter, 2129920, arrayOfComponentName, paramComponentName);
  }

  public static void setDefaultApplication(String paramString, Context paramContext)
  {
    if (((TelephonyManager)paramContext.getSystemService("phone")).getPhoneType() == 0);
    while (true)
    {
      return;
      String str = Settings.Secure.getString(paramContext.getContentResolver(), "sms_default_application");
      if ((paramString != null) && (str != null) && (paramString.equals(str)))
        continue;
      PackageManager localPackageManager = paramContext.getPackageManager();
      SmsApplicationData localSmsApplicationData = getApplicationForPackage(getApplicationCollection(paramContext), paramString);
      if (localSmsApplicationData == null)
        continue;
      AppOpsManager localAppOpsManager = (AppOpsManager)paramContext.getSystemService("appops");
      if (str != null);
      try
      {
        localAppOpsManager.setMode(15, localPackageManager.getPackageInfo(str, 8192).applicationInfo.uid, str, 1);
        Settings.Secure.putString(paramContext.getContentResolver(), "sms_default_application", localSmsApplicationData.mPackageName);
        configurePreferredActivity(localPackageManager, new ComponentName(localSmsApplicationData.mPackageName, localSmsApplicationData.mSendToClass));
        localAppOpsManager.setMode(15, localSmsApplicationData.mUid, localSmsApplicationData.mPackageName, 0);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException3)
      {
        try
        {
          localAppOpsManager.setMode(15, localPackageManager.getPackageInfo("com.android.phone", 0).applicationInfo.uid, "com.android.phone", 0);
          try
          {
            localAppOpsManager.setMode(15, localPackageManager.getPackageInfo("com.android.bluetooth", 0).applicationInfo.uid, "com.android.bluetooth", 0);
          }
          catch (PackageManager.NameNotFoundException localNameNotFoundException2)
          {
            Rlog.e("SmsApplication", "Bluetooth package not found: com.android.bluetooth");
          }
          continue;
          localNameNotFoundException3 = localNameNotFoundException3;
          Rlog.w("SmsApplication", "Old SMS package not found: " + str);
        }
        catch (PackageManager.NameNotFoundException localNameNotFoundException1)
        {
          while (true)
            Rlog.e("SmsApplication", "Phone package not found: com.android.phone");
        }
      }
    }
  }

  public static boolean shouldWriteMessageForPackage(String paramString, Context paramContext)
  {
    boolean bool = true;
    if (paramString == null);
    while (true)
    {
      return bool;
      String str = null;
      ComponentName localComponentName = getDefaultSmsApplication(paramContext, false);
      if (localComponentName != null)
        str = localComponentName.getPackageName();
      if (((str != null) && (str.equals(paramString))) || (paramString.equals("com.android.bluetooth")))
        bool = false;
    }
  }

  public static class SmsApplicationData
  {
    public String mApplicationName;
    public String mMmsReceiverClass;
    public String mPackageName;
    public String mRespondViaMessageClass;
    public String mSendToClass;
    public String mSmsReceiverClass;
    public int mUid;

    public SmsApplicationData(String paramString1, String paramString2, int paramInt)
    {
      this.mApplicationName = paramString1;
      this.mPackageName = paramString2;
      this.mUid = paramInt;
    }

    public boolean isComplete()
    {
      if ((this.mSmsReceiverClass != null) && (this.mMmsReceiverClass != null) && (this.mRespondViaMessageClass != null) && (this.mSendToClass != null));
      for (boolean bool = true; ; bool = false)
        return bool;
    }
  }

  private static final class SmsPackageMonitor extends PackageMonitor
  {
    final Context mContext;

    public SmsPackageMonitor(Context paramContext)
    {
      this.mContext = paramContext;
    }

    private void onPackageChanged(String paramString)
    {
      PackageManager localPackageManager = this.mContext.getPackageManager();
      ComponentName localComponentName = SmsApplication.getDefaultSendToApplication(this.mContext, true);
      if (localComponentName != null)
        SmsApplication.configurePreferredActivity(localPackageManager, localComponentName);
    }

    public void onPackageAppeared(String paramString, int paramInt)
    {
      onPackageChanged(paramString);
    }

    public void onPackageDisappeared(String paramString, int paramInt)
    {
      onPackageChanged(paramString);
    }

    public void onPackageModified(String paramString)
    {
      onPackageChanged(paramString);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsApplication
 * JD-Core Version:    0.6.2
 */