package com.android.internal.telephony;

import android.provider.Telephony.Mms;
import java.util.Arrays;

public abstract class SmsMessageBase
{
  protected String mEmailBody;
  protected String mEmailFrom;
  protected int mIndexOnIcc = -1;
  protected boolean mIsEmail;
  protected boolean mIsMwi;
  protected String mMessageBody;
  public int mMessageRef;
  protected boolean mMwiDontStore;
  protected boolean mMwiSense;
  protected SmsAddress mOriginatingAddress;
  protected byte[] mPdu;
  protected String mPseudoSubject;
  protected String mScAddress;
  protected long mScTimeMillis;
  protected int mStatusOnIcc = -1;
  protected byte[] mUserData;
  protected SmsHeader mUserDataHeader;

  protected void extractEmailAddressFromMessageBody()
  {
    String[] arrayOfString = this.mMessageBody.split("( /)|( )", 2);
    if (arrayOfString.length < 2);
    while (true)
    {
      return;
      this.mEmailFrom = arrayOfString[0];
      this.mEmailBody = arrayOfString[1];
      this.mIsEmail = Telephony.Mms.isEmailAddress(this.mEmailFrom);
    }
  }

  public String getDisplayMessageBody()
  {
    if (this.mIsEmail);
    for (String str = this.mEmailBody; ; str = getMessageBody())
      return str;
  }

  public String getDisplayOriginatingAddress()
  {
    if (this.mIsEmail);
    for (String str = this.mEmailFrom; ; str = getOriginatingAddress())
      return str;
  }

  public String getEmailBody()
  {
    return this.mEmailBody;
  }

  public String getEmailFrom()
  {
    return this.mEmailFrom;
  }

  public int getIndexOnIcc()
  {
    return this.mIndexOnIcc;
  }

  public String getMessageBody()
  {
    return this.mMessageBody;
  }

  public abstract SmsConstants.MessageClass getMessageClass();

  public String getOriginatingAddress()
  {
    if (this.mOriginatingAddress == null);
    for (String str = null; ; str = this.mOriginatingAddress.getAddressString())
      return str;
  }

  public byte[] getPdu()
  {
    return this.mPdu;
  }

  public abstract int getProtocolIdentifier();

  public String getPseudoSubject()
  {
    if (this.mPseudoSubject == null);
    for (String str = ""; ; str = this.mPseudoSubject)
      return str;
  }

  public String getServiceCenterAddress()
  {
    return this.mScAddress;
  }

  public abstract int getStatus();

  public int getStatusOnIcc()
  {
    return this.mStatusOnIcc;
  }

  public long getTimestampMillis()
  {
    return this.mScTimeMillis;
  }

  public byte[] getUserData()
  {
    return this.mUserData;
  }

  public SmsHeader getUserDataHeader()
  {
    return this.mUserDataHeader;
  }

  public abstract boolean isCphsMwiMessage();

  public boolean isEmail()
  {
    return this.mIsEmail;
  }

  public abstract boolean isMWIClearMessage();

  public abstract boolean isMWISetMessage();

  public abstract boolean isMwiDontStore();

  public abstract boolean isReplace();

  public abstract boolean isReplyPathPresent();

  public abstract boolean isStatusReportMessage();

  protected void parseMessageBody()
  {
    if ((this.mOriginatingAddress != null) && (this.mOriginatingAddress.couldBeEmailGateway()))
      extractEmailAddressFromMessageBody();
  }

  public static abstract class SubmitPduBase
  {
    public byte[] encodedMessage;
    public byte[] encodedScAddress;

    public String toString()
    {
      return "SubmitPdu: encodedScAddress = " + Arrays.toString(this.encodedScAddress) + ", encodedMessage = " + Arrays.toString(this.encodedMessage);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsMessageBase
 * JD-Core Version:    0.6.2
 */