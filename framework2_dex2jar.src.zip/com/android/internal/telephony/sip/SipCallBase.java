package com.android.internal.telephony.sip;

import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

abstract class SipCallBase extends Call
{
  void clearDisconnected()
  {
    Iterator localIterator = this.mConnections.iterator();
    while (localIterator.hasNext())
      if (((Connection)localIterator.next()).getState() == Call.State.DISCONNECTED)
        localIterator.remove();
    if (this.mConnections.isEmpty())
      setState(Call.State.IDLE);
  }

  public List<Connection> getConnections()
  {
    return this.mConnections;
  }

  public boolean isMultiparty()
  {
    int i = 1;
    if (this.mConnections.size() > i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  protected abstract void setState(Call.State paramState);

  public String toString()
  {
    return this.mState.toString() + ":" + super.toString();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.sip.SipCallBase
 * JD-Core Version:    0.6.2
 */