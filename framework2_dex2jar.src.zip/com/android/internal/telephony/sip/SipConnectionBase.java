package com.android.internal.telephony.sip;

import android.os.SystemClock;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.Connection.DisconnectCause;
import com.android.internal.telephony.Connection.PostDialState;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneConstants;
import com.android.internal.telephony.UUSInfo;

abstract class SipConnectionBase extends Connection
{
  private static final boolean DBG = true;
  private static final String LOG_TAG = "SipConnBase";
  private static final boolean VDBG;
  private Connection.DisconnectCause mCause = Connection.DisconnectCause.NOT_DISCONNECTED;
  private long mConnectTime;
  private long mConnectTimeReal;
  private long mCreateTime;
  private long mDisconnectTime;
  private long mDuration = -1L;
  private long mHoldingStartTime;
  private int mNextPostDialChar;
  private Connection.PostDialState mPostDialState = Connection.PostDialState.NOT_STARTED;
  private String mPostDialString;

  SipConnectionBase(String paramString)
  {
    log("SipConnectionBase: ctor dialString=" + paramString);
    this.mPostDialString = PhoneNumberUtils.extractPostDialPortion(paramString);
    this.mCreateTime = System.currentTimeMillis();
  }

  private void log(String paramString)
  {
    Rlog.d("SipConnBase", paramString);
  }

  public void cancelPostDial()
  {
    log("cancelPostDial: ignore");
  }

  public long getConnectTime()
  {
    return this.mConnectTime;
  }

  public long getCreateTime()
  {
    return this.mCreateTime;
  }

  public Connection.DisconnectCause getDisconnectCause()
  {
    return this.mCause;
  }

  public long getDisconnectTime()
  {
    return this.mDisconnectTime;
  }

  public long getDurationMillis()
  {
    long l;
    if (this.mConnectTimeReal == 0L)
      l = 0L;
    while (true)
    {
      return l;
      if (this.mDuration < 0L)
        l = SystemClock.elapsedRealtime() - this.mConnectTimeReal;
      else
        l = this.mDuration;
    }
  }

  public long getHoldDurationMillis()
  {
    if (getState() != Call.State.HOLDING);
    for (long l = 0L; ; l = SystemClock.elapsedRealtime() - this.mHoldingStartTime)
      return l;
  }

  public int getNumberPresentation()
  {
    return PhoneConstants.PRESENTATION_ALLOWED;
  }

  protected abstract Phone getPhone();

  public Connection.PostDialState getPostDialState()
  {
    return this.mPostDialState;
  }

  public String getRemainingPostDialString()
  {
    if ((this.mPostDialState == Connection.PostDialState.CANCELLED) || (this.mPostDialState == Connection.PostDialState.COMPLETE) || (this.mPostDialString == null) || (this.mPostDialString.length() <= this.mNextPostDialChar))
      log("getRemaingPostDialString: ret empty string");
    for (String str = ""; ; str = this.mPostDialString.substring(this.mNextPostDialChar))
      return str;
  }

  public UUSInfo getUUSInfo()
  {
    return null;
  }

  public void proceedAfterWaitChar()
  {
    log("proceedAfterWaitChar: ignore");
  }

  public void proceedAfterWildChar(String paramString)
  {
    log("proceedAfterWildChar: ignore");
  }

  void setDisconnectCause(Connection.DisconnectCause paramDisconnectCause)
  {
    log("setDisconnectCause: prev=" + this.mCause + " new=" + paramDisconnectCause);
    this.mCause = paramDisconnectCause;
  }

  protected void setState(Call.State paramState)
  {
    log("setState: state=" + paramState);
    switch (1.$SwitchMap$com$android$internal$telephony$Call$State[paramState.ordinal()])
    {
    default:
    case 1:
    case 2:
    case 3:
    }
    while (true)
    {
      return;
      if (this.mConnectTime == 0L)
      {
        this.mConnectTimeReal = SystemClock.elapsedRealtime();
        this.mConnectTime = System.currentTimeMillis();
        continue;
        this.mDuration = getDurationMillis();
        this.mDisconnectTime = System.currentTimeMillis();
        continue;
        this.mHoldingStartTime = SystemClock.elapsedRealtime();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.sip.SipConnectionBase
 * JD-Core Version:    0.6.2
 */