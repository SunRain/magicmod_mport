package com.android.internal.telephony;

public class SmsResponse
{
  String mAckPdu;
  int mErrorCode;
  int mMessageRef;

  public SmsResponse(int paramInt1, String paramString, int paramInt2)
  {
    this.mMessageRef = paramInt1;
    this.mAckPdu = paramString;
    this.mErrorCode = paramInt2;
  }

  public String toString()
  {
    return "{ mMessageRef = " + this.mMessageRef + ", mErrorCode = " + this.mErrorCode + ", mAckPdu = " + this.mAckPdu + "}";
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsResponse
 * JD-Core Version:    0.6.2
 */