package com.android.internal.telephony;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.provider.Telephony.Sms;
import android.telephony.Rlog;
import com.android.internal.telephony.cdma.CdmaInboundSmsHandler;
import com.android.internal.telephony.gsm.GsmInboundSmsHandler;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class SmsBroadcastUndelivered
  implements Runnable
{
  private static final boolean DBG = true;
  static final long PARTIAL_SEGMENT_EXPIRE_AGE = 2592000000L;
  private static final String[] PDU_PENDING_MESSAGE_PROJECTION = { "pdu", "sequence", "destination_port", "date", "reference_number", "count", "address", "_id" };
  private static final String TAG = "SmsBroadcastUndelivered";
  private static final Uri sRawUri = Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, "raw");
  private final CdmaInboundSmsHandler mCdmaInboundSmsHandler;
  private final GsmInboundSmsHandler mGsmInboundSmsHandler;
  private final ContentResolver mResolver;

  public SmsBroadcastUndelivered(Context paramContext, GsmInboundSmsHandler paramGsmInboundSmsHandler, CdmaInboundSmsHandler paramCdmaInboundSmsHandler)
  {
    this.mResolver = paramContext.getContentResolver();
    this.mGsmInboundSmsHandler = paramGsmInboundSmsHandler;
    this.mCdmaInboundSmsHandler = paramCdmaInboundSmsHandler;
  }

  private void broadcastSms(InboundSmsTracker paramInboundSmsTracker)
  {
    Object localObject;
    if (paramInboundSmsTracker.is3gpp2())
    {
      localObject = this.mCdmaInboundSmsHandler;
      if (localObject == null)
        break label31;
      ((InboundSmsHandler)localObject).sendMessage(2, paramInboundSmsTracker);
    }
    while (true)
    {
      return;
      localObject = this.mGsmInboundSmsHandler;
      break;
      label31: Rlog.e("SmsBroadcastUndelivered", "null handler for " + paramInboundSmsTracker.getFormat() + " format, can't deliver.");
    }
  }

  private void scanRawTable()
  {
    long l = System.nanoTime();
    HashMap localHashMap = new HashMap(4);
    HashSet localHashSet = new HashSet(4);
    Cursor localCursor = null;
    while (true)
    {
      String str1;
      String str2;
      InboundSmsTracker localInboundSmsTracker;
      try
      {
        localCursor = this.mResolver.query(sRawUri, PDU_PENDING_MESSAGE_PROJECTION, null, null, null);
        if (localCursor == null)
        {
          Rlog.e("SmsBroadcastUndelivered", "error getting pending message cursor");
          if (localCursor != null)
            localCursor.close();
          str1 = "SmsBroadcastUndelivered";
          str2 = "finished scanning raw table in " + (System.nanoTime() - l) / 1000000L + " ms";
          Rlog.d(str1, str2);
          return;
        }
        bool1 = InboundSmsHandler.isCurrentFormat3gpp2();
        boolean bool2 = localCursor.moveToNext();
        if (!bool2)
          break label441;
      }
      catch (SQLException localSQLException)
      {
        boolean bool1;
        continue;
      }
      finally
      {
        if (localCursor != null)
          localCursor.close();
        Rlog.d("SmsBroadcastUndelivered", "finished scanning raw table in " + (System.nanoTime() - l) / 1000000L + " ms");
      }
      SmsReferenceKey localSmsReferenceKey2 = new SmsReferenceKey(localInboundSmsTracker);
      Integer localInteger = (Integer)localHashMap.get(localSmsReferenceKey2);
      if (localInteger == null)
      {
        localHashMap.put(localSmsReferenceKey2, Integer.valueOf(1));
        if (localInboundSmsTracker.getTimestamp() < System.currentTimeMillis() - 2592000000L)
          localHashSet.add(localSmsReferenceKey2);
      }
      else
      {
        int j = 1 + localInteger.intValue();
        if (j == localInboundSmsTracker.getMessageCount())
        {
          Rlog.d("SmsBroadcastUndelivered", "found complete multi-part message");
          broadcastSms(localInboundSmsTracker);
          localHashSet.remove(localSmsReferenceKey2);
        }
        else
        {
          localHashMap.put(localSmsReferenceKey2, Integer.valueOf(j));
          continue;
          label441: Iterator localIterator = localHashSet.iterator();
          while (localIterator.hasNext())
          {
            SmsReferenceKey localSmsReferenceKey1 = (SmsReferenceKey)localIterator.next();
            int i = this.mResolver.delete(sRawUri, "address=? AND reference_number=? AND count=?", localSmsReferenceKey1.getDeleteWhereArgs());
            if (i == 0)
              Rlog.e("SmsBroadcastUndelivered", "No rows were deleted from raw table!");
            else
              Rlog.d("SmsBroadcastUndelivered", "Deleted " + i + " rows from raw table for incomplete " + localSmsReferenceKey1.mMessageCount + " part message");
          }
          if (localCursor != null)
            localCursor.close();
          str1 = "SmsBroadcastUndelivered";
          str2 = "finished scanning raw table in " + (System.nanoTime() - l) / 1000000L + " ms";
        }
      }
    }
  }

  public void run()
  {
    Rlog.d("SmsBroadcastUndelivered", "scanning raw table for undelivered messages");
    scanRawTable();
    if (this.mGsmInboundSmsHandler != null)
      this.mGsmInboundSmsHandler.sendMessage(6);
    if (this.mCdmaInboundSmsHandler != null)
      this.mCdmaInboundSmsHandler.sendMessage(6);
  }

  private static class SmsReferenceKey
  {
    final String mAddress;
    final int mMessageCount;
    final int mReferenceNumber;

    SmsReferenceKey(InboundSmsTracker paramInboundSmsTracker)
    {
      this.mAddress = paramInboundSmsTracker.getAddress();
      this.mReferenceNumber = paramInboundSmsTracker.getReferenceNumber();
      this.mMessageCount = paramInboundSmsTracker.getMessageCount();
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = false;
      if ((paramObject instanceof SmsReferenceKey))
      {
        SmsReferenceKey localSmsReferenceKey = (SmsReferenceKey)paramObject;
        if ((localSmsReferenceKey.mAddress.equals(this.mAddress)) && (localSmsReferenceKey.mReferenceNumber == this.mReferenceNumber) && (localSmsReferenceKey.mMessageCount == this.mMessageCount))
          bool = true;
      }
      return bool;
    }

    String[] getDeleteWhereArgs()
    {
      String[] arrayOfString = new String[3];
      arrayOfString[0] = this.mAddress;
      arrayOfString[1] = Integer.toString(this.mReferenceNumber);
      arrayOfString[2] = Integer.toString(this.mMessageCount);
      return arrayOfString;
    }

    public int hashCode()
    {
      return 31 * (31 * this.mReferenceNumber + this.mMessageCount) + this.mAddress.hashCode();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SmsBroadcastUndelivered
 * JD-Core Version:    0.6.2
 */