package com.android.internal.telephony;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class OperatorInfo
  implements Parcelable
{
  public static final Parcelable.Creator<OperatorInfo> CREATOR = new Parcelable.Creator()
  {
    public OperatorInfo createFromParcel(Parcel paramAnonymousParcel)
    {
      return new OperatorInfo(paramAnonymousParcel.readString(), paramAnonymousParcel.readString(), paramAnonymousParcel.readString(), (OperatorInfo.State)paramAnonymousParcel.readSerializable());
    }

    public OperatorInfo[] newArray(int paramAnonymousInt)
    {
      return new OperatorInfo[paramAnonymousInt];
    }
  };
  private String mOperatorAlphaLong;
  private String mOperatorAlphaShort;
  private String mOperatorNumeric;
  private State mState = State.UNKNOWN;

  OperatorInfo(String paramString1, String paramString2, String paramString3, State paramState)
  {
    this.mOperatorAlphaLong = paramString1;
    this.mOperatorAlphaShort = paramString2;
    this.mOperatorNumeric = paramString3;
    this.mState = paramState;
  }

  public OperatorInfo(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    this(paramString1, paramString2, paramString3, rilStateToState(paramString4));
  }

  private static State rilStateToState(String paramString)
  {
    State localState;
    if (paramString.equals("unknown"))
      localState = State.UNKNOWN;
    while (true)
    {
      return localState;
      if (paramString.equals("available"))
      {
        localState = State.AVAILABLE;
      }
      else if (paramString.equals("current"))
      {
        localState = State.CURRENT;
      }
      else
      {
        if (!paramString.equals("forbidden"))
          break;
        localState = State.FORBIDDEN;
      }
    }
    throw new RuntimeException("RIL impl error: Invalid network state '" + paramString + "'");
  }

  public int describeContents()
  {
    return 0;
  }

  public String getOperatorAlphaLong()
  {
    return this.mOperatorAlphaLong;
  }

  public String getOperatorAlphaShort()
  {
    return this.mOperatorAlphaShort;
  }

  public String getOperatorNumeric()
  {
    return this.mOperatorNumeric;
  }

  public State getState()
  {
    return this.mState;
  }

  public String toString()
  {
    return "OperatorInfo " + this.mOperatorAlphaLong + "/" + this.mOperatorAlphaShort + "/" + this.mOperatorNumeric + "/" + this.mState;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.mOperatorAlphaLong);
    paramParcel.writeString(this.mOperatorAlphaShort);
    paramParcel.writeString(this.mOperatorNumeric);
    paramParcel.writeSerializable(this.mState);
  }

  public static enum State
  {
    static
    {
      AVAILABLE = new State("AVAILABLE", 1);
      CURRENT = new State("CURRENT", 2);
      FORBIDDEN = new State("FORBIDDEN", 3);
      State[] arrayOfState = new State[4];
      arrayOfState[0] = UNKNOWN;
      arrayOfState[1] = AVAILABLE;
      arrayOfState[2] = CURRENT;
      arrayOfState[3] = FORBIDDEN;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.OperatorInfo
 * JD-Core Version:    0.6.2
 */