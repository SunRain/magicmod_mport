package com.android.internal.telephony;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.sqlite.SqliteWrapper;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Binder;
import android.os.Handler;
import android.os.Message;
import android.os.SystemProperties;
import android.provider.Settings.Global;
import android.provider.Telephony.Sms;
import android.provider.Telephony.Sms.Sent;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.text.Spanned;
import android.util.EventLog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class SMSDispatcher extends Handler
{
  static final boolean DBG = false;
  private static final int EVENT_CONFIRM_SEND_TO_POSSIBLE_PREMIUM_SHORT_CODE = 8;
  private static final int EVENT_CONFIRM_SEND_TO_PREMIUM_SHORT_CODE = 9;
  protected static final int EVENT_HANDLE_STATUS_REPORT = 10;
  protected static final int EVENT_ICC_CHANGED = 15;
  protected static final int EVENT_IMS_STATE_CHANGED = 12;
  protected static final int EVENT_IMS_STATE_DONE = 13;
  protected static final int EVENT_NEW_ICC_SMS = 14;
  protected static final int EVENT_RADIO_ON = 11;
  static final int EVENT_SEND_CONFIRMED_SMS = 5;
  private static final int EVENT_SEND_LIMIT_REACHED_CONFIRMATION = 4;
  private static final int EVENT_SEND_RETRY = 3;
  protected static final int EVENT_SEND_SMS_COMPLETE = 2;
  static final int EVENT_STOP_SENDING = 7;
  private static final int MAX_SEND_RETRIES = 3;
  private static final int MO_MSG_QUEUE_LIMIT = 5;
  private static final int PREMIUM_RULE_USE_BOTH = 3;
  private static final int PREMIUM_RULE_USE_NETWORK = 2;
  private static final int PREMIUM_RULE_USE_SIM = 1;
  private static final String SEND_NEXT_MSG_EXTRA = "SendNextMsg";
  private static final int SEND_RETRY_DELAY = 2000;
  private static final String SEND_SMS_NO_CONFIRMATION_PERMISSION = "android.permission.SEND_SMS_NO_CONFIRMATION";
  private static final int SINGLE_PART_SMS = 1;
  static final String TAG = "SMSDispatcher";
  private static int sConcatenatedRef = new Random().nextInt(256);
  protected final ArrayList<SmsTracker> deliveryPendingList = new ArrayList();
  protected final CommandsInterface mCi;
  protected final Context mContext;
  private ImsSMSDispatcher mImsSMSDispatcher;
  private int mPendingTrackerCount;
  protected PhoneBase mPhone;
  private final AtomicInteger mPremiumSmsRule = new AtomicInteger(1);
  protected int mRemainingMessages = -1;
  protected final ContentResolver mResolver;
  private final SettingsObserver mSettingsObserver;
  protected boolean mSmsCapable = true;
  protected boolean mSmsSendDisabled;
  protected final TelephonyManager mTelephonyManager;
  private SmsUsageMonitor mUsageMonitor;

  protected SMSDispatcher(PhoneBase paramPhoneBase, SmsUsageMonitor paramSmsUsageMonitor, ImsSMSDispatcher paramImsSMSDispatcher)
  {
    this.mPhone = paramPhoneBase;
    this.mImsSMSDispatcher = paramImsSMSDispatcher;
    this.mContext = paramPhoneBase.getContext();
    this.mResolver = this.mContext.getContentResolver();
    this.mCi = paramPhoneBase.mCi;
    this.mUsageMonitor = paramSmsUsageMonitor;
    this.mTelephonyManager = ((TelephonyManager)this.mContext.getSystemService("phone"));
    this.mSettingsObserver = new SettingsObserver(this, this.mPremiumSmsRule, this.mContext);
    this.mContext.getContentResolver().registerContentObserver(Settings.Global.getUriFor("sms_short_code_rule"), false, this.mSettingsObserver);
    this.mSmsCapable = this.mContext.getResources().getBoolean(17891386);
    if (!SystemProperties.getBoolean("telephony.sms.send", this.mSmsCapable));
    for (boolean bool = true; ; bool = false)
    {
      this.mSmsSendDisabled = bool;
      Rlog.d("SMSDispatcher", "SMSDispatcher: ctor mSmsCapable=" + this.mSmsCapable + " format=" + getFormat() + " mSmsSendDisabled=" + this.mSmsSendDisabled);
      return;
    }
  }

  private boolean denyIfQueueLimitReached(SmsTracker paramSmsTracker)
  {
    if (this.mPendingTrackerCount >= 5);
    while (true)
    {
      try
      {
        if (paramSmsTracker.mSentIntent != null)
          paramSmsTracker.mSentIntent.send(5);
        bool = true;
        return bool;
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
        Rlog.e("SMSDispatcher", "failed to send back RESULT_ERROR_LIMIT_EXCEEDED");
        continue;
      }
      this.mPendingTrackerCount = (1 + this.mPendingTrackerCount);
      boolean bool = false;
    }
  }

  private CharSequence getAppLabel(String paramString)
  {
    PackageManager localPackageManager = this.mContext.getPackageManager();
    try
    {
      CharSequence localCharSequence = localPackageManager.getApplicationInfo(paramString, 0).loadLabel(localPackageManager);
      paramString = localCharSequence;
      return paramString;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
        Rlog.e("SMSDispatcher", "PackageManager Name Not Found for package " + paramString);
    }
  }

  protected static int getNextConcatenatedRef()
  {
    sConcatenatedRef = 1 + sConcatenatedRef;
    return sConcatenatedRef;
  }

  protected static void handleNotInService(int paramInt, PendingIntent paramPendingIntent)
  {
    if (paramPendingIntent != null)
    {
      if (paramInt == 3);
      try
      {
        paramPendingIntent.send(2);
        return;
        paramPendingIntent.send(4);
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
      }
    }
  }

  private void sendMultipartSms(SmsTracker paramSmsTracker)
  {
    HashMap localHashMap = paramSmsTracker.mData;
    String str1 = (String)localHashMap.get("destination");
    String str2 = (String)localHashMap.get("scaddress");
    ArrayList localArrayList1 = (ArrayList)localHashMap.get("parts");
    ArrayList localArrayList2 = (ArrayList)localHashMap.get("sentIntents");
    ArrayList localArrayList3 = (ArrayList)localHashMap.get("deliveryIntents");
    int i = this.mPhone.getServiceState().getState();
    int j;
    int k;
    if ((!isIms()) && (i != 0))
    {
      j = 0;
      k = localArrayList1.size();
    }
    while (j < k)
    {
      PendingIntent localPendingIntent = null;
      if ((localArrayList2 != null) && (localArrayList2.size() > j))
        localPendingIntent = (PendingIntent)localArrayList2.get(j);
      handleNotInService(i, localPendingIntent);
      j++;
      continue;
      sendMultipartText(str1, str2, localArrayList1, localArrayList2, localArrayList3);
    }
  }

  protected abstract GsmAlphabet.TextEncodingDetails calculateLength(CharSequence paramCharSequence, boolean paramBoolean);

  boolean checkDestination(SmsTracker paramSmsTracker)
  {
    int i = 1;
    if (this.mContext.checkCallingOrSelfPermission("android.permission.SEND_SMS_NO_CONFIRMATION") == 0);
    int k;
    do
    {
      return i;
      int j = this.mPremiumSmsRule.get();
      k = 0;
      if ((j == i) || (j == 3))
      {
        String str1 = this.mTelephonyManager.getSimCountryIso();
        if ((str1 == null) || (str1.length() != 2))
        {
          Rlog.e("SMSDispatcher", "Can't get SIM country Iso: trying network country Iso");
          str1 = this.mTelephonyManager.getNetworkCountryIso();
        }
        k = this.mUsageMonitor.checkDestination(paramSmsTracker.mDestAddress, str1);
      }
      if ((j == 2) || (j == 3))
      {
        String str2 = this.mTelephonyManager.getNetworkCountryIso();
        if ((str2 == null) || (str2.length() != 2))
        {
          Rlog.e("SMSDispatcher", "Can't get Network country Iso: trying SIM country Iso");
          str2 = this.mTelephonyManager.getSimCountryIso();
        }
        k = SmsUsageMonitor.mergeShortCodeCategories(k, this.mUsageMonitor.checkDestination(paramSmsTracker.mDestAddress, str2));
      }
    }
    while ((k == 0) || (k == i) || (k == 2));
    int m = this.mUsageMonitor.getPremiumSmsPermission(paramSmsTracker.mAppInfo.packageName);
    if (m == 0)
      m = 1;
    switch (m)
    {
    default:
      if (k != 3)
        break;
    case 3:
    case 2:
    }
    for (int n = 8; ; n = 9)
    {
      sendMessage(obtainMessage(n, paramSmsTracker));
      i = 0;
      break;
      Rlog.d("SMSDispatcher", "User approved this app to send to premium SMS");
      break;
      Rlog.w("SMSDispatcher", "User denied this app from sending to premium SMS");
      sendMessage(obtainMessage(7, paramSmsTracker));
      i = 0;
      break;
    }
  }

  public void dispose()
  {
    this.mContext.getContentResolver().unregisterContentObserver(this.mSettingsObserver);
  }

  protected abstract String getFormat();

  public String getImsSmsFormat()
  {
    if (this.mImsSMSDispatcher != null);
    for (String str = this.mImsSMSDispatcher.getImsSmsFormat(); ; str = null)
    {
      return str;
      Rlog.e("SMSDispatcher", this.mImsSMSDispatcher + " is null");
    }
  }

  public int getPremiumSmsPermission(String paramString)
  {
    return this.mUsageMonitor.getPremiumSmsPermission(paramString);
  }

  protected SmsTracker getSmsTracker(HashMap<String, Object> paramHashMap, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String paramString)
  {
    PackageManager localPackageManager = this.mContext.getPackageManager();
    String[] arrayOfString = localPackageManager.getPackagesForUid(Binder.getCallingUid());
    Object localObject = null;
    if ((arrayOfString != null) && (arrayOfString.length > 0));
    try
    {
      PackageInfo localPackageInfo = localPackageManager.getPackageInfo(arrayOfString[0], 64);
      localObject = localPackageInfo;
      label50: return new SmsTracker(paramHashMap, paramPendingIntent1, paramPendingIntent2, localObject, PhoneNumberUtils.extractNetworkPortion((String)paramHashMap.get("destAddr")), paramString, null);
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label50;
    }
  }

  protected HashMap<String, Object> getSmsTrackerMap(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfByte, SmsMessageBase.SubmitPduBase paramSubmitPduBase)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("destAddr", paramString1);
    localHashMap.put("scAddr", paramString2);
    localHashMap.put("destPort", Integer.valueOf(paramInt));
    localHashMap.put("data", paramArrayOfByte);
    localHashMap.put("smsc", paramSubmitPduBase.encodedScAddress);
    localHashMap.put("pdu", paramSubmitPduBase.encodedMessage);
    return localHashMap;
  }

  protected HashMap<String, Object> getSmsTrackerMap(String paramString1, String paramString2, String paramString3, SmsMessageBase.SubmitPduBase paramSubmitPduBase)
  {
    HashMap localHashMap = new HashMap();
    localHashMap.put("destAddr", paramString1);
    localHashMap.put("scAddr", paramString2);
    localHashMap.put("text", paramString3);
    localHashMap.put("smsc", paramSubmitPduBase.encodedScAddress);
    localHashMap.put("pdu", paramSubmitPduBase.encodedMessage);
    return localHashMap;
  }

  protected void handleConfirmShortCode(boolean paramBoolean, SmsTracker paramSmsTracker)
  {
    if (denyIfQueueLimitReached(paramSmsTracker))
      return;
    if (paramBoolean);
    for (int i = 17040459; ; i = 17040458)
    {
      CharSequence localCharSequence = getAppLabel(paramSmsTracker.mAppInfo.packageName);
      Resources localResources = Resources.getSystem();
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = localCharSequence;
      arrayOfObject[1] = paramSmsTracker.mDestAddress;
      Spanned localSpanned = Html.fromHtml(localResources.getString(17040457, arrayOfObject));
      View localView = ((LayoutInflater)this.mContext.getSystemService("layout_inflater")).inflate(17367202, null);
      ConfirmDialogListener localConfirmDialogListener = new ConfirmDialogListener(paramSmsTracker, (TextView)localView.findViewById(16909121));
      ((TextView)localView.findViewById(16909115)).setText(localSpanned);
      ((TextView)((ViewGroup)localView.findViewById(16909116)).findViewById(16909118)).setText(i);
      ((CheckBox)localView.findViewById(16909119)).setOnCheckedChangeListener(localConfirmDialogListener);
      AlertDialog localAlertDialog = new AlertDialog.Builder(this.mContext).setView(localView).setPositiveButton(localResources.getString(17040460), localConfirmDialogListener).setNegativeButton(localResources.getString(17040461), localConfirmDialogListener).setOnCancelListener(localConfirmDialogListener).create();
      localAlertDialog.getWindow().setType(2003);
      localAlertDialog.show();
      localConfirmDialogListener.setPositiveButton(localAlertDialog.getButton(-1));
      localConfirmDialogListener.setNegativeButton(localAlertDialog.getButton(-2));
      break;
    }
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    case 6:
    default:
      Rlog.e("SMSDispatcher", "handleMessage() ignoring message of unexpected type " + paramMessage.what);
    case 2:
    case 3:
    case 4:
    case 8:
    case 9:
    case 5:
    case 7:
    case 10:
    }
    while (true)
    {
      return;
      handleSendComplete((AsyncResult)paramMessage.obj);
      continue;
      Rlog.d("SMSDispatcher", "SMS retry..");
      sendRetrySms((SmsTracker)paramMessage.obj);
      continue;
      handleReachSentLimit((SmsTracker)paramMessage.obj);
      continue;
      handleConfirmShortCode(false, (SmsTracker)paramMessage.obj);
      continue;
      handleConfirmShortCode(true, (SmsTracker)paramMessage.obj);
      continue;
      SmsTracker localSmsTracker2 = (SmsTracker)paramMessage.obj;
      if (localSmsTracker2.isMultipart())
        sendMultipartSms(localSmsTracker2);
      while (true)
      {
        this.mPendingTrackerCount = (-1 + this.mPendingTrackerCount);
        break;
        sendSms(localSmsTracker2);
      }
      SmsTracker localSmsTracker1 = (SmsTracker)paramMessage.obj;
      if (localSmsTracker1.mSentIntent != null);
      try
      {
        localSmsTracker1.mSentIntent.send(5);
        this.mPendingTrackerCount = (-1 + this.mPendingTrackerCount);
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
        while (true)
          Rlog.e("SMSDispatcher", "failed to send RESULT_ERROR_LIMIT_EXCEEDED");
      }
      handleStatusReport(paramMessage.obj);
    }
  }

  protected void handleReachSentLimit(SmsTracker paramSmsTracker)
  {
    if (denyIfQueueLimitReached(paramSmsTracker));
    while (true)
    {
      return;
      CharSequence localCharSequence = getAppLabel(paramSmsTracker.mAppInfo.packageName);
      Resources localResources = Resources.getSystem();
      Spanned localSpanned = Html.fromHtml(localResources.getString(17040454, new Object[] { localCharSequence }));
      ConfirmDialogListener localConfirmDialogListener = new ConfirmDialogListener(paramSmsTracker, null);
      AlertDialog localAlertDialog = new AlertDialog.Builder(this.mContext).setTitle(17040453).setIcon(17301642).setMessage(localSpanned).setPositiveButton(localResources.getString(17040455), localConfirmDialogListener).setNegativeButton(localResources.getString(17040456), localConfirmDialogListener).setOnCancelListener(localConfirmDialogListener).create();
      localAlertDialog.getWindow().setType(2003);
      localAlertDialog.show();
    }
  }

  protected void handleSendComplete(AsyncResult paramAsyncResult)
  {
    SmsTracker localSmsTracker = (SmsTracker)paramAsyncResult.userObj;
    PendingIntent localPendingIntent = localSmsTracker.mSentIntent;
    if (paramAsyncResult.result != null)
    {
      localSmsTracker.mMessageRef = ((SmsResponse)paramAsyncResult.result).mMessageRef;
      if (paramAsyncResult.exception != null)
        break label169;
      if (SmsApplication.shouldWriteMessageForPackage(localSmsTracker.mAppInfo.applicationInfo.packageName, this.mContext))
        localSmsTracker.writeSentMessage(this.mContext);
      if (localSmsTracker.mDeliveryIntent != null)
        this.deliveryPendingList.add(localSmsTracker);
      if (localPendingIntent == null);
    }
    while (true)
    {
      try
      {
        if (this.mRemainingMessages > -1)
          this.mRemainingMessages = (-1 + this.mRemainingMessages);
        if (this.mRemainingMessages == 0)
        {
          Intent localIntent2 = new Intent();
          localIntent2.putExtra("SendNextMsg", true);
          localPendingIntent.send(this.mContext, -1, localIntent2);
          return;
          Rlog.d("SMSDispatcher", "SmsResponse was null");
          break;
        }
        localPendingIntent.send(-1);
        continue;
      }
      catch (PendingIntent.CanceledException localCanceledException2)
      {
        continue;
      }
      label169: int i = this.mPhone.getServiceState().getState();
      if ((localSmsTracker.mImsRetry > 0) && (i != 0))
      {
        localSmsTracker.mRetryCount = 3;
        Rlog.d("SMSDispatcher", "handleSendComplete: Skipping retry:  isIms()=" + isIms() + " mRetryCount=" + localSmsTracker.mRetryCount + " mImsRetry=" + localSmsTracker.mImsRetry + " mMessageRef=" + localSmsTracker.mMessageRef + " SS= " + this.mPhone.getServiceState().getState());
      }
      if ((!isIms()) && (i != 0))
      {
        handleNotInService(i, localSmsTracker.mSentIntent);
      }
      else if ((((CommandException)paramAsyncResult.exception).getCommandError() == CommandException.Error.SMS_FAIL_RETRY) && (localSmsTracker.mRetryCount < 3))
      {
        localSmsTracker.mRetryCount = (1 + localSmsTracker.mRetryCount);
        sendMessageDelayed(obtainMessage(3, localSmsTracker), 2000L);
      }
      else if (localSmsTracker.mSentIntent != null)
      {
        int j = 1;
        if (((CommandException)paramAsyncResult.exception).getCommandError() == CommandException.Error.FDN_CHECK_FAILURE)
          j = 6;
        try
        {
          Intent localIntent1 = new Intent();
          if (paramAsyncResult.result != null)
            localIntent1.putExtra("errorCode", ((SmsResponse)paramAsyncResult.result).mErrorCode);
          if (this.mRemainingMessages > -1)
            this.mRemainingMessages = (-1 + this.mRemainingMessages);
          if (this.mRemainingMessages == 0)
            localIntent1.putExtra("SendNextMsg", true);
          localSmsTracker.mSentIntent.send(this.mContext, j, localIntent1);
        }
        catch (PendingIntent.CanceledException localCanceledException1)
        {
        }
      }
    }
  }

  protected void handleStatusReport(Object paramObject)
  {
    Rlog.d("SMSDispatcher", "handleStatusReport() called with no subclass.");
  }

  public boolean isIms()
  {
    if (this.mImsSMSDispatcher != null);
    for (boolean bool = this.mImsSMSDispatcher.isIms(); ; bool = false)
    {
      return bool;
      Rlog.e("SMSDispatcher", this.mImsSMSDispatcher + " is null");
    }
  }

  protected abstract void sendData(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfByte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2);

  protected void sendMultipartText(String paramString1, String paramString2, ArrayList<String> paramArrayList, ArrayList<PendingIntent> paramArrayList1, ArrayList<PendingIntent> paramArrayList2)
  {
    int i = 0xFF & getNextConcatenatedRef();
    int j = paramArrayList.size();
    int k = 0;
    this.mRemainingMessages = j;
    GsmAlphabet.TextEncodingDetails[] arrayOfTextEncodingDetails = new GsmAlphabet.TextEncodingDetails[j];
    for (int m = 0; m < j; m++)
    {
      GsmAlphabet.TextEncodingDetails localTextEncodingDetails = calculateLength((CharSequence)paramArrayList.get(m), false);
      if ((k != localTextEncodingDetails.codeUnitSize) && ((k == 0) || (k == 1)))
        k = localTextEncodingDetails.codeUnitSize;
      arrayOfTextEncodingDetails[m] = localTextEncodingDetails;
    }
    int n = 0;
    if (n < j)
    {
      SmsHeader.ConcatRef localConcatRef = new SmsHeader.ConcatRef();
      localConcatRef.refNumber = i;
      localConcatRef.seqNumber = (n + 1);
      localConcatRef.msgCount = j;
      localConcatRef.isEightBits = true;
      SmsHeader localSmsHeader = new SmsHeader();
      localSmsHeader.concatRef = localConcatRef;
      if (k == 1)
      {
        localSmsHeader.languageTable = arrayOfTextEncodingDetails[n].languageTable;
        localSmsHeader.languageShiftTable = arrayOfTextEncodingDetails[n].languageShiftTable;
      }
      PendingIntent localPendingIntent1 = null;
      if ((paramArrayList1 != null) && (paramArrayList1.size() > n))
        localPendingIntent1 = (PendingIntent)paramArrayList1.get(n);
      PendingIntent localPendingIntent2 = null;
      if ((paramArrayList2 != null) && (paramArrayList2.size() > n))
        localPendingIntent2 = (PendingIntent)paramArrayList2.get(n);
      String str = (String)paramArrayList.get(n);
      if (n == j - 1);
      for (boolean bool = true; ; bool = false)
      {
        sendNewSubmitPdu(paramString1, paramString2, str, localSmsHeader, k, localPendingIntent1, localPendingIntent2, bool);
        n++;
        break;
      }
    }
  }

  protected abstract void sendNewSubmitPdu(String paramString1, String paramString2, String paramString3, SmsHeader paramSmsHeader, int paramInt, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, boolean paramBoolean);

  protected void sendRawPdu(SmsTracker paramSmsTracker)
  {
    byte[] arrayOfByte = (byte[])paramSmsTracker.mData.get("pdu");
    PendingIntent localPendingIntent = paramSmsTracker.mSentIntent;
    if ((!this.mSmsSendDisabled) || (localPendingIntent != null));
    try
    {
      localPendingIntent.send(4);
      label38: Rlog.d("SMSDispatcher", "Device does not support sending sms.");
      while (true)
      {
        return;
        if (arrayOfByte == null)
        {
          if (localPendingIntent != null)
            try
            {
              localPendingIntent.send(3);
            }
            catch (PendingIntent.CanceledException localCanceledException3)
            {
            }
        }
        else
        {
          PackageManager localPackageManager = this.mContext.getPackageManager();
          String[] arrayOfString = localPackageManager.getPackagesForUid(Binder.getCallingUid());
          if ((arrayOfString == null) || (arrayOfString.length == 0))
          {
            Rlog.e("SMSDispatcher", "Can't get calling app package name: refusing to send SMS");
            if (localPendingIntent != null)
              try
              {
                localPendingIntent.send(1);
              }
              catch (PendingIntent.CanceledException localCanceledException1)
              {
                Rlog.e("SMSDispatcher", "failed to send error result");
              }
          }
          else
          {
            try
            {
              PackageInfo localPackageInfo = localPackageManager.getPackageInfo(arrayOfString[0], 64);
              if (!checkDestination(paramSmsTracker))
                continue;
              if (this.mUsageMonitor.check(localPackageInfo.packageName, 1))
                break label222;
              sendMessage(obtainMessage(4, paramSmsTracker));
            }
            catch (PackageManager.NameNotFoundException localNameNotFoundException)
            {
              Rlog.e("SMSDispatcher", "Can't get calling app package info: refusing to send SMS");
            }
            if (localPendingIntent != null)
            {
              try
              {
                localPendingIntent.send(1);
              }
              catch (PendingIntent.CanceledException localCanceledException2)
              {
                Rlog.e("SMSDispatcher", "failed to send error result");
              }
              continue;
              label222: int i = this.mPhone.getServiceState().getState();
              if ((!isIms()) && (i != 0))
                handleNotInService(i, paramSmsTracker.mSentIntent);
              else
                sendSms(paramSmsTracker);
            }
          }
        }
      }
    }
    catch (PendingIntent.CanceledException localCanceledException4)
    {
      break label38;
    }
  }

  public void sendRetrySms(SmsTracker paramSmsTracker)
  {
    if (this.mImsSMSDispatcher != null)
      this.mImsSMSDispatcher.sendRetrySms(paramSmsTracker);
    while (true)
    {
      return;
      Rlog.e("SMSDispatcher", this.mImsSMSDispatcher + " is null. Retry failed");
    }
  }

  protected abstract void sendSms(SmsTracker paramSmsTracker);

  protected abstract void sendText(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2);

  public void setPremiumSmsPermission(String paramString, int paramInt)
  {
    this.mUsageMonitor.setPremiumSmsPermission(paramString, paramInt);
  }

  protected void updatePhoneObject(PhoneBase paramPhoneBase)
  {
    this.mPhone = paramPhoneBase;
    this.mUsageMonitor = paramPhoneBase.mSmsUsageMonitor;
    Rlog.d("SMSDispatcher", "Active phone changed to " + this.mPhone.getPhoneName());
  }

  private final class ConfirmDialogListener
    implements DialogInterface.OnClickListener, DialogInterface.OnCancelListener, CompoundButton.OnCheckedChangeListener
  {
    private Button mNegativeButton;
    private Button mPositiveButton;
    private boolean mRememberChoice;
    private final TextView mRememberUndoInstruction;
    private final SMSDispatcher.SmsTracker mTracker;

    ConfirmDialogListener(SMSDispatcher.SmsTracker paramTextView, TextView arg3)
    {
      this.mTracker = paramTextView;
      Object localObject;
      this.mRememberUndoInstruction = localObject;
    }

    public void onCancel(DialogInterface paramDialogInterface)
    {
      Rlog.d("SMSDispatcher", "dialog dismissed: don't send SMS");
      SMSDispatcher.this.sendMessage(SMSDispatcher.this.obtainMessage(7, this.mTracker));
    }

    public void onCheckedChanged(CompoundButton paramCompoundButton, boolean paramBoolean)
    {
      Rlog.d("SMSDispatcher", "remember this choice: " + paramBoolean);
      this.mRememberChoice = paramBoolean;
      if (paramBoolean)
      {
        this.mPositiveButton.setText(17040464);
        this.mNegativeButton.setText(17040465);
        if (this.mRememberUndoInstruction != null)
        {
          this.mRememberUndoInstruction.setText(17040463);
          this.mRememberUndoInstruction.setPadding(0, 0, 0, 32);
        }
      }
      while (true)
      {
        return;
        this.mPositiveButton.setText(17040460);
        this.mNegativeButton.setText(17040461);
        if (this.mRememberUndoInstruction != null)
        {
          this.mRememberUndoInstruction.setText("");
          this.mRememberUndoInstruction.setPadding(0, 0, 0, 0);
        }
      }
    }

    public void onClick(DialogInterface paramDialogInterface, int paramInt)
    {
      int i = -1;
      int j = 1;
      if (paramInt == i)
      {
        Rlog.d("SMSDispatcher", "CONFIRM sending SMS");
        if (this.mTracker.mAppInfo.applicationInfo == null)
        {
          EventLog.writeEvent(50128, i);
          SMSDispatcher.this.sendMessage(SMSDispatcher.this.obtainMessage(5, this.mTracker));
          if (this.mRememberChoice)
            j = 3;
        }
      }
      while (paramInt != -2)
        while (true)
        {
          SMSDispatcher.this.setPremiumSmsPermission(this.mTracker.mAppInfo.packageName, j);
          return;
          i = this.mTracker.mAppInfo.applicationInfo.uid;
        }
      Rlog.d("SMSDispatcher", "DENY sending SMS");
      if (this.mTracker.mAppInfo.applicationInfo == null);
      while (true)
      {
        EventLog.writeEvent(50125, i);
        SMSDispatcher.this.sendMessage(SMSDispatcher.this.obtainMessage(7, this.mTracker));
        if (!this.mRememberChoice)
          break;
        j = 2;
        break;
        i = this.mTracker.mAppInfo.applicationInfo.uid;
      }
    }

    void setNegativeButton(Button paramButton)
    {
      this.mNegativeButton = paramButton;
    }

    void setPositiveButton(Button paramButton)
    {
      this.mPositiveButton = paramButton;
    }
  }

  private static class SettingsObserver extends ContentObserver
  {
    private final Context mContext;
    private final AtomicInteger mPremiumSmsRule;

    SettingsObserver(Handler paramHandler, AtomicInteger paramAtomicInteger, Context paramContext)
    {
      super();
      this.mPremiumSmsRule = paramAtomicInteger;
      this.mContext = paramContext;
      onChange(false);
    }

    public void onChange(boolean paramBoolean)
    {
      this.mPremiumSmsRule.set(Settings.Global.getInt(this.mContext.getContentResolver(), "sms_short_code_rule", 1));
    }
  }

  protected static final class SmsTracker
  {
    public final PackageInfo mAppInfo;
    public final HashMap<String, Object> mData;
    public final PendingIntent mDeliveryIntent;
    public final String mDestAddress;
    String mFormat;
    public int mImsRetry;
    public int mMessageRef;
    public int mRetryCount;
    public final PendingIntent mSentIntent;
    private Uri mSentMessageUri;
    private long mTimestamp = System.currentTimeMillis();

    private SmsTracker(HashMap<String, Object> paramHashMap, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, PackageInfo paramPackageInfo, String paramString1, String paramString2)
    {
      this.mData = paramHashMap;
      this.mSentIntent = paramPendingIntent1;
      this.mDeliveryIntent = paramPendingIntent2;
      this.mRetryCount = 0;
      this.mAppInfo = paramPackageInfo;
      this.mDestAddress = paramString1;
      this.mFormat = paramString2;
      this.mImsRetry = 0;
      this.mMessageRef = 0;
    }

    boolean isMultipart()
    {
      return this.mData.containsKey("parts");
    }

    public void updateSentMessageStatus(Context paramContext, int paramInt)
    {
      if (this.mSentMessageUri != null)
      {
        ContentValues localContentValues = new ContentValues(1);
        localContentValues.put("status", Integer.valueOf(paramInt));
        SqliteWrapper.update(paramContext, paramContext.getContentResolver(), this.mSentMessageUri, localContentValues, null, null);
      }
    }

    void writeSentMessage(Context paramContext)
    {
      String str = (String)this.mData.get("text");
      if (str != null)
        if (this.mDeliveryIntent == null)
          break label57;
      label57: for (boolean bool = true; ; bool = false)
      {
        this.mSentMessageUri = Telephony.Sms.addMessageToUri(paramContext.getContentResolver(), Telephony.Sms.Sent.CONTENT_URI, this.mDestAddress, str, null, Long.valueOf(this.mTimestamp), true, bool, 0L);
        return;
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.SMSDispatcher
 * JD-Core Version:    0.6.2
 */