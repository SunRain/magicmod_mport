package com.android.internal.telephony;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.SystemProperties;
import android.provider.Telephony.Sms;
import android.telephony.Rlog;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import com.android.internal.util.HexDump;
import com.android.internal.util.State;
import com.android.internal.util.StateMachine;
import java.io.ByteArrayOutputStream;

public abstract class InboundSmsHandler extends StateMachine
{
  static final int ADDRESS_COLUMN = 6;
  static final int COUNT_COLUMN = 5;
  static final int DATE_COLUMN = 3;
  protected static final boolean DBG = true;
  static final int DESTINATION_PORT_COLUMN = 2;
  static final int EVENT_BROADCAST_COMPLETE = 3;
  static final int EVENT_BROADCAST_SMS = 2;
  public static final int EVENT_NEW_SMS = 1;
  static final int EVENT_RELEASE_WAKELOCK = 5;
  static final int EVENT_RETURN_TO_IDLE = 4;
  static final int EVENT_START_ACCEPTING_SMS = 6;
  static final int EVENT_UPDATE_PHONE_OBJECT = 7;
  static final int ID_COLUMN = 7;
  static final int PDU_COLUMN = 0;
  private static final String[] PDU_PROJECTION = { "pdu" };
  private static final String[] PDU_SEQUENCE_PORT_PROJECTION = { "pdu", "sequence", "destination_port" };
  static final int REFERENCE_NUMBER_COLUMN = 4;
  static final String SELECT_BY_ID = "_id=?";
  static final String SELECT_BY_REFERENCE = "address=? AND reference_number=? AND count=?";
  static final int SEQUENCE_COLUMN = 1;
  private static final boolean VDBG = false;
  private static final int WAKELOCK_TIMEOUT = 3000;
  private static final Uri sRawUri = Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, "raw");
  protected CellBroadcastHandler mCellBroadcastHandler;
  protected final Context mContext;
  final DefaultState mDefaultState = new DefaultState();
  final DeliveringState mDeliveringState = new DeliveringState();
  final IdleState mIdleState = new IdleState();
  protected PhoneBase mPhone;
  private final ContentResolver mResolver;
  private final boolean mSmsReceiveDisabled;
  final StartupState mStartupState = new StartupState();
  protected SmsStorageMonitor mStorageMonitor;
  final WaitingState mWaitingState = new WaitingState();
  final PowerManager.WakeLock mWakeLock;
  private final WapPushOverSms mWapPush;

  protected InboundSmsHandler(String paramString, Context paramContext, SmsStorageMonitor paramSmsStorageMonitor, PhoneBase paramPhoneBase, CellBroadcastHandler paramCellBroadcastHandler)
  {
    super(paramString);
    this.mContext = paramContext;
    this.mStorageMonitor = paramSmsStorageMonitor;
    this.mPhone = paramPhoneBase;
    this.mCellBroadcastHandler = paramCellBroadcastHandler;
    this.mResolver = paramContext.getContentResolver();
    this.mWapPush = new WapPushOverSms(paramContext);
    if (!SystemProperties.getBoolean("telephony.sms.receive", this.mContext.getResources().getBoolean(17891386)));
    for (boolean bool = true; ; bool = false)
    {
      this.mSmsReceiveDisabled = bool;
      this.mWakeLock = ((PowerManager)this.mContext.getSystemService("power")).newWakeLock(1, paramString);
      this.mWakeLock.acquire();
      addState(this.mDefaultState);
      addState(this.mStartupState, this.mDefaultState);
      addState(this.mIdleState, this.mDefaultState);
      addState(this.mDeliveringState, this.mDefaultState);
      addState(this.mWaitingState, this.mDeliveringState);
      setInitialState(this.mStartupState);
      log("created InboundSmsHandler");
      return;
    }
  }

  // ERROR //
  private int addTrackerToRawTable(InboundSmsTracker paramInboundSmsTracker)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual 238	com/android/internal/telephony/InboundSmsTracker:getMessageCount	()I
    //   4: iconst_1
    //   5: if_icmpeq +267 -> 272
    //   8: aconst_null
    //   9: astore 9
    //   11: aload_1
    //   12: invokevirtual 241	com/android/internal/telephony/InboundSmsTracker:getSequenceNumber	()I
    //   15: istore 12
    //   17: aload_1
    //   18: invokevirtual 245	com/android/internal/telephony/InboundSmsTracker:getAddress	()Ljava/lang/String;
    //   21: astore 13
    //   23: aload_1
    //   24: invokevirtual 248	com/android/internal/telephony/InboundSmsTracker:getReferenceNumber	()I
    //   27: invokestatic 254	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   30: astore 14
    //   32: aload_1
    //   33: invokevirtual 238	com/android/internal/telephony/InboundSmsTracker:getMessageCount	()I
    //   36: invokestatic 254	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   39: astore 15
    //   41: iload 12
    //   43: invokestatic 254	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   46: astore 16
    //   48: aload_1
    //   49: ldc 39
    //   51: iconst_3
    //   52: anewarray 74	java/lang/String
    //   55: dup
    //   56: iconst_0
    //   57: aload 13
    //   59: aastore
    //   60: dup
    //   61: iconst_1
    //   62: aload 14
    //   64: aastore
    //   65: dup
    //   66: iconst_2
    //   67: aload 15
    //   69: aastore
    //   70: invokevirtual 258	com/android/internal/telephony/InboundSmsTracker:setDeleteWhere	(Ljava/lang/String;[Ljava/lang/String;)V
    //   73: aload_0
    //   74: getfield 147	com/android/internal/telephony/InboundSmsHandler:mResolver	Landroid/content/ContentResolver;
    //   77: getstatic 99	com/android/internal/telephony/InboundSmsHandler:sRawUri	Landroid/net/Uri;
    //   80: getstatic 78	com/android/internal/telephony/InboundSmsHandler:PDU_PROJECTION	[Ljava/lang/String;
    //   83: ldc_w 260
    //   86: iconst_4
    //   87: anewarray 74	java/lang/String
    //   90: dup
    //   91: iconst_0
    //   92: aload 13
    //   94: aastore
    //   95: dup
    //   96: iconst_1
    //   97: aload 14
    //   99: aastore
    //   100: dup
    //   101: iconst_2
    //   102: aload 15
    //   104: aastore
    //   105: dup
    //   106: iconst_3
    //   107: aload 16
    //   109: aastore
    //   110: aconst_null
    //   111: invokevirtual 266	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   114: astore 9
    //   116: aload 9
    //   118: invokeinterface 272 1 0
    //   123: ifeq +130 -> 253
    //   126: aload_0
    //   127: new 274	java/lang/StringBuilder
    //   130: dup
    //   131: invokespecial 276	java/lang/StringBuilder:<init>	()V
    //   134: ldc_w 278
    //   137: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: aload 14
    //   142: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: ldc_w 284
    //   148: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: aload 16
    //   153: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: invokevirtual 286	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   159: invokevirtual 289	com/android/internal/telephony/InboundSmsHandler:loge	(Ljava/lang/String;)V
    //   162: aload 9
    //   164: iconst_0
    //   165: invokeinterface 292 2 0
    //   170: astore 17
    //   172: aload_1
    //   173: invokevirtual 296	com/android/internal/telephony/InboundSmsTracker:getPdu	()[B
    //   176: astore 18
    //   178: aload 17
    //   180: invokestatic 302	com/android/internal/util/HexDump:hexStringToByteArray	(Ljava/lang/String;)[B
    //   183: astore 19
    //   185: aload 19
    //   187: aload_1
    //   188: invokevirtual 296	com/android/internal/telephony/InboundSmsTracker:getPdu	()[B
    //   191: invokestatic 308	java/util/Arrays:equals	([B[B)Z
    //   194: ifne +41 -> 235
    //   197: aload_0
    //   198: new 274	java/lang/StringBuilder
    //   201: dup
    //   202: invokespecial 276	java/lang/StringBuilder:<init>	()V
    //   205: ldc_w 310
    //   208: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: aload 18
    //   213: arraylength
    //   214: invokevirtual 313	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   217: ldc_w 315
    //   220: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: aload 19
    //   225: arraylength
    //   226: invokevirtual 313	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   229: invokevirtual 286	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   232: invokevirtual 289	com/android/internal/telephony/InboundSmsHandler:loge	(Ljava/lang/String;)V
    //   235: iconst_5
    //   236: istore 5
    //   238: aload 9
    //   240: ifnull +10 -> 250
    //   243: aload 9
    //   245: invokeinterface 318 1 0
    //   250: iload 5
    //   252: ireturn
    //   253: aload 9
    //   255: invokeinterface 318 1 0
    //   260: aload 9
    //   262: ifnull +10 -> 272
    //   265: aload 9
    //   267: invokeinterface 318 1 0
    //   272: aload_1
    //   273: invokevirtual 322	com/android/internal/telephony/InboundSmsTracker:getContentValues	()Landroid/content/ContentValues;
    //   276: astore_2
    //   277: aload_0
    //   278: getfield 147	com/android/internal/telephony/InboundSmsHandler:mResolver	Landroid/content/ContentResolver;
    //   281: getstatic 99	com/android/internal/telephony/InboundSmsHandler:sRawUri	Landroid/net/Uri;
    //   284: aload_2
    //   285: invokevirtual 326	android/content/ContentResolver:insert	(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    //   288: astore_3
    //   289: aload_0
    //   290: new 274	java/lang/StringBuilder
    //   293: dup
    //   294: invokespecial 276	java/lang/StringBuilder:<init>	()V
    //   297: ldc_w 328
    //   300: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: aload_3
    //   304: invokevirtual 331	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   307: invokevirtual 286	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   310: invokevirtual 208	com/android/internal/telephony/InboundSmsHandler:log	(Ljava/lang/String;)V
    //   313: aload_3
    //   314: invokestatic 337	android/content/ContentUris:parseId	(Landroid/net/Uri;)J
    //   317: lstore 6
    //   319: aload_1
    //   320: invokevirtual 238	com/android/internal/telephony/InboundSmsTracker:getMessageCount	()I
    //   323: iconst_1
    //   324: if_icmpne +26 -> 350
    //   327: iconst_1
    //   328: anewarray 74	java/lang/String
    //   331: astore 8
    //   333: aload 8
    //   335: iconst_0
    //   336: lload 6
    //   338: invokestatic 342	java/lang/Long:toString	(J)Ljava/lang/String;
    //   341: aastore
    //   342: aload_1
    //   343: ldc 36
    //   345: aload 8
    //   347: invokevirtual 258	com/android/internal/telephony/InboundSmsTracker:setDeleteWhere	(Ljava/lang/String;[Ljava/lang/String;)V
    //   350: iconst_1
    //   351: istore 5
    //   353: goto -103 -> 250
    //   356: astore 11
    //   358: aload_0
    //   359: ldc_w 344
    //   362: aload 11
    //   364: invokevirtual 347	com/android/internal/telephony/InboundSmsHandler:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   367: iconst_2
    //   368: istore 5
    //   370: aload 9
    //   372: ifnull -122 -> 250
    //   375: goto -132 -> 243
    //   378: astore 10
    //   380: aload 9
    //   382: ifnull +10 -> 392
    //   385: aload 9
    //   387: invokeinterface 318 1 0
    //   392: aload 10
    //   394: athrow
    //   395: astore 4
    //   397: aload_0
    //   398: new 274	java/lang/StringBuilder
    //   401: dup
    //   402: invokespecial 276	java/lang/StringBuilder:<init>	()V
    //   405: ldc_w 349
    //   408: invokevirtual 282	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   411: aload_3
    //   412: invokevirtual 331	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   415: invokevirtual 286	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   418: aload 4
    //   420: invokevirtual 347	com/android/internal/telephony/InboundSmsHandler:loge	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   423: iconst_2
    //   424: istore 5
    //   426: goto -176 -> 250
    //
    // Exception table:
    //   from	to	target	type
    //   11	235	356	android/database/SQLException
    //   253	260	356	android/database/SQLException
    //   11	235	378	finally
    //   253	260	378	finally
    //   358	367	378	finally
    //   313	350	395	java/lang/Exception
  }

  static boolean isCurrentFormat3gpp2()
  {
    if (2 == TelephonyManager.getDefault().getCurrentPhoneType());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected abstract void acknowledgeLastIncomingSms(boolean paramBoolean, int paramInt, Message paramMessage);

  protected int addTrackerToRawTableAndSendMessage(InboundSmsTracker paramInboundSmsTracker)
  {
    int i = 1;
    switch (addTrackerToRawTable(paramInboundSmsTracker))
    {
    default:
      i = 2;
    case 5:
    case 1:
    }
    while (true)
    {
      return i;
      sendMessage(2, paramInboundSmsTracker);
    }
  }

  void deleteFromRawTable(String paramString, String[] paramArrayOfString)
  {
    int i = this.mResolver.delete(sRawUri, paramString, paramArrayOfString);
    if (i == 0)
      loge("No rows were deleted from raw table!");
    while (true)
    {
      return;
      log("Deleted " + i + " rows from raw table.");
    }
  }

  void dispatchIntent(Intent paramIntent, String paramString, int paramInt, BroadcastReceiver paramBroadcastReceiver)
  {
    if (Injector.InboundSmsHandlerHook.before_dispatchIntent(this, paramIntent, paramString, paramInt, paramBroadcastReceiver));
    while (true)
    {
      return;
      paramIntent.addFlags(134217728);
      this.mContext.sendOrderedBroadcast(paramIntent, paramString, paramInt, paramBroadcastReceiver, getHandler(), -1, null, null);
    }
  }

  public int dispatchMessage(SmsMessageBase paramSmsMessageBase)
  {
    int i;
    if (paramSmsMessageBase == null)
    {
      loge("dispatchSmsMessage: message is null");
      i = 2;
    }
    while (true)
    {
      return i;
      if (this.mSmsReceiveDisabled)
      {
        log("Received short message on device which doesn't support receiving SMS. Ignored.");
        i = 1;
      }
      else
      {
        i = dispatchMessageRadioSpecific(paramSmsMessageBase);
      }
    }
  }

  protected abstract int dispatchMessageRadioSpecific(SmsMessageBase paramSmsMessageBase);

  protected int dispatchNormalMessage(SmsMessageBase paramSmsMessageBase)
  {
    SmsHeader localSmsHeader = paramSmsMessageBase.getUserDataHeader();
    InboundSmsTracker localInboundSmsTracker;
    if ((localSmsHeader == null) || (localSmsHeader.concatRef == null))
    {
      int i = -1;
      if ((localSmsHeader != null) && (localSmsHeader.portAddrs != null))
      {
        i = localSmsHeader.portAddrs.destPort;
        log("destination port: " + i);
      }
      localInboundSmsTracker = new InboundSmsTracker(paramSmsMessageBase.getPdu(), paramSmsMessageBase.getTimestampMillis(), i, is3gpp2(), false);
      return addTrackerToRawTableAndSendMessage(localInboundSmsTracker);
    }
    SmsHeader.ConcatRef localConcatRef = localSmsHeader.concatRef;
    SmsHeader.PortAddrs localPortAddrs = localSmsHeader.portAddrs;
    if (localPortAddrs != null);
    for (int j = localPortAddrs.destPort; ; j = -1)
    {
      localInboundSmsTracker = new InboundSmsTracker(paramSmsMessageBase.getPdu(), paramSmsMessageBase.getTimestampMillis(), j, is3gpp2(), paramSmsMessageBase.getOriginatingAddress(), localConcatRef.refNumber, localConcatRef.seqNumber, localConcatRef.msgCount, false);
      break;
    }
  }

  public void dispose()
  {
    quit();
  }

  void handleNewSms(AsyncResult paramAsyncResult)
  {
    int i = 1;
    if (paramAsyncResult.exception != null)
      loge("Exception processing incoming SMS: " + paramAsyncResult.exception);
    while (true)
    {
      return;
      try
      {
        int m = dispatchMessage(((SmsMessage)paramAsyncResult.result).mWrappedSmsMessage);
        int j = m;
        if (j == -1)
          continue;
        if (j == i)
          notifyAndAcknowledgeLastIncomingSms(i, j, null);
      }
      catch (RuntimeException localRuntimeException)
      {
        while (true)
        {
          loge("Exception dispatching message", localRuntimeException);
          int k = 2;
          continue;
          i = 0;
        }
      }
    }
  }

  protected abstract boolean is3gpp2();

  protected void log(String paramString)
  {
    Rlog.d(getName(), paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e(getName(), paramString);
  }

  protected void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e(getName(), paramString, paramThrowable);
  }

  void notifyAndAcknowledgeLastIncomingSms(boolean paramBoolean, int paramInt, Message paramMessage)
  {
    if (!paramBoolean)
    {
      Intent localIntent = new Intent("android.provider.Telephony.SMS_REJECTED");
      localIntent.putExtra("result", paramInt);
      this.mContext.sendBroadcast(localIntent, "android.permission.RECEIVE_SMS");
    }
    acknowledgeLastIncomingSms(paramBoolean, paramInt, paramMessage);
  }

  protected void onQuitting()
  {
    this.mWapPush.dispose();
    while (this.mWakeLock.isHeld())
      this.mWakeLock.release();
  }

  protected void onUpdatePhoneObject(PhoneBase paramPhoneBase)
  {
    this.mPhone = paramPhoneBase;
    this.mStorageMonitor = this.mPhone.mSmsStorageMonitor;
    log("onUpdatePhoneObject: phone=" + this.mPhone.getClass().getSimpleName());
  }

  boolean processMessagePart(InboundSmsTracker paramInboundSmsTracker)
  {
    int i = paramInboundSmsTracker.getMessageCount();
    int j = paramInboundSmsTracker.getDestPort();
    byte[][] arrayOfByte1;
    if (i == 1)
    {
      arrayOfByte1 = new byte[1][];
      arrayOfByte1[0] = paramInboundSmsTracker.getPdu();
    }
    while (true)
    {
      SmsBroadcastReceiver localSmsBroadcastReceiver = new SmsBroadcastReceiver(paramInboundSmsTracker);
      Cursor localCursor;
      boolean bool;
      if (j == 2948)
      {
        ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
        byte[][] arrayOfByte2 = arrayOfByte1;
        int m = arrayOfByte2.length;
        int n = 0;
        while (n < m)
        {
          Object localObject2 = arrayOfByte2[n];
          if (!paramInboundSmsTracker.is3gpp2())
            localObject2 = SmsMessage.createFromPdu((byte[])localObject2, "3gpp").getUserData();
          int i2 = localObject2.length;
          localByteArrayOutputStream.write((byte[])localObject2, 0, i2);
          n++;
          continue;
          localCursor = null;
        }
        while (true)
        {
          try
          {
            String[] arrayOfString = { paramInboundSmsTracker.getAddress(), Integer.toString(paramInboundSmsTracker.getReferenceNumber()), Integer.toString(paramInboundSmsTracker.getMessageCount()) };
            localCursor = this.mResolver.query(sRawUri, PDU_SEQUENCE_PORT_PROJECTION, "address=? AND reference_number=? AND count=?", arrayOfString, null);
            int k = localCursor.getCount();
            if (k < i)
            {
              bool = false;
              return bool;
            }
            arrayOfByte1 = new byte[i][];
            if (!localCursor.moveToNext())
              break;
            int i3 = localCursor.getInt(1) - paramInboundSmsTracker.getIndexOffset();
            arrayOfByte1[i3] = HexDump.hexStringToByteArray(localCursor.getString(0));
            if ((i3 != 0) || (localCursor.isNull(2)))
              continue;
            int i4 = InboundSmsTracker.getRealDestPort(localCursor.getInt(2));
            if (i4 == -1)
              continue;
            j = i4;
            continue;
          }
          catch (SQLException localSQLException)
          {
            loge("Can't access multipart SMS database", localSQLException);
            bool = false;
            if (localCursor == null)
              continue;
            continue;
          }
          finally
          {
            if (localCursor != null)
              localCursor.close();
          }
          int i1 = this.mWapPush.dispatchWapPdu(localByteArrayOutputStream.toByteArray(), localSmsBroadcastReceiver, this);
          log("dispatchWapPdu() returned " + i1);
          if (i1 == -1)
            bool = true;
          else
            bool = false;
        }
      }
      Intent localIntent;
      if (j == -1)
      {
        localIntent = new Intent("android.provider.Telephony.SMS_DELIVER");
        ComponentName localComponentName = SmsApplication.getDefaultSmsApplication(this.mContext, true);
        if (localComponentName != null)
        {
          localIntent.setComponent(localComponentName);
          log("Delivering SMS to: " + localComponentName.getPackageName() + " " + localComponentName.getClassName());
        }
      }
      while (true)
      {
        localIntent.putExtra("pdus", arrayOfByte1);
        String str = paramInboundSmsTracker.getFormat();
        localIntent.putExtra("format", str);
        dispatchIntent(localIntent, "android.permission.RECEIVE_SMS", 16, localSmsBroadcastReceiver);
        bool = true;
        break;
        Uri localUri = Uri.parse("sms://localhost:" + j);
        localIntent = new Intent("android.intent.action.DATA_SMS_RECEIVED", localUri);
      }
      if (localCursor != null)
        localCursor.close();
    }
  }

  public void updatePhoneObject(PhoneBase paramPhoneBase)
  {
    sendMessage(7, paramPhoneBase);
  }

  class DefaultState extends State
  {
    DefaultState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      String str;
      switch (paramMessage.what)
      {
      default:
        str = "processMessage: unhandled message type " + paramMessage.what;
        if (Build.IS_DEBUGGABLE)
          throw new RuntimeException(str);
        break;
      case 7:
        InboundSmsHandler.this.onUpdatePhoneObject((PhoneBase)paramMessage.obj);
      }
      while (true)
      {
        return true;
        InboundSmsHandler.this.loge(str);
      }
    }
  }

  class DeliveringState extends State
  {
    DeliveringState()
    {
    }

    public void enter()
    {
      InboundSmsHandler.this.log("entering Delivering state");
    }

    public void exit()
    {
      InboundSmsHandler.this.log("leaving Delivering state");
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool;
      switch (paramMessage.what)
      {
      case 3:
      default:
        bool = false;
      case 1:
      case 2:
      case 4:
      case 5:
      }
      while (true)
      {
        return bool;
        InboundSmsHandler.this.handleNewSms((AsyncResult)paramMessage.obj);
        InboundSmsHandler.this.sendMessage(4);
        bool = true;
        continue;
        if (InboundSmsHandler.this.processMessagePart((InboundSmsTracker)paramMessage.obj))
          InboundSmsHandler.this.transitionTo(InboundSmsHandler.this.mWaitingState);
        bool = true;
        continue;
        InboundSmsHandler.this.transitionTo(InboundSmsHandler.this.mIdleState);
        bool = true;
        continue;
        InboundSmsHandler.this.mWakeLock.release();
        if (!InboundSmsHandler.this.mWakeLock.isHeld())
          InboundSmsHandler.this.loge("mWakeLock released while delivering/broadcasting!");
        bool = true;
      }
    }
  }

  class IdleState extends State
  {
    IdleState()
    {
    }

    public void enter()
    {
      InboundSmsHandler.this.log("entering Idle state");
      InboundSmsHandler.this.sendMessageDelayed(5, 3000L);
    }

    public void exit()
    {
      InboundSmsHandler.this.mWakeLock.acquire();
      InboundSmsHandler.this.log("acquired wakelock, leaving Idle state");
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool = true;
      InboundSmsHandler.this.log("Idle state processing message type " + paramMessage.what);
      switch (paramMessage.what)
      {
      case 3:
      default:
        bool = false;
      case 4:
      case 1:
      case 2:
      case 5:
      }
      while (true)
      {
        return bool;
        InboundSmsHandler.this.deferMessage(paramMessage);
        InboundSmsHandler.this.transitionTo(InboundSmsHandler.this.mDeliveringState);
        continue;
        InboundSmsHandler.this.mWakeLock.release();
        if (InboundSmsHandler.this.mWakeLock.isHeld())
          InboundSmsHandler.this.log("mWakeLock is still held after release");
        else
          InboundSmsHandler.this.log("mWakeLock released");
      }
    }
  }

  private final class SmsBroadcastReceiver extends BroadcastReceiver
  {
    private long mBroadcastTimeNano;
    private final String mDeleteWhere;
    private final String[] mDeleteWhereArgs;

    SmsBroadcastReceiver(InboundSmsTracker arg2)
    {
      Object localObject;
      this.mDeleteWhere = localObject.getDeleteWhere();
      this.mDeleteWhereArgs = localObject.getDeleteWhereArgs();
      this.mBroadcastTimeNano = System.nanoTime();
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str = paramIntent.getAction();
      if (str.equals("android.provider.Telephony.SMS_DELIVER"))
      {
        paramIntent.setAction("android.provider.Telephony.SMS_RECEIVED");
        paramIntent.setComponent(null);
        InboundSmsHandler.this.dispatchIntent(paramIntent, "android.permission.RECEIVE_SMS", 16, this);
      }
      while (true)
      {
        return;
        if (str.equals("android.provider.Telephony.WAP_PUSH_DELIVER"))
        {
          paramIntent.setAction("android.provider.Telephony.WAP_PUSH_RECEIVED");
          paramIntent.setComponent(null);
          InboundSmsHandler.this.dispatchIntent(paramIntent, "android.permission.RECEIVE_SMS", 16, this);
        }
        else
        {
          if ((!"android.intent.action.DATA_SMS_RECEIVED".equals(str)) && (!"android.intent.action.DATA_SMS_RECEIVED".equals(str)) && (!"android.provider.Telephony.WAP_PUSH_RECEIVED".equals(str)))
            InboundSmsHandler.this.loge("unexpected BroadcastReceiver action: " + str);
          int i = getResultCode();
          if ((i != -1) && (i != 1))
            InboundSmsHandler.this.loge("a broadcast receiver set the result code to " + i + ", deleting from raw table anyway!");
          int j;
          while (true)
          {
            InboundSmsHandler.this.deleteFromRawTable(this.mDeleteWhere, this.mDeleteWhereArgs);
            InboundSmsHandler.this.sendMessage(3);
            j = (int)((System.nanoTime() - this.mBroadcastTimeNano) / 1000000L);
            if (j < 5000)
              break label275;
            InboundSmsHandler.this.loge("Slow ordered broadcast completion time: " + j + " ms");
            break;
            InboundSmsHandler.this.log("successful broadcast, deleting from raw table.");
          }
          label275: InboundSmsHandler.this.log("ordered broadcast completed in: " + j + " ms");
        }
      }
    }
  }

  class StartupState extends State
  {
    StartupState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool = true;
      switch (paramMessage.what)
      {
      case 3:
      case 4:
      case 5:
      default:
        bool = false;
      case 1:
      case 2:
      case 6:
      }
      while (true)
      {
        return bool;
        InboundSmsHandler.this.deferMessage(paramMessage);
        continue;
        InboundSmsHandler.this.transitionTo(InboundSmsHandler.this.mIdleState);
      }
    }
  }

  class WaitingState extends State
  {
    WaitingState()
    {
    }

    public boolean processMessage(Message paramMessage)
    {
      boolean bool = true;
      switch (paramMessage.what)
      {
      default:
        bool = false;
      case 4:
      case 2:
      case 3:
      }
      while (true)
      {
        return bool;
        InboundSmsHandler.this.deferMessage(paramMessage);
        continue;
        InboundSmsHandler.this.sendMessage(4);
        InboundSmsHandler.this.transitionTo(InboundSmsHandler.this.mDeliveringState);
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.InboundSmsHandler
 * JD-Core Version:    0.6.2
 */