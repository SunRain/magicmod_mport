package com.android.internal.telephony;

import android.content.Context;
import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemClock;
import android.telephony.CellInfo;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.util.Pair;
import android.util.TimeUtils;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class ServiceStateTracker extends Handler
{
  protected static final boolean DBG = true;
  public static final int DEFAULT_GPRS_CHECK_PERIOD_MILLIS = 60000;
  protected static final int EVENT_CDMA_PRL_VERSION_CHANGED = 40;
  protected static final int EVENT_CDMA_SUBSCRIPTION_SOURCE_CHANGED = 39;
  protected static final int EVENT_CHECK_REPORT_GPRS = 22;
  protected static final int EVENT_ERI_FILE_LOADED = 36;
  protected static final int EVENT_GET_CELL_INFO_LIST = 43;
  protected static final int EVENT_GET_LOC_DONE = 15;
  protected static final int EVENT_GET_LOC_DONE_CDMA = 31;
  protected static final int EVENT_GET_PREFERRED_NETWORK_TYPE = 19;
  protected static final int EVENT_GET_SIGNAL_STRENGTH = 3;
  protected static final int EVENT_GET_SIGNAL_STRENGTH_CDMA = 29;
  protected static final int EVENT_ICC_CHANGED = 42;
  protected static final int EVENT_LOCATION_UPDATES_ENABLED = 18;
  protected static final int EVENT_NETWORK_STATE_CHANGED = 2;
  protected static final int EVENT_NETWORK_STATE_CHANGED_CDMA = 30;
  protected static final int EVENT_NITZ_TIME = 11;
  protected static final int EVENT_NV_LOADED = 33;
  protected static final int EVENT_NV_READY = 35;
  protected static final int EVENT_OTA_PROVISION_STATUS_CHANGE = 37;
  protected static final int EVENT_POLL_SIGNAL_STRENGTH = 10;
  protected static final int EVENT_POLL_SIGNAL_STRENGTH_CDMA = 28;
  protected static final int EVENT_POLL_STATE_CDMA_SUBSCRIPTION = 34;
  protected static final int EVENT_POLL_STATE_GPRS = 5;
  protected static final int EVENT_POLL_STATE_NETWORK_SELECTION_MODE = 14;
  protected static final int EVENT_POLL_STATE_OPERATOR = 6;
  protected static final int EVENT_POLL_STATE_OPERATOR_CDMA = 25;
  protected static final int EVENT_POLL_STATE_REGISTRATION = 4;
  protected static final int EVENT_POLL_STATE_REGISTRATION_CDMA = 24;
  protected static final int EVENT_RADIO_AVAILABLE = 13;
  protected static final int EVENT_RADIO_ON = 41;
  protected static final int EVENT_RADIO_STATE_CHANGED = 1;
  protected static final int EVENT_RESET_PREFERRED_NETWORK_TYPE = 21;
  protected static final int EVENT_RESTRICTED_STATE_CHANGED = 23;
  protected static final int EVENT_RUIM_READY = 26;
  protected static final int EVENT_RUIM_RECORDS_LOADED = 27;
  protected static final int EVENT_SET_PREFERRED_NETWORK_TYPE = 20;
  protected static final int EVENT_SET_RADIO_POWER_OFF = 38;
  protected static final int EVENT_SIGNAL_STRENGTH_UPDATE = 12;
  protected static final int EVENT_SIM_READY = 17;
  protected static final int EVENT_SIM_RECORDS_LOADED = 16;
  protected static final int EVENT_UNSOL_CELL_INFO_LIST = 44;
  protected static final String[] GMT_COUNTRY_CODES = { "bf", "ci", "eh", "fo", "gb", "gh", "gm", "gn", "gw", "ie", "lr", "is", "ma", "ml", "mr", "pt", "sl", "sn", "st", "tg" };
  private static final long LAST_CELL_INFO_LIST_MAX_AGE_MS = 2000L;
  public static final int OTASP_NEEDED = 2;
  public static final int OTASP_NOT_NEEDED = 3;
  public static final int OTASP_UNINITIALIZED = 0;
  public static final int OTASP_UNKNOWN = 1;
  protected static final int POLL_PERIOD_MILLIS = 20000;
  protected static final String PROP_FORCE_ROAMING = "telephony.test.forceRoaming";
  protected static final String REGISTRATION_DENIED_AUTH = "Authentication Failure";
  protected static final String REGISTRATION_DENIED_GEN = "General";
  protected static final String TIMEZONE_PROPERTY = "persist.sys.timezone";
  protected static final boolean VDBG;
  protected RegistrantList mAttachedRegistrants = new RegistrantList();
  protected final CellInfo mCellInfo;
  protected CommandsInterface mCi;
  protected RegistrantList mDataRegStateOrRatChangedRegistrants = new RegistrantList();
  protected boolean mDesiredPowerState;
  protected RegistrantList mDetachedRegistrants = new RegistrantList();
  protected boolean mDontPollSignalStrength = false;
  protected IccRecords mIccRecords = null;
  protected List<CellInfo> mLastCellInfoList = null;
  protected long mLastCellInfoListTime;
  private SignalStrength mLastSignalStrength = null;
  protected RegistrantList mNetworkAttachedRegistrants = new RegistrantList();
  protected ServiceState mNewSS = new ServiceState();
  private boolean mPendingRadioPowerOffAfterDataOff = false;
  private int mPendingRadioPowerOffAfterDataOffTag = 0;
  protected PhoneBase mPhoneBase;
  protected int[] mPollingContext;
  protected RegistrantList mPsRestrictDisabledRegistrants = new RegistrantList();
  protected RegistrantList mPsRestrictEnabledRegistrants = new RegistrantList();
  public RestrictedState mRestrictedState = new RestrictedState();
  protected RegistrantList mRoamingOffRegistrants = new RegistrantList();
  protected RegistrantList mRoamingOnRegistrants = new RegistrantList();
  public ServiceState mSS = new ServiceState();
  protected SignalStrength mSignalStrength = new SignalStrength();
  protected UiccCardApplication mUiccApplcation = null;
  protected UiccController mUiccController = null;
  protected boolean mVoiceCapable;
  private boolean mWantContinuousLocationUpdates;
  private boolean mWantSingleLocationUpdate;

  protected ServiceStateTracker(PhoneBase paramPhoneBase, CommandsInterface paramCommandsInterface, CellInfo paramCellInfo)
  {
    this.mPhoneBase = paramPhoneBase;
    this.mCellInfo = paramCellInfo;
    this.mCi = paramCommandsInterface;
    this.mVoiceCapable = this.mPhoneBase.getContext().getResources().getBoolean(17891385);
    this.mUiccController = UiccController.getInstance();
    this.mUiccController.registerForIccChanged(this, 42, null);
    this.mCi.setOnSignalStrengthUpdate(this, 12, null);
    this.mCi.registerForCellInfoList(this, 44, null);
    this.mPhoneBase.setSystemProperty("gsm.network.type", ServiceState.rilRadioTechnologyToString(0));
  }

  protected void cancelPollState()
  {
    this.mPollingContext = new int[1];
  }

  protected void checkCorrectThread()
  {
    if (Thread.currentThread() != getLooper().getThread())
      throw new RuntimeException("ServiceStateTracker must be used from within one thread");
  }

  public void disableLocationUpdates()
  {
    this.mWantContinuousLocationUpdates = false;
    if ((!this.mWantSingleLocationUpdate) && (!this.mWantContinuousLocationUpdates))
      this.mCi.setLocationUpdates(false, null);
  }

  protected void disableSingleLocationUpdate()
  {
    this.mWantSingleLocationUpdate = false;
    if ((!this.mWantSingleLocationUpdate) && (!this.mWantContinuousLocationUpdates))
      this.mCi.setLocationUpdates(false, null);
  }

  public void dispose()
  {
    this.mCi.unSetOnSignalStrengthUpdate(this);
    this.mUiccController.unregisterForIccChanged(this);
    this.mCi.unregisterForCellInfoList(this);
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("ServiceStateTracker:");
    paramPrintWriter.println(" mSS=" + this.mSS);
    paramPrintWriter.println(" mNewSS=" + this.mNewSS);
    paramPrintWriter.println(" mCellInfo=" + this.mCellInfo);
    paramPrintWriter.println(" mRestrictedState=" + this.mRestrictedState);
    paramPrintWriter.println(" mPollingContext=" + this.mPollingContext);
    paramPrintWriter.println(" mDesiredPowerState=" + this.mDesiredPowerState);
    paramPrintWriter.println(" mDontPollSignalStrength=" + this.mDontPollSignalStrength);
    paramPrintWriter.println(" mPendingRadioPowerOffAfterDataOff=" + this.mPendingRadioPowerOffAfterDataOff);
    paramPrintWriter.println(" mPendingRadioPowerOffAfterDataOffTag=" + this.mPendingRadioPowerOffAfterDataOffTag);
  }

  public void enableLocationUpdates()
  {
    if ((this.mWantSingleLocationUpdate) || (this.mWantContinuousLocationUpdates));
    while (true)
    {
      return;
      this.mWantContinuousLocationUpdates = true;
      this.mCi.setLocationUpdates(true, obtainMessage(18));
    }
  }

  public void enableSingleLocationUpdate()
  {
    if ((this.mWantSingleLocationUpdate) || (this.mWantContinuousLocationUpdates));
    while (true)
    {
      return;
      this.mWantSingleLocationUpdate = true;
      this.mCi.setLocationUpdates(true, obtainMessage(18));
    }
  }

  public List<CellInfo> getAllCellInfo()
  {
    CellInfoResult localCellInfoResult = new CellInfoResult(null);
    Message localMessage;
    if (this.mCi.getRilVersion() >= 8)
      if (isCallerOnDifferentThread())
        if (SystemClock.elapsedRealtime() - this.mLastCellInfoListTime > 2000L)
          localMessage = obtainMessage(43, localCellInfoResult);
    while (true)
    {
      synchronized (localCellInfoResult.lockObj)
      {
        this.mCi.getCellInfoList(localMessage);
        try
        {
          localCellInfoResult.lockObj.wait();
          if (localCellInfoResult.list == null)
            break label210;
          log("SST.getAllCellInfo(): X size=" + localCellInfoResult.list.size() + " list=" + localCellInfoResult.list);
          return localCellInfoResult.list;
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
          localCellInfoResult.list = null;
          continue;
        }
      }
      log("SST.getAllCellInfo(): return last, back to back calls");
      localCellInfoResult.list = this.mLastCellInfoList;
      continue;
      log("SST.getAllCellInfo(): return last, same thread can't block");
      localCellInfoResult.list = this.mLastCellInfoList;
      continue;
      log("SST.getAllCellInfo(): not implemented");
      localCellInfoResult.list = null;
      continue;
      label210: log("SST.getAllCellInfo(): X size=0 list=null");
    }
  }

  public abstract int getCurrentDataConnectionState();

  public boolean getDesiredPowerState()
  {
    return this.mDesiredPowerState;
  }

  protected abstract Phone getPhone();

  public SignalStrength getSignalStrength()
  {
    synchronized (this.mCellInfo)
    {
      SignalStrength localSignalStrength = this.mSignalStrength;
      return localSignalStrength;
    }
  }

  // ERROR //
  public void handleMessage(Message paramMessage)
  {
    // Byte code:
    //   0: aload_1
    //   1: getfield 496	android/os/Message:what	I
    //   4: tableswitch	default:+44 -> 48, 38:+72->76, 39:+44->48, 40:+44->48, 41:+44->48, 42:+173->177, 43:+180->184, 44:+305->309
    //   49: new 373	java/lang/StringBuilder
    //   52: dup
    //   53: invokespecial 374	java/lang/StringBuilder:<init>	()V
    //   56: ldc_w 498
    //   59: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: aload_1
    //   63: getfield 496	android/os/Message:what	I
    //   66: invokevirtual 411	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   69: invokevirtual 387	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   72: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   75: return
    //   76: aload_0
    //   77: monitorenter
    //   78: aload_0
    //   79: getfield 256	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOff	Z
    //   82: ifeq +52 -> 134
    //   85: aload_1
    //   86: getfield 501	android/os/Message:arg1	I
    //   89: aload_0
    //   90: getfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   93: if_icmpne +41 -> 134
    //   96: aload_0
    //   97: ldc_w 503
    //   100: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   103: aload_0
    //   104: invokevirtual 506	com/android/internal/telephony/ServiceStateTracker:hangupAndPowerOff	()V
    //   107: aload_0
    //   108: iconst_1
    //   109: aload_0
    //   110: getfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   113: iadd
    //   114: putfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   117: aload_0
    //   118: iconst_0
    //   119: putfield 256	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOff	Z
    //   122: aload_0
    //   123: monitorexit
    //   124: goto -49 -> 75
    //   127: astore 8
    //   129: aload_0
    //   130: monitorexit
    //   131: aload 8
    //   133: athrow
    //   134: aload_0
    //   135: new 373	java/lang/StringBuilder
    //   138: dup
    //   139: invokespecial 374	java/lang/StringBuilder:<init>	()V
    //   142: ldc_w 508
    //   145: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: aload_1
    //   149: getfield 501	android/os/Message:arg1	I
    //   152: invokevirtual 411	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   155: ldc_w 510
    //   158: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: aload_0
    //   162: getfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   165: invokevirtual 411	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   168: invokevirtual 387	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   171: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   174: goto -52 -> 122
    //   177: aload_0
    //   178: invokevirtual 513	com/android/internal/telephony/ServiceStateTracker:onUpdateIccAvailability	()V
    //   181: goto -106 -> 75
    //   184: aload_1
    //   185: getfield 516	android/os/Message:obj	Ljava/lang/Object;
    //   188: checkcast 518	android/os/AsyncResult
    //   191: astore 4
    //   193: aload 4
    //   195: getfield 521	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   198: checkcast 423	com/android/internal/telephony/ServiceStateTracker$CellInfoResult
    //   201: astore 5
    //   203: aload 5
    //   205: getfield 449	com/android/internal/telephony/ServiceStateTracker$CellInfoResult:lockObj	Ljava/lang/Object;
    //   208: astore 6
    //   210: aload 6
    //   212: monitorenter
    //   213: aload 4
    //   215: getfield 525	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   218: ifnull +75 -> 293
    //   221: aload_0
    //   222: new 373	java/lang/StringBuilder
    //   225: dup
    //   226: invokespecial 374	java/lang/StringBuilder:<init>	()V
    //   229: ldc_w 527
    //   232: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: aload 4
    //   237: getfield 525	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   240: invokevirtual 383	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   243: invokevirtual 387	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   246: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   249: aload 5
    //   251: aconst_null
    //   252: putfield 461	com/android/internal/telephony/ServiceStateTracker$CellInfoResult:list	Ljava/util/List;
    //   255: aload_0
    //   256: invokestatic 440	android/os/SystemClock:elapsedRealtime	()J
    //   259: putfield 442	com/android/internal/telephony/ServiceStateTracker:mLastCellInfoListTime	J
    //   262: aload_0
    //   263: aload 5
    //   265: getfield 461	com/android/internal/telephony/ServiceStateTracker$CellInfoResult:list	Ljava/util/List;
    //   268: putfield 223	com/android/internal/telephony/ServiceStateTracker:mLastCellInfoList	Ljava/util/List;
    //   271: aload 5
    //   273: getfield 449	com/android/internal/telephony/ServiceStateTracker$CellInfoResult:lockObj	Ljava/lang/Object;
    //   276: invokevirtual 530	java/lang/Object:notify	()V
    //   279: aload 6
    //   281: monitorexit
    //   282: goto -207 -> 75
    //   285: astore 7
    //   287: aload 6
    //   289: monitorexit
    //   290: aload 7
    //   292: athrow
    //   293: aload 5
    //   295: aload 4
    //   297: getfield 533	android/os/AsyncResult:result	Ljava/lang/Object;
    //   300: checkcast 465	java/util/List
    //   303: putfield 461	com/android/internal/telephony/ServiceStateTracker$CellInfoResult:list	Ljava/util/List;
    //   306: goto -51 -> 255
    //   309: aload_1
    //   310: getfield 516	android/os/Message:obj	Ljava/lang/Object;
    //   313: checkcast 518	android/os/AsyncResult
    //   316: astore_2
    //   317: aload_2
    //   318: getfield 525	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   321: ifnull +33 -> 354
    //   324: aload_0
    //   325: new 373	java/lang/StringBuilder
    //   328: dup
    //   329: invokespecial 374	java/lang/StringBuilder:<init>	()V
    //   332: ldc_w 535
    //   335: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   338: aload_2
    //   339: getfield 525	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   342: invokevirtual 383	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   345: invokevirtual 387	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   348: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   351: goto -276 -> 75
    //   354: aload_2
    //   355: getfield 533	android/os/AsyncResult:result	Ljava/lang/Object;
    //   358: checkcast 465	java/util/List
    //   361: astore_3
    //   362: aload_0
    //   363: new 373	java/lang/StringBuilder
    //   366: dup
    //   367: invokespecial 374	java/lang/StringBuilder:<init>	()V
    //   370: ldc_w 537
    //   373: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: aload_3
    //   377: invokeinterface 468 1 0
    //   382: invokevirtual 411	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   385: ldc_w 470
    //   388: invokevirtual 380	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: aload_3
    //   392: invokevirtual 383	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   395: invokevirtual 387	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   398: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   401: aload_0
    //   402: invokestatic 440	android/os/SystemClock:elapsedRealtime	()J
    //   405: putfield 442	com/android/internal/telephony/ServiceStateTracker:mLastCellInfoListTime	J
    //   408: aload_0
    //   409: aload_3
    //   410: putfield 223	com/android/internal/telephony/ServiceStateTracker:mLastCellInfoList	Ljava/util/List;
    //   413: aload_0
    //   414: getfield 262	com/android/internal/telephony/ServiceStateTracker:mPhoneBase	Lcom/android/internal/telephony/PhoneBase;
    //   417: aload_3
    //   418: invokevirtual 541	com/android/internal/telephony/PhoneBase:notifyCellInfo	(Ljava/util/List;)V
    //   421: goto -346 -> 75
    //
    // Exception table:
    //   from	to	target	type
    //   78	131	127	finally
    //   134	174	127	finally
    //   213	290	285	finally
    //   293	306	285	finally
  }

  protected abstract void handlePollStateResult(int paramInt, AsyncResult paramAsyncResult);

  protected abstract void hangupAndPowerOff();

  protected boolean isCallerOnDifferentThread()
  {
    if (Thread.currentThread() != getLooper().getThread());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public abstract boolean isConcurrentVoiceAndDataAllowed();

  protected abstract void log(String paramString);

  protected abstract void loge(String paramString);

  protected void notifyDataRegStateRilRadioTechnologyChanged()
  {
    int i = this.mSS.getRilDataRadioTechnology();
    int j = this.mSS.getDataRegState();
    log("notifyDataRegStateRilRadioTechnologyChanged: drs=" + j + " rat=" + i);
    this.mPhoneBase.setSystemProperty("gsm.network.type", ServiceState.rilRadioTechnologyToString(i));
    this.mDataRegStateOrRatChangedRegistrants.notifyResult(new Pair(Integer.valueOf(j), Integer.valueOf(i)));
  }

  protected boolean notifySignalStrength()
  {
    boolean bool1 = false;
    synchronized (this.mCellInfo)
    {
      boolean bool2 = this.mSignalStrength.equals(this.mLastSignalStrength);
      if (!bool2);
      try
      {
        this.mPhoneBase.notifySignalStrength();
        bool1 = true;
        return bool1;
      }
      catch (NullPointerException localNullPointerException)
      {
        while (true)
          loge("updateSignalStrength() Phone already destroyed: " + localNullPointerException + "SignalStrength not notified");
      }
    }
  }

  protected boolean onSignalStrengthResult(AsyncResult paramAsyncResult, boolean paramBoolean)
  {
    if ((paramAsyncResult.exception == null) && (paramAsyncResult.result != null))
    {
      this.mSignalStrength = ((SignalStrength)paramAsyncResult.result);
      this.mSignalStrength.validateInput();
      this.mSignalStrength.setGsm(paramBoolean);
    }
    while (true)
    {
      return notifySignalStrength();
      log("onSignalStrengthResult() Exception from RIL : " + paramAsyncResult.exception);
      this.mSignalStrength = new SignalStrength(paramBoolean);
    }
  }

  protected abstract void onUpdateIccAvailability();

  // ERROR //
  public void powerOffRadioSafely(com.android.internal.telephony.dataconnection.DcTrackerBase paramDcTrackerBase)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 256	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOff	Z
    //   6: ifne +28 -> 34
    //   9: aload_1
    //   10: invokevirtual 608	com/android/internal/telephony/dataconnection/DcTrackerBase:isDisconnected	()Z
    //   13: ifeq +24 -> 37
    //   16: aload_1
    //   17: ldc_w 610
    //   20: invokevirtual 613	com/android/internal/telephony/dataconnection/DcTrackerBase:cleanUpAllConnections	(Ljava/lang/String;)V
    //   23: aload_0
    //   24: ldc_w 615
    //   27: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   30: aload_0
    //   31: invokevirtual 506	com/android/internal/telephony/ServiceStateTracker:hangupAndPowerOff	()V
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: aload_1
    //   38: ldc_w 610
    //   41: invokevirtual 613	com/android/internal/telephony/dataconnection/DcTrackerBase:cleanUpAllConnections	(Ljava/lang/String;)V
    //   44: aload_0
    //   45: invokestatic 619	android/os/Message:obtain	(Landroid/os/Handler;)Landroid/os/Message;
    //   48: astore_3
    //   49: aload_3
    //   50: bipush 38
    //   52: putfield 496	android/os/Message:what	I
    //   55: iconst_1
    //   56: aload_0
    //   57: getfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   60: iadd
    //   61: istore 4
    //   63: aload_0
    //   64: iload 4
    //   66: putfield 258	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOffTag	I
    //   69: aload_3
    //   70: iload 4
    //   72: putfield 501	android/os/Message:arg1	I
    //   75: aload_0
    //   76: aload_3
    //   77: ldc2_w 620
    //   80: invokevirtual 625	com/android/internal/telephony/ServiceStateTracker:sendMessageDelayed	(Landroid/os/Message;J)Z
    //   83: ifeq +23 -> 106
    //   86: aload_0
    //   87: ldc_w 627
    //   90: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   93: aload_0
    //   94: iconst_1
    //   95: putfield 256	com/android/internal/telephony/ServiceStateTracker:mPendingRadioPowerOffAfterDataOff	Z
    //   98: goto -64 -> 34
    //   101: astore_2
    //   102: aload_0
    //   103: monitorexit
    //   104: aload_2
    //   105: athrow
    //   106: aload_0
    //   107: ldc_w 629
    //   110: invokevirtual 473	com/android/internal/telephony/ServiceStateTracker:log	(Ljava/lang/String;)V
    //   113: aload_0
    //   114: invokevirtual 506	com/android/internal/telephony/ServiceStateTracker:hangupAndPowerOff	()V
    //   117: goto -83 -> 34
    //
    // Exception table:
    //   from	to	target	type
    //   2	104	101	finally
    //   106	117	101	finally
  }

  public boolean processPendingRadioPowerOffAfterDataOff()
  {
    boolean bool = false;
    try
    {
      if (this.mPendingRadioPowerOffAfterDataOff)
      {
        log("Process pending request to turn radio off.");
        this.mPendingRadioPowerOffAfterDataOffTag = (1 + this.mPendingRadioPowerOffAfterDataOffTag);
        hangupAndPowerOff();
        this.mPendingRadioPowerOffAfterDataOff = false;
        bool = true;
      }
      else;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
    return bool;
  }

  public void reRegisterNetwork(Message paramMessage)
  {
    this.mCi.getPreferredNetworkType(obtainMessage(19, paramMessage));
  }

  public void registerForDataConnectionAttached(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mAttachedRegistrants.add(localRegistrant);
    if (getCurrentDataConnectionState() == 0)
      localRegistrant.notifyRegistrant();
  }

  public void registerForDataConnectionDetached(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mDetachedRegistrants.add(localRegistrant);
    if (getCurrentDataConnectionState() != 0)
      localRegistrant.notifyRegistrant();
  }

  public void registerForDataRegStateOrRatChanged(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mDataRegStateOrRatChangedRegistrants.add(localRegistrant);
    notifyDataRegStateRilRadioTechnologyChanged();
  }

  public void registerForNetworkAttached(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mNetworkAttachedRegistrants.add(localRegistrant);
    if (this.mSS.getVoiceRegState() == 0)
      localRegistrant.notifyRegistrant();
  }

  public void registerForPsRestrictedDisabled(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mPsRestrictDisabledRegistrants.add(localRegistrant);
    if (this.mRestrictedState.isPsRestricted())
      localRegistrant.notifyRegistrant();
  }

  public void registerForPsRestrictedEnabled(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mPsRestrictEnabledRegistrants.add(localRegistrant);
    if (this.mRestrictedState.isPsRestricted())
      localRegistrant.notifyRegistrant();
  }

  public void registerForRoamingOff(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mRoamingOffRegistrants.add(localRegistrant);
    if (!this.mSS.getRoaming())
      localRegistrant.notifyRegistrant();
  }

  public void registerForRoamingOn(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mRoamingOnRegistrants.add(localRegistrant);
    if (this.mSS.getRoaming())
      localRegistrant.notifyRegistrant();
  }

  protected abstract void setPowerStateToDesired();

  public void setRadioPower(boolean paramBoolean)
  {
    this.mDesiredPowerState = paramBoolean;
    setPowerStateToDesired();
  }

  protected boolean shouldFixTimeZoneNow(PhoneBase paramPhoneBase, String paramString1, String paramString2, boolean paramBoolean)
  {
    try
    {
      i = Integer.parseInt(paramString1.substring(0, 3));
    }
    catch (Exception localException1)
    {
      try
      {
        int k = Integer.parseInt(paramString2.substring(0, 3));
        j = k;
        bool2 = false;
        if (this.mUiccApplcation != null)
        {
          if (this.mUiccApplcation.getState() != IccCardApplicationStatus.AppState.APPSTATE_UNKNOWN)
            bool2 = true;
        }
        else
        {
          if (((!bool2) || (i == j)) && (!paramBoolean))
            break label238;
          bool1 = true;
          long l = System.currentTimeMillis();
          log("shouldFixTimeZoneNow: retVal=" + bool1 + " iccCardExist=" + bool2 + " operatorNumeric=" + paramString1 + " mcc=" + i + " prevOperatorNumeric=" + paramString2 + " prevMcc=" + j + " needToFixTimeZone=" + paramBoolean + " ltod=" + TimeUtils.logTimeOfDay(l));
          while (true)
          {
            return bool1;
            localException1 = localException1;
            log("shouldFixTimeZoneNow: no mcc, operatorNumeric=" + paramString1 + " retVal=false");
            bool1 = false;
          }
        }
      }
      catch (Exception localException2)
      {
        while (true)
        {
          int i;
          int j = i + 1;
          continue;
          boolean bool2 = false;
          continue;
          label238: boolean bool1 = false;
        }
      }
    }
  }

  public void unregisterForDataConnectionAttached(Handler paramHandler)
  {
    this.mAttachedRegistrants.remove(paramHandler);
  }

  public void unregisterForDataConnectionDetached(Handler paramHandler)
  {
    this.mDetachedRegistrants.remove(paramHandler);
  }

  public void unregisterForDataRegStateOrRatChanged(Handler paramHandler)
  {
    this.mDataRegStateOrRatChangedRegistrants.remove(paramHandler);
  }

  public void unregisterForNetworkAttached(Handler paramHandler)
  {
    this.mNetworkAttachedRegistrants.remove(paramHandler);
  }

  public void unregisterForPsRestrictedDisabled(Handler paramHandler)
  {
    this.mPsRestrictDisabledRegistrants.remove(paramHandler);
  }

  public void unregisterForPsRestrictedEnabled(Handler paramHandler)
  {
    this.mPsRestrictEnabledRegistrants.remove(paramHandler);
  }

  public void unregisterForRoamingOff(Handler paramHandler)
  {
    this.mRoamingOffRegistrants.remove(paramHandler);
  }

  public void unregisterForRoamingOn(Handler paramHandler)
  {
    this.mRoamingOnRegistrants.remove(paramHandler);
  }

  protected void updatePhoneObject()
  {
    this.mPhoneBase.updatePhoneObject(this.mSS.getRilVoiceRadioTechnology());
  }

  protected abstract void updateSpnDisplay();

  protected void useDataRegStateForDataOnlyDevices()
  {
    if (!this.mVoiceCapable)
    {
      log("useDataRegStateForDataOnlyDevice: VoiceRegState=" + this.mNewSS.getVoiceRegState() + " DataRegState=" + this.mNewSS.getDataRegState());
      this.mNewSS.setVoiceRegState(this.mNewSS.getDataRegState());
    }
  }

  private class CellInfoResult
  {
    List<CellInfo> list;
    Object lockObj = new Object();

    private CellInfoResult()
    {
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.ServiceStateTracker
 * JD-Core Version:    0.6.2
 */