package com.android.internal.telephony;

import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.os.AsyncResult;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.cdma.CdmaInboundSmsHandler;
import com.android.internal.telephony.cdma.CdmaSMSDispatcher;
import com.android.internal.telephony.gsm.GsmInboundSmsHandler;
import com.android.internal.telephony.gsm.GsmSMSDispatcher;
import java.util.ArrayList;
import java.util.HashMap;

public final class ImsSMSDispatcher extends SMSDispatcher
{
  private static final String TAG = "RIL_ImsSms";
  private SMSDispatcher mCdmaDispatcher;
  private CdmaInboundSmsHandler mCdmaInboundSmsHandler;
  private SMSDispatcher mGsmDispatcher;
  private GsmInboundSmsHandler mGsmInboundSmsHandler;
  private boolean mIms = false;
  private String mImsSmsFormat = "unknown";

  public ImsSMSDispatcher(PhoneBase paramPhoneBase, SmsStorageMonitor paramSmsStorageMonitor, SmsUsageMonitor paramSmsUsageMonitor)
  {
    super(paramPhoneBase, paramSmsUsageMonitor, null);
    Rlog.d("RIL_ImsSms", "ImsSMSDispatcher created");
    this.mCdmaDispatcher = new CdmaSMSDispatcher(paramPhoneBase, paramSmsUsageMonitor, this);
    this.mGsmInboundSmsHandler = GsmInboundSmsHandler.makeInboundSmsHandler(paramPhoneBase.getContext(), paramSmsStorageMonitor, paramPhoneBase);
    this.mCdmaInboundSmsHandler = CdmaInboundSmsHandler.makeInboundSmsHandler(paramPhoneBase.getContext(), paramSmsStorageMonitor, paramPhoneBase, (CdmaSMSDispatcher)this.mCdmaDispatcher);
    this.mGsmDispatcher = new GsmSMSDispatcher(paramPhoneBase, paramSmsUsageMonitor, this, this.mGsmInboundSmsHandler);
    new Thread(new SmsBroadcastUndelivered(paramPhoneBase.getContext(), this.mGsmInboundSmsHandler, this.mCdmaInboundSmsHandler)).start();
    this.mCi.registerForOn(this, 11, null);
    this.mCi.registerForImsNetworkStateChanged(this, 12, null);
  }

  private boolean isCdmaFormat(String paramString)
  {
    return this.mCdmaDispatcher.getFormat().equals(paramString);
  }

  private boolean isCdmaMo()
  {
    boolean bool;
    if (!isIms())
      if (2 == this.mPhone.getPhoneType())
        bool = true;
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = isCdmaFormat(this.mImsSmsFormat);
    }
  }

  private void setImsSmsFormat(int paramInt)
  {
    switch (paramInt)
    {
    default:
      this.mImsSmsFormat = "unknown";
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      this.mImsSmsFormat = "3gpp";
      continue;
      this.mImsSmsFormat = "3gpp2";
    }
  }

  private void updateImsInfo(AsyncResult paramAsyncResult)
  {
    int[] arrayOfInt = (int[])paramAsyncResult.result;
    this.mIms = false;
    if (arrayOfInt[0] == 1)
    {
      Rlog.d("RIL_ImsSms", "IMS is registered!");
      this.mIms = true;
    }
    while (true)
    {
      setImsSmsFormat(arrayOfInt[1]);
      if ("unknown".equals(this.mImsSmsFormat))
      {
        Rlog.e("RIL_ImsSms", "IMS format was unknown!");
        this.mIms = false;
      }
      return;
      Rlog.d("RIL_ImsSms", "IMS is NOT registered!");
    }
  }

  protected GsmAlphabet.TextEncodingDetails calculateLength(CharSequence paramCharSequence, boolean paramBoolean)
  {
    Rlog.e("RIL_ImsSms", "Error! Not implemented for IMS.");
    return null;
  }

  public void dispose()
  {
    this.mCi.unregisterForOn(this);
    this.mCi.unregisterForImsNetworkStateChanged(this);
    this.mGsmDispatcher.dispose();
    this.mCdmaDispatcher.dispose();
    this.mGsmInboundSmsHandler.dispose();
    this.mCdmaInboundSmsHandler.dispose();
  }

  protected String getFormat()
  {
    Rlog.e("RIL_ImsSms", "getFormat should never be called from here!");
    return "unknown";
  }

  public String getImsSmsFormat()
  {
    return this.mImsSmsFormat;
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 11:
    case 12:
    case 13:
    }
    while (true)
    {
      return;
      this.mCi.getImsRegistrationState(obtainMessage(13));
      continue;
      AsyncResult localAsyncResult = (AsyncResult)paramMessage.obj;
      if (localAsyncResult.exception == null)
        updateImsInfo(localAsyncResult);
      else
        Rlog.e("RIL_ImsSms", "IMS State query failed with exp " + localAsyncResult.exception);
    }
  }

  public boolean isIms()
  {
    return this.mIms;
  }

  protected void sendData(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfByte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    if (isCdmaMo())
      this.mCdmaDispatcher.sendData(paramString1, paramString2, paramInt, paramArrayOfByte, paramPendingIntent1, paramPendingIntent2);
    while (true)
    {
      return;
      this.mGsmDispatcher.sendData(paramString1, paramString2, paramInt, paramArrayOfByte, paramPendingIntent1, paramPendingIntent2);
    }
  }

  protected void sendMultipartText(String paramString1, String paramString2, ArrayList<String> paramArrayList, ArrayList<PendingIntent> paramArrayList1, ArrayList<PendingIntent> paramArrayList2)
  {
    if (isCdmaMo())
      this.mCdmaDispatcher.sendMultipartText(paramString1, paramString2, paramArrayList, paramArrayList1, paramArrayList2);
    while (true)
    {
      return;
      this.mGsmDispatcher.sendMultipartText(paramString1, paramString2, paramArrayList, paramArrayList1, paramArrayList2);
    }
  }

  protected void sendNewSubmitPdu(String paramString1, String paramString2, String paramString3, SmsHeader paramSmsHeader, int paramInt, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, boolean paramBoolean)
  {
    Rlog.e("RIL_ImsSms", "Error! Not implemented for IMS.");
  }

  public void sendRetrySms(SMSDispatcher.SmsTracker paramSmsTracker)
  {
    String str1 = paramSmsTracker.mFormat;
    String str2;
    if (2 == this.mPhone.getPhoneType())
    {
      str2 = this.mCdmaDispatcher.getFormat();
      if (!str1.equals(str2))
        break label87;
      if (!isCdmaFormat(str2))
        break label68;
      Rlog.d("RIL_ImsSms", "old format matched new format (cdma)");
      this.mCdmaDispatcher.sendSms(paramSmsTracker);
    }
    label68: label87: HashMap localHashMap;
    while (true)
    {
      return;
      str2 = this.mGsmDispatcher.getFormat();
      break;
      Rlog.d("RIL_ImsSms", "old format matched new format (gsm)");
      this.mGsmDispatcher.sendSms(paramSmsTracker);
      continue;
      localHashMap = paramSmsTracker.mData;
      if ((localHashMap.containsKey("scAddr")) && (localHashMap.containsKey("destAddr")) && ((localHashMap.containsKey("text")) || ((localHashMap.containsKey("data")) && (localHashMap.containsKey("destPort")))))
        break label182;
      Rlog.e("RIL_ImsSms", "sendRetrySms failed to re-encode per missing fields!");
      if (paramSmsTracker.mSentIntent != null)
        try
        {
          paramSmsTracker.mSentIntent.send(this.mContext, 1, null);
        }
        catch (PendingIntent.CanceledException localCanceledException)
        {
        }
    }
    label182: String str3 = (String)localHashMap.get("scAddr");
    String str4 = (String)localHashMap.get("destAddr");
    Object localObject = null;
    String str5;
    boolean bool4;
    if (localHashMap.containsKey("text"))
    {
      Rlog.d("RIL_ImsSms", "sms failed was text");
      str5 = (String)localHashMap.get("text");
      if (isCdmaFormat(str2))
      {
        Rlog.d("RIL_ImsSms", "old format (gsm) ==> new format (cdma)");
        if (paramSmsTracker.mDeliveryIntent != null)
        {
          bool4 = true;
          label267: localObject = com.android.internal.telephony.cdma.SmsMessage.getSubmitPdu(str3, str4, str5, bool4, null);
          label281: localHashMap.put("smsc", ((SmsMessageBase.SubmitPduBase)localObject).encodedScAddress);
          localHashMap.put("pdu", ((SmsMessageBase.SubmitPduBase)localObject).encodedMessage);
          if (!isCdmaFormat(str2))
            break label546;
        }
      }
    }
    label546: for (SMSDispatcher localSMSDispatcher = this.mCdmaDispatcher; ; localSMSDispatcher = this.mGsmDispatcher)
    {
      paramSmsTracker.mFormat = localSMSDispatcher.getFormat();
      localSMSDispatcher.sendSms(paramSmsTracker);
      break;
      bool4 = false;
      break label267;
      Rlog.d("RIL_ImsSms", "old format (cdma) ==> new format (gsm)");
      if (paramSmsTracker.mDeliveryIntent != null);
      for (boolean bool3 = true; ; bool3 = false)
      {
        localObject = com.android.internal.telephony.gsm.SmsMessage.getSubmitPdu(str3, str4, str5, bool3, null);
        break;
      }
      if (!localHashMap.containsKey("data"))
        break label281;
      Rlog.d("RIL_ImsSms", "sms failed was data");
      byte[] arrayOfByte = (byte[])localHashMap.get("data");
      Integer localInteger = (Integer)localHashMap.get("destPort");
      if (isCdmaFormat(str2))
      {
        Rlog.d("RIL_ImsSms", "old format (gsm) ==> new format (cdma)");
        int j = localInteger.intValue();
        if (paramSmsTracker.mDeliveryIntent != null);
        for (boolean bool2 = true; ; bool2 = false)
        {
          localObject = com.android.internal.telephony.cdma.SmsMessage.getSubmitPdu(str3, str4, j, arrayOfByte, bool2);
          break;
        }
      }
      Rlog.d("RIL_ImsSms", "old format (cdma) ==> new format (gsm)");
      int i = localInteger.intValue();
      if (paramSmsTracker.mDeliveryIntent != null);
      for (boolean bool1 = true; ; bool1 = false)
      {
        localObject = com.android.internal.telephony.gsm.SmsMessage.getSubmitPdu(str3, str4, i, arrayOfByte, bool1);
        break;
      }
    }
  }

  protected void sendSms(SMSDispatcher.SmsTracker paramSmsTracker)
  {
    Rlog.e("RIL_ImsSms", "sendSms should never be called from here!");
  }

  protected void sendText(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    Rlog.d("RIL_ImsSms", "sendText");
    if (isCdmaMo())
      this.mCdmaDispatcher.sendText(paramString1, paramString2, paramString3, paramPendingIntent1, paramPendingIntent2);
    while (true)
    {
      return;
      this.mGsmDispatcher.sendText(paramString1, paramString2, paramString3, paramPendingIntent1, paramPendingIntent2);
    }
  }

  protected void updatePhoneObject(PhoneBase paramPhoneBase)
  {
    Rlog.d("RIL_ImsSms", "In IMS updatePhoneObject ");
    super.updatePhoneObject(paramPhoneBase);
    this.mCdmaDispatcher.updatePhoneObject(paramPhoneBase);
    this.mGsmDispatcher.updatePhoneObject(paramPhoneBase);
    this.mGsmInboundSmsHandler.updatePhoneObject(paramPhoneBase);
    this.mCdmaInboundSmsHandler.updatePhoneObject(paramPhoneBase);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.ImsSMSDispatcher
 * JD-Core Version:    0.6.2
 */