package com.android.internal.telephony;

import java.util.ArrayList;
import java.util.Iterator;

public abstract class IntRangeManager
{
  private static final int INITIAL_CLIENTS_ARRAY_SIZE = 4;
  private ArrayList<IntRange> mRanges = new ArrayList();

  private void populateAllClientRanges()
  {
    int i = this.mRanges.size();
    for (int j = 0; j < i; j++)
    {
      IntRange localIntRange = (IntRange)this.mRanges.get(j);
      int k = localIntRange.mClients.size();
      for (int m = 0; m < k; m++)
      {
        ClientRange localClientRange = (ClientRange)localIntRange.mClients.get(m);
        addRange(localClientRange.mStartId, localClientRange.mEndId, true);
      }
    }
  }

  private void populateAllRanges()
  {
    Iterator localIterator = this.mRanges.iterator();
    while (localIterator.hasNext())
    {
      IntRange localIntRange = (IntRange)localIterator.next();
      addRange(localIntRange.mStartId, localIntRange.mEndId, true);
    }
  }

  protected abstract void addRange(int paramInt1, int paramInt2, boolean paramBoolean);

  public boolean disableRange(int paramInt1, int paramInt2, String paramString)
  {
    while (true)
    {
      int j;
      IntRange localIntRange1;
      boolean bool;
      int i2;
      ClientRange localClientRange1;
      int n;
      int i1;
      ArrayList localArrayList2;
      IntRange localIntRange3;
      int i3;
      try
      {
        int i = this.mRanges.size();
        j = 0;
        if (j >= i)
          break label626;
        localIntRange1 = (IntRange)this.mRanges.get(j);
        int k = localIntRange1.mStartId;
        if (paramInt1 < k)
        {
          bool = false;
          return bool;
        }
        if (paramInt2 > localIntRange1.mEndId)
          break label620;
        ArrayList localArrayList1 = localIntRange1.mClients;
        int m = localArrayList1.size();
        if (m != 1)
          break label638;
        ClientRange localClientRange3 = (ClientRange)localArrayList1.get(0);
        if ((localClientRange3.mStartId != paramInt1) || (localClientRange3.mEndId != paramInt2) || (!localClientRange3.mClient.equals(paramString)))
          break label632;
        this.mRanges.remove(j);
        if (updateRanges())
        {
          bool = true;
          continue;
        }
        this.mRanges.add(j, localIntRange1);
        bool = false;
        continue;
        if (i2 >= m)
          break label620;
        localClientRange1 = (ClientRange)localArrayList1.get(i2);
        if ((localClientRange1.mStartId != paramInt1) || (localClientRange1.mEndId != paramInt2) || (!localClientRange1.mClient.equals(paramString)))
          break label597;
        if (i2 == m - 1)
        {
          if (localIntRange1.mEndId == n)
          {
            localArrayList1.remove(i2);
            bool = true;
            continue;
          }
          localArrayList1.remove(i2);
          localIntRange1.mEndId = n;
          if (updateRanges())
          {
            bool = true;
            continue;
          }
          localArrayList1.add(i2, localClientRange1);
          localIntRange1.mEndId = localClientRange1.mEndId;
          bool = false;
          continue;
        }
        IntRange localIntRange2 = new IntRange(localIntRange1, i2);
        if (i2 == 0)
        {
          int i4 = ((ClientRange)localArrayList1.get(1)).mStartId;
          if (i4 != localIntRange1.mStartId)
          {
            i1 = 1;
            localIntRange2.mStartId = i4;
          }
          n = ((ClientRange)localArrayList1.get(1)).mEndId;
        }
        localArrayList2 = new ArrayList();
        localIntRange3 = localIntRange2;
        i3 = i2 + 1;
        if (i3 < m)
        {
          ClientRange localClientRange2 = (ClientRange)localArrayList1.get(i3);
          if (localClientRange2.mStartId > n + 1)
          {
            i1 = 1;
            localIntRange3.mEndId = n;
            localArrayList2.add(localIntRange3);
            localIntRange3 = new IntRange(localClientRange2);
            if (localClientRange2.mEndId <= n)
              break label651;
            n = localClientRange2.mEndId;
            break label651;
          }
          if (localIntRange3.mEndId < localClientRange2.mEndId)
            localIntRange3.mEndId = localClientRange2.mEndId;
          localIntRange3.mClients.add(localClientRange2);
          continue;
        }
      }
      finally
      {
      }
      if (n < paramInt2)
      {
        i1 = 1;
        localIntRange3.mEndId = n;
      }
      localArrayList2.add(localIntRange3);
      this.mRanges.remove(j);
      this.mRanges.addAll(j, localArrayList2);
      if ((i1 != 0) && (!updateRanges()))
      {
        this.mRanges.removeAll(localArrayList2);
        this.mRanges.add(j, localIntRange1);
        bool = false;
        continue;
        label597: if (localClientRange1.mEndId > n)
          n = localClientRange1.mEndId;
        i2++;
        continue;
        label620: j++;
        continue;
        label626: bool = false;
        continue;
        label632: bool = false;
        continue;
        label638: n = -2147483648;
        i1 = 0;
        i2 = 0;
        continue;
        label651: i3++;
      }
      else
      {
        bool = true;
      }
    }
  }

  public boolean enableRange(int paramInt1, int paramInt2, String paramString)
  {
    while (true)
    {
      int j;
      try
      {
        int i = this.mRanges.size();
        if (i == 0)
        {
          if (tryAddRanges(paramInt1, paramInt2, true))
          {
            ArrayList localArrayList3 = this.mRanges;
            IntRange localIntRange12 = new IntRange(paramInt1, paramInt2, paramString);
            localArrayList3.add(localIntRange12);
            bool = true;
            return bool;
          }
          bool = false;
          continue;
        }
        j = 0;
        if (j < i)
        {
          IntRange localIntRange2 = (IntRange)this.mRanges.get(j);
          if ((paramInt1 >= localIntRange2.mStartId) && (paramInt2 <= localIntRange2.mEndId))
          {
            ClientRange localClientRange5 = new ClientRange(paramInt1, paramInt2, paramString);
            localIntRange2.insert(localClientRange5);
            bool = true;
            continue;
          }
          if (paramInt1 - 1 == localIntRange2.mEndId)
          {
            int i11 = paramInt2;
            localIntRange11 = null;
            if (j + 1 < i)
            {
              localIntRange11 = (IntRange)this.mRanges.get(j + 1);
              if (-1 + localIntRange11.mStartId > paramInt2)
                break label1127;
              if (paramInt2 <= localIntRange11.mEndId)
                i11 = -1 + localIntRange11.mStartId;
            }
            if (!tryAddRanges(paramInt1, i11, true))
              break label1133;
            localIntRange2.mEndId = paramInt2;
            ClientRange localClientRange4 = new ClientRange(paramInt1, paramInt2, paramString);
            localIntRange2.insert(localClientRange4);
            if (localIntRange11 == null)
              break label1121;
            if (localIntRange2.mEndId < localIntRange11.mEndId)
              localIntRange2.mEndId = localIntRange11.mEndId;
            localIntRange2.mClients.addAll(localIntRange11.mClients);
            this.mRanges.remove(localIntRange11);
            break label1121;
          }
          if (paramInt1 < localIntRange2.mStartId)
          {
            if (paramInt2 + 1 < localIntRange2.mStartId)
            {
              if (!tryAddRanges(paramInt1, paramInt2, true))
                break label1139;
              ArrayList localArrayList2 = this.mRanges;
              IntRange localIntRange10 = new IntRange(paramInt1, paramInt2, paramString);
              localArrayList2.add(j, localIntRange10);
              bool = true;
              continue;
            }
            if (paramInt2 > localIntRange2.mEndId)
              break label1151;
            if (!tryAddRanges(paramInt1, -1 + localIntRange2.mStartId, true))
              break label1145;
            localIntRange2.mStartId = paramInt1;
            localIntRange2.mClients.add(0, new ClientRange(paramInt1, paramInt2, paramString));
            bool = true;
            continue;
            if (i4 < i)
            {
              IntRange localIntRange7 = (IntRange)this.mRanges.get(i4);
              if (paramInt2 + 1 < localIntRange7.mStartId)
              {
                if (!tryAddRanges(paramInt1, paramInt2, true))
                  break label1166;
                localIntRange2.mStartId = paramInt1;
                localIntRange2.mEndId = paramInt2;
                localIntRange2.mClients.add(0, new ClientRange(paramInt1, paramInt2, paramString));
                int i9 = j + 1;
                int i10 = i9;
                if (i10 >= i4)
                  break label1160;
                IntRange localIntRange9 = (IntRange)this.mRanges.get(i9);
                localIntRange2.mClients.addAll(localIntRange9.mClients);
                this.mRanges.remove(localIntRange9);
                i10++;
                continue;
              }
              if (paramInt2 > localIntRange7.mEndId)
                break label1184;
              if (!tryAddRanges(paramInt1, -1 + localIntRange7.mStartId, true))
                break label1178;
              localIntRange2.mStartId = paramInt1;
              localIntRange2.mEndId = localIntRange7.mEndId;
              localIntRange2.mClients.add(0, new ClientRange(paramInt1, paramInt2, paramString));
              int i7 = j + 1;
              int i8 = i7;
              if (i8 > i4)
                break label1172;
              IntRange localIntRange8 = (IntRange)this.mRanges.get(i7);
              localIntRange2.mClients.addAll(localIntRange8.mClients);
              this.mRanges.remove(localIntRange8);
              i8++;
              continue;
            }
            if (!tryAddRanges(paramInt1, paramInt2, true))
              break label1196;
            localIntRange2.mStartId = paramInt1;
            localIntRange2.mEndId = paramInt2;
            localIntRange2.mClients.add(0, new ClientRange(paramInt1, paramInt2, paramString));
            int i5 = j + 1;
            int i6 = i5;
            if (i6 >= i)
              break label1190;
            IntRange localIntRange6 = (IntRange)this.mRanges.get(i5);
            localIntRange2.mClients.addAll(localIntRange6.mClients);
            this.mRanges.remove(localIntRange6);
            i6++;
            continue;
          }
          if (paramInt1 + 1 > localIntRange2.mEndId)
            break label1255;
          if (paramInt2 > localIntRange2.mEndId)
            break label1202;
          ClientRange localClientRange1 = new ClientRange(paramInt1, paramInt2, paramString);
          localIntRange2.insert(localClientRange1);
          bool = true;
          continue;
          if (m < i)
          {
            IntRange localIntRange5 = (IntRange)this.mRanges.get(m);
            if (paramInt2 + 1 >= localIntRange5.mStartId)
              break label1215;
          }
          if (k == j)
          {
            if (!tryAddRanges(1 + localIntRange2.mEndId, paramInt2, true))
              break label1225;
            localIntRange2.mEndId = paramInt2;
            ClientRange localClientRange3 = new ClientRange(paramInt1, paramInt2, paramString);
            localIntRange2.insert(localClientRange3);
            bool = true;
            continue;
          }
          IntRange localIntRange3 = (IntRange)this.mRanges.get(k);
          if (paramInt2 > localIntRange3.mEndId)
            break label1231;
          n = -1 + localIntRange3.mStartId;
          if (!tryAddRanges(1 + localIntRange2.mEndId, n, true))
            break label1249;
          if (paramInt2 > localIntRange3.mEndId)
            break label1237;
          i1 = localIntRange3.mEndId;
          localIntRange2.mEndId = i1;
          ClientRange localClientRange2 = new ClientRange(paramInt1, paramInt2, paramString);
          localIntRange2.insert(localClientRange2);
          int i2 = j + 1;
          int i3 = i2;
          if (i3 > k)
            break label1243;
          IntRange localIntRange4 = (IntRange)this.mRanges.get(i2);
          localIntRange2.mClients.addAll(localIntRange4.mClients);
          this.mRanges.remove(localIntRange4);
          i3++;
          continue;
        }
        if (tryAddRanges(paramInt1, paramInt2, true))
        {
          ArrayList localArrayList1 = this.mRanges;
          IntRange localIntRange1 = new IntRange(paramInt1, paramInt2, paramString);
          localArrayList1.add(localIntRange1);
          bool = true;
          continue;
        }
        bool = false;
        continue;
      }
      finally
      {
      }
      label1121: boolean bool = true;
      continue;
      label1127: IntRange localIntRange11 = null;
      continue;
      label1133: bool = false;
      continue;
      label1139: bool = false;
      continue;
      label1145: bool = false;
      continue;
      label1151: int i4 = j + 1;
      continue;
      label1160: bool = true;
      continue;
      label1166: bool = false;
      continue;
      label1172: bool = true;
      continue;
      label1178: bool = false;
      continue;
      label1184: i4++;
      continue;
      label1190: bool = true;
      continue;
      label1196: bool = false;
      continue;
      label1202: int k = j;
      int m = j + 1;
      continue;
      label1215: k = m;
      m++;
      continue;
      label1225: bool = false;
      continue;
      label1231: int n = paramInt2;
      continue;
      label1237: int i1 = paramInt2;
      continue;
      label1243: bool = true;
      continue;
      label1249: bool = false;
      continue;
      label1255: j++;
    }
  }

  protected abstract boolean finishUpdate();

  public boolean isEmpty()
  {
    return this.mRanges.isEmpty();
  }

  protected abstract void startUpdate();

  protected boolean tryAddRanges(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    startUpdate();
    populateAllRanges();
    addRange(paramInt1, paramInt2, paramBoolean);
    return finishUpdate();
  }

  public boolean updateRanges()
  {
    startUpdate();
    populateAllRanges();
    return finishUpdate();
  }

  private class ClientRange
  {
    final String mClient;
    final int mEndId;
    final int mStartId;

    ClientRange(int paramInt1, int paramString, String arg4)
    {
      this.mStartId = paramInt1;
      this.mEndId = paramString;
      Object localObject;
      this.mClient = localObject;
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = false;
      if ((paramObject != null) && ((paramObject instanceof ClientRange)))
      {
        ClientRange localClientRange = (ClientRange)paramObject;
        if ((this.mStartId == localClientRange.mStartId) && (this.mEndId == localClientRange.mEndId) && (this.mClient.equals(localClientRange.mClient)))
          bool = true;
      }
      return bool;
    }

    public int hashCode()
    {
      return 31 * (31 * this.mStartId + this.mEndId) + this.mClient.hashCode();
    }
  }

  private class IntRange
  {
    final ArrayList<IntRangeManager.ClientRange> mClients;
    int mEndId;
    int mStartId;

    IntRange(int paramInt1, int paramString, String arg4)
    {
      this.mStartId = paramInt1;
      this.mEndId = paramString;
      this.mClients = new ArrayList(4);
      String str;
      this.mClients.add(new IntRangeManager.ClientRange(IntRangeManager.this, paramInt1, paramString, str));
    }

    IntRange(IntRangeManager.ClientRange arg2)
    {
      Object localObject;
      this.mStartId = localObject.mStartId;
      this.mEndId = localObject.mEndId;
      this.mClients = new ArrayList(4);
      this.mClients.add(localObject);
    }

    IntRange(IntRange paramInt, int arg3)
    {
      this.mStartId = paramInt.mStartId;
      this.mEndId = paramInt.mEndId;
      this.mClients = new ArrayList(paramInt.mClients.size());
      int i;
      for (int j = 0; j < i; j++)
        this.mClients.add(paramInt.mClients.get(j));
    }

    void insert(IntRangeManager.ClientRange paramClientRange)
    {
      int i = this.mClients.size();
      int j = -1;
      int k = 0;
      while (true)
        if (k < i)
        {
          IntRangeManager.ClientRange localClientRange = (IntRangeManager.ClientRange)this.mClients.get(k);
          if (paramClientRange.mStartId <= localClientRange.mStartId)
          {
            if (paramClientRange.equals(localClientRange))
              break;
            if ((paramClientRange.mStartId == localClientRange.mStartId) && (paramClientRange.mEndId > localClientRange.mEndId))
            {
              j = k + 1;
              if (j >= i)
                break label105;
            }
          }
          else
          {
            k++;
            continue;
          }
          this.mClients.add(k, paramClientRange);
        }
      while (true)
      {
        return;
        label105: if ((j != -1) && (j < i))
          this.mClients.add(j, paramClientRange);
        else
          this.mClients.add(paramClientRange);
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.IntRangeManager
 * JD-Core Version:    0.6.2
 */