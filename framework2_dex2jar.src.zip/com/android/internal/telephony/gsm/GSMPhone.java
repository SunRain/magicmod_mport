package com.android.internal.telephony.gsm;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.SQLException;
import android.net.Uri;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.preference.PreferenceManager;
import android.provider.Telephony.Carriers;
import android.telephony.CellLocation;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallForwardInfo;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.DctConstants.Activity;
import com.android.internal.telephony.DctConstants.State;
import com.android.internal.telephony.IccPhoneBookInterfaceManager;
import com.android.internal.telephony.MmiCode;
import com.android.internal.telephony.OperatorInfo;
import com.android.internal.telephony.Phone.DataActivityState;
import com.android.internal.telephony.Phone.SuppService;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.DataState;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.PhoneNotifier;
import com.android.internal.telephony.PhoneProxy;
import com.android.internal.telephony.PhoneSubInfo;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.UUSInfo;
import com.android.internal.telephony.dataconnection.DcTracker;
import com.android.internal.telephony.dataconnection.DcTrackerBase;
import com.android.internal.telephony.test.SimulatedRadioControl;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.IccVmNotSupportedException;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class GSMPhone extends PhoneBase
{
  public static final String CIPHERING_KEY = "ciphering_key";
  private static final boolean DBG_PORT = false;
  private static final boolean LOCAL_DEBUG = true;
  static final String LOG_TAG = "GSMPhone";
  private static final boolean VDBG = false;
  public static final String VM_NUMBER = "vm_number_key";
  public static final String VM_SIM_IMSI = "vm_sim_imsi_key";
  GsmCallTracker mCT;
  Thread mDebugPortThread;
  ServerSocket mDebugSocket;
  private String mImei;
  private String mImeiSv;
  ArrayList<GsmMmiCode> mPendingMMIs = new ArrayList();
  Registrant mPostDialHandler;
  GsmServiceStateTracker mSST;
  IccPhoneBookInterfaceManager mSimPhoneBookIntManager;
  RegistrantList mSsnRegistrants = new RegistrantList();
  PhoneSubInfo mSubInfo;
  private String mVmNumber;

  public GSMPhone(Context paramContext, CommandsInterface paramCommandsInterface, PhoneNotifier paramPhoneNotifier)
  {
    this(paramContext, paramCommandsInterface, paramPhoneNotifier, false);
  }

  public GSMPhone(Context paramContext, CommandsInterface paramCommandsInterface, PhoneNotifier paramPhoneNotifier, boolean paramBoolean)
  {
    super("GSM", paramPhoneNotifier, paramContext, paramCommandsInterface, paramBoolean);
    if ((paramCommandsInterface instanceof SimulatedRadioControl))
      this.mSimulatedRadioControl = ((SimulatedRadioControl)paramCommandsInterface);
    this.mCi.setPhoneType(1);
    this.mCT = new GsmCallTracker(this);
    this.mSST = new GsmServiceStateTracker(this);
    this.mDcTracker = new DcTracker(this);
    if (!paramBoolean)
    {
      this.mSimPhoneBookIntManager = new MiuiSimPhoneBookInterfaceManager(this);
      this.mSubInfo = new PhoneSubInfo(this);
    }
    this.mCi.registerForAvailable(this, 1, null);
    this.mCi.registerForOffOrNotAvailable(this, 8, null);
    this.mCi.registerForOn(this, 5, null);
    this.mCi.setOnUSSD(this, 7, null);
    this.mCi.setOnSuppServiceNotification(this, 2, null);
    this.mSST.registerForNetworkAttached(this, 19, null);
    SystemProperties.set("gsm.current.phone-type", new Integer(1).toString());
  }

  private String getVmSimImsi()
  {
    return PreferenceManager.getDefaultSharedPreferences(getContext()).getString("vm_sim_imsi_key", null);
  }

  private boolean handleCallDeflectionIncallSupplementaryService(String paramString)
  {
    int i = 1;
    if (paramString.length() > i)
      i = 0;
    while (true)
    {
      return i;
      if (getRingingCall().getState() != Call.State.IDLE)
      {
        Rlog.d("GSMPhone", "MmiCode 0: rejectCall");
        try
        {
          this.mCT.rejectCall();
        }
        catch (CallStateException localCallStateException)
        {
          Rlog.d("GSMPhone", "reject failed", localCallStateException);
          notifySuppServiceFailed(Phone.SuppService.REJECT);
        }
      }
      else if (getBackgroundCall().getState() != Call.State.IDLE)
      {
        Rlog.d("GSMPhone", "MmiCode 0: hangupWaitingOrBackground");
        this.mCT.hangupWaitingOrBackground();
      }
    }
  }

  private boolean handleCallHoldIncallSupplementaryService(String paramString)
  {
    int i = 1;
    int j = paramString.length();
    if (j > 2)
      i = 0;
    while (true)
    {
      return i;
      GsmCall localGsmCall = getForegroundCall();
      if (j > i)
      {
        int k;
        try
        {
          k = '\0*0' + paramString.charAt(1);
          GsmConnection localGsmConnection = this.mCT.getConnectionByIndex(localGsmCall, k);
          if ((localGsmConnection == null) || (k < i) || (k > 7))
            break label129;
          Rlog.d("GSMPhone", "MmiCode 2: separate call " + k);
          this.mCT.separate(localGsmConnection);
        }
        catch (CallStateException localCallStateException2)
        {
          Rlog.d("GSMPhone", "separate failed", localCallStateException2);
          notifySuppServiceFailed(Phone.SuppService.SEPARATE);
        }
        continue;
        label129: Rlog.d("GSMPhone", "separate: invalid call index " + k);
        notifySuppServiceFailed(Phone.SuppService.SEPARATE);
      }
      else
      {
        try
        {
          if (getRingingCall().getState() == Call.State.IDLE)
            break label221;
          Rlog.d("GSMPhone", "MmiCode 2: accept ringing call");
          this.mCT.acceptCall();
        }
        catch (CallStateException localCallStateException1)
        {
          Rlog.d("GSMPhone", "switch failed", localCallStateException1);
          notifySuppServiceFailed(Phone.SuppService.SWITCH);
        }
        continue;
        label221: Rlog.d("GSMPhone", "MmiCode 2: switchWaitingOrHoldingAndActive");
        this.mCT.switchWaitingOrHoldingAndActive();
      }
    }
  }

  private boolean handleCallWaitingIncallSupplementaryService(String paramString)
  {
    int i = 1;
    int j = paramString.length();
    if (j > 2)
      i = 0;
    while (true)
    {
      return i;
      GsmCall localGsmCall = getForegroundCall();
      if (j > i)
      {
        try
        {
          int k = '\0*0' + paramString.charAt(1);
          if ((k < i) || (k > 7))
            continue;
          Rlog.d("GSMPhone", "MmiCode 1: hangupConnectionByIndex " + k);
          this.mCT.hangupConnectionByIndex(localGsmCall, k);
        }
        catch (CallStateException localCallStateException)
        {
          Rlog.d("GSMPhone", "hangup failed", localCallStateException);
          notifySuppServiceFailed(Phone.SuppService.HANGUP);
        }
      }
      else if (localGsmCall.getState() != Call.State.IDLE)
      {
        Rlog.d("GSMPhone", "MmiCode 1: hangup foreground");
        this.mCT.hangup(localGsmCall);
      }
      else
      {
        Rlog.d("GSMPhone", "MmiCode 1: switchWaitingOrHoldingAndActive");
        this.mCT.switchWaitingOrHoldingAndActive();
      }
    }
  }

  private boolean handleCcbsIncallSupplementaryService(String paramString)
  {
    int i = 1;
    if (paramString.length() > i)
      i = 0;
    while (true)
    {
      return i;
      Rlog.i("GSMPhone", "MmiCode 5: CCBS not supported!");
      notifySuppServiceFailed(Phone.SuppService.UNKNOWN);
    }
  }

  private void handleCfuQueryResult(CallForwardInfo[] paramArrayOfCallForwardInfo)
  {
    boolean bool = false;
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null)
    {
      if ((paramArrayOfCallForwardInfo != null) && (paramArrayOfCallForwardInfo.length != 0))
        break label34;
      localIccRecords.setVoiceCallForwardingFlag(1, false, null);
    }
    label34: label93: 
    while (true)
    {
      return;
      int i = 0;
      int j = paramArrayOfCallForwardInfo.length;
      while (true)
      {
        if (i >= j)
          break label93;
        if ((0x1 & paramArrayOfCallForwardInfo[i].serviceClass) != 0)
        {
          if (paramArrayOfCallForwardInfo[i].status == 1)
            bool = true;
          localIccRecords.setVoiceCallForwardingFlag(1, bool, paramArrayOfCallForwardInfo[i].number);
          break;
        }
        i++;
      }
    }
  }

  private boolean handleEctIncallSupplementaryService(String paramString)
  {
    int i = 1;
    if (paramString.length() != i)
      i = 0;
    while (true)
    {
      return i;
      Rlog.d("GSMPhone", "MmiCode 4: explicit call transfer");
      explicitCallTransfer();
    }
  }

  private boolean handleMultipartyIncallSupplementaryService(String paramString)
  {
    int i = 1;
    if (paramString.length() > i)
      i = 0;
    while (true)
    {
      return i;
      Rlog.d("GSMPhone", "MmiCode 3: merge calls");
      conference();
    }
  }

  private void handleSetSelectNetwork(AsyncResult paramAsyncResult)
  {
    if (!(paramAsyncResult.userObj instanceof NetworkSelectMessage))
      Rlog.d("GSMPhone", "unexpected result from user object.");
    while (true)
    {
      return;
      NetworkSelectMessage localNetworkSelectMessage = (NetworkSelectMessage)paramAsyncResult.userObj;
      if (localNetworkSelectMessage.message != null)
      {
        Rlog.d("GSMPhone", "sending original message to recipient");
        AsyncResult.forMessage(localNetworkSelectMessage.message, paramAsyncResult.result, paramAsyncResult.exception);
        localNetworkSelectMessage.message.sendToTarget();
      }
      SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
      localEditor.putString("network_selection_key", localNetworkSelectMessage.operatorNumeric);
      localEditor.putString("network_selection_name_key", localNetworkSelectMessage.operatorAlphaLong);
      if (!localEditor.commit())
        Rlog.e("GSMPhone", "failed to commit network selection preference");
    }
  }

  private boolean isValidCommandInterfaceCFAction(int paramInt)
  {
    switch (paramInt)
    {
    case 2:
    default:
    case 0:
    case 1:
    case 3:
    case 4:
    }
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  private boolean isValidCommandInterfaceCFReason(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    }
    for (boolean bool = false; ; bool = true)
      return bool;
  }

  private void onIncomingUSSD(int paramInt, String paramString)
  {
    int i = 1;
    int j;
    label19: GsmMmiCode localGsmMmiCode;
    int k;
    if (paramInt == i)
    {
      j = i;
      if ((paramInt == 0) || (paramInt == i))
        break label94;
      localGsmMmiCode = null;
      k = 0;
      int m = this.mPendingMMIs.size();
      label34: if (k < m)
      {
        if (!((GsmMmiCode)this.mPendingMMIs.get(k)).isPendingUSSD())
          break label99;
        localGsmMmiCode = (GsmMmiCode)this.mPendingMMIs.get(k);
      }
      if (localGsmMmiCode == null)
        break label116;
      if (i == 0)
        break label105;
      localGsmMmiCode.onUssdFinishedError();
    }
    while (true)
    {
      return;
      j = 0;
      break;
      label94: i = 0;
      break label19;
      label99: k++;
      break label34;
      label105: localGsmMmiCode.onUssdFinished(paramString, j);
      continue;
      label116: if ((i == 0) && (paramString != null))
        onNetworkInitiatedUssd(GsmMmiCode.newNetworkInitiatedUssd(paramString, j, this, (UiccCardApplication)this.mUiccApplication.get()));
    }
  }

  private void onNetworkInitiatedUssd(GsmMmiCode paramGsmMmiCode)
  {
    this.mMmiCompleteRegistrants.notifyRegistrants(new AsyncResult(null, paramGsmMmiCode, null));
  }

  private void processIccRecordEvents(int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 1:
    case 0:
    }
    while (true)
    {
      return;
      notifyCallForwardingIndicator();
      continue;
      notifyMessageWaitingIndicator();
    }
  }

  private void registerForSimRecordEvents()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords == null);
    while (true)
    {
      return;
      localIccRecords.registerForNetworkSelectionModeAutomatic(this, 28, null);
      localIccRecords.registerForRecordsEvents(this, 29, null);
      localIccRecords.registerForRecordsLoaded(this, 3, null);
    }
  }

  private void setVmSimImsi(String paramString)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
    localEditor.putString("vm_sim_imsi_key", paramString);
    localEditor.apply();
  }

  private void storeVoiceMailNumber(String paramString)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
    localEditor.putString("vm_number_key", paramString);
    localEditor.apply();
    setVmSimImsi(getSubscriberId());
  }

  private void unregisterForSimRecordEvents()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords == null);
    while (true)
    {
      return;
      localIccRecords.unregisterForNetworkSelectionModeAutomatic(this);
      localIccRecords.unregisterForRecordsEvents(this);
      localIccRecords.unregisterForRecordsLoaded(this);
    }
  }

  public void acceptCall()
    throws CallStateException
  {
    Injector.GSMPhoneHook.before_acceptCall(this);
    this.mCT.acceptCall();
  }

  public void activateCellBroadcastSms(int paramInt, Message paramMessage)
  {
    Rlog.e("GSMPhone", "[GSMPhone] activateCellBroadcastSms() is obsolete; use SmsManager");
    paramMessage.sendToTarget();
  }

  public boolean canConference()
  {
    return this.mCT.canConference();
  }

  public boolean canDial()
  {
    return this.mCT.canDial();
  }

  public boolean canTransfer()
  {
    return this.mCT.canTransfer();
  }

  public void clearDisconnected()
  {
    this.mCT.clearDisconnected();
  }

  public void conference()
  {
    this.mCT.conference();
  }

  public Connection dial(String paramString)
    throws CallStateException
  {
    return dial(paramString, null);
  }

  public Connection dial(String paramString, UUSInfo paramUUSInfo)
    throws CallStateException
  {
    String str = PhoneNumberUtils.stripSeparators(paramString);
    Connection localConnection;
    if (handleInCallMmiCommands(str))
      localConnection = null;
    while (true)
    {
      return localConnection;
      GsmMmiCode localGsmMmiCode = GsmMmiCode.newFromDialString(PhoneNumberUtils.extractNetworkPortionAlt(str), this, (UiccCardApplication)this.mUiccApplication.get());
      Rlog.d("GSMPhone", "dialing w/ mmi '" + localGsmMmiCode + "'...");
      if (localGsmMmiCode == null)
      {
        localConnection = this.mCT.dial(str, paramUUSInfo);
      }
      else if (localGsmMmiCode.isTemporaryModeCLIR())
      {
        localConnection = this.mCT.dial(localGsmMmiCode.mDialingNumber, localGsmMmiCode.getCLIRMode(), paramUUSInfo);
      }
      else
      {
        this.mPendingMMIs.add(localGsmMmiCode);
        this.mMmiRegistrants.notifyRegistrants(new AsyncResult(null, localGsmMmiCode, null));
        localGsmMmiCode.processCode();
        localConnection = null;
      }
    }
  }

  public void disableLocationUpdates()
  {
    this.mSST.disableLocationUpdates();
  }

  public void dispose()
  {
    synchronized (PhoneProxy.lockForRadioTechnologyChange)
    {
      super.dispose();
      this.mCi.unregisterForAvailable(this);
      unregisterForSimRecordEvents();
      this.mCi.unregisterForOffOrNotAvailable(this);
      this.mCi.unregisterForOn(this);
      this.mSST.unregisterForNetworkAttached(this);
      this.mCi.unSetOnUSSD(this);
      this.mCi.unSetOnSuppServiceNotification(this);
      this.mPendingMMIs.clear();
      this.mCT.dispose();
      this.mDcTracker.dispose();
      this.mSST.dispose();
      this.mSimPhoneBookIntManager.dispose();
      this.mSubInfo.dispose();
      return;
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("GSMPhone extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mCT=" + this.mCT);
    paramPrintWriter.println(" mSST=" + this.mSST);
    paramPrintWriter.println(" mPendingMMIs=" + this.mPendingMMIs);
    paramPrintWriter.println(" mSimPhoneBookIntManager=" + this.mSimPhoneBookIntManager);
    paramPrintWriter.println(" mSubInfo=" + this.mSubInfo);
    paramPrintWriter.println(" mVmNumber=" + this.mVmNumber);
  }

  public void enableLocationUpdates()
  {
    this.mSST.enableLocationUpdates();
  }

  public void explicitCallTransfer()
  {
    this.mCT.explicitCallTransfer();
  }

  protected void finalize()
  {
    Rlog.d("GSMPhone", "GSMPhone finalized");
  }

  public void getAvailableNetworks(Message paramMessage)
  {
    this.mCi.getAvailableNetworks(paramMessage);
  }

  public GsmCall getBackgroundCall()
  {
    return this.mCT.mBackgroundCall;
  }

  public void getCallForwardingOption(int paramInt, Message paramMessage)
  {
    if (isValidCommandInterfaceCFReason(paramInt))
    {
      Rlog.d("GSMPhone", "requesting call forwarding query.");
      if (paramInt != 0)
        break label45;
    }
    label45: for (Message localMessage = obtainMessage(13, paramMessage); ; localMessage = paramMessage)
    {
      this.mCi.queryCallForwardStatus(paramInt, 0, null, localMessage);
      return;
    }
  }

  public CallTracker getCallTracker()
  {
    return this.mCT;
  }

  public void getCallWaiting(Message paramMessage)
  {
    this.mCi.queryCallWaiting(0, paramMessage);
  }

  public void getCellBroadcastSmsConfig(Message paramMessage)
  {
    Rlog.e("GSMPhone", "[GSMPhone] getCellBroadcastSmsConfig() is obsolete; use SmsManager");
    paramMessage.sendToTarget();
  }

  public CellLocation getCellLocation()
  {
    return this.mSST.getCellLocation();
  }

  public Phone.DataActivityState getDataActivityState()
  {
    Phone.DataActivityState localDataActivityState = Phone.DataActivityState.NONE;
    if (this.mSST.getCurrentDataConnectionState() == 0)
      switch (2.$SwitchMap$com$android$internal$telephony$DctConstants$Activity[this.mDcTracker.getActivity().ordinal()])
      {
      default:
        localDataActivityState = Phone.DataActivityState.NONE;
      case 1:
      case 2:
      case 3:
      case 4:
      }
    while (true)
    {
      return localDataActivityState;
      localDataActivityState = Phone.DataActivityState.DATAIN;
      continue;
      localDataActivityState = Phone.DataActivityState.DATAOUT;
      continue;
      localDataActivityState = Phone.DataActivityState.DATAINANDOUT;
      continue;
      localDataActivityState = Phone.DataActivityState.DORMANT;
    }
  }

  public void getDataCallList(Message paramMessage)
  {
    this.mCi.getDataCallList(paramMessage);
  }

  public PhoneConstants.DataState getDataConnectionState(String paramString)
  {
    PhoneConstants.DataState localDataState = PhoneConstants.DataState.DISCONNECTED;
    if (this.mSST == null)
      localDataState = PhoneConstants.DataState.DISCONNECTED;
    while (true)
    {
      return localDataState;
      if (this.mSST.getCurrentDataConnectionState() != 0)
        localDataState = PhoneConstants.DataState.DISCONNECTED;
      else if ((!this.mDcTracker.isApnTypeEnabled(paramString)) || (!this.mDcTracker.isApnTypeActive(paramString)))
        localDataState = PhoneConstants.DataState.DISCONNECTED;
      else
        switch (2.$SwitchMap$com$android$internal$telephony$DctConstants$State[this.mDcTracker.getState(paramString).ordinal()])
        {
        default:
          break;
        case 1:
        case 2:
        case 3:
          localDataState = PhoneConstants.DataState.DISCONNECTED;
          break;
        case 4:
        case 5:
          if ((this.mCT.mState != PhoneConstants.State.IDLE) && (!this.mSST.isConcurrentVoiceAndDataAllowed()))
            localDataState = PhoneConstants.DataState.SUSPENDED;
          else
            localDataState = PhoneConstants.DataState.CONNECTED;
          break;
        case 6:
        case 7:
          localDataState = PhoneConstants.DataState.CONNECTING;
        }
    }
  }

  public boolean getDataRoamingEnabled()
  {
    return this.mDcTracker.getDataOnRoamingEnabled();
  }

  public String getDeviceId()
  {
    return Injector.GSMPhoneHook.getDeviceId(this, this.mImei);
  }

  public String getDeviceSvn()
  {
    return this.mImeiSv;
  }

  public String getEsn()
  {
    Rlog.e("GSMPhone", "[GSMPhone] getEsn() is a CDMA method");
    return "0";
  }

  public GsmCall getForegroundCall()
  {
    return this.mCT.mForegroundCall;
  }

  public String getGroupIdLevel1()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getGid1(); ; str = null)
      return str;
  }

  public IccPhoneBookInterfaceManager getIccPhoneBookInterfaceManager()
  {
    return this.mSimPhoneBookIntManager;
  }

  public String getImei()
  {
    return this.mImei;
  }

  public String getLine1AlphaTag()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getMsisdnAlphaTag(); ; str = null)
      return str;
  }

  public String getLine1Number()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getMsisdnNumber(); ; str = null)
      return str;
  }

  public String getMeid()
  {
    Rlog.e("GSMPhone", "[GSMPhone] getMeid() is a CDMA method");
    return "0";
  }

  public String getMsisdn()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getMsisdnNumber(); ; str = null)
      return str;
  }

  public boolean getMute()
  {
    return this.mCT.getMute();
  }

  public void getNeighboringCids(Message paramMessage)
  {
    this.mCi.getNeighboringCids(paramMessage);
  }

  public void getOutgoingCallerIdDisplay(Message paramMessage)
  {
    this.mCi.getCLIR(paramMessage);
  }

  public List<? extends MmiCode> getPendingMmiCodes()
  {
    return this.mPendingMMIs;
  }

  public PhoneSubInfo getPhoneSubInfo()
  {
    return this.mSubInfo;
  }

  public int getPhoneType()
  {
    return 1;
  }

  public GsmCall getRingingCall()
  {
    return this.mCT.mRingingCall;
  }

  public ServiceState getServiceState()
  {
    if (this.mSST != null);
    for (ServiceState localServiceState = this.mSST.mSS; ; localServiceState = new ServiceState())
      return localServiceState;
  }

  public ServiceStateTracker getServiceStateTracker()
  {
    return this.mSST;
  }

  public PhoneConstants.State getState()
  {
    return this.mCT.mState;
  }

  public String getSubscriberId()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getIMSI(); ; str = null)
      return str;
  }

  public String getVoiceMailAlphaTag()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getVoiceMailAlphaTag(); ; str = "")
    {
      if ((str == null) || (str.length() == 0))
        str = this.mContext.getText(17039364).toString();
      return str;
    }
  }

  public String getVoiceMailNumber()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (String str = localIccRecords.getVoiceMailNumber(); ; str = "")
    {
      if (TextUtils.isEmpty(str))
        str = PreferenceManager.getDefaultSharedPreferences(getContext()).getString("vm_number_key", null);
      return str;
    }
  }

  public boolean handleInCallMmiCommands(String paramString)
  {
    boolean bool;
    if (!isInCall())
      bool = false;
    while (true)
    {
      return bool;
      if (TextUtils.isEmpty(paramString))
      {
        bool = false;
      }
      else
      {
        bool = false;
        switch (paramString.charAt(0))
        {
        default:
          break;
        case '0':
          bool = handleCallDeflectionIncallSupplementaryService(paramString);
          break;
        case '1':
          bool = handleCallWaitingIncallSupplementaryService(paramString);
          break;
        case '2':
          bool = handleCallHoldIncallSupplementaryService(paramString);
          break;
        case '3':
          bool = handleMultipartyIncallSupplementaryService(paramString);
          break;
        case '4':
          bool = handleEctIncallSupplementaryService(paramString);
          break;
        case '5':
          bool = handleCcbsIncallSupplementaryService(paramString);
        }
      }
    }
  }

  public void handleMessage(Message paramMessage)
  {
    boolean bool = false;
    if (!this.mIsTheCurrentActivePhone)
    {
      Rlog.e("GSMPhone", "Received message " + paramMessage + "[" + paramMessage.what + "] while being destroyed. Ignoring.");
      return;
    }
    switch (paramMessage.what)
    {
    case 4:
    case 11:
    case 14:
    case 15:
    case 21:
    case 22:
    case 23:
    case 24:
    case 25:
    case 26:
    case 27:
    default:
      super.handleMessage(paramMessage);
    case 5:
    case 1:
    case 19:
    case 3:
    case 6:
    case 9:
    case 10:
    case 7:
    case 8:
    case 2:
    case 12:
    case 20:
    case 13:
    case 28:
    case 29:
    case 16:
    case 17:
    case 18:
    }
    while (true)
    {
      Injector.GSMPhoneHook.checkAndNotifyDeviceId(this, paramMessage);
      break;
      this.mCi.getBasebandVersion(obtainMessage(6));
      this.mCi.getIMEI(obtainMessage(9));
      this.mCi.getIMEISV(obtainMessage(10));
      continue;
      syncClirSetting();
      continue;
      updateCurrentCarrierInProvider();
      String str1 = getVmSimImsi();
      String str2 = getSubscriberId();
      if ((str1 != null) && (str2 != null) && (!str2.equals(str1)))
      {
        storeVoiceMailNumber(null);
        setVmSimImsi(null);
        continue;
        AsyncResult localAsyncResult8 = (AsyncResult)paramMessage.obj;
        if (localAsyncResult8.exception == null)
        {
          Rlog.d("GSMPhone", "Baseband version: " + localAsyncResult8.result);
          setSystemProperty("gsm.version.baseband", (String)localAsyncResult8.result);
          continue;
          AsyncResult localAsyncResult7 = (AsyncResult)paramMessage.obj;
          if (localAsyncResult7.exception == null)
          {
            this.mImei = ((String)localAsyncResult7.result);
            continue;
            AsyncResult localAsyncResult6 = (AsyncResult)paramMessage.obj;
            if (localAsyncResult6.exception == null)
            {
              this.mImeiSv = ((String)localAsyncResult6.result);
              continue;
              String[] arrayOfString = (String[])((AsyncResult)paramMessage.obj).result;
              if (arrayOfString.length > 1)
              {
                try
                {
                  onIncomingUSSD(Integer.parseInt(arrayOfString[0]), arrayOfString[1]);
                }
                catch (NumberFormatException localNumberFormatException)
                {
                  Rlog.w("GSMPhone", "error parsing USSD");
                }
                continue;
                for (int i = -1 + this.mPendingMMIs.size(); i >= 0; i--)
                  if (((GsmMmiCode)this.mPendingMMIs.get(i)).isPendingUSSD())
                    ((GsmMmiCode)this.mPendingMMIs.get(i)).onUssdFinishedError();
                AsyncResult localAsyncResult5 = (AsyncResult)paramMessage.obj;
                ((SuppServiceNotification)localAsyncResult5.result);
                this.mSsnRegistrants.notifyRegistrants(localAsyncResult5);
                continue;
                AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
                IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
                Cfu localCfu = (Cfu)localAsyncResult4.userObj;
                if ((localAsyncResult4.exception == null) && (localIccRecords != null))
                {
                  if (paramMessage.arg1 == 1)
                    bool = true;
                  localIccRecords.setVoiceCallForwardingFlag(1, bool, localCfu.mSetCfNumber);
                }
                if (localCfu.mOnComplete != null)
                {
                  AsyncResult.forMessage(localCfu.mOnComplete, localAsyncResult4.result, localAsyncResult4.exception);
                  localCfu.mOnComplete.sendToTarget();
                  continue;
                  AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
                  if (IccVmNotSupportedException.class.isInstance(localAsyncResult3.exception))
                  {
                    storeVoiceMailNumber(this.mVmNumber);
                    localAsyncResult3.exception = null;
                  }
                  Message localMessage3 = (Message)localAsyncResult3.userObj;
                  if (localMessage3 != null)
                  {
                    AsyncResult.forMessage(localMessage3, localAsyncResult3.result, localAsyncResult3.exception);
                    localMessage3.sendToTarget();
                    continue;
                    AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
                    if (localAsyncResult2.exception == null)
                      handleCfuQueryResult((CallForwardInfo[])localAsyncResult2.result);
                    Message localMessage2 = (Message)localAsyncResult2.userObj;
                    if (localMessage2 != null)
                    {
                      AsyncResult.forMessage(localMessage2, localAsyncResult2.result, localAsyncResult2.exception);
                      localMessage2.sendToTarget();
                      continue;
                      setNetworkSelectionModeAutomatic((Message)((AsyncResult)paramMessage.obj).result);
                      continue;
                      processIccRecordEvents(((Integer)((AsyncResult)paramMessage.obj).result).intValue());
                      continue;
                      handleSetSelectNetwork((AsyncResult)paramMessage.obj);
                      continue;
                      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
                      if (localAsyncResult1.exception == null)
                        saveClirSetting(paramMessage.arg1);
                      Message localMessage1 = (Message)localAsyncResult1.userObj;
                      if (localMessage1 != null)
                      {
                        AsyncResult.forMessage(localMessage1, localAsyncResult1.result, localAsyncResult1.exception);
                        localMessage1.sendToTarget();
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  public boolean handlePinMmi(String paramString)
  {
    GsmMmiCode localGsmMmiCode = GsmMmiCode.newFromDialString(paramString, this, (UiccCardApplication)this.mUiccApplication.get());
    if ((localGsmMmiCode != null) && (localGsmMmiCode.isPinPukCommand()))
    {
      this.mPendingMMIs.add(localGsmMmiCode);
      this.mMmiRegistrants.notifyRegistrants(new AsyncResult(null, localGsmMmiCode, null));
      localGsmMmiCode.processCode();
    }
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected boolean isCfEnable(int paramInt)
  {
    int i = 1;
    if ((paramInt == i) || (paramInt == 3));
    while (true)
    {
      return i;
      i = 0;
    }
  }

  public boolean isCspPlmnEnabled()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    for (boolean bool = localIccRecords.isCspPlmnEnabled(); ; bool = false)
      return bool;
  }

  boolean isInCall()
  {
    Call.State localState1 = getForegroundCall().getState();
    Call.State localState2 = getBackgroundCall().getState();
    Call.State localState3 = getRingingCall().getState();
    if ((localState1.isAlive()) || (localState2.isAlive()) || (localState3.isAlive()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected void log(String paramString)
  {
    Rlog.d("GSMPhone", "[GSMPhone] " + paramString);
  }

  public void notifyCallForwardingIndicator()
  {
    this.mNotifier.notifyCallForwardingChanged(this);
  }

  void notifyDisconnect(Connection paramConnection)
  {
    this.mDisconnectRegistrants.notifyResult(paramConnection);
  }

  void notifyLocationChanged()
  {
    this.mNotifier.notifyCellLocation(this);
  }

  void notifyNewRingingConnection(Connection paramConnection)
  {
    super.notifyNewRingingConnectionP(paramConnection);
  }

  void notifyPhoneStateChanged()
  {
    this.mNotifier.notifyPhoneState(this);
  }

  void notifyPreciseCallStateChanged()
  {
    super.notifyPreciseCallStateChangedP();
  }

  void notifyServiceStateChanged(ServiceState paramServiceState)
  {
    super.notifyServiceStateChangedP(paramServiceState);
  }

  void notifySuppServiceFailed(Phone.SuppService paramSuppService)
  {
    this.mSuppServiceFailedRegistrants.notifyResult(paramSuppService);
  }

  void notifyUnknownConnection()
  {
    this.mUnknownConnectionRegistrants.notifyResult(this);
  }

  void onMMIDone(GsmMmiCode paramGsmMmiCode)
  {
    if ((this.mPendingMMIs.remove(paramGsmMmiCode)) || (paramGsmMmiCode.isUssdRequest()))
      this.mMmiCompleteRegistrants.notifyRegistrants(new AsyncResult(null, paramGsmMmiCode, null));
  }

  protected void onUpdateIccAvailability()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      UiccCardApplication localUiccCardApplication1 = this.mUiccController.getUiccCardApplication(1);
      UiccCardApplication localUiccCardApplication2 = (UiccCardApplication)this.mUiccApplication.get();
      if (localUiccCardApplication2 != localUiccCardApplication1)
      {
        if (localUiccCardApplication2 != null)
        {
          log("Removing stale icc objects.");
          if (this.mIccRecords.get() != null)
          {
            unregisterForSimRecordEvents();
            this.mSimPhoneBookIntManager.updateIccRecords(null);
          }
          this.mIccRecords.set(null);
          this.mUiccApplication.set(null);
        }
        if (localUiccCardApplication1 != null)
        {
          log("New Uicc application found");
          this.mUiccApplication.set(localUiccCardApplication1);
          this.mIccRecords.set(localUiccCardApplication1.getIccRecords());
          registerForSimRecordEvents();
          this.mSimPhoneBookIntManager.updateIccRecords((IccRecords)this.mIccRecords.get());
        }
      }
    }
  }

  public void registerForSuppServiceNotification(Handler paramHandler, int paramInt, Object paramObject)
  {
    this.mSsnRegistrants.addUnique(paramHandler, paramInt, paramObject);
    if (this.mSsnRegistrants.size() == 1)
      this.mCi.setSuppServiceNotifications(true, null);
  }

  public void rejectCall()
    throws CallStateException
  {
    this.mCT.rejectCall();
  }

  public void removeReferences()
  {
    Rlog.d("GSMPhone", "removeReferences");
    this.mSimulatedRadioControl = null;
    this.mSimPhoneBookIntManager = null;
    this.mSubInfo = null;
    this.mCT = null;
    this.mSST = null;
    super.removeReferences();
  }

  public void saveClirSetting(int paramInt)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getContext()).edit();
    localEditor.putInt("clir_key", paramInt);
    if (!localEditor.commit())
      Rlog.e("GSMPhone", "failed to commit CLIR preference");
  }

  public void selectNetworkManually(OperatorInfo paramOperatorInfo, Message paramMessage)
  {
    NetworkSelectMessage localNetworkSelectMessage = new NetworkSelectMessage(null);
    localNetworkSelectMessage.message = paramMessage;
    localNetworkSelectMessage.operatorNumeric = paramOperatorInfo.getOperatorNumeric();
    localNetworkSelectMessage.operatorAlphaLong = paramOperatorInfo.getOperatorAlphaLong();
    Message localMessage = obtainMessage(16, localNetworkSelectMessage);
    this.mCi.setNetworkSelectionModeManual(paramOperatorInfo.getOperatorNumeric(), localMessage);
  }

  public void sendBurstDtmf(String paramString)
  {
    Rlog.e("GSMPhone", "[GSMPhone] sendBurstDtmf() is a CDMA method");
  }

  public void sendDtmf(char paramChar)
  {
    if (!PhoneNumberUtils.is12Key(paramChar))
      Rlog.e("GSMPhone", "sendDtmf called with invalid character '" + paramChar + "'");
    while (true)
    {
      return;
      if (this.mCT.mState == PhoneConstants.State.OFFHOOK)
        this.mCi.sendDtmf(paramChar, null);
    }
  }

  public void sendUssdResponse(String paramString)
  {
    GsmMmiCode localGsmMmiCode = GsmMmiCode.newFromUssdUserInput(paramString, this, (UiccCardApplication)this.mUiccApplication.get());
    this.mPendingMMIs.add(localGsmMmiCode);
    this.mMmiRegistrants.notifyRegistrants(new AsyncResult(null, localGsmMmiCode, null));
    localGsmMmiCode.sendUssd(paramString);
  }

  public void setCallForwardingOption(int paramInt1, int paramInt2, String paramString, int paramInt3, Message paramMessage)
  {
    Cfu localCfu;
    int i;
    if ((isValidCommandInterfaceCFAction(paramInt1)) && (isValidCommandInterfaceCFReason(paramInt2)))
    {
      if (paramInt2 != 0)
        break label80;
      localCfu = new Cfu(paramString, paramMessage);
      if (!isCfEnable(paramInt1))
        break label74;
      i = 1;
    }
    label74: label80: for (Message localMessage = obtainMessage(12, i, 0, localCfu); ; localMessage = paramMessage)
    {
      this.mCi.setCallForward(paramInt1, paramInt2, 1, paramString, paramInt3, localMessage);
      return;
      i = 0;
      break;
    }
  }

  public void setCallWaiting(boolean paramBoolean, Message paramMessage)
  {
    this.mCi.setCallWaiting(paramBoolean, 1, paramMessage);
  }

  public void setCellBroadcastSmsConfig(int[] paramArrayOfInt, Message paramMessage)
  {
    Rlog.e("GSMPhone", "[GSMPhone] setCellBroadcastSmsConfig() is obsolete; use SmsManager");
    paramMessage.sendToTarget();
  }

  public void setDataRoamingEnabled(boolean paramBoolean)
  {
    this.mDcTracker.setDataOnRoamingEnabled(paramBoolean);
  }

  public void setLine1Number(String paramString1, String paramString2, Message paramMessage)
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null)
      localIccRecords.setMsisdnNumber(paramString1, paramString2, paramMessage);
  }

  public void setMute(boolean paramBoolean)
  {
    this.mCT.setMute(paramBoolean);
  }

  public void setNetworkSelectionModeAutomatic(Message paramMessage)
  {
    NetworkSelectMessage localNetworkSelectMessage = new NetworkSelectMessage(null);
    localNetworkSelectMessage.message = paramMessage;
    localNetworkSelectMessage.operatorNumeric = "";
    localNetworkSelectMessage.operatorAlphaLong = "";
    Message localMessage = obtainMessage(17, localNetworkSelectMessage);
    Rlog.d("GSMPhone", "wrapping and sending message to connect automatically");
    this.mCi.setNetworkSelectionModeAutomatic(localMessage);
  }

  public void setOnPostDialCharacter(Handler paramHandler, int paramInt, Object paramObject)
  {
    this.mPostDialHandler = new Registrant(paramHandler, paramInt, paramObject);
  }

  public void setOutgoingCallerIdDisplay(int paramInt, Message paramMessage)
  {
    this.mCi.setCLIR(paramInt, obtainMessage(18, paramInt, 0, paramMessage));
  }

  public void setRadioPower(boolean paramBoolean)
  {
    this.mSST.setRadioPower(paramBoolean);
  }

  public final void setSystemProperty(String paramString1, String paramString2)
  {
    super.setSystemProperty(paramString1, paramString2);
  }

  public void setVoiceMailNumber(String paramString1, String paramString2, Message paramMessage)
  {
    this.mVmNumber = paramString2;
    Message localMessage = obtainMessage(20, 0, 0, paramMessage);
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null)
      localIccRecords.setVoiceMailNumber(paramString1, this.mVmNumber, localMessage);
  }

  public void startDtmf(char paramChar)
  {
    if (!PhoneNumberUtils.is12Key(paramChar))
      Rlog.e("GSMPhone", "startDtmf called with invalid character '" + paramChar + "'");
    while (true)
    {
      return;
      this.mCi.startDtmf(paramChar, null);
    }
  }

  public void stopDtmf()
  {
    this.mCi.stopDtmf(null);
  }

  public void switchHoldingAndActive()
    throws CallStateException
  {
    this.mCT.switchWaitingOrHoldingAndActive();
  }

  protected void syncClirSetting()
  {
    int i = PreferenceManager.getDefaultSharedPreferences(getContext()).getInt("clir_key", -1);
    if (i >= 0)
      this.mCi.setCLIR(i, null);
  }

  public void unregisterForSuppServiceNotification(Handler paramHandler)
  {
    this.mSsnRegistrants.remove(paramHandler);
    if (this.mSsnRegistrants.size() == 0)
      this.mCi.setSuppServiceNotifications(false, null);
  }

  public boolean updateCurrentCarrierInProvider()
  {
    IccRecords localIccRecords = (IccRecords)this.mIccRecords.get();
    if (localIccRecords != null);
    while (true)
    {
      try
      {
        Uri localUri = Uri.withAppendedPath(Telephony.Carriers.CONTENT_URI, "current");
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("numeric", localIccRecords.getOperatorNumeric());
        this.mContext.getContentResolver().insert(localUri, localContentValues);
        bool = true;
        return bool;
      }
      catch (SQLException localSQLException)
      {
        Rlog.e("GSMPhone", "Can't store current operator", localSQLException);
      }
      boolean bool = false;
    }
  }

  public void updateServiceLocation()
  {
    this.mSST.enableSingleLocationUpdate();
  }

  private static class Cfu
  {
    final Message mOnComplete;
    final String mSetCfNumber;

    Cfu(String paramString, Message paramMessage)
    {
      this.mSetCfNumber = paramString;
      this.mOnComplete = paramMessage;
    }
  }

  private static class NetworkSelectMessage
  {
    public Message message;
    public String operatorAlphaLong;
    public String operatorNumeric;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GSMPhone
 * JD-Core Version:    0.6.2
 */