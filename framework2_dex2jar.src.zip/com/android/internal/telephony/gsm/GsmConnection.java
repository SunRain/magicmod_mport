package com.android.internal.telephony.gsm;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Registrant;
import android.os.SystemClock;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.text.TextUtils;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.Connection.DisconnectCause;
import com.android.internal.telephony.Connection.PostDialState;
import com.android.internal.telephony.DriverCall;
import com.android.internal.telephony.DriverCall.State;
import com.android.internal.telephony.PhoneConstants;
import com.android.internal.telephony.RestrictedState;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.UUSInfo;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;

public class GsmConnection extends Connection
{
  private static final boolean DBG = true;
  static final int EVENT_DTMF_DONE = 1;
  static final int EVENT_NEXT_POST_DIAL = 3;
  static final int EVENT_PAUSE_DONE = 2;
  static final int EVENT_WAKE_LOCK_TIMEOUT = 4;
  private static final String LOG_TAG = "GsmConnection";
  static final int PAUSE_DELAY_MILLIS = 3000;
  static final int WAKE_LOCK_TIMEOUT_MILLIS = 60000;
  String mAddress;
  Connection.DisconnectCause mCause = Connection.DisconnectCause.NOT_DISCONNECTED;
  long mConnectTime;
  long mConnectTimeReal;
  long mCreateTime;
  String mDialString;
  long mDisconnectTime;
  boolean mDisconnected;
  long mDuration;
  Handler mHandler;
  long mHoldingStartTime;
  int mIndex;
  boolean mIsIncoming;
  int mNextPostDialChar;
  int mNumberPresentation = PhoneConstants.PRESENTATION_ALLOWED;
  GsmCallTracker mOwner;
  GsmCall mParent;
  private PowerManager.WakeLock mPartialWakeLock;
  Connection.PostDialState mPostDialState = Connection.PostDialState.NOT_STARTED;
  String mPostDialString;
  UUSInfo mUusInfo;

  GsmConnection(Context paramContext, DriverCall paramDriverCall, GsmCallTracker paramGsmCallTracker, int paramInt)
  {
    createWakeLock(paramContext);
    acquireWakeLock();
    this.mOwner = paramGsmCallTracker;
    this.mHandler = new MyHandler(this.mOwner.getLooper());
    this.mAddress = paramDriverCall.number;
    this.mIsIncoming = paramDriverCall.isMT;
    this.mCreateTime = System.currentTimeMillis();
    this.mCnapName = paramDriverCall.name;
    this.mCnapNamePresentation = paramDriverCall.namePresentation;
    this.mNumberPresentation = paramDriverCall.numberPresentation;
    this.mUusInfo = paramDriverCall.uusInfo;
    this.mIndex = paramInt;
    this.mParent = parentFromDCState(paramDriverCall.state);
    this.mParent.attach(this, paramDriverCall);
  }

  GsmConnection(Context paramContext, String paramString, GsmCallTracker paramGsmCallTracker, GsmCall paramGsmCall)
  {
    createWakeLock(paramContext);
    acquireWakeLock();
    this.mOwner = paramGsmCallTracker;
    this.mHandler = new MyHandler(this.mOwner.getLooper());
    this.mDialString = paramString;
    this.mAddress = PhoneNumberUtils.extractNetworkPortionAlt(paramString);
    this.mPostDialString = PhoneNumberUtils.extractPostDialPortion(paramString);
    this.mIndex = -1;
    this.mIsIncoming = false;
    this.mCnapName = null;
    this.mCnapNamePresentation = PhoneConstants.PRESENTATION_ALLOWED;
    this.mNumberPresentation = PhoneConstants.PRESENTATION_ALLOWED;
    this.mCreateTime = System.currentTimeMillis();
    this.mParent = paramGsmCall;
    paramGsmCall.attachFake(this, Call.State.DIALING);
  }

  private void acquireWakeLock()
  {
    log("acquireWakeLock");
    this.mPartialWakeLock.acquire();
  }

  private void createWakeLock(Context paramContext)
  {
    this.mPartialWakeLock = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "GsmConnection");
  }

  static boolean equalsHandlesNulls(Object paramObject1, Object paramObject2)
  {
    boolean bool;
    if (paramObject1 == null)
      if (paramObject2 == null)
        bool = true;
    while (true)
    {
      return bool;
      bool = false;
      continue;
      bool = paramObject1.equals(paramObject2);
    }
  }

  private boolean isConnectingInOrOut()
  {
    if ((this.mParent == null) || (this.mParent == this.mOwner.mRingingCall) || (this.mParent.mState == Call.State.DIALING) || (this.mParent.mState == Call.State.ALERTING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void log(String paramString)
  {
    Rlog.d("GsmConnection", "[GSMConn] " + paramString);
  }

  private GsmCall parentFromDCState(DriverCall.State paramState)
  {
    GsmCall localGsmCall;
    switch (1.$SwitchMap$com$android$internal$telephony$DriverCall$State[paramState.ordinal()])
    {
    default:
      throw new RuntimeException("illegal call state: " + paramState);
    case 1:
    case 2:
    case 3:
      localGsmCall = this.mOwner.mForegroundCall;
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      return localGsmCall;
      localGsmCall = this.mOwner.mBackgroundCall;
      continue;
      localGsmCall = this.mOwner.mRingingCall;
    }
  }

  private void processNextPostDialChar()
  {
    if (this.mPostDialState == Connection.PostDialState.CANCELLED);
    while (true)
    {
      return;
      char c;
      if ((this.mPostDialString == null) || (this.mPostDialString.length() <= this.mNextPostDialChar))
      {
        setPostDialState(Connection.PostDialState.COMPLETE);
        c = '\000';
      }
      do
      {
        Registrant localRegistrant = this.mOwner.mPhone.mPostDialHandler;
        if (localRegistrant == null)
          break;
        Message localMessage = localRegistrant.messageForRegistrant();
        if (localMessage == null)
          break;
        Connection.PostDialState localPostDialState = this.mPostDialState;
        AsyncResult localAsyncResult = AsyncResult.forMessage(localMessage);
        localAsyncResult.result = this;
        localAsyncResult.userObj = localPostDialState;
        localMessage.arg1 = c;
        localMessage.sendToTarget();
        break;
        setPostDialState(Connection.PostDialState.STARTED);
        String str = this.mPostDialString;
        int i = this.mNextPostDialChar;
        this.mNextPostDialChar = (i + 1);
        c = str.charAt(i);
      }
      while (processPostDialChar(c));
      this.mHandler.obtainMessage(3).sendToTarget();
      Rlog.e("GSM", "processNextPostDialChar: c=" + c + " isn't valid!");
    }
  }

  private boolean processPostDialChar(char paramChar)
  {
    int i = 1;
    if (PhoneNumberUtils.is12Key(paramChar))
      this.mOwner.mCi.sendDtmf(paramChar, this.mHandler.obtainMessage(i));
    while (true)
    {
      return i;
      if (paramChar == ',')
        this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(2), 3000L);
      else if (paramChar == ';')
        setPostDialState(Connection.PostDialState.WAIT);
      else if (paramChar == 'N')
        setPostDialState(Connection.PostDialState.WILD);
      else
        int j = 0;
    }
  }

  private void releaseWakeLock()
  {
    synchronized (this.mPartialWakeLock)
    {
      if (this.mPartialWakeLock.isHeld())
      {
        log("releaseWakeLock");
        this.mPartialWakeLock.release();
      }
      return;
    }
  }

  private void setPostDialState(Connection.PostDialState paramPostDialState)
  {
    if ((this.mPostDialState != Connection.PostDialState.STARTED) && (paramPostDialState == Connection.PostDialState.STARTED))
    {
      acquireWakeLock();
      Message localMessage = this.mHandler.obtainMessage(4);
      this.mHandler.sendMessageDelayed(localMessage, 60000L);
    }
    while (true)
    {
      this.mPostDialState = paramPostDialState;
      return;
      if ((this.mPostDialState == Connection.PostDialState.STARTED) && (paramPostDialState != Connection.PostDialState.STARTED))
      {
        this.mHandler.removeMessages(4);
        releaseWakeLock();
      }
    }
  }

  public void cancelPostDial()
  {
    setPostDialState(Connection.PostDialState.CANCELLED);
  }

  boolean compareTo(DriverCall paramDriverCall)
  {
    boolean bool = true;
    if ((!this.mIsIncoming) && (!paramDriverCall.isMT));
    while (true)
    {
      return bool;
      String str = PhoneNumberUtils.stringFromStringAndTOA(paramDriverCall.number, paramDriverCall.TOA);
      if ((this.mIsIncoming != paramDriverCall.isMT) || (!equalsHandlesNulls(this.mAddress, str)))
        bool = false;
    }
  }

  Connection.DisconnectCause disconnectCauseFromCode(int paramInt)
  {
    GSMPhone localGSMPhone;
    int i;
    IccCardApplicationStatus.AppState localAppState;
    Connection.DisconnectCause localDisconnectCause;
    switch (paramInt)
    {
    default:
      localGSMPhone = this.mOwner.mPhone;
      i = localGSMPhone.getServiceState().getState();
      UiccCardApplication localUiccCardApplication = UiccController.getInstance().getUiccCardApplication(1);
      if (localUiccCardApplication != null)
      {
        localAppState = localUiccCardApplication.getState();
        if (i != 3)
          break label200;
        localDisconnectCause = Connection.DisconnectCause.POWER_OFF;
      }
      break;
    case 17:
    case 34:
    case 41:
    case 42:
    case 44:
    case 49:
    case 58:
    case 68:
    case 240:
    case 241:
    case 1:
    }
    while (true)
    {
      return localDisconnectCause;
      localDisconnectCause = Connection.DisconnectCause.BUSY;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CONGESTION;
      continue;
      localDisconnectCause = Connection.DisconnectCause.LIMIT_EXCEEDED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.CALL_BARRED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.FDN_BLOCKED;
      continue;
      localDisconnectCause = Connection.DisconnectCause.UNOBTAINABLE_NUMBER;
      continue;
      localAppState = IccCardApplicationStatus.AppState.APPSTATE_UNKNOWN;
      break;
      label200: if ((i == 1) || (i == 2))
        localDisconnectCause = Connection.DisconnectCause.OUT_OF_SERVICE;
      else if (localAppState != IccCardApplicationStatus.AppState.APPSTATE_READY)
        localDisconnectCause = Connection.DisconnectCause.ICC_ERROR;
      else if (paramInt == 65535)
      {
        if (localGSMPhone.mSST.mRestrictedState.isCsRestricted())
          localDisconnectCause = Connection.DisconnectCause.CS_RESTRICTED;
        else if (localGSMPhone.mSST.mRestrictedState.isCsEmergencyRestricted())
          localDisconnectCause = Connection.DisconnectCause.CS_RESTRICTED_EMERGENCY;
        else if (localGSMPhone.mSST.mRestrictedState.isCsNormalRestricted())
          localDisconnectCause = Connection.DisconnectCause.CS_RESTRICTED_NORMAL;
        else
          localDisconnectCause = Connection.DisconnectCause.ERROR_UNSPECIFIED;
      }
      else if (paramInt == 16)
        localDisconnectCause = Connection.DisconnectCause.NORMAL;
      else
        localDisconnectCause = Connection.DisconnectCause.ERROR_UNSPECIFIED;
    }
  }

  public void dispose()
  {
  }

  void fakeHoldBeforeDial()
  {
    if (this.mParent != null)
      this.mParent.detach(this);
    this.mParent = this.mOwner.mBackgroundCall;
    this.mParent.attachFake(this, Call.State.HOLDING);
    onStartedHolding();
  }

  protected void finalize()
  {
    if (this.mPartialWakeLock.isHeld())
      Rlog.e("GsmConnection", "[GSMConn] UNEXPECTED; mPartialWakeLock is held when finalizing.");
    releaseWakeLock();
  }

  public String getAddress()
  {
    return this.mAddress;
  }

  public GsmCall getCall()
  {
    return this.mParent;
  }

  public long getConnectTime()
  {
    return this.mConnectTime;
  }

  public long getCreateTime()
  {
    return this.mCreateTime;
  }

  public Connection.DisconnectCause getDisconnectCause()
  {
    return this.mCause;
  }

  public long getDisconnectTime()
  {
    return this.mDisconnectTime;
  }

  public long getDurationMillis()
  {
    long l = 0L;
    if (this.mConnectTimeReal == l);
    while (true)
    {
      return l;
      if (this.mDuration == l)
        l = SystemClock.elapsedRealtime() - this.mConnectTimeReal;
      else
        l = this.mDuration;
    }
  }

  int getGSMIndex()
    throws CallStateException
  {
    if (this.mIndex >= 0)
      return 1 + this.mIndex;
    throw new CallStateException("GSM index not yet assigned");
  }

  public long getHoldDurationMillis()
  {
    if (getState() != Call.State.HOLDING);
    for (long l = 0L; ; l = SystemClock.elapsedRealtime() - this.mHoldingStartTime)
      return l;
  }

  public int getNumberPresentation()
  {
    return this.mNumberPresentation;
  }

  public Connection.PostDialState getPostDialState()
  {
    return this.mPostDialState;
  }

  public String getRemainingPostDialString()
  {
    if ((this.mPostDialState == Connection.PostDialState.CANCELLED) || (this.mPostDialState == Connection.PostDialState.COMPLETE) || (this.mPostDialString == null) || (this.mPostDialString.length() <= this.mNextPostDialChar));
    for (String str = ""; ; str = this.mPostDialString.substring(this.mNextPostDialChar))
      return str;
  }

  public Call.State getState()
  {
    if (this.mDisconnected);
    for (Call.State localState = Call.State.DISCONNECTED; ; localState = super.getState())
      return localState;
  }

  public UUSInfo getUUSInfo()
  {
    return this.mUusInfo;
  }

  public void hangup()
    throws CallStateException
  {
    if (!this.mDisconnected)
    {
      this.mOwner.hangup(this);
      return;
    }
    throw new CallStateException("disconnected");
  }

  public boolean isIncoming()
  {
    return this.mIsIncoming;
  }

  void onConnectedInOrOut()
  {
    this.mConnectTime = System.currentTimeMillis();
    this.mConnectTimeReal = SystemClock.elapsedRealtime();
    this.mDuration = 0L;
    log("onConnectedInOrOut: connectTime=" + this.mConnectTime);
    if (!this.mIsIncoming)
      processNextPostDialChar();
    releaseWakeLock();
  }

  boolean onDisconnect(Connection.DisconnectCause paramDisconnectCause)
  {
    boolean bool = false;
    this.mCause = paramDisconnectCause;
    if (!this.mDisconnected)
    {
      this.mIndex = -1;
      this.mDisconnectTime = System.currentTimeMillis();
      this.mDuration = (SystemClock.elapsedRealtime() - this.mConnectTimeReal);
      this.mDisconnected = true;
      Rlog.d("GsmConnection", "onDisconnect: cause=" + paramDisconnectCause);
      this.mOwner.mPhone.notifyDisconnect(this);
      if (this.mParent != null)
        bool = this.mParent.connectionDisconnected(this);
    }
    releaseWakeLock();
    return bool;
  }

  void onHangupLocal()
  {
    this.mCause = Connection.DisconnectCause.LOCAL;
  }

  void onRemoteDisconnect(int paramInt)
  {
    onDisconnect(disconnectCauseFromCode(paramInt));
  }

  void onStartedHolding()
  {
    this.mHoldingStartTime = SystemClock.elapsedRealtime();
  }

  public void proceedAfterWaitChar()
  {
    if (this.mPostDialState != Connection.PostDialState.WAIT)
      Rlog.w("GsmConnection", "GsmConnection.proceedAfterWaitChar(): Expected getPostDialState() to be WAIT but was " + this.mPostDialState);
    while (true)
    {
      return;
      setPostDialState(Connection.PostDialState.STARTED);
      processNextPostDialChar();
    }
  }

  public void proceedAfterWildChar(String paramString)
  {
    if (this.mPostDialState != Connection.PostDialState.WILD)
      Rlog.w("GsmConnection", "GsmConnection.proceedAfterWaitChar(): Expected getPostDialState() to be WILD but was " + this.mPostDialState);
    while (true)
    {
      return;
      setPostDialState(Connection.PostDialState.STARTED);
      StringBuilder localStringBuilder = new StringBuilder(paramString);
      localStringBuilder.append(this.mPostDialString.substring(this.mNextPostDialChar));
      this.mPostDialString = localStringBuilder.toString();
      this.mNextPostDialChar = 0;
      log("proceedAfterWildChar: new postDialString is " + this.mPostDialString);
      processNextPostDialChar();
    }
  }

  public void separate()
    throws CallStateException
  {
    if (!this.mDisconnected)
    {
      this.mOwner.separate(this);
      return;
    }
    throw new CallStateException("disconnected");
  }

  boolean update(DriverCall paramDriverCall)
  {
    boolean bool1 = true;
    int i = 0;
    boolean bool2 = isConnectingInOrOut();
    boolean bool3;
    label93: boolean bool5;
    StringBuilder localStringBuilder;
    if (getState() == Call.State.HOLDING)
    {
      bool3 = bool1;
      GsmCall localGsmCall = parentFromDCState(paramDriverCall.state);
      if (!equalsHandlesNulls(this.mAddress, paramDriverCall.number))
      {
        log("update: phone # changed!");
        this.mAddress = paramDriverCall.number;
        i = 1;
      }
      if (!TextUtils.isEmpty(paramDriverCall.name))
        break label321;
      if (!TextUtils.isEmpty(this.mCnapName))
      {
        i = 1;
        this.mCnapName = "";
      }
      log("--dssds----" + this.mCnapName);
      this.mCnapNamePresentation = paramDriverCall.namePresentation;
      this.mNumberPresentation = paramDriverCall.numberPresentation;
      if (localGsmCall == this.mParent)
        break label348;
      if (this.mParent != null)
        this.mParent.detach(this);
      localGsmCall.attach(this, paramDriverCall);
      this.mParent = localGsmCall;
      bool5 = true;
      localStringBuilder = new StringBuilder().append("update: parent=").append(this.mParent).append(", hasNewParent=");
      if (localGsmCall == this.mParent)
        break label380;
    }
    while (true)
    {
      log(bool1 + ", wasConnectingInOrOut=" + bool2 + ", wasHolding=" + bool3 + ", isConnectingInOrOut=" + isConnectingInOrOut() + ", changed=" + bool5);
      if ((bool2) && (!isConnectingInOrOut()))
        onConnectedInOrOut();
      if ((bool5) && (!bool3) && (getState() == Call.State.HOLDING))
        onStartedHolding();
      return bool5;
      bool3 = false;
      break;
      label321: if (paramDriverCall.name.equals(this.mCnapName))
        break label93;
      i = 1;
      this.mCnapName = paramDriverCall.name;
      break label93;
      label348: boolean bool4 = this.mParent.update(this, paramDriverCall);
      if ((i != 0) || (bool4));
      for (bool5 = bool1; ; bool5 = false)
        break;
      label380: bool1 = false;
    }
  }

  class MyHandler extends Handler
  {
    MyHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      }
      while (true)
      {
        return;
        GsmConnection.this.processNextPostDialChar();
        continue;
        GsmConnection.this.releaseWakeLock();
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmConnection
 * JD-Core Version:    0.6.2
 */