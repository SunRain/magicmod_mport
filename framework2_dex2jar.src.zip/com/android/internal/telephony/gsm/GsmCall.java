package com.android.internal.telephony.gsm;

import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.DriverCall;
import com.android.internal.telephony.DriverCall.State;
import com.android.internal.telephony.Phone;
import java.util.ArrayList;
import java.util.List;

class GsmCall extends Call
{
  GsmCallTracker mOwner;

  GsmCall(GsmCallTracker paramGsmCallTracker)
  {
    this.mOwner = paramGsmCallTracker;
  }

  static Call.State stateFromDCState(DriverCall.State paramState)
  {
    Call.State localState;
    switch (1.$SwitchMap$com$android$internal$telephony$DriverCall$State[paramState.ordinal()])
    {
    default:
      throw new RuntimeException("illegal call state:" + paramState);
    case 1:
      localState = Call.State.ACTIVE;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      return localState;
      localState = Call.State.HOLDING;
      continue;
      localState = Call.State.DIALING;
      continue;
      localState = Call.State.ALERTING;
      continue;
      localState = Call.State.INCOMING;
      continue;
      localState = Call.State.WAITING;
    }
  }

  void attach(Connection paramConnection, DriverCall paramDriverCall)
  {
    this.mConnections.add(paramConnection);
    this.mState = stateFromDCState(paramDriverCall.state);
  }

  void attachFake(Connection paramConnection, Call.State paramState)
  {
    this.mConnections.add(paramConnection);
    this.mState = paramState;
  }

  void clearDisconnected()
  {
    for (int i = -1 + this.mConnections.size(); i >= 0; i--)
      if (((GsmConnection)this.mConnections.get(i)).getState() == Call.State.DISCONNECTED)
        this.mConnections.remove(i);
    if (this.mConnections.size() == 0)
      this.mState = Call.State.IDLE;
  }

  boolean connectionDisconnected(GsmConnection paramGsmConnection)
  {
    int j;
    if (this.mState != Call.State.DISCONNECTED)
    {
      int i = 1;
      j = 0;
      int k = this.mConnections.size();
      if (j < k)
      {
        if (((Connection)this.mConnections.get(j)).getState() != Call.State.DISCONNECTED)
          i = 0;
      }
      else
      {
        if (i == 0)
          break label75;
        this.mState = Call.State.DISCONNECTED;
      }
    }
    label75: for (boolean bool = true; ; bool = false)
    {
      return bool;
      j++;
      break;
    }
  }

  void detach(GsmConnection paramGsmConnection)
  {
    this.mConnections.remove(paramGsmConnection);
    if (this.mConnections.size() == 0)
      this.mState = Call.State.IDLE;
  }

  public void dispose()
  {
  }

  public List<Connection> getConnections()
  {
    return this.mConnections;
  }

  public Phone getPhone()
  {
    return this.mOwner.mPhone;
  }

  public void hangup()
    throws CallStateException
  {
    this.mOwner.hangup(this);
  }

  boolean isFull()
  {
    if (this.mConnections.size() == 5);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isMultiparty()
  {
    int i = 1;
    if (this.mConnections.size() > i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  void onHangupLocal()
  {
    int i = 0;
    int j = this.mConnections.size();
    while (i < j)
    {
      ((GsmConnection)this.mConnections.get(i)).onHangupLocal();
      i++;
    }
    this.mState = Call.State.DISCONNECTING;
  }

  public String toString()
  {
    return this.mState.toString();
  }

  boolean update(GsmConnection paramGsmConnection, DriverCall paramDriverCall)
  {
    boolean bool = false;
    Call.State localState = stateFromDCState(paramDriverCall.state);
    if (localState != this.mState)
    {
      this.mState = localState;
      bool = true;
    }
    return bool;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmCall
 * JD-Core Version:    0.6.2
 */