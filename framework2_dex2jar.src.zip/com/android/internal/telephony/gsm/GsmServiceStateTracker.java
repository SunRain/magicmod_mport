package com.android.internal.telephony.gsm;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.os.AsyncResult;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.RegistrantList;
import android.os.SystemClock;
import android.os.SystemProperties;
import android.os.UserHandle;
import android.provider.Settings.Global;
import android.provider.Settings.SettingNotFoundException;
import android.telephony.CellIdentityGsm;
import android.telephony.CellIdentityLte;
import android.telephony.CellIdentityWcdma;
import android.telephony.CellInfo;
import android.telephony.CellInfoGsm;
import android.telephony.CellInfoLte;
import android.telephony.CellInfoWcdma;
import android.telephony.CellLocation;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.SignalStrength;
import android.telephony.gsm.GsmCellLocation;
import android.text.TextUtils;
import android.util.EventLog;
import android.util.TimeUtils;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.CommandsInterface.RadioState;
import com.android.internal.telephony.Injector.ServiceStateTrackerHook;
import com.android.internal.telephony.MccTable;
import com.android.internal.telephony.Phone;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.RestrictedState;
import com.android.internal.telephony.ServiceStateTracker;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

final class GsmServiceStateTracker extends ServiceStateTracker
{
  static final int CS_DISABLED = 1004;
  static final int CS_EMERGENCY_ENABLED = 1006;
  static final int CS_ENABLED = 1003;
  static final int CS_NORMAL_ENABLED = 1005;
  static final int CS_NOTIFICATION = 999;
  private static final String LOG_TAG = "GsmSST";
  static final int PS_DISABLED = 1002;
  static final int PS_ENABLED = 1001;
  static final int PS_NOTIFICATION = 888;
  private static final boolean VDBG = false;
  private static final String WAKELOCK_TAG = "ServiceStateTracker";
  private ContentObserver mAutoTimeObserver = new ContentObserver(new Handler())
  {
    public void onChange(boolean paramAnonymousBoolean)
    {
      Rlog.i("GsmServiceStateTracker", "Auto time state changed");
      GsmServiceStateTracker.this.revertToNitzTime();
    }
  };
  private ContentObserver mAutoTimeZoneObserver = new ContentObserver(new Handler())
  {
    public void onChange(boolean paramAnonymousBoolean)
    {
      Rlog.i("GsmServiceStateTracker", "Auto time zone state changed");
      GsmServiceStateTracker.this.revertToNitzTimeZone();
    }
  };
  GsmCellLocation mCellLoc;
  private ContentResolver mCr;
  private String mCurPlmn = null;
  private boolean mCurShowPlmn = false;
  private boolean mCurShowSpn = false;
  private String mCurSpn = null;
  private boolean mDataRoaming = false;
  private boolean mEmergencyOnly = false;
  private boolean mGotCountryCode = false;
  private boolean mGsmRoaming = false;
  private BroadcastReceiver mIntentReceiver = new BroadcastReceiver()
  {
    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      if (!GsmServiceStateTracker.this.mPhone.mIsTheCurrentActivePhone)
        Rlog.e("GsmSST", "Received Intent " + paramAnonymousIntent + " while being destroyed. Ignoring.");
      while (true)
      {
        return;
        if (paramAnonymousIntent.getAction().equals("android.intent.action.LOCALE_CHANGED"))
          GsmServiceStateTracker.this.updateSpnDisplay();
      }
    }
  };
  private int mMaxDataCalls = 1;
  private boolean mNeedFixZoneAfterNitz = false;
  GsmCellLocation mNewCellLoc;
  private int mNewMaxDataCalls = 1;
  private int mNewReasonDataDenied = -1;
  private boolean mNitzUpdatedTime = false;
  private Notification mNotification;
  GSMPhone mPhone;
  int mPreferredNetworkType;
  private int mReasonDataDenied = -1;
  private boolean mReportedGprsNoReg = false;
  long mSavedAtTime;
  long mSavedTime;
  String mSavedTimeZone;
  private boolean mStartedGprsRegCheck = false;
  private PowerManager.WakeLock mWakeLock;
  private boolean mZoneDst;
  private int mZoneOffset;
  private long mZoneTime;

  public GsmServiceStateTracker(GSMPhone paramGSMPhone)
  {
    super(paramGSMPhone, paramGSMPhone.mCi, new CellInfoGsm());
    this.mPhone = paramGSMPhone;
    this.mCellLoc = new GsmCellLocation();
    this.mNewCellLoc = new GsmCellLocation();
    this.mWakeLock = ((PowerManager)paramGSMPhone.getContext().getSystemService("power")).newWakeLock(1, "ServiceStateTracker");
    this.mCi.registerForAvailable(this, 13, null);
    this.mCi.registerForRadioStateChanged(this, 1, null);
    this.mCi.registerForVoiceNetworkStateChanged(this, 2, null);
    this.mCi.setOnNITZTime(this, 11, null);
    this.mCi.setOnRestrictedStateChanged(this, 23, null);
    if (Settings.Global.getInt(paramGSMPhone.getContext().getContentResolver(), "airplane_mode_on", 0) <= 0)
      bool = true;
    this.mDesiredPowerState = bool;
    this.mCr = paramGSMPhone.getContext().getContentResolver();
    this.mCr.registerContentObserver(Settings.Global.getUriFor("auto_time"), true, this.mAutoTimeObserver);
    this.mCr.registerContentObserver(Settings.Global.getUriFor("auto_time_zone"), true, this.mAutoTimeZoneObserver);
    setSignalStrengthDefaultValues();
    IntentFilter localIntentFilter = new IntentFilter();
    localIntentFilter.addAction("android.intent.action.LOCALE_CHANGED");
    paramGSMPhone.getContext().registerReceiver(this.mIntentReceiver, localIntentFilter);
    paramGSMPhone.notifyOtaspChanged(3);
  }

  private boolean currentMccEqualsSimMcc(ServiceState paramServiceState)
  {
    String str1 = SystemProperties.get("gsm.sim.operator.numeric", "");
    String str2 = paramServiceState.getOperatorNumeric();
    boolean bool1 = true;
    try
    {
      boolean bool2 = str1.substring(0, 3).equals(str2.substring(0, 3));
      bool1 = bool2;
      label39: return bool1;
    }
    catch (Exception localException)
    {
      break label39;
    }
  }

  private TimeZone findTimeZone(int paramInt, boolean paramBoolean, long paramLong)
  {
    int i = paramInt;
    if (paramBoolean)
      i += 4480;
    String[] arrayOfString = TimeZone.getAvailableIDs(i);
    Object localObject = null;
    Date localDate = new Date(paramLong);
    int j = arrayOfString.length;
    for (int k = 0; ; k++)
      if (k < j)
      {
        TimeZone localTimeZone = TimeZone.getTimeZone(arrayOfString[k]);
        if ((localTimeZone.getOffset(paramLong) == paramInt) && (localTimeZone.inDaylightTime(localDate) == paramBoolean))
          localObject = localTimeZone;
      }
      else
      {
        return localObject;
      }
  }

  private boolean getAutoTime()
  {
    boolean bool = true;
    try
    {
      int i = Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "auto_time");
      if (i > 0);
      while (true)
      {
        label22: return bool;
        bool = false;
      }
    }
    catch (Settings.SettingNotFoundException localSettingNotFoundException)
    {
      break label22;
    }
  }

  private boolean getAutoTimeZone()
  {
    boolean bool = true;
    try
    {
      int i = Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "auto_time_zone");
      if (i > 0);
      while (true)
      {
        label22: return bool;
        bool = false;
      }
    }
    catch (Settings.SettingNotFoundException localSettingNotFoundException)
    {
      break label22;
    }
  }

  private TimeZone getNitzTimeZone(int paramInt, boolean paramBoolean, long paramLong)
  {
    TimeZone localTimeZone = findTimeZone(paramInt, paramBoolean, paramLong);
    boolean bool;
    StringBuilder localStringBuilder;
    if (localTimeZone == null)
    {
      if (!paramBoolean)
      {
        bool = true;
        localTimeZone = findTimeZone(paramInt, bool, paramLong);
      }
    }
    else
    {
      localStringBuilder = new StringBuilder().append("getNitzTimeZone returning ");
      if (localTimeZone != null)
        break label78;
    }
    label78: for (Object localObject = localTimeZone; ; localObject = localTimeZone.getID())
    {
      log(localObject);
      return localTimeZone;
      bool = false;
      break;
    }
  }

  private boolean isGprsConsistent(int paramInt1, int paramInt2)
  {
    if ((paramInt2 != 0) || (paramInt1 == 0));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isOperatorConsideredNonRoaming(ServiceState paramServiceState)
  {
    boolean bool = false;
    String str = paramServiceState.getOperatorNumeric();
    String[] arrayOfString = this.mPhone.getContext().getResources().getStringArray(17236013);
    if ((arrayOfString.length == 0) || (str == null));
    label73: 
    while (true)
    {
      return bool;
      int i = arrayOfString.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label73;
        if (str.startsWith(arrayOfString[j]))
        {
          bool = true;
          break;
        }
      }
    }
  }

  private boolean isSameNamedOperatorConsideredRoaming(ServiceState paramServiceState)
  {
    boolean bool = false;
    String str = paramServiceState.getOperatorNumeric();
    String[] arrayOfString = this.mPhone.getContext().getResources().getStringArray(17236014);
    if ((arrayOfString.length == 0) || (str == null));
    while (true)
    {
      return bool;
      if ((arrayOfString.length < 0) && (str.startsWith(arrayOfString[0])))
        bool = true;
    }
  }

  private boolean isSameNamedOperators(ServiceState paramServiceState)
  {
    boolean bool1 = true;
    String str1 = SystemProperties.get("gsm.sim.operator.alpha", "empty");
    String str2 = paramServiceState.getOperatorAlphaLong();
    String str3 = paramServiceState.getOperatorAlphaShort();
    boolean bool2;
    boolean bool3;
    if ((str2 != null) && (str1.equals(str2)))
    {
      bool2 = bool1;
      if ((str3 == null) || (!str1.equals(str3)))
        break label84;
      bool3 = bool1;
      label58: if ((!currentMccEqualsSimMcc(paramServiceState)) || ((!bool2) && (!bool3)))
        break label90;
    }
    while (true)
    {
      return bool1;
      bool2 = false;
      break;
      label84: bool3 = false;
      break label58;
      label90: bool1 = false;
    }
  }

  private void onRestrictedStateChanged(AsyncResult paramAsyncResult)
  {
    boolean bool1 = true;
    RestrictedState localRestrictedState = new RestrictedState();
    log("onRestrictedStateChanged: E rs " + this.mRestrictedState);
    boolean bool2;
    boolean bool3;
    if (paramAsyncResult.exception == null)
    {
      int i = ((int[])(int[])paramAsyncResult.result)[0];
      if (((i & 0x1) == 0) && ((i & 0x4) == 0))
        break label249;
      bool2 = bool1;
      localRestrictedState.setCsEmergencyRestricted(bool2);
      if ((this.mUiccApplcation != null) && (this.mUiccApplcation.getState() == IccCardApplicationStatus.AppState.APPSTATE_READY))
      {
        if (((i & 0x2) == 0) && ((i & 0x4) == 0))
          break label255;
        bool3 = bool1;
        label118: localRestrictedState.setCsNormalRestricted(bool3);
        if ((i & 0x10) == 0)
          break label261;
        label132: localRestrictedState.setPsRestricted(bool1);
      }
      log("onRestrictedStateChanged: new rs " + localRestrictedState);
      if ((this.mRestrictedState.isPsRestricted()) || (!localRestrictedState.isPsRestricted()))
        break label266;
      this.mPsRestrictEnabledRegistrants.notifyRegistrants();
      setNotification(1001);
      label192: if (!this.mRestrictedState.isCsRestricted())
        break label334;
      if (localRestrictedState.isCsRestricted())
        break label300;
      setNotification(1004);
    }
    while (true)
    {
      this.mRestrictedState = localRestrictedState;
      log("onRestrictedStateChanged: X rs " + this.mRestrictedState);
      return;
      label249: bool2 = false;
      break;
      label255: bool3 = false;
      break label118;
      label261: bool1 = false;
      break label132;
      label266: if ((!this.mRestrictedState.isPsRestricted()) || (localRestrictedState.isPsRestricted()))
        break label192;
      this.mPsRestrictDisabledRegistrants.notifyRegistrants();
      setNotification(1002);
      break label192;
      label300: if (!localRestrictedState.isCsNormalRestricted())
      {
        setNotification(1006);
      }
      else if (!localRestrictedState.isCsEmergencyRestricted())
      {
        setNotification(1005);
        continue;
        label334: if ((this.mRestrictedState.isCsEmergencyRestricted()) && (!this.mRestrictedState.isCsNormalRestricted()))
        {
          if (!localRestrictedState.isCsRestricted())
            setNotification(1004);
          else if (localRestrictedState.isCsRestricted())
            setNotification(1003);
          else if (localRestrictedState.isCsNormalRestricted())
            setNotification(1005);
        }
        else if ((!this.mRestrictedState.isCsEmergencyRestricted()) && (this.mRestrictedState.isCsNormalRestricted()))
        {
          if (!localRestrictedState.isCsRestricted())
            setNotification(1004);
          else if (localRestrictedState.isCsRestricted())
            setNotification(1003);
          else if (localRestrictedState.isCsEmergencyRestricted())
            setNotification(1006);
        }
        else if (localRestrictedState.isCsRestricted())
          setNotification(1003);
        else if (localRestrictedState.isCsEmergencyRestricted())
          setNotification(1006);
        else if (localRestrictedState.isCsNormalRestricted())
          setNotification(1005);
      }
    }
  }

  private void pollState()
  {
    this.mPollingContext = new int[1];
    this.mPollingContext[0] = 0;
    switch (4.$SwitchMap$com$android$internal$telephony$CommandsInterface$RadioState[this.mCi.getRadioState().ordinal()])
    {
    default:
      int[] arrayOfInt1 = this.mPollingContext;
      arrayOfInt1[0] = (1 + arrayOfInt1[0]);
      this.mCi.getOperator(obtainMessage(6, this.mPollingContext));
      int[] arrayOfInt2 = this.mPollingContext;
      arrayOfInt2[0] = (1 + arrayOfInt2[0]);
      this.mCi.getDataRegistrationState(obtainMessage(5, this.mPollingContext));
      int[] arrayOfInt3 = this.mPollingContext;
      arrayOfInt3[0] = (1 + arrayOfInt3[0]);
      this.mCi.getVoiceRegistrationState(obtainMessage(4, this.mPollingContext));
      int[] arrayOfInt4 = this.mPollingContext;
      arrayOfInt4[0] = (1 + arrayOfInt4[0]);
      this.mCi.getNetworkSelectionMode(obtainMessage(14, this.mPollingContext));
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      this.mNewSS.setStateOutOfService();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      this.mNitzUpdatedTime = false;
      pollStateDone();
      continue;
      this.mNewSS.setStateOff();
      this.mNewCellLoc.setStateInvalid();
      setSignalStrengthDefaultValues();
      this.mGotCountryCode = false;
      this.mNitzUpdatedTime = false;
      pollStateDone();
    }
  }

  private void pollStateDone()
  {
    log("Poll ServiceState done:  oldSS=[" + this.mSS + "] newSS=[" + this.mNewSS + "]" + " oldMaxDataCalls=" + this.mMaxDataCalls + " mNewMaxDataCalls=" + this.mNewMaxDataCalls + " oldReasonDataDenied=" + this.mReasonDataDenied + " mNewReasonDataDenied=" + this.mNewReasonDataDenied);
    if ((Build.IS_DEBUGGABLE) && (SystemProperties.getBoolean("telephony.test.forceRoaming", false)))
      this.mNewSS.setRoaming(true);
    useDataRegStateForDataOnlyDevices();
    int i;
    label168: int j;
    label190: int k;
    label212: int m;
    label232: int n;
    label252: int i1;
    label272: int i2;
    label292: int i3;
    label309: int i4;
    label332: int i5;
    label355: int i6;
    label372: String str1;
    String str2;
    label836: String str5;
    if ((this.mSS.getVoiceRegState() != 0) && (this.mNewSS.getVoiceRegState() == 0))
    {
      i = 1;
      if ((this.mSS.getVoiceRegState() != 0) || (this.mNewSS.getVoiceRegState() == 0))
        break label1039;
      if ((this.mSS.getDataRegState() == 0) || (this.mNewSS.getDataRegState() != 0))
        break label1042;
      j = 1;
      if ((this.mSS.getDataRegState() != 0) || (this.mNewSS.getDataRegState() == 0))
        break label1047;
      k = 1;
      if (this.mSS.getDataRegState() == this.mNewSS.getDataRegState())
        break label1052;
      m = 1;
      if (this.mSS.getVoiceRegState() == this.mNewSS.getVoiceRegState())
        break label1058;
      n = 1;
      if (this.mSS.getRilVoiceRadioTechnology() == this.mNewSS.getRilVoiceRadioTechnology())
        break label1064;
      i1 = 1;
      if (this.mSS.getRilDataRadioTechnology() == this.mNewSS.getRilDataRadioTechnology())
        break label1070;
      i2 = 1;
      if (this.mNewSS.equals(this.mSS))
        break label1076;
      i3 = 1;
      if ((this.mSS.getRoaming()) || (!this.mNewSS.getRoaming()))
        break label1082;
      i4 = 1;
      if ((!this.mSS.getRoaming()) || (this.mNewSS.getRoaming()))
        break label1088;
      i5 = 1;
      if (this.mNewCellLoc.equals(this.mCellLoc))
        break label1094;
      i6 = 1;
      if ((n != 0) || (m != 0))
      {
        Object[] arrayOfObject1 = new Object[4];
        arrayOfObject1[0] = Integer.valueOf(this.mSS.getVoiceRegState());
        arrayOfObject1[1] = Integer.valueOf(this.mSS.getDataRegState());
        arrayOfObject1[2] = Integer.valueOf(this.mNewSS.getVoiceRegState());
        arrayOfObject1[3] = Integer.valueOf(this.mNewSS.getDataRegState());
        EventLog.writeEvent(50114, arrayOfObject1);
      }
      if (i1 != 0)
      {
        int i8 = -1;
        GsmCellLocation localGsmCellLocation2 = this.mNewCellLoc;
        if (localGsmCellLocation2 != null)
          i8 = localGsmCellLocation2.getCid();
        Object[] arrayOfObject2 = new Object[3];
        arrayOfObject2[0] = Integer.valueOf(i8);
        arrayOfObject2[1] = Integer.valueOf(this.mSS.getRilVoiceRadioTechnology());
        arrayOfObject2[2] = Integer.valueOf(this.mNewSS.getRilVoiceRadioTechnology());
        EventLog.writeEvent(50123, arrayOfObject2);
        log("RAT switched " + ServiceState.rilRadioTechnologyToString(this.mSS.getRilVoiceRadioTechnology()) + " -> " + ServiceState.rilRadioTechnologyToString(this.mNewSS.getRilVoiceRadioTechnology()) + " at cell " + i8);
      }
      ServiceState localServiceState = this.mSS;
      this.mSS = this.mNewSS;
      this.mNewSS = localServiceState;
      this.mNewSS.setStateOutOfService();
      GsmCellLocation localGsmCellLocation1 = this.mCellLoc;
      this.mCellLoc = this.mNewCellLoc;
      this.mNewCellLoc = localGsmCellLocation1;
      this.mReasonDataDenied = this.mNewReasonDataDenied;
      this.mMaxDataCalls = this.mNewMaxDataCalls;
      if (i1 != 0)
        updatePhoneObject();
      if (i2 != 0)
        this.mPhone.setSystemProperty("gsm.network.type", ServiceState.rilRadioTechnologyToString(this.mSS.getRilVoiceRadioTechnology()));
      if (i != 0)
      {
        this.mNetworkAttachedRegistrants.notifyRegistrants();
        log("pollStateDone: registering current mNitzUpdatedTime=" + this.mNitzUpdatedTime + " changing to false");
        this.mNitzUpdatedTime = false;
      }
      if (i3 != 0)
      {
        updateSpnDisplay();
        this.mPhone.setSystemProperty("gsm.operator.alpha", this.mSS.getOperatorAlphaLong());
        str1 = SystemProperties.get("gsm.operator.numeric", "");
        str2 = this.mSS.getOperatorNumeric();
        this.mPhone.setSystemProperty("gsm.operator.numeric", str2);
        if (!TextUtils.isEmpty(str2))
          break label1100;
        log("operatorNumeric is null");
        this.mPhone.setSystemProperty("gsm.operator.iso-country", "");
        this.mGotCountryCode = false;
        this.mNitzUpdatedTime = false;
        GSMPhone localGSMPhone = this.mPhone;
        if (!this.mSS.getRoaming())
          break label1854;
        str5 = "true";
        label857: localGSMPhone.setSystemProperty("gsm.operator.isroaming", str5);
        this.mPhone.notifyServiceStateChanged(this.mSS);
      }
      if (j != 0)
        this.mAttachedRegistrants.notifyRegistrants();
      if (k != 0)
        this.mDetachedRegistrants.notifyRegistrants();
      if ((m != 0) || (i2 != 0))
      {
        notifyDataRegStateRilRadioTechnologyChanged();
        this.mPhone.notifyDataConnection(null);
      }
      if (i4 != 0)
        this.mRoamingOnRegistrants.notifyRegistrants();
      if (i5 != 0)
        this.mRoamingOffRegistrants.notifyRegistrants();
      if (i6 != 0)
        this.mPhone.notifyLocationChanged();
      if (isGprsConsistent(this.mSS.getDataRegState(), this.mSS.getVoiceRegState()))
        break label1862;
      if ((!this.mStartedGprsRegCheck) && (!this.mReportedGprsNoReg))
      {
        this.mStartedGprsRegCheck = true;
        int i7 = Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "gprs_register_check_period_ms", 60000);
        sendMessageDelayed(obtainMessage(22), i7);
      }
    }
    while (true)
    {
      while (true)
      {
        return;
        i = 0;
        break;
        label1039: break label168;
        label1042: j = 0;
        break label190;
        label1047: k = 0;
        break label212;
        label1052: m = 0;
        break label232;
        label1058: n = 0;
        break label252;
        label1064: i1 = 0;
        break label272;
        label1070: i2 = 0;
        break label292;
        label1076: i3 = 0;
        break label309;
        label1082: i4 = 0;
        break label332;
        label1088: i5 = 0;
        break label355;
        label1094: i6 = 0;
        break label372;
        label1100: Object localObject = "";
        String str3 = "";
        try
        {
          str3 = str2.substring(0, 3);
          String str6 = MccTable.countryCodeForMcc(Integer.parseInt(str3));
          localObject = str6;
          this.mPhone.setSystemProperty("gsm.operator.iso-country", (String)localObject);
          this.mGotCountryCode = true;
          if ((!this.mNitzUpdatedTime) && (!str3.equals("000")) && (!TextUtils.isEmpty((CharSequence)localObject)) && (getAutoTimeZone()))
          {
            if ((SystemProperties.getBoolean("telephony.test.ignore.nitz", false)) && ((1L & SystemClock.uptimeMillis()) == 0L))
            {
              bool = true;
              localArrayList = TimeUtils.getTimeZonesWithUniqueOffsets((String)localObject);
              if ((localArrayList.size() != 1) && (!bool))
                break label1703;
              TimeZone localTimeZone2 = (TimeZone)localArrayList.get(0);
              log("pollStateDone: no nitz but one TZ for iso-cc=" + (String)localObject + " with zone.getID=" + localTimeZone2.getID() + " testOneUniqueOffsetPath=" + bool);
              setAndBroadcastNetworkSetTimeZone(localTimeZone2.getID());
              saveNitzTimeZone(localTimeZone2.getID());
            }
          }
          else
          {
            if (!shouldFixTimeZoneNow(this.mPhone, str2, str1, this.mNeedFixZoneAfterNitz))
              break label836;
            String str4 = SystemProperties.get("persist.sys.timezone");
            log("pollStateDone: fix time zone zoneName='" + str4 + "' mZoneOffset=" + this.mZoneOffset + " mZoneDst=" + this.mZoneDst + " iso-cc='" + (String)localObject + "' iso-cc-idx=" + Arrays.binarySearch(GMT_COUNTRY_CODES, localObject));
            if ((this.mZoneOffset != 0) || (this.mZoneDst) || (str4 == null) || (str4.length() <= 0) || (Arrays.binarySearch(GMT_COUNTRY_CODES, localObject) >= 0))
              break label1776;
            localTimeZone1 = TimeZone.getDefault();
            if (this.mNeedFixZoneAfterNitz)
            {
              long l1 = System.currentTimeMillis();
              l2 = localTimeZone1.getOffset(l1);
              log("pollStateDone: tzOffset=" + l2 + " ltod=" + TimeUtils.logTimeOfDay(l1));
              if (!getAutoTime())
                break label1762;
              long l3 = l1 - l2;
              log("pollStateDone: adj ltod=" + TimeUtils.logTimeOfDay(l3));
              setAndBroadcastNetworkSetTime(l3);
            }
            log("pollStateDone: using default TimeZone");
            this.mNeedFixZoneAfterNitz = false;
            if (localTimeZone1 == null)
              break label1844;
            log("pollStateDone: zone != null zone.getID=" + localTimeZone1.getID());
            if (getAutoTimeZone())
              setAndBroadcastNetworkSetTimeZone(localTimeZone1.getID());
            saveNitzTimeZone(localTimeZone1.getID());
          }
        }
        catch (NumberFormatException localNumberFormatException)
        {
          while (true)
            loge("pollStateDone: countryCodeForMcc error" + localNumberFormatException);
        }
        catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException)
        {
          while (true)
          {
            ArrayList localArrayList;
            TimeZone localTimeZone1;
            long l2;
            loge("pollStateDone: countryCodeForMcc error" + localStringIndexOutOfBoundsException);
            continue;
            boolean bool = false;
            continue;
            label1703: log("pollStateDone: there are " + localArrayList.size() + " unique offsets for iso-cc='" + (String)localObject + " testOneUniqueOffsetPath=" + bool + "', do nothing");
            continue;
            label1762: this.mSavedTime -= l2;
            continue;
            label1776: if (((String)localObject).equals(""))
            {
              localTimeZone1 = getNitzTimeZone(this.mZoneOffset, this.mZoneDst, this.mZoneTime);
              log("pollStateDone: using NITZ TimeZone");
            }
            else
            {
              localTimeZone1 = TimeUtils.getTimeZone(this.mZoneOffset, this.mZoneDst, this.mZoneTime, (String)localObject);
              log("pollStateDone: using getTimeZone(off, dst, time, iso)");
            }
          }
          label1844: log("pollStateDone: zone == null");
        }
      }
      break label836;
      label1854: str5 = "false";
      break label857;
      label1862: this.mReportedGprsNoReg = false;
    }
  }

  private void queueNextSignalStrengthPoll()
  {
    if (this.mDontPollSignalStrength);
    while (true)
    {
      return;
      Message localMessage = obtainMessage();
      localMessage.what = 10;
      sendMessageDelayed(localMessage, 20000L);
    }
  }

  private boolean regCodeIsRoaming(int paramInt)
  {
    if (5 == paramInt);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private int regCodeToServiceState(int paramInt)
  {
    int i = 1;
    switch (paramInt)
    {
    case 6:
    case 7:
    case 8:
    case 9:
    case 11:
    default:
      loge("regCodeToServiceState: unexpected service state " + paramInt);
    case 0:
    case 2:
    case 3:
    case 4:
    case 10:
    case 12:
    case 13:
    case 14:
    case 1:
    case 5:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 0;
    }
  }

  private void revertToNitzTime()
  {
    if (Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "auto_time", 0) == 0);
    while (true)
    {
      return;
      log("Reverting to NITZ Time: mSavedTime=" + this.mSavedTime + " mSavedAtTime=" + this.mSavedAtTime);
      if ((this.mSavedTime != 0L) && (this.mSavedAtTime != 0L))
        setAndBroadcastNetworkSetTime(this.mSavedTime + (SystemClock.elapsedRealtime() - this.mSavedAtTime));
    }
  }

  private void revertToNitzTimeZone()
  {
    if (Settings.Global.getInt(this.mPhone.getContext().getContentResolver(), "auto_time_zone", 0) == 0);
    while (true)
    {
      return;
      log("Reverting to NITZ TimeZone: tz='" + this.mSavedTimeZone);
      if (this.mSavedTimeZone != null)
        setAndBroadcastNetworkSetTimeZone(this.mSavedTimeZone);
    }
  }

  private void saveNitzTime(long paramLong)
  {
    this.mSavedTime = paramLong;
    this.mSavedAtTime = SystemClock.elapsedRealtime();
  }

  private void saveNitzTimeZone(String paramString)
  {
    this.mSavedTimeZone = paramString;
  }

  private void setAndBroadcastNetworkSetTime(long paramLong)
  {
    log("setAndBroadcastNetworkSetTime: time=" + paramLong + "ms");
    SystemClock.setCurrentTimeMillis(paramLong);
    Intent localIntent = new Intent("android.intent.action.NETWORK_SET_TIME");
    localIntent.addFlags(536870912);
    localIntent.putExtra("time", paramLong);
    this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
  }

  private void setAndBroadcastNetworkSetTimeZone(String paramString)
  {
    log("setAndBroadcastNetworkSetTimeZone: setTimeZone=" + paramString);
    ((AlarmManager)this.mPhone.getContext().getSystemService("alarm")).setTimeZone(paramString);
    Intent localIntent = new Intent("android.intent.action.NETWORK_SET_TIMEZONE");
    localIntent.addFlags(536870912);
    localIntent.putExtra("time-zone", paramString);
    this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
    log("setAndBroadcastNetworkSetTimeZone: call alarm.setTimeZone and broadcast zoneId=" + paramString);
  }

  private void setNotification(int paramInt)
  {
    log("setNotification: create notification " + paramInt);
    Context localContext = this.mPhone.getContext();
    this.mNotification = new Notification();
    this.mNotification.when = System.currentTimeMillis();
    this.mNotification.flags = 16;
    this.mNotification.icon = 17301642;
    Intent localIntent = new Intent();
    this.mNotification.contentIntent = PendingIntent.getActivity(localContext, 0, localIntent, 268435456);
    Object localObject = "";
    CharSequence localCharSequence = localContext.getText(17039479);
    int i = 999;
    NotificationManager localNotificationManager;
    switch (paramInt)
    {
    case 1004:
    default:
      log("setNotification: put notification " + localCharSequence + " / " + localObject);
      this.mNotification.tickerText = localCharSequence;
      this.mNotification.setLatestEventInfo(localContext, localCharSequence, (CharSequence)localObject, this.mNotification.contentIntent);
      localNotificationManager = (NotificationManager)localContext.getSystemService("notification");
      if ((paramInt == 1002) || (paramInt == 1004))
        localNotificationManager.cancel(i);
      break;
    case 1001:
    case 1002:
    case 1003:
    case 1005:
    case 1006:
    }
    while (true)
    {
      return;
      i = 888;
      localObject = localContext.getText(17039480);
      break;
      i = 888;
      break;
      localObject = localContext.getText(17039483);
      break;
      localObject = localContext.getText(17039482);
      break;
      localObject = localContext.getText(17039481);
      break;
      localNotificationManager.notify(i, this.mNotification);
    }
  }

  private void setSignalStrengthDefaultValues()
  {
    this.mSignalStrength = new SignalStrength(true);
  }

  // ERROR //
  private void setTimeFromNITZString(String paramString, long paramLong)
  {
    // Byte code:
    //   0: invokestatic 836	android/os/SystemClock:elapsedRealtime	()J
    //   3: lstore 4
    //   5: aload_0
    //   6: new 318	java/lang/StringBuilder
    //   9: dup
    //   10: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   13: ldc_w 969
    //   16: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: aload_1
    //   20: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: ldc_w 971
    //   26: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: lload_2
    //   30: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   33: ldc_w 973
    //   36: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: lload 4
    //   41: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   44: ldc_w 975
    //   47: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: lload 4
    //   52: lload_2
    //   53: lsub
    //   54: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   57: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   60: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   63: ldc_w 977
    //   66: invokestatic 297	java/util/TimeZone:getTimeZone	(Ljava/lang/String;)Ljava/util/TimeZone;
    //   69: invokestatic 983	java/util/Calendar:getInstance	(Ljava/util/TimeZone;)Ljava/util/Calendar;
    //   72: astore 7
    //   74: aload 7
    //   76: invokevirtual 986	java/util/Calendar:clear	()V
    //   79: aload 7
    //   81: bipush 16
    //   83: iconst_0
    //   84: invokevirtual 990	java/util/Calendar:set	(II)V
    //   87: aload_1
    //   88: ldc_w 992
    //   91: invokevirtual 996	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   94: astore 8
    //   96: aload 7
    //   98: iconst_1
    //   99: sipush 2000
    //   102: aload 8
    //   104: iconst_0
    //   105: aaload
    //   106: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   109: iadd
    //   110: invokevirtual 990	java/util/Calendar:set	(II)V
    //   113: aload 7
    //   115: iconst_2
    //   116: iconst_m1
    //   117: aload 8
    //   119: iconst_1
    //   120: aaload
    //   121: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   124: iadd
    //   125: invokevirtual 990	java/util/Calendar:set	(II)V
    //   128: aload 7
    //   130: iconst_5
    //   131: aload 8
    //   133: iconst_2
    //   134: aaload
    //   135: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   138: invokevirtual 990	java/util/Calendar:set	(II)V
    //   141: aload 7
    //   143: bipush 10
    //   145: aload 8
    //   147: iconst_3
    //   148: aaload
    //   149: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   152: invokevirtual 990	java/util/Calendar:set	(II)V
    //   155: aload 7
    //   157: bipush 12
    //   159: aload 8
    //   161: iconst_4
    //   162: aaload
    //   163: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   166: invokevirtual 990	java/util/Calendar:set	(II)V
    //   169: aload 7
    //   171: bipush 13
    //   173: aload 8
    //   175: iconst_5
    //   176: aaload
    //   177: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   180: invokevirtual 990	java/util/Calendar:set	(II)V
    //   183: aload_1
    //   184: bipush 45
    //   186: invokevirtual 999	java/lang/String:indexOf	(I)I
    //   189: iconst_m1
    //   190: if_icmpne +643 -> 833
    //   193: iconst_1
    //   194: istore 9
    //   196: aload 8
    //   198: bipush 6
    //   200: aaload
    //   201: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   204: istore 10
    //   206: aload 8
    //   208: arraylength
    //   209: bipush 8
    //   211: if_icmplt +628 -> 839
    //   214: aload 8
    //   216: bipush 7
    //   218: aaload
    //   219: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   222: istore 11
    //   224: goto +587 -> 811
    //   227: sipush 1000
    //   230: bipush 60
    //   232: bipush 15
    //   234: iload 12
    //   236: iload 10
    //   238: imul
    //   239: imul
    //   240: imul
    //   241: imul
    //   242: istore 13
    //   244: aconst_null
    //   245: astore 14
    //   247: aload 8
    //   249: arraylength
    //   250: bipush 9
    //   252: if_icmplt +20 -> 272
    //   255: aload 8
    //   257: bipush 8
    //   259: aaload
    //   260: bipush 33
    //   262: bipush 47
    //   264: invokevirtual 1003	java/lang/String:replace	(CC)Ljava/lang/String;
    //   267: invokestatic 297	java/util/TimeZone:getTimeZone	(Ljava/lang/String;)Ljava/util/TimeZone;
    //   270: astore 14
    //   272: ldc_w 624
    //   275: invokestatic 721	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   278: astore 15
    //   280: aload 14
    //   282: ifnonnull +51 -> 333
    //   285: aload_0
    //   286: getfield 105	com/android/internal/telephony/gsm/GsmServiceStateTracker:mGotCountryCode	Z
    //   289: ifeq +44 -> 333
    //   292: aload 15
    //   294: ifnull +563 -> 857
    //   297: aload 15
    //   299: invokevirtual 748	java/lang/String:length	()I
    //   302: ifle +555 -> 857
    //   305: iload 11
    //   307: ifeq +544 -> 851
    //   310: iconst_1
    //   311: istore 29
    //   313: aload 7
    //   315: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   318: lstore 30
    //   320: iload 13
    //   322: iload 29
    //   324: lload 30
    //   326: aload 15
    //   328: invokestatic 801	android/util/TimeUtils:getTimeZone	(IZJLjava/lang/String;)Ljava/util/TimeZone;
    //   331: astore 14
    //   333: aload 14
    //   335: ifnull +29 -> 364
    //   338: aload_0
    //   339: getfield 727	com/android/internal/telephony/gsm/GsmServiceStateTracker:mZoneOffset	I
    //   342: iload 13
    //   344: if_icmpne +20 -> 364
    //   347: aload_0
    //   348: getfield 731	com/android/internal/telephony/gsm/GsmServiceStateTracker:mZoneDst	Z
    //   351: istore 23
    //   353: iload 11
    //   355: ifeq +139 -> 494
    //   358: iconst_1
    //   359: istore 24
    //   361: goto +461 -> 822
    //   364: aload_0
    //   365: iconst_1
    //   366: putfield 103	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNeedFixZoneAfterNitz	Z
    //   369: aload_0
    //   370: iload 13
    //   372: putfield 727	com/android/internal/telephony/gsm/GsmServiceStateTracker:mZoneOffset	I
    //   375: iload 11
    //   377: ifeq +123 -> 500
    //   380: iconst_1
    //   381: istore 16
    //   383: aload_0
    //   384: iload 16
    //   386: putfield 731	com/android/internal/telephony/gsm/GsmServiceStateTracker:mZoneDst	Z
    //   389: aload_0
    //   390: aload 7
    //   392: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   395: putfield 794	com/android/internal/telephony/gsm/GsmServiceStateTracker:mZoneTime	J
    //   398: aload 14
    //   400: ifnull +28 -> 428
    //   403: aload_0
    //   404: invokespecial 678	com/android/internal/telephony/gsm/GsmServiceStateTracker:getAutoTimeZone	()Z
    //   407: ifeq +12 -> 419
    //   410: aload_0
    //   411: aload 14
    //   413: invokevirtual 337	java/util/TimeZone:getID	()Ljava/lang/String;
    //   416: invokespecial 709	com/android/internal/telephony/gsm/GsmServiceStateTracker:setAndBroadcastNetworkSetTimeZone	(Ljava/lang/String;)V
    //   419: aload_0
    //   420: aload 14
    //   422: invokevirtual 337	java/util/TimeZone:getID	()Ljava/lang/String;
    //   425: invokespecial 712	com/android/internal/telephony/gsm/GsmServiceStateTracker:saveNitzTimeZone	(Ljava/lang/String;)V
    //   428: ldc_w 1008
    //   431: invokestatic 721	android/os/SystemProperties:get	(Ljava/lang/String;)Ljava/lang/String;
    //   434: astore 17
    //   436: aload 17
    //   438: ifnull +68 -> 506
    //   441: aload 17
    //   443: ldc_w 1010
    //   446: invokevirtual 280	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   449: ifeq +57 -> 506
    //   452: aload_0
    //   453: ldc_w 1012
    //   456: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   459: goto +373 -> 832
    //   462: aload 7
    //   464: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   467: lstore 26
    //   469: aload_0
    //   470: iload 13
    //   472: iload 25
    //   474: lload 26
    //   476: invokespecial 796	com/android/internal/telephony/gsm/GsmServiceStateTracker:getNitzTimeZone	(IZJ)Ljava/util/TimeZone;
    //   479: astore 28
    //   481: aload 28
    //   483: astore 14
    //   485: goto -152 -> 333
    //   488: iconst_0
    //   489: istore 25
    //   491: goto -29 -> 462
    //   494: iconst_0
    //   495: istore 24
    //   497: goto +325 -> 822
    //   500: iconst_0
    //   501: istore 16
    //   503: goto -120 -> 383
    //   506: aload_0
    //   507: getfield 172	com/android/internal/telephony/gsm/GsmServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   510: invokevirtual 1017	android/os/PowerManager$WakeLock:acquire	()V
    //   513: aload_0
    //   514: invokespecial 770	com/android/internal/telephony/gsm/GsmServiceStateTracker:getAutoTime	()Z
    //   517: ifeq +244 -> 761
    //   520: invokestatic 836	android/os/SystemClock:elapsedRealtime	()J
    //   523: lload_2
    //   524: lsub
    //   525: lstore 19
    //   527: lload 19
    //   529: lconst_0
    //   530: lcmp
    //   531: ifge +77 -> 608
    //   534: aload_0
    //   535: new 318	java/lang/StringBuilder
    //   538: dup
    //   539: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   542: ldc_w 1019
    //   545: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   548: aload_1
    //   549: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   552: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   555: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   558: aload_0
    //   559: getfield 172	com/android/internal/telephony/gsm/GsmServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   562: invokevirtual 1022	android/os/PowerManager$WakeLock:release	()V
    //   565: goto +267 -> 832
    //   568: astore 6
    //   570: aload_0
    //   571: new 318	java/lang/StringBuilder
    //   574: dup
    //   575: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   578: ldc_w 1024
    //   581: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   584: aload_1
    //   585: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   588: ldc_w 1026
    //   591: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   594: aload 6
    //   596: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   599: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   602: invokevirtual 784	com/android/internal/telephony/gsm/GsmServiceStateTracker:loge	(Ljava/lang/String;)V
    //   605: goto +227 -> 832
    //   608: lload 19
    //   610: ldc2_w 1027
    //   613: lcmp
    //   614: ifle +48 -> 662
    //   617: aload_0
    //   618: new 318	java/lang/StringBuilder
    //   621: dup
    //   622: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   625: ldc_w 1030
    //   628: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: lload 19
    //   633: ldc2_w 1031
    //   636: ldiv
    //   637: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   640: ldc_w 1034
    //   643: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   646: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   649: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   652: aload_0
    //   653: getfield 172	com/android/internal/telephony/gsm/GsmServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   656: invokevirtual 1022	android/os/PowerManager$WakeLock:release	()V
    //   659: goto +173 -> 832
    //   662: lload 19
    //   664: l2i
    //   665: istore 21
    //   667: aload 7
    //   669: bipush 14
    //   671: iload 21
    //   673: invokevirtual 1037	java/util/Calendar:add	(II)V
    //   676: aload_0
    //   677: new 318	java/lang/StringBuilder
    //   680: dup
    //   681: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   684: ldc_w 1039
    //   687: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   690: aload 7
    //   692: invokevirtual 1043	java/util/Calendar:getTime	()Ljava/util/Date;
    //   695: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   698: ldc_w 1045
    //   701: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   704: lload 19
    //   706: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   709: ldc_w 1047
    //   712: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   715: aload 7
    //   717: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   720: invokestatic 757	java/lang/System:currentTimeMillis	()J
    //   723: lsub
    //   724: invokevirtual 762	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   727: ldc_w 1049
    //   730: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   733: aload_1
    //   734: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   740: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   743: aload_0
    //   744: aload 7
    //   746: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   749: invokespecial 775	com/android/internal/telephony/gsm/GsmServiceStateTracker:setAndBroadcastNetworkSetTime	(J)V
    //   752: ldc 19
    //   754: ldc_w 1051
    //   757: invokestatic 1057	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   760: pop
    //   761: ldc_w 1059
    //   764: aload 7
    //   766: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   769: invokestatic 1061	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   772: invokestatic 1063	android/os/SystemProperties:set	(Ljava/lang/String;Ljava/lang/String;)V
    //   775: aload_0
    //   776: aload 7
    //   778: invokevirtual 1006	java/util/Calendar:getTimeInMillis	()J
    //   781: invokespecial 1065	com/android/internal/telephony/gsm/GsmServiceStateTracker:saveNitzTime	(J)V
    //   784: aload_0
    //   785: iconst_1
    //   786: putfield 107	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNitzUpdatedTime	Z
    //   789: aload_0
    //   790: getfield 172	com/android/internal/telephony/gsm/GsmServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   793: invokevirtual 1022	android/os/PowerManager$WakeLock:release	()V
    //   796: goto +36 -> 832
    //   799: astore 18
    //   801: aload_0
    //   802: getfield 172	com/android/internal/telephony/gsm/GsmServiceStateTracker:mWakeLock	Landroid/os/PowerManager$WakeLock;
    //   805: invokevirtual 1022	android/os/PowerManager$WakeLock:release	()V
    //   808: aload 18
    //   810: athrow
    //   811: iload 9
    //   813: ifeq +32 -> 845
    //   816: iconst_1
    //   817: istore 12
    //   819: goto -592 -> 227
    //   822: iload 23
    //   824: iload 24
    //   826: if_icmpeq -428 -> 398
    //   829: goto -465 -> 364
    //   832: return
    //   833: iconst_0
    //   834: istore 9
    //   836: goto -640 -> 196
    //   839: iconst_0
    //   840: istore 11
    //   842: goto -31 -> 811
    //   845: iconst_m1
    //   846: istore 12
    //   848: goto -621 -> 227
    //   851: iconst_0
    //   852: istore 29
    //   854: goto -541 -> 313
    //   857: iload 11
    //   859: ifeq -371 -> 488
    //   862: iconst_1
    //   863: istore 25
    //   865: goto -403 -> 462
    //
    // Exception table:
    //   from	to	target	type
    //   63	481	568	java/lang/RuntimeException
    //   558	565	568	java/lang/RuntimeException
    //   652	659	568	java/lang/RuntimeException
    //   789	811	568	java/lang/RuntimeException
    //   506	558	799	finally
    //   617	652	799	finally
    //   667	789	799	finally
  }

  public void dispose()
  {
    checkCorrectThread();
    log("ServiceStateTracker dispose");
    this.mCi.unregisterForAvailable(this);
    this.mCi.unregisterForRadioStateChanged(this);
    this.mCi.unregisterForVoiceNetworkStateChanged(this);
    if (this.mUiccApplcation != null)
      this.mUiccApplcation.unregisterForReady(this);
    if (this.mIccRecords != null)
      this.mIccRecords.unregisterForRecordsLoaded(this);
    this.mCi.unSetOnRestrictedStateChanged(this);
    this.mCi.unSetOnNITZTime(this);
    this.mCr.unregisterContentObserver(this.mAutoTimeObserver);
    this.mCr.unregisterContentObserver(this.mAutoTimeZoneObserver);
    this.mPhone.getContext().unregisterReceiver(this.mIntentReceiver);
    super.dispose();
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("GsmServiceStateTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.println(" mSS=" + this.mSS);
    paramPrintWriter.println(" mNewSS=" + this.mNewSS);
    paramPrintWriter.println(" mCellLoc=" + this.mCellLoc);
    paramPrintWriter.println(" mNewCellLoc=" + this.mNewCellLoc);
    paramPrintWriter.println(" mPreferredNetworkType=" + this.mPreferredNetworkType);
    paramPrintWriter.println(" mMaxDataCalls=" + this.mMaxDataCalls);
    paramPrintWriter.println(" mNewMaxDataCalls=" + this.mNewMaxDataCalls);
    paramPrintWriter.println(" mReasonDataDenied=" + this.mReasonDataDenied);
    paramPrintWriter.println(" mNewReasonDataDenied=" + this.mNewReasonDataDenied);
    paramPrintWriter.println(" mGsmRoaming=" + this.mGsmRoaming);
    paramPrintWriter.println(" mDataRoaming=" + this.mDataRoaming);
    paramPrintWriter.println(" mEmergencyOnly=" + this.mEmergencyOnly);
    paramPrintWriter.println(" mNeedFixZoneAfterNitz=" + this.mNeedFixZoneAfterNitz);
    paramPrintWriter.println(" mZoneOffset=" + this.mZoneOffset);
    paramPrintWriter.println(" mZoneDst=" + this.mZoneDst);
    paramPrintWriter.println(" mZoneTime=" + this.mZoneTime);
    paramPrintWriter.println(" mGotCountryCode=" + this.mGotCountryCode);
    paramPrintWriter.println(" mNitzUpdatedTime=" + this.mNitzUpdatedTime);
    paramPrintWriter.println(" mSavedTimeZone=" + this.mSavedTimeZone);
    paramPrintWriter.println(" mSavedTime=" + this.mSavedTime);
    paramPrintWriter.println(" mSavedAtTime=" + this.mSavedAtTime);
    paramPrintWriter.println(" mStartedGprsRegCheck=" + this.mStartedGprsRegCheck);
    paramPrintWriter.println(" mReportedGprsNoReg=" + this.mReportedGprsNoReg);
    paramPrintWriter.println(" mNotification=" + this.mNotification);
    paramPrintWriter.println(" mWakeLock=" + this.mWakeLock);
    paramPrintWriter.println(" mCurSpn=" + this.mCurSpn);
    paramPrintWriter.println(" mCurShowSpn=" + this.mCurShowSpn);
    paramPrintWriter.println(" mCurPlmn=" + this.mCurPlmn);
    paramPrintWriter.println(" mCurShowPlmn=" + this.mCurShowPlmn);
  }

  protected void finalize()
  {
    log("finalize");
  }

  public CellLocation getCellLocation()
  {
    GsmCellLocation localGsmCellLocation;
    if ((this.mCellLoc.getLac() >= 0) && (this.mCellLoc.getCid() >= 0))
    {
      log("getCellLocation(): X good mCellLoc=" + this.mCellLoc);
      localGsmCellLocation = this.mCellLoc;
    }
    while (true)
    {
      return localGsmCellLocation;
      List localList = getAllCellInfo();
      if (localList != null)
      {
        localGsmCellLocation = new GsmCellLocation();
        Iterator localIterator = localList.iterator();
        while (true)
        {
          if (!localIterator.hasNext())
            break label334;
          CellInfo localCellInfo = (CellInfo)localIterator.next();
          if ((localCellInfo instanceof CellInfoGsm))
          {
            CellIdentityGsm localCellIdentityGsm = ((CellInfoGsm)localCellInfo).getCellIdentity();
            localGsmCellLocation.setLacAndCid(localCellIdentityGsm.getLac(), localCellIdentityGsm.getCid());
            localGsmCellLocation.setPsc(localCellIdentityGsm.getPsc());
            log("getCellLocation(): X ret GSM info=" + localGsmCellLocation);
            break;
          }
          if ((localCellInfo instanceof CellInfoWcdma))
          {
            CellIdentityWcdma localCellIdentityWcdma = ((CellInfoWcdma)localCellInfo).getCellIdentity();
            localGsmCellLocation.setLacAndCid(localCellIdentityWcdma.getLac(), localCellIdentityWcdma.getCid());
            localGsmCellLocation.setPsc(localCellIdentityWcdma.getPsc());
            log("getCellLocation(): X ret WCDMA info=" + localGsmCellLocation);
            break;
          }
          if (((localCellInfo instanceof CellInfoLte)) && ((localGsmCellLocation.getLac() < 0) || (localGsmCellLocation.getCid() < 0)))
          {
            CellIdentityLte localCellIdentityLte = ((CellInfoLte)localCellInfo).getCellIdentity();
            if ((localCellIdentityLte.getTac() != 2147483647) && (localCellIdentityLte.getCi() != 2147483647))
            {
              localGsmCellLocation.setLacAndCid(localCellIdentityLte.getTac(), localCellIdentityLte.getCi());
              localGsmCellLocation.setPsc(0);
              log("getCellLocation(): possible LTE cellLocOther=" + localGsmCellLocation);
            }
          }
        }
        label334: log("getCellLocation(): X ret best answer cellLocOther=" + localGsmCellLocation);
      }
      else
      {
        log("getCellLocation(): X empty mCellLoc and CellInfo mCellLoc=" + this.mCellLoc);
        localGsmCellLocation = this.mCellLoc;
      }
    }
  }

  public int getCurrentDataConnectionState()
  {
    return this.mSS.getDataRegState();
  }

  protected Phone getPhone()
  {
    return this.mPhone;
  }

  public void handleMessage(Message paramMessage)
  {
    if (!this.mPhone.mIsTheCurrentActivePhone)
      Rlog.e("GsmSST", "Received message " + paramMessage + "[" + paramMessage.what + "] while being destroyed. Ignoring.");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      case 13:
      case 7:
      case 8:
      case 9:
      default:
        super.handleMessage(paramMessage);
        break;
      case 17:
        this.mCi.setCurrentPreferredNetworkType();
        if (!this.mPhone.getContext().getResources().getBoolean(17891390))
          this.mPhone.restoreSavedNetworkSelection(null);
        pollState();
        queueNextSignalStrengthPoll();
        break;
      case 1:
        setPowerStateToDesired();
        pollState();
        break;
      case 2:
        pollState();
        break;
      case 3:
        if (this.mCi.getRadioState().isOn())
        {
          onSignalStrengthResult((AsyncResult)paramMessage.obj, true);
          queueNextSignalStrengthPoll();
        }
        break;
      case 15:
        AsyncResult localAsyncResult6 = (AsyncResult)paramMessage.obj;
        String[] arrayOfString;
        int j;
        int k;
        if (localAsyncResult6.exception == null)
        {
          arrayOfString = (String[])localAsyncResult6.result;
          j = -1;
          k = -1;
          if (arrayOfString.length < 3);
        }
        try
        {
          if ((arrayOfString[1] != null) && (arrayOfString[1].length() > 0))
            j = Integer.parseInt(arrayOfString[1], 16);
          if ((arrayOfString[2] != null) && (arrayOfString[2].length() > 0))
          {
            int m = Integer.parseInt(arrayOfString[2], 16);
            k = m;
          }
          this.mCellLoc.setLacAndCid(j, k);
          this.mPhone.notifyLocationChanged();
          disableSingleLocationUpdate();
        }
        catch (NumberFormatException localNumberFormatException)
        {
          while (true)
            Rlog.w("GsmSST", "error parsing location: " + localNumberFormatException);
        }
      case 4:
      case 5:
      case 6:
      case 14:
        AsyncResult localAsyncResult5 = (AsyncResult)paramMessage.obj;
        handlePollStateResult(paramMessage.what, localAsyncResult5);
        break;
      case 10:
        this.mCi.getSignalStrength(obtainMessage(3));
        break;
      case 11:
        AsyncResult localAsyncResult4 = (AsyncResult)paramMessage.obj;
        setTimeFromNITZString((String)((Object[])(Object[])localAsyncResult4.result)[0], ((Long)((Object[])(Object[])localAsyncResult4.result)[1]).longValue());
        break;
      case 12:
        AsyncResult localAsyncResult3 = (AsyncResult)paramMessage.obj;
        this.mDontPollSignalStrength = true;
        onSignalStrengthResult(localAsyncResult3, true);
        break;
      case 16:
        log("EVENT_SIM_RECORDS_LOADED: what=" + paramMessage.what);
        updatePhoneObject();
        updateSpnDisplay();
        break;
      case 18:
        if (((AsyncResult)paramMessage.obj).exception == null)
          this.mCi.getVoiceRegistrationState(obtainMessage(15, null));
        break;
      case 20:
        Message localMessage2 = obtainMessage(21, ((AsyncResult)paramMessage.obj).userObj);
        this.mCi.setPreferredNetworkType(this.mPreferredNetworkType, localMessage2);
        break;
      case 21:
        AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
        if (localAsyncResult2.userObj != null)
        {
          AsyncResult.forMessage((Message)localAsyncResult2.userObj).exception = localAsyncResult2.exception;
          ((Message)localAsyncResult2.userObj).sendToTarget();
        }
        break;
      case 19:
        AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
        if (localAsyncResult1.exception == null);
        for (this.mPreferredNetworkType = ((int[])(int[])localAsyncResult1.result)[0]; ; this.mPreferredNetworkType = 7)
        {
          Message localMessage1 = obtainMessage(20, localAsyncResult1.userObj);
          this.mCi.setPreferredNetworkType(7, localMessage1);
          break;
        }
      case 22:
        GsmCellLocation localGsmCellLocation;
        Object[] arrayOfObject;
        if ((this.mSS != null) && (!isGprsConsistent(this.mSS.getDataRegState(), this.mSS.getVoiceRegState())))
        {
          localGsmCellLocation = (GsmCellLocation)this.mPhone.getCellLocation();
          arrayOfObject = new Object[2];
          arrayOfObject[0] = this.mSS.getOperatorNumeric();
          if (localGsmCellLocation == null)
            break label872;
        }
        for (int i = localGsmCellLocation.getCid(); ; i = -1)
        {
          arrayOfObject[1] = Integer.valueOf(i);
          EventLog.writeEvent(50107, arrayOfObject);
          this.mReportedGprsNoReg = true;
          this.mStartedGprsRegCheck = false;
          break;
        }
      case 23:
        label872: log("EVENT_RESTRICTED_STATE_CHANGED");
        onRestrictedStateChanged((AsyncResult)paramMessage.obj);
      }
    }
  }

  // ERROR //
  protected void handlePollStateResult(int paramInt, AsyncResult paramAsyncResult)
  {
    // Byte code:
    //   0: aload_2
    //   1: getfield 1332	android/os/AsyncResult:userObj	Ljava/lang/Object;
    //   4: aload_0
    //   5: getfield 453	com/android/internal/telephony/ServiceStateTracker:mPollingContext	[I
    //   8: if_acmpeq +4 -> 12
    //   11: return
    //   12: aload_2
    //   13: getfield 386	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   16: ifnull +215 -> 231
    //   19: aconst_null
    //   20: astore 26
    //   22: aload_2
    //   23: getfield 386	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   26: instanceof 1352
    //   29: ifeq +18 -> 47
    //   32: aload_2
    //   33: getfield 386	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   36: checkcast 1352	com/android/internal/telephony/CommandException
    //   39: checkcast 1352	com/android/internal/telephony/CommandException
    //   42: invokevirtual 1356	com/android/internal/telephony/CommandException:getCommandError	()Lcom/android/internal/telephony/CommandException$Error;
    //   45: astore 26
    //   47: aload 26
    //   49: getstatic 1362	com/android/internal/telephony/CommandException$Error:RADIO_NOT_AVAILABLE	Lcom/android/internal/telephony/CommandException$Error;
    //   52: if_acmpne +10 -> 62
    //   55: aload_0
    //   56: invokevirtual 1365	com/android/internal/telephony/gsm/GsmServiceStateTracker:cancelPollState	()V
    //   59: goto -48 -> 11
    //   62: aload_0
    //   63: getfield 173	com/android/internal/telephony/ServiceStateTracker:mCi	Lcom/android/internal/telephony/CommandsInterface;
    //   66: invokeinterface 462 1 0
    //   71: invokevirtual 1292	com/android/internal/telephony/CommandsInterface$RadioState:isOn	()Z
    //   74: ifne +10 -> 84
    //   77: aload_0
    //   78: invokevirtual 1365	com/android/internal/telephony/gsm/GsmServiceStateTracker:cancelPollState	()V
    //   81: goto -70 -> 11
    //   84: aload 26
    //   86: getstatic 1368	com/android/internal/telephony/CommandException$Error:OP_NOT_ALLOWED_BEFORE_REG_NW	Lcom/android/internal/telephony/CommandException$Error;
    //   89: if_acmpeq +30 -> 119
    //   92: aload_0
    //   93: new 318	java/lang/StringBuilder
    //   96: dup
    //   97: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   100: ldc_w 1370
    //   103: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: aload_2
    //   107: getfield 386	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   110: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   113: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   116: invokevirtual 784	com/android/internal/telephony/gsm/GsmServiceStateTracker:loge	(Ljava/lang/String;)V
    //   119: aload_0
    //   120: getfield 453	com/android/internal/telephony/ServiceStateTracker:mPollingContext	[I
    //   123: astore 6
    //   125: aload 6
    //   127: iconst_0
    //   128: iconst_m1
    //   129: aload 6
    //   131: iconst_0
    //   132: iaload
    //   133: iadd
    //   134: iastore
    //   135: aload_0
    //   136: getfield 453	com/android/internal/telephony/ServiceStateTracker:mPollingContext	[I
    //   139: iconst_0
    //   140: iaload
    //   141: ifne -130 -> 11
    //   144: aload_0
    //   145: getfield 97	com/android/internal/telephony/gsm/GsmServiceStateTracker:mGsmRoaming	Z
    //   148: ifne +10 -> 158
    //   151: aload_0
    //   152: getfield 99	com/android/internal/telephony/gsm/GsmServiceStateTracker:mDataRoaming	Z
    //   155: ifeq +796 -> 951
    //   158: iconst_1
    //   159: istore 7
    //   161: aload_0
    //   162: getfield 97	com/android/internal/telephony/gsm/GsmServiceStateTracker:mGsmRoaming	Z
    //   165: ifeq +25 -> 190
    //   168: aload_0
    //   169: aload_0
    //   170: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   173: invokespecial 1372	com/android/internal/telephony/gsm/GsmServiceStateTracker:isSameNamedOperators	(Landroid/telephony/ServiceState;)Z
    //   176: ifeq +14 -> 190
    //   179: aload_0
    //   180: aload_0
    //   181: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   184: invokespecial 1374	com/android/internal/telephony/gsm/GsmServiceStateTracker:isSameNamedOperatorConsideredRoaming	(Landroid/telephony/ServiceState;)Z
    //   187: ifeq +14 -> 201
    //   190: aload_0
    //   191: aload_0
    //   192: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   195: invokespecial 1376	com/android/internal/telephony/gsm/GsmServiceStateTracker:isOperatorConsideredNonRoaming	(Landroid/telephony/ServiceState;)Z
    //   198: ifeq +6 -> 204
    //   201: iconst_0
    //   202: istore 7
    //   204: aload_0
    //   205: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   208: iload 7
    //   210: invokevirtual 539	android/telephony/ServiceState:setRoaming	(Z)V
    //   213: aload_0
    //   214: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   217: aload_0
    //   218: getfield 101	com/android/internal/telephony/gsm/GsmServiceStateTracker:mEmergencyOnly	Z
    //   221: invokevirtual 1379	android/telephony/ServiceState:setEmergencyOnly	(Z)V
    //   224: aload_0
    //   225: invokespecial 498	com/android/internal/telephony/gsm/GsmServiceStateTracker:pollStateDone	()V
    //   228: goto -217 -> 11
    //   231: iload_1
    //   232: lookupswitch	default:+44->276, 4:+47->279, 5:+401->633, 6:+630->862, 14:+676->908
    //   277: impdep2
    //   278: dadd
    //   279: aload_2
    //   280: getfield 390	android/os/AsyncResult:result	Ljava/lang/Object;
    //   283: checkcast 1300	[Ljava/lang/String;
    //   286: checkcast 1300	[Ljava/lang/String;
    //   289: astore 16
    //   291: iconst_m1
    //   292: istore 17
    //   294: iconst_m1
    //   295: istore 18
    //   297: iconst_0
    //   298: istore 19
    //   300: iconst_4
    //   301: istore 20
    //   303: iconst_m1
    //   304: istore 21
    //   306: aload 16
    //   308: arraylength
    //   309: istore 22
    //   311: iload 22
    //   313: ifle +141 -> 454
    //   316: aload 16
    //   318: iconst_0
    //   319: aaload
    //   320: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   323: istore 20
    //   325: aload 16
    //   327: arraylength
    //   328: iconst_3
    //   329: if_icmplt +82 -> 411
    //   332: aload 16
    //   334: iconst_1
    //   335: aaload
    //   336: ifnull +24 -> 360
    //   339: aload 16
    //   341: iconst_1
    //   342: aaload
    //   343: invokevirtual 748	java/lang/String:length	()I
    //   346: ifle +14 -> 360
    //   349: aload 16
    //   351: iconst_1
    //   352: aaload
    //   353: bipush 16
    //   355: invokestatic 1303	java/lang/Integer:parseInt	(Ljava/lang/String;I)I
    //   358: istore 17
    //   360: aload 16
    //   362: iconst_2
    //   363: aaload
    //   364: ifnull +24 -> 388
    //   367: aload 16
    //   369: iconst_2
    //   370: aaload
    //   371: invokevirtual 748	java/lang/String:length	()I
    //   374: ifle +14 -> 388
    //   377: aload 16
    //   379: iconst_2
    //   380: aaload
    //   381: bipush 16
    //   383: invokestatic 1303	java/lang/Integer:parseInt	(Ljava/lang/String;I)I
    //   386: istore 18
    //   388: aload 16
    //   390: arraylength
    //   391: iconst_4
    //   392: if_icmplt +19 -> 411
    //   395: aload 16
    //   397: iconst_3
    //   398: aaload
    //   399: ifnull +12 -> 411
    //   402: aload 16
    //   404: iconst_3
    //   405: aaload
    //   406: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   409: istore 19
    //   411: aload 16
    //   413: arraylength
    //   414: bipush 14
    //   416: if_icmple +38 -> 454
    //   419: aload 16
    //   421: bipush 14
    //   423: aaload
    //   424: ifnull +30 -> 454
    //   427: aload 16
    //   429: bipush 14
    //   431: aaload
    //   432: invokevirtual 748	java/lang/String:length	()I
    //   435: ifle +19 -> 454
    //   438: aload 16
    //   440: bipush 14
    //   442: aaload
    //   443: bipush 16
    //   445: invokestatic 1303	java/lang/Integer:parseInt	(Ljava/lang/String;I)I
    //   448: istore 25
    //   450: iload 25
    //   452: istore 21
    //   454: aload_0
    //   455: aload_0
    //   456: iload 20
    //   458: invokespecial 1381	com/android/internal/telephony/gsm/GsmServiceStateTracker:regCodeIsRoaming	(I)Z
    //   461: putfield 97	com/android/internal/telephony/gsm/GsmServiceStateTracker:mGsmRoaming	Z
    //   464: aload_0
    //   465: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   468: aload_0
    //   469: iload 20
    //   471: invokespecial 1383	com/android/internal/telephony/gsm/GsmServiceStateTracker:regCodeToServiceState	(I)I
    //   474: invokevirtual 1386	android/telephony/ServiceState:setState	(I)V
    //   477: aload_0
    //   478: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   481: iload 19
    //   483: invokevirtual 1389	android/telephony/ServiceState:setRilVoiceRadioTechnology	(I)V
    //   486: aload_0
    //   487: getfield 1393	com/android/internal/telephony/ServiceStateTracker:mPhoneBase	Lcom/android/internal/telephony/PhoneBase;
    //   490: invokevirtual 1394	com/android/internal/telephony/PhoneBase:getContext	()Landroid/content/Context;
    //   493: invokevirtual 344	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   496: ldc_w 1395
    //   499: invokevirtual 1279	android/content/res/Resources:getBoolean	(I)Z
    //   502: istore 23
    //   504: iload 20
    //   506: bipush 13
    //   508: if_icmpeq +24 -> 532
    //   511: iload 20
    //   513: bipush 10
    //   515: if_icmpeq +17 -> 532
    //   518: iload 20
    //   520: bipush 12
    //   522: if_icmpeq +10 -> 532
    //   525: iload 20
    //   527: bipush 14
    //   529: if_icmpne +96 -> 625
    //   532: iload 23
    //   534: ifeq +91 -> 625
    //   537: aload_0
    //   538: iconst_1
    //   539: putfield 101	com/android/internal/telephony/gsm/GsmServiceStateTracker:mEmergencyOnly	Z
    //   542: aload_0
    //   543: getfield 150	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewCellLoc	Landroid/telephony/gsm/GsmCellLocation;
    //   546: iload 17
    //   548: iload 18
    //   550: invokevirtual 1215	android/telephony/gsm/GsmCellLocation:setLacAndCid	(II)V
    //   553: aload_0
    //   554: getfield 150	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewCellLoc	Landroid/telephony/gsm/GsmCellLocation;
    //   557: iload 21
    //   559: invokevirtual 1221	android/telephony/gsm/GsmCellLocation:setPsc	(I)V
    //   562: goto -443 -> 119
    //   565: astore 8
    //   567: aload_0
    //   568: new 318	java/lang/StringBuilder
    //   571: dup
    //   572: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   575: ldc_w 1397
    //   578: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   581: aload 8
    //   583: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   586: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   589: invokevirtual 784	com/android/internal/telephony/gsm/GsmServiceStateTracker:loge	(Ljava/lang/String;)V
    //   592: goto -473 -> 119
    //   595: astore 24
    //   597: aload_0
    //   598: new 318	java/lang/StringBuilder
    //   601: dup
    //   602: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   605: ldc_w 1399
    //   608: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: aload 24
    //   613: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   616: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   619: invokevirtual 784	com/android/internal/telephony/gsm/GsmServiceStateTracker:loge	(Ljava/lang/String;)V
    //   622: goto -168 -> 454
    //   625: aload_0
    //   626: iconst_0
    //   627: putfield 101	com/android/internal/telephony/gsm/GsmServiceStateTracker:mEmergencyOnly	Z
    //   630: goto -88 -> 542
    //   633: aload_2
    //   634: getfield 390	android/os/AsyncResult:result	Ljava/lang/Object;
    //   637: checkcast 1300	[Ljava/lang/String;
    //   640: checkcast 1300	[Ljava/lang/String;
    //   643: astore 10
    //   645: iconst_0
    //   646: istore 11
    //   648: iconst_4
    //   649: istore 12
    //   651: aload_0
    //   652: iconst_m1
    //   653: putfield 95	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewReasonDataDenied	I
    //   656: aload_0
    //   657: iconst_1
    //   658: putfield 91	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewMaxDataCalls	I
    //   661: aload 10
    //   663: arraylength
    //   664: istore 13
    //   666: iload 13
    //   668: ifle +78 -> 746
    //   671: aload 10
    //   673: iconst_0
    //   674: aaload
    //   675: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   678: istore 12
    //   680: aload 10
    //   682: arraylength
    //   683: iconst_4
    //   684: if_icmplt +19 -> 703
    //   687: aload 10
    //   689: iconst_3
    //   690: aaload
    //   691: ifnull +12 -> 703
    //   694: aload 10
    //   696: iconst_3
    //   697: aaload
    //   698: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   701: istore 11
    //   703: aload 10
    //   705: arraylength
    //   706: iconst_5
    //   707: if_icmplt +20 -> 727
    //   710: iload 12
    //   712: iconst_3
    //   713: if_icmpne +14 -> 727
    //   716: aload_0
    //   717: aload 10
    //   719: iconst_4
    //   720: aaload
    //   721: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   724: putfield 95	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewReasonDataDenied	I
    //   727: aload 10
    //   729: arraylength
    //   730: bipush 6
    //   732: if_icmplt +14 -> 746
    //   735: aload_0
    //   736: aload 10
    //   738: iconst_5
    //   739: aaload
    //   740: invokestatic 669	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   743: putfield 91	com/android/internal/telephony/gsm/GsmServiceStateTracker:mNewMaxDataCalls	I
    //   746: aload_0
    //   747: iload 12
    //   749: invokespecial 1383	com/android/internal/telephony/gsm/GsmServiceStateTracker:regCodeToServiceState	(I)I
    //   752: istore 14
    //   754: aload_0
    //   755: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   758: iload 14
    //   760: invokevirtual 1402	android/telephony/ServiceState:setDataRegState	(I)V
    //   763: aload_0
    //   764: aload_0
    //   765: iload 12
    //   767: invokespecial 1381	com/android/internal/telephony/gsm/GsmServiceStateTracker:regCodeIsRoaming	(I)Z
    //   770: putfield 99	com/android/internal/telephony/gsm/GsmServiceStateTracker:mDataRoaming	Z
    //   773: aload_0
    //   774: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   777: iload 11
    //   779: invokevirtual 1405	android/telephony/ServiceState:setRilDataRadioTechnology	(I)V
    //   782: aload_0
    //   783: new 318	java/lang/StringBuilder
    //   786: dup
    //   787: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   790: ldc_w 1407
    //   793: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   796: iload 14
    //   798: invokevirtual 519	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   801: ldc_w 1409
    //   804: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   807: iload 12
    //   809: invokevirtual 519	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   812: ldc_w 1411
    //   815: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   818: iload 11
    //   820: invokevirtual 519	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   823: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   826: invokevirtual 334	com/android/internal/telephony/gsm/GsmServiceStateTracker:log	(Ljava/lang/String;)V
    //   829: goto -710 -> 119
    //   832: astore 15
    //   834: aload_0
    //   835: new 318	java/lang/StringBuilder
    //   838: dup
    //   839: invokespecial 319	java/lang/StringBuilder:<init>	()V
    //   842: ldc_w 1413
    //   845: invokevirtual 325	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   848: aload 15
    //   850: invokevirtual 328	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   853: invokevirtual 331	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   856: invokevirtual 784	com/android/internal/telephony/gsm/GsmServiceStateTracker:loge	(Ljava/lang/String;)V
    //   859: goto -113 -> 746
    //   862: aload_2
    //   863: getfield 390	android/os/AsyncResult:result	Ljava/lang/Object;
    //   866: checkcast 1300	[Ljava/lang/String;
    //   869: checkcast 1300	[Ljava/lang/String;
    //   872: astore 9
    //   874: aload 9
    //   876: ifnull -757 -> 119
    //   879: aload 9
    //   881: arraylength
    //   882: iconst_3
    //   883: if_icmplt -764 -> 119
    //   886: aload_0
    //   887: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   890: aload 9
    //   892: iconst_0
    //   893: aaload
    //   894: aload 9
    //   896: iconst_1
    //   897: aaload
    //   898: aload 9
    //   900: iconst_2
    //   901: aaload
    //   902: invokevirtual 1417	android/telephony/ServiceState:setOperatorName	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   905: goto -786 -> 119
    //   908: aload_2
    //   909: getfield 390	android/os/AsyncResult:result	Ljava/lang/Object;
    //   912: checkcast 392	[I
    //   915: checkcast 392	[I
    //   918: astore_3
    //   919: aload_0
    //   920: getfield 489	com/android/internal/telephony/ServiceStateTracker:mNewSS	Landroid/telephony/ServiceState;
    //   923: astore 4
    //   925: aload_3
    //   926: iconst_0
    //   927: iaload
    //   928: iconst_1
    //   929: if_icmpne +16 -> 945
    //   932: iconst_1
    //   933: istore 5
    //   935: aload 4
    //   937: iload 5
    //   939: invokevirtual 1420	android/telephony/ServiceState:setIsManualSelection	(Z)V
    //   942: goto -823 -> 119
    //   945: iconst_0
    //   946: istore 5
    //   948: goto -13 -> 935
    //   951: iconst_0
    //   952: istore 7
    //   954: goto -793 -> 161
    //
    // Exception table:
    //   from	to	target	type
    //   279	311	565	java/lang/RuntimeException
    //   316	450	565	java/lang/RuntimeException
    //   454	562	565	java/lang/RuntimeException
    //   597	666	565	java/lang/RuntimeException
    //   671	746	565	java/lang/RuntimeException
    //   746	942	565	java/lang/RuntimeException
    //   316	450	595	java/lang/NumberFormatException
    //   671	746	832	java/lang/NumberFormatException
  }

  protected void hangupAndPowerOff()
  {
    if (this.mPhone.isInCall())
    {
      this.mPhone.mCT.mRingingCall.hangupIfAlive();
      this.mPhone.mCT.mBackgroundCall.hangupIfAlive();
      this.mPhone.mCT.mForegroundCall.hangupIfAlive();
    }
    this.mCi.setRadioPower(false, null);
  }

  public boolean isConcurrentVoiceAndDataAllowed()
  {
    if (this.mSS.getRilVoiceRadioTechnology() >= 3);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  protected void log(String paramString)
  {
    Rlog.d("GsmSST", "[GsmSST] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("GsmSST", "[GsmSST] " + paramString);
  }

  protected void onUpdateIccAvailability()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      UiccCardApplication localUiccCardApplication = this.mUiccController.getUiccCardApplication(1);
      if (this.mUiccApplcation != localUiccCardApplication)
      {
        if (this.mUiccApplcation != null)
        {
          log("Removing stale icc objects.");
          this.mUiccApplcation.unregisterForReady(this);
          if (this.mIccRecords != null)
            this.mIccRecords.unregisterForRecordsLoaded(this);
          this.mIccRecords = null;
          this.mUiccApplcation = null;
        }
        if (localUiccCardApplication != null)
        {
          log("New card found");
          this.mUiccApplcation = localUiccCardApplication;
          this.mIccRecords = this.mUiccApplcation.getIccRecords();
          this.mUiccApplcation.registerForReady(this, 17, null);
          if (this.mIccRecords != null)
            this.mIccRecords.registerForRecordsLoaded(this, 16, null);
        }
      }
    }
  }

  protected void setPowerStateToDesired()
  {
    if ((this.mDesiredPowerState) && (this.mCi.getRadioState() == CommandsInterface.RadioState.RADIO_OFF))
      this.mCi.setRadioPower(true, null);
    while (true)
    {
      return;
      if ((!this.mDesiredPowerState) && (this.mCi.getRadioState().isOn()))
        powerOffRadioSafely(this.mPhone.mDcTracker);
    }
  }

  protected void updateSpnDisplay()
  {
    IccRecords localIccRecords = this.mIccRecords;
    String str1 = null;
    boolean bool1 = false;
    int i;
    label70: label100: String str2;
    label110: String str3;
    int j;
    if (localIccRecords != null)
    {
      i = localIccRecords.getDisplayRule(this.mSS.getOperatorNumeric());
      if ((this.mSS.getVoiceRegState() != 1) && (this.mSS.getVoiceRegState() != 2))
        break label399;
      bool1 = true;
      if (!this.mEmergencyOnly)
        break label383;
      str1 = Resources.getSystem().getText(17040162).toString();
      log("updateSpnDisplay: radio is on but out of service, set plmn='" + str1 + "'");
      if (localIccRecords == null)
        break label483;
      str2 = localIccRecords.getServiceProviderName();
      str3 = Injector.ServiceStateTrackerHook.getSpn(this, str2);
      if ((TextUtils.isEmpty(str3)) || ((i & 0x1) != 1))
        break label491;
      j = 1;
      label137: if ((j == 0) || (this.mEmergencyOnly) || (this.mSS.getState() != 0))
        break label497;
    }
    label399: label483: label491: label497: for (boolean bool2 = true; ; bool2 = false)
    {
      if ((bool1 != this.mCurShowPlmn) || (bool2 != this.mCurShowSpn) || (!TextUtils.equals(str3, this.mCurSpn)) || (!TextUtils.equals(str1, this.mCurPlmn)))
      {
        String str4 = "updateSpnDisplay: changed sending intent rule=" + i + " showPlmn='%b' plmn='%s' showSpn='%b' spn='%s'";
        Object[] arrayOfObject = new Object[4];
        arrayOfObject[0] = Boolean.valueOf(bool1);
        arrayOfObject[1] = str1;
        arrayOfObject[2] = Boolean.valueOf(bool2);
        arrayOfObject[3] = str3;
        log(String.format(str4, arrayOfObject));
        Intent localIntent = new Intent("android.provider.Telephony.SPN_STRINGS_UPDATED");
        localIntent.addFlags(536870912);
        localIntent.putExtra("showSpn", bool2);
        localIntent.putExtra("spn", str3);
        localIntent.putExtra("showPlmn", bool1);
        localIntent.putExtra("plmn", str1);
        this.mPhone.getContext().sendStickyBroadcastAsUser(localIntent, UserHandle.ALL);
      }
      this.mCurShowSpn = bool2;
      this.mCurShowPlmn = bool1;
      this.mCurSpn = str3;
      this.mCurPlmn = str1;
      return;
      i = 0;
      break;
      label383: str1 = Resources.getSystem().getText(17040136).toString();
      break label70;
      if (this.mSS.getVoiceRegState() == 0)
      {
        str1 = Injector.ServiceStateTrackerHook.getSpn(this, this.mSS.getOperatorAlphaLong());
        if ((!TextUtils.isEmpty(str1)) && ((i & 0x2) == 2));
        for (bool1 = true; ; bool1 = false)
          break;
      }
      log("updateSpnDisplay: radio is off w/ showPlmn=" + false + " plmn=" + null);
      break label100;
      str2 = "";
      break label110;
      j = 0;
      break label137;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmServiceStateTracker
 * JD-Core Version:    0.6.2
 */