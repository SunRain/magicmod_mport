package com.android.internal.telephony.gsm;

import android.util.Log;
import com.android.internal.telephony.MiuiIccPhoneBookInterfaceManager;

public class MiuiSimPhoneBookInterfaceManager extends MiuiIccPhoneBookInterfaceManager
{
  static final String LOG_TAG = "GSM";

  public MiuiSimPhoneBookInterfaceManager(GSMPhone paramGSMPhone)
  {
    super(paramGSMPhone);
  }

  protected void logd(String paramString)
  {
    Log.d("GSM", "[SimPbInterfaceManager] " + paramString);
  }

  protected void loge(String paramString)
  {
    Log.e("GSM", "[SimPbInterfaceManager] " + paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.MiuiSimPhoneBookInterfaceManager
 * JD-Core Version:    0.6.2
 */