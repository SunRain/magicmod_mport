package com.android.internal.telephony.gsm;

import android.os.Message;
import com.android.internal.telephony.Injector.PhoneBaseHook;
import com.android.internal.telephony.PhoneBase;

class Injector
{
  static class GSMPhoneHook
  {
    public static void before_acceptCall(GSMPhone paramGSMPhone)
    {
      paramGSMPhone.removeMessages(15);
    }

    public static void checkAndNotifyDeviceId(GSMPhone paramGSMPhone, Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
      case 9:
      }
      while (true)
      {
        return;
        Injector.PhoneBaseHook.checkAndNotifyDeviceId(paramGSMPhone.getDeviceId(), paramGSMPhone, paramGSMPhone.mCi, paramMessage.arg1);
      }
    }

    public static String getDeviceId(GSMPhone paramGSMPhone, String paramString)
    {
      return Injector.PhoneBaseHook.checkEmptyDeviceId(paramGSMPhone, paramString);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.Injector
 * JD-Core Version:    0.6.2
 */