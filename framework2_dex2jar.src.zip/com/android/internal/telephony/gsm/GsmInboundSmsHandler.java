package com.android.internal.telephony.gsm;

import android.content.Context;
import android.os.Message;
import com.android.internal.telephony.CellBroadcastHandler;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.InboundSmsHandler;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.SmsConstants.MessageClass;
import com.android.internal.telephony.SmsMessageBase;
import com.android.internal.telephony.SmsStorageMonitor;
import com.android.internal.telephony.uicc.UsimServiceTable;

public class GsmInboundSmsHandler extends InboundSmsHandler
{
  private final UsimDataDownloadHandler mDataDownloadHandler;

  private GsmInboundSmsHandler(Context paramContext, SmsStorageMonitor paramSmsStorageMonitor, PhoneBase paramPhoneBase)
  {
    super("GsmInboundSmsHandler", paramContext, paramSmsStorageMonitor, paramPhoneBase, GsmCellBroadcastHandler.makeGsmCellBroadcastHandler(paramContext, paramPhoneBase));
    paramPhoneBase.mCi.setOnNewGsmSms(getHandler(), 1, null);
    this.mDataDownloadHandler = new UsimDataDownloadHandler(paramPhoneBase.mCi);
  }

  public static GsmInboundSmsHandler makeInboundSmsHandler(Context paramContext, SmsStorageMonitor paramSmsStorageMonitor, PhoneBase paramPhoneBase)
  {
    GsmInboundSmsHandler localGsmInboundSmsHandler = new GsmInboundSmsHandler(paramContext, paramSmsStorageMonitor, paramPhoneBase);
    localGsmInboundSmsHandler.start();
    return localGsmInboundSmsHandler;
  }

  private static int resultToCause(int paramInt)
  {
    int i;
    switch (paramInt)
    {
    case 0:
    case 2:
    default:
      i = 255;
    case -1:
    case 1:
    case 3:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 211;
    }
  }

  protected void acknowledgeLastIncomingSms(boolean paramBoolean, int paramInt, Message paramMessage)
  {
    this.mPhone.mCi.acknowledgeLastIncomingGsmSms(paramBoolean, resultToCause(paramInt), paramMessage);
  }

  protected int dispatchMessageRadioSpecific(SmsMessageBase paramSmsMessageBase)
  {
    boolean bool1 = false;
    int i = 1;
    SmsMessage localSmsMessage = (SmsMessage)paramSmsMessageBase;
    if (localSmsMessage.isTypeZero())
      log("Received short message type 0, Don't display or store it. Send Ack");
    while (true)
    {
      return i;
      if (localSmsMessage.isUsimDataDownload())
      {
        UsimServiceTable localUsimServiceTable = this.mPhone.getUsimServiceTable();
        i = this.mDataDownloadHandler.handleUsimDataDownload(localUsimServiceTable, localSmsMessage);
      }
      else
      {
        boolean bool2 = false;
        if (localSmsMessage.isMWISetMessage())
        {
          this.mPhone.setVoiceMessageWaiting(i, -1);
          bool2 = localSmsMessage.isMwiDontStore();
          StringBuilder localStringBuilder2 = new StringBuilder().append("Received voice mail indicator set SMS shouldStore=");
          if (!bool2)
            bool1 = i;
          log(bool1);
        }
        while (true)
        {
          if (bool2)
            break label209;
          if ((this.mStorageMonitor.isStorageAvailable()) || (localSmsMessage.getMessageClass() == SmsConstants.MessageClass.CLASS_0))
            break label211;
          i = 3;
          break;
          if (localSmsMessage.isMWIClearMessage())
          {
            this.mPhone.setVoiceMessageWaiting(i, 0);
            bool2 = localSmsMessage.isMwiDontStore();
            StringBuilder localStringBuilder1 = new StringBuilder().append("Received voice mail indicator clear SMS shouldStore=");
            if (!bool2)
              bool1 = i;
            log(bool1);
          }
        }
        label209: continue;
        label211: i = dispatchNormalMessage(paramSmsMessageBase);
      }
    }
  }

  protected boolean is3gpp2()
  {
    return false;
  }

  protected void onQuitting()
  {
    this.mPhone.mCi.unSetOnNewGsmSms(getHandler());
    this.mCellBroadcastHandler.dispose();
    log("unregistered for 3GPP SMS");
    super.onQuitting();
  }

  protected void onUpdatePhoneObject(PhoneBase paramPhoneBase)
  {
    super.onUpdatePhoneObject(paramPhoneBase);
    log("onUpdatePhoneObject: dispose of old CellBroadcastHandler and make a new one");
    this.mCellBroadcastHandler.dispose();
    this.mCellBroadcastHandler = GsmCellBroadcastHandler.makeGsmCellBroadcastHandler(this.mContext, paramPhoneBase);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmInboundSmsHandler
 * JD-Core Version:    0.6.2
 */