package com.android.internal.telephony.gsm;

public final class SmsBroadcastConfigInfo
{
  private int mFromCodeScheme;
  private int mFromServiceId;
  private boolean mSelected;
  private int mToCodeScheme;
  private int mToServiceId;

  public SmsBroadcastConfigInfo(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    this.mFromServiceId = paramInt1;
    this.mToServiceId = paramInt2;
    this.mFromCodeScheme = paramInt3;
    this.mToCodeScheme = paramInt4;
    this.mSelected = paramBoolean;
  }

  public int getFromCodeScheme()
  {
    return this.mFromCodeScheme;
  }

  public int getFromServiceId()
  {
    return this.mFromServiceId;
  }

  public int getToCodeScheme()
  {
    return this.mToCodeScheme;
  }

  public int getToServiceId()
  {
    return this.mToServiceId;
  }

  public boolean isSelected()
  {
    return this.mSelected;
  }

  public void setFromCodeScheme(int paramInt)
  {
    this.mFromCodeScheme = paramInt;
  }

  public void setFromServiceId(int paramInt)
  {
    this.mFromServiceId = paramInt;
  }

  public void setSelected(boolean paramBoolean)
  {
    this.mSelected = paramBoolean;
  }

  public void setToCodeScheme(int paramInt)
  {
    this.mToCodeScheme = paramInt;
  }

  public void setToServiceId(int paramInt)
  {
    this.mToServiceId = paramInt;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder().append("SmsBroadcastConfigInfo: Id [").append(this.mFromServiceId).append(',').append(this.mToServiceId).append("] Code [").append(this.mFromCodeScheme).append(',').append(this.mToCodeScheme).append("] ");
    if (this.mSelected);
    for (String str = "ENABLED"; ; str = "DISABLED")
      return str;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.SmsBroadcastConfigInfo
 * JD-Core Version:    0.6.2
 */