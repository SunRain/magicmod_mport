package com.android.internal.telephony.gsm;

public class SimTlv
{
  int mCurDataLength;
  int mCurDataOffset;
  int mCurOffset;
  boolean mHasValidTlvObject;
  byte[] mRecord;
  int mTlvLength;
  int mTlvOffset;

  public SimTlv(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.mRecord = paramArrayOfByte;
    this.mTlvOffset = paramInt1;
    this.mTlvLength = paramInt2;
    this.mCurOffset = paramInt1;
    this.mHasValidTlvObject = parseCurrentTlvObject();
  }

  private boolean parseCurrentTlvObject()
  {
    boolean bool = false;
    try
    {
      if ((this.mRecord[this.mCurOffset] != 0) && ((0xFF & this.mRecord[this.mCurOffset]) != 255))
      {
        if ((0xFF & this.mRecord[(1 + this.mCurOffset)]) < 128)
          this.mCurDataLength = (0xFF & this.mRecord[(1 + this.mCurOffset)]);
        for (this.mCurDataOffset = (2 + this.mCurOffset); this.mCurDataLength + this.mCurDataOffset <= this.mTlvOffset + this.mTlvLength; this.mCurDataOffset = (3 + this.mCurOffset))
        {
          bool = true;
          break;
          if ((0xFF & this.mRecord[(1 + this.mCurOffset)]) != 129)
            break;
          this.mCurDataLength = (0xFF & this.mRecord[(2 + this.mCurOffset)]);
        }
      }
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
    }
    return bool;
  }

  public byte[] getData()
  {
    byte[] arrayOfByte;
    if (!this.mHasValidTlvObject)
      arrayOfByte = null;
    while (true)
    {
      return arrayOfByte;
      arrayOfByte = new byte[this.mCurDataLength];
      System.arraycopy(this.mRecord, this.mCurDataOffset, arrayOfByte, 0, this.mCurDataLength);
    }
  }

  public int getTag()
  {
    if (!this.mHasValidTlvObject);
    for (int i = 0; ; i = 0xFF & this.mRecord[this.mCurOffset])
      return i;
  }

  public boolean isValidObject()
  {
    return this.mHasValidTlvObject;
  }

  public boolean nextObject()
  {
    if (!this.mHasValidTlvObject);
    for (boolean bool = false; ; bool = this.mHasValidTlvObject)
    {
      return bool;
      this.mCurOffset = (this.mCurDataOffset + this.mCurDataLength);
      this.mHasValidTlvObject = parseCurrentTlvObject();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.SimTlv
 * JD-Core Version:    0.6.2
 */