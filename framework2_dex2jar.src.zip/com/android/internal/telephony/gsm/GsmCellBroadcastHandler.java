package com.android.internal.telephony.gsm;

import android.content.Context;
import android.os.AsyncResult;
import android.os.Message;
import android.os.SystemProperties;
import android.telephony.CellLocation;
import android.telephony.SmsCbLocation;
import android.telephony.SmsCbMessage;
import android.telephony.gsm.GsmCellLocation;
import com.android.internal.telephony.CellBroadcastHandler;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.WakeLockStateMachine;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class GsmCellBroadcastHandler extends CellBroadcastHandler
{
  private static final boolean VDBG;
  private final HashMap<SmsCbConcatInfo, byte[][]> mSmsCbPageMap = new HashMap(4);

  protected GsmCellBroadcastHandler(Context paramContext, PhoneBase paramPhoneBase)
  {
    super("GsmCellBroadcastHandler", paramContext, paramPhoneBase);
    paramPhoneBase.mCi.setOnNewGsmBroadcastSms(getHandler(), 1, null);
  }

  private SmsCbMessage handleGsmBroadcastSms(AsyncResult paramAsyncResult)
  {
    while (true)
    {
      int n;
      Object localObject1;
      try
      {
        arrayOfByte = (byte[])paramAsyncResult.result;
        localSmsCbHeader = new SmsCbHeader(arrayOfByte);
        String str = SystemProperties.get("gsm.operator.numeric");
        int i = -1;
        int j = -1;
        CellLocation localCellLocation = this.mPhone.getCellLocation();
        if ((localCellLocation instanceof GsmCellLocation))
        {
          GsmCellLocation localGsmCellLocation = (GsmCellLocation)localCellLocation;
          i = localGsmCellLocation.getLac();
          j = localGsmCellLocation.getCid();
        }
        SmsCbConcatInfo localSmsCbConcatInfo;
        switch (localSmsCbHeader.getGeographicalScope())
        {
        case 1:
        default:
          localSmsCbLocation = new SmsCbLocation(str);
          int k = localSmsCbHeader.getNumberOfPages();
          if (k <= 1)
            continue;
          localSmsCbConcatInfo = new SmsCbConcatInfo(localSmsCbHeader, localSmsCbLocation);
          localObject2 = (byte[][])this.mSmsCbPageMap.get(localSmsCbConcatInfo);
          if (localObject2 == null)
          {
            localObject2 = new byte[k][];
            this.mSmsCbPageMap.put(localSmsCbConcatInfo, localObject2);
          }
          localObject2[(-1 + localSmsCbHeader.getPageIndex())] = arrayOfByte;
          Object localObject3 = localObject2;
          int m = localObject3.length;
          n = 0;
          if (n >= m)
            continue;
          if (localObject3[n] != null)
            break label372;
          localObject1 = null;
          break;
        case 2:
          localSmsCbLocation = new SmsCbLocation(str, i, -1);
          break;
        case 0:
        case 3:
        }
        localSmsCbLocation = new SmsCbLocation(str, i, j);
        continue;
        this.mSmsCbPageMap.remove(localSmsCbConcatInfo);
        Iterator localIterator = this.mSmsCbPageMap.keySet().iterator();
        if (localIterator.hasNext())
        {
          if (((SmsCbConcatInfo)localIterator.next()).matchesLocation(str, i, j))
            continue;
          localIterator.remove();
          continue;
        }
      }
      catch (RuntimeException localRuntimeException)
      {
        byte[] arrayOfByte;
        SmsCbHeader localSmsCbHeader;
        SmsCbLocation localSmsCbLocation;
        loge("Error in decoding SMS CB pdu", localRuntimeException);
        localObject1 = null;
        break label370;
        Object localObject2 = new byte[1][];
        localObject2[0] = arrayOfByte;
        continue;
        SmsCbMessage localSmsCbMessage = GsmSmsCbMessage.createSmsCbMessage(localSmsCbHeader, localSmsCbLocation, (byte[][])localObject2);
        localObject1 = localSmsCbMessage;
      }
      label370: return localObject1;
      label372: n++;
    }
  }

  public static GsmCellBroadcastHandler makeGsmCellBroadcastHandler(Context paramContext, PhoneBase paramPhoneBase)
  {
    GsmCellBroadcastHandler localGsmCellBroadcastHandler = new GsmCellBroadcastHandler(paramContext, paramPhoneBase);
    localGsmCellBroadcastHandler.start();
    return localGsmCellBroadcastHandler;
  }

  protected boolean handleSmsMessage(Message paramMessage)
  {
    if ((paramMessage.obj instanceof AsyncResult))
    {
      SmsCbMessage localSmsCbMessage = handleGsmBroadcastSms((AsyncResult)paramMessage.obj);
      if (localSmsCbMessage != null)
        handleBroadcastSms(localSmsCbMessage);
    }
    for (boolean bool = true; ; bool = super.handleSmsMessage(paramMessage))
      return bool;
  }

  protected void onQuitting()
  {
    this.mPhone.mCi.unSetOnNewGsmBroadcastSms(getHandler());
    super.onQuitting();
  }

  private static final class SmsCbConcatInfo
  {
    private final SmsCbHeader mHeader;
    private final SmsCbLocation mLocation;

    SmsCbConcatInfo(SmsCbHeader paramSmsCbHeader, SmsCbLocation paramSmsCbLocation)
    {
      this.mHeader = paramSmsCbHeader;
      this.mLocation = paramSmsCbLocation;
    }

    public boolean equals(Object paramObject)
    {
      boolean bool = false;
      if ((paramObject instanceof SmsCbConcatInfo))
      {
        SmsCbConcatInfo localSmsCbConcatInfo = (SmsCbConcatInfo)paramObject;
        if ((this.mHeader.getSerialNumber() == localSmsCbConcatInfo.mHeader.getSerialNumber()) && (this.mLocation.equals(localSmsCbConcatInfo.mLocation)))
          bool = true;
      }
      return bool;
    }

    public int hashCode()
    {
      return 31 * this.mHeader.getSerialNumber() + this.mLocation.hashCode();
    }

    public boolean matchesLocation(String paramString, int paramInt1, int paramInt2)
    {
      return this.mLocation.isInLocationArea(paramString, paramInt1, paramInt2);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmCellBroadcastHandler
 * JD-Core Version:    0.6.2
 */