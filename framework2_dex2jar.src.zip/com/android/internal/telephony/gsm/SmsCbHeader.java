package com.android.internal.telephony.gsm;

import android.telephony.SmsCbCmasInfo;
import android.telephony.SmsCbEtwsInfo;
import java.util.Arrays;

class SmsCbHeader
{
  static final int FORMAT_ETWS_PRIMARY = 3;
  static final int FORMAT_GSM = 1;
  static final int FORMAT_UMTS = 2;
  private static final int MESSAGE_TYPE_CBS_MESSAGE = 1;
  static final int PDU_HEADER_LENGTH = 6;
  private static final int PDU_LENGTH_ETWS = 56;
  private static final int PDU_LENGTH_GSM = 88;
  private final SmsCbCmasInfo mCmasInfo;
  private final int mDataCodingScheme;
  private final SmsCbEtwsInfo mEtwsInfo;
  private final int mFormat;
  private final int mGeographicalScope;
  private final int mMessageIdentifier;
  private final int mNrOfPages;
  private final int mPageIndex;
  private final int mSerialNumber;

  public SmsCbHeader(byte[] paramArrayOfByte)
    throws IllegalArgumentException
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length < 6))
      throw new IllegalArgumentException("Illegal PDU");
    boolean bool3;
    boolean bool4;
    label148: byte[] arrayOfByte;
    if (paramArrayOfByte.length <= 88)
    {
      this.mGeographicalScope = ((0xC0 & paramArrayOfByte[0]) >>> 6);
      this.mSerialNumber = ((0xFF & paramArrayOfByte[0]) << 8 | 0xFF & paramArrayOfByte[1]);
      this.mMessageIdentifier = ((0xFF & paramArrayOfByte[2]) << 8 | 0xFF & paramArrayOfByte[3]);
      if ((isEtwsMessage()) && (paramArrayOfByte.length <= 56))
      {
        this.mFormat = 3;
        this.mDataCodingScheme = -1;
        this.mPageIndex = -1;
        this.mNrOfPages = -1;
        if ((0x1 & paramArrayOfByte[4]) != 0)
        {
          bool3 = true;
          if ((0x80 & paramArrayOfByte[5]) == 0)
            break label207;
          bool4 = true;
          int i3 = (0xFE & paramArrayOfByte[4]) >>> 1;
          if (paramArrayOfByte.length <= 6)
            break label213;
          arrayOfByte = Arrays.copyOfRange(paramArrayOfByte, 6, paramArrayOfByte.length);
          label176: this.mEtwsInfo = new SmsCbEtwsInfo(i3, bool3, bool4, arrayOfByte);
          this.mCmasInfo = null;
        }
      }
    }
    while (true)
    {
      return;
      bool3 = false;
      break;
      label207: bool4 = false;
      break label148;
      label213: arrayOfByte = null;
      break label176;
      this.mFormat = 1;
      this.mDataCodingScheme = (0xFF & paramArrayOfByte[4]);
      int i1 = (0xF0 & paramArrayOfByte[5]) >>> 4;
      int i2 = 0xF & paramArrayOfByte[5];
      if ((i1 == 0) || (i2 == 0) || (i1 > i2))
      {
        i1 = 1;
        i2 = 1;
      }
      this.mPageIndex = i1;
      for (this.mNrOfPages = i2; ; this.mNrOfPages = 1)
      {
        if (!isEtwsMessage())
          break label459;
        boolean bool1 = isEtwsEmergencyUserAlert();
        boolean bool2 = isEtwsPopupAlert();
        this.mEtwsInfo = new SmsCbEtwsInfo(getEtwsWarningType(), bool1, bool2, null);
        this.mCmasInfo = null;
        break;
        this.mFormat = 2;
        int i = paramArrayOfByte[0];
        if (i != 1)
          throw new IllegalArgumentException("Unsupported message type " + i);
        this.mMessageIdentifier = ((0xFF & paramArrayOfByte[1]) << 8 | 0xFF & paramArrayOfByte[2]);
        this.mGeographicalScope = ((0xC0 & paramArrayOfByte[3]) >>> 6);
        this.mSerialNumber = ((0xFF & paramArrayOfByte[3]) << 8 | 0xFF & paramArrayOfByte[4]);
        this.mDataCodingScheme = (0xFF & paramArrayOfByte[5]);
        this.mPageIndex = 1;
      }
      label459: if (isCmasMessage())
      {
        int j = getCmasMessageClass();
        int k = getCmasSeverity();
        int m = getCmasUrgency();
        int n = getCmasCertainty();
        this.mEtwsInfo = null;
        this.mCmasInfo = new SmsCbCmasInfo(j, -1, -1, k, m, n);
      }
      else
      {
        this.mEtwsInfo = null;
        this.mCmasInfo = null;
      }
    }
  }

  private int getCmasCertainty()
  {
    int i;
    switch (this.mMessageIdentifier)
    {
    default:
      i = -1;
    case 4371:
    case 4373:
    case 4375:
    case 4377:
    case 4372:
    case 4374:
    case 4376:
    case 4378:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
    }
  }

  private int getCmasMessageClass()
  {
    int i;
    switch (this.mMessageIdentifier)
    {
    default:
      i = -1;
    case 4370:
    case 4371:
    case 4372:
    case 4373:
    case 4374:
    case 4375:
    case 4376:
    case 4377:
    case 4378:
    case 4379:
    case 4380:
    case 4381:
    case 4382:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
      continue;
      i = 2;
      continue;
      i = 3;
      continue;
      i = 4;
      continue;
      i = 5;
      continue;
      i = 6;
    }
  }

  private int getCmasSeverity()
  {
    int i;
    switch (this.mMessageIdentifier)
    {
    default:
      i = -1;
    case 4371:
    case 4372:
    case 4373:
    case 4374:
    case 4375:
    case 4376:
    case 4377:
    case 4378:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
    }
  }

  private int getCmasUrgency()
  {
    int i;
    switch (this.mMessageIdentifier)
    {
    default:
      i = -1;
    case 4371:
    case 4372:
    case 4375:
    case 4376:
    case 4373:
    case 4374:
    case 4377:
    case 4378:
    }
    while (true)
    {
      return i;
      i = 0;
      continue;
      i = 1;
    }
  }

  private int getEtwsWarningType()
  {
    return -4352 + this.mMessageIdentifier;
  }

  private boolean isCmasMessage()
  {
    if ((this.mMessageIdentifier >= 4370) && (this.mMessageIdentifier <= 4399));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isEtwsEmergencyUserAlert()
  {
    if ((0x2000 & this.mSerialNumber) != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isEtwsMessage()
  {
    if ((0xFFF8 & this.mMessageIdentifier) == 4352);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isEtwsPopupAlert()
  {
    if ((0x1000 & this.mSerialNumber) != 0);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  SmsCbCmasInfo getCmasInfo()
  {
    return this.mCmasInfo;
  }

  int getDataCodingScheme()
  {
    return this.mDataCodingScheme;
  }

  SmsCbEtwsInfo getEtwsInfo()
  {
    return this.mEtwsInfo;
  }

  int getGeographicalScope()
  {
    return this.mGeographicalScope;
  }

  int getNumberOfPages()
  {
    return this.mNrOfPages;
  }

  int getPageIndex()
  {
    return this.mPageIndex;
  }

  int getSerialNumber()
  {
    return this.mSerialNumber;
  }

  int getServiceCategory()
  {
    return this.mMessageIdentifier;
  }

  boolean isEmergencyMessage()
  {
    if ((this.mMessageIdentifier >= 4352) && (this.mMessageIdentifier <= 6399));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isEtwsPrimaryNotification()
  {
    if (this.mFormat == 3);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isUmtsFormat()
  {
    if (this.mFormat == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public String toString()
  {
    return "SmsCbHeader{GS=" + this.mGeographicalScope + ", serialNumber=0x" + Integer.toHexString(this.mSerialNumber) + ", messageIdentifier=0x" + Integer.toHexString(this.mMessageIdentifier) + ", DCS=0x" + Integer.toHexString(this.mDataCodingScheme) + ", page " + this.mPageIndex + " of " + this.mNrOfPages + '}';
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.SmsCbHeader
 * JD-Core Version:    0.6.2
 */