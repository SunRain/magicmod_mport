package com.android.internal.telephony.gsm;

import android.os.Handler;
import android.os.Message;
import android.telephony.Rlog;
import com.android.internal.telephony.IccPhoneBookInterfaceManager;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.uicc.IccFileHandler;
import java.util.concurrent.atomic.AtomicBoolean;

public class SimPhoneBookInterfaceManager extends IccPhoneBookInterfaceManager
{
  static final String LOG_TAG = "SimPhoneBookIM";

  public SimPhoneBookInterfaceManager(GSMPhone paramGSMPhone)
  {
    super(paramGSMPhone);
  }

  public void dispose()
  {
    super.dispose();
  }

  protected void finalize()
  {
    try
    {
      super.finalize();
      Rlog.d("SimPhoneBookIM", "SimPhoneBookInterfaceManager finalized");
      return;
    }
    catch (Throwable localThrowable)
    {
      while (true)
        Rlog.e("SimPhoneBookIM", "Error while finalizing:", localThrowable);
    }
  }

  public int[] getAdnRecordsSize(int paramInt)
  {
    logd("getAdnRecordsSize: efid=" + paramInt);
    synchronized (this.mLock)
    {
      checkThread();
      this.mRecordSize = new int[3];
      AtomicBoolean localAtomicBoolean = new AtomicBoolean(false);
      Message localMessage = this.mBaseHandler.obtainMessage(1, localAtomicBoolean);
      IccFileHandler localIccFileHandler = this.mPhone.getIccFileHandler();
      if (localIccFileHandler != null)
      {
        localIccFileHandler.getEFLinearRecordSize(paramInt, localMessage);
        waitForResult(localAtomicBoolean);
      }
      return this.mRecordSize;
    }
  }

  protected void logd(String paramString)
  {
    Rlog.d("SimPhoneBookIM", "[SimPbInterfaceManager] " + paramString);
  }

  protected void loge(String paramString)
  {
    Rlog.e("SimPhoneBookIM", "[SimPbInterfaceManager] " + paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.SimPhoneBookInterfaceManager
 * JD-Core Version:    0.6.2
 */