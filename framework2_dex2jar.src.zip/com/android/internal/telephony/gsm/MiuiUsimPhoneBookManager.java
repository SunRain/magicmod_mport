package com.android.internal.telephony.gsm;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.telephony.PhoneNumberUtils;
import android.text.TextUtils;
import android.util.Log;
import com.android.internal.telephony.GsmAlphabet;
import com.android.internal.telephony.IccUtils;
import com.android.internal.telephony.MiuiIccProviderException;
import com.android.internal.telephony.uicc.AdnRecordCache;
import com.android.internal.telephony.uicc.IccConstants;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.telephony.uicc.MiuiAdnRecord;
import com.android.internal.telephony.uicc.MiuiAdnRecordLoader;
import com.android.internal.telephony.uicc.MiuiIccFileHandler;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MiuiUsimPhoneBookManager extends Handler
  implements IccConstants
{
  static final boolean DBG = true;
  static final int EVENT_ANR_RECORD_LOAD_DONE = 4;
  static final int EVENT_EMAIL_RECORD_LOAD_DONE = 5;
  static final int EVENT_IAP_RECORD_LOAD_DONE = 6;
  static final int EVENT_PBR_LOAD_DONE = 1;
  static final int EVENT_RECORD_SIZE_READ_DONE = 2;
  static final int EVENT_UPDATE_DONE = 7;
  static final int EVENT_USIM_ADN_LOAD_DONE = 3;
  static final String LOG_TAG = "UsimPhoneBookManager";
  static final int MAX_ANR_DATA_LENGTH = 11;
  static final int MAX_ANR_LENGTH = 20;
  static final int USIM_EFAAS_TAG = 199;
  static final int USIM_EFADN_TAG = 192;
  static final int USIM_EFANR_TAG = 196;
  static final int USIM_EFCCP1_TAG = 203;
  static final int USIM_EFEMAIL_TAG = 202;
  static final int USIM_EFEXT1_TAG = 194;
  static final int USIM_EFGRP_TAG = 198;
  static final int USIM_EFGSD_TAG = 200;
  static final int USIM_EFIAP_TAG = 193;
  static final int USIM_EFPBC_TAG = 197;
  static final int USIM_EFSNE_TAG = 195;
  static final int USIM_EFUID_TAG = 201;
  static final int USIM_TYPE1_TAG = 168;
  static final int USIM_TYPE2_CONDITIONAL_LENGTH = 2;
  static final int USIM_TYPE2_TAG = 169;
  static final int USIM_TYPE3_TAG = 170;
  AdnRecordCache mAdnCache;
  MiuiIccFileHandler mFh;
  byte[][][] mIapFiles;
  boolean mIsPbrPresent;
  Object mLock = new Object();
  PbrFile mPbrFile;
  ArrayList<MiuiAdnRecord> mPhoneBookRecords;
  Object mReadLock = new Object();
  AtomicInteger mReadingAnrNum = new AtomicInteger(0);
  AtomicInteger mReadingEmailNum = new AtomicInteger(0);
  AtomicInteger mReadingIapNum = new AtomicInteger(0);
  HashMap<Integer, RecordSize> mRecordSize;
  boolean mSupportAnr = true;
  boolean mSupportEmail = true;
  AsyncResult mUpdateResult;

  public MiuiUsimPhoneBookManager(IccFileHandler paramIccFileHandler, AdnRecordCache paramAdnRecordCache)
  {
    this.mFh = new MiuiIccFileHandler(paramIccFileHandler);
    this.mPhoneBookRecords = new ArrayList();
    this.mAdnCache = paramAdnRecordCache;
    this.mPbrFile = null;
    this.mIsPbrPresent = true;
    this.mRecordSize = new HashMap();
  }

  private int getRecordNumber(EfRecord paramEfRecord, int paramInt)
  {
    BitSet localBitSet = new BitSet(paramInt + 1);
    localBitSet.set(1, paramInt + 1);
    Iterator localIterator = ((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(paramEfRecord.mTag))).iterator();
    while (localIterator.hasNext())
    {
      EfRecord localEfRecord = (EfRecord)localIterator.next();
      if (localEfRecord.mEfTag == paramEfRecord.mEfTag)
      {
        byte[][] arrayOfByte = this.mIapFiles[localEfRecord.mPbrIndex];
        for (int i = 0; i < arrayOfByte.length; i++)
        {
          byte[] arrayOfByte1 = arrayOfByte[i];
          if (arrayOfByte1 != null)
          {
            int j = arrayOfByte1[localEfRecord.mType2Record];
            if ((j > 0) && (j < 255) && (j <= paramInt))
              localBitSet.clear(j);
          }
        }
      }
    }
    return localBitSet.nextSetBit(1);
  }

  byte[] buildAnrRecord(String paramString, int paramInt)
  {
    byte[] arrayOfByte1 = new byte[paramInt];
    Arrays.fill(arrayOfByte1, (byte)-1);
    String str = PhoneNumberUtils.convertPreDial(paramString);
    if (TextUtils.isEmpty(str));
    while (true)
    {
      return arrayOfByte1;
      if (str.length() > 20)
      {
        arrayOfByte1 = null;
      }
      else
      {
        byte[] arrayOfByte2 = PhoneNumberUtils.numberToCalledPartyBCD(str);
        if (arrayOfByte2 != null)
        {
          System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 2, arrayOfByte2.length);
          arrayOfByte1[1] = ((byte)arrayOfByte2.length);
        }
      }
    }
  }

  byte[] buildEmailRecord(String paramString, int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = new byte[paramInt2];
    Arrays.fill(arrayOfByte1, (byte)-1);
    int i;
    byte[] arrayOfByte2;
    int j;
    if (((EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(0)).mType == 169)
    {
      i = 1;
      if (!TextUtils.isEmpty(paramString))
      {
        arrayOfByte2 = GsmAlphabet.stringToGsm8BitPacked(paramString);
        if (i == 0)
          break label95;
        j = -2 + arrayOfByte1.length;
        label75: if (arrayOfByte2.length <= j)
          break label103;
        arrayOfByte1 = null;
      }
    }
    while (true)
    {
      return arrayOfByte1;
      i = 0;
      break;
      label95: j = arrayOfByte1.length;
      break label75;
      label103: System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
      if (i != 0)
      {
        int k = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
        int m = (paramInt1 - 1) / k;
        EfRecord localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(192))).get(m);
        arrayOfByte1[(paramInt2 - 2)] = localEfRecord.mSfi;
        arrayOfByte1[(paramInt2 - 1)] = ((byte)(1 + (paramInt1 - 1) % k));
      }
    }
  }

  boolean checkAnrCapacityFree(int paramInt, String paramString)
  {
    boolean bool1 = true;
    if (!this.mSupportAnr)
      bool1 = false;
    int i;
    EfRecord localEfRecord;
    do
    {
      do
        return bool1;
      while (TextUtils.isEmpty(paramString));
      i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(196))).mRecordCount;
      int j = (paramInt - 1) / ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
      localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(196))).get(j);
    }
    while (localEfRecord.mType != 169);
    if (getRecordNumber(localEfRecord, i) > 0);
    for (boolean bool2 = bool1; ; bool2 = false)
    {
      bool1 = bool2;
      break;
    }
  }

  boolean checkAnrLength(String paramString)
  {
    String str = PhoneNumberUtils.convertPreDial(paramString);
    if ((TextUtils.isEmpty(str)) || (str.length() <= 20));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean checkEmailCapacityFree(int paramInt, String[] paramArrayOfString)
  {
    boolean bool1 = true;
    if (!this.mSupportEmail)
      bool1 = false;
    int i;
    EfRecord localEfRecord;
    do
    {
      do
        return bool1;
      while (!hasEmail(paramArrayOfString));
      i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(202))).mRecordCount;
      int j = (paramInt - 1) / ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
      localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(j);
    }
    while (localEfRecord.mType != 169);
    if (getRecordNumber(localEfRecord, i) > 0);
    for (boolean bool2 = bool1; ; bool2 = false)
    {
      bool1 = bool2;
      break;
    }
  }

  boolean checkEmailLength(String[] paramArrayOfString)
  {
    int i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(202))).mRecordSize;
    int j;
    if ((((RecordSize)this.mRecordSize.get(Integer.valueOf(202))).mRecordCount != -1) && (((EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(0)).mType == 169))
    {
      j = i - 2;
      if ((paramArrayOfString == null) || (paramArrayOfString[0] == null))
        break label123;
      byte[] arrayOfByte = GsmAlphabet.stringToGsm8BitPacked(paramArrayOfString[0]);
      if ((j == -1) || (arrayOfByte.length <= j))
        break label123;
    }
    label123: for (boolean bool = false; ; bool = true)
    {
      return bool;
      j = i;
      break;
    }
  }

  void createPbrFile(ArrayList<byte[]> paramArrayList)
  {
    if (paramArrayList == null)
    {
      this.mPbrFile = null;
      this.mIsPbrPresent = false;
    }
    while (true)
    {
      return;
      this.mPbrFile = new PbrFile(paramArrayList);
    }
  }

  public ArrayList<MiuiAdnRecord> getAdnRecordsIfLoaded()
  {
    if (this.mPhoneBookRecords.isEmpty());
    for (Object localObject = null; ; localObject = this.mPhoneBookRecords)
      return localObject;
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (true)
    {
      return;
      readPbrFileDone((AsyncResult)paramMessage.obj);
      continue;
      readRecordSizeDone(paramMessage.arg1, (AsyncResult)paramMessage.obj);
      continue;
      readAdnFileDone((AsyncResult)paramMessage.obj);
      continue;
      readAnrRecordDone(paramMessage.arg1, paramMessage.arg2, (AsyncResult)paramMessage.obj);
      continue;
      readEmailRecordDone(paramMessage.arg1, paramMessage.arg2, (AsyncResult)paramMessage.obj);
      continue;
      readIapRecordDone(paramMessage.arg1, paramMessage.arg2, (AsyncResult)paramMessage.obj);
      continue;
      synchronized (this.mLock)
      {
        this.mUpdateResult = ((AsyncResult)paramMessage.obj);
        this.mLock.notify();
      }
    }
  }

  boolean hasEmail(String[] paramArrayOfString)
  {
    boolean bool = false;
    if ((paramArrayOfString != null) && (!TextUtils.isEmpty(paramArrayOfString[0])))
      bool = true;
    return bool;
  }

  public ArrayList<MiuiAdnRecord> loadEfFilesFromUsim()
  {
    while (true)
    {
      ArrayList localArrayList;
      int i;
      int j;
      synchronized (this.mLock)
      {
        if (!this.mPhoneBookRecords.isEmpty())
          localArrayList = this.mPhoneBookRecords;
        else if (!this.mIsPbrPresent)
          localArrayList = null;
      }
      int k = 0;
    }
  }

  void readAdnFileAndWait(int paramInt)
  {
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(paramInt));
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(192))))
    {
      Log.d("UsimPhoneBookManager", "readAdnFileAndWait: no ADN tag in PBR " + paramInt);
      return;
    }
    if (localMap.containsKey(Integer.valueOf(194)));
    for (int i = ((Integer)localMap.get(Integer.valueOf(194))).intValue(); ; i = 0)
    {
      while (true)
      {
        this.mAdnCache.requestLoadAllAdnLike(((Integer)localMap.get(Integer.valueOf(192))).intValue(), i, obtainMessage(3));
        try
        {
          this.mLock.wait();
        }
        catch (InterruptedException localInterruptedException)
        {
          Log.e("UsimPhoneBookManager", "Interrupted Exception in readAdnFileAndWait");
        }
      }
      break;
    }
  }

  void readAdnFileDone(AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
    {
      ArrayList localArrayList = (ArrayList)paramAsyncResult.result;
      this.mPhoneBookRecords.addAll(localArrayList);
    }
    synchronized (this.mLock)
    {
      this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readAdnFileDone failed", paramAsyncResult.exception);
    }
  }

  void readAnrFileAndWait(int paramInt)
  {
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(paramInt));
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(196))))
    {
      Log.d("UsimPhoneBookManager", "readAnrFileAndWait: no ANR tag in PBR " + paramInt);
      this.mSupportAnr = false;
    }
    while (true)
    {
      return;
      if (!this.mRecordSize.containsKey(Integer.valueOf(196)))
      {
        Log.e("UsimPhoneBookManager", "readAnrFileAndWait: size of ANR tag in PBR is incorrect");
        this.mSupportAnr = false;
      }
      else
      {
        EfRecord localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(196))).get(paramInt);
        if (localEfRecord.mType == 169)
          readType2Ef(localEfRecord);
        else if (localEfRecord.mType == 168)
          readType1Ef(localEfRecord);
      }
    }
  }

  void readAnrRecordDone(int paramInt1, int paramInt2, AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
      setPhoneAdnRecordAnr(paramInt1, paramInt2, (byte[])paramAsyncResult.result);
    synchronized (this.mLock)
    {
      this.mReadingAnrNum.decrementAndGet();
      if (this.mReadingAnrNum.get() == 0)
        this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readAnrRecord failed for pbrIndex=" + paramInt1 + ", adnIndex=" + paramInt2, paramAsyncResult.exception);
    }
  }

  void readEmailFileAndWait(int paramInt)
  {
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(paramInt));
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(202))))
    {
      Log.d("UsimPhoneBookManager", "readEmailFileAndWait: no EMAIL tag in PBR " + paramInt);
      this.mSupportEmail = false;
    }
    while (true)
    {
      return;
      if (!this.mRecordSize.containsKey(Integer.valueOf(202)))
      {
        Log.e("UsimPhoneBookManager", "readEmailFileAndWait: size of EMAIL tag in PBR is incorrect");
        this.mSupportEmail = false;
      }
      else
      {
        EfRecord localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(paramInt);
        if (localEfRecord.mType == 169)
          readType2Ef(localEfRecord);
        else if (localEfRecord.mType == 168)
          readType1Ef(localEfRecord);
      }
    }
  }

  void readEmailRecordDone(int paramInt1, int paramInt2, AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
      setPhoneAdnRecordEmail(paramInt1, paramInt2, (byte[])paramAsyncResult.result);
    synchronized (this.mLock)
    {
      this.mReadingEmailNum.decrementAndGet();
      if (this.mReadingEmailNum.get() == 0)
        this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readAnrRecord failed for pbrIndex=" + paramInt1 + ", adnIndex=" + paramInt2, paramAsyncResult.exception);
    }
  }

  void readIapFileAndWait(int paramInt)
  {
    if (this.mIapFiles == null)
      this.mIapFiles = new byte[this.mPbrFile.mFileIds.size()][][];
    if (this.mIapFiles[paramInt] != null);
    while (true)
    {
      return;
      int i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
      byte[][] arrayOfByte = new byte[i][];
      int j = ((RecordSize)this.mRecordSize.get(Integer.valueOf(193))).mRecordSize;
      for (int k = 0; k < i; k++)
      {
        byte[] arrayOfByte1 = new byte[j];
        Arrays.fill(arrayOfByte1, (byte)-1);
        arrayOfByte[k] = arrayOfByte1;
      }
      this.mIapFiles[paramInt] = arrayOfByte;
      int m = paramInt * i;
      int n = m + i;
      if (this.mPhoneBookRecords.size() < n)
        n = this.mPhoneBookRecords.size();
      int i1 = ((Integer)((Map)this.mPbrFile.mFileIds.get(Integer.valueOf(paramInt))).get(Integer.valueOf(193))).intValue();
      for (int i2 = m; i2 < n; i2++)
        if (!((MiuiAdnRecord)this.mPhoneBookRecords.get(i2)).isEmpty())
        {
          this.mReadingIapNum.incrementAndGet();
          this.mFh.loadEFLinearFixed(i1, j, i2 + 1 - m, obtainMessage(6, paramInt, i2 - m));
        }
      if (this.mReadingIapNum.get() != 0)
        try
        {
          this.mLock.wait();
        }
        catch (InterruptedException localInterruptedException)
        {
          Log.e("UsimPhoneBookManager", "Interrupted Exception in readIapFileAndWait");
        }
    }
  }

  void readIapRecordDone(int paramInt1, int paramInt2, AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
      this.mIapFiles[paramInt1][paramInt2] = ((byte[])(byte[])paramAsyncResult.result);
    synchronized (this.mLock)
    {
      this.mReadingIapNum.decrementAndGet();
      if (this.mReadingIapNum.get() == 0)
        this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readIapRecordDone failed for pbrIndex=" + paramInt1 + ", iapIndex=" + paramInt2, paramAsyncResult.exception);
    }
  }

  void readPbrFileAndWait()
  {
    this.mFh.loadEFLinearFixedAll(20272, obtainMessage(1));
    try
    {
      this.mLock.wait();
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        Log.e("UsimPhoneBookManager", "Interrupted Exception in readPbrFileAndWait");
    }
  }

  void readPbrFileDone(AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
      createPbrFile((ArrayList)paramAsyncResult.result);
    synchronized (this.mLock)
    {
      this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readPbrFile failed", paramAsyncResult.exception);
    }
  }

  RecordSize readRecordSizeAndWait(int paramInt1, int paramInt2)
  {
    this.mFh.getEFLinearRecordSize(paramInt2, obtainMessage(2, paramInt1, 0));
    try
    {
      this.mLock.wait();
      return (RecordSize)this.mRecordSize.get(Integer.valueOf(paramInt1));
    }
    catch (InterruptedException localInterruptedException)
    {
      while (true)
        Log.e("UsimPhoneBookManager", "Interrupted Exception in readRecordSizeAndWait");
    }
  }

  void readRecordSizeDone(int paramInt, AsyncResult paramAsyncResult)
  {
    if (paramAsyncResult.exception == null)
    {
      int[] arrayOfInt = (int[])paramAsyncResult.result;
      if (arrayOfInt.length == 3)
        this.mRecordSize.put(Integer.valueOf(paramInt), new RecordSize(arrayOfInt));
    }
    synchronized (this.mLock)
    {
      this.mLock.notify();
      return;
      Log.e("UsimPhoneBookManager", "readRecordSize failed", paramAsyncResult.exception);
    }
  }

  void readType1Ef(EfRecord paramEfRecord)
  {
    if (paramEfRecord.mType != 168);
    while (true)
    {
      return;
      int i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
      int j = i * paramEfRecord.mPbrIndex;
      int k = j + i;
      if (this.mPhoneBookRecords.size() < k)
        k = this.mPhoneBookRecords.size();
      int m;
      switch (paramEfRecord.mTag)
      {
      default:
        Log.e("UsimPhoneBookManager", "readType1Ef: unsupported tag " + paramEfRecord.mTag);
        break;
      case 196:
        m = 4;
      case 202:
        for (AtomicInteger localAtomicInteger = this.mReadingAnrNum; ; localAtomicInteger = this.mReadingEmailNum)
        {
          int n = ((RecordSize)this.mRecordSize.get(Integer.valueOf(paramEfRecord.mTag))).mRecordSize;
          for (int i1 = j; i1 < k; i1++)
            if (!((MiuiAdnRecord)this.mPhoneBookRecords.get(i1)).isEmpty())
            {
              localAtomicInteger.incrementAndGet();
              this.mFh.loadEFLinearFixed(paramEfRecord.mEfTag, n, i1 + 1 - j, obtainMessage(m, paramEfRecord.mPbrIndex, i1));
            }
          m = 5;
        }
        if (localAtomicInteger.get() != 0)
          try
          {
            this.mLock.wait();
          }
          catch (InterruptedException localInterruptedException)
          {
            Log.e("UsimPhoneBookManager", "Interrupted Exception in readType1Ef");
          }
        break;
      }
    }
  }

  void readType2Ef(EfRecord paramEfRecord)
  {
    if (paramEfRecord.mType != 169);
    while (true)
    {
      return;
      Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(paramEfRecord.mPbrIndex));
      if ((localMap != null) && (localMap.containsKey(Integer.valueOf(193))))
      {
        readIapFileAndWait(paramEfRecord.mPbrIndex);
        if ((this.mIapFiles == null) || (this.mIapFiles.length <= paramEfRecord.mPbrIndex) || (this.mIapFiles[paramEfRecord.mPbrIndex] == null))
        {
          Log.e("UsimPhoneBookManager", "readType2Ef: IAP file is empty");
        }
        else
        {
          int i;
          AtomicInteger localAtomicInteger;
          int n;
          int i1;
          label268: byte[] arrayOfByte1;
          switch (paramEfRecord.mTag)
          {
          default:
            Log.e("UsimPhoneBookManager", "readType2EF: no implementation for " + paramEfRecord.mTag);
            break;
          case 196:
            i = 4;
            localAtomicInteger = this.mReadingAnrNum;
            byte[][] arrayOfByte = this.mIapFiles[paramEfRecord.mPbrIndex];
            int j = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
            int k = j * paramEfRecord.mPbrIndex;
            int m = k + j;
            if (this.mPhoneBookRecords.size() < m)
              m = this.mPhoneBookRecords.size();
            n = ((RecordSize)this.mRecordSize.get(Integer.valueOf(paramEfRecord.mTag))).mRecordSize;
            i1 = k;
            if (i1 < m)
              if (!((MiuiAdnRecord)this.mPhoneBookRecords.get(i1)).isEmpty())
              {
                arrayOfByte1 = arrayOfByte[(i1 - k)];
                if (arrayOfByte1 != null)
                  break label355;
                Log.e("UsimPhoneBookManager", "readType2Ef: No IAP for ADN " + (i1 + 1));
              }
          case 202:
            while (true)
            {
              i1++;
              break label268;
              i = 5;
              localAtomicInteger = this.mReadingEmailNum;
              break;
              label355: int i2 = arrayOfByte1[paramEfRecord.mType2Record];
              if (i2 == 255)
              {
                Log.e("UsimPhoneBookManager", "readType2Ef: NO IAP index for ADN " + (i1 + 1));
              }
              else
              {
                localAtomicInteger.incrementAndGet();
                this.mFh.loadEFLinearFixed(paramEfRecord.mEfTag, n, i2, obtainMessage(i, paramEfRecord.mPbrIndex, i1));
              }
            }
            if (localAtomicInteger.get() != 0)
              try
              {
                this.mLock.wait();
              }
              catch (InterruptedException localInterruptedException)
              {
                Log.e("UsimPhoneBookManager", "Interrupted Exception in readType2Ef");
              }
            break;
          }
        }
      }
    }
  }

  public void reset()
  {
    this.mPhoneBookRecords.clear();
    this.mPbrFile = null;
    this.mIapFiles = ((byte[][][])null);
    this.mRecordSize.clear();
  }

  void setPhoneAdnRecordAnr(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    while (true)
    {
      return;
      int i = paramArrayOfByte[1];
      if ((i > 0) && (i < 11))
      {
        String str = PhoneNumberUtils.calledPartyBCDToString(paramArrayOfByte, 2, i);
        if (!TextUtils.isEmpty(str))
          ((MiuiAdnRecord)this.mPhoneBookRecords.get(paramInt2)).setAnr(str);
      }
    }
  }

  void setPhoneAdnRecordEmail(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    while (true)
    {
      return;
      int i = paramArrayOfByte.length;
      if (i >= 2)
        i -= 2;
      String str = IccUtils.adnStringFieldToString(paramArrayOfByte, 0, i);
      if (!TextUtils.isEmpty(str))
        ((MiuiAdnRecord)this.mPhoneBookRecords.get(paramInt2)).setEmails(new String[] { str });
    }
  }

  // ERROR //
  public int update(int paramInt, MiuiAdnRecord paramMiuiAdnRecord)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 102	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mLock	Ljava/lang/Object;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 95	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mSupportEmail	Z
    //   11: ifeq +75 -> 86
    //   14: aload_0
    //   15: iload_1
    //   16: aload_2
    //   17: invokevirtual 543	com/android/internal/telephony/uicc/MiuiAdnRecord:getEmails	()[Ljava/lang/String;
    //   20: invokevirtual 545	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:checkEmailCapacityFree	(I[Ljava/lang/String;)Z
    //   23: ifne +13 -> 36
    //   26: sipush -1011
    //   29: istore 5
    //   31: aload_3
    //   32: monitorexit
    //   33: goto +135 -> 168
    //   36: aload_0
    //   37: aload_2
    //   38: invokevirtual 543	com/android/internal/telephony/uicc/MiuiAdnRecord:getEmails	()[Ljava/lang/String;
    //   41: invokevirtual 547	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:checkEmailLength	([Ljava/lang/String;)Z
    //   44: ifne +20 -> 64
    //   47: sipush -1012
    //   50: istore 5
    //   52: aload_3
    //   53: monitorexit
    //   54: goto +114 -> 168
    //   57: astore 4
    //   59: aload_3
    //   60: monitorexit
    //   61: aload 4
    //   63: athrow
    //   64: aload_0
    //   65: aload_2
    //   66: iload_1
    //   67: invokevirtual 551	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:updateEmailAndWait	(Lcom/android/internal/telephony/uicc/MiuiAdnRecord;I)I
    //   70: istore 7
    //   72: iload 7
    //   74: ifeq +12 -> 86
    //   77: aload_3
    //   78: monitorexit
    //   79: iload 7
    //   81: istore 5
    //   83: goto +85 -> 168
    //   86: aload_0
    //   87: getfield 97	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mSupportAnr	Z
    //   90: ifeq +68 -> 158
    //   93: aload_0
    //   94: iload_1
    //   95: aload_2
    //   96: invokevirtual 554	com/android/internal/telephony/uicc/MiuiAdnRecord:getAnr	()Ljava/lang/String;
    //   99: invokevirtual 556	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:checkAnrCapacityFree	(ILjava/lang/String;)Z
    //   102: ifne +13 -> 115
    //   105: sipush -1008
    //   108: istore 5
    //   110: aload_3
    //   111: monitorexit
    //   112: goto +56 -> 168
    //   115: aload_0
    //   116: aload_2
    //   117: invokevirtual 554	com/android/internal/telephony/uicc/MiuiAdnRecord:getAnr	()Ljava/lang/String;
    //   120: invokevirtual 558	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:checkAnrLength	(Ljava/lang/String;)Z
    //   123: ifne +13 -> 136
    //   126: sipush -1009
    //   129: istore 5
    //   131: aload_3
    //   132: monitorexit
    //   133: goto +35 -> 168
    //   136: aload_0
    //   137: aload_2
    //   138: iload_1
    //   139: invokevirtual 561	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:updateAnrAndWait	(Lcom/android/internal/telephony/uicc/MiuiAdnRecord;I)I
    //   142: istore 6
    //   144: iload 6
    //   146: ifeq +12 -> 158
    //   149: aload_3
    //   150: monitorexit
    //   151: iload 6
    //   153: istore 5
    //   155: goto +13 -> 168
    //   158: aload_0
    //   159: aload_2
    //   160: iload_1
    //   161: invokevirtual 564	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:updateAdnAndWait	(Lcom/android/internal/telephony/uicc/MiuiAdnRecord;I)I
    //   164: istore 5
    //   166: aload_3
    //   167: monitorexit
    //   168: iload 5
    //   170: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   7	61	57	finally
    //   64	168	57	finally
  }

  public int update(MiuiAdnRecord paramMiuiAdnRecord1, int paramInt, MiuiAdnRecord paramMiuiAdnRecord2)
  {
    while (true)
    {
      int i;
      int j;
      int[] arrayOfInt;
      synchronized (this.mLock)
      {
        i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
        j = (paramInt - 1) / i;
        arrayOfInt = new int[this.mPbrFile.mFileIds.size()];
        Arrays.fill(arrayOfInt, 0);
        int k = arrayOfInt.length;
        if (this.mSupportEmail)
        {
          EfRecord localEfRecord2 = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(j);
          int i6;
          int i1;
          EfRecord localEfRecord1;
          int i4;
          int i5;
          int n;
          int i2;
          int i3;
          int m;
          if ((hasEmail(paramMiuiAdnRecord2.getEmails())) && (!hasEmail(paramMiuiAdnRecord1.getEmails())) && (localEfRecord2.mType == 169))
          {
            i6 = 0;
            int i7 = this.mPbrFile.mFileIds.size();
            if (i6 < i7)
            {
              if (checkEmailCapacityFree(1 + i6 * i, paramMiuiAdnRecord2.getEmails()))
                continue;
              arrayOfInt[i6] = -1011;
              k--;
              continue;
            }
          }
        }
        if (k == 0)
        {
          i1 = arrayOfInt[j];
        }
        else
        {
          if (this.mSupportAnr)
          {
            localEfRecord1 = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(196))).get(j);
            if ((!TextUtils.isEmpty(paramMiuiAdnRecord2.getAnr())) && (TextUtils.isEmpty(paramMiuiAdnRecord1.getAnr())) && (localEfRecord1.mType == 169))
            {
              i4 = 0;
              i5 = this.mPbrFile.mFileIds.size();
              if (i4 < i5)
              {
                if (checkAnrCapacityFree(1 + i4 * i, paramMiuiAdnRecord2.getAnr()))
                  break label509;
                arrayOfInt[i4] = -1008;
                k--;
                break label509;
              }
            }
          }
          if (k == 0)
            i1 = arrayOfInt[j];
        }
      }
      label509: i4++;
      continue;
      m = -1;
      n = 0;
      continue;
      n++;
      continue;
      i2++;
    }
  }

  int updateAdnAndWait(MiuiAdnRecord paramMiuiAdnRecord, int paramInt)
  {
    int i = (paramInt - 1) / ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
    int j = (paramInt - 1) % ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(i));
    int k;
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(192))))
      k = -1014;
    while (true)
    {
      return k;
      int m;
      if (localMap.containsKey(Integer.valueOf(194)))
      {
        m = ((Integer)localMap.get(Integer.valueOf(194))).intValue();
        new MiuiAdnRecordLoader(this.mFh).updateEF(paramMiuiAdnRecord, ((Integer)localMap.get(Integer.valueOf(192))).intValue(), m, j + 1, null, obtainMessage(7));
      }
      try
      {
        this.mLock.wait();
        if (this.mUpdateResult.exception == null)
        {
          MiuiAdnRecord localMiuiAdnRecord = (MiuiAdnRecord)this.mPhoneBookRecords.get(paramInt - 1);
          localMiuiAdnRecord.setAlphaTag(paramMiuiAdnRecord.getAlphaTag());
          localMiuiAdnRecord.setNumber(paramMiuiAdnRecord.getNumber());
        }
        k = MiuiIccProviderException.getErrorCauseFromException(this.mUpdateResult.exception);
        continue;
        m = 0;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          Log.e("UsimPhoneBookManager", "Interrupted Exception in updateAdnAndWait");
      }
    }
  }

  int updateAnrAndWait(MiuiAdnRecord paramMiuiAdnRecord, int paramInt)
  {
    int i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
    int j = (paramInt - 1) / i;
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(j));
    int k;
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(196))))
      k = -1014;
    while (true)
    {
      return k;
      EfRecord localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(196))).get(j);
      if (localEfRecord.mType == 169)
        k = updateType2Ef(paramMiuiAdnRecord.getAnr(), paramInt, localEfRecord);
      else if (localEfRecord.mType == 168)
        k = updateType1Ef(paramMiuiAdnRecord.getAnr(), paramInt, localEfRecord);
      else
        k = -1001;
    }
  }

  int updateEmailAndWait(MiuiAdnRecord paramMiuiAdnRecord, int paramInt)
  {
    String str1 = null;
    int i = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
    int j = (paramInt - 1) / i;
    Map localMap = (Map)this.mPbrFile.mFileIds.get(Integer.valueOf(j));
    int k;
    if ((localMap == null) || (!localMap.containsKey(Integer.valueOf(202))))
      k = -1014;
    while (true)
    {
      return k;
      EfRecord localEfRecord = (EfRecord)((ArrayList)this.mPbrFile.mEfRecords.get(Integer.valueOf(202))).get(j);
      if (localEfRecord.mType == 169)
      {
        if (paramMiuiAdnRecord.getEmails() == null);
        for (String str2 = null; ; str2 = paramMiuiAdnRecord.getEmails()[0])
        {
          k = updateType2Ef(str2, paramInt, localEfRecord);
          break;
        }
      }
      if (localEfRecord.mType == 168)
      {
        if (paramMiuiAdnRecord.getEmails() == null);
        while (true)
        {
          k = updateType1Ef(str1, paramInt, localEfRecord);
          break;
          str1 = paramMiuiAdnRecord.getEmails()[0];
        }
      }
      k = -1001;
    }
  }

  int updateType1Ef(String paramString, int paramInt, EfRecord paramEfRecord)
  {
    int i = -1014;
    if (paramEfRecord.mType != 168);
    while (true)
    {
      return i;
      switch (paramEfRecord.mTag)
      {
      default:
        break;
      case 196:
      case 202:
        byte[] arrayOfByte = null;
        switch (paramEfRecord.mTag)
        {
        default:
          label84: int j = ((RecordSize)this.mRecordSize.get(Integer.valueOf(192))).mRecordCount;
          int k = (paramInt - 1) % j;
          this.mFh.updateEFLinearFixed(paramEfRecord.mEfTag, k + 1, arrayOfByte, null, obtainMessage(7));
        case 196:
        case 202:
        }
        try
        {
          this.mLock.wait();
          if (this.mUpdateResult.exception == null)
            localMiuiAdnRecord = (MiuiAdnRecord)this.mPhoneBookRecords.get(paramInt - 1);
          switch (paramEfRecord.mTag)
          {
          default:
            i = MiuiIccProviderException.getErrorCauseFromException(this.mUpdateResult.exception);
            continue;
            if (!TextUtils.isEmpty(paramString))
            {
              arrayOfByte = buildAnrRecord(paramString, ((RecordSize)this.mRecordSize.get(Integer.valueOf(196))).mRecordSize);
              if (arrayOfByte != null)
                break label84;
              i = -1009;
              continue;
            }
            arrayOfByte = new byte[((RecordSize)this.mRecordSize.get(Integer.valueOf(196))).mRecordSize];
            Arrays.fill(arrayOfByte, (byte)-1);
            break label84;
            if (!TextUtils.isEmpty(paramString))
            {
              arrayOfByte = buildEmailRecord(paramString, paramInt, ((RecordSize)this.mRecordSize.get(Integer.valueOf(202))).mRecordSize);
              if (arrayOfByte != null)
                break label84;
              i = -1012;
              continue;
            }
            arrayOfByte = new byte[((RecordSize)this.mRecordSize.get(Integer.valueOf(202))).mRecordSize];
            Arrays.fill(arrayOfByte, (byte)-1);
          case 196:
          case 202:
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
          {
            MiuiAdnRecord localMiuiAdnRecord;
            Log.e("UsimPhoneBookManager", "Interrupted Exception in updateType1Ef");
            continue;
            if (TextUtils.isEmpty(paramString))
            {
              localMiuiAdnRecord.setAnr("");
            }
            else
            {
              localMiuiAdnRecord.setAnr(paramString);
              continue;
              if (TextUtils.isEmpty(paramString))
                localMiuiAdnRecord.setEmails(null);
              else
                localMiuiAdnRecord.setEmails(new String[] { paramString });
            }
          }
        }
      }
    }
  }

  // ERROR //
  int updateType2Ef(String paramString, int paramInt, EfRecord paramEfRecord)
  {
    // Byte code:
    //   0: aload_3
    //   1: getfield 243	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mType	I
    //   4: sipush 169
    //   7: if_icmpeq +11 -> 18
    //   10: sipush -1014
    //   13: istore 5
    //   15: iload 5
    //   17: ireturn
    //   18: aload_0
    //   19: getfield 131	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mPbrFile	Lcom/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$PbrFile;
    //   22: getfield 332	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$PbrFile:mFileIds	Ljava/util/HashMap;
    //   25: aload_3
    //   26: getfield 189	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mPbrIndex	I
    //   29: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   32: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast 334	java/util/Map
    //   38: astore 4
    //   40: aload 4
    //   42: ifnull +19 -> 61
    //   45: aload 4
    //   47: sipush 193
    //   50: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   53: invokeinterface 360 2 0
    //   58: ifne +11 -> 69
    //   61: sipush -1014
    //   64: istore 5
    //   66: goto -51 -> 15
    //   69: aload_3
    //   70: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   73: lookupswitch	default:+27->100, 196:+35->108, 202:+35->108
    //   101: <illegal opcode>
    //   102: lconst_1
    //   103: istore 5
    //   105: goto -90 -> 15
    //   108: aload_0
    //   109: aload_3
    //   110: getfield 189	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mPbrIndex	I
    //   113: invokevirtual 505	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:readIapFileAndWait	(I)V
    //   116: aload_0
    //   117: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   120: sipush 192
    //   123: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   126: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   129: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   132: getfield 253	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordCount	I
    //   135: istore 6
    //   137: iload_2
    //   138: iconst_1
    //   139: isub
    //   140: iload 6
    //   142: irem
    //   143: istore 7
    //   145: aload_0
    //   146: getfield 186	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mIapFiles	[[[B
    //   149: aload_3
    //   150: getfield 189	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mPbrIndex	I
    //   153: aaload
    //   154: iload 7
    //   156: aaload
    //   157: astore 8
    //   159: aload_0
    //   160: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   163: aload_3
    //   164: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   167: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   170: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   173: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   176: getfield 253	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordCount	I
    //   179: istore 9
    //   181: aload 8
    //   183: aload_3
    //   184: getfield 192	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mType2Record	I
    //   187: baload
    //   188: istore 10
    //   190: sipush 255
    //   193: istore 11
    //   195: aload_1
    //   196: invokestatic 219	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   199: ifne +355 -> 554
    //   202: iload 10
    //   204: ifle +235 -> 439
    //   207: iload 10
    //   209: iload 9
    //   211: if_icmpgt +228 -> 439
    //   214: iload 10
    //   216: istore 11
    //   218: aconst_null
    //   219: astore 21
    //   221: aload_3
    //   222: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   225: lookupswitch	default:+27->252, 196:+236->461, 202:+275->500
    //   253: getfield 122	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mFh	Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;
    //   256: aload 4
    //   258: aload_3
    //   259: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   262: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   265: invokeinterface 335 2 0
    //   270: checkcast 159	java/lang/Integer
    //   273: invokevirtual 338	java/lang/Integer:intValue	()I
    //   276: iload 11
    //   278: aload 21
    //   280: aconst_null
    //   281: aload_0
    //   282: bipush 7
    //   284: invokevirtual 386	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:obtainMessage	(I)Landroid/os/Message;
    //   287: invokevirtual 615	com/android/internal/telephony/uicc/MiuiIccFileHandler:updateEFLinearFixed	(II[BLjava/lang/String;Landroid/os/Message;)V
    //   290: aload_0
    //   291: getfield 102	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mLock	Ljava/lang/Object;
    //   294: invokevirtual 395	java/lang/Object:wait	()V
    //   297: aload_0
    //   298: getfield 322	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mUpdateResult	Landroid/os/AsyncResult;
    //   301: getfield 404	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   304: ifnonnull +120 -> 424
    //   307: iload 11
    //   309: iload 10
    //   311: if_icmpeq +59 -> 370
    //   314: aload 8
    //   316: aload_3
    //   317: getfield 192	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mType2Record	I
    //   320: iload 11
    //   322: i2b
    //   323: bastore
    //   324: aload_0
    //   325: getfield 122	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mFh	Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;
    //   328: aload 4
    //   330: sipush 193
    //   333: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   336: invokeinterface 335 2 0
    //   341: checkcast 159	java/lang/Integer
    //   344: invokevirtual 338	java/lang/Integer:intValue	()I
    //   347: iload 7
    //   349: iconst_1
    //   350: iadd
    //   351: aload 8
    //   353: aconst_null
    //   354: aload_0
    //   355: bipush 7
    //   357: invokevirtual 386	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:obtainMessage	(I)Landroid/os/Message;
    //   360: invokevirtual 615	com/android/internal/telephony/uicc/MiuiIccFileHandler:updateEFLinearFixed	(II[BLjava/lang/String;Landroid/os/Message;)V
    //   363: aload_0
    //   364: getfield 102	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mLock	Ljava/lang/Object;
    //   367: invokevirtual 395	java/lang/Object:wait	()V
    //   370: aload_0
    //   371: getfield 322	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mUpdateResult	Landroid/os/AsyncResult;
    //   374: getfield 404	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   377: ifnonnull +47 -> 424
    //   380: aload_0
    //   381: getfield 127	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mPhoneBookRecords	Ljava/util/ArrayList;
    //   384: iload_2
    //   385: iconst_1
    //   386: isub
    //   387: invokevirtual 240	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   390: checkcast 456	com/android/internal/telephony/uicc/MiuiAdnRecord
    //   393: astore 18
    //   395: aload_3
    //   396: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   399: lookupswitch	default:+25->424, 196:+354->753, 202:+381->780
    //   425: getfield 322	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mUpdateResult	Landroid/os/AsyncResult;
    //   428: getfield 404	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   431: invokestatic 602	com/android/internal/telephony/MiuiIccProviderException:getErrorCauseFromException	(Ljava/lang/Throwable;)I
    //   434: istore 5
    //   436: goto -421 -> 15
    //   439: aload_0
    //   440: aload_3
    //   441: iload 9
    //   443: invokespecial 261	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:getRecordNumber	(Lcom/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord;I)I
    //   446: istore 11
    //   448: iload 11
    //   450: ifge -232 -> 218
    //   453: sipush -1005
    //   456: istore 5
    //   458: goto -443 -> 15
    //   461: aload_0
    //   462: aload_1
    //   463: aload_0
    //   464: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   467: sipush 196
    //   470: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   473: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   476: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   479: getfield 272	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordSize	I
    //   482: invokevirtual 617	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:buildAnrRecord	(Ljava/lang/String;I)[B
    //   485: astore 21
    //   487: aload 21
    //   489: ifnonnull -237 -> 252
    //   492: sipush -1009
    //   495: istore 5
    //   497: goto -482 -> 15
    //   500: aload_0
    //   501: aload_1
    //   502: iload_2
    //   503: aload_0
    //   504: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   507: sipush 202
    //   510: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   513: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   516: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   519: getfield 272	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordSize	I
    //   522: invokevirtual 619	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:buildEmailRecord	(Ljava/lang/String;II)[B
    //   525: astore 21
    //   527: aload 21
    //   529: ifnonnull -277 -> 252
    //   532: sipush -1012
    //   535: istore 5
    //   537: goto -522 -> 15
    //   540: astore 22
    //   542: ldc 27
    //   544: ldc_w 623
    //   547: invokestatic 400	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   550: pop
    //   551: goto -254 -> 297
    //   554: iload 10
    //   556: ifle +177 -> 733
    //   559: iload 10
    //   561: iload 9
    //   563: if_icmpgt +170 -> 733
    //   566: aconst_null
    //   567: astore 12
    //   569: aload_3
    //   570: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   573: lookupswitch	default:+27->600, 196:+101->674, 202:+130->703
    //   601: getfield 122	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mFh	Lcom/android/internal/telephony/uicc/MiuiIccFileHandler;
    //   604: astore 13
    //   606: aload 4
    //   608: aload_3
    //   609: getfield 157	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$EfRecord:mTag	I
    //   612: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   615: invokeinterface 335 2 0
    //   620: checkcast 159	java/lang/Integer
    //   623: invokevirtual 338	java/lang/Integer:intValue	()I
    //   626: istore 14
    //   628: aload_0
    //   629: bipush 7
    //   631: invokevirtual 386	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:obtainMessage	(I)Landroid/os/Message;
    //   634: astore 15
    //   636: aload 13
    //   638: iload 14
    //   640: iload 10
    //   642: aload 12
    //   644: aconst_null
    //   645: aload 15
    //   647: invokevirtual 615	com/android/internal/telephony/uicc/MiuiIccFileHandler:updateEFLinearFixed	(II[BLjava/lang/String;Landroid/os/Message;)V
    //   650: aload_0
    //   651: getfield 102	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mLock	Ljava/lang/Object;
    //   654: invokevirtual 395	java/lang/Object:wait	()V
    //   657: goto -360 -> 297
    //   660: astore 16
    //   662: ldc 27
    //   664: ldc_w 623
    //   667: invokestatic 400	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   670: pop
    //   671: goto -374 -> 297
    //   674: aload_0
    //   675: aconst_null
    //   676: aload_0
    //   677: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   680: sipush 196
    //   683: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   686: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   689: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   692: getfield 272	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordSize	I
    //   695: invokevirtual 617	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:buildAnrRecord	(Ljava/lang/String;I)[B
    //   698: astore 12
    //   700: goto -100 -> 600
    //   703: aload_0
    //   704: aconst_null
    //   705: iload_2
    //   706: aload_0
    //   707: getfield 138	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:mRecordSize	Ljava/util/HashMap;
    //   710: sipush 202
    //   713: invokestatic 163	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   716: invokevirtual 167	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   719: checkcast 250	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize
    //   722: getfield 272	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager$RecordSize:mRecordSize	I
    //   725: invokevirtual 619	com/android/internal/telephony/gsm/MiuiUsimPhoneBookManager:buildEmailRecord	(Ljava/lang/String;II)[B
    //   728: astore 12
    //   730: goto -130 -> 600
    //   733: iconst_0
    //   734: istore 5
    //   736: goto -721 -> 15
    //   739: astore 19
    //   741: ldc 27
    //   743: ldc_w 623
    //   746: invokestatic 400	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   749: pop
    //   750: goto -380 -> 370
    //   753: aload_1
    //   754: invokestatic 219	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   757: ifeq +14 -> 771
    //   760: aload 18
    //   762: ldc_w 572
    //   765: invokevirtual 528	com/android/internal/telephony/uicc/MiuiAdnRecord:setAnr	(Ljava/lang/String;)V
    //   768: goto -344 -> 424
    //   771: aload 18
    //   773: aload_1
    //   774: invokevirtual 528	com/android/internal/telephony/uicc/MiuiAdnRecord:setAnr	(Ljava/lang/String;)V
    //   777: goto -353 -> 424
    //   780: aload_1
    //   781: invokestatic 219	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   784: ifeq +12 -> 796
    //   787: aload 18
    //   789: aconst_null
    //   790: invokevirtual 537	com/android/internal/telephony/uicc/MiuiAdnRecord:setEmails	([Ljava/lang/String;)V
    //   793: goto -369 -> 424
    //   796: aload 18
    //   798: iconst_1
    //   799: anewarray 221	java/lang/String
    //   802: dup
    //   803: iconst_0
    //   804: aload_1
    //   805: aastore
    //   806: invokevirtual 537	com/android/internal/telephony/uicc/MiuiAdnRecord:setEmails	([Ljava/lang/String;)V
    //   809: goto -385 -> 424
    //
    // Exception table:
    //   from	to	target	type
    //   290	297	540	java/lang/InterruptedException
    //   650	657	660	java/lang/InterruptedException
    //   363	370	739	java/lang/InterruptedException
  }

  class EfRecord
  {
    public int mEfTag;
    public int mPbrIndex;
    public byte mSfi = -1;
    public int mTag;
    public int mType;
    public int mType2Record = -1;

    EfRecord()
    {
    }

    public String toString()
    {
      return "mTAG:" + this.mTag + "mPbrRecord:" + this.mPbrIndex + ",mEfTag:" + this.mEfTag + ",mType:" + this.mType + ",mType2Record:" + this.mType2Record + ",mSFI:" + this.mSfi;
    }
  }

  class PbrFile
  {
    HashMap<Integer, ArrayList<MiuiUsimPhoneBookManager.EfRecord>> mEfRecords = new HashMap();
    HashMap<Integer, Map<Integer, Integer>> mFileIds = new HashMap();

    PbrFile()
    {
      int i = 0;
      Object localObject;
      Iterator localIterator = localObject.iterator();
      while (localIterator.hasNext())
      {
        byte[] arrayOfByte = (byte[])localIterator.next();
        parseTag(new SimTlv(arrayOfByte, 0, arrayOfByte.length), i);
        i++;
      }
    }

    void parseEf(SimTlv paramSimTlv, Map<Integer, Integer> paramMap, int paramInt1, int paramInt2)
    {
      int i = 0;
      int j = paramSimTlv.getTag();
      switch (j)
      {
      case 195:
      case 197:
      case 198:
      case 199:
      case 200:
      case 201:
      default:
      case 192:
      case 193:
      case 194:
      case 196:
      case 202:
      }
      while (true)
      {
        i++;
        if (paramSimTlv.nextObject())
          break;
        return;
        byte[] arrayOfByte = paramSimTlv.getData();
        int k = arrayOfByte[0] << 8 | arrayOfByte[1];
        paramMap.put(Integer.valueOf(j), Integer.valueOf(k));
        MiuiUsimPhoneBookManager.EfRecord localEfRecord = new MiuiUsimPhoneBookManager.EfRecord(MiuiUsimPhoneBookManager.this);
        localEfRecord.mTag = j;
        localEfRecord.mPbrIndex = paramInt2;
        localEfRecord.mEfTag = k;
        localEfRecord.mType = paramInt1;
        if (paramInt1 == 169)
          localEfRecord.mType2Record = i;
        if (arrayOfByte.length == 3)
          localEfRecord.mSfi = arrayOfByte[2];
        if (!this.mEfRecords.containsKey(Integer.valueOf(j)))
          this.mEfRecords.put(Integer.valueOf(j), new ArrayList());
        ((ArrayList)this.mEfRecords.get(Integer.valueOf(j))).add(localEfRecord);
      }
    }

    void parseTag(SimTlv paramSimTlv, int paramInt)
    {
      HashMap localHashMap = new HashMap();
      while (true)
      {
        int i = paramSimTlv.getTag();
        switch (i)
        {
        default:
        case 168:
        case 169:
        case 170:
        }
        while (!paramSimTlv.nextObject())
        {
          this.mFileIds.put(Integer.valueOf(paramInt), localHashMap);
          return;
          byte[] arrayOfByte = paramSimTlv.getData();
          parseEf(new SimTlv(arrayOfByte, 0, arrayOfByte.length), localHashMap, i, paramInt);
        }
      }
    }
  }

  class RecordSize
  {
    int mRecordCount;
    int mRecordSize;
    int mTotalSize;

    public RecordSize(int[] arg2)
    {
      Object localObject;
      this.mRecordSize = localObject[0];
      this.mTotalSize = localObject[1];
      this.mRecordCount = localObject[2];
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.MiuiUsimPhoneBookManager
 * JD-Core Version:    0.6.2
 */