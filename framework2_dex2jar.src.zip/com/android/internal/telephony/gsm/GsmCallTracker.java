package com.android.internal.telephony.gsm;

import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.os.Registrant;
import android.os.RegistrantList;
import android.os.SystemProperties;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.EventLog;
import com.android.internal.telephony.Call;
import com.android.internal.telephony.Call.State;
import com.android.internal.telephony.CallStateException;
import com.android.internal.telephony.CallTracker;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.Connection;
import com.android.internal.telephony.Connection.DisconnectCause;
import com.android.internal.telephony.Phone.SuppService;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.PhoneConstants.State;
import com.android.internal.telephony.UUSInfo;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public final class GsmCallTracker extends CallTracker
{
  private static final boolean DBG_POLL = false;
  static final String LOG_TAG = "GsmCallTracker";
  static final int MAX_CONNECTIONS = 7;
  static final int MAX_CONNECTIONS_PER_CALL = 5;
  private static final boolean REPEAT_POLLING;
  GsmCall mBackgroundCall = new GsmCall(this);
  GsmConnection[] mConnections = new GsmConnection[7];
  boolean mDesiredMute = false;
  ArrayList<GsmConnection> mDroppedDuringPoll = new ArrayList(7);
  GsmCall mForegroundCall = new GsmCall(this);
  boolean mHangupPendingMO;
  GsmConnection mPendingMO;
  GSMPhone mPhone;
  GsmCall mRingingCall = new GsmCall(this);
  PhoneConstants.State mState = PhoneConstants.State.IDLE;
  RegistrantList mVoiceCallEndedRegistrants = new RegistrantList();
  RegistrantList mVoiceCallStartedRegistrants = new RegistrantList();

  GsmCallTracker(GSMPhone paramGSMPhone)
  {
    this.mPhone = paramGSMPhone;
    this.mCi = paramGSMPhone.mCi;
    this.mCi.registerForCallStateChanged(this, 2, null);
    this.mCi.registerForOn(this, 9, null);
    this.mCi.registerForNotAvailable(this, 10, null);
  }

  private void dumpState()
  {
    Rlog.i("GsmCallTracker", "Phone State:" + this.mState);
    Rlog.i("GsmCallTracker", "Ringing call: " + this.mRingingCall.toString());
    List localList1 = this.mRingingCall.getConnections();
    int i = 0;
    int j = localList1.size();
    while (i < j)
    {
      Rlog.i("GsmCallTracker", localList1.get(i).toString());
      i++;
    }
    Rlog.i("GsmCallTracker", "Foreground call: " + this.mForegroundCall.toString());
    List localList2 = this.mForegroundCall.getConnections();
    int k = 0;
    int m = localList2.size();
    while (k < m)
    {
      Rlog.i("GsmCallTracker", localList2.get(k).toString());
      k++;
    }
    Rlog.i("GsmCallTracker", "Background call: " + this.mBackgroundCall.toString());
    List localList3 = this.mBackgroundCall.getConnections();
    int n = 0;
    int i1 = localList3.size();
    while (n < i1)
    {
      Rlog.i("GsmCallTracker", localList3.get(n).toString());
      n++;
    }
  }

  private void fakeHoldForegroundBeforeDial()
  {
    List localList = (List)this.mForegroundCall.mConnections.clone();
    int i = 0;
    int j = localList.size();
    while (i < j)
    {
      ((GsmConnection)localList.get(i)).fakeHoldBeforeDial();
      i++;
    }
  }

  private Phone.SuppService getFailedService(int paramInt)
  {
    Phone.SuppService localSuppService;
    switch (paramInt)
    {
    case 9:
    case 10:
    default:
      localSuppService = Phone.SuppService.UNKNOWN;
    case 8:
    case 11:
    case 12:
    case 13:
    }
    while (true)
    {
      return localSuppService;
      localSuppService = Phone.SuppService.SWITCH;
      continue;
      localSuppService = Phone.SuppService.CONFERENCE;
      continue;
      localSuppService = Phone.SuppService.SEPARATE;
      continue;
      localSuppService = Phone.SuppService.TRANSFER;
    }
  }

  private void handleRadioNotAvailable()
  {
    pollCallsWhenSafe();
  }

  private void internalClearDisconnected()
  {
    this.mRingingCall.clearDisconnected();
    this.mForegroundCall.clearDisconnected();
    this.mBackgroundCall.clearDisconnected();
  }

  private Message obtainCompleteMessage()
  {
    return obtainCompleteMessage(4);
  }

  private Message obtainCompleteMessage(int paramInt)
  {
    this.mPendingOperations = (1 + this.mPendingOperations);
    this.mLastRelevantPoll = null;
    this.mNeedsPoll = true;
    return obtainMessage(paramInt);
  }

  private void operationComplete()
  {
    this.mPendingOperations = (-1 + this.mPendingOperations);
    if ((this.mPendingOperations == 0) && (this.mNeedsPoll))
    {
      this.mLastRelevantPoll = obtainMessage(1);
      this.mCi.getCurrentCalls(this.mLastRelevantPoll);
    }
    while (true)
    {
      return;
      if (this.mPendingOperations < 0)
      {
        Rlog.e("GsmCallTracker", "GsmCallTracker.pendingOperations < 0");
        this.mPendingOperations = 0;
      }
    }
  }

  private void updatePhoneState()
  {
    PhoneConstants.State localState = this.mState;
    if (this.mRingingCall.isRinging())
    {
      this.mState = PhoneConstants.State.RINGING;
      if ((this.mState != PhoneConstants.State.IDLE) || (localState == this.mState))
        break label120;
      this.mVoiceCallEndedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
    }
    while (true)
    {
      if (this.mState != localState)
        this.mPhone.notifyPhoneStateChanged();
      return;
      if ((this.mPendingMO != null) || (!this.mForegroundCall.isIdle()) || (!this.mBackgroundCall.isIdle()))
      {
        this.mState = PhoneConstants.State.OFFHOOK;
        break;
      }
      this.mState = PhoneConstants.State.IDLE;
      break;
      label120: if ((localState == PhoneConstants.State.IDLE) && (localState != this.mState))
        this.mVoiceCallStartedRegistrants.notifyRegistrants(new AsyncResult(null, null, null));
    }
  }

  void acceptCall()
    throws CallStateException
  {
    if (this.mRingingCall.getState() == Call.State.INCOMING)
    {
      Rlog.i("phone", "acceptCall: incoming...");
      setMute(false);
      this.mCi.acceptCall(obtainCompleteMessage());
    }
    while (true)
    {
      return;
      if (this.mRingingCall.getState() != Call.State.WAITING)
        break;
      setMute(false);
      switchWaitingOrHoldingAndActive();
    }
    throw new CallStateException("phone not ringing");
  }

  boolean canConference()
  {
    if ((this.mForegroundCall.getState() == Call.State.ACTIVE) && (this.mBackgroundCall.getState() == Call.State.HOLDING) && (!this.mBackgroundCall.isFull()) && (!this.mForegroundCall.isFull()));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean canDial()
  {
    int i = this.mPhone.getServiceState().getState();
    String str = SystemProperties.get("ro.telephony.disable-call", "false");
    if ((i != 3) && (this.mPendingMO == null) && (!this.mRingingCall.isRinging()) && (!str.equals("true")) && ((!this.mForegroundCall.getState().isAlive()) || (!this.mBackgroundCall.getState().isAlive())));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean canTransfer()
  {
    if (((this.mForegroundCall.getState() == Call.State.ACTIVE) || (this.mForegroundCall.getState() == Call.State.ALERTING) || (this.mForegroundCall.getState() == Call.State.DIALING)) && (this.mBackgroundCall.getState() == Call.State.HOLDING));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  void clearDisconnected()
  {
    internalClearDisconnected();
    updatePhoneState();
    this.mPhone.notifyPreciseCallStateChanged();
  }

  void conference()
  {
    this.mCi.conference(obtainCompleteMessage(11));
  }

  Connection dial(String paramString)
    throws CallStateException
  {
    return dial(paramString, 0, null);
  }

  Connection dial(String paramString, int paramInt)
    throws CallStateException
  {
    return dial(paramString, paramInt, null);
  }

  Connection dial(String paramString, int paramInt, UUSInfo paramUUSInfo)
    throws CallStateException
  {
    try
    {
      clearDisconnected();
      if (!canDial())
        throw new CallStateException("cannot dial in current state");
    }
    finally
    {
    }
    if (this.mForegroundCall.getState() == Call.State.ACTIVE)
    {
      switchWaitingOrHoldingAndActive();
      fakeHoldForegroundBeforeDial();
    }
    if (this.mForegroundCall.getState() != Call.State.IDLE)
      throw new CallStateException("cannot dial in current state");
    this.mPendingMO = new GsmConnection(this.mPhone.getContext(), checkForTestEmergencyNumber(paramString), this, this.mForegroundCall);
    this.mHangupPendingMO = false;
    if ((this.mPendingMO.mAddress == null) || (this.mPendingMO.mAddress.length() == 0) || (this.mPendingMO.mAddress.indexOf('N') >= 0))
    {
      this.mPendingMO.mCause = Connection.DisconnectCause.INVALID_NUMBER;
      pollCallsWhenSafe();
    }
    while (true)
    {
      updatePhoneState();
      this.mPhone.notifyPreciseCallStateChanged();
      GsmConnection localGsmConnection = this.mPendingMO;
      return localGsmConnection;
      setMute(false);
      this.mCi.dial(this.mPendingMO.mAddress, paramInt, paramUUSInfo, obtainCompleteMessage());
    }
  }

  Connection dial(String paramString, UUSInfo paramUUSInfo)
    throws CallStateException
  {
    return dial(paramString, 0, paramUUSInfo);
  }

  public void dispose()
  {
    this.mCi.unregisterForCallStateChanged(this);
    this.mCi.unregisterForOn(this);
    this.mCi.unregisterForNotAvailable(this);
    GsmConnection[] arrayOfGsmConnection = this.mConnections;
    int i = arrayOfGsmConnection.length;
    int j = 0;
    while (true)
      if (j < i)
      {
        GsmConnection localGsmConnection = arrayOfGsmConnection[j];
        if (localGsmConnection != null);
        try
        {
          hangup(localGsmConnection);
          Rlog.d("GsmCallTracker", "dispose: call connnection onDisconnect, cause LOST_SIGNAL");
          localGsmConnection.onDisconnect(Connection.DisconnectCause.LOST_SIGNAL);
          j++;
        }
        catch (CallStateException localCallStateException2)
        {
          while (true)
            Rlog.e("GsmCallTracker", "dispose: unexpected error on hangup", localCallStateException2);
        }
      }
    try
    {
      if (this.mPendingMO != null)
      {
        hangup(this.mPendingMO);
        Rlog.d("GsmCallTracker", "dispose: call mPendingMO.onDsiconnect, cause LOST_SIGNAL");
        this.mPendingMO.onDisconnect(Connection.DisconnectCause.LOST_SIGNAL);
      }
      clearDisconnected();
      return;
    }
    catch (CallStateException localCallStateException1)
    {
      while (true)
        Rlog.e("GsmCallTracker", "dispose: unexpected error on hangup", localCallStateException1);
    }
  }

  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.println("GsmCallTracker extends:");
    super.dump(paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.println("mConnections: length=" + this.mConnections.length);
    for (int i = 0; i < this.mConnections.length; i++)
    {
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(i);
      arrayOfObject2[1] = this.mConnections[i];
      paramPrintWriter.printf("  mConnections[%d]=%s\n", arrayOfObject2);
    }
    paramPrintWriter.println(" mVoiceCallEndedRegistrants=" + this.mVoiceCallEndedRegistrants);
    paramPrintWriter.println(" mVoiceCallStartedRegistrants=" + this.mVoiceCallStartedRegistrants);
    paramPrintWriter.println(" mDroppedDuringPoll: size=" + this.mDroppedDuringPoll.size());
    for (int j = 0; j < this.mDroppedDuringPoll.size(); j++)
    {
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = Integer.valueOf(j);
      arrayOfObject1[1] = this.mDroppedDuringPoll.get(j);
      paramPrintWriter.printf("  mDroppedDuringPoll[%d]=%s\n", arrayOfObject1);
    }
    paramPrintWriter.println(" mRingingCall=" + this.mRingingCall);
    paramPrintWriter.println(" mForegroundCall=" + this.mForegroundCall);
    paramPrintWriter.println(" mBackgroundCall=" + this.mBackgroundCall);
    paramPrintWriter.println(" mPendingMO=" + this.mPendingMO);
    paramPrintWriter.println(" mHangupPendingMO=" + this.mHangupPendingMO);
    paramPrintWriter.println(" mPhone=" + this.mPhone);
    paramPrintWriter.println(" mDesiredMute=" + this.mDesiredMute);
    paramPrintWriter.println(" mState=" + this.mState);
  }

  void explicitCallTransfer()
  {
    this.mCi.explicitCallTransfer(obtainCompleteMessage(13));
  }

  protected void finalize()
  {
    Rlog.d("GsmCallTracker", "GsmCallTracker finalized");
  }

  GsmConnection getConnectionByIndex(GsmCall paramGsmCall, int paramInt)
    throws CallStateException
  {
    int i = paramGsmCall.mConnections.size();
    int j = 0;
    GsmConnection localGsmConnection;
    if (j < i)
    {
      localGsmConnection = (GsmConnection)paramGsmCall.mConnections.get(j);
      if (localGsmConnection.getGSMIndex() != paramInt);
    }
    while (true)
    {
      return localGsmConnection;
      j++;
      break;
      localGsmConnection = null;
    }
  }

  boolean getMute()
  {
    return this.mDesiredMute;
  }

  public void handleMessage(Message paramMessage)
  {
    if (!this.mPhone.mIsTheCurrentActivePhone)
      Rlog.e("GsmCallTracker", "Received message " + paramMessage + "[" + paramMessage.what + "] while being destroyed. Ignoring.");
    while (true)
    {
      return;
      switch (paramMessage.what)
      {
      case 6:
      case 7:
      default:
        break;
      case 1:
        ((AsyncResult)paramMessage.obj);
        if (paramMessage == this.mLastRelevantPoll)
        {
          this.mNeedsPoll = false;
          this.mLastRelevantPoll = null;
          handlePollCalls((AsyncResult)paramMessage.obj);
        }
        break;
      case 4:
        ((AsyncResult)paramMessage.obj);
        operationComplete();
        break;
      case 8:
      case 11:
      case 12:
      case 13:
        if (((AsyncResult)paramMessage.obj).exception != null)
          this.mPhone.notifySuppServiceFailed(getFailedService(paramMessage.what));
        operationComplete();
        break;
      case 5:
        AsyncResult localAsyncResult = (AsyncResult)paramMessage.obj;
        operationComplete();
        int i;
        GsmCellLocation localGsmCellLocation;
        Object[] arrayOfObject;
        if (localAsyncResult.exception != null)
        {
          i = 16;
          Rlog.i("GsmCallTracker", "Exception during getLastCallFailCause, assuming normal disconnect");
          if ((i == 34) || (i == 41) || (i == 42) || (i == 44) || (i == 49) || (i == 58) || (i == 65535))
          {
            localGsmCellLocation = (GsmCellLocation)this.mPhone.getCellLocation();
            arrayOfObject = new Object[3];
            arrayOfObject[0] = Integer.valueOf(i);
            if (localGsmCellLocation == null)
              break label421;
          }
        }
        for (int j = localGsmCellLocation.getCid(); ; j = -1)
        {
          arrayOfObject[1] = Integer.valueOf(j);
          arrayOfObject[2] = Integer.valueOf(TelephonyManager.getDefault().getNetworkType());
          EventLog.writeEvent(50106, arrayOfObject);
          int k = 0;
          int m = this.mDroppedDuringPoll.size();
          while (k < m)
          {
            ((GsmConnection)this.mDroppedDuringPoll.get(k)).onRemoteDisconnect(i);
            k++;
          }
          i = ((int[])(int[])localAsyncResult.result)[0];
          break;
        }
        updatePhoneState();
        this.mPhone.notifyPreciseCallStateChanged();
        this.mDroppedDuringPoll.clear();
        break;
      case 2:
      case 3:
        pollCallsWhenSafe();
        break;
      case 9:
        handleRadioAvailable();
        break;
      case 10:
        label421: handleRadioNotAvailable();
      }
    }
  }

  // ERROR //
  protected void handlePollCalls(AsyncResult paramAsyncResult)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: getfield 520	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   6: ifnonnull +209 -> 215
    //   9: aload_1
    //   10: getfield 560	android/os/AsyncResult:result	Ljava/lang/Object;
    //   13: checkcast 133	java/util/List
    //   16: astore_3
    //   17: aconst_null
    //   18: astore 4
    //   20: iconst_0
    //   21: istore 5
    //   23: iconst_0
    //   24: istore 6
    //   26: iconst_0
    //   27: istore 7
    //   29: iconst_0
    //   30: istore 8
    //   32: iconst_0
    //   33: istore 9
    //   35: aload_3
    //   36: invokeinterface 137 1 0
    //   41: istore 10
    //   43: iload 8
    //   45: aload_0
    //   46: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   49: arraylength
    //   50: if_icmpge +521 -> 571
    //   53: aload_0
    //   54: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   57: iload 8
    //   59: aaload
    //   60: astore 18
    //   62: aconst_null
    //   63: astore 19
    //   65: iload 9
    //   67: iload 10
    //   69: if_icmpge +31 -> 100
    //   72: aload_3
    //   73: iload 9
    //   75: invokeinterface 141 2 0
    //   80: checkcast 572	com/android/internal/telephony/DriverCall
    //   83: astore 19
    //   85: aload 19
    //   87: getfield 575	com/android/internal/telephony/DriverCall:index	I
    //   90: iload 8
    //   92: iconst_1
    //   93: iadd
    //   94: if_icmpne +155 -> 249
    //   97: iinc 9 1
    //   100: aload 18
    //   102: ifnonnull +313 -> 415
    //   105: aload 19
    //   107: ifnull +308 -> 415
    //   110: aload_0
    //   111: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   114: ifnull +155 -> 269
    //   117: aload_0
    //   118: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   121: aload 19
    //   123: invokevirtual 579	com/android/internal/telephony/gsm/GsmConnection:compareTo	(Lcom/android/internal/telephony/DriverCall;)Z
    //   126: ifeq +143 -> 269
    //   129: aload_0
    //   130: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   133: iload 8
    //   135: aload_0
    //   136: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   139: aastore
    //   140: aload_0
    //   141: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   144: iload 8
    //   146: putfield 582	com/android/internal/telephony/gsm/GsmConnection:mIndex	I
    //   149: aload_0
    //   150: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   153: aload 19
    //   155: invokevirtual 585	com/android/internal/telephony/gsm/GsmConnection:update	(Lcom/android/internal/telephony/DriverCall;)Z
    //   158: pop
    //   159: aload_0
    //   160: aconst_null
    //   161: putfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   164: aload_0
    //   165: getfield 366	com/android/internal/telephony/gsm/GsmCallTracker:mHangupPendingMO	Z
    //   168: ifeq +746 -> 914
    //   171: aload_0
    //   172: iconst_0
    //   173: putfield 366	com/android/internal/telephony/gsm/GsmCallTracker:mHangupPendingMO	Z
    //   176: aload_0
    //   177: new 104	java/lang/StringBuilder
    //   180: dup
    //   181: invokespecial 105	java/lang/StringBuilder:<init>	()V
    //   184: ldc_w 587
    //   187: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: iload 8
    //   192: invokevirtual 439	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   195: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   198: invokevirtual 590	com/android/internal/telephony/gsm/GsmCallTracker:log	(Ljava/lang/String;)V
    //   201: aload_0
    //   202: aload_0
    //   203: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   206: iload 8
    //   208: aaload
    //   209: invokevirtual 404	com/android/internal/telephony/gsm/GsmCallTracker:hangup	(Lcom/android/internal/telephony/gsm/GsmConnection;)V
    //   212: aload_0
    //   213: monitorexit
    //   214: return
    //   215: aload_0
    //   216: aload_1
    //   217: getfield 520	android/os/AsyncResult:exception	Ljava/lang/Throwable;
    //   220: invokevirtual 594	com/android/internal/telephony/gsm/GsmCallTracker:isCommandExceptionRadioNotAvailable	(Ljava/lang/Throwable;)Z
    //   223: ifeq +14 -> 237
    //   226: new 55	java/util/ArrayList
    //   229: dup
    //   230: invokespecial 595	java/util/ArrayList:<init>	()V
    //   233: astore_3
    //   234: goto -217 -> 17
    //   237: aload_0
    //   238: invokevirtual 598	com/android/internal/telephony/gsm/GsmCallTracker:pollCallsAfterDelay	()V
    //   241: goto -29 -> 212
    //   244: astore_2
    //   245: aload_0
    //   246: monitorexit
    //   247: aload_2
    //   248: athrow
    //   249: aconst_null
    //   250: astore 19
    //   252: goto -152 -> 100
    //   255: astore 29
    //   257: ldc 11
    //   259: ldc_w 600
    //   262: invokestatic 216	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   265: pop
    //   266: goto -54 -> 212
    //   269: aload_0
    //   270: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   273: astore 25
    //   275: new 44	com/android/internal/telephony/gsm/GsmConnection
    //   278: dup
    //   279: aload_0
    //   280: getfield 82	com/android/internal/telephony/gsm/GsmCallTracker:mPhone	Lcom/android/internal/telephony/gsm/GSMPhone;
    //   283: invokevirtual 357	com/android/internal/telephony/gsm/GSMPhone:getContext	()Landroid/content/Context;
    //   286: aload 19
    //   288: aload_0
    //   289: iload 8
    //   291: invokespecial 603	com/android/internal/telephony/gsm/GsmConnection:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/DriverCall;Lcom/android/internal/telephony/gsm/GsmCallTracker;I)V
    //   294: astore 26
    //   296: aload 25
    //   298: iload 8
    //   300: aload 26
    //   302: aastore
    //   303: aload_0
    //   304: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   307: iload 8
    //   309: aaload
    //   310: invokevirtual 607	com/android/internal/telephony/gsm/GsmConnection:getCall	()Lcom/android/internal/telephony/gsm/GsmCall;
    //   313: aload_0
    //   314: getfield 67	com/android/internal/telephony/gsm/GsmCallTracker:mRingingCall	Lcom/android/internal/telephony/gsm/GsmCall;
    //   317: if_acmpne +15 -> 332
    //   320: aload_0
    //   321: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   324: iload 8
    //   326: aaload
    //   327: astore 4
    //   329: goto +585 -> 914
    //   332: ldc 11
    //   334: new 104	java/lang/StringBuilder
    //   337: dup
    //   338: invokespecial 105	java/lang/StringBuilder:<init>	()V
    //   341: ldc_w 609
    //   344: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   347: aload 19
    //   349: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   352: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   355: invokestatic 124	android/telephony/Rlog:i	(Ljava/lang/String;Ljava/lang/String;)I
    //   358: pop
    //   359: aload 19
    //   361: getfield 613	com/android/internal/telephony/DriverCall:state	Lcom/android/internal/telephony/DriverCall$State;
    //   364: getstatic 617	com/android/internal/telephony/DriverCall$State:ALERTING	Lcom/android/internal/telephony/DriverCall$State;
    //   367: if_acmpeq +556 -> 923
    //   370: aload 19
    //   372: getfield 613	com/android/internal/telephony/DriverCall:state	Lcom/android/internal/telephony/DriverCall$State;
    //   375: getstatic 619	com/android/internal/telephony/DriverCall$State:DIALING	Lcom/android/internal/telephony/DriverCall$State;
    //   378: if_acmpeq +545 -> 923
    //   381: aload_0
    //   382: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   385: iload 8
    //   387: aaload
    //   388: invokevirtual 622	com/android/internal/telephony/gsm/GsmConnection:onConnectedInOrOut	()V
    //   391: aload 19
    //   393: getfield 613	com/android/internal/telephony/DriverCall:state	Lcom/android/internal/telephony/DriverCall$State;
    //   396: getstatic 624	com/android/internal/telephony/DriverCall$State:HOLDING	Lcom/android/internal/telephony/DriverCall$State;
    //   399: if_acmpne +524 -> 923
    //   402: aload_0
    //   403: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   406: iload 8
    //   408: aaload
    //   409: invokevirtual 627	com/android/internal/telephony/gsm/GsmConnection:onStartedHolding	()V
    //   412: goto +511 -> 923
    //   415: aload 18
    //   417: ifnull +29 -> 446
    //   420: aload 19
    //   422: ifnonnull +24 -> 446
    //   425: aload_0
    //   426: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   429: aload 18
    //   431: invokevirtual 630	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   434: pop
    //   435: aload_0
    //   436: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   439: iload 8
    //   441: aconst_null
    //   442: aastore
    //   443: goto +474 -> 917
    //   446: aload 18
    //   448: ifnull +91 -> 539
    //   451: aload 19
    //   453: ifnull +86 -> 539
    //   456: aload 18
    //   458: aload 19
    //   460: invokevirtual 579	com/android/internal/telephony/gsm/GsmConnection:compareTo	(Lcom/android/internal/telephony/DriverCall;)Z
    //   463: ifne +76 -> 539
    //   466: aload_0
    //   467: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   470: aload 18
    //   472: invokevirtual 630	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   475: pop
    //   476: aload_0
    //   477: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   480: astore 22
    //   482: new 44	com/android/internal/telephony/gsm/GsmConnection
    //   485: dup
    //   486: aload_0
    //   487: getfield 82	com/android/internal/telephony/gsm/GsmCallTracker:mPhone	Lcom/android/internal/telephony/gsm/GSMPhone;
    //   490: invokevirtual 357	com/android/internal/telephony/gsm/GSMPhone:getContext	()Landroid/content/Context;
    //   493: aload 19
    //   495: aload_0
    //   496: iload 8
    //   498: invokespecial 603	com/android/internal/telephony/gsm/GsmConnection:<init>	(Landroid/content/Context;Lcom/android/internal/telephony/DriverCall;Lcom/android/internal/telephony/gsm/GsmCallTracker;I)V
    //   501: astore 23
    //   503: aload 22
    //   505: iload 8
    //   507: aload 23
    //   509: aastore
    //   510: aload_0
    //   511: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   514: iload 8
    //   516: aaload
    //   517: invokevirtual 607	com/android/internal/telephony/gsm/GsmConnection:getCall	()Lcom/android/internal/telephony/gsm/GsmCall;
    //   520: aload_0
    //   521: getfield 67	com/android/internal/telephony/gsm/GsmCallTracker:mRingingCall	Lcom/android/internal/telephony/gsm/GsmCall;
    //   524: if_acmpne +405 -> 929
    //   527: aload_0
    //   528: getfield 46	com/android/internal/telephony/gsm/GsmCallTracker:mConnections	[Lcom/android/internal/telephony/gsm/GsmConnection;
    //   531: iload 8
    //   533: aaload
    //   534: astore 4
    //   536: goto +393 -> 929
    //   539: aload 18
    //   541: ifnull +376 -> 917
    //   544: aload 19
    //   546: ifnull +371 -> 917
    //   549: aload 18
    //   551: aload 19
    //   553: invokevirtual 585	com/android/internal/telephony/gsm/GsmConnection:update	(Lcom/android/internal/telephony/DriverCall;)Z
    //   556: istore 20
    //   558: iload 5
    //   560: ifne +375 -> 935
    //   563: iload 20
    //   565: ifeq +376 -> 941
    //   568: goto +367 -> 935
    //   571: aload_0
    //   572: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   575: ifnull +57 -> 632
    //   578: ldc 11
    //   580: new 104	java/lang/StringBuilder
    //   583: dup
    //   584: invokespecial 105	java/lang/StringBuilder:<init>	()V
    //   587: ldc_w 632
    //   590: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   593: aload_0
    //   594: getfield 69	com/android/internal/telephony/gsm/GsmCallTracker:mForegroundCall	Lcom/android/internal/telephony/gsm/GsmCall;
    //   597: invokevirtual 253	com/android/internal/telephony/gsm/GsmCall:getState	()Lcom/android/internal/telephony/Call$State;
    //   600: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   603: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   606: invokestatic 409	android/telephony/Rlog:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   609: pop
    //   610: aload_0
    //   611: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   614: aload_0
    //   615: getfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   618: invokevirtual 630	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   621: pop
    //   622: aload_0
    //   623: aconst_null
    //   624: putfield 240	com/android/internal/telephony/gsm/GsmCallTracker:mPendingMO	Lcom/android/internal/telephony/gsm/GsmConnection;
    //   627: aload_0
    //   628: iconst_0
    //   629: putfield 366	com/android/internal/telephony/gsm/GsmCallTracker:mHangupPendingMO	Z
    //   632: aload 4
    //   634: ifnull +12 -> 646
    //   637: aload_0
    //   638: getfield 82	com/android/internal/telephony/gsm/GsmCallTracker:mPhone	Lcom/android/internal/telephony/gsm/GSMPhone;
    //   641: aload 4
    //   643: invokevirtual 636	com/android/internal/telephony/gsm/GSMPhone:notifyNewRingingConnection	(Lcom/android/internal/telephony/Connection;)V
    //   646: iconst_m1
    //   647: aload_0
    //   648: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   651: invokevirtual 458	java/util/ArrayList:size	()I
    //   654: iadd
    //   655: istore 11
    //   657: iload 11
    //   659: iflt +187 -> 846
    //   662: aload_0
    //   663: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   666: iload 11
    //   668: invokevirtual 459	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   671: checkcast 44	com/android/internal/telephony/gsm/GsmConnection
    //   674: astore 12
    //   676: aload 12
    //   678: invokevirtual 639	com/android/internal/telephony/gsm/GsmConnection:isIncoming	()Z
    //   681: ifeq +115 -> 796
    //   684: aload 12
    //   686: invokevirtual 643	com/android/internal/telephony/gsm/GsmConnection:getConnectTime	()J
    //   689: lconst_0
    //   690: lcmp
    //   691: ifne +105 -> 796
    //   694: aload 12
    //   696: getfield 385	com/android/internal/telephony/gsm/GsmConnection:mCause	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   699: getstatic 646	com/android/internal/telephony/Connection$DisconnectCause:LOCAL	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   702: if_acmpne +86 -> 788
    //   705: getstatic 649	com/android/internal/telephony/Connection$DisconnectCause:INCOMING_REJECTED	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   708: astore 14
    //   710: aload_0
    //   711: new 104	java/lang/StringBuilder
    //   714: dup
    //   715: invokespecial 105	java/lang/StringBuilder:<init>	()V
    //   718: ldc_w 651
    //   721: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   724: aload 12
    //   726: getfield 385	com/android/internal/telephony/gsm/GsmConnection:mCause	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   729: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   732: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   735: invokevirtual 590	com/android/internal/telephony/gsm/GsmCallTracker:log	(Ljava/lang/String;)V
    //   738: aload_0
    //   739: new 104	java/lang/StringBuilder
    //   742: dup
    //   743: invokespecial 105	java/lang/StringBuilder:<init>	()V
    //   746: ldc_w 653
    //   749: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   752: aload 14
    //   754: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   757: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   760: invokevirtual 590	com/android/internal/telephony/gsm/GsmCallTracker:log	(Ljava/lang/String;)V
    //   763: aload_0
    //   764: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   767: iload 11
    //   769: invokevirtual 656	java/util/ArrayList:remove	(I)Ljava/lang/Object;
    //   772: pop
    //   773: iload 6
    //   775: aload 12
    //   777: aload 14
    //   779: invokevirtual 416	com/android/internal/telephony/gsm/GsmConnection:onDisconnect	(Lcom/android/internal/telephony/Connection$DisconnectCause;)Z
    //   782: ior
    //   783: istore 6
    //   785: goto +162 -> 947
    //   788: getstatic 659	com/android/internal/telephony/Connection$DisconnectCause:INCOMING_MISSED	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   791: astore 14
    //   793: goto -83 -> 710
    //   796: aload 12
    //   798: getfield 385	com/android/internal/telephony/gsm/GsmConnection:mCause	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   801: getstatic 646	com/android/internal/telephony/Connection$DisconnectCause:LOCAL	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   804: if_acmpeq +14 -> 818
    //   807: aload 12
    //   809: getfield 385	com/android/internal/telephony/gsm/GsmConnection:mCause	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   812: getstatic 382	com/android/internal/telephony/Connection$DisconnectCause:INVALID_NUMBER	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   815: if_acmpne +132 -> 947
    //   818: aload_0
    //   819: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   822: iload 11
    //   824: invokevirtual 656	java/util/ArrayList:remove	(I)Ljava/lang/Object;
    //   827: pop
    //   828: iload 6
    //   830: aload 12
    //   832: aload 12
    //   834: getfield 385	com/android/internal/telephony/gsm/GsmConnection:mCause	Lcom/android/internal/telephony/Connection$DisconnectCause;
    //   837: invokevirtual 416	com/android/internal/telephony/gsm/GsmConnection:onDisconnect	(Lcom/android/internal/telephony/Connection$DisconnectCause;)Z
    //   840: ior
    //   841: istore 6
    //   843: goto +104 -> 947
    //   846: aload_0
    //   847: getfield 60	com/android/internal/telephony/gsm/GsmCallTracker:mDroppedDuringPoll	Ljava/util/ArrayList;
    //   850: invokevirtual 458	java/util/ArrayList:size	()I
    //   853: ifle +17 -> 870
    //   856: aload_0
    //   857: getfield 89	com/android/internal/telephony/CallTracker:mCi	Lcom/android/internal/telephony/CommandsInterface;
    //   860: aload_0
    //   861: iconst_5
    //   862: invokevirtual 662	com/android/internal/telephony/gsm/GsmCallTracker:obtainNoPollCompleteMessage	(I)Landroid/os/Message;
    //   865: invokeinterface 665 2 0
    //   870: iconst_0
    //   871: ifeq +82 -> 953
    //   874: aload_0
    //   875: invokevirtual 598	com/android/internal/telephony/gsm/GsmCallTracker:pollCallsAfterDelay	()V
    //   878: goto +75 -> 953
    //   881: aload_0
    //   882: invokespecial 330	com/android/internal/telephony/gsm/GsmCallTracker:internalClearDisconnected	()V
    //   885: aload_0
    //   886: invokespecial 332	com/android/internal/telephony/gsm/GsmCallTracker:updatePhoneState	()V
    //   889: iload 7
    //   891: ifeq +80 -> 971
    //   894: aload_0
    //   895: getfield 82	com/android/internal/telephony/gsm/GsmCallTracker:mPhone	Lcom/android/internal/telephony/gsm/GSMPhone;
    //   898: invokevirtual 668	com/android/internal/telephony/gsm/GSMPhone:notifyUnknownConnection	()V
    //   901: goto +70 -> 971
    //   904: aload_0
    //   905: getfield 82	com/android/internal/telephony/gsm/GsmCallTracker:mPhone	Lcom/android/internal/telephony/gsm/GSMPhone;
    //   908: invokevirtual 335	com/android/internal/telephony/gsm/GSMPhone:notifyPreciseCallStateChanged	()V
    //   911: goto -699 -> 212
    //   914: iconst_1
    //   915: istore 5
    //   917: iinc 8 1
    //   920: goto -877 -> 43
    //   923: iconst_1
    //   924: istore 7
    //   926: goto -12 -> 914
    //   929: iconst_1
    //   930: istore 5
    //   932: goto -15 -> 917
    //   935: iconst_1
    //   936: istore 5
    //   938: goto -21 -> 917
    //   941: iconst_0
    //   942: istore 5
    //   944: goto -6 -> 938
    //   947: iinc 11 255
    //   950: goto -293 -> 657
    //   953: aload 4
    //   955: ifnonnull -74 -> 881
    //   958: iload 5
    //   960: ifne -79 -> 881
    //   963: iload 6
    //   965: ifeq -80 -> 885
    //   968: goto -87 -> 881
    //   971: iload 5
    //   973: ifne -69 -> 904
    //   976: aload 4
    //   978: ifnonnull -74 -> 904
    //   981: iload 6
    //   983: ifeq -771 -> 212
    //   986: goto -82 -> 904
    //
    // Exception table:
    //   from	to	target	type
    //   2	176	244	finally
    //   176	212	244	finally
    //   215	241	244	finally
    //   257	911	244	finally
    //   176	212	255	com/android/internal/telephony/CallStateException
  }

  void hangup(GsmCall paramGsmCall)
    throws CallStateException
  {
    if (paramGsmCall.getConnections().size() == 0)
      throw new CallStateException("no connections in call");
    if (paramGsmCall == this.mRingingCall)
    {
      log("(ringing) hangup waiting or background");
      this.mCi.hangupWaitingOrBackground(obtainCompleteMessage());
    }
    while (true)
    {
      paramGsmCall.onHangupLocal();
      this.mPhone.notifyPreciseCallStateChanged();
      return;
      if (paramGsmCall == this.mForegroundCall)
      {
        if (paramGsmCall.isDialingOrAlerting())
        {
          log("(foregnd) hangup dialing or alerting...");
          hangup((GsmConnection)paramGsmCall.getConnections().get(0));
        }
        else
        {
          hangupForegroundResumeBackground();
        }
      }
      else
      {
        if (paramGsmCall != this.mBackgroundCall)
          break;
        if (this.mRingingCall.isRinging())
        {
          log("hangup all conns in background call");
          hangupAllConnections(paramGsmCall);
        }
        else
        {
          hangupWaitingOrBackground();
        }
      }
    }
    throw new RuntimeException("GsmCall " + paramGsmCall + "does not belong to GsmCallTracker " + this);
  }

  void hangup(GsmConnection paramGsmConnection)
    throws CallStateException
  {
    if (paramGsmConnection.mOwner != this)
      throw new CallStateException("GsmConnection " + paramGsmConnection + "does not belong to GsmCallTracker " + this);
    if (paramGsmConnection == this.mPendingMO)
    {
      log("hangup: set hangupPendingMO to true");
      this.mHangupPendingMO = true;
    }
    while (true)
    {
      paramGsmConnection.onHangupLocal();
      return;
      try
      {
        this.mCi.hangupConnection(paramGsmConnection.getGSMIndex(), obtainCompleteMessage());
      }
      catch (CallStateException localCallStateException)
      {
        Rlog.w("GsmCallTracker", "GsmCallTracker WARN: hangup() on absent connection " + paramGsmConnection);
      }
    }
  }

  void hangupAllConnections(GsmCall paramGsmCall)
  {
    try
    {
      int i = paramGsmCall.mConnections.size();
      for (int j = 0; j < i; j++)
      {
        GsmConnection localGsmConnection = (GsmConnection)paramGsmCall.mConnections.get(j);
        this.mCi.hangupConnection(localGsmConnection.getGSMIndex(), obtainCompleteMessage());
      }
    }
    catch (CallStateException localCallStateException)
    {
      Rlog.e("GsmCallTracker", "hangupConnectionByIndex caught " + localCallStateException);
    }
  }

  void hangupConnectionByIndex(GsmCall paramGsmCall, int paramInt)
    throws CallStateException
  {
    int i = paramGsmCall.mConnections.size();
    for (int j = 0; j < i; j++)
      if (((GsmConnection)paramGsmCall.mConnections.get(j)).getGSMIndex() == paramInt)
      {
        this.mCi.hangupConnection(paramInt, obtainCompleteMessage());
        return;
      }
    throw new CallStateException("no gsm index found");
  }

  void hangupForegroundResumeBackground()
  {
    log("hangupForegroundResumeBackground");
    this.mCi.hangupForegroundResumeBackground(obtainCompleteMessage());
  }

  void hangupWaitingOrBackground()
  {
    log("hangupWaitingOrBackground");
    this.mCi.hangupWaitingOrBackground(obtainCompleteMessage());
  }

  protected void log(String paramString)
  {
    Rlog.d("GsmCallTracker", "[GsmCallTracker] " + paramString);
  }

  public void registerForVoiceCallEnded(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mVoiceCallEndedRegistrants.add(localRegistrant);
  }

  public void registerForVoiceCallStarted(Handler paramHandler, int paramInt, Object paramObject)
  {
    Registrant localRegistrant = new Registrant(paramHandler, paramInt, paramObject);
    this.mVoiceCallStartedRegistrants.add(localRegistrant);
  }

  void rejectCall()
    throws CallStateException
  {
    if (this.mRingingCall.getState().isRinging())
    {
      this.mCi.rejectCall(obtainCompleteMessage());
      return;
    }
    throw new CallStateException("phone not ringing");
  }

  void separate(GsmConnection paramGsmConnection)
    throws CallStateException
  {
    if (paramGsmConnection.mOwner != this)
      throw new CallStateException("GsmConnection " + paramGsmConnection + "does not belong to GsmCallTracker " + this);
    try
    {
      this.mCi.separateConnection(paramGsmConnection.getGSMIndex(), obtainCompleteMessage(12));
      return;
    }
    catch (CallStateException localCallStateException)
    {
      while (true)
        Rlog.w("GsmCallTracker", "GsmCallTracker WARN: separate() on absent connection " + paramGsmConnection);
    }
  }

  void setMute(boolean paramBoolean)
  {
    this.mDesiredMute = paramBoolean;
    this.mCi.setMute(this.mDesiredMute, null);
  }

  void switchWaitingOrHoldingAndActive()
    throws CallStateException
  {
    if (this.mRingingCall.getState() == Call.State.INCOMING)
      throw new CallStateException("cannot be in the incoming state");
    this.mCi.switchWaitingOrHoldingAndActive(obtainCompleteMessage(8));
  }

  public void unregisterForVoiceCallEnded(Handler paramHandler)
  {
    this.mVoiceCallEndedRegistrants.remove(paramHandler);
  }

  public void unregisterForVoiceCallStarted(Handler paramHandler)
  {
    this.mVoiceCallStartedRegistrants.remove(paramHandler);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmCallTracker
 * JD-Core Version:    0.6.2
 */