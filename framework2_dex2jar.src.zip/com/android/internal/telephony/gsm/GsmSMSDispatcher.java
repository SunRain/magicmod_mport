package com.android.internal.telephony.gsm;

import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.Intent;
import android.os.AsyncResult;
import android.os.Message;
import android.telephony.Rlog;
import android.telephony.ServiceState;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.GsmAlphabet.TextEncodingDetails;
import com.android.internal.telephony.ImsSMSDispatcher;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.SMSDispatcher;
import com.android.internal.telephony.SMSDispatcher.SmsTracker;
import com.android.internal.telephony.SmsHeader;
import com.android.internal.telephony.SmsMessageBase;
import com.android.internal.telephony.SmsUsageMonitor;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.IccUtils;
import com.android.internal.telephony.uicc.UiccCardApplication;
import com.android.internal.telephony.uicc.UiccController;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicReference;

public final class GsmSMSDispatcher extends SMSDispatcher
{
  private static final int EVENT_NEW_SMS_STATUS_REPORT = 100;
  private static final String TAG = "GsmSMSDispatcher";
  private static final boolean VDBG;
  private GsmInboundSmsHandler mGsmInboundSmsHandler;
  private AtomicReference<IccRecords> mIccRecords = new AtomicReference();
  private AtomicReference<UiccCardApplication> mUiccApplication = new AtomicReference();
  protected UiccController mUiccController = null;

  public GsmSMSDispatcher(PhoneBase paramPhoneBase, SmsUsageMonitor paramSmsUsageMonitor, ImsSMSDispatcher paramImsSMSDispatcher, GsmInboundSmsHandler paramGsmInboundSmsHandler)
  {
    super(paramPhoneBase, paramSmsUsageMonitor, paramImsSMSDispatcher);
    this.mCi.setOnSmsStatus(this, 100, null);
    this.mGsmInboundSmsHandler = paramGsmInboundSmsHandler;
    this.mUiccController = UiccController.getInstance();
    this.mUiccController.registerForIccChanged(this, 15, null);
    Rlog.d("GsmSMSDispatcher", "GsmSMSDispatcher created");
  }

  private void handleStatusReport(AsyncResult paramAsyncResult)
  {
    String str = (String)paramAsyncResult.result;
    SmsMessage localSmsMessage = SmsMessage.newFromCDS(str);
    int i;
    int j;
    int k;
    int m;
    if (localSmsMessage != null)
    {
      i = localSmsMessage.getStatus();
      j = localSmsMessage.mMessageRef;
      k = 0;
      m = this.deliveryPendingList.size();
    }
    while (true)
    {
      PendingIntent localPendingIntent;
      Intent localIntent;
      if (k < m)
      {
        SMSDispatcher.SmsTracker localSmsTracker = (SMSDispatcher.SmsTracker)this.deliveryPendingList.get(k);
        if (localSmsTracker.mMessageRef != j)
          break label172;
        if ((i >= 64) || (i < 32))
        {
          this.deliveryPendingList.remove(k);
          localSmsTracker.updateSentMessageStatus(this.mContext, i);
        }
        localPendingIntent = localSmsTracker.mDeliveryIntent;
        localIntent = new Intent();
        localIntent.putExtra("pdu", IccUtils.hexStringToBytes(str));
        localIntent.putExtra("format", getFormat());
      }
      try
      {
        localPendingIntent.send(this.mContext, -1, localIntent);
        label159: this.mCi.acknowledgeLastIncomingGsmSms(true, 1, null);
        return;
        label172: k++;
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
        break label159;
      }
    }
  }

  private void onUpdateIccAvailability()
  {
    if (this.mUiccController == null);
    while (true)
    {
      return;
      UiccCardApplication localUiccCardApplication1 = getUiccCardApplication();
      UiccCardApplication localUiccCardApplication2 = (UiccCardApplication)this.mUiccApplication.get();
      if (localUiccCardApplication2 != localUiccCardApplication1)
      {
        if (localUiccCardApplication2 != null)
        {
          Rlog.d("GsmSMSDispatcher", "Removing stale icc objects.");
          if (this.mIccRecords.get() != null)
            ((IccRecords)this.mIccRecords.get()).unregisterForNewSms(this);
          this.mIccRecords.set(null);
          this.mUiccApplication.set(null);
        }
        if (localUiccCardApplication1 != null)
        {
          Rlog.d("GsmSMSDispatcher", "New Uicc application found");
          this.mUiccApplication.set(localUiccCardApplication1);
          this.mIccRecords.set(localUiccCardApplication1.getIccRecords());
          if (this.mIccRecords.get() != null)
            ((IccRecords)this.mIccRecords.get()).registerForNewSms(this, 14, null);
        }
      }
    }
  }

  protected GsmAlphabet.TextEncodingDetails calculateLength(CharSequence paramCharSequence, boolean paramBoolean)
  {
    return SmsMessage.calculateLength(paramCharSequence, paramBoolean);
  }

  public void dispose()
  {
    super.dispose();
    this.mCi.unSetOnSmsStatus(this);
    this.mUiccController.unregisterForIccChanged(this);
  }

  protected String getFormat()
  {
    return "3gpp";
  }

  protected UiccCardApplication getUiccCardApplication()
  {
    return this.mUiccController.getUiccCardApplication(1);
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 100:
    case 14:
    case 15:
    }
    while (true)
    {
      return;
      handleStatusReport((AsyncResult)paramMessage.obj);
      continue;
      this.mGsmInboundSmsHandler.sendMessage(1, paramMessage.obj);
      continue;
      onUpdateIccAvailability();
    }
  }

  protected void sendData(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfByte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    boolean bool;
    if (paramPendingIntent2 != null)
    {
      bool = true;
      SmsMessage.SubmitPdu localSubmitPdu = SmsMessage.getSubmitPdu(paramString2, paramString1, paramInt, paramArrayOfByte, bool);
      if (localSubmitPdu == null)
        break label59;
      sendRawPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramInt, paramArrayOfByte, localSubmitPdu), paramPendingIntent1, paramPendingIntent2, getFormat()));
    }
    while (true)
    {
      return;
      bool = false;
      break;
      label59: Rlog.e("GsmSMSDispatcher", "GsmSMSDispatcher.sendData(): getSubmitPdu() returned null");
    }
  }

  protected void sendNewSubmitPdu(String paramString1, String paramString2, String paramString3, SmsHeader paramSmsHeader, int paramInt, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, boolean paramBoolean)
  {
    boolean bool;
    if (paramPendingIntent2 != null)
    {
      bool = true;
      SmsMessage.SubmitPdu localSubmitPdu = SmsMessage.getSubmitPdu(paramString2, paramString1, paramString3, bool, SmsHeader.toByteArray(paramSmsHeader), paramInt, paramSmsHeader.languageTable, paramSmsHeader.languageShiftTable);
      if (localSubmitPdu == null)
        break label72;
      sendRawPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramString3, localSubmitPdu), paramPendingIntent1, paramPendingIntent2, getFormat()));
    }
    while (true)
    {
      return;
      bool = false;
      break;
      label72: Rlog.e("GsmSMSDispatcher", "GsmSMSDispatcher.sendNewSubmitPdu(): getSubmitPdu() returned null");
    }
  }

  protected void sendSms(SMSDispatcher.SmsTracker paramSmsTracker)
  {
    HashMap localHashMap = paramSmsTracker.mData;
    byte[] arrayOfByte1 = (byte[])localHashMap.get("smsc");
    byte[] arrayOfByte2 = (byte[])localHashMap.get("pdu");
    Message localMessage = obtainMessage(2, paramSmsTracker);
    if (paramSmsTracker.mRetryCount > 0)
    {
      Rlog.d("GsmSMSDispatcher", "sendSms:  mRetryCount=" + paramSmsTracker.mRetryCount + " mMessageRef=" + paramSmsTracker.mMessageRef + " SS=" + this.mPhone.getServiceState().getState());
      if ((0x1 & arrayOfByte2[0]) == 1)
      {
        arrayOfByte2[0] = ((byte)(0x4 | arrayOfByte2[0]));
        arrayOfByte2[1] = ((byte)paramSmsTracker.mMessageRef);
      }
    }
    Rlog.d("GsmSMSDispatcher", "sendSms:  isIms()=" + isIms() + " mRetryCount=" + paramSmsTracker.mRetryCount + " mImsRetry=" + paramSmsTracker.mImsRetry + " mMessageRef=" + paramSmsTracker.mMessageRef + " SS=" + this.mPhone.getServiceState().getState());
    if ((paramSmsTracker.mImsRetry == 0) && (!isIms()))
    {
      if ((paramSmsTracker.mRetryCount > 0) && ((0x1 & arrayOfByte2[0]) == 1))
      {
        arrayOfByte2[0] = ((byte)(0x4 | arrayOfByte2[0]));
        arrayOfByte2[1] = ((byte)paramSmsTracker.mMessageRef);
      }
      this.mCi.sendSMS(IccUtils.bytesToHexString(arrayOfByte1), IccUtils.bytesToHexString(arrayOfByte2), localMessage);
    }
    while (true)
    {
      return;
      this.mCi.sendImsGsmSms(IccUtils.bytesToHexString(arrayOfByte1), IccUtils.bytesToHexString(arrayOfByte2), paramSmsTracker.mImsRetry, paramSmsTracker.mMessageRef, localMessage);
      paramSmsTracker.mImsRetry = (1 + paramSmsTracker.mImsRetry);
    }
  }

  protected void sendText(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    boolean bool;
    if (paramPendingIntent2 != null)
    {
      bool = true;
      SmsMessage.SubmitPdu localSubmitPdu = SmsMessage.getSubmitPdu(paramString2, paramString1, paramString3, bool);
      if (localSubmitPdu == null)
        break label55;
      sendRawPdu(getSmsTracker(getSmsTrackerMap(paramString1, paramString2, paramString3, localSubmitPdu), paramPendingIntent1, paramPendingIntent2, getFormat()));
    }
    while (true)
    {
      return;
      bool = false;
      break;
      label55: Rlog.e("GsmSMSDispatcher", "GsmSMSDispatcher.sendText(): getSubmitPdu() returned null");
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmSMSDispatcher
 * JD-Core Version:    0.6.2
 */