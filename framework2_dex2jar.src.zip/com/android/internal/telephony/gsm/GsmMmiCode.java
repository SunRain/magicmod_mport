package com.android.internal.telephony.gsm;

import android.content.Context;
import android.content.res.Resources;
import android.os.AsyncResult;
import android.os.Handler;
import android.os.Message;
import android.telephony.PhoneNumberUtils;
import android.telephony.Rlog;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import com.android.internal.telephony.CallForwardInfo;
import com.android.internal.telephony.CommandException;
import com.android.internal.telephony.CommandException.Error;
import com.android.internal.telephony.CommandsInterface;
import com.android.internal.telephony.MmiCode;
import com.android.internal.telephony.MmiCode.State;
import com.android.internal.telephony.PhoneBase;
import com.android.internal.telephony.uicc.IccCardApplicationStatus.AppState;
import com.android.internal.telephony.uicc.IccRecords;
import com.android.internal.telephony.uicc.UiccCardApplication;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class GsmMmiCode extends Handler
  implements MmiCode
{
  static final String ACTION_ACTIVATE = "*";
  static final String ACTION_DEACTIVATE = "#";
  static final String ACTION_ERASURE = "##";
  static final String ACTION_INTERROGATE = "*#";
  static final String ACTION_REGISTER = "**";
  static final char END_OF_USSD_COMMAND = '#';
  static final int EVENT_GET_CLIR_COMPLETE = 2;
  static final int EVENT_QUERY_CF_COMPLETE = 3;
  static final int EVENT_QUERY_COMPLETE = 5;
  static final int EVENT_SET_CFF_COMPLETE = 6;
  static final int EVENT_SET_COMPLETE = 1;
  static final int EVENT_USSD_CANCEL_COMPLETE = 7;
  static final int EVENT_USSD_COMPLETE = 4;
  static final String LOG_TAG = "GsmMmiCode";
  static final int MATCH_GROUP_ACTION = 2;
  static final int MATCH_GROUP_DIALING_NUMBER = 12;
  static final int MATCH_GROUP_POUND_STRING = 1;
  static final int MATCH_GROUP_PWD_CONFIRM = 11;
  static final int MATCH_GROUP_SERVICE_CODE = 3;
  static final int MATCH_GROUP_SIA = 5;
  static final int MATCH_GROUP_SIB = 7;
  static final int MATCH_GROUP_SIC = 9;
  static final int MAX_LENGTH_SHORT_CODE = 2;
  static final String SC_BAIC = "35";
  static final String SC_BAICr = "351";
  static final String SC_BAOC = "33";
  static final String SC_BAOIC = "331";
  static final String SC_BAOICxH = "332";
  static final String SC_BA_ALL = "330";
  static final String SC_BA_MO = "333";
  static final String SC_BA_MT = "353";
  static final String SC_CFB = "67";
  static final String SC_CFNR = "62";
  static final String SC_CFNRy = "61";
  static final String SC_CFU = "21";
  static final String SC_CF_All = "002";
  static final String SC_CF_All_Conditional = "004";
  static final String SC_CLIP = "30";
  static final String SC_CLIR = "31";
  static final String SC_PIN = "04";
  static final String SC_PIN2 = "042";
  static final String SC_PUK = "05";
  static final String SC_PUK2 = "052";
  static final String SC_PWD = "03";
  static final String SC_WAIT = "43";
  static Pattern sPatternSuppService = Pattern.compile("((\\*|#|\\*#|\\*\\*|##)(\\d{2,3})(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*)(\\*([^*#]*))?)?)?)?#)(.*)");
  private static String[] sTwoDigitNumberPattern;
  String mAction;
  Context mContext;
  String mDialingNumber;
  IccRecords mIccRecords;
  private boolean mIsCallFwdReg;
  private boolean mIsPendingUSSD;
  private boolean mIsUssdRequest;
  CharSequence mMessage;
  GSMPhone mPhone;
  String mPoundString;
  String mPwd;
  String mSc;
  String mSia;
  String mSib;
  String mSic;
  MmiCode.State mState = MmiCode.State.PENDING;
  UiccCardApplication mUiccApplication;

  GsmMmiCode(GSMPhone paramGSMPhone, UiccCardApplication paramUiccCardApplication)
  {
    super(paramGSMPhone.getHandler().getLooper());
    this.mPhone = paramGSMPhone;
    this.mContext = paramGSMPhone.getContext();
    this.mUiccApplication = paramUiccCardApplication;
    if (paramUiccCardApplication != null)
      this.mIccRecords = paramUiccCardApplication.getIccRecords();
  }

  private CharSequence createQueryCallBarringResultMessage(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder(this.mContext.getText(17039444));
    int i = 1;
    while (i <= 128)
    {
      if ((i & paramInt) != 0)
      {
        localStringBuilder.append("\n");
        localStringBuilder.append(serviceClassToCFString(i & paramInt));
      }
      i <<= 1;
    }
    return localStringBuilder;
  }

  private CharSequence createQueryCallWaitingResultMessage(int paramInt)
  {
    StringBuilder localStringBuilder = new StringBuilder(this.mContext.getText(17039444));
    int i = 1;
    while (i <= 128)
    {
      if ((i & paramInt) != 0)
      {
        localStringBuilder.append("\n");
        localStringBuilder.append(serviceClassToCFString(i & paramInt));
      }
      i <<= 1;
    }
    return localStringBuilder;
  }

  private CharSequence getErrorMessage(AsyncResult paramAsyncResult)
  {
    if (((paramAsyncResult.exception instanceof CommandException)) && (((CommandException)paramAsyncResult.exception).getCommandError() == CommandException.Error.FDN_CHECK_FAILURE))
      Rlog.i("GsmMmiCode", "FDN_CHECK_FAILURE");
    for (CharSequence localCharSequence = this.mContext.getText(17039442); ; localCharSequence = this.mContext.getText(17039441))
      return localCharSequence;
  }

  private CharSequence getScString()
  {
    Object localObject;
    if (this.mSc != null)
      if (isServiceCodeCallBarring(this.mSc))
        localObject = this.mContext.getText(17039464);
    while (true)
    {
      return localObject;
      if (isServiceCodeCallForwarding(this.mSc))
        localObject = this.mContext.getText(17039462);
      else if (this.mSc.equals("30"))
        localObject = this.mContext.getText(17039460);
      else if (this.mSc.equals("31"))
        localObject = this.mContext.getText(17039461);
      else if (this.mSc.equals("03"))
        localObject = this.mContext.getText(17039465);
      else if (this.mSc.equals("43"))
        localObject = this.mContext.getText(17039463);
      else if (isPinPukCommand())
        localObject = this.mContext.getText(17039466);
      else
        localObject = "";
    }
  }

  private void handlePasswordError(int paramInt)
  {
    this.mState = MmiCode.State.FAILED;
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    localStringBuilder.append(this.mContext.getText(paramInt));
    this.mMessage = localStringBuilder;
    this.mPhone.onMMIDone(this);
  }

  private static boolean isEmptyOrNull(CharSequence paramCharSequence)
  {
    if ((paramCharSequence == null) || (paramCharSequence.length() == 0));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  static boolean isServiceCodeCallBarring(String paramString)
  {
    Resources localResources = Resources.getSystem();
    int j;
    if (paramString != null)
    {
      String[] arrayOfString = localResources.getStringArray(17236015);
      if (arrayOfString != null)
      {
        int i = arrayOfString.length;
        j = 0;
        if (j < i)
          if (!paramString.equals(arrayOfString[j]));
      }
    }
    for (boolean bool = true; ; bool = false)
    {
      return bool;
      j++;
      break;
    }
  }

  static boolean isServiceCodeCallForwarding(String paramString)
  {
    if ((paramString != null) && ((paramString.equals("21")) || (paramString.equals("67")) || (paramString.equals("61")) || (paramString.equals("62")) || (paramString.equals("002")) || (paramString.equals("004"))));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private static boolean isShortCode(String paramString, GSMPhone paramGSMPhone)
  {
    boolean bool = false;
    if (paramString == null);
    while (true)
    {
      return bool;
      if ((paramString.length() != 0) && (!PhoneNumberUtils.isLocalEmergencyNumber(paramString, paramGSMPhone.getContext())))
        bool = isShortCodeUSSD(paramString, paramGSMPhone);
    }
  }

  private static boolean isShortCodeUSSD(String paramString, GSMPhone paramGSMPhone)
  {
    boolean bool = true;
    if ((paramString != null) && (paramString.length() <= 2))
      if (!paramGSMPhone.isInCall());
    while (true)
    {
      return bool;
      if ((paramString.length() == 2) && (paramString.charAt(0) == '1'))
        bool = false;
    }
  }

  private static boolean isTwoDigitShortCode(Context paramContext, String paramString)
  {
    boolean bool = false;
    Rlog.d("GsmMmiCode", "isTwoDigitShortCode");
    if ((paramString == null) || (paramString.length() != 2));
    while (true)
    {
      return bool;
      if (sTwoDigitNumberPattern == null)
        sTwoDigitNumberPattern = paramContext.getResources().getStringArray(17236004);
      String[] arrayOfString = sTwoDigitNumberPattern;
      int i = arrayOfString.length;
      for (int j = 0; ; j++)
      {
        if (j >= i)
          break label127;
        String str = arrayOfString[j];
        Rlog.d("GsmMmiCode", "Two Digit Number Pattern " + str);
        if (paramString.equals(str))
        {
          Rlog.d("GsmMmiCode", "Two Digit Number Pattern -true");
          bool = true;
          break;
        }
      }
      label127: Rlog.d("GsmMmiCode", "Two Digit Number Pattern -false");
    }
  }

  private CharSequence makeCFQueryResultMessage(CallForwardInfo paramCallForwardInfo, int paramInt)
  {
    String[] arrayOfString = { "{0}", "{1}", "{2}" };
    CharSequence[] arrayOfCharSequence = new CharSequence[3];
    int i;
    CharSequence localCharSequence;
    if (paramCallForwardInfo.reason == 2)
    {
      i = 1;
      if (paramCallForwardInfo.status != 1)
        break label184;
      if (i == 0)
        break label169;
      localCharSequence = this.mContext.getText(17039512);
      label65: arrayOfCharSequence[0] = serviceClassToCFString(paramInt & paramCallForwardInfo.serviceClass);
      arrayOfCharSequence[1] = PhoneNumberUtils.stringFromStringAndTOA(paramCallForwardInfo.number, paramCallForwardInfo.toa);
      arrayOfCharSequence[2] = Integer.toString(paramCallForwardInfo.timeSeconds);
      if ((paramCallForwardInfo.reason == 0) && ((paramInt & paramCallForwardInfo.serviceClass) == 1))
        if (paramCallForwardInfo.status != 1)
          break label251;
    }
    label169: label184: label251: for (boolean bool = true; ; bool = false)
    {
      if (this.mIccRecords != null)
        this.mIccRecords.setVoiceCallForwardingFlag(1, bool, paramCallForwardInfo.number);
      return TextUtils.replace(localCharSequence, arrayOfString, arrayOfCharSequence);
      i = 0;
      break;
      localCharSequence = this.mContext.getText(17039511);
      break label65;
      if ((paramCallForwardInfo.status == 0) && (isEmptyOrNull(paramCallForwardInfo.number)))
      {
        localCharSequence = this.mContext.getText(17039510);
        break label65;
      }
      if (i != 0)
      {
        localCharSequence = this.mContext.getText(17039514);
        break label65;
      }
      localCharSequence = this.mContext.getText(17039513);
      break label65;
    }
  }

  private static String makeEmptyNull(String paramString)
  {
    if ((paramString != null) && (paramString.length() == 0))
      paramString = null;
    return paramString;
  }

  static GsmMmiCode newFromDialString(String paramString, GSMPhone paramGSMPhone, UiccCardApplication paramUiccCardApplication)
  {
    GsmMmiCode localGsmMmiCode = null;
    Matcher localMatcher = sPatternSuppService.matcher(paramString);
    if (localMatcher.matches())
    {
      localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
      localGsmMmiCode.mPoundString = makeEmptyNull(localMatcher.group(1));
      localGsmMmiCode.mAction = makeEmptyNull(localMatcher.group(2));
      localGsmMmiCode.mSc = makeEmptyNull(localMatcher.group(3));
      localGsmMmiCode.mSia = makeEmptyNull(localMatcher.group(5));
      localGsmMmiCode.mSib = makeEmptyNull(localMatcher.group(7));
      localGsmMmiCode.mSic = makeEmptyNull(localMatcher.group(9));
      localGsmMmiCode.mPwd = makeEmptyNull(localMatcher.group(11));
      localGsmMmiCode.mDialingNumber = makeEmptyNull(localMatcher.group(12));
      if ((localGsmMmiCode.mDialingNumber != null) && (localGsmMmiCode.mDialingNumber.endsWith("#")) && (paramString.endsWith("#")))
      {
        localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
        localGsmMmiCode.mPoundString = paramString;
      }
    }
    while (true)
    {
      return localGsmMmiCode;
      if (paramString.endsWith("#"))
      {
        localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
        localGsmMmiCode.mPoundString = paramString;
      }
      else if (isTwoDigitShortCode(paramGSMPhone.getContext(), paramString))
      {
        localGsmMmiCode = null;
      }
      else if (isShortCode(paramString, paramGSMPhone))
      {
        localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
        localGsmMmiCode.mDialingNumber = paramString;
      }
    }
  }

  static GsmMmiCode newFromUssdUserInput(String paramString, GSMPhone paramGSMPhone, UiccCardApplication paramUiccCardApplication)
  {
    GsmMmiCode localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
    localGsmMmiCode.mMessage = paramString;
    localGsmMmiCode.mState = MmiCode.State.PENDING;
    localGsmMmiCode.mIsPendingUSSD = true;
    return localGsmMmiCode;
  }

  static GsmMmiCode newNetworkInitiatedUssd(String paramString, boolean paramBoolean, GSMPhone paramGSMPhone, UiccCardApplication paramUiccCardApplication)
  {
    GsmMmiCode localGsmMmiCode = new GsmMmiCode(paramGSMPhone, paramUiccCardApplication);
    localGsmMmiCode.mMessage = paramString;
    localGsmMmiCode.mIsUssdRequest = paramBoolean;
    if (paramBoolean)
      localGsmMmiCode.mIsPendingUSSD = true;
    for (localGsmMmiCode.mState = MmiCode.State.PENDING; ; localGsmMmiCode.mState = MmiCode.State.COMPLETE)
      return localGsmMmiCode;
  }

  private void onGetClirComplete(AsyncResult paramAsyncResult)
  {
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    if (paramAsyncResult.exception != null)
    {
      this.mState = MmiCode.State.FAILED;
      localStringBuilder.append(getErrorMessage(paramAsyncResult));
    }
    int[] arrayOfInt;
    while (true)
    {
      this.mMessage = localStringBuilder;
      this.mPhone.onMMIDone(this);
      return;
      arrayOfInt = (int[])paramAsyncResult.result;
      switch (arrayOfInt[1])
      {
      default:
        break;
      case 0:
        localStringBuilder.append(this.mContext.getText(17039477));
        this.mState = MmiCode.State.COMPLETE;
        break;
      case 1:
        localStringBuilder.append(this.mContext.getText(17039478));
        this.mState = MmiCode.State.COMPLETE;
        break;
      case 2:
        localStringBuilder.append(this.mContext.getText(17039441));
        this.mState = MmiCode.State.FAILED;
      case 3:
      case 4:
      }
    }
    switch (arrayOfInt[0])
    {
    default:
      localStringBuilder.append(this.mContext.getText(17039473));
    case 1:
    case 2:
    }
    while (true)
    {
      this.mState = MmiCode.State.COMPLETE;
      break;
      localStringBuilder.append(this.mContext.getText(17039473));
      continue;
      localStringBuilder.append(this.mContext.getText(17039474));
    }
    switch (arrayOfInt[0])
    {
    default:
      localStringBuilder.append(this.mContext.getText(17039476));
    case 1:
    case 2:
    }
    while (true)
    {
      this.mState = MmiCode.State.COMPLETE;
      break;
      localStringBuilder.append(this.mContext.getText(17039475));
      continue;
      localStringBuilder.append(this.mContext.getText(17039476));
    }
  }

  private void onQueryCfComplete(AsyncResult paramAsyncResult)
  {
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    if (paramAsyncResult.exception != null)
    {
      this.mState = MmiCode.State.FAILED;
      localStringBuilder.append(getErrorMessage(paramAsyncResult));
      this.mMessage = localStringBuilder;
      this.mPhone.onMMIDone(this);
      return;
    }
    CallForwardInfo[] arrayOfCallForwardInfo = (CallForwardInfo[])paramAsyncResult.result;
    if (arrayOfCallForwardInfo.length == 0)
    {
      localStringBuilder.append(this.mContext.getText(17039445));
      if (this.mIccRecords != null)
        this.mIccRecords.setVoiceCallForwardingFlag(1, false, null);
    }
    while (true)
    {
      this.mState = MmiCode.State.COMPLETE;
      break;
      SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder();
      int i = 1;
      while (i <= 128)
      {
        int j = 0;
        int k = arrayOfCallForwardInfo.length;
        while (j < k)
        {
          if ((i & arrayOfCallForwardInfo[j].serviceClass) != 0)
          {
            localSpannableStringBuilder.append(makeCFQueryResultMessage(arrayOfCallForwardInfo[j], i));
            localSpannableStringBuilder.append("\n");
          }
          j++;
        }
        i <<= 1;
      }
      localStringBuilder.append(localSpannableStringBuilder);
    }
  }

  private void onQueryComplete(AsyncResult paramAsyncResult)
  {
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    if (paramAsyncResult.exception != null)
    {
      this.mState = MmiCode.State.FAILED;
      localStringBuilder.append(getErrorMessage(paramAsyncResult));
      this.mMessage = localStringBuilder;
      this.mPhone.onMMIDone(this);
      return;
    }
    int[] arrayOfInt = (int[])paramAsyncResult.result;
    if (arrayOfInt.length != 0)
      if (arrayOfInt[0] == 0)
        localStringBuilder.append(this.mContext.getText(17039445));
    while (true)
    {
      this.mState = MmiCode.State.COMPLETE;
      break;
      if (this.mSc.equals("43"))
      {
        localStringBuilder.append(createQueryCallWaitingResultMessage(arrayOfInt[1]));
      }
      else if (isServiceCodeCallBarring(this.mSc))
      {
        localStringBuilder.append(createQueryCallBarringResultMessage(arrayOfInt[0]));
      }
      else if (arrayOfInt[0] == 1)
      {
        localStringBuilder.append(this.mContext.getText(17039443));
      }
      else
      {
        localStringBuilder.append(this.mContext.getText(17039441));
        continue;
        localStringBuilder.append(this.mContext.getText(17039441));
      }
    }
  }

  private void onSetComplete(Message paramMessage, AsyncResult paramAsyncResult)
  {
    StringBuilder localStringBuilder = new StringBuilder(getScString());
    localStringBuilder.append("\n");
    CommandException.Error localError;
    int i;
    if (paramAsyncResult.exception != null)
    {
      this.mState = MmiCode.State.FAILED;
      if ((paramAsyncResult.exception instanceof CommandException))
      {
        localError = ((CommandException)paramAsyncResult.exception).getCommandError();
        if (localError == CommandException.Error.PASSWORD_INCORRECT)
          if (isPinPukCommand())
            if ((this.mSc.equals("05")) || (this.mSc.equals("052")))
            {
              localStringBuilder.append(this.mContext.getText(17039451));
              i = paramMessage.arg1;
              if (i > 0)
                break label171;
              Rlog.d("GsmMmiCode", "onSetComplete: PUK locked, cancel as lock screen will handle this");
              this.mState = MmiCode.State.CANCELLED;
            }
      }
    }
    while (true)
    {
      this.mMessage = localStringBuilder;
      this.mPhone.onMMIDone(this);
      return;
      localStringBuilder.append(this.mContext.getText(17039450));
      break;
      label171: if (i > 0)
      {
        Rlog.d("GsmMmiCode", "onSetComplete: attemptsRemaining=" + i);
        Resources localResources = this.mContext.getResources();
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(i);
        localStringBuilder.append(localResources.getQuantityString(18022400, i, arrayOfObject));
        continue;
        localStringBuilder.append(this.mContext.getText(17039448));
        continue;
        if (localError == CommandException.Error.SIM_PUK2)
        {
          localStringBuilder.append(this.mContext.getText(17039450));
          localStringBuilder.append("\n");
          localStringBuilder.append(this.mContext.getText(17039456));
        }
        else if (localError == CommandException.Error.REQUEST_NOT_SUPPORTED)
        {
          if (this.mSc.equals("04"))
            localStringBuilder.append(this.mContext.getText(17039457));
        }
        else if (localError == CommandException.Error.FDN_CHECK_FAILURE)
        {
          Rlog.i("GsmMmiCode", "FDN_CHECK_FAILURE");
          localStringBuilder.append(this.mContext.getText(17039442));
        }
        else
        {
          localStringBuilder.append(this.mContext.getText(17039441));
          continue;
          localStringBuilder.append(this.mContext.getText(17039441));
          continue;
          if (isActivate())
          {
            this.mState = MmiCode.State.COMPLETE;
            if (this.mIsCallFwdReg)
              localStringBuilder.append(this.mContext.getText(17039446));
            while (true)
            {
              if (!this.mSc.equals("31"))
                break label495;
              this.mPhone.saveClirSetting(1);
              break;
              localStringBuilder.append(this.mContext.getText(17039443));
            }
          }
          else
          {
            label495: if (isDeactivate())
            {
              this.mState = MmiCode.State.COMPLETE;
              localStringBuilder.append(this.mContext.getText(17039445));
              if (this.mSc.equals("31"))
                this.mPhone.saveClirSetting(2);
            }
            else if (isRegister())
            {
              this.mState = MmiCode.State.COMPLETE;
              localStringBuilder.append(this.mContext.getText(17039446));
            }
            else if (isErasure())
            {
              this.mState = MmiCode.State.COMPLETE;
              localStringBuilder.append(this.mContext.getText(17039447));
            }
            else
            {
              this.mState = MmiCode.State.FAILED;
              localStringBuilder.append(this.mContext.getText(17039441));
            }
          }
        }
      }
    }
  }

  static String scToBarringFacility(String paramString)
  {
    if (paramString == null)
      throw new RuntimeException("invalid call barring sc");
    String str;
    if (paramString.equals("33"))
      str = "AO";
    while (true)
    {
      return str;
      if (paramString.equals("331"))
      {
        str = "OI";
      }
      else if (paramString.equals("332"))
      {
        str = "OX";
      }
      else if (paramString.equals("35"))
      {
        str = "AI";
      }
      else if (paramString.equals("351"))
      {
        str = "IR";
      }
      else if (paramString.equals("330"))
      {
        str = "AB";
      }
      else if (paramString.equals("333"))
      {
        str = "AG";
      }
      else
      {
        if (!paramString.equals("353"))
          break;
        str = "AC";
      }
    }
    throw new RuntimeException("invalid call barring sc");
  }

  private static int scToCallForwardReason(String paramString)
  {
    if (paramString == null)
      throw new RuntimeException("invalid call forward sc");
    int i;
    if (paramString.equals("002"))
      i = 4;
    while (true)
    {
      return i;
      if (paramString.equals("21"))
      {
        i = 0;
      }
      else if (paramString.equals("67"))
      {
        i = 1;
      }
      else if (paramString.equals("62"))
      {
        i = 3;
      }
      else if (paramString.equals("61"))
      {
        i = 2;
      }
      else
      {
        if (!paramString.equals("004"))
          break;
        i = 5;
      }
    }
    throw new RuntimeException("invalid call forward sc");
  }

  private CharSequence serviceClassToCFString(int paramInt)
  {
    CharSequence localCharSequence;
    switch (paramInt)
    {
    default:
      localCharSequence = null;
    case 1:
    case 2:
    case 4:
    case 8:
    case 16:
    case 32:
    case 64:
    case 128:
    }
    while (true)
    {
      return localCharSequence;
      localCharSequence = this.mContext.getText(17039488);
      continue;
      localCharSequence = this.mContext.getText(17039489);
      continue;
      localCharSequence = this.mContext.getText(17039490);
      continue;
      localCharSequence = this.mContext.getText(17039491);
      continue;
      localCharSequence = this.mContext.getText(17039493);
      continue;
      localCharSequence = this.mContext.getText(17039492);
      continue;
      localCharSequence = this.mContext.getText(17039494);
      continue;
      localCharSequence = this.mContext.getText(17039495);
    }
  }

  private static int siToServiceClass(String paramString)
  {
    int i;
    if ((paramString == null) || (paramString.length() == 0))
      i = 0;
    while (true)
    {
      return i;
      switch (Integer.parseInt(paramString, 10))
      {
      default:
        throw new RuntimeException("unsupported MMI service code " + paramString);
      case 10:
        i = 13;
        break;
      case 11:
        i = 1;
        break;
      case 12:
        i = 12;
        break;
      case 13:
        i = 4;
        break;
      case 16:
        i = 8;
        break;
      case 19:
        i = 5;
        break;
      case 20:
        i = 48;
        break;
      case 21:
        i = 160;
        break;
      case 22:
        i = 80;
        break;
      case 24:
        i = 16;
        break;
      case 25:
        i = 32;
        break;
      case 26:
        i = 17;
        break;
      case 99:
        i = 64;
      }
    }
  }

  private static int siToTime(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0));
    for (int i = 0; ; i = Integer.parseInt(paramString, 10))
      return i;
  }

  public void cancel()
  {
    if ((this.mState == MmiCode.State.COMPLETE) || (this.mState == MmiCode.State.FAILED));
    while (true)
    {
      return;
      this.mState = MmiCode.State.CANCELLED;
      if (this.mIsPendingUSSD)
        this.mPhone.mCi.cancelPendingUssd(obtainMessage(7, this));
      else
        this.mPhone.onMMIDone(this);
    }
  }

  int getCLIRMode()
  {
    int i;
    if ((this.mSc != null) && (this.mSc.equals("31")))
      if (isActivate())
        i = 2;
    while (true)
    {
      return i;
      if (isDeactivate())
        i = 1;
      else
        i = 0;
    }
  }

  public CharSequence getMessage()
  {
    return this.mMessage;
  }

  public MmiCode.State getState()
  {
    return this.mState;
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
    case 1:
    case 6:
    case 2:
    case 3:
    case 5:
    case 4:
    case 7:
    }
    while (true)
    {
      return;
      onSetComplete(paramMessage, (AsyncResult)paramMessage.obj);
      continue;
      AsyncResult localAsyncResult2 = (AsyncResult)paramMessage.obj;
      if ((localAsyncResult2.exception == null) && (paramMessage.arg1 == 1))
        if (paramMessage.arg2 != 1)
          break label134;
      label134: for (boolean bool = true; ; bool = false)
      {
        if (this.mIccRecords != null)
          this.mIccRecords.setVoiceCallForwardingFlag(1, bool, this.mDialingNumber);
        onSetComplete(paramMessage, localAsyncResult2);
        break;
      }
      onGetClirComplete((AsyncResult)paramMessage.obj);
      continue;
      onQueryCfComplete((AsyncResult)paramMessage.obj);
      continue;
      onQueryComplete((AsyncResult)paramMessage.obj);
      continue;
      AsyncResult localAsyncResult1 = (AsyncResult)paramMessage.obj;
      if (localAsyncResult1.exception != null)
      {
        this.mState = MmiCode.State.FAILED;
        this.mMessage = getErrorMessage(localAsyncResult1);
        this.mPhone.onMMIDone(this);
        continue;
        this.mPhone.onMMIDone(this);
      }
    }
  }

  boolean isActivate()
  {
    if ((this.mAction != null) && (this.mAction.equals("*")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isCancelable()
  {
    return this.mIsPendingUSSD;
  }

  boolean isDeactivate()
  {
    if ((this.mAction != null) && (this.mAction.equals("#")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isErasure()
  {
    if ((this.mAction != null) && (this.mAction.equals("##")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isInterrogate()
  {
    if ((this.mAction != null) && (this.mAction.equals("*#")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isMMI()
  {
    if (this.mPoundString != null);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isPendingUSSD()
  {
    return this.mIsPendingUSSD;
  }

  boolean isPinPukCommand()
  {
    if ((this.mSc != null) && ((this.mSc.equals("04")) || (this.mSc.equals("042")) || (this.mSc.equals("05")) || (this.mSc.equals("052"))));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isRegister()
  {
    if ((this.mAction != null) && (this.mAction.equals("**")));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isShortCode()
  {
    if ((this.mPoundString == null) && (this.mDialingNumber != null) && (this.mDialingNumber.length() <= 2));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  boolean isTemporaryModeCLIR()
  {
    if ((this.mSc != null) && (this.mSc.equals("31")) && (this.mDialingNumber != null) && ((isActivate()) || (isDeactivate())));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isUssdRequest()
  {
    return this.mIsUssdRequest;
  }

  void onUssdFinished(String paramString, boolean paramBoolean)
  {
    if (this.mState == MmiCode.State.PENDING)
      if (paramString != null)
        break label53;
    label53: for (this.mMessage = this.mContext.getText(17039449); ; this.mMessage = paramString)
    {
      this.mIsUssdRequest = paramBoolean;
      if (!paramBoolean)
        this.mState = MmiCode.State.COMPLETE;
      this.mPhone.onMMIDone(this);
      return;
    }
  }

  void onUssdFinishedError()
  {
    if (this.mState == MmiCode.State.PENDING)
    {
      this.mState = MmiCode.State.FAILED;
      this.mMessage = this.mContext.getText(17039441);
      this.mPhone.onMMIDone(this);
    }
  }

  void processCode()
  {
    try
    {
      if (isShortCode())
      {
        Rlog.d("GsmMmiCode", "isShortCode");
        sendUssd(this.mDialingNumber);
        break label1218;
      }
      if (this.mDialingNumber != null)
        throw new RuntimeException("Invalid or Unsupported MMI Code");
    }
    catch (RuntimeException localRuntimeException)
    {
      this.mState = MmiCode.State.FAILED;
      this.mMessage = this.mContext.getText(17039441);
      this.mPhone.onMMIDone(this);
    }
    int m;
    int n;
    int i2;
    int i3;
    int i4;
    String str1;
    String str2;
    int i;
    if ((this.mSc != null) && (this.mSc.equals("30")))
    {
      Rlog.d("GsmMmiCode", "is CLIP");
      if (isInterrogate())
        this.mPhone.mCi.queryCLIP(obtainMessage(5, this));
      else
        throw new RuntimeException("Invalid or Unsupported MMI Code");
    }
    else if ((this.mSc != null) && (this.mSc.equals("31")))
    {
      Rlog.d("GsmMmiCode", "is CLIR");
      if (isActivate())
        this.mPhone.mCi.setCLIR(1, obtainMessage(1, this));
      else if (isDeactivate())
        this.mPhone.mCi.setCLIR(2, obtainMessage(1, this));
      else if (isInterrogate())
        this.mPhone.mCi.getCLIR(obtainMessage(2, this));
      else
        throw new RuntimeException("Invalid or Unsupported MMI Code");
    }
    else if (isServiceCodeCallForwarding(this.mSc))
    {
      Rlog.d("GsmMmiCode", "is CF");
      String str8 = this.mSia;
      m = siToServiceClass(this.mSib);
      n = scToCallForwardReason(this.mSc);
      int i1 = siToTime(this.mSic);
      if (isInterrogate())
      {
        this.mPhone.mCi.queryCallForwardStatus(n, m, str8, obtainMessage(3, this));
      }
      else if (isActivate())
      {
        if (isEmptyOrNull(str8))
        {
          i2 = 1;
          this.mIsCallFwdReg = false;
          break label1219;
          Rlog.d("GsmMmiCode", "is CF setCallForward");
          this.mPhone.mCi.setCallForward(i2, n, m, str8, i1, obtainMessage(6, i3, i4, this));
        }
        else
        {
          i2 = 3;
          this.mIsCallFwdReg = true;
          break label1219;
        }
      }
      else
      {
        if (isDeactivate())
        {
          i2 = 0;
          break label1219;
        }
        if (isRegister())
        {
          i2 = 3;
          break label1219;
        }
        if (isErasure())
        {
          i2 = 4;
          break label1219;
        }
        throw new RuntimeException("invalid action");
      }
    }
    else if (isServiceCodeCallBarring(this.mSc))
    {
      String str6 = this.mSia;
      int k = siToServiceClass(this.mSib);
      String str7 = scToBarringFacility(this.mSc);
      if (isInterrogate())
        this.mPhone.mCi.queryFacilityLock(str7, str6, k, obtainMessage(5, this));
      else if ((isActivate()) || (isDeactivate()))
        this.mPhone.mCi.setFacilityLock(str7, isActivate(), str6, k, obtainMessage(1, this));
      else
        throw new RuntimeException("Invalid or Unsupported MMI Code");
    }
    else if ((this.mSc != null) && (this.mSc.equals("03")))
    {
      String str3 = this.mSib;
      String str4 = this.mSic;
      if ((isActivate()) || (isRegister()))
      {
        this.mAction = "**";
        if (this.mSia == null);
        for (String str5 = "AB"; str4.equals(this.mPwd); str5 = scToBarringFacility(this.mSia))
        {
          this.mPhone.mCi.changeBarringPassword(str5, str3, str4, obtainMessage(1, this));
          break label1218;
        }
        handlePasswordError(17039448);
      }
      else
      {
        throw new RuntimeException("Invalid or Unsupported MMI Code");
      }
    }
    else if ((this.mSc != null) && (this.mSc.equals("43")))
    {
      int j = siToServiceClass(this.mSia);
      if ((isActivate()) || (isDeactivate()))
        this.mPhone.mCi.setCallWaiting(isActivate(), j, obtainMessage(1, this));
      else if (isInterrogate())
        this.mPhone.mCi.queryCallWaiting(j, obtainMessage(5, this));
      else
        throw new RuntimeException("Invalid or Unsupported MMI Code");
    }
    else if (isPinPukCommand())
    {
      str1 = this.mSia;
      str2 = this.mSib;
      i = str2.length();
      if (isRegister())
      {
        if (str2.equals(this.mSic))
          break label1275;
        handlePasswordError(17039452);
        break label1218;
      }
    }
    while (true)
    {
      label908: handlePasswordError(17039453);
      label1218: label1219: label1269: label1275: 
      do
      {
        if ((this.mSc.equals("04")) && (this.mUiccApplication != null) && (this.mUiccApplication.getState() == IccCardApplicationStatus.AppState.APPSTATE_PUK))
        {
          handlePasswordError(17039455);
        }
        else if (this.mUiccApplication != null)
        {
          Rlog.d("GsmMmiCode", "process mmi service code using UiccApp sc=" + this.mSc);
          if (this.mSc.equals("04"))
            this.mUiccApplication.changeIccLockPassword(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("042"))
            this.mUiccApplication.changeIccFdnPassword(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("05"))
            this.mUiccApplication.supplyPuk(str1, str2, obtainMessage(1, this));
          else if (this.mSc.equals("052"))
            this.mUiccApplication.supplyPuk2(str1, str2, obtainMessage(1, this));
          else
            throw new RuntimeException("uicc unsupported service code=" + this.mSc);
        }
        else
        {
          throw new RuntimeException("No application mUiccApplicaiton is null");
          throw new RuntimeException("Ivalid register/action=" + this.mAction);
          if (this.mPoundString != null)
            sendUssd(this.mPoundString);
          else
            throw new RuntimeException("Invalid or Unsupported MMI Code");
        }
        return;
        if (((n == 0) || (n == 4)) && (((m & 0x1) != 0) || (m == 0)));
        for (i3 = 1; ; i3 = 0)
        {
          if ((i2 != 1) && (i2 != 3))
            break label1269;
          i4 = 1;
          break;
        }
        i4 = 0;
        break;
        if (i < 4)
          break label908;
      }
      while (i <= 8);
    }
  }

  void sendUssd(String paramString)
  {
    this.mIsPendingUSSD = true;
    this.mPhone.mCi.sendUSSD(paramString, obtainMessage(4, this));
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("GsmMmiCode {");
    localStringBuilder.append("State=" + getState());
    if (this.mAction != null)
      localStringBuilder.append(" action=" + this.mAction);
    if (this.mSc != null)
      localStringBuilder.append(" sc=" + this.mSc);
    if (this.mSia != null)
      localStringBuilder.append(" sia=" + this.mSia);
    if (this.mSib != null)
      localStringBuilder.append(" sib=" + this.mSib);
    if (this.mSic != null)
      localStringBuilder.append(" sic=" + this.mSic);
    if (this.mPoundString != null)
      localStringBuilder.append(" poundString=" + this.mPoundString);
    if (this.mDialingNumber != null)
      localStringBuilder.append(" dialingNumber=" + this.mDialingNumber);
    if (this.mPwd != null)
      localStringBuilder.append(" pwd=" + this.mPwd);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.gsm.GsmMmiCode
 * JD-Core Version:    0.6.2
 */