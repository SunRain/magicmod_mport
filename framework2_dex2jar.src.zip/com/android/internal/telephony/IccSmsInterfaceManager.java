package com.android.internal.telephony;

import android.app.AppOpsManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Handler;
import android.os.Message;
import android.os.ServiceManager;
import android.telephony.Rlog;
import android.util.Log;
import com.android.internal.telephony.cdma.CdmaSmsBroadcastConfigInfo;
import com.android.internal.telephony.gsm.SmsBroadcastConfigInfo;
import com.android.internal.telephony.uicc.IccFileHandler;
import com.android.internal.util.HexDump;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class IccSmsInterfaceManager extends ISms.Stub
{
  static final boolean DBG = true;
  private static final int EVENT_LOAD_DONE = 1;
  protected static final int EVENT_SET_BROADCAST_ACTIVATION_DONE = 3;
  protected static final int EVENT_SET_BROADCAST_CONFIG_DONE = 4;
  private static final int EVENT_UPDATE_DONE = 2;
  static final String LOG_TAG = "IccSmsInterfaceManager";
  private static final int SMS_CB_CODE_SCHEME_MAX = 255;
  private static final int SMS_CB_CODE_SCHEME_MIN;
  protected final AppOpsManager mAppOps;
  private CdmaBroadcastRangeManager mCdmaBroadcastRangeManager = new CdmaBroadcastRangeManager();
  private CellBroadcastRangeManager mCellBroadcastRangeManager = new CellBroadcastRangeManager();
  protected final Context mContext;
  protected SMSDispatcher mDispatcher;
  protected Handler mHandler = new Handler()
  {
    // ERROR //
    public void handleMessage(Message paramAnonymousMessage)
    {
      // Byte code:
      //   0: iconst_1
      //   1: istore_2
      //   2: aload_1
      //   3: getfield 23	android/os/Message:what	I
      //   6: tableswitch	default:+30 -> 36, 1:+101->107, 2:+31->37, 3:+235->241, 4:+235->241
      //   37: aload_1
      //   38: getfield 27	android/os/Message:obj	Ljava/lang/Object;
      //   41: checkcast 29	android/os/AsyncResult
      //   44: astore 11
      //   46: aload_0
      //   47: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   50: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   53: astore 12
      //   55: aload 12
      //   57: monitorenter
      //   58: aload_0
      //   59: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   62: astore 14
      //   64: aload 11
      //   66: getfield 36	android/os/AsyncResult:exception	Ljava/lang/Throwable;
      //   69: ifnonnull +33 -> 102
      //   72: aload 14
      //   74: iload_2
      //   75: putfield 40	com/android/internal/telephony/IccSmsInterfaceManager:mSuccess	Z
      //   78: aload_0
      //   79: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   82: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   85: invokevirtual 45	java/lang/Object:notifyAll	()V
      //   88: aload 12
      //   90: monitorexit
      //   91: goto -55 -> 36
      //   94: astore 13
      //   96: aload 12
      //   98: monitorexit
      //   99: aload 13
      //   101: athrow
      //   102: iconst_0
      //   103: istore_2
      //   104: goto -32 -> 72
      //   107: aload_1
      //   108: getfield 27	android/os/Message:obj	Ljava/lang/Object;
      //   111: checkcast 29	android/os/AsyncResult
      //   114: astore 7
      //   116: aload_0
      //   117: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   120: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   123: astore 8
      //   125: aload 8
      //   127: monitorenter
      //   128: aload 7
      //   130: getfield 36	android/os/AsyncResult:exception	Ljava/lang/Throwable;
      //   133: ifnonnull +65 -> 198
      //   136: aload_0
      //   137: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   140: aload_0
      //   141: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   144: aload 7
      //   146: getfield 48	android/os/AsyncResult:result	Ljava/lang/Object;
      //   149: checkcast 50	java/util/ArrayList
      //   152: invokevirtual 54	com/android/internal/telephony/IccSmsInterfaceManager:buildValidRawData	(Ljava/util/ArrayList;)Ljava/util/ArrayList;
      //   155: invokestatic 58	com/android/internal/telephony/IccSmsInterfaceManager:access$002	(Lcom/android/internal/telephony/IccSmsInterfaceManager;Ljava/util/List;)Ljava/util/List;
      //   158: pop
      //   159: aload_0
      //   160: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   163: aload 7
      //   165: getfield 48	android/os/AsyncResult:result	Ljava/lang/Object;
      //   168: checkcast 50	java/util/ArrayList
      //   171: invokevirtual 62	com/android/internal/telephony/IccSmsInterfaceManager:markMessagesAsRead	(Ljava/util/ArrayList;)V
      //   174: aload_0
      //   175: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   178: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   181: invokevirtual 45	java/lang/Object:notifyAll	()V
      //   184: aload 8
      //   186: monitorexit
      //   187: goto -151 -> 36
      //   190: astore 9
      //   192: aload 8
      //   194: monitorexit
      //   195: aload 9
      //   197: athrow
      //   198: ldc 64
      //   200: iconst_3
      //   201: invokestatic 70	android/telephony/Rlog:isLoggable	(Ljava/lang/String;I)Z
      //   204: ifeq +12 -> 216
      //   207: aload_0
      //   208: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   211: ldc 72
      //   213: invokevirtual 76	com/android/internal/telephony/IccSmsInterfaceManager:log	(Ljava/lang/String;)V
      //   216: aload_0
      //   217: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   220: invokestatic 80	com/android/internal/telephony/IccSmsInterfaceManager:access$000	(Lcom/android/internal/telephony/IccSmsInterfaceManager;)Ljava/util/List;
      //   223: ifnull -49 -> 174
      //   226: aload_0
      //   227: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   230: invokestatic 80	com/android/internal/telephony/IccSmsInterfaceManager:access$000	(Lcom/android/internal/telephony/IccSmsInterfaceManager;)Ljava/util/List;
      //   233: invokeinterface 85 1 0
      //   238: goto -64 -> 174
      //   241: aload_1
      //   242: getfield 27	android/os/Message:obj	Ljava/lang/Object;
      //   245: checkcast 29	android/os/AsyncResult
      //   248: astore_3
      //   249: aload_0
      //   250: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   253: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   256: astore 4
      //   258: aload 4
      //   260: monitorenter
      //   261: aload_0
      //   262: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   265: astore 6
      //   267: aload_3
      //   268: getfield 36	android/os/AsyncResult:exception	Ljava/lang/Throwable;
      //   271: ifnonnull +33 -> 304
      //   274: aload 6
      //   276: iload_2
      //   277: putfield 40	com/android/internal/telephony/IccSmsInterfaceManager:mSuccess	Z
      //   280: aload_0
      //   281: getfield 12	com/android/internal/telephony/IccSmsInterfaceManager$1:this$0	Lcom/android/internal/telephony/IccSmsInterfaceManager;
      //   284: getfield 32	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
      //   287: invokevirtual 45	java/lang/Object:notifyAll	()V
      //   290: aload 4
      //   292: monitorexit
      //   293: goto -257 -> 36
      //   296: astore 5
      //   298: aload 4
      //   300: monitorexit
      //   301: aload 5
      //   303: athrow
      //   304: iconst_0
      //   305: istore_2
      //   306: goto -32 -> 274
      //
      // Exception table:
      //   from	to	target	type
      //   58	99	94	finally
      //   128	195	190	finally
      //   198	238	190	finally
      //   261	301	296	finally
    }
  };
  protected final Object mLock = new Object();
  protected PhoneBase mPhone;
  private List<SmsRawData> mSms;
  protected boolean mSuccess;

  protected IccSmsInterfaceManager(PhoneBase paramPhoneBase)
  {
    this.mPhone = paramPhoneBase;
    this.mContext = paramPhoneBase.getContext();
    this.mAppOps = ((AppOpsManager)this.mContext.getSystemService("appops"));
    this.mDispatcher = new ImsSMSDispatcher(paramPhoneBase, paramPhoneBase.mSmsStorageMonitor, paramPhoneBase.mSmsUsageMonitor);
    if (ServiceManager.getService("isms") == null)
      ServiceManager.addService("isms", this);
  }

  private boolean setCdmaBroadcastActivation(boolean paramBoolean)
  {
    log("Calling setCdmaBroadcastActivation(" + paramBoolean + ")");
    synchronized (this.mLock)
    {
      Message localMessage = this.mHandler.obtainMessage(3);
      this.mSuccess = false;
      this.mPhone.mCi.setCdmaBroadcastActivation(paramBoolean, localMessage);
      try
      {
        this.mLock.wait();
        return this.mSuccess;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to set cdma broadcast activation");
      }
    }
  }

  private boolean setCdmaBroadcastConfig(CdmaSmsBroadcastConfigInfo[] paramArrayOfCdmaSmsBroadcastConfigInfo)
  {
    log("Calling setCdmaBroadcastConfig with " + paramArrayOfCdmaSmsBroadcastConfigInfo.length + " configurations");
    synchronized (this.mLock)
    {
      Message localMessage = this.mHandler.obtainMessage(4);
      this.mSuccess = false;
      this.mPhone.mCi.setCdmaBroadcastConfig(paramArrayOfCdmaSmsBroadcastConfigInfo, localMessage);
      try
      {
        this.mLock.wait();
        return this.mSuccess;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to set cdma broadcast config");
      }
    }
  }

  private boolean setCellBroadcastActivation(boolean paramBoolean)
  {
    log("Calling setCellBroadcastActivation(" + paramBoolean + ')');
    synchronized (this.mLock)
    {
      Message localMessage = this.mHandler.obtainMessage(3);
      this.mSuccess = false;
      this.mPhone.mCi.setGsmBroadcastActivation(paramBoolean, localMessage);
      try
      {
        this.mLock.wait();
        return this.mSuccess;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to set cell broadcast activation");
      }
    }
  }

  private boolean setCellBroadcastConfig(SmsBroadcastConfigInfo[] paramArrayOfSmsBroadcastConfigInfo)
  {
    log("Calling setGsmBroadcastConfig with " + paramArrayOfSmsBroadcastConfigInfo.length + " configurations");
    synchronized (this.mLock)
    {
      Message localMessage = this.mHandler.obtainMessage(4);
      this.mSuccess = false;
      this.mPhone.mCi.setGsmBroadcastConfig(paramArrayOfSmsBroadcastConfigInfo, localMessage);
      try
      {
        this.mLock.wait();
        return this.mSuccess;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to set cell broadcast config");
      }
    }
  }

  protected ArrayList<SmsRawData> buildValidRawData(ArrayList<byte[]> paramArrayList)
  {
    int i = paramArrayList.size();
    ArrayList localArrayList = new ArrayList(i);
    int j = 0;
    if (j < i)
    {
      if (((byte[])paramArrayList.get(j))[0] == 0)
        localArrayList.add(null);
      while (true)
      {
        j++;
        break;
        localArrayList.add(new SmsRawData((byte[])paramArrayList.get(j)));
      }
    }
    return localArrayList;
  }

  public boolean copyMessageToIccEf(String paramString, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    boolean bool = false;
    log("copyMessageToIccEf: status=" + paramInt + " ==> " + "pdu=(" + Arrays.toString(paramArrayOfByte1) + "), smsc=(" + Arrays.toString(paramArrayOfByte2) + ")");
    enforceReceiveAndSend("Copying message to Icc");
    if (this.mAppOps.noteOp(22, Binder.getCallingUid(), paramString) != 0);
    while (true)
    {
      return bool;
      Message localMessage;
      synchronized (this.mLock)
      {
        this.mSuccess = false;
        localMessage = this.mHandler.obtainMessage(2);
        if (1 == this.mPhone.getPhoneType())
          this.mPhone.mCi.writeSmsToSim(paramInt, IccUtils.bytesToHexString(paramArrayOfByte2), IccUtils.bytesToHexString(paramArrayOfByte1), localMessage);
      }
      try
      {
        while (true)
        {
          this.mLock.wait();
          bool = this.mSuccess;
          break;
          this.mPhone.mCi.writeSmsToRuim(paramInt, IccUtils.bytesToHexString(paramArrayOfByte1), localMessage);
        }
        localObject2 = finally;
        throw localObject2;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to update by index");
      }
    }
  }

  public boolean disableCdmaBroadcastRange(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    try
    {
      log("disableCdmaBroadcastRange");
      Context localContext = this.mPhone.getContext();
      localContext.enforceCallingPermission("android.permission.RECEIVE_SMS", "Disabling cell broadcast SMS");
      String str = localContext.getPackageManager().getNameForUid(Binder.getCallingUid());
      if (!this.mCdmaBroadcastRangeManager.disableRange(paramInt1, paramInt2, str))
        log("Failed to remove cdma broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
      while (true)
      {
        return bool;
        log("Removed cdma broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
        if (!this.mCdmaBroadcastRangeManager.isEmpty())
          bool = true;
        setCdmaBroadcastActivation(bool);
        bool = true;
      }
    }
    finally
    {
    }
  }

  public boolean disableCellBroadcast(int paramInt)
  {
    return disableCellBroadcastRange(paramInt, paramInt);
  }

  public boolean disableCellBroadcastRange(int paramInt1, int paramInt2)
  {
    if (1 == this.mPhone.getPhoneType());
    for (boolean bool = disableGsmBroadcastRange(paramInt1, paramInt2); ; bool = disableCdmaBroadcastRange(paramInt1, paramInt2))
      return bool;
  }

  public boolean disableGsmBroadcastRange(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    try
    {
      log("disableGsmBroadcastRange");
      Context localContext = this.mPhone.getContext();
      localContext.enforceCallingPermission("android.permission.RECEIVE_SMS", "Disabling cell broadcast SMS");
      String str = localContext.getPackageManager().getNameForUid(Binder.getCallingUid());
      if (!this.mCellBroadcastRangeManager.disableRange(paramInt1, paramInt2, str))
        log("Failed to remove cell broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
      while (true)
      {
        return bool;
        log("Removed cell broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
        if (!this.mCellBroadcastRangeManager.isEmpty())
          bool = true;
        setCellBroadcastActivation(bool);
        bool = true;
      }
    }
    finally
    {
    }
  }

  public boolean enableCdmaBroadcastRange(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    try
    {
      log("enableCdmaBroadcastRange");
      Context localContext = this.mPhone.getContext();
      localContext.enforceCallingPermission("android.permission.RECEIVE_SMS", "Enabling cdma broadcast SMS");
      String str = localContext.getPackageManager().getNameForUid(Binder.getCallingUid());
      if (!this.mCdmaBroadcastRangeManager.enableRange(paramInt1, paramInt2, str))
        log("Failed to add cdma broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
      while (true)
      {
        return bool;
        log("Added cdma broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
        if (!this.mCdmaBroadcastRangeManager.isEmpty())
          bool = true;
        setCdmaBroadcastActivation(bool);
        bool = true;
      }
    }
    finally
    {
    }
  }

  public boolean enableCellBroadcast(int paramInt)
  {
    return enableCellBroadcastRange(paramInt, paramInt);
  }

  public boolean enableCellBroadcastRange(int paramInt1, int paramInt2)
  {
    if (1 == this.mPhone.getPhoneType());
    for (boolean bool = enableGsmBroadcastRange(paramInt1, paramInt2); ; bool = enableCdmaBroadcastRange(paramInt1, paramInt2))
      return bool;
  }

  public boolean enableGsmBroadcastRange(int paramInt1, int paramInt2)
  {
    boolean bool = false;
    try
    {
      log("enableGsmBroadcastRange");
      Context localContext = this.mPhone.getContext();
      localContext.enforceCallingPermission("android.permission.RECEIVE_SMS", "Enabling cell broadcast SMS");
      String str = localContext.getPackageManager().getNameForUid(Binder.getCallingUid());
      if (!this.mCellBroadcastRangeManager.enableRange(paramInt1, paramInt2, str))
        log("Failed to add cell broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
      while (true)
      {
        return bool;
        log("Added cell broadcast subscription for MID range " + paramInt1 + " to " + paramInt2 + " from client " + str);
        if (!this.mCellBroadcastRangeManager.isEmpty())
          bool = true;
        setCellBroadcastActivation(bool);
        bool = true;
      }
    }
    finally
    {
    }
  }

  protected void enforceReceiveAndSend(String paramString)
  {
    this.mContext.enforceCallingPermission("android.permission.RECEIVE_SMS", paramString);
    this.mContext.enforceCallingPermission("android.permission.SEND_SMS", paramString);
  }

  // ERROR //
  public List<SmsRawData> getAllMessagesFromIccEf(String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 380
    //   4: invokevirtual 162	com/android/internal/telephony/IccSmsInterfaceManager:log	(Ljava/lang/String;)V
    //   7: aload_0
    //   8: getfield 79	com/android/internal/telephony/IccSmsInterfaceManager:mContext	Landroid/content/Context;
    //   11: ldc_w 293
    //   14: ldc_w 382
    //   17: invokevirtual 385	android/content/Context:enforceCallingOrSelfPermission	(Ljava/lang/String;Ljava/lang/String;)V
    //   20: aload_0
    //   21: getfield 91	com/android/internal/telephony/IccSmsInterfaceManager:mAppOps	Landroid/app/AppOpsManager;
    //   24: bipush 21
    //   26: invokestatic 266	android/os/Binder:getCallingUid	()I
    //   29: aload_1
    //   30: invokevirtual 270	android/app/AppOpsManager:noteOp	(IILjava/lang/String;)I
    //   33: ifeq +13 -> 46
    //   36: new 219	java/util/ArrayList
    //   39: dup
    //   40: invokespecial 386	java/util/ArrayList:<init>	()V
    //   43: astore_2
    //   44: aload_2
    //   45: areturn
    //   46: aload_0
    //   47: getfield 52	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
    //   50: astore_3
    //   51: aload_3
    //   52: monitorenter
    //   53: aload_0
    //   54: getfield 71	com/android/internal/telephony/IccSmsInterfaceManager:mPhone	Lcom/android/internal/telephony/PhoneBase;
    //   57: invokevirtual 390	com/android/internal/telephony/PhoneBase:getIccFileHandler	()Lcom/android/internal/telephony/uicc/IccFileHandler;
    //   60: astore 5
    //   62: aload 5
    //   64: ifnonnull +45 -> 109
    //   67: ldc 19
    //   69: ldc_w 392
    //   72: invokestatic 398	android/telephony/Rlog:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   75: pop
    //   76: aload_0
    //   77: getfield 122	com/android/internal/telephony/IccSmsInterfaceManager:mSms	Ljava/util/List;
    //   80: ifnull +29 -> 109
    //   83: aload_0
    //   84: getfield 122	com/android/internal/telephony/IccSmsInterfaceManager:mSms	Ljava/util/List;
    //   87: invokeinterface 403 1 0
    //   92: aload_0
    //   93: getfield 122	com/android/internal/telephony/IccSmsInterfaceManager:mSms	Ljava/util/List;
    //   96: astore_2
    //   97: aload_3
    //   98: monitorexit
    //   99: goto -55 -> 44
    //   102: astore 4
    //   104: aload_3
    //   105: monitorexit
    //   106: aload 4
    //   108: athrow
    //   109: aload 5
    //   111: sipush 28476
    //   114: aload_0
    //   115: getfield 69	com/android/internal/telephony/IccSmsInterfaceManager:mHandler	Landroid/os/Handler;
    //   118: iconst_1
    //   119: invokevirtual 168	android/os/Handler:obtainMessage	(I)Landroid/os/Message;
    //   122: invokevirtual 409	com/android/internal/telephony/uicc/IccFileHandler:loadEFLinearFixedAll	(ILandroid/os/Message;)V
    //   125: aload_0
    //   126: getfield 52	com/android/internal/telephony/IccSmsInterfaceManager:mLock	Ljava/lang/Object;
    //   129: invokevirtual 182	java/lang/Object:wait	()V
    //   132: aload_3
    //   133: monitorexit
    //   134: aload_0
    //   135: getfield 122	com/android/internal/telephony/IccSmsInterfaceManager:mSms	Ljava/util/List;
    //   138: astore_2
    //   139: goto -95 -> 44
    //   142: astore 6
    //   144: aload_0
    //   145: ldc_w 411
    //   148: invokevirtual 162	com/android/internal/telephony/IccSmsInterfaceManager:log	(Ljava/lang/String;)V
    //   151: goto -19 -> 132
    //
    // Exception table:
    //   from	to	target	type
    //   53	106	102	finally
    //   109	125	102	finally
    //   125	132	102	finally
    //   132	134	102	finally
    //   144	151	102	finally
    //   125	132	142	java/lang/InterruptedException
  }

  public String getImsSmsFormat()
  {
    return this.mDispatcher.getImsSmsFormat();
  }

  public int getPremiumSmsPermission(String paramString)
  {
    return this.mDispatcher.getPremiumSmsPermission(paramString);
  }

  public boolean isImsSmsSupported()
  {
    return this.mDispatcher.isIms();
  }

  protected void log(String paramString)
  {
    Log.d("IccSmsInterfaceManager", "[IccSmsInterfaceManager] " + paramString);
  }

  protected byte[] makeSmsRecordData(int paramInt, byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte['°'];
    arrayOfByte[0] = ((byte)(paramInt & 0x7));
    System.arraycopy(paramArrayOfByte, 0, arrayOfByte, 1, paramArrayOfByte.length);
    for (int i = 1 + paramArrayOfByte.length; i < 176; i++)
      arrayOfByte[i] = -1;
    return arrayOfByte;
  }

  protected void markMessagesAsRead(ArrayList<byte[]> paramArrayList)
  {
    if (paramArrayList == null);
    while (true)
    {
      return;
      IccFileHandler localIccFileHandler = this.mPhone.getIccFileHandler();
      if (localIccFileHandler == null)
      {
        if (Rlog.isLoggable("SMS", 3))
          log("markMessagesAsRead - aborting, no icc card present.");
      }
      else
      {
        int i = paramArrayList.size();
        for (int j = 0; j < i; j++)
        {
          byte[] arrayOfByte1 = (byte[])paramArrayList.get(j);
          if (arrayOfByte1[0] == 3)
          {
            int k = arrayOfByte1.length;
            byte[] arrayOfByte2 = new byte[k - 1];
            System.arraycopy(arrayOfByte1, 1, arrayOfByte2, 0, k - 1);
            byte[] arrayOfByte3 = makeSmsRecordData(1, arrayOfByte2);
            localIccFileHandler.updateEFLinearFixed(28476, j + 1, arrayOfByte3, null, null);
            if (Rlog.isLoggable("SMS", 3))
              log("SMS " + (j + 1) + " marked as read");
          }
        }
      }
    }
  }

  public void sendData(String paramString1, String paramString2, String paramString3, int paramInt, byte[] paramArrayOfByte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    this.mPhone.getContext().enforceCallingPermission("android.permission.SEND_SMS", "Sending SMS message");
    if (Rlog.isLoggable("SMS", 2))
      log("sendData: destAddr=" + paramString2 + " scAddr=" + paramString3 + " destPort=" + paramInt + " data='" + HexDump.toHexString(paramArrayOfByte) + "' sentIntent=" + paramPendingIntent1 + " deliveryIntent=" + paramPendingIntent2);
    if (this.mAppOps.noteOp(20, Binder.getCallingUid(), paramString1) != 0);
    while (true)
    {
      return;
      this.mDispatcher.sendData(paramString2, paramString3, paramInt, paramArrayOfByte, paramPendingIntent1, paramPendingIntent2);
    }
  }

  public void sendMultipartText(String paramString1, String paramString2, String paramString3, List<String> paramList, List<PendingIntent> paramList1, List<PendingIntent> paramList2)
  {
    this.mPhone.getContext().enforceCallingPermission("android.permission.SEND_SMS", "Sending SMS message");
    if (Rlog.isLoggable("SMS", 2))
    {
      int i = 0;
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        StringBuilder localStringBuilder = new StringBuilder().append("sendMultipartText: destAddr=").append(paramString2).append(", srAddr=").append(paramString3).append(", part[");
        int j = i + 1;
        log(i + "]=" + str);
        i = j;
      }
    }
    if (this.mAppOps.noteOp(20, Binder.getCallingUid(), paramString1) != 0);
    while (true)
    {
      return;
      this.mDispatcher.sendMultipartText(paramString2, paramString3, (ArrayList)paramList, (ArrayList)paramList1, (ArrayList)paramList2);
    }
  }

  public void sendText(String paramString1, String paramString2, String paramString3, String paramString4, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2)
  {
    this.mPhone.getContext().enforceCallingPermission("android.permission.SEND_SMS", "Sending SMS message");
    if (Rlog.isLoggable("SMS", 2))
      log("sendText: destAddr=" + paramString2 + " scAddr=" + paramString3 + " text='" + paramString4 + "' sentIntent=" + paramPendingIntent1 + " deliveryIntent=" + paramPendingIntent2);
    if (this.mAppOps.noteOp(20, Binder.getCallingUid(), paramString1) != 0);
    while (true)
    {
      return;
      this.mDispatcher.sendText(paramString2, paramString3, paramString4, paramPendingIntent1, paramPendingIntent2);
    }
  }

  public void setPremiumSmsPermission(String paramString, int paramInt)
  {
    this.mDispatcher.setPremiumSmsPermission(paramString, paramInt);
  }

  public boolean updateMessageOnIccEf(String paramString, int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    boolean bool = false;
    log("updateMessageOnIccEf: index=" + paramInt1 + " status=" + paramInt2 + " ==> " + "(" + Arrays.toString(paramArrayOfByte) + ")");
    enforceReceiveAndSend("Updating message on Icc");
    if (this.mAppOps.noteOp(22, Binder.getCallingUid(), paramString) != 0);
    while (true)
    {
      return bool;
      Message localMessage;
      synchronized (this.mLock)
      {
        this.mSuccess = false;
        localMessage = this.mHandler.obtainMessage(2);
        if (paramInt2 == 0)
          if (1 == this.mPhone.getPhoneType())
            this.mPhone.mCi.deleteSmsOnSim(paramInt1, localMessage);
      }
      try
      {
        while (true)
        {
          this.mLock.wait();
          bool = this.mSuccess;
          break;
          this.mPhone.mCi.deleteSmsOnRuim(paramInt1, localMessage);
          continue;
          localObject2 = finally;
          throw localObject2;
          IccFileHandler localIccFileHandler = this.mPhone.getIccFileHandler();
          if (localIccFileHandler == null)
          {
            localMessage.recycle();
            bool = this.mSuccess;
            break;
          }
          localIccFileHandler.updateEFLinearFixed(28476, paramInt1, makeSmsRecordData(paramInt2, paramArrayOfByte), null, localMessage);
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          log("interrupted while trying to update by index");
      }
    }
  }

  protected void updatePhoneObject(PhoneBase paramPhoneBase)
  {
    this.mPhone = paramPhoneBase;
    this.mDispatcher.updatePhoneObject(paramPhoneBase);
  }

  class CdmaBroadcastRangeManager extends IntRangeManager
  {
    private ArrayList<CdmaSmsBroadcastConfigInfo> mConfigList = new ArrayList();

    CdmaBroadcastRangeManager()
    {
    }

    protected void addRange(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.mConfigList.add(new CdmaSmsBroadcastConfigInfo(paramInt1, paramInt2, 1, paramBoolean));
    }

    protected boolean finishUpdate()
    {
      if (this.mConfigList.isEmpty());
      CdmaSmsBroadcastConfigInfo[] arrayOfCdmaSmsBroadcastConfigInfo;
      for (boolean bool = true; ; bool = IccSmsInterfaceManager.this.setCdmaBroadcastConfig(arrayOfCdmaSmsBroadcastConfigInfo))
      {
        return bool;
        arrayOfCdmaSmsBroadcastConfigInfo = (CdmaSmsBroadcastConfigInfo[])this.mConfigList.toArray(new CdmaSmsBroadcastConfigInfo[this.mConfigList.size()]);
      }
    }

    protected void startUpdate()
    {
      this.mConfigList.clear();
    }
  }

  class CellBroadcastRangeManager extends IntRangeManager
  {
    private ArrayList<SmsBroadcastConfigInfo> mConfigList = new ArrayList();

    CellBroadcastRangeManager()
    {
    }

    protected void addRange(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.mConfigList.add(new SmsBroadcastConfigInfo(paramInt1, paramInt2, 0, 255, paramBoolean));
    }

    protected boolean finishUpdate()
    {
      if (this.mConfigList.isEmpty());
      SmsBroadcastConfigInfo[] arrayOfSmsBroadcastConfigInfo;
      for (boolean bool = true; ; bool = IccSmsInterfaceManager.this.setCellBroadcastConfig(arrayOfSmsBroadcastConfigInfo))
      {
        return bool;
        arrayOfSmsBroadcastConfigInfo = (SmsBroadcastConfigInfo[])this.mConfigList.toArray(new SmsBroadcastConfigInfo[this.mConfigList.size()]);
      }
    }

    protected void startUpdate()
    {
      this.mConfigList.clear();
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.internal.telephony.IccSmsInterfaceManager
 * JD-Core Version:    0.6.2
 */