package com.android.server.sip;

import android.net.sip.ISipSession;
import android.net.sip.ISipSession.Stub;
import android.net.sip.ISipSessionListener;
import android.net.sip.SipProfile;
import android.net.sip.SipProfile.Builder;
import android.net.sip.SipSession.State;
import android.net.sip.SipSessionAdapter;
import android.telephony.Rlog;
import android.text.TextUtils;
import gov.nist.javax.sip.clientauthutils.AccountManager;
import gov.nist.javax.sip.clientauthutils.UserCredentials;
import gov.nist.javax.sip.header.ProxyAuthenticate;
import gov.nist.javax.sip.header.StatusLine;
import gov.nist.javax.sip.header.WWWAuthenticate;
import gov.nist.javax.sip.header.extensions.ReferredByHeader;
import gov.nist.javax.sip.header.extensions.ReplacesHeader;
import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.Collection;
import java.util.EventObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.sip.ClientTransaction;
import javax.sip.Dialog;
import javax.sip.DialogTerminatedEvent;
import javax.sip.IOExceptionEvent;
import javax.sip.ObjectInUseException;
import javax.sip.RequestEvent;
import javax.sip.ResponseEvent;
import javax.sip.ServerTransaction;
import javax.sip.SipException;
import javax.sip.SipListener;
import javax.sip.SipStack;
import javax.sip.TimeoutEvent;
import javax.sip.Transaction;
import javax.sip.TransactionTerminatedEvent;
import javax.sip.address.Address;
import javax.sip.address.SipURI;
import javax.sip.header.CSeqHeader;
import javax.sip.header.ContactHeader;
import javax.sip.header.ExpiresHeader;
import javax.sip.header.HeaderAddress;
import javax.sip.header.ReferToHeader;
import javax.sip.header.ViaHeader;
import javax.sip.message.Message;
import javax.sip.message.Request;
import javax.sip.message.Response;

class SipSessionGroup
  implements SipListener
{
  private static final String ANONYMOUS = "anonymous";
  private static final int CANCEL_CALL_TIMER = 3;
  private static final boolean DBG = false;
  private static final boolean DBG_PING = false;
  private static final EventObject DEREGISTER = new EventObject("Deregister");
  private static final EventObject END_CALL = new EventObject("End call");
  private static final int END_CALL_TIMER = 3;
  private static final int EXPIRY_TIME = 3600;
  private static final int INCALL_KEEPALIVE_INTERVAL = 10;
  private static final int KEEPALIVE_TIMEOUT = 5;
  private static final String TAG = "SipSession";
  private static final String THREAD_POOL_SIZE = "1";
  private static final long WAKE_LOCK_HOLDING_TIME = 500L;
  private SipSessionImpl mCallReceiverSession;
  private String mExternalIp;
  private int mExternalPort;
  private String mLocalIp;
  private final SipProfile mLocalProfile;
  private final String mPassword;
  private Map<String, SipSessionImpl> mSessionMap = new HashMap();
  private SipHelper mSipHelper;
  private SipStack mSipStack;
  private SipWakeLock mWakeLock;
  private SipWakeupTimer mWakeupTimer;

  public SipSessionGroup(SipProfile paramSipProfile, String paramString, SipWakeupTimer paramSipWakeupTimer, SipWakeLock paramSipWakeLock)
    throws SipException
  {
    this.mLocalProfile = paramSipProfile;
    this.mPassword = paramString;
    this.mWakeupTimer = paramSipWakeupTimer;
    this.mWakeLock = paramSipWakeLock;
    reset();
  }

  private void addSipSession(SipSessionImpl paramSipSessionImpl)
  {
    try
    {
      removeSipSession(paramSipSessionImpl);
      String str = paramSipSessionImpl.getCallId();
      this.mSessionMap.put(str, paramSipSessionImpl);
      if (isLoggable(paramSipSessionImpl))
      {
        Iterator localIterator = this.mSessionMap.keySet().iterator();
        while (localIterator.hasNext())
          ((String)localIterator.next());
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private SipSessionImpl createNewSession(RequestEvent paramRequestEvent, ISipSessionListener paramISipSessionListener, ServerTransaction paramServerTransaction, int paramInt)
    throws SipException
  {
    SipSessionImpl localSipSessionImpl = new SipSessionImpl(paramISipSessionListener);
    localSipSessionImpl.mServerTransaction = paramServerTransaction;
    localSipSessionImpl.mState = paramInt;
    localSipSessionImpl.mDialog = localSipSessionImpl.mServerTransaction.getDialog();
    localSipSessionImpl.mInviteReceived = paramRequestEvent;
    localSipSessionImpl.mPeerProfile = createPeerProfile((HeaderAddress)paramRequestEvent.getRequest().getHeader("From"));
    localSipSessionImpl.mPeerSessionDescription = extractContent(paramRequestEvent.getRequest());
    return localSipSessionImpl;
  }

  private static SipProfile createPeerProfile(HeaderAddress paramHeaderAddress)
    throws SipException
  {
    try
    {
      Address localAddress = paramHeaderAddress.getAddress();
      SipURI localSipURI = (SipURI)localAddress.getURI();
      String str = localSipURI.getUser();
      if (str == null)
        str = "anonymous";
      int i = localSipURI.getPort();
      SipProfile.Builder localBuilder = new SipProfile.Builder(str, localSipURI.getHost()).setDisplayName(localAddress.getDisplayName());
      if (i > 0)
        localBuilder.setPort(i);
      SipProfile localSipProfile = localBuilder.build();
      return localSipProfile;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw new SipException("createPeerProfile()", localIllegalArgumentException);
    }
    catch (ParseException localParseException)
    {
      throw new SipException("createPeerProfile()", localParseException);
    }
  }

  private static boolean expectResponse(String paramString, EventObject paramEventObject)
  {
    if ((paramEventObject instanceof ResponseEvent));
    for (boolean bool = paramString.equalsIgnoreCase(getCseqMethod(((ResponseEvent)paramEventObject).getResponse())); ; bool = false)
      return bool;
  }

  private String extractContent(Message paramMessage)
  {
    byte[] arrayOfByte = paramMessage.getRawContent();
    String str;
    if (arrayOfByte != null)
      try
      {
        if ((paramMessage instanceof SIPMessage))
          str = ((SIPMessage)paramMessage).getMessageContent();
        else
          str = new String(arrayOfByte, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    else
      str = null;
    return str;
  }

  private void extractExternalAddress(ResponseEvent paramResponseEvent)
  {
    ViaHeader localViaHeader = (ViaHeader)paramResponseEvent.getResponse().getHeader("Via");
    if (localViaHeader == null);
    while (true)
    {
      return;
      int i = localViaHeader.getRPort();
      String str = localViaHeader.getReceived();
      if ((i > 0) && (str != null))
      {
        this.mExternalIp = str;
        this.mExternalPort = i;
      }
    }
  }

  private static String getCseqMethod(Message paramMessage)
  {
    return ((CSeqHeader)paramMessage.getHeader("CSeq")).getMethod();
  }

  private Throwable getRootCause(Throwable paramThrowable)
  {
    for (Throwable localThrowable = paramThrowable.getCause(); localThrowable != null; localThrowable = paramThrowable.getCause())
      paramThrowable = localThrowable;
    return paramThrowable;
  }

  private SipSessionImpl getSipSession(EventObject paramEventObject)
  {
    try
    {
      String str = SipHelper.getCallId(paramEventObject);
      SipSessionImpl localSipSessionImpl = (SipSessionImpl)this.mSessionMap.get(str);
      if ((localSipSessionImpl != null) && (isLoggable(localSipSessionImpl)))
      {
        Iterator localIterator = this.mSessionMap.keySet().iterator();
        while (localIterator.hasNext())
          ((String)localIterator.next());
      }
      if (localSipSessionImpl != null);
      while (true)
      {
        return localSipSessionImpl;
        localSipSessionImpl = this.mCallReceiverSession;
      }
    }
    finally
    {
    }
  }

  private String getStackName()
  {
    return "stack" + System.currentTimeMillis();
  }

  private static boolean isLoggable(SipSessionImpl paramSipSessionImpl)
  {
    if (paramSipSessionImpl != null)
      switch (paramSipSessionImpl.mState)
      {
      case 9:
      }
    return false;
  }

  // ERROR //
  private static boolean isLoggable(SipSessionImpl paramSipSessionImpl, EventObject paramEventObject)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic 201	com/android/server/sip/SipSessionGroup:isLoggable	(Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;)Z
    //   4: ifne +5 -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_1
    //   10: ifnull -3 -> 7
    //   13: aload_1
    //   14: instanceof 321
    //   17: ifeq +30 -> 47
    //   20: ldc_w 413
    //   23: aload_1
    //   24: checkcast 321	javax/sip/ResponseEvent
    //   27: invokevirtual 325	javax/sip/ResponseEvent:getResponse	()Ljavax/sip/message/Response;
    //   30: ldc_w 365
    //   33: invokeinterface 355 2 0
    //   38: invokevirtual 417	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   41: ifeq -34 -> 7
    //   44: goto -37 -> 7
    //   47: aload_1
    //   48: instanceof 249
    //   51: ifeq -44 -> 7
    //   54: ldc_w 413
    //   57: aload_1
    //   58: invokestatic 186	com/android/server/sip/SipSessionGroup:isRequestEvent	(Ljava/lang/String;Ljava/util/EventObject;)Z
    //   61: ifeq -54 -> 7
    //   64: goto -57 -> 7
  }

  private static boolean isLoggable(EventObject paramEventObject)
  {
    return isLoggable(null, paramEventObject);
  }

  private static boolean isRequestEvent(String paramString, EventObject paramEventObject)
  {
    try
    {
      if ((paramEventObject instanceof RequestEvent))
      {
        boolean bool2 = paramString.equals(((RequestEvent)paramEventObject).getRequest().getMethod());
        bool1 = bool2;
        return bool1;
      }
    }
    catch (Throwable localThrowable)
    {
      while (true)
        boolean bool1 = false;
    }
  }

  private void log(String paramString)
  {
    Rlog.d("SipSession", paramString);
  }

  private static String logEvt(EventObject paramEventObject)
  {
    String str;
    if ((paramEventObject instanceof RequestEvent))
      str = ((RequestEvent)paramEventObject).getRequest().toString();
    while (true)
    {
      return str;
      if ((paramEventObject instanceof ResponseEvent))
        str = ((ResponseEvent)paramEventObject).getResponse().toString();
      else
        str = paramEventObject.toString();
    }
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e("SipSession", paramString, paramThrowable);
  }

  private void process(EventObject paramEventObject)
  {
    try
    {
      SipSessionImpl localSipSessionImpl = getSipSession(paramEventObject);
      try
      {
        boolean bool = isLoggable(localSipSessionImpl, paramEventObject);
        if ((localSipSessionImpl != null) && (localSipSessionImpl.process(paramEventObject)));
        for (int i = 1; ; i = 0)
        {
          if ((bool) && (i != 0))
            log("process: event new state after: " + SipSession.State.toString(localSipSessionImpl.mState));
          return;
        }
      }
      catch (Throwable localThrowable)
      {
        while (true)
        {
          loge("process: error event=" + paramEventObject, getRootCause(localThrowable));
          localSipSessionImpl.onError(localThrowable);
        }
      }
    }
    finally
    {
    }
  }

  private void removeSipSession(SipSessionImpl paramSipSessionImpl)
  {
    while (true)
    {
      try
      {
        SipSessionImpl localSipSessionImpl1 = this.mCallReceiverSession;
        if (paramSipSessionImpl == localSipSessionImpl1)
          return;
        String str1 = paramSipSessionImpl.getCallId();
        SipSessionImpl localSipSessionImpl2 = (SipSessionImpl)this.mSessionMap.remove(str1);
        Iterator localIterator1;
        if ((localSipSessionImpl2 != null) && (localSipSessionImpl2 != paramSipSessionImpl))
        {
          this.mSessionMap.put(str1, localSipSessionImpl2);
          Iterator localIterator2 = this.mSessionMap.entrySet().iterator();
          if (localIterator2.hasNext())
          {
            Map.Entry localEntry = (Map.Entry)localIterator2.next();
            if (localEntry.getValue() != localSipSessionImpl2)
              continue;
            String str2 = (String)localEntry.getKey();
            this.mSessionMap.remove(str2);
            continue;
          }
        }
      }
      finally
      {
      }
      if ((localSipSessionImpl2 != null) && (isLoggable(localSipSessionImpl2)))
      {
        localIterator1 = this.mSessionMap.keySet().iterator();
        while (localIterator1.hasNext())
          ((String)localIterator1.next());
      }
    }
  }

  public void close()
  {
    try
    {
      onConnectivityChanged();
      this.mSessionMap.clear();
      closeToNotReceiveCalls();
      if (this.mSipStack != null)
      {
        this.mSipStack.stop();
        this.mSipStack = null;
        this.mSipHelper = null;
      }
      resetExternalAddress();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void closeToNotReceiveCalls()
  {
    try
    {
      this.mCallReceiverSession = null;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  boolean containsSession(String paramString)
  {
    try
    {
      boolean bool = this.mSessionMap.containsKey(paramString);
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public ISipSession createSession(ISipSessionListener paramISipSessionListener)
  {
    if (isClosed());
    for (Object localObject = null; ; localObject = new SipSessionImpl(paramISipSessionListener))
      return localObject;
  }

  public SipProfile getLocalProfile()
  {
    return this.mLocalProfile;
  }

  public String getLocalProfileUri()
  {
    return this.mLocalProfile.getUriString();
  }

  public boolean isClosed()
  {
    try
    {
      SipStack localSipStack = this.mSipStack;
      if (localSipStack == null)
      {
        bool = true;
        return bool;
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  void onConnectivityChanged()
  {
    try
    {
      SipSessionImpl[] arrayOfSipSessionImpl = (SipSessionImpl[])this.mSessionMap.values().toArray(new SipSessionImpl[this.mSessionMap.size()]);
      int i = arrayOfSipSessionImpl.length;
      for (int j = 0; j < i; j++)
        arrayOfSipSessionImpl[j].onError(-10, "data connection lost");
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void openToReceiveCalls(ISipSessionListener paramISipSessionListener)
  {
    try
    {
      if (this.mCallReceiverSession == null)
        this.mCallReceiverSession = new SipSessionCallReceiverImpl(paramISipSessionListener);
      while (true)
      {
        return;
        this.mCallReceiverSession.setListener(paramISipSessionListener);
      }
    }
    finally
    {
    }
  }

  public void processDialogTerminated(DialogTerminatedEvent paramDialogTerminatedEvent)
  {
    process(paramDialogTerminatedEvent);
  }

  public void processIOException(IOExceptionEvent paramIOExceptionEvent)
  {
    process(paramIOExceptionEvent);
  }

  public void processRequest(RequestEvent paramRequestEvent)
  {
    if (isRequestEvent("INVITE", paramRequestEvent))
      this.mWakeLock.acquire(500L);
    process(paramRequestEvent);
  }

  public void processResponse(ResponseEvent paramResponseEvent)
  {
    process(paramResponseEvent);
  }

  public void processTimeout(TimeoutEvent paramTimeoutEvent)
  {
    process(paramTimeoutEvent);
  }

  public void processTransactionTerminated(TransactionTerminatedEvent paramTransactionTerminatedEvent)
  {
    process(paramTransactionTerminatedEvent);
  }

  // ERROR //
  void reset()
    throws SipException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 560	java/util/Properties
    //   5: dup
    //   6: invokespecial 561	java/util/Properties:<init>	()V
    //   9: astore_1
    //   10: aload_0
    //   11: getfield 84	com/android/server/sip/SipSessionGroup:mLocalProfile	Landroid/net/sip/SipProfile;
    //   14: invokevirtual 564	android/net/sip/SipProfile:getProtocol	()Ljava/lang/String;
    //   17: astore_3
    //   18: aload_0
    //   19: getfield 84	com/android/server/sip/SipSessionGroup:mLocalProfile	Landroid/net/sip/SipProfile;
    //   22: invokevirtual 565	android/net/sip/SipProfile:getPort	()I
    //   25: istore 4
    //   27: aload_0
    //   28: getfield 84	com/android/server/sip/SipSessionGroup:mLocalProfile	Landroid/net/sip/SipProfile;
    //   31: invokevirtual 568	android/net/sip/SipProfile:getProxyAddress	()Ljava/lang/String;
    //   34: astore 5
    //   36: aload 5
    //   38: invokestatic 574	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   41: ifne +174 -> 215
    //   44: aload_1
    //   45: ldc_w 576
    //   48: new 392	java/lang/StringBuilder
    //   51: dup
    //   52: invokespecial 393	java/lang/StringBuilder:<init>	()V
    //   55: aload 5
    //   57: invokevirtual 399	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: bipush 58
    //   62: invokevirtual 579	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   65: iload 4
    //   67: invokevirtual 582	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   70: bipush 47
    //   72: invokevirtual 579	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   75: aload_3
    //   76: invokevirtual 399	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: invokevirtual 411	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   82: invokevirtual 586	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    //   85: pop
    //   86: aload 5
    //   88: ldc_w 588
    //   91: invokevirtual 591	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   94: ifeq +33 -> 127
    //   97: aload 5
    //   99: ldc_w 593
    //   102: invokevirtual 596	java/lang/String:endsWith	(Ljava/lang/String;)Z
    //   105: ifeq +22 -> 127
    //   108: aload 5
    //   110: iconst_1
    //   111: iconst_m1
    //   112: aload 5
    //   114: invokevirtual 599	java/lang/String:length	()I
    //   117: iadd
    //   118: invokevirtual 603	java/lang/String:substring	(II)Ljava/lang/String;
    //   121: astore 19
    //   123: aload 19
    //   125: astore 5
    //   127: aconst_null
    //   128: astore 7
    //   130: aload 5
    //   132: invokestatic 609	java/net/InetAddress:getAllByName	(Ljava/lang/String;)[Ljava/net/InetAddress;
    //   135: astore 14
    //   137: aload 14
    //   139: arraylength
    //   140: istore 15
    //   142: iconst_0
    //   143: istore 16
    //   145: iload 16
    //   147: iload 15
    //   149: if_icmpge +58 -> 207
    //   152: aload 14
    //   154: iload 16
    //   156: aaload
    //   157: astore 17
    //   159: new 611	java/net/DatagramSocket
    //   162: dup
    //   163: invokespecial 612	java/net/DatagramSocket:<init>	()V
    //   166: astore 18
    //   168: aload 18
    //   170: aload 17
    //   172: iload 4
    //   174: invokevirtual 616	java/net/DatagramSocket:connect	(Ljava/net/InetAddress;I)V
    //   177: aload 18
    //   179: invokevirtual 619	java/net/DatagramSocket:isConnected	()Z
    //   182: ifeq +49 -> 231
    //   185: aload 18
    //   187: invokevirtual 623	java/net/DatagramSocket:getLocalAddress	()Ljava/net/InetAddress;
    //   190: invokevirtual 626	java/net/InetAddress:getHostAddress	()Ljava/lang/String;
    //   193: astore 7
    //   195: aload 18
    //   197: invokevirtual 629	java/net/DatagramSocket:getLocalPort	()I
    //   200: istore 4
    //   202: aload 18
    //   204: invokevirtual 631	java/net/DatagramSocket:close	()V
    //   207: aload 7
    //   209: ifnonnull +33 -> 242
    //   212: aload_0
    //   213: monitorexit
    //   214: return
    //   215: aload_0
    //   216: getfield 84	com/android/server/sip/SipSessionGroup:mLocalProfile	Landroid/net/sip/SipProfile;
    //   219: invokevirtual 634	android/net/sip/SipProfile:getSipDomain	()Ljava/lang/String;
    //   222: astore 6
    //   224: aload 6
    //   226: astore 5
    //   228: goto -142 -> 86
    //   231: aload 18
    //   233: invokevirtual 631	java/net/DatagramSocket:close	()V
    //   236: iinc 16 1
    //   239: goto -94 -> 145
    //   242: aload_0
    //   243: invokevirtual 635	com/android/server/sip/SipSessionGroup:close	()V
    //   246: aload_0
    //   247: aload 7
    //   249: putfield 109	com/android/server/sip/SipSessionGroup:mLocalIp	Ljava/lang/String;
    //   252: aload_1
    //   253: ldc_w 637
    //   256: aload_0
    //   257: invokespecial 639	com/android/server/sip/SipSessionGroup:getStackName	()Ljava/lang/String;
    //   260: invokevirtual 586	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    //   263: pop
    //   264: aload_1
    //   265: ldc_w 641
    //   268: ldc 33
    //   270: invokevirtual 586	java/util/Properties:setProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    //   273: pop
    //   274: aload_0
    //   275: invokestatic 647	javax/sip/SipFactory:getInstance	()Ljavax/sip/SipFactory;
    //   278: aload_1
    //   279: invokevirtual 651	javax/sip/SipFactory:createSipStack	(Ljava/util/Properties;)Ljavax/sip/SipStack;
    //   282: putfield 482	com/android/server/sip/SipSessionGroup:mSipStack	Ljavax/sip/SipStack;
    //   285: aload_0
    //   286: getfield 482	com/android/server/sip/SipSessionGroup:mSipStack	Ljavax/sip/SipStack;
    //   289: aload_0
    //   290: getfield 482	com/android/server/sip/SipSessionGroup:mSipStack	Ljavax/sip/SipStack;
    //   293: aload 7
    //   295: iload 4
    //   297: aload_3
    //   298: invokeinterface 655 4 0
    //   303: invokeinterface 659 2 0
    //   308: astore 13
    //   310: aload 13
    //   312: aload_0
    //   313: invokeinterface 665 2 0
    //   318: aload_0
    //   319: new 381	com/android/server/sip/SipHelper
    //   322: dup
    //   323: aload_0
    //   324: getfield 482	com/android/server/sip/SipSessionGroup:mSipStack	Ljavax/sip/SipStack;
    //   327: aload 13
    //   329: invokespecial 668	com/android/server/sip/SipHelper:<init>	(Ljavax/sip/SipStack;Ljavax/sip/SipProvider;)V
    //   332: putfield 163	com/android/server/sip/SipSessionGroup:mSipHelper	Lcom/android/server/sip/SipHelper;
    //   335: aload_0
    //   336: getfield 482	com/android/server/sip/SipSessionGroup:mSipStack	Ljavax/sip/SipStack;
    //   339: invokeinterface 671 1 0
    //   344: goto -132 -> 212
    //   347: astore_2
    //   348: aload_0
    //   349: monitorexit
    //   350: aload_2
    //   351: athrow
    //   352: astore 12
    //   354: aload 12
    //   356: athrow
    //   357: astore 11
    //   359: new 75	javax/sip/SipException
    //   362: dup
    //   363: ldc_w 673
    //   366: aload 11
    //   368: invokespecial 319	javax/sip/SipException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   371: athrow
    //   372: astore 8
    //   374: goto -167 -> 207
    //
    // Exception table:
    //   from	to	target	type
    //   2	123	347	finally
    //   130	207	347	finally
    //   215	224	347	finally
    //   231	236	347	finally
    //   242	285	347	finally
    //   285	335	347	finally
    //   335	344	347	finally
    //   354	372	347	finally
    //   285	335	352	javax/sip/SipException
    //   285	335	357	java/lang/Exception
    //   130	207	372	java/lang/Exception
    //   231	236	372	java/lang/Exception
  }

  void resetExternalAddress()
  {
    try
    {
      this.mExternalIp = null;
      this.mExternalPort = 0;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void setWakeupTimer(SipWakeupTimer paramSipWakeupTimer)
  {
    this.mWakeupTimer = paramSipWakeupTimer;
  }

  static abstract interface KeepAliveProcessCallback
  {
    public abstract void onError(int paramInt, String paramString);

    public abstract void onResponse(boolean paramBoolean);
  }

  static class KeepAliveProcessCallbackProxy
    implements SipSessionGroup.KeepAliveProcessCallback
  {
    private static final String KAPCP_TAG = "KeepAliveProcessCallbackProxy";
    private SipSessionGroup.KeepAliveProcessCallback mCallback;

    KeepAliveProcessCallbackProxy(SipSessionGroup.KeepAliveProcessCallback paramKeepAliveProcessCallback)
    {
      this.mCallback = paramKeepAliveProcessCallback;
    }

    private void loge(String paramString, Throwable paramThrowable)
    {
      Rlog.e("KeepAliveProcessCallbackProxy", paramString, paramThrowable);
    }

    private void proxy(Runnable paramRunnable)
    {
      new Thread(paramRunnable, "SIP-KeepAliveProcessCallbackThread").start();
    }

    public void onError(final int paramInt, final String paramString)
    {
      if (this.mCallback == null);
      while (true)
      {
        return;
        proxy(new Runnable()
        {
          public void run()
          {
            try
            {
              SipSessionGroup.KeepAliveProcessCallbackProxy.this.mCallback.onError(paramInt, paramString);
              return;
            }
            catch (Throwable localThrowable)
            {
              while (true)
                SipSessionGroup.KeepAliveProcessCallbackProxy.this.loge("onError", localThrowable);
            }
          }
        });
      }
    }

    public void onResponse(final boolean paramBoolean)
    {
      if (this.mCallback == null);
      while (true)
      {
        return;
        proxy(new Runnable()
        {
          public void run()
          {
            try
            {
              SipSessionGroup.KeepAliveProcessCallbackProxy.this.mCallback.onResponse(paramBoolean);
              return;
            }
            catch (Throwable localThrowable)
            {
              while (true)
                SipSessionGroup.KeepAliveProcessCallbackProxy.this.loge("onResponse", localThrowable);
            }
          }
        });
      }
    }
  }

  private class MakeCallCommand extends EventObject
  {
    private String mSessionDescription;
    private int mTimeout;

    public MakeCallCommand(SipProfile paramString, String paramInt, int arg4)
    {
      super();
      this.mSessionDescription = paramInt;
      int i;
      this.mTimeout = i;
    }

    public SipProfile getPeerProfile()
    {
      return (SipProfile)getSource();
    }

    public String getSessionDescription()
    {
      return this.mSessionDescription;
    }

    public int getTimeout()
    {
      return this.mTimeout;
    }
  }

  private class RegisterCommand extends EventObject
  {
    private int mDuration;

    public RegisterCommand(int arg2)
    {
      super();
      int i;
      this.mDuration = i;
    }

    public int getDuration()
    {
      return this.mDuration;
    }
  }

  private class SipSessionCallReceiverImpl extends SipSessionGroup.SipSessionImpl
  {
    private static final boolean SSCRI_DBG = true;
    private static final String SSCRI_TAG = "SipSessionCallReceiverImpl";

    public SipSessionCallReceiverImpl(ISipSessionListener arg2)
    {
      super(localISipSessionListener);
    }

    private void log(String paramString)
    {
      Rlog.d("SipSessionCallReceiverImpl", paramString);
    }

    private int processInviteWithReplaces(RequestEvent paramRequestEvent, ReplacesHeader paramReplacesHeader)
    {
      int i = 481;
      String str = paramReplacesHeader.getCallId();
      SipSessionGroup.SipSessionImpl localSipSessionImpl = (SipSessionGroup.SipSessionImpl)SipSessionGroup.this.mSessionMap.get(str);
      if (localSipSessionImpl == null);
      while (true)
      {
        return i;
        Dialog localDialog = localSipSessionImpl.mDialog;
        if (localDialog == null)
        {
          i = 603;
        }
        else if ((localDialog.getLocalTag().equals(paramReplacesHeader.getToTag())) && (localDialog.getRemoteTag().equals(paramReplacesHeader.getFromTag())))
        {
          ReferredByHeader localReferredByHeader = (ReferredByHeader)paramRequestEvent.getRequest().getHeader("Referred-By");
          if ((localReferredByHeader != null) && (localDialog.getRemoteParty().equals(localReferredByHeader.getAddress())))
            i = 200;
        }
      }
    }

    private void processNewInviteRequest(RequestEvent paramRequestEvent)
      throws SipException
    {
      ReplacesHeader localReplacesHeader = (ReplacesHeader)paramRequestEvent.getRequest().getHeader("Replaces");
      SipSessionGroup.SipSessionImpl localSipSessionImpl1 = null;
      int i;
      if (localReplacesHeader != null)
      {
        i = processInviteWithReplaces(paramRequestEvent, localReplacesHeader);
        log("processNewInviteRequest: " + localReplacesHeader + " response=" + i);
        if (i == 200)
        {
          SipSessionGroup.SipSessionImpl localSipSessionImpl2 = (SipSessionGroup.SipSessionImpl)SipSessionGroup.this.mSessionMap.get(localReplacesHeader.getCallId());
          localSipSessionImpl1 = SipSessionGroup.this.createNewSession(paramRequestEvent, localSipSessionImpl2.mProxy.getListener(), SipSessionGroup.this.mSipHelper.getServerTransaction(paramRequestEvent), 3);
          localSipSessionImpl1.mProxy.onCallTransferring(localSipSessionImpl1, localSipSessionImpl1.mPeerSessionDescription);
        }
      }
      while (true)
      {
        if (localSipSessionImpl1 != null)
          SipSessionGroup.this.addSipSession(localSipSessionImpl1);
        return;
        SipSessionGroup.this.mSipHelper.sendResponse(paramRequestEvent, i);
        continue;
        localSipSessionImpl1 = SipSessionGroup.this.createNewSession(paramRequestEvent, this.mProxy, SipSessionGroup.this.mSipHelper.sendRinging(paramRequestEvent, generateTag()), 3);
        this.mProxy.onRinging(localSipSessionImpl1, localSipSessionImpl1.mPeerProfile, localSipSessionImpl1.mPeerSessionDescription);
      }
    }

    public boolean process(EventObject paramEventObject)
      throws SipException
    {
      boolean bool = true;
      if (SipSessionGroup.isLoggable(this, paramEventObject))
        log("process: " + this + ": " + SipSession.State.toString(this.mState) + ": processing " + SipSessionGroup.logEvt(paramEventObject));
      if (SipSessionGroup.isRequestEvent("INVITE", paramEventObject))
        processNewInviteRequest((RequestEvent)paramEventObject);
      while (true)
      {
        return bool;
        if (SipSessionGroup.isRequestEvent("OPTIONS", paramEventObject))
          SipSessionGroup.this.mSipHelper.sendResponse((RequestEvent)paramEventObject, 200);
        else
          bool = false;
      }
    }
  }

  class SipSessionImpl extends ISipSession.Stub
  {
    private static final boolean SSI_DBG = true;
    private static final String SSI_TAG = "SipSessionImpl";
    int mAuthenticationRetryCount;
    ClientTransaction mClientTransaction;
    Dialog mDialog;
    boolean mInCall;
    RequestEvent mInviteReceived;
    SipProfile mPeerProfile;
    String mPeerSessionDescription;
    SipSessionListenerProxy mProxy = new SipSessionListenerProxy();
    SipSessionImpl mReferSession;
    ReferredByHeader mReferredBy;
    String mReplaces;
    ServerTransaction mServerTransaction;
    SessionTimer mSessionTimer;
    private SipKeepAlive mSipKeepAlive;
    private SipSessionImpl mSipSessionImpl;
    int mState = 0;

    public SipSessionImpl(ISipSessionListener arg2)
    {
      ISipSessionListener localISipSessionListener;
      setListener(localISipSessionListener);
    }

    private void cancelSessionTimer()
    {
      if (this.mSessionTimer != null)
      {
        this.mSessionTimer.cancel();
        this.mSessionTimer = null;
      }
    }

    private String createErrorMessage(Response paramResponse)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramResponse.getReasonPhrase();
      arrayOfObject[1] = Integer.valueOf(paramResponse.getStatusCode());
      return String.format("%s (%d)", arrayOfObject);
    }

    private boolean crossDomainAuthenticationRequired(Response paramResponse)
    {
      String str = getRealmFromResponse(paramResponse);
      if (str == null)
        str = "";
      if (!SipSessionGroup.this.mLocalProfile.getSipDomain().trim().equals(str.trim()));
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    private void doCommandAsync(final EventObject paramEventObject)
    {
      new Thread(new Runnable()
      {
        public void run()
        {
          try
          {
            SipSessionGroup.SipSessionImpl.this.processCommand(paramEventObject);
            return;
          }
          catch (Throwable localThrowable)
          {
            while (true)
            {
              SipSessionGroup.this.loge("command error: " + paramEventObject + ": " + SipSessionGroup.this.mLocalProfile.getUriString(), SipSessionGroup.access$1700(SipSessionGroup.this, localThrowable));
              SipSessionGroup.SipSessionImpl.this.onError(localThrowable);
            }
          }
        }
      }
      , "SipSessionAsyncCmdThread").start();
    }

    private void enableKeepAlive()
    {
      if (this.mSipSessionImpl != null)
        this.mSipSessionImpl.stopKeepAliveProcess();
      try
      {
        while (true)
        {
          this.mSipSessionImpl.startKeepAliveProcess(10, this.mPeerProfile, null);
          return;
          this.mSipSessionImpl = duplicate();
        }
      }
      catch (SipException localSipException)
      {
        while (true)
        {
          SipSessionGroup.this.loge("keepalive cannot be enabled; ignored", localSipException);
          this.mSipSessionImpl.stopKeepAliveProcess();
        }
      }
    }

    private void endCallNormally()
    {
      reset();
      this.mProxy.onCallEnded(this);
    }

    private void endCallOnBusy()
    {
      reset();
      this.mProxy.onCallBusy(this);
    }

    private void endCallOnError(int paramInt, String paramString)
    {
      reset();
      this.mProxy.onError(this, paramInt, paramString);
    }

    private boolean endingCall(EventObject paramEventObject)
      throws SipException
    {
      boolean bool = true;
      ResponseEvent localResponseEvent;
      if (SipSessionGroup.expectResponse("BYE", paramEventObject))
      {
        localResponseEvent = (ResponseEvent)paramEventObject;
        switch (localResponseEvent.getResponse().getStatusCode())
        {
        default:
          cancelSessionTimer();
          reset();
        case 401:
        case 407:
        }
      }
      while (true)
      {
        return bool;
        if (!handleAuthentication(localResponseEvent))
          break;
        continue;
        bool = false;
      }
    }

    private void establishCall(boolean paramBoolean)
    {
      this.mState = 8;
      cancelSessionTimer();
      if ((!this.mInCall) && (paramBoolean))
        enableKeepAlive();
      this.mInCall = true;
      this.mProxy.onCallEstablished(this, this.mPeerSessionDescription);
    }

    private AccountManager getAccountManager()
    {
      return new AccountManager()
      {
        public UserCredentials getCredentials(ClientTransaction paramAnonymousClientTransaction, String paramAnonymousString)
        {
          return new UserCredentials()
          {
            public String getPassword()
            {
              return SipSessionGroup.this.mPassword;
            }

            public String getSipDomain()
            {
              return SipSessionGroup.this.mLocalProfile.getSipDomain();
            }

            public String getUserName()
            {
              String str = SipSessionGroup.this.mLocalProfile.getAuthUserName();
              if (!TextUtils.isEmpty(str));
              while (true)
              {
                return str;
                str = SipSessionGroup.this.mLocalProfile.getUserName();
              }
            }
          };
        }
      };
    }

    private int getErrorCode(int paramInt)
    {
      int i;
      switch (paramInt)
      {
      default:
        if (paramInt < 500)
          i = -4;
        break;
      case 403:
      case 404:
      case 406:
      case 410:
      case 480:
      case 488:
      case 414:
      case 484:
      case 485:
      case 408:
      }
      while (true)
      {
        return i;
        i = -7;
        continue;
        i = -6;
        continue;
        i = -5;
        continue;
        i = -2;
      }
    }

    private int getErrorCode(Throwable paramThrowable)
    {
      paramThrowable.getMessage();
      int i;
      if ((paramThrowable instanceof UnknownHostException))
        i = -12;
      while (true)
      {
        return i;
        if ((paramThrowable instanceof IOException))
          i = -1;
        else
          i = -4;
      }
    }

    private int getExpiryTime(Response paramResponse)
    {
      int i = -1;
      ContactHeader localContactHeader = (ContactHeader)paramResponse.getHeader("Contact");
      if (localContactHeader != null)
        i = localContactHeader.getExpires();
      ExpiresHeader localExpiresHeader1 = (ExpiresHeader)paramResponse.getHeader("Expires");
      if ((localExpiresHeader1 != null) && ((i < 0) || (i > localExpiresHeader1.getExpires())))
        i = localExpiresHeader1.getExpires();
      if (i <= 0)
        i = 3600;
      ExpiresHeader localExpiresHeader2 = (ExpiresHeader)paramResponse.getHeader("Min-Expires");
      if ((localExpiresHeader2 != null) && (i < localExpiresHeader2.getExpires()))
        i = localExpiresHeader2.getExpires();
      log("Expiry time = " + i);
      return i;
    }

    private String getNonceFromResponse(Response paramResponse)
    {
      WWWAuthenticate localWWWAuthenticate = (WWWAuthenticate)paramResponse.getHeader("WWW-Authenticate");
      String str;
      if (localWWWAuthenticate != null)
        str = localWWWAuthenticate.getNonce();
      while (true)
      {
        return str;
        ProxyAuthenticate localProxyAuthenticate = (ProxyAuthenticate)paramResponse.getHeader("Proxy-Authenticate");
        if (localProxyAuthenticate == null)
          str = null;
        else
          str = localProxyAuthenticate.getNonce();
      }
    }

    private String getRealmFromResponse(Response paramResponse)
    {
      WWWAuthenticate localWWWAuthenticate = (WWWAuthenticate)paramResponse.getHeader("WWW-Authenticate");
      String str;
      if (localWWWAuthenticate != null)
        str = localWWWAuthenticate.getRealm();
      while (true)
      {
        return str;
        ProxyAuthenticate localProxyAuthenticate = (ProxyAuthenticate)paramResponse.getHeader("Proxy-Authenticate");
        if (localProxyAuthenticate == null)
          str = null;
        else
          str = localProxyAuthenticate.getRealm();
      }
    }

    private String getResponseString(int paramInt)
    {
      StatusLine localStatusLine = new StatusLine();
      localStatusLine.setStatusCode(paramInt);
      localStatusLine.setReasonPhrase(SIPResponse.getReasonPhrase(paramInt));
      return localStatusLine.encode();
    }

    private Transaction getTransaction()
    {
      Object localObject;
      if (this.mClientTransaction != null)
        localObject = this.mClientTransaction;
      while (true)
      {
        return localObject;
        if (this.mServerTransaction != null)
          localObject = this.mServerTransaction;
        else
          localObject = null;
      }
    }

    private boolean handleAuthentication(ResponseEvent paramResponseEvent)
      throws SipException
    {
      boolean bool = false;
      Response localResponse = paramResponseEvent.getResponse();
      if (getNonceFromResponse(localResponse) == null)
        onError(-2, "server does not provide challenge");
      while (true)
      {
        return bool;
        if (this.mAuthenticationRetryCount < 2)
        {
          this.mClientTransaction = SipSessionGroup.this.mSipHelper.handleChallenge(paramResponseEvent, getAccountManager());
          this.mDialog = this.mClientTransaction.getDialog();
          this.mAuthenticationRetryCount = (1 + this.mAuthenticationRetryCount);
          if (SipSessionGroup.isLoggable(this, paramResponseEvent))
            log("   authentication retry count=" + this.mAuthenticationRetryCount);
          bool = true;
        }
        else if (crossDomainAuthenticationRequired(localResponse))
        {
          onError(-11, getRealmFromResponse(localResponse));
        }
        else
        {
          onError(-8, "incorrect username or password");
        }
      }
    }

    private boolean inCall(EventObject paramEventObject)
      throws SipException
    {
      boolean bool;
      if (SipSessionGroup.END_CALL == paramEventObject)
      {
        this.mState = 10;
        SipSessionGroup.this.mSipHelper.sendBye(this.mDialog);
        this.mProxy.onCallEnded(this);
        startSessionTimer(3);
        bool = true;
      }
      while (true)
      {
        return bool;
        if (SipSessionGroup.isRequestEvent("INVITE", paramEventObject))
        {
          this.mState = 3;
          RequestEvent localRequestEvent = (RequestEvent)paramEventObject;
          this.mInviteReceived = localRequestEvent;
          this.mPeerSessionDescription = SipSessionGroup.this.extractContent(localRequestEvent.getRequest());
          this.mServerTransaction = null;
          this.mProxy.onRinging(this, this.mPeerProfile, this.mPeerSessionDescription);
          bool = true;
        }
        else if (SipSessionGroup.isRequestEvent("BYE", paramEventObject))
        {
          SipSessionGroup.this.mSipHelper.sendResponse((RequestEvent)paramEventObject, 200);
          endCallNormally();
          bool = true;
        }
        else if (SipSessionGroup.isRequestEvent("REFER", paramEventObject))
        {
          bool = processReferRequest((RequestEvent)paramEventObject);
        }
        else if ((paramEventObject instanceof SipSessionGroup.MakeCallCommand))
        {
          this.mState = 5;
          this.mClientTransaction = SipSessionGroup.this.mSipHelper.sendReinvite(this.mDialog, ((SipSessionGroup.MakeCallCommand)paramEventObject).getSessionDescription());
          startSessionTimer(((SipSessionGroup.MakeCallCommand)paramEventObject).getTimeout());
          bool = true;
        }
        else if (((paramEventObject instanceof ResponseEvent)) && (SipSessionGroup.expectResponse("NOTIFY", paramEventObject)))
        {
          bool = true;
        }
        else
        {
          bool = false;
        }
      }
    }

    private boolean incomingCall(EventObject paramEventObject)
      throws SipException
    {
      boolean bool;
      if ((paramEventObject instanceof SipSessionGroup.MakeCallCommand))
      {
        this.mState = 4;
        this.mServerTransaction = SipSessionGroup.this.mSipHelper.sendInviteOk(this.mInviteReceived, SipSessionGroup.this.mLocalProfile, ((SipSessionGroup.MakeCallCommand)paramEventObject).getSessionDescription(), this.mServerTransaction, SipSessionGroup.this.mExternalIp, SipSessionGroup.this.mExternalPort);
        startSessionTimer(((SipSessionGroup.MakeCallCommand)paramEventObject).getTimeout());
        bool = true;
      }
      while (true)
      {
        return bool;
        if (SipSessionGroup.END_CALL == paramEventObject)
        {
          SipSessionGroup.this.mSipHelper.sendInviteBusyHere(this.mInviteReceived, this.mServerTransaction);
          endCallNormally();
          bool = true;
        }
        else if (SipSessionGroup.isRequestEvent("CANCEL", paramEventObject))
        {
          RequestEvent localRequestEvent = (RequestEvent)paramEventObject;
          SipSessionGroup.this.mSipHelper.sendResponse(localRequestEvent, 200);
          SipSessionGroup.this.mSipHelper.sendInviteRequestTerminated(this.mInviteReceived.getRequest(), this.mServerTransaction);
          endCallNormally();
          bool = true;
        }
        else
        {
          bool = false;
        }
      }
    }

    private boolean incomingCallToInCall(EventObject paramEventObject)
    {
      boolean bool = true;
      if (SipSessionGroup.isRequestEvent("ACK", paramEventObject))
      {
        String str = SipSessionGroup.this.extractContent(((RequestEvent)paramEventObject).getRequest());
        if (str != null)
          this.mPeerSessionDescription = str;
        if (this.mPeerSessionDescription == null)
          onError(-4, "peer sdp is empty");
      }
      while (true)
      {
        return bool;
        establishCall(false);
        continue;
        if (!SipSessionGroup.isRequestEvent("CANCEL", paramEventObject))
          bool = false;
      }
    }

    private boolean isCurrentTransaction(TransactionTerminatedEvent paramTransactionTerminatedEvent)
    {
      boolean bool = true;
      Object localObject1;
      Object localObject2;
      if (paramTransactionTerminatedEvent.isServerTransaction())
      {
        localObject1 = this.mServerTransaction;
        if (!paramTransactionTerminatedEvent.isServerTransaction())
          break label97;
        localObject2 = paramTransactionTerminatedEvent.getServerTransaction();
        label27: if ((localObject1 == localObject2) || (this.mState == 9))
          break label106;
        log("not the current transaction; current=" + toString((Transaction)localObject1) + ", target=" + toString((Transaction)localObject2));
        bool = false;
      }
      while (true)
      {
        return bool;
        localObject1 = this.mClientTransaction;
        break;
        label97: localObject2 = paramTransactionTerminatedEvent.getClientTransaction();
        break label27;
        label106: if (localObject1 != null)
          log("transaction terminated: " + toString((Transaction)localObject1));
      }
    }

    private void log(String paramString)
    {
      Rlog.d("SipSessionImpl", paramString);
    }

    private void onError(int paramInt, String paramString)
    {
      cancelSessionTimer();
      switch (this.mState)
      {
      default:
        endCallOnError(paramInt, paramString);
      case 1:
      case 2:
      }
      while (true)
      {
        return;
        onRegistrationFailed(paramInt, paramString);
      }
    }

    private void onError(Throwable paramThrowable)
    {
      Throwable localThrowable = SipSessionGroup.this.getRootCause(paramThrowable);
      onError(getErrorCode(localThrowable), localThrowable.toString());
    }

    private void onError(Response paramResponse)
    {
      int i = paramResponse.getStatusCode();
      if ((!this.mInCall) && (i == 486))
        endCallOnBusy();
      while (true)
      {
        return;
        onError(getErrorCode(i), createErrorMessage(paramResponse));
      }
    }

    private void onRegistrationDone(int paramInt)
    {
      reset();
      this.mProxy.onRegistrationDone(this, paramInt);
    }

    private void onRegistrationFailed(int paramInt, String paramString)
    {
      reset();
      this.mProxy.onRegistrationFailed(this, paramInt, paramString);
    }

    private void onRegistrationFailed(Response paramResponse)
    {
      onRegistrationFailed(getErrorCode(paramResponse.getStatusCode()), createErrorMessage(paramResponse));
    }

    private boolean outgoingCall(EventObject paramEventObject)
      throws SipException
    {
      boolean bool = true;
      ResponseEvent localResponseEvent;
      Response localResponse;
      int i;
      if (SipSessionGroup.expectResponse("INVITE", paramEventObject))
      {
        localResponseEvent = (ResponseEvent)paramEventObject;
        localResponse = localResponseEvent.getResponse();
        i = localResponse.getStatusCode();
        switch (i)
        {
        default:
          if (this.mReferSession != null)
            SipSessionGroup.this.mSipHelper.sendReferNotify(this.mReferSession.mDialog, getResponseString(503));
          if (i >= 400)
            onError(localResponse);
          break;
        case 491:
        case 180:
        case 181:
        case 182:
        case 183:
        case 200:
        case 401:
        case 407:
        }
      }
      while (true)
      {
        return bool;
        if (this.mState == 5)
        {
          this.mState = 6;
          cancelSessionTimer();
          this.mProxy.onRingingBack(this);
          continue;
          if (this.mReferSession != null)
          {
            SipSessionGroup.this.mSipHelper.sendReferNotify(this.mReferSession.mDialog, getResponseString(200));
            this.mReferSession = null;
          }
          SipSessionGroup.this.mSipHelper.sendInviteAck(localResponseEvent, this.mDialog);
          this.mPeerSessionDescription = SipSessionGroup.this.extractContent(localResponse);
          establishCall(bool);
          continue;
          if (handleAuthentication(localResponseEvent))
          {
            SipSessionGroup.this.addSipSession(this);
            continue;
            if (i >= 300)
            {
              bool = false;
              continue;
              if (SipSessionGroup.END_CALL == paramEventObject)
              {
                this.mState = 7;
                SipSessionGroup.this.mSipHelper.sendCancel(this.mClientTransaction);
                startSessionTimer(3);
              }
              else if (SipSessionGroup.isRequestEvent("INVITE", paramEventObject))
              {
                RequestEvent localRequestEvent = (RequestEvent)paramEventObject;
                SipSessionGroup.this.mSipHelper.sendInviteBusyHere(localRequestEvent, localRequestEvent.getServerTransaction());
              }
              else
              {
                bool = false;
              }
            }
          }
        }
      }
    }

    private boolean outgoingCallToReady(EventObject paramEventObject)
      throws SipException
    {
      boolean bool = true;
      Response localResponse;
      int i;
      if ((paramEventObject instanceof ResponseEvent))
      {
        localResponse = ((ResponseEvent)paramEventObject).getResponse();
        i = localResponse.getStatusCode();
        if (SipSessionGroup.expectResponse("CANCEL", paramEventObject))
          if (i != 200)
            break label84;
      }
      while (true)
      {
        return bool;
        if (SipSessionGroup.expectResponse("INVITE", paramEventObject))
        {
          switch (i)
          {
          default:
            if (i < 400)
              break label142;
            onError(localResponse);
            break;
          case 200:
            outgoingCall(paramEventObject);
            break;
          case 487:
            label84: endCallNormally();
            break;
          }
        }
        else
        {
          bool = false;
          continue;
          if ((paramEventObject instanceof TransactionTerminatedEvent))
            onError(new SipException("timed out"));
          label142: bool = false;
        }
      }
    }

    private void processCommand(EventObject paramEventObject)
      throws SipException
    {
      if (SipSessionGroup.isLoggable(paramEventObject))
        log("process cmd: " + paramEventObject);
      if (!process(paramEventObject))
        onError(-9, "cannot initiate a new transaction to execute: " + paramEventObject);
    }

    private void processDialogTerminated(DialogTerminatedEvent paramDialogTerminatedEvent)
    {
      if (this.mDialog == paramDialogTerminatedEvent.getDialog())
        onError(new SipException("dialog terminated"));
      while (true)
      {
        return;
        log("not the current dialog; current=" + this.mDialog + ", terminated=" + paramDialogTerminatedEvent.getDialog());
      }
    }

    private boolean processExceptions(EventObject paramEventObject)
      throws SipException
    {
      boolean bool;
      if (SipSessionGroup.isRequestEvent("BYE", paramEventObject))
      {
        SipSessionGroup.this.mSipHelper.sendResponse((RequestEvent)paramEventObject, 200);
        endCallNormally();
        bool = true;
      }
      while (true)
      {
        return bool;
        if (SipSessionGroup.isRequestEvent("CANCEL", paramEventObject))
        {
          SipSessionGroup.this.mSipHelper.sendResponse((RequestEvent)paramEventObject, 481);
          bool = true;
        }
        else
        {
          if ((paramEventObject instanceof TransactionTerminatedEvent))
          {
            if (isCurrentTransaction((TransactionTerminatedEvent)paramEventObject))
            {
              if ((paramEventObject instanceof TimeoutEvent))
                processTimeout((TimeoutEvent)paramEventObject);
              while (true)
              {
                bool = true;
                break;
                processTransactionTerminated((TransactionTerminatedEvent)paramEventObject);
              }
            }
          }
          else
          {
            if (SipSessionGroup.isRequestEvent("OPTIONS", paramEventObject))
            {
              SipSessionGroup.this.mSipHelper.sendResponse((RequestEvent)paramEventObject, 200);
              bool = true;
              continue;
            }
            if ((paramEventObject instanceof DialogTerminatedEvent))
            {
              processDialogTerminated((DialogTerminatedEvent)paramEventObject);
              bool = true;
              continue;
            }
          }
          bool = false;
        }
      }
    }

    private boolean processReferRequest(RequestEvent paramRequestEvent)
      throws SipException
    {
      boolean bool = false;
      try
      {
        ReferToHeader localReferToHeader = (ReferToHeader)paramRequestEvent.getRequest().getHeader("Refer-To");
        SipURI localSipURI = (SipURI)localReferToHeader.getAddress().getURI();
        String str = localSipURI.getHeader("Replaces");
        if (localSipURI.getUser() == null)
        {
          SipSessionGroup.this.mSipHelper.sendResponse(paramRequestEvent, 400);
        }
        else
        {
          SipSessionGroup.this.mSipHelper.sendResponse(paramRequestEvent, 202);
          SipSessionImpl localSipSessionImpl = SipSessionGroup.this.createNewSession(paramRequestEvent, this.mProxy.getListener(), SipSessionGroup.this.mSipHelper.getServerTransaction(paramRequestEvent), 0);
          localSipSessionImpl.mReferSession = this;
          localSipSessionImpl.mReferredBy = ((ReferredByHeader)paramRequestEvent.getRequest().getHeader("Referred-By"));
          localSipSessionImpl.mReplaces = str;
          localSipSessionImpl.mPeerProfile = SipSessionGroup.createPeerProfile(localReferToHeader);
          localSipSessionImpl.mProxy.onCallTransferring(localSipSessionImpl, null);
          bool = true;
        }
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw new SipException("createPeerProfile()", localIllegalArgumentException);
      }
      return bool;
    }

    private void processTimeout(TimeoutEvent paramTimeoutEvent)
    {
      log("processing Timeout...");
      switch (this.mState)
      {
      case 6:
      default:
        log("   do nothing");
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 7:
      }
      while (true)
      {
        return;
        reset();
        this.mProxy.onRegistrationTimeout(this);
        continue;
        onError(-5, paramTimeoutEvent.toString());
      }
    }

    private void processTransactionTerminated(TransactionTerminatedEvent paramTransactionTerminatedEvent)
    {
      switch (this.mState)
      {
      default:
        log("Transaction terminated early: " + this);
        onError(-3, "transaction terminated");
      case 0:
      case 8:
      }
      while (true)
      {
        return;
        log("Transaction terminated; do nothing");
      }
    }

    private boolean readyForCall(EventObject paramEventObject)
      throws SipException
    {
      boolean bool = false;
      if ((paramEventObject instanceof SipSessionGroup.MakeCallCommand))
      {
        this.mState = 5;
        SipSessionGroup.MakeCallCommand localMakeCallCommand = (SipSessionGroup.MakeCallCommand)paramEventObject;
        this.mPeerProfile = localMakeCallCommand.getPeerProfile();
        if (this.mReferSession != null)
          SipSessionGroup.this.mSipHelper.sendReferNotify(this.mReferSession.mDialog, getResponseString(100));
        this.mClientTransaction = SipSessionGroup.this.mSipHelper.sendInvite(SipSessionGroup.this.mLocalProfile, this.mPeerProfile, localMakeCallCommand.getSessionDescription(), generateTag(), this.mReferredBy, this.mReplaces);
        this.mDialog = this.mClientTransaction.getDialog();
        SipSessionGroup.this.addSipSession(this);
        startSessionTimer(localMakeCallCommand.getTimeout());
        this.mProxy.onCalling(this);
        bool = true;
      }
      while (true)
      {
        return bool;
        if ((paramEventObject instanceof SipSessionGroup.RegisterCommand))
        {
          this.mState = 1;
          int i = ((SipSessionGroup.RegisterCommand)paramEventObject).getDuration();
          this.mClientTransaction = SipSessionGroup.this.mSipHelper.sendRegister(SipSessionGroup.this.mLocalProfile, generateTag(), i);
          this.mDialog = this.mClientTransaction.getDialog();
          SipSessionGroup.this.addSipSession(this);
          this.mProxy.onRegistering(this);
          bool = true;
        }
        else if (SipSessionGroup.DEREGISTER == paramEventObject)
        {
          this.mState = 2;
          this.mClientTransaction = SipSessionGroup.this.mSipHelper.sendRegister(SipSessionGroup.this.mLocalProfile, generateTag(), 0);
          this.mDialog = this.mClientTransaction.getDialog();
          SipSessionGroup.this.addSipSession(this);
          this.mProxy.onRegistering(this);
          bool = true;
        }
      }
    }

    private boolean registeringToReady(EventObject paramEventObject)
      throws SipException
    {
      ResponseEvent localResponseEvent;
      boolean bool;
      if (SipSessionGroup.expectResponse("REGISTER", paramEventObject))
      {
        localResponseEvent = (ResponseEvent)paramEventObject;
        Response localResponse = localResponseEvent.getResponse();
        int i = localResponse.getStatusCode();
        switch (i)
        {
        default:
          if (i >= 500)
          {
            onRegistrationFailed(localResponse);
            bool = true;
          }
          break;
        case 200:
        case 401:
        case 407:
        }
      }
      while (true)
      {
        return bool;
        if (this.mState == 1);
        for (int j = getExpiryTime(((ResponseEvent)paramEventObject).getResponse()); ; j = -1)
        {
          onRegistrationDone(j);
          bool = true;
          break;
        }
        handleAuthentication(localResponseEvent);
        bool = true;
        continue;
        bool = false;
      }
    }

    private void reset()
    {
      this.mInCall = false;
      SipSessionGroup.this.removeSipSession(this);
      this.mPeerProfile = null;
      this.mState = 0;
      this.mInviteReceived = null;
      this.mPeerSessionDescription = null;
      this.mAuthenticationRetryCount = 0;
      this.mReferSession = null;
      this.mReferredBy = null;
      this.mReplaces = null;
      if (this.mDialog != null)
        this.mDialog.delete();
      this.mDialog = null;
      try
      {
        if (this.mServerTransaction != null)
          this.mServerTransaction.terminate();
        label90: this.mServerTransaction = null;
        try
        {
          if (this.mClientTransaction != null)
            this.mClientTransaction.terminate();
          label111: this.mClientTransaction = null;
          cancelSessionTimer();
          if (this.mSipSessionImpl != null)
          {
            this.mSipSessionImpl.stopKeepAliveProcess();
            this.mSipSessionImpl = null;
          }
          return;
        }
        catch (ObjectInUseException localObjectInUseException2)
        {
          break label111;
        }
      }
      catch (ObjectInUseException localObjectInUseException1)
      {
        break label90;
      }
    }

    private void startSessionTimer(int paramInt)
    {
      if (paramInt > 0)
      {
        this.mSessionTimer = new SessionTimer();
        this.mSessionTimer.start(paramInt);
      }
    }

    private String toString(Transaction paramTransaction)
    {
      String str;
      if (paramTransaction == null)
      {
        str = "null";
        return str;
      }
      Request localRequest = paramTransaction.getRequest();
      Dialog localDialog = paramTransaction.getDialog();
      CSeqHeader localCSeqHeader = (CSeqHeader)localRequest.getHeader("CSeq");
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = localRequest.getMethod();
      arrayOfObject[1] = Long.valueOf(localCSeqHeader.getSeqNumber());
      arrayOfObject[2] = paramTransaction.getState();
      if (localDialog == null);
      for (Object localObject = "-"; ; localObject = localDialog.getState())
      {
        arrayOfObject[3] = localObject;
        str = String.format("req=%s,%s,s=%s,ds=%s,", arrayOfObject);
        break;
      }
    }

    public void answerCall(String paramString, int paramInt)
    {
      synchronized (SipSessionGroup.this)
      {
        if (this.mPeerProfile != null)
          doCommandAsync(new SipSessionGroup.MakeCallCommand(SipSessionGroup.this, this.mPeerProfile, paramString, paramInt));
      }
    }

    public void changeCall(String paramString, int paramInt)
    {
      synchronized (SipSessionGroup.this)
      {
        if (this.mPeerProfile != null)
          doCommandAsync(new SipSessionGroup.MakeCallCommand(SipSessionGroup.this, this.mPeerProfile, paramString, paramInt));
      }
    }

    SipSessionImpl duplicate()
    {
      return new SipSessionImpl(SipSessionGroup.this, this.mProxy.getListener());
    }

    public void endCall()
    {
      doCommandAsync(SipSessionGroup.END_CALL);
    }

    protected String generateTag()
    {
      return String.valueOf(()(4294967296.0D * Math.random()));
    }

    public String getCallId()
    {
      return SipHelper.getCallId(getTransaction());
    }

    public String getLocalIp()
    {
      return SipSessionGroup.this.mLocalIp;
    }

    public SipProfile getLocalProfile()
    {
      return SipSessionGroup.this.mLocalProfile;
    }

    public SipProfile getPeerProfile()
    {
      return this.mPeerProfile;
    }

    public int getState()
    {
      return this.mState;
    }

    public boolean isInCall()
    {
      return this.mInCall;
    }

    public void makeCall(SipProfile paramSipProfile, String paramString, int paramInt)
    {
      doCommandAsync(new SipSessionGroup.MakeCallCommand(SipSessionGroup.this, paramSipProfile, paramString, paramInt));
    }

    public boolean process(EventObject paramEventObject)
      throws SipException
    {
      if (SipSessionGroup.isLoggable(this, paramEventObject))
        log(" ~~~~~   " + this + ": " + SipSession.State.toString(this.mState) + ": processing " + SipSessionGroup.logEvt(paramEventObject));
      while (true)
      {
        Dialog localDialog;
        boolean bool1;
        synchronized (SipSessionGroup.this)
        {
          if (SipSessionGroup.this.isClosed())
          {
            bool3 = false;
          }
          else if ((this.mSipKeepAlive != null) && (this.mSipKeepAlive.process(paramEventObject)))
          {
            bool3 = true;
          }
          else
          {
            localDialog = null;
            if ((paramEventObject instanceof RequestEvent))
            {
              localDialog = ((RequestEvent)paramEventObject).getDialog();
              if (localDialog != null)
                this.mDialog = localDialog;
              switch (this.mState)
              {
              case 1:
                if (bool2)
                  break label359;
                if (processExceptions(paramEventObject))
                  break label359;
                break;
              case 2:
              case 0:
              case 3:
              case 4:
              case 5:
              case 6:
              case 7:
              case 8:
              case 10:
              case 9:
              }
            }
          }
        }
        boolean bool2 = false;
        continue;
        label359: boolean bool3 = true;
      }
    }

    public void register(int paramInt)
    {
      doCommandAsync(new SipSessionGroup.RegisterCommand(SipSessionGroup.this, paramInt));
    }

    public void setListener(ISipSessionListener paramISipSessionListener)
    {
      SipSessionListenerProxy localSipSessionListenerProxy = this.mProxy;
      if ((paramISipSessionListener instanceof SipSessionListenerProxy))
        paramISipSessionListener = ((SipSessionListenerProxy)paramISipSessionListener).getListener();
      localSipSessionListenerProxy.setListener(paramISipSessionListener);
    }

    // ERROR //
    public void startKeepAliveProcess(int paramInt, SipProfile paramSipProfile, SipSessionGroup.KeepAliveProcessCallback paramKeepAliveProcessCallback)
      throws SipException
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 44	com/android/server/sip/SipSessionGroup$SipSessionImpl:this$0	Lcom/android/server/sip/SipSessionGroup;
      //   4: astore 4
      //   6: aload 4
      //   8: monitorenter
      //   9: aload_0
      //   10: getfield 802	com/android/server/sip/SipSessionGroup$SipSessionImpl:mSipKeepAlive	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive;
      //   13: ifnull +22 -> 35
      //   16: new 73	javax/sip/SipException
      //   19: dup
      //   20: ldc_w 834
      //   23: invokespecial 542	javax/sip/SipException:<init>	(Ljava/lang/String;)V
      //   26: athrow
      //   27: astore 5
      //   29: aload 4
      //   31: monitorexit
      //   32: aload 5
      //   34: athrow
      //   35: aload_0
      //   36: aload_2
      //   37: putfield 175	com/android/server/sip/SipSessionGroup$SipSessionImpl:mPeerProfile	Landroid/net/sip/SipProfile;
      //   40: aload_0
      //   41: new 804	com/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive
      //   44: dup
      //   45: aload_0
      //   46: invokespecial 835	com/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive:<init>	(Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;)V
      //   49: putfield 802	com/android/server/sip/SipSessionGroup$SipSessionImpl:mSipKeepAlive	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive;
      //   52: aload_0
      //   53: getfield 52	com/android/server/sip/SipSessionGroup$SipSessionImpl:mProxy	Lcom/android/server/sip/SipSessionListenerProxy;
      //   56: aload_0
      //   57: getfield 802	com/android/server/sip/SipSessionGroup$SipSessionImpl:mSipKeepAlive	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive;
      //   60: invokevirtual 832	com/android/server/sip/SipSessionListenerProxy:setListener	(Landroid/net/sip/ISipSessionListener;)V
      //   63: aload_0
      //   64: getfield 802	com/android/server/sip/SipSessionGroup$SipSessionImpl:mSipKeepAlive	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive;
      //   67: iload_1
      //   68: aload_3
      //   69: invokevirtual 838	com/android/server/sip/SipSessionGroup$SipSessionImpl$SipKeepAlive:start	(ILcom/android/server/sip/SipSessionGroup$KeepAliveProcessCallback;)V
      //   72: aload 4
      //   74: monitorexit
      //   75: return
      //
      // Exception table:
      //   from	to	target	type
      //   9	32	27	finally
      //   35	75	27	finally
    }

    public void startKeepAliveProcess(int paramInt, SipSessionGroup.KeepAliveProcessCallback paramKeepAliveProcessCallback)
      throws SipException
    {
      synchronized (SipSessionGroup.this)
      {
        startKeepAliveProcess(paramInt, SipSessionGroup.this.mLocalProfile, paramKeepAliveProcessCallback);
        return;
      }
    }

    public void stopKeepAliveProcess()
    {
      synchronized (SipSessionGroup.this)
      {
        if (this.mSipKeepAlive != null)
        {
          this.mSipKeepAlive.stop();
          this.mSipKeepAlive = null;
        }
        return;
      }
    }

    public String toString()
    {
      try
      {
        String str2 = super.toString();
        String str3 = str2.substring(str2.indexOf("@")) + ":" + SipSession.State.toString(this.mState);
        str1 = str3;
        return str1;
      }
      catch (Throwable localThrowable)
      {
        while (true)
          String str1 = super.toString();
      }
    }

    public void unregister()
    {
      doCommandAsync(SipSessionGroup.DEREGISTER);
    }

    class SessionTimer
    {
      private boolean mRunning = true;

      SessionTimer()
      {
      }

      private void sleep(int paramInt)
      {
        long l = paramInt * 1000;
        try
        {
          wait(l);
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            SipSessionGroup.this.loge("session timer interrupted!", localInterruptedException);
        }
        finally
        {
        }
      }

      private void timeout()
      {
        synchronized (SipSessionGroup.this)
        {
          SipSessionGroup.SipSessionImpl.this.onError(-5, "Session timed out!");
          return;
        }
      }

      void cancel()
      {
        try
        {
          this.mRunning = false;
          notify();
          return;
        }
        finally
        {
          localObject = finally;
          throw localObject;
        }
      }

      void start(final int paramInt)
      {
        new Thread(new Runnable()
        {
          public void run()
          {
            SipSessionGroup.SipSessionImpl.SessionTimer.this.sleep(paramInt);
            if (SipSessionGroup.SipSessionImpl.SessionTimer.this.mRunning)
              SipSessionGroup.SipSessionImpl.SessionTimer.this.timeout();
          }
        }
        , "SipSessionTimerThread").start();
      }
    }

    class SipKeepAlive extends SipSessionAdapter
      implements Runnable
    {
      private static final boolean SKA_DBG = true;
      private static final String SKA_TAG = "SipKeepAlive";
      private SipSessionGroup.KeepAliveProcessCallback mCallback;
      private int mInterval;
      private boolean mPortChanged = false;
      private int mRPort = 0;
      private boolean mRunning = false;

      SipKeepAlive()
      {
      }

      private int getRPortFromResponse(Response paramResponse)
      {
        ViaHeader localViaHeader = (ViaHeader)paramResponse.getHeader("Via");
        if (localViaHeader == null);
        for (int i = -1; ; i = localViaHeader.getRPort())
          return i;
      }

      private void log(String paramString)
      {
        Rlog.d("SipKeepAlive", paramString);
      }

      private boolean parseOptionsResult(EventObject paramEventObject)
      {
        boolean bool = true;
        int i;
        if (SipSessionGroup.expectResponse("OPTIONS", paramEventObject))
        {
          i = getRPortFromResponse(((ResponseEvent)paramEventObject).getResponse());
          if (i != -1)
          {
            if (this.mRPort == 0)
              this.mRPort = i;
            if (this.mRPort != i)
            {
              this.mPortChanged = bool;
              Object[] arrayOfObject = new Object[2];
              arrayOfObject[0] = Integer.valueOf(this.mRPort);
              arrayOfObject[bool] = Integer.valueOf(i);
              log(String.format("rport is changed: %d <> %d", arrayOfObject));
              this.mRPort = i;
            }
          }
        }
        while (true)
        {
          return bool;
          log("rport is the same: " + i);
          continue;
          log("peer did not respond rport");
          continue;
          bool = false;
        }
      }

      private void sendKeepAlive()
        throws SipException
      {
        synchronized (SipSessionGroup.this)
        {
          SipSessionGroup.SipSessionImpl.this.mState = 9;
          SipSessionGroup.SipSessionImpl.this.mClientTransaction = SipSessionGroup.this.mSipHelper.sendOptions(SipSessionGroup.this.mLocalProfile, SipSessionGroup.SipSessionImpl.this.mPeerProfile, SipSessionGroup.SipSessionImpl.this.generateTag());
          SipSessionGroup.SipSessionImpl.this.mDialog = SipSessionGroup.SipSessionImpl.this.mClientTransaction.getDialog();
          SipSessionGroup.this.addSipSession(SipSessionGroup.SipSessionImpl.this);
          SipSessionGroup.SipSessionImpl.this.startSessionTimer(5);
          return;
        }
      }

      public void onError(ISipSession paramISipSession, int paramInt, String paramString)
      {
        stop();
        this.mCallback.onError(paramInt, paramString);
      }

      boolean process(EventObject paramEventObject)
      {
        if ((this.mRunning) && (SipSessionGroup.SipSessionImpl.this.mState == 9) && ((paramEventObject instanceof ResponseEvent)) && (parseOptionsResult(paramEventObject)))
          if (this.mPortChanged)
          {
            SipSessionGroup.this.resetExternalAddress();
            stop();
            this.mCallback.onResponse(this.mPortChanged);
          }
        for (boolean bool = true; ; bool = false)
        {
          return bool;
          SipSessionGroup.SipSessionImpl.this.cancelSessionTimer();
          SipSessionGroup.this.removeSipSession(SipSessionGroup.SipSessionImpl.this);
          break;
        }
      }

      public void run()
      {
        while (true)
        {
          synchronized (SipSessionGroup.this)
          {
            if (!this.mRunning)
              return;
          }
          try
          {
            sendKeepAlive();
            continue;
            localObject = finally;
            throw localObject;
          }
          catch (Throwable localThrowable)
          {
            while (true)
            {
              SipSessionGroup.this.loge("keepalive error: " + SipSessionGroup.this.mLocalProfile.getUriString(), SipSessionGroup.access$1700(SipSessionGroup.this, localThrowable));
              if (this.mRunning)
                SipSessionGroup.SipSessionImpl.this.onError(localThrowable);
            }
          }
        }
      }

      void start(int paramInt, SipSessionGroup.KeepAliveProcessCallback paramKeepAliveProcessCallback)
      {
        if (this.mRunning);
        while (true)
        {
          return;
          this.mRunning = true;
          this.mInterval = paramInt;
          this.mCallback = new SipSessionGroup.KeepAliveProcessCallbackProxy(paramKeepAliveProcessCallback);
          SipSessionGroup.this.mWakeupTimer.set(paramInt * 1000, this);
          log("start keepalive:" + SipSessionGroup.this.mLocalProfile.getUriString());
          run();
        }
      }

      void stop()
      {
        synchronized (SipSessionGroup.this)
        {
          log("stop keepalive:" + SipSessionGroup.this.mLocalProfile.getUriString() + ",RPort=" + this.mRPort);
          this.mRunning = false;
          SipSessionGroup.this.mWakeupTimer.cancel(this);
          SipSessionGroup.SipSessionImpl.this.reset();
          return;
        }
      }
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.server.sip.SipSessionGroup
 * JD-Core Version:    0.6.2
 */