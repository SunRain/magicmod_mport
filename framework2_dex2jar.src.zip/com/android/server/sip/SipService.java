package com.android.server.sip;

import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.sip.ISipService.Stub;
import android.net.sip.ISipSession;
import android.net.sip.ISipSessionListener;
import android.net.sip.SipErrorCode;
import android.net.sip.SipManager;
import android.net.sip.SipProfile;
import android.net.sip.SipProfile.Builder;
import android.net.sip.SipSessionAdapter;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.WifiLock;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemClock;
import android.telephony.Rlog;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Executor;
import javax.sip.SipException;

public final class SipService extends ISipService.Stub
{
  static final boolean DBG = true;
  private static final int DEFAULT_KEEPALIVE_INTERVAL = 10;
  private static final int DEFAULT_MAX_KEEPALIVE_INTERVAL = 120;
  private static final int EXPIRY_TIME = 3600;
  private static final int MIN_EXPIRY_TIME = 60;
  private static final int SHORT_EXPIRY_TIME = 10;
  static final String TAG = "SipService";
  private ConnectivityReceiver mConnectivityReceiver;
  private Context mContext;
  private MyExecutor mExecutor = new MyExecutor();
  private int mKeepAliveInterval;
  private int mLastGoodKeepAliveInterval = 10;
  private String mLocalIp;
  private SipWakeLock mMyWakeLock;
  private int mNetworkType = -1;
  private Map<String, ISipSession> mPendingSessions = new HashMap();
  private Map<String, SipSessionGroupExt> mSipGroups = new HashMap();
  private SipKeepAliveProcessCallback mSipKeepAliveProcessCallback;
  private boolean mSipOnWifiOnly;
  private SipWakeupTimer mTimer;
  private WifiManager.WifiLock mWifiLock;

  private SipService(Context paramContext)
  {
    log("SipService: started!");
    this.mContext = paramContext;
    this.mConnectivityReceiver = new ConnectivityReceiver(null);
    this.mWifiLock = ((WifiManager)paramContext.getSystemService("wifi")).createWifiLock(1, "SipService");
    this.mWifiLock.setReferenceCounted(false);
    this.mSipOnWifiOnly = SipManager.isSipWifiOnly(paramContext);
    this.mMyWakeLock = new SipWakeLock((PowerManager)paramContext.getSystemService("power"));
    this.mTimer = new SipWakeupTimer(paramContext, this.mExecutor);
  }

  private void addPendingSession(ISipSession paramISipSession)
  {
    try
    {
      cleanUpPendingSessions();
      this.mPendingSessions.put(paramISipSession.getCallId(), paramISipSession);
      log("#pending sess=" + this.mPendingSessions.size());
      return;
    }
    catch (RemoteException localRemoteException)
    {
      while (true)
        loge("addPendingSession()", localRemoteException);
    }
    finally
    {
    }
  }

  private boolean callingSelf(SipSessionGroupExt paramSipSessionGroupExt, SipSessionGroup.SipSessionImpl paramSipSessionImpl)
  {
    try
    {
      String str = paramSipSessionImpl.getCallId();
      Iterator localIterator = this.mSipGroups.values().iterator();
      while (localIterator.hasNext())
      {
        SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)localIterator.next();
        if ((localSipSessionGroupExt != paramSipSessionGroupExt) && (localSipSessionGroupExt.containsSession(str)))
        {
          log("call self: " + paramSipSessionImpl.getLocalProfile().getUriString() + " -> " + localSipSessionGroupExt.getLocalProfile().getUriString());
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
    finally
    {
    }
  }

  private void cleanUpPendingSessions()
    throws RemoteException
  {
    for (Map.Entry localEntry : (Map.Entry[])this.mPendingSessions.entrySet().toArray(new Map.Entry[this.mPendingSessions.size()]))
      if (((ISipSession)localEntry.getValue()).getState() != 3)
        this.mPendingSessions.remove(localEntry.getKey());
  }

  private SipSessionGroupExt createGroup(SipProfile paramSipProfile)
    throws SipException
  {
    String str = paramSipProfile.getUriString();
    SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)this.mSipGroups.get(str);
    if (localSipSessionGroupExt == null)
    {
      localSipSessionGroupExt = new SipSessionGroupExt(paramSipProfile, null, null);
      this.mSipGroups.put(str, localSipSessionGroupExt);
      notifyProfileAdded(paramSipProfile);
    }
    while (isCallerCreator(localSipSessionGroupExt))
      return localSipSessionGroupExt;
    throw new SipException("only creator can access the profile");
  }

  private SipSessionGroupExt createGroup(SipProfile paramSipProfile, PendingIntent paramPendingIntent, ISipSessionListener paramISipSessionListener)
    throws SipException
  {
    String str = paramSipProfile.getUriString();
    SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)this.mSipGroups.get(str);
    if (localSipSessionGroupExt != null)
    {
      if (!isCallerCreator(localSipSessionGroupExt))
        throw new SipException("only creator can access the profile");
      localSipSessionGroupExt.setIncomingCallPendingIntent(paramPendingIntent);
      localSipSessionGroupExt.setListener(paramISipSessionListener);
    }
    while (true)
    {
      return localSipSessionGroupExt;
      localSipSessionGroupExt = new SipSessionGroupExt(paramSipProfile, paramPendingIntent, paramISipSessionListener);
      this.mSipGroups.put(str, localSipSessionGroupExt);
      notifyProfileAdded(paramSipProfile);
    }
  }

  private static Looper createLooper()
  {
    HandlerThread localHandlerThread = new HandlerThread("SipService.Executor");
    localHandlerThread.start();
    return localHandlerThread.getLooper();
  }

  private String determineLocalIp()
  {
    try
    {
      DatagramSocket localDatagramSocket = new DatagramSocket();
      localDatagramSocket.connect(InetAddress.getByName("192.168.1.1"), 80);
      String str2 = localDatagramSocket.getLocalAddress().getHostAddress();
      str1 = str2;
      return str1;
    }
    catch (IOException localIOException)
    {
      while (true)
      {
        loge("determineLocalIp()", localIOException);
        String str1 = null;
      }
    }
  }

  private int getKeepAliveInterval()
  {
    if (this.mKeepAliveInterval < 0);
    for (int i = this.mLastGoodKeepAliveInterval; ; i = this.mKeepAliveInterval)
      return i;
  }

  private boolean isBehindNAT(String paramString)
  {
    boolean bool = true;
    try
    {
      byte[] arrayOfByte = InetAddress.getByName(paramString).getAddress();
      if ((arrayOfByte[0] != 10) && (((0xFF & arrayOfByte[0]) != 172) || ((0xF0 & arrayOfByte[1]) != 16)))
      {
        if ((0xFF & arrayOfByte[0]) == 192)
        {
          int i = arrayOfByte[1];
          if ((i & 0xFF) != 168);
        }
      }
      else
        return bool;
    }
    catch (UnknownHostException localUnknownHostException)
    {
      while (true)
      {
        loge("isBehindAT()" + paramString, localUnknownHostException);
        bool = false;
      }
    }
  }

  private boolean isCallerCreator(SipSessionGroupExt paramSipSessionGroupExt)
  {
    if (paramSipSessionGroupExt.getLocalProfile().getCallingUid() == Binder.getCallingUid());
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isCallerCreatorOrRadio(SipSessionGroupExt paramSipSessionGroupExt)
  {
    if ((isCallerRadio()) || (isCallerCreator(paramSipSessionGroupExt)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private boolean isCallerRadio()
  {
    if (Binder.getCallingUid() == 1001);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  private void log(String paramString)
  {
    Rlog.d("SipService", paramString);
  }

  private void loge(String paramString, Throwable paramThrowable)
  {
    Rlog.e("SipService", paramString, paramThrowable);
  }

  private void notifyProfileAdded(SipProfile paramSipProfile)
  {
    log("notify: profile added: " + paramSipProfile);
    Intent localIntent = new Intent("com.android.phone.SIP_ADD_PHONE");
    localIntent.putExtra("android:localSipUri", paramSipProfile.getUriString());
    this.mContext.sendBroadcast(localIntent);
    if (this.mSipGroups.size() == 1)
      registerReceivers();
  }

  private void notifyProfileRemoved(SipProfile paramSipProfile)
  {
    log("notify: profile removed: " + paramSipProfile);
    Intent localIntent = new Intent("com.android.phone.SIP_REMOVE_PHONE");
    localIntent.putExtra("android:localSipUri", paramSipProfile.getUriString());
    this.mContext.sendBroadcast(localIntent);
    if (this.mSipGroups.size() == 0)
      unregisterReceivers();
  }

  private void onConnectivityChanged(NetworkInfo paramNetworkInfo)
  {
    if (paramNetworkInfo != null);
    while (true)
    {
      int i;
      try
      {
        if ((paramNetworkInfo.isConnected()) || (paramNetworkInfo.getType() != this.mNetworkType))
          paramNetworkInfo = ((ConnectivityManager)this.mContext.getSystemService("connectivity")).getActiveNetworkInfo();
        if ((paramNetworkInfo != null) && (paramNetworkInfo.isConnected()))
        {
          i = paramNetworkInfo.getType();
          if ((this.mSipOnWifiOnly) && (i != 1))
            i = -1;
          int j = this.mNetworkType;
          if (j != i);
        }
        else
        {
          i = -1;
          continue;
        }
        log("onConnectivityChanged: " + this.mNetworkType + " -> " + i);
        try
        {
          if (this.mNetworkType == -1)
            break label207;
          this.mLocalIp = null;
          stopPortMappingMeasurement();
          Iterator localIterator2 = this.mSipGroups.values().iterator();
          if (!localIterator2.hasNext())
            break label207;
          ((SipSessionGroupExt)localIterator2.next()).onConnectivityChanged(false);
          continue;
        }
        catch (SipException localSipException)
        {
          loge("onConnectivityChanged()", localSipException);
        }
        continue;
      }
      finally
      {
      }
      label207: this.mNetworkType = i;
      if (this.mNetworkType != -1)
      {
        this.mLocalIp = determineLocalIp();
        this.mKeepAliveInterval = -1;
        this.mLastGoodKeepAliveInterval = 10;
        Iterator localIterator1 = this.mSipGroups.values().iterator();
        while (localIterator1.hasNext())
          ((SipSessionGroupExt)localIterator1.next()).onConnectivityChanged(true);
      }
      updateWakeLocks();
    }
  }

  private void onKeepAliveIntervalChanged()
  {
    try
    {
      Iterator localIterator = this.mSipGroups.values().iterator();
      if (localIterator.hasNext())
        ((SipSessionGroupExt)localIterator.next()).onKeepAliveIntervalChanged();
    }
    finally
    {
    }
  }

  private void registerReceivers()
  {
    this.mContext.registerReceiver(this.mConnectivityReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    log("registerReceivers:");
  }

  private void restartPortMappingLifetimeMeasurement(SipProfile paramSipProfile, int paramInt)
  {
    stopPortMappingMeasurement();
    this.mKeepAliveInterval = -1;
    startPortMappingLifetimeMeasurement(paramSipProfile, paramInt);
  }

  private static void slog(String paramString)
  {
    Rlog.d("SipService", paramString);
  }

  public static void start(Context paramContext)
  {
    if (SipManager.isApiSupported(paramContext))
    {
      ServiceManager.addService("sip", new SipService(paramContext));
      paramContext.sendBroadcast(new Intent("android.net.sip.SIP_SERVICE_UP"));
      slog("start:");
    }
  }

  private void startPortMappingLifetimeMeasurement(SipProfile paramSipProfile)
  {
    startPortMappingLifetimeMeasurement(paramSipProfile, 120);
  }

  private void startPortMappingLifetimeMeasurement(SipProfile paramSipProfile, int paramInt)
  {
    if ((this.mSipKeepAliveProcessCallback == null) && (this.mKeepAliveInterval == -1) && (isBehindNAT(this.mLocalIp)))
    {
      log("startPortMappingLifetimeMeasurement: profile=" + paramSipProfile.getUriString());
      int i = this.mLastGoodKeepAliveInterval;
      if (i >= paramInt)
      {
        i = 10;
        this.mLastGoodKeepAliveInterval = i;
        log("  reset min interval to " + i);
      }
      this.mSipKeepAliveProcessCallback = new SipKeepAliveProcessCallback(paramSipProfile, i, paramInt);
      this.mSipKeepAliveProcessCallback.start();
    }
  }

  private void stopPortMappingMeasurement()
  {
    if (this.mSipKeepAliveProcessCallback != null)
    {
      this.mSipKeepAliveProcessCallback.stop();
      this.mSipKeepAliveProcessCallback = null;
    }
  }

  private void unregisterReceivers()
  {
    this.mContext.unregisterReceiver(this.mConnectivityReceiver);
    log("unregisterReceivers:");
    this.mWifiLock.release();
    this.mNetworkType = -1;
  }

  private void updateWakeLocks()
  {
    Iterator localIterator = this.mSipGroups.values().iterator();
    while (true)
      if (localIterator.hasNext())
        if (((SipSessionGroupExt)localIterator.next()).isOpenedToReceiveCalls())
          if ((this.mNetworkType == 1) || (this.mNetworkType == -1))
            this.mWifiLock.acquire();
    while (true)
    {
      return;
      this.mWifiLock.release();
      continue;
      this.mWifiLock.release();
      this.mMyWakeLock.reset();
    }
  }

  public void close(String paramString)
  {
    while (true)
    {
      try
      {
        this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
        SipSessionGroupExt localSipSessionGroupExt1 = (SipSessionGroupExt)this.mSipGroups.get(paramString);
        if (localSipSessionGroupExt1 == null)
          return;
        if (!isCallerCreatorOrRadio(localSipSessionGroupExt1))
        {
          log("only creator or radio can close this profile");
          continue;
        }
      }
      finally
      {
      }
      SipSessionGroupExt localSipSessionGroupExt2 = (SipSessionGroupExt)this.mSipGroups.remove(paramString);
      notifyProfileRemoved(localSipSessionGroupExt2.getLocalProfile());
      localSipSessionGroupExt2.close();
      updateWakeLocks();
    }
  }

  public ISipSession createSession(SipProfile paramSipProfile, ISipSessionListener paramISipSessionListener)
  {
    Object localObject1 = null;
    try
    {
      log("createSession: profile" + paramSipProfile);
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      paramSipProfile.setCallingUid(Binder.getCallingUid());
      if (this.mNetworkType == -1)
        log("createSession: mNetworkType==-1 ret=null");
      while (true)
      {
        return localObject1;
        try
        {
          ISipSession localISipSession = createGroup(paramSipProfile).createSession(paramISipSessionListener);
          localObject1 = localISipSession;
        }
        catch (SipException localSipException)
        {
          loge("createSession;", localSipException);
        }
      }
    }
    finally
    {
    }
  }

  public SipProfile[] getListOfProfiles()
  {
    ArrayList localArrayList;
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      boolean bool = isCallerRadio();
      localArrayList = new ArrayList();
      Iterator localIterator = this.mSipGroups.values().iterator();
      while (localIterator.hasNext())
      {
        SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)localIterator.next();
        if ((bool) || (isCallerCreator(localSipSessionGroupExt)))
          localArrayList.add(localSipSessionGroupExt.getLocalProfile());
      }
    }
    finally
    {
    }
    SipProfile[] arrayOfSipProfile = (SipProfile[])localArrayList.toArray(new SipProfile[localArrayList.size()]);
    return arrayOfSipProfile;
  }

  public ISipSession getPendingSession(String paramString)
  {
    ISipSession localISipSession = null;
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      if (paramString == null);
      while (true)
      {
        return localISipSession;
        localISipSession = (ISipSession)this.mPendingSessions.get(paramString);
      }
    }
    finally
    {
    }
  }

  public boolean isOpened(String paramString)
  {
    boolean bool = false;
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)this.mSipGroups.get(paramString);
      if (localSipSessionGroupExt == null);
      while (true)
      {
        return bool;
        if (isCallerCreatorOrRadio(localSipSessionGroupExt))
          bool = true;
        else
          log("only creator or radio can query on the profile");
      }
    }
    finally
    {
    }
  }

  public boolean isRegistered(String paramString)
  {
    boolean bool = false;
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)this.mSipGroups.get(paramString);
      if (localSipSessionGroupExt == null);
      while (true)
      {
        return bool;
        if (isCallerCreatorOrRadio(localSipSessionGroupExt))
          bool = localSipSessionGroupExt.isRegistered();
        else
          log("only creator or radio can query on the profile");
      }
    }
    finally
    {
    }
  }

  public void open(SipProfile paramSipProfile)
  {
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      paramSipProfile.setCallingUid(Binder.getCallingUid());
      try
      {
        createGroup(paramSipProfile);
        return;
      }
      catch (SipException localSipException)
      {
        while (true)
          loge("openToMakeCalls()", localSipException);
      }
    }
    finally
    {
    }
  }

  public void open3(SipProfile paramSipProfile, PendingIntent paramPendingIntent, ISipSessionListener paramISipSessionListener)
  {
    try
    {
      this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
      paramSipProfile.setCallingUid(Binder.getCallingUid());
      if (paramPendingIntent == null)
        log("open3: incomingCallPendingIntent cannot be null; the profile is not opened");
      while (true)
      {
        return;
        log("open3: " + paramSipProfile.getUriString() + ": " + paramPendingIntent + ": " + paramISipSessionListener);
        try
        {
          SipSessionGroupExt localSipSessionGroupExt = createGroup(paramSipProfile, paramPendingIntent, paramISipSessionListener);
          if (paramSipProfile.getAutoRegistration())
          {
            localSipSessionGroupExt.openToReceiveCalls();
            updateWakeLocks();
          }
        }
        catch (SipException localSipException)
        {
          loge("open3:", localSipException);
        }
      }
    }
    finally
    {
    }
  }

  public void setRegistrationListener(String paramString, ISipSessionListener paramISipSessionListener)
  {
    while (true)
    {
      try
      {
        this.mContext.enforceCallingOrSelfPermission("android.permission.USE_SIP", null);
        SipSessionGroupExt localSipSessionGroupExt = (SipSessionGroupExt)this.mSipGroups.get(paramString);
        if (localSipSessionGroupExt == null)
          return;
        if (isCallerCreator(localSipSessionGroupExt))
        {
          localSipSessionGroupExt.setListener(paramISipSessionListener);
          continue;
        }
      }
      finally
      {
      }
      log("only creator can set listener on the profile");
    }
  }

  private class ConnectivityReceiver extends BroadcastReceiver
  {
    private ConnectivityReceiver()
    {
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      Bundle localBundle = paramIntent.getExtras();
      if (localBundle != null)
      {
        final NetworkInfo localNetworkInfo = (NetworkInfo)localBundle.get("networkInfo");
        SipService.this.mExecutor.execute(new Runnable()
        {
          public void run()
          {
            SipService.this.onConnectivityChanged(localNetworkInfo);
          }
        });
      }
    }
  }

  private class MyExecutor extends Handler
    implements Executor
  {
    MyExecutor()
    {
      super();
    }

    private void executeInternal(Runnable paramRunnable)
    {
      try
      {
        paramRunnable.run();
        localSipWakeLock = SipService.this.mMyWakeLock;
        localSipWakeLock.release(paramRunnable);
        return;
      }
      catch (Throwable localThrowable)
      {
        while (true)
        {
          SipService.this.loge("run task: " + paramRunnable, localThrowable);
          SipWakeLock localSipWakeLock = SipService.this.mMyWakeLock;
        }
      }
      finally
      {
        SipService.this.mMyWakeLock.release(paramRunnable);
      }
    }

    public void execute(Runnable paramRunnable)
    {
      SipService.this.mMyWakeLock.acquire(paramRunnable);
      Message.obtain(this, 0, paramRunnable).sendToTarget();
    }

    public void handleMessage(Message paramMessage)
    {
      if ((paramMessage.obj instanceof Runnable))
        executeInternal((Runnable)paramMessage.obj);
      while (true)
      {
        return;
        SipService.this.log("handleMessage: not Runnable ignore msg=" + paramMessage);
      }
    }
  }

  private class SipAutoReg extends SipSessionAdapter
    implements Runnable, SipSessionGroup.KeepAliveProcessCallback
  {
    private static final int MIN_KEEPALIVE_SUCCESS_COUNT = 10;
    private static final boolean SAR_DBG = true;
    private String SAR_TAG;
    private int mBackoff = 1;
    private int mErrorCode;
    private String mErrorMessage;
    private long mExpiryTime;
    private SipSessionGroup.SipSessionImpl mKeepAliveSession;
    private int mKeepAliveSuccessCount = 0;
    private SipSessionListenerProxy mProxy = new SipSessionListenerProxy();
    private boolean mRegistered;
    private boolean mRunning = false;
    private SipSessionGroup.SipSessionImpl mSession;

    private SipAutoReg()
    {
    }

    private int backoffDuration()
    {
      int i = 10 * this.mBackoff;
      if (i > 3600)
        i = 3600;
      while (true)
      {
        return i;
        this.mBackoff = (2 * this.mBackoff);
      }
    }

    private void log(String paramString)
    {
      Rlog.d(this.SAR_TAG, paramString);
    }

    private void loge(String paramString)
    {
      Rlog.e(this.SAR_TAG, paramString);
    }

    private void loge(String paramString, Throwable paramThrowable)
    {
      Rlog.e(this.SAR_TAG, paramString, paramThrowable);
    }

    private boolean notCurrentSession(ISipSession paramISipSession)
    {
      boolean bool1 = true;
      if (paramISipSession != this.mSession)
      {
        ((SipSessionGroup.SipSessionImpl)paramISipSession).setListener(null);
        SipService.this.mMyWakeLock.release(paramISipSession);
        return bool1;
      }
      if (!this.mRunning);
      for (boolean bool2 = bool1; ; bool2 = false)
      {
        bool1 = bool2;
        break;
      }
    }

    private void restart(int paramInt)
    {
      log("restart: duration=" + paramInt + "s later.");
      SipService.this.mTimer.cancel(this);
      SipService.this.mTimer.set(paramInt * 1000, this);
    }

    private void restartLater()
    {
      loge("restartLater");
      this.mRegistered = false;
      restart(backoffDuration());
    }

    private void startKeepAliveProcess(int paramInt)
    {
      log("startKeepAliveProcess: interval=" + paramInt);
      if (this.mKeepAliveSession == null)
        this.mKeepAliveSession = this.mSession.duplicate();
      try
      {
        while (true)
        {
          this.mKeepAliveSession.startKeepAliveProcess(paramInt, this);
          return;
          this.mKeepAliveSession.stopKeepAliveProcess();
        }
      }
      catch (SipException localSipException)
      {
        while (true)
          loge("startKeepAliveProcess: interval=" + paramInt, localSipException);
      }
    }

    private void stopKeepAliveProcess()
    {
      if (this.mKeepAliveSession != null)
      {
        this.mKeepAliveSession.stopKeepAliveProcess();
        this.mKeepAliveSession = null;
      }
      this.mKeepAliveSuccessCount = 0;
    }

    public boolean isRegistered()
    {
      return this.mRegistered;
    }

    public void onError(int paramInt, String paramString)
    {
      loge("onError: errorCode=" + paramInt + " desc=" + paramString);
      onResponse(true);
    }

    public void onKeepAliveIntervalChanged()
    {
      if (this.mKeepAliveSession != null)
      {
        int i = SipService.this.getKeepAliveInterval();
        log("onKeepAliveIntervalChanged: interval=" + i);
        this.mKeepAliveSuccessCount = 0;
        startKeepAliveProcess(i);
      }
    }

    public void onRegistering(ISipSession paramISipSession)
    {
      log("onRegistering: " + paramISipSession);
      synchronized (SipService.this)
      {
        if (!notCurrentSession(paramISipSession))
        {
          this.mRegistered = false;
          this.mProxy.onRegistering(paramISipSession);
        }
      }
    }

    // ERROR //
    public void onRegistrationDone(ISipSession paramISipSession, int paramInt)
    {
      // Byte code:
      //   0: aload_0
      //   1: new 98	java/lang/StringBuilder
      //   4: dup
      //   5: invokespecial 99	java/lang/StringBuilder:<init>	()V
      //   8: ldc 195
      //   10: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   13: aload_1
      //   14: invokevirtual 187	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   17: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   20: invokespecial 116	com/android/server/sip/SipService$SipAutoReg:log	(Ljava/lang/String;)V
      //   23: aload_0
      //   24: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   27: astore_3
      //   28: aload_3
      //   29: monitorenter
      //   30: aload_0
      //   31: aload_1
      //   32: invokespecial 189	com/android/server/sip/SipService$SipAutoReg:notCurrentSession	(Landroid/net/sip/ISipSession;)Z
      //   35: ifeq +8 -> 43
      //   38: aload_3
      //   39: monitorexit
      //   40: goto +165 -> 205
      //   43: aload_0
      //   44: getfield 43	com/android/server/sip/SipService$SipAutoReg:mProxy	Lcom/android/server/sip/SipSessionListenerProxy;
      //   47: aload_1
      //   48: iload_2
      //   49: invokevirtual 197	com/android/server/sip/SipSessionListenerProxy:onRegistrationDone	(Landroid/net/sip/ISipSession;I)V
      //   52: iload_2
      //   53: ifle +127 -> 180
      //   56: aload_0
      //   57: invokestatic 203	android/os/SystemClock:elapsedRealtime	()J
      //   60: iload_2
      //   61: sipush 1000
      //   64: imul
      //   65: i2l
      //   66: ladd
      //   67: putfield 205	com/android/server/sip/SipService$SipAutoReg:mExpiryTime	J
      //   70: aload_0
      //   71: getfield 136	com/android/server/sip/SipService$SipAutoReg:mRegistered	Z
      //   74: ifne +83 -> 157
      //   77: aload_0
      //   78: iconst_1
      //   79: putfield 136	com/android/server/sip/SipService$SipAutoReg:mRegistered	Z
      //   82: iload_2
      //   83: bipush 60
      //   85: isub
      //   86: istore 5
      //   88: iload 5
      //   90: bipush 60
      //   92: if_icmpge +7 -> 99
      //   95: bipush 60
      //   97: istore 5
      //   99: aload_0
      //   100: iload 5
      //   102: invokespecial 140	com/android/server/sip/SipService$SipAutoReg:restart	(I)V
      //   105: aload_0
      //   106: getfield 76	com/android/server/sip/SipService$SipAutoReg:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   109: invokevirtual 209	com/android/server/sip/SipSessionGroup$SipSessionImpl:getLocalProfile	()Landroid/net/sip/SipProfile;
      //   112: astore 6
      //   114: aload_0
      //   115: getfield 147	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   118: ifnonnull +39 -> 157
      //   121: aload_0
      //   122: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   125: aload_0
      //   126: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   129: invokestatic 213	com/android/server/sip/SipService:access$1500	(Lcom/android/server/sip/SipService;)Ljava/lang/String;
      //   132: invokestatic 217	com/android/server/sip/SipService:access$1600	(Lcom/android/server/sip/SipService;Ljava/lang/String;)Z
      //   135: ifne +11 -> 146
      //   138: aload 6
      //   140: invokevirtual 222	android/net/sip/SipProfile:getSendKeepAlive	()Z
      //   143: ifeq +14 -> 157
      //   146: aload_0
      //   147: aload_0
      //   148: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   151: invokestatic 176	com/android/server/sip/SipService:access$1200	(Lcom/android/server/sip/SipService;)I
      //   154: invokespecial 180	com/android/server/sip/SipService$SipAutoReg:startKeepAliveProcess	(I)V
      //   157: aload_0
      //   158: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   161: invokestatic 88	com/android/server/sip/SipService:access$300	(Lcom/android/server/sip/SipService;)Lcom/android/server/sip/SipWakeLock;
      //   164: aload_1
      //   165: invokevirtual 94	com/android/server/sip/SipWakeLock:release	(Ljava/lang/Object;)V
      //   168: aload_3
      //   169: monitorexit
      //   170: goto +35 -> 205
      //   173: astore 4
      //   175: aload_3
      //   176: monitorexit
      //   177: aload 4
      //   179: athrow
      //   180: aload_0
      //   181: iconst_0
      //   182: putfield 136	com/android/server/sip/SipService$SipAutoReg:mRegistered	Z
      //   185: aload_0
      //   186: ldc2_w 223
      //   189: putfield 205	com/android/server/sip/SipService$SipAutoReg:mExpiryTime	J
      //   192: aload_0
      //   193: ldc 226
      //   195: invokespecial 116	com/android/server/sip/SipService$SipAutoReg:log	(Ljava/lang/String;)V
      //   198: aload_0
      //   199: invokevirtual 229	com/android/server/sip/SipService$SipAutoReg:run	()V
      //   202: goto -34 -> 168
      //   205: return
      //
      // Exception table:
      //   from	to	target	type
      //   30	177	173	finally
      //   180	202	173	finally
    }

    public void onRegistrationFailed(ISipSession paramISipSession, int paramInt, String paramString)
    {
      log("onRegistrationFailed: " + paramISipSession + ": " + SipErrorCode.toString(paramInt) + ": " + paramString);
      label129: synchronized (SipService.this)
      {
        if (notCurrentSession(paramISipSession))
        {
          break label129;
          restartLater();
          this.mErrorCode = paramInt;
          this.mErrorMessage = paramString;
          this.mProxy.onRegistrationFailed(paramISipSession, paramInt, paramString);
          SipService.this.mMyWakeLock.release(paramISipSession);
        }
      }
      switch (paramInt)
      {
      default:
      case -12:
      case -8:
      }
    }

    public void onRegistrationTimeout(ISipSession paramISipSession)
    {
      log("onRegistrationTimeout: " + paramISipSession);
      synchronized (SipService.this)
      {
        if (!notCurrentSession(paramISipSession))
        {
          this.mErrorCode = -5;
          this.mProxy.onRegistrationTimeout(paramISipSession);
          restartLater();
          SipService.this.mMyWakeLock.release(paramISipSession);
        }
      }
    }

    // ERROR //
    public void onResponse(boolean paramBoolean)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   4: astore_2
      //   5: aload_2
      //   6: monitorenter
      //   7: iload_1
      //   8: ifeq +159 -> 167
      //   11: aload_0
      //   12: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   15: invokestatic 176	com/android/server/sip/SipService:access$1200	(Lcom/android/server/sip/SipService;)I
      //   18: istore 4
      //   20: aload_0
      //   21: getfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   24: bipush 10
      //   26: if_icmpge +85 -> 111
      //   29: aload_0
      //   30: new 98	java/lang/StringBuilder
      //   33: dup
      //   34: invokespecial 99	java/lang/StringBuilder:<init>	()V
      //   37: ldc_w 260
      //   40: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   43: iload 4
      //   45: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   48: ldc_w 262
      //   51: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   54: aload_0
      //   55: getfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   58: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   61: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   64: invokespecial 116	com/android/server/sip/SipService$SipAutoReg:log	(Ljava/lang/String;)V
      //   67: iload 4
      //   69: bipush 10
      //   71: if_icmple +24 -> 95
      //   74: aload_0
      //   75: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   78: aload_0
      //   79: getfield 76	com/android/server/sip/SipService$SipAutoReg:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   82: invokevirtual 209	com/android/server/sip/SipSessionGroup$SipSessionImpl:getLocalProfile	()Landroid/net/sip/SipProfile;
      //   85: iload 4
      //   87: invokestatic 266	com/android/server/sip/SipService:access$1300	(Lcom/android/server/sip/SipService;Landroid/net/sip/SipProfile;I)V
      //   90: aload_0
      //   91: iconst_0
      //   92: putfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   95: aload_0
      //   96: getfield 47	com/android/server/sip/SipService$SipAutoReg:mRunning	Z
      //   99: ifeq +7 -> 106
      //   102: iload_1
      //   103: ifne +91 -> 194
      //   106: aload_2
      //   107: monitorexit
      //   108: goto +117 -> 225
      //   111: aload_0
      //   112: new 98	java/lang/StringBuilder
      //   115: dup
      //   116: invokespecial 99	java/lang/StringBuilder:<init>	()V
      //   119: ldc_w 268
      //   122: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   125: iload 4
      //   127: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   130: ldc_w 262
      //   133: invokevirtual 105	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   136: aload_0
      //   137: getfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   140: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   143: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   146: invokespecial 116	com/android/server/sip/SipService$SipAutoReg:log	(Ljava/lang/String;)V
      //   149: aload_0
      //   150: aload_0
      //   151: getfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   154: iconst_2
      //   155: idiv
      //   156: putfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   159: goto -64 -> 95
      //   162: astore_3
      //   163: aload_2
      //   164: monitorexit
      //   165: aload_3
      //   166: athrow
      //   167: aload_0
      //   168: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   171: aload_0
      //   172: getfield 76	com/android/server/sip/SipService$SipAutoReg:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   175: invokevirtual 209	com/android/server/sip/SipSessionGroup$SipSessionImpl:getLocalProfile	()Landroid/net/sip/SipProfile;
      //   178: invokestatic 272	com/android/server/sip/SipService:access$1400	(Lcom/android/server/sip/SipService;Landroid/net/sip/SipProfile;)V
      //   181: aload_0
      //   182: iconst_1
      //   183: aload_0
      //   184: getfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   187: iadd
      //   188: putfield 49	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSuccessCount	I
      //   191: goto -96 -> 95
      //   194: aload_0
      //   195: aconst_null
      //   196: putfield 147	com/android/server/sip/SipService$SipAutoReg:mKeepAliveSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   199: aload_0
      //   200: getfield 35	com/android/server/sip/SipService$SipAutoReg:this$0	Lcom/android/server/sip/SipService;
      //   203: invokestatic 88	com/android/server/sip/SipService:access$300	(Lcom/android/server/sip/SipService;)Lcom/android/server/sip/SipWakeLock;
      //   206: aload_0
      //   207: getfield 76	com/android/server/sip/SipService$SipAutoReg:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   210: invokevirtual 275	com/android/server/sip/SipWakeLock:acquire	(Ljava/lang/Object;)V
      //   213: aload_0
      //   214: getfield 76	com/android/server/sip/SipService$SipAutoReg:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   217: sipush 3600
      //   220: invokevirtual 278	com/android/server/sip/SipSessionGroup$SipSessionImpl:register	(I)V
      //   223: aload_2
      //   224: monitorexit
      //   225: return
      //
      // Exception table:
      //   from	to	target	type
      //   11	165	162	finally
      //   167	225	162	finally
    }

    public void run()
    {
      synchronized (SipService.this)
      {
        if (this.mRunning)
        {
          this.mErrorCode = 0;
          this.mErrorMessage = null;
          log("run: registering");
          if (SipService.this.mNetworkType != -1)
          {
            SipService.this.mMyWakeLock.acquire(this.mSession);
            this.mSession.register(3600);
          }
        }
      }
    }

    public void setListener(ISipSessionListener paramISipSessionListener)
    {
      while (true)
      {
        int i;
        synchronized (SipService.this)
        {
          this.mProxy.setListener(paramISipSessionListener);
          try
          {
            if (this.mSession == null)
            {
              i = 0;
              break label236;
              this.mProxy.onRegistering(this.mSession);
              return;
            }
            i = this.mSession.getState();
            break label236;
            if (this.mRegistered)
            {
              int j = (int)(this.mExpiryTime - SystemClock.elapsedRealtime());
              this.mProxy.onRegistrationDone(this.mSession, j);
              continue;
            }
          }
          catch (Throwable localThrowable)
          {
            loge("setListener: ", localThrowable);
            continue;
          }
        }
        if (this.mErrorCode != 0)
        {
          if (this.mErrorCode == -5)
            this.mProxy.onRegistrationTimeout(this.mSession);
          else
            this.mProxy.onRegistrationFailed(this.mSession, this.mErrorCode, this.mErrorMessage);
        }
        else if (SipService.this.mNetworkType == -1)
        {
          this.mProxy.onRegistrationFailed(this.mSession, -10, "no data connection");
        }
        else if (!this.mRunning)
        {
          this.mProxy.onRegistrationFailed(this.mSession, -4, "registration not running");
        }
        else
        {
          this.mProxy.onRegistrationFailed(this.mSession, -9, String.valueOf(i));
          continue;
          label236: if (i != 1)
            if (i != 2);
        }
      }
    }

    public void start(SipSessionGroup paramSipSessionGroup)
    {
      if (!this.mRunning)
      {
        this.mRunning = true;
        this.mBackoff = 1;
        this.mSession = ((SipSessionGroup.SipSessionImpl)paramSipSessionGroup.createSession(this));
        if (this.mSession != null)
          break label37;
      }
      while (true)
      {
        return;
        label37: SipService.this.mMyWakeLock.acquire(this.mSession);
        this.mSession.unregister();
        this.SAR_TAG = ("SipAutoReg:" + this.mSession.getLocalProfile().getUriString());
        log("start: group=" + paramSipSessionGroup);
      }
    }

    public void stop()
    {
      if (!this.mRunning);
      while (true)
      {
        return;
        this.mRunning = false;
        SipService.this.mMyWakeLock.release(this.mSession);
        if (this.mSession != null)
        {
          this.mSession.setListener(null);
          if ((SipService.this.mNetworkType != -1) && (this.mRegistered))
            this.mSession.unregister();
        }
        SipService.this.mTimer.cancel(this);
        stopKeepAliveProcess();
        this.mRegistered = false;
        setListener(this.mProxy.getListener());
      }
    }
  }

  private class SipKeepAliveProcessCallback
    implements Runnable, SipSessionGroup.KeepAliveProcessCallback
  {
    private static final int MIN_INTERVAL = 5;
    private static final int NAT_MEASUREMENT_RETRY_INTERVAL = 120;
    private static final int PASS_THRESHOLD = 10;
    private static final boolean SKAI_DBG = true;
    private static final String SKAI_TAG = "SipKeepAliveProcessCallback";
    private SipService.SipSessionGroupExt mGroup;
    private int mInterval;
    private SipProfile mLocalProfile;
    private int mMaxInterval;
    private int mMinInterval;
    private int mPassCount;
    private SipSessionGroup.SipSessionImpl mSession;

    public SipKeepAliveProcessCallback(SipProfile paramInt1, int paramInt2, int arg4)
    {
      int i;
      this.mMaxInterval = i;
      this.mMinInterval = paramInt2;
      this.mLocalProfile = paramInt1;
    }

    private boolean checkTermination()
    {
      if (this.mMaxInterval - this.mMinInterval < 5);
      for (boolean bool = true; ; bool = false)
        return bool;
    }

    private void log(String paramString)
    {
      Rlog.d("SipKeepAliveProcessCallback", paramString);
    }

    private void loge(String paramString)
    {
      Rlog.d("SipKeepAliveProcessCallback", paramString);
    }

    private void loge(String paramString, Throwable paramThrowable)
    {
      Rlog.d("SipKeepAliveProcessCallback", paramString, paramThrowable);
    }

    private void restart()
    {
      synchronized (SipService.this)
      {
        if (this.mSession == null)
          return;
        log("restart: interval=" + this.mInterval);
      }
      try
      {
        this.mSession.stopKeepAliveProcess();
        this.mPassCount = 0;
        this.mSession.startKeepAliveProcess(this.mInterval, this);
        return;
        localObject = finally;
        throw localObject;
      }
      catch (SipException localSipException)
      {
        while (true)
          loge("restart", localSipException);
      }
    }

    private void restartLater()
    {
      synchronized (SipService.this)
      {
        SipService.this.mTimer.cancel(this);
        SipService.this.mTimer.set(120000, this);
        return;
      }
    }

    public void onError(int paramInt, String paramString)
    {
      loge("onError: errorCode=" + paramInt + " desc=" + paramString);
      restartLater();
    }

    // ERROR //
    public void onResponse(boolean paramBoolean)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   4: astore_2
      //   5: aload_2
      //   6: monitorenter
      //   7: iload_1
      //   8: ifne +187 -> 195
      //   11: iconst_1
      //   12: aload_0
      //   13: getfield 94	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mPassCount	I
      //   16: iadd
      //   17: istore 5
      //   19: aload_0
      //   20: iload 5
      //   22: putfield 94	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mPassCount	I
      //   25: iload 5
      //   27: bipush 10
      //   29: if_icmpeq +8 -> 37
      //   32: aload_2
      //   33: monitorexit
      //   34: goto +235 -> 269
      //   37: aload_0
      //   38: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   41: invokestatic 135	com/android/server/sip/SipService:access$900	(Lcom/android/server/sip/SipService;)I
      //   44: ifle +18 -> 62
      //   47: aload_0
      //   48: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   51: aload_0
      //   52: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   55: invokestatic 135	com/android/server/sip/SipService:access$900	(Lcom/android/server/sip/SipService;)I
      //   58: invokestatic 139	com/android/server/sip/SipService:access$1002	(Lcom/android/server/sip/SipService;I)I
      //   61: pop
      //   62: aload_0
      //   63: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   66: astore 6
      //   68: aload_0
      //   69: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   72: istore 7
      //   74: aload_0
      //   75: iload 7
      //   77: putfield 45	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMinInterval	I
      //   80: aload 6
      //   82: iload 7
      //   84: invokestatic 142	com/android/server/sip/SipService:access$902	(Lcom/android/server/sip/SipService;I)I
      //   87: pop
      //   88: aload_0
      //   89: new 69	java/lang/StringBuilder
      //   92: dup
      //   93: invokespecial 70	java/lang/StringBuilder:<init>	()V
      //   96: ldc 144
      //   98: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   101: iload_1
      //   102: invokevirtual 147	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
      //   105: ldc 149
      //   107: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   110: aload_0
      //   111: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   114: invokestatic 135	com/android/server/sip/SipService:access$900	(Lcom/android/server/sip/SipService;)I
      //   117: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   120: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   123: invokespecial 87	com/android/server/sip/SipService$SipKeepAliveProcessCallback:log	(Ljava/lang/String;)V
      //   126: aload_0
      //   127: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   130: invokestatic 153	com/android/server/sip/SipService:access$1100	(Lcom/android/server/sip/SipService;)V
      //   133: aload_0
      //   134: invokespecial 155	com/android/server/sip/SipService$SipKeepAliveProcessCallback:checkTermination	()Z
      //   137: ifeq +69 -> 206
      //   140: aload_0
      //   141: invokevirtual 158	com/android/server/sip/SipService$SipKeepAliveProcessCallback:stop	()V
      //   144: aload_0
      //   145: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   148: aload_0
      //   149: getfield 45	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMinInterval	I
      //   152: invokestatic 142	com/android/server/sip/SipService:access$902	(Lcom/android/server/sip/SipService;I)I
      //   155: pop
      //   156: aload_0
      //   157: new 69	java/lang/StringBuilder
      //   160: dup
      //   161: invokespecial 70	java/lang/StringBuilder:<init>	()V
      //   164: ldc 160
      //   166: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   169: aload_0
      //   170: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   173: invokestatic 135	com/android/server/sip/SipService:access$900	(Lcom/android/server/sip/SipService;)I
      //   176: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   179: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   182: invokespecial 87	com/android/server/sip/SipService$SipKeepAliveProcessCallback:log	(Ljava/lang/String;)V
      //   185: aload_2
      //   186: monitorexit
      //   187: goto +82 -> 269
      //   190: astore_3
      //   191: aload_2
      //   192: monitorexit
      //   193: aload_3
      //   194: athrow
      //   195: aload_0
      //   196: aload_0
      //   197: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   200: putfield 43	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMaxInterval	I
      //   203: goto -70 -> 133
      //   206: aload_0
      //   207: aload_0
      //   208: getfield 43	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMaxInterval	I
      //   211: aload_0
      //   212: getfield 45	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMinInterval	I
      //   215: iadd
      //   216: iconst_2
      //   217: idiv
      //   218: putfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   221: aload_0
      //   222: new 69	java/lang/StringBuilder
      //   225: dup
      //   226: invokespecial 70	java/lang/StringBuilder:<init>	()V
      //   229: ldc 162
      //   231: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   234: aload_0
      //   235: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   238: invokestatic 135	com/android/server/sip/SipService:access$900	(Lcom/android/server/sip/SipService;)I
      //   241: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   244: ldc 164
      //   246: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   249: aload_0
      //   250: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   253: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   256: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   259: invokespecial 87	com/android/server/sip/SipService$SipKeepAliveProcessCallback:log	(Ljava/lang/String;)V
      //   262: aload_0
      //   263: invokespecial 166	com/android/server/sip/SipService$SipKeepAliveProcessCallback:restart	()V
      //   266: goto -81 -> 185
      //   269: return
      //
      // Exception table:
      //   from	to	target	type
      //   11	193	190	finally
      //   195	266	190	finally
    }

    public void run()
    {
      SipService.this.mTimer.cancel(this);
      restart();
    }

    // ERROR //
    public void start()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   4: astore_1
      //   5: aload_1
      //   6: monitorenter
      //   7: aload_0
      //   8: getfield 67	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   11: ifnull +8 -> 19
      //   14: aload_1
      //   15: monitorexit
      //   16: goto +213 -> 229
      //   19: aload_0
      //   20: aload_0
      //   21: getfield 43	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMaxInterval	I
      //   24: aload_0
      //   25: getfield 45	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMinInterval	I
      //   28: iadd
      //   29: iconst_2
      //   30: idiv
      //   31: putfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   34: aload_0
      //   35: iconst_0
      //   36: putfield 94	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mPassCount	I
      //   39: aload_0
      //   40: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   43: bipush 10
      //   45: if_icmplt +10 -> 55
      //   48: aload_0
      //   49: invokespecial 155	com/android/server/sip/SipService$SipKeepAliveProcessCallback:checkTermination	()Z
      //   52: ifeq +56 -> 108
      //   55: aload_0
      //   56: new 69	java/lang/StringBuilder
      //   59: dup
      //   60: invokespecial 70	java/lang/StringBuilder:<init>	()V
      //   63: ldc 172
      //   65: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   68: aload_0
      //   69: getfield 45	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMinInterval	I
      //   72: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   75: ldc 174
      //   77: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   80: aload_0
      //   81: getfield 43	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mMaxInterval	I
      //   84: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   87: ldc 176
      //   89: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   92: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   95: invokespecial 87	com/android/server/sip/SipService$SipKeepAliveProcessCallback:log	(Ljava/lang/String;)V
      //   98: aload_1
      //   99: monitorexit
      //   100: goto +129 -> 229
      //   103: astore_2
      //   104: aload_1
      //   105: monitorexit
      //   106: aload_2
      //   107: athrow
      //   108: aload_0
      //   109: new 69	java/lang/StringBuilder
      //   112: dup
      //   113: invokespecial 70	java/lang/StringBuilder:<init>	()V
      //   116: ldc 178
      //   118: invokevirtual 76	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   121: aload_0
      //   122: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   125: invokevirtual 81	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
      //   128: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   131: invokespecial 87	com/android/server/sip/SipService$SipKeepAliveProcessCallback:log	(Ljava/lang/String;)V
      //   134: aload_0
      //   135: new 180	com/android/server/sip/SipService$SipSessionGroupExt
      //   138: dup
      //   139: aload_0
      //   140: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   143: aload_0
      //   144: getfield 47	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mLocalProfile	Landroid/net/sip/SipProfile;
      //   147: aconst_null
      //   148: aconst_null
      //   149: invokespecial 183	com/android/server/sip/SipService$SipSessionGroupExt:<init>	(Lcom/android/server/sip/SipService;Landroid/net/sip/SipProfile;Landroid/app/PendingIntent;Landroid/net/sip/ISipSessionListener;)V
      //   152: putfield 185	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mGroup	Lcom/android/server/sip/SipService$SipSessionGroupExt;
      //   155: aload_0
      //   156: getfield 185	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mGroup	Lcom/android/server/sip/SipService$SipSessionGroupExt;
      //   159: new 110	com/android/server/sip/SipWakeupTimer
      //   162: dup
      //   163: aload_0
      //   164: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   167: invokestatic 189	com/android/server/sip/SipService:access$700	(Lcom/android/server/sip/SipService;)Landroid/content/Context;
      //   170: aload_0
      //   171: getfield 38	com/android/server/sip/SipService$SipKeepAliveProcessCallback:this$0	Lcom/android/server/sip/SipService;
      //   174: invokestatic 193	com/android/server/sip/SipService:access$800	(Lcom/android/server/sip/SipService;)Lcom/android/server/sip/SipService$MyExecutor;
      //   177: invokespecial 196	com/android/server/sip/SipWakeupTimer:<init>	(Landroid/content/Context;Ljava/util/concurrent/Executor;)V
      //   180: invokevirtual 200	com/android/server/sip/SipService$SipSessionGroupExt:setWakeupTimer	(Lcom/android/server/sip/SipWakeupTimer;)V
      //   183: aload_0
      //   184: aload_0
      //   185: getfield 185	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mGroup	Lcom/android/server/sip/SipService$SipSessionGroupExt;
      //   188: aconst_null
      //   189: invokevirtual 204	com/android/server/sip/SipService$SipSessionGroupExt:createSession	(Landroid/net/sip/ISipSessionListener;)Landroid/net/sip/ISipSession;
      //   192: checkcast 89	com/android/server/sip/SipSessionGroup$SipSessionImpl
      //   195: putfield 67	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   198: aload_0
      //   199: getfield 67	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mSession	Lcom/android/server/sip/SipSessionGroup$SipSessionImpl;
      //   202: aload_0
      //   203: getfield 78	com/android/server/sip/SipService$SipKeepAliveProcessCallback:mInterval	I
      //   206: aload_0
      //   207: invokevirtual 98	com/android/server/sip/SipSessionGroup$SipSessionImpl:startKeepAliveProcess	(ILcom/android/server/sip/SipSessionGroup$KeepAliveProcessCallback;)V
      //   210: aload_1
      //   211: monitorexit
      //   212: goto +17 -> 229
      //   215: astore_3
      //   216: aload_0
      //   217: bipush 252
      //   219: aload_3
      //   220: invokevirtual 205	java/lang/Throwable:toString	()Ljava/lang/String;
      //   223: invokevirtual 207	com/android/server/sip/SipService$SipKeepAliveProcessCallback:onError	(ILjava/lang/String;)V
      //   226: goto -16 -> 210
      //   229: return
      //
      // Exception table:
      //   from	to	target	type
      //   7	106	103	finally
      //   108	210	103	finally
      //   210	226	103	finally
      //   108	210	215	java/lang/Throwable
    }

    public void stop()
    {
      synchronized (SipService.this)
      {
        if (this.mSession != null)
        {
          this.mSession.stopKeepAliveProcess();
          this.mSession = null;
        }
        if (this.mGroup != null)
        {
          this.mGroup.close();
          this.mGroup = null;
        }
        SipService.this.mTimer.cancel(this);
        log("stop");
        return;
      }
    }
  }

  private class SipSessionGroupExt extends SipSessionAdapter
  {
    private static final boolean SSGE_DBG = true;
    private static final String SSGE_TAG = "SipSessionGroupExt";
    private SipService.SipAutoReg mAutoRegistration = new SipService.SipAutoReg(SipService.this, null);
    private PendingIntent mIncomingCallPendingIntent;
    private boolean mOpenedToReceiveCalls;
    private SipSessionGroup mSipGroup;

    public SipSessionGroupExt(SipProfile paramPendingIntent, PendingIntent paramISipSessionListener, ISipSessionListener arg4)
      throws SipException
    {
      log("SipSessionGroupExt: profile=" + paramPendingIntent);
      this.mSipGroup = new SipSessionGroup(duplicate(paramPendingIntent), paramPendingIntent.getPassword(), SipService.this.mTimer, SipService.this.mMyWakeLock);
      this.mIncomingCallPendingIntent = paramISipSessionListener;
      ISipSessionListener localISipSessionListener;
      this.mAutoRegistration.setListener(localISipSessionListener);
    }

    private SipProfile duplicate(SipProfile paramSipProfile)
    {
      try
      {
        SipProfile localSipProfile = new SipProfile.Builder(paramSipProfile).setPassword("*").build();
        return localSipProfile;
      }
      catch (Exception localException)
      {
        loge("duplicate()", localException);
        throw new RuntimeException("duplicate profile", localException);
      }
    }

    private String getUri()
    {
      return this.mSipGroup.getLocalProfileUri();
    }

    private void log(String paramString)
    {
      Rlog.d("SipSessionGroupExt", paramString);
    }

    private void loge(String paramString, Throwable paramThrowable)
    {
      Rlog.e("SipSessionGroupExt", paramString, paramThrowable);
    }

    public void close()
    {
      this.mOpenedToReceiveCalls = false;
      this.mSipGroup.close();
      this.mAutoRegistration.stop();
      log("close: " + getUri() + ": " + this.mIncomingCallPendingIntent);
    }

    public boolean containsSession(String paramString)
    {
      return this.mSipGroup.containsSession(paramString);
    }

    public ISipSession createSession(ISipSessionListener paramISipSessionListener)
    {
      log("createSession");
      return this.mSipGroup.createSession(paramISipSessionListener);
    }

    public SipProfile getLocalProfile()
    {
      return this.mSipGroup.getLocalProfile();
    }

    public boolean isOpenedToReceiveCalls()
    {
      return this.mOpenedToReceiveCalls;
    }

    public boolean isRegistered()
    {
      return this.mAutoRegistration.isRegistered();
    }

    public void onConnectivityChanged(boolean paramBoolean)
      throws SipException
    {
      log("onConnectivityChanged: connected=" + paramBoolean + " uri=" + getUri() + ": " + this.mIncomingCallPendingIntent);
      this.mSipGroup.onConnectivityChanged();
      if (paramBoolean)
      {
        this.mSipGroup.reset();
        if (this.mOpenedToReceiveCalls)
          openToReceiveCalls();
      }
      while (true)
      {
        return;
        this.mSipGroup.close();
        this.mAutoRegistration.stop();
      }
    }

    public void onError(ISipSession paramISipSession, int paramInt, String paramString)
    {
      log("onError: errorCode=" + paramInt + " desc=" + SipErrorCode.toString(paramInt) + ": " + paramString);
    }

    public void onKeepAliveIntervalChanged()
    {
      this.mAutoRegistration.onKeepAliveIntervalChanged();
    }

    public void onRinging(ISipSession paramISipSession, SipProfile paramSipProfile, String paramString)
    {
      SipSessionGroup.SipSessionImpl localSipSessionImpl = (SipSessionGroup.SipSessionImpl)paramISipSession;
      try
      {
        synchronized (SipService.this)
        {
          if ((!isRegistered()) || (SipService.this.callingSelf(this, localSipSessionImpl)))
          {
            log("onRinging: end notReg or self");
            localSipSessionImpl.endCall();
            return;
          }
          SipService.this.addPendingSession(localSipSessionImpl);
          Intent localIntent = SipManager.createIncomingCallBroadcast(localSipSessionImpl.getCallId(), paramString);
          log("onRinging: uri=" + getUri() + ": " + paramSipProfile.getUri() + ": " + localSipSessionImpl.getCallId() + " " + this.mIncomingCallPendingIntent);
          this.mIncomingCallPendingIntent.send(SipService.this.mContext, 101, localIntent);
        }
      }
      catch (PendingIntent.CanceledException localCanceledException)
      {
        while (true)
        {
          loge("onRinging: pendingIntent is canceled, drop incoming call", localCanceledException);
          localSipSessionImpl.endCall();
        }
      }
    }

    public void openToReceiveCalls()
      throws SipException
    {
      this.mOpenedToReceiveCalls = true;
      if (SipService.this.mNetworkType != -1)
      {
        this.mSipGroup.openToReceiveCalls(this);
        this.mAutoRegistration.start(this.mSipGroup);
      }
      log("openToReceiveCalls: " + getUri() + ": " + this.mIncomingCallPendingIntent);
    }

    public void setIncomingCallPendingIntent(PendingIntent paramPendingIntent)
    {
      this.mIncomingCallPendingIntent = paramPendingIntent;
    }

    public void setListener(ISipSessionListener paramISipSessionListener)
    {
      this.mAutoRegistration.setListener(paramISipSessionListener);
    }

    void setWakeupTimer(SipWakeupTimer paramSipWakeupTimer)
    {
      this.mSipGroup.setWakeupTimer(paramSipWakeupTimer);
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.server.sip.SipService
 * JD-Core Version:    0.6.2
 */