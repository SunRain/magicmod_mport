package com.android.server.sip;

import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.telephony.Rlog;
import java.util.HashSet;

class SipWakeLock
{
  private static final boolean DBG = false;
  private static final String TAG = "SipWakeLock";
  private HashSet<Object> mHolders = new HashSet();
  private PowerManager mPowerManager;
  private PowerManager.WakeLock mTimerWakeLock;
  private PowerManager.WakeLock mWakeLock;

  SipWakeLock(PowerManager paramPowerManager)
  {
    this.mPowerManager = paramPowerManager;
  }

  private void log(String paramString)
  {
    Rlog.d("SipWakeLock", paramString);
  }

  void acquire(long paramLong)
  {
    try
    {
      if (this.mTimerWakeLock == null)
      {
        this.mTimerWakeLock = this.mPowerManager.newWakeLock(1, "SipWakeLock.timer");
        this.mTimerWakeLock.setReferenceCounted(true);
      }
      this.mTimerWakeLock.acquire(paramLong);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void acquire(Object paramObject)
  {
    try
    {
      this.mHolders.add(paramObject);
      if (this.mWakeLock == null)
        this.mWakeLock = this.mPowerManager.newWakeLock(1, "SipWakeLock");
      if (!this.mWakeLock.isHeld())
        this.mWakeLock.acquire();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void release(Object paramObject)
  {
    try
    {
      this.mHolders.remove(paramObject);
      if ((this.mWakeLock != null) && (this.mHolders.isEmpty()) && (this.mWakeLock.isHeld()))
        this.mWakeLock.release();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void reset()
  {
    try
    {
      this.mHolders.clear();
      release(null);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.server.sip.SipWakeLock
 * JD-Core Version:    0.6.2
 */