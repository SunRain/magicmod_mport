package com.android.server.net;

import android.net.INetworkManagementEventObserver.Stub;

public class BaseNetworkObserver extends INetworkManagementEventObserver.Stub
{
  public void addressRemoved(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
  }

  public void addressUpdated(String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
  }

  public void interfaceAdded(String paramString)
  {
  }

  public void interfaceClassDataActivityChanged(String paramString, boolean paramBoolean)
  {
  }

  public void interfaceLinkStateChanged(String paramString, boolean paramBoolean)
  {
  }

  public void interfaceRemoved(String paramString)
  {
  }

  public void interfaceStatusChanged(String paramString, boolean paramBoolean)
  {
  }

  public void limitReached(String paramString1, String paramString2)
  {
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.android.server.net.BaseNetworkObserver
 * JD-Core Version:    0.6.2
 */