package com.miui.internal.app;

import android.content.Context;
import android.os.SystemProperties;
import android.text.format.DateFormat;
import android.widget.CheckBox;
import miui.os.Build;
import miui.os.Shell;

public class ShutdownAlarm
{
  private static final String DM12 = "E h:mm aa";
  private static final String DM24 = "E kk:mm";
  private static final String TAG = "ShutdownAlarm";
  private static final String WAKEALARM_PATH = "/sys/class/rtc/rtc0/wakealarm";

  public static CheckBox buildShutdownAlarmCheckBox(Context paramContext)
  {
    long l = 1000L * readWakeAlarm();
    if (Build.IS_HONGMI)
      l = 1000L * SystemProperties.getLong("sys.power_off_alarm", 0L);
    CheckBox localCheckBox = null;
    StringBuilder localStringBuilder;
    Object[] arrayOfObject;
    if (l > System.currentTimeMillis())
    {
      localCheckBox = new CheckBox(paramContext);
      localCheckBox.setChecked(true);
      localStringBuilder = new StringBuilder();
      arrayOfObject = new Object[1];
      if (!DateFormat.is24HourFormat(paramContext))
        break label131;
    }
    label131: for (String str = "E kk:mm"; ; str = "E h:mm aa")
    {
      arrayOfObject[0] = DateFormat.format(str, l);
      localStringBuilder.append(paramContext.getString(101450248, arrayOfObject));
      localStringBuilder.append("\n");
      localStringBuilder.append(formatAlarm(paramContext, l, 101056534));
      localCheckBox.setText(localStringBuilder.toString());
      return localCheckBox;
    }
  }

  private static String formatAlarm(Context paramContext, long paramLong, int paramInt)
  {
    long l1 = paramLong - System.currentTimeMillis();
    long l2 = l1 / 3600000L;
    long l3 = l1 / 60000L % 60L;
    long l4 = l2 / 24L;
    long l5 = l2 % 24L;
    String str1;
    String str2;
    label65: String str3;
    label76: int i;
    label86: int j;
    label96: int k;
    label106: int m;
    label114: int n;
    label122: int i1;
    if (l4 == 0L)
    {
      str1 = "";
      if (l3 != 0L)
        break label206;
      str2 = "";
      if (l5 != 0L)
        break label234;
      str3 = "";
      if (l4 <= 0L)
        break label262;
      i = 1;
      if (l5 <= 0L)
        break label268;
      j = 1;
      if (l3 <= 0L)
        break label274;
      k = 1;
      if (i == 0)
        break label280;
      m = 1;
      if (j == 0)
        break label286;
      n = 2;
      i1 = m | n;
      if (k == 0)
        break label292;
    }
    label262: label268: label274: label280: label286: label292: for (int i2 = 4; ; i2 = 0)
    {
      int i3 = i1 | i2;
      return String.format(paramContext.getResources().getStringArray(paramInt)[i3], new Object[] { str1, str3, str2 });
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Long.valueOf(l4);
      str1 = paramContext.getString(101450307, arrayOfObject1);
      break;
      label206: Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = Long.valueOf(l3);
      str2 = paramContext.getString(101450309, arrayOfObject2);
      break label65;
      label234: Object[] arrayOfObject3 = new Object[1];
      arrayOfObject3[0] = Long.valueOf(l5);
      str3 = paramContext.getString(101450308, arrayOfObject3);
      break label76;
      i = 0;
      break label86;
      j = 0;
      break label96;
      k = 0;
      break label106;
      m = 0;
      break label114;
      n = 0;
      break label122;
    }
  }

  // ERROR //
  public static long readWakeAlarm()
  {
    // Byte code:
    //   0: lconst_0
    //   1: lstore_0
    //   2: aconst_null
    //   3: astore_2
    //   4: new 138	java/io/BufferedReader
    //   7: dup
    //   8: new 140	java/io/FileReader
    //   11: dup
    //   12: ldc 17
    //   14: invokespecial 143	java/io/FileReader:<init>	(Ljava/lang/String;)V
    //   17: invokespecial 146	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   20: astore_3
    //   21: aload_3
    //   22: invokevirtual 149	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   25: invokestatic 155	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   28: istore 17
    //   30: iload 17
    //   32: i2l
    //   33: lstore_0
    //   34: aload_3
    //   35: ifnull +7 -> 42
    //   38: aload_3
    //   39: invokevirtual 158	java/io/BufferedReader:close	()V
    //   42: lload_0
    //   43: lreturn
    //   44: astore 4
    //   46: ldc 14
    //   48: ldc 160
    //   50: aload 4
    //   52: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   55: pop
    //   56: aload_2
    //   57: ifnull -15 -> 42
    //   60: aload_2
    //   61: invokevirtual 158	java/io/BufferedReader:close	()V
    //   64: goto -22 -> 42
    //   67: astore 9
    //   69: ldc 14
    //   71: astore 10
    //   73: ldc 160
    //   75: astore 11
    //   77: aload 10
    //   79: aload 11
    //   81: aload 9
    //   83: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   86: pop
    //   87: goto -45 -> 42
    //   90: astore 13
    //   92: ldc 14
    //   94: ldc 160
    //   96: aload 13
    //   98: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   101: pop
    //   102: aload_2
    //   103: ifnull -61 -> 42
    //   106: aload_2
    //   107: invokevirtual 158	java/io/BufferedReader:close	()V
    //   110: goto -68 -> 42
    //   113: astore 9
    //   115: ldc 14
    //   117: astore 10
    //   119: ldc 160
    //   121: astore 11
    //   123: goto -46 -> 77
    //   126: astore 15
    //   128: ldc 14
    //   130: ldc 160
    //   132: aload 15
    //   134: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   137: pop
    //   138: aload_2
    //   139: ifnull -97 -> 42
    //   142: aload_2
    //   143: invokevirtual 158	java/io/BufferedReader:close	()V
    //   146: goto -104 -> 42
    //   149: astore 9
    //   151: ldc 14
    //   153: astore 10
    //   155: ldc 160
    //   157: astore 11
    //   159: goto -82 -> 77
    //   162: astore 5
    //   164: aload_2
    //   165: ifnull +7 -> 172
    //   168: aload_2
    //   169: invokevirtual 158	java/io/BufferedReader:close	()V
    //   172: aload 5
    //   174: athrow
    //   175: astore 6
    //   177: ldc 14
    //   179: ldc 160
    //   181: aload 6
    //   183: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   186: pop
    //   187: goto -15 -> 172
    //   190: astore 18
    //   192: ldc 14
    //   194: ldc 160
    //   196: aload 18
    //   198: invokestatic 166	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   201: pop
    //   202: goto -160 -> 42
    //   205: astore 5
    //   207: aload_3
    //   208: astore_2
    //   209: goto -45 -> 164
    //   212: astore 15
    //   214: aload_3
    //   215: astore_2
    //   216: goto -88 -> 128
    //   219: astore 13
    //   221: aload_3
    //   222: astore_2
    //   223: goto -131 -> 92
    //   226: astore 4
    //   228: aload_3
    //   229: astore_2
    //   230: goto -184 -> 46
    //
    // Exception table:
    //   from	to	target	type
    //   4	21	44	java/io/FileNotFoundException
    //   60	64	67	java/io/IOException
    //   4	21	90	java/lang/NumberFormatException
    //   106	110	113	java/io/IOException
    //   4	21	126	java/io/IOException
    //   142	146	149	java/io/IOException
    //   4	21	162	finally
    //   46	56	162	finally
    //   92	102	162	finally
    //   128	138	162	finally
    //   168	172	175	java/io/IOException
    //   38	42	190	java/io/IOException
    //   21	30	205	finally
    //   21	30	212	java/io/IOException
    //   21	30	219	java/lang/NumberFormatException
    //   21	30	226	java/io/FileNotFoundException
  }

  public static void writeWakeAlarm(long paramLong)
  {
    Shell.write("/sys/class/rtc/rtc0/wakealarm", String.valueOf(paramLong));
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.app.ShutdownAlarm
 * JD-Core Version:    0.6.2
 */