package com.miui.internal.os;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.BatteryStats.Uid;
import android.os.ServiceManager;
import android.os.UserHandle;
import com.android.internal.app.IBatteryStats;
import com.android.internal.app.IBatteryStats.Stub;
import com.android.internal.os.BatteryStatsImpl;
import com.android.internal.os.PowerProfile;

public class BatteryStatsHelper
{
  public static void sendQueryPackageIntent(Context paramContext, String[] paramArrayOfString, int paramInt, BroadcastReceiver paramBroadcastReceiver)
  {
    Intent localIntent = new Intent("android.intent.action.QUERY_PACKAGE_RESTART", Uri.fromParts("package", paramArrayOfString[0], null));
    localIntent.putExtra("android.intent.extra.user_handle", UserHandle.getUserId(paramInt));
    localIntent.putExtra("android.intent.extra.PACKAGES", paramArrayOfString);
    paramContext.sendOrderedBroadcastAsUser(localIntent, UserHandle.ALL, null, paramBroadcastReceiver, null, 0, null, null);
  }

  public IBatteryStats getBatteryStats()
  {
    return IBatteryStats.Stub.asInterface(ServiceManager.getService("batterystats"));
  }

  public double getMobilePowerPerByte(BatteryStatsImpl paramBatteryStatsImpl, PowerProfile paramPowerProfile, int paramInt)
  {
    double d = paramPowerProfile.getAveragePower("radio.active") / 3600.0D;
    long l1 = paramBatteryStatsImpl.getNetworkActivityCount(0, paramInt) + paramBatteryStatsImpl.getNetworkActivityCount(1, paramInt);
    long l2 = paramBatteryStatsImpl.getRadioDataUptime() / 1000L;
    if (l2 != 0L);
    for (long l3 = 1000L * (8L * l1) / l2; ; l3 = 200000L)
      return d / (l3 / 8L);
  }

  public long getTcpBytesReceived(BatteryStats.Uid paramUid, int paramInt)
  {
    return paramUid.getNetworkActivityCount(0, paramInt);
  }

  public long getTcpBytesSent(BatteryStats.Uid paramUid, int paramInt)
  {
    return paramUid.getNetworkActivityCount(1, paramInt);
  }

  public double getWifiPowerPerByte(BatteryStatsImpl paramBatteryStatsImpl, PowerProfile paramPowerProfile, int paramInt)
  {
    return paramPowerProfile.getAveragePower("wifi.active") / 3600.0D / 125000.0D;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.os.BatteryStatsHelper
 * JD-Core Version:    0.6.2
 */