package com.miui.internal.v5.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.AnimatorSet.Builder;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.android.internal.view.menu.ActionMenuItem;
import com.android.internal.view.menu.MenuBuilder;
import com.android.internal.widget.AbsActionBarView;
import com.android.internal.widget.AbsActionBarView.VisibilityAnimListener;
import com.android.internal.widget.ActionBarContainer;
import com.miui.internal.v5.view.ActionModeView;
import java.lang.ref.WeakReference;
import miui.util.UiUtils;
import miui.v5.view.EditActionMode;

public class ActionBarContextView extends com.android.internal.widget.ActionBarContextView
  implements View.OnClickListener, ActionModeView
{
  private static final int ANIMATE_IDLE = 0;
  private static final int ANIMATE_IN = 1;
  private static final int ANIMATE_OUT = 2;
  private static final int FADE_DURATION = 200;
  private WeakReference<ActionMode> mActionMode;
  private TextView mButton1;
  private ActionMenuItem mButton1MenuItem;
  private TextView mButton2;
  private ActionMenuItem mButton2MenuItem;
  private int mContentHeightWithoutPadding;
  private boolean mRequestAniamtion;

  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    Drawable localDrawable = getBackground();
    if (localDrawable != null)
    {
      this.mContentHeight = localDrawable.getIntrinsicHeight();
      Rect localRect = new Rect();
      localDrawable.getPadding(localRect);
      this.mContentHeightWithoutPadding = (this.mContentHeight - localRect.top - localRect.bottom);
    }
    this.mButton1MenuItem = new ActionMenuItem(paramContext, 0, 16908313, 0, 0, paramContext.getString(17039360));
    this.mButton2MenuItem = new ActionMenuItem(paramContext, 0, 16908314, 0, 0, paramContext.getString(101450237));
  }

  public void animateToVisibility(int paramInt)
  {
    if (this.mVisibilityAnim != null)
      this.mVisibilityAnim.cancel();
    if (paramInt == 0)
    {
      setVisibility(0);
      this.mRequestAniamtion = true;
    }
    while (true)
    {
      return;
      makeInOutAnimator(paramInt).start();
    }
  }

  protected void cancelVisibilityAnimation()
  {
    if (this.mVisibilityAnim != null)
    {
      this.mVisibilityAnim.cancel();
      this.mVisibilityAnim = null;
    }
  }

  public void closeMode()
  {
    cancelVisibilityAnimation();
    setAnimationMode(2);
  }

  public CharSequence getSubtitle()
  {
    throw new UnsupportedOperationException("getSubTitle is not supported");
  }

  public void initForMode(ActionMode paramActionMode)
  {
    if (this.mActionMode != null)
    {
      cancelVisibilityAnimation();
      killMode();
    }
    this.mActionMode = new WeakReference(paramActionMode);
    MenuBuilder localMenuBuilder = (MenuBuilder)paramActionMode.getMenu();
    if (this.mActionMenuPresenter != null)
      this.mActionMenuPresenter.dismissPopupMenus();
    this.mActionMenuPresenter = new com.miui.internal.v5.view.menu.ActionMenuPresenter(this.mContext, 100859944, 100859941, 100859943, true);
    localMenuBuilder.addMenuPresenter(this.mActionMenuPresenter);
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-2, -1);
    if (!this.mSplitActionBar)
    {
      this.mMenuView = ((com.miui.internal.v5.view.menu.ActionMenuView)this.mActionMenuPresenter.getMenuView(this));
      this.mMenuView.setBackgroundDrawable(null);
      addView(this.mMenuView, localLayoutParams);
    }
    while (true)
    {
      return;
      this.mActionMenuPresenter.setWidthLimit(getContext().getResources().getDisplayMetrics().widthPixels, true);
      this.mActionMenuPresenter.setItemLimit(2147483647);
      localLayoutParams.width = -1;
      localLayoutParams.height = -2;
      localLayoutParams.gravity = 80;
      this.mMenuView = ((com.miui.internal.v5.view.menu.ActionMenuView)this.mActionMenuPresenter.getMenuView(this.mSplitView));
      this.mSplitView.addView(this.mMenuView, localLayoutParams);
    }
  }

  public void killMode()
  {
    super.killMode();
    this.mActionMode = null;
  }

  protected Animator makeInOutAnimator(int paramInt)
  {
    com.miui.internal.v5.view.menu.ActionMenuView localActionMenuView = (com.miui.internal.v5.view.menu.ActionMenuView)this.mMenuView;
    int i = localActionMenuView.getPrimaryContainerHeight();
    float f1 = localActionMenuView.getTranslationY();
    float f2;
    float f3;
    float f4;
    float f5;
    Object localObject;
    if (paramInt == 0)
    {
      f2 = -this.mContentHeight;
      f3 = 0.0F;
      f4 = f1 + i;
      f5 = f1;
      localObject = ObjectAnimator.ofFloat(this, "TranslationY", new float[] { f2, f3 });
      if (this.mSplitActionBar)
        break label120;
      ((ObjectAnimator)localObject).addListener(this.mVisAnimListener.withFinalVisibility(paramInt));
      ((ObjectAnimator)localObject).addListener(this);
    }
    while (true)
    {
      return localObject;
      f2 = 0.0F;
      f3 = -this.mContentHeight;
      f4 = f1;
      f5 = f1 + i;
      break;
      label120: ObjectAnimator localObjectAnimator = ObjectAnimator.ofFloat(this.mMenuView, "TranslationY", new float[] { f4, f5 });
      AnimatorSet localAnimatorSet = new AnimatorSet();
      localAnimatorSet.play((Animator)localObject).with(localObjectAnimator);
      localAnimatorSet.addListener(this.mVisAnimListener.withFinalVisibility(paramInt));
      localAnimatorSet.addListener(this);
      localAnimatorSet.setDuration(200L);
      localObject = localAnimatorSet;
    }
  }

  protected int measureChildView(View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramView != getTitleLayout());
    for (int i = super.measureChildView(paramView, paramInt1, paramInt2, paramInt3); ; i = Math.max(0, paramInt1 - paramView.getMeasuredWidth() - paramInt3))
    {
      return i;
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
    }
  }

  protected boolean miuiInitTitle()
  {
    TextView localTextView = getTitleView();
    LinearLayout localLinearLayout = getTitleLayout();
    int i = UiUtils.resolveAttribute(this.mContext, 100728899);
    if (localLinearLayout == null)
    {
      LayoutInflater localLayoutInflater = LayoutInflater.from(this.mContext);
      if (i != 0)
        localLinearLayout = (LinearLayout)localLayoutInflater.inflate(i, this, false);
      if (localLinearLayout != null)
      {
        this.mButton1 = ((TextView)localLinearLayout.findViewById(16908313));
        this.mButton2 = ((TextView)localLinearLayout.findViewById(16908314));
        localTextView = (TextView)localLinearLayout.findViewById(16908310);
        if (this.mButton1 != null)
        {
          this.mButton1.setOnClickListener(this);
          this.mButton1.setText(this.mButton1MenuItem.getTitle());
        }
        if (this.mButton2 != null)
        {
          this.mButton2.setOnClickListener(this);
          this.mButton2.setText(this.mButton2MenuItem.getTitle());
        }
        if (localTextView != null)
        {
          int j = getTitleStyleRes();
          if (j != 0)
            localTextView.setTextAppearance(this.mContext, j);
          setTitleView(localTextView);
        }
      }
    }
    if (localTextView != null)
      localTextView.setText(getTitle());
    if ((localLinearLayout != null) && (localLinearLayout.getParent() == null))
    {
      addView(localLinearLayout);
      setTitleLayout(localLinearLayout);
    }
    return true;
  }

  public void onClick(View paramView)
  {
    if (paramView.getId() == 16908313);
    for (ActionMenuItem localActionMenuItem = this.mButton1MenuItem; ; localActionMenuItem = this.mButton2MenuItem)
    {
      EditActionMode localEditActionMode = (EditActionMode)this.mActionMode.get();
      if (localEditActionMode != null)
        localEditActionMode.onMenuItemSelected((MenuBuilder)localEditActionMode.getMenu(), localActionMenuItem);
      return;
    }
  }

  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    Drawable localDrawable = UiUtils.getDrawable(this.mContext, 100728938);
    if (localDrawable != null)
      this.mContentHeight = localDrawable.getIntrinsicHeight();
    setBackground(localDrawable);
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.mRequestAniamtion)
    {
      makeInOutAnimator(0).start();
      this.mRequestAniamtion = false;
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if (paramMotionEvent.getY() < this.mContentHeightWithoutPadding);
    for (boolean bool = true; ; bool = super.onTouchEvent(paramMotionEvent))
      return bool;
  }

  protected int positionChild(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = 0;
    if ((paramView != null) && (paramView.getParent() == this))
      i = super.positionChild(paramView, paramInt1, paramInt2, paramInt3, paramBoolean);
    return i;
  }

  public void setButton(int paramInt, CharSequence paramCharSequence)
  {
    if (paramInt == 16908313)
      if (this.mButton1 != null)
      {
        this.mButton1.setText(paramCharSequence);
        this.mButton1MenuItem.setTitle(paramCharSequence);
      }
    while (true)
    {
      return;
      if ((paramInt == 16908314) && (this.mButton2 != null))
      {
        this.mButton2.setText(paramCharSequence);
        this.mButton2MenuItem.setTitle(paramCharSequence);
      }
    }
  }

  public void setContentHeight(int paramInt)
  {
  }

  public void setCustomView(View paramView)
  {
    throw new UnsupportedOperationException("setCustomView is not supported");
  }

  public void setSplitActionBar(boolean paramBoolean)
  {
    super.setSplitActionBar(paramBoolean);
    if ((paramBoolean) && (this.mActionMenuPresenter != null))
    {
      this.mMenuView = ((com.android.internal.view.menu.ActionMenuView)this.mActionMenuPresenter.getMenuView(this));
      this.mMenuView.getLayoutParams().height = -2;
    }
  }

  public void setSubtitle(CharSequence paramCharSequence)
  {
    throw new UnsupportedOperationException("setSubtitle is not supported");
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.widget.ActionBarContextView
 * JD-Core Version:    0.6.2
 */