package com.miui.internal.v5.widget;

import android.content.Context;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;
import com.android.internal.widget.ActionBarOverlayLayout.LayoutParams;
import com.miui.internal.v5.app.ActionBarImpl;
import com.miui.internal.v5.view.menu.ActionMenuView;
import miui.util.ResourceMapper;
import miui.util.UiUtils;

public class ActionBarOverlayLayout extends com.android.internal.widget.ActionBarOverlayLayout
  implements IActionBarLayout
{
  static final int[] mActionBarSizeAttr = { 16843499 };
  private int mActionBarHeight;
  private View mDimView;
  private boolean mUpdateContentMargin = true;

  public ActionBarOverlayLayout(Context paramContext)
  {
    super(paramContext);
    init(paramContext);
  }

  public ActionBarOverlayLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init(paramContext);
  }

  private boolean applyInsets(View paramView, Rect paramRect, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    boolean bool = false;
    ActionBarOverlayLayout.LayoutParams localLayoutParams = (ActionBarOverlayLayout.LayoutParams)paramView.getLayoutParams();
    if ((paramBoolean1) && (localLayoutParams.leftMargin != paramRect.left))
    {
      bool = true;
      localLayoutParams.leftMargin = paramRect.left;
    }
    if ((paramBoolean2) && (localLayoutParams.topMargin != paramRect.top))
    {
      bool = true;
      localLayoutParams.topMargin = paramRect.top;
    }
    if ((paramBoolean4) && (localLayoutParams.rightMargin != paramRect.right))
    {
      bool = true;
      localLayoutParams.rightMargin = paramRect.right;
    }
    if ((paramBoolean3) && (localLayoutParams.bottomMargin != paramRect.bottom))
    {
      bool = true;
      localLayoutParams.bottomMargin = paramRect.bottom;
    }
    return bool;
  }

  private ActionBarContextView getActionBarContextView()
  {
    if (getContainerView() != null);
    for (ActionBarContextView localActionBarContextView = (ActionBarContextView)getContainerView().findViewById(ResourceMapper.resolveReference(this.mContext, 101384201)); ; localActionBarContextView = null)
      return localActionBarContextView;
  }

  private void init(Context paramContext)
  {
    TypedArray localTypedArray = getContext().getTheme().obtainStyledAttributes(mActionBarSizeAttr);
    this.mActionBarHeight = localTypedArray.getDimensionPixelSize(0, 0);
    localTypedArray.recycle();
  }

  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    int i = 1;
    boolean bool = false;
    if ((paramKeyEvent.getAction() == i) && (paramKeyEvent.getKeyCode() == 4))
      bool = false | getActionView().hideOverflowMenu() | getActionBarContextView().hideOverflowMenu();
    if ((bool) || (super.dispatchKeyEvent(paramKeyEvent)));
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  protected int getActionBarHeight()
  {
    View localView1 = getActionBarTop();
    ActionBarView localActionBarView = (ActionBarView)getActionView();
    ActionBarContainer localActionBarContainer = (ActionBarContainer)getContainerView();
    int i;
    if (localView1.getVisibility() != 0)
      i = 0;
    while (true)
    {
      return i;
      i = localActionBarView.getMeasuredHeight();
      View localView2 = localActionBarContainer.getTabContainer();
      if ((localView2 != null) && (localView2.getVisibility() == 0))
        i += localActionBarContainer.getTabContainer().getMeasuredHeight();
      if (i > 0)
        i = Math.max(i - UiUtils.getActionBarOverlayHeight(this.mContext), 0);
    }
  }

  protected int getSplitActionBarHeight()
  {
    ActionBarContainer localActionBarContainer = (ActionBarContainer)getActionBarBottom();
    ActionBarView localActionBarView = (ActionBarView)getActionView();
    int i;
    if (localActionBarContainer.getVisibility() != 0)
      i = 0;
    do
    {
      return i;
      i = 0;
    }
    while (!localActionBarView.isSplitActionBar());
    ActionMenuView localActionMenuView;
    int j;
    if (!localActionBarView.getActionBar().isFragmentViewPagerMode())
    {
      if (localActionBarContainer.getVisibility() == 0)
        for (int k = 0; k < localActionBarContainer.getChildCount(); k++)
        {
          View localView = localActionBarContainer.getChildAt(k);
          if (((localView instanceof ActionMenuView)) && (((ActionMenuView)localView).getMenuItems() > 0) && (localView.getVisibility() == 0))
            i = Math.max(i, ((ActionMenuView)localView).getPrimaryContainerHeight());
        }
    }
    else
    {
      localActionMenuView = localActionBarView.getActionMenuView();
      ActionBarContextView localActionBarContextView = getActionBarContextView();
      if (localActionBarContextView == null)
        break label198;
      if (localActionBarContextView.getAnimatedVisibility() != 0)
        break label192;
      j = 1;
    }
    while (true)
    {
      if ((j != 0) && (localActionMenuView != null) && (localActionMenuView.getMenuItems() == 0))
        i = localActionMenuView.getPrimaryContainerHeight();
      if (i <= 0)
        break;
      i = Math.max(i - UiUtils.getSplitActionBarOverlayHeight(this.mContext), 0);
      break;
      label192: j = 0;
      continue;
      label198: j = 0;
    }
  }

  protected void onFinishInflate()
  {
    super.onFinishInflate();
    this.mDimView = findViewById(101384354);
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = getChildCount();
    int j = getPaddingLeft();
    (paramInt3 - paramInt1 - getPaddingRight());
    int k = getPaddingTop();
    int m = paramInt4 - paramInt2 - getPaddingBottom();
    int n = 0;
    if (n < i)
    {
      View localView = getChildAt(n);
      ActionBarOverlayLayout.LayoutParams localLayoutParams;
      int i1;
      int i2;
      int i3;
      if (localView.getVisibility() != 8)
      {
        localLayoutParams = (ActionBarOverlayLayout.LayoutParams)localView.getLayoutParams();
        i1 = localView.getMeasuredWidth();
        i2 = localView.getMeasuredHeight();
        i3 = j + localLayoutParams.leftMargin;
        if (localView != getActionBarBottom())
          break label148;
      }
      label148: for (int i4 = m - i2 - localLayoutParams.bottomMargin; ; i4 = k + localLayoutParams.topMargin)
      {
        localView.layout(i3, i4, i3 + i1, i4 + i2);
        n++;
        break;
      }
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    findViews();
    int i = 0;
    int j = 0;
    View localView1 = getActionBarTop();
    View localView2 = getActionBarBottom();
    ActionBarImpl localActionBarImpl = (ActionBarImpl)getActionBar();
    ActionBarView localActionBarView = (ActionBarView)getActionView();
    ActionBarContainer localActionBarContainer = (ActionBarContainer)getContainerView();
    View localView3 = getContent();
    measureChildWithMargins(localView1, paramInt1, 0, paramInt2, 0);
    ActionBarOverlayLayout.LayoutParams localLayoutParams1 = (ActionBarOverlayLayout.LayoutParams)localView1.getLayoutParams();
    int k = Math.max(0, localView1.getMeasuredWidth() + localLayoutParams1.leftMargin + localLayoutParams1.rightMargin);
    int m = Math.max(0, localView1.getMeasuredHeight() + localLayoutParams1.topMargin + localLayoutParams1.bottomMargin);
    int n = combineMeasuredStates(0, localView1.getMeasuredState());
    if (localView2 != null)
    {
      measureChildWithMargins(localView2, paramInt1, 0, paramInt2, 0);
      ActionBarOverlayLayout.LayoutParams localLayoutParams3 = (ActionBarOverlayLayout.LayoutParams)localView2.getLayoutParams();
      int i11 = localView2.getMeasuredWidth() + localLayoutParams3.leftMargin + localLayoutParams3.rightMargin;
      k = Math.max(k, i11);
      int i12 = localView2.getMeasuredHeight() + localLayoutParams3.topMargin + localLayoutParams3.bottomMargin;
      m = Math.max(m, i12);
      int i13 = localView2.getMeasuredState();
      n = combineMeasuredStates(n, i13);
    }
    int i1;
    label280: label304: Rect localRect1;
    Rect localRect2;
    Rect localRect5;
    if ((0x100 & getWindowSystemUiVisibility()) != 0)
    {
      i1 = 1;
      if (i1 == 0)
        break label657;
      i = this.mActionBarHeight;
      if ((localActionBarImpl != null) && (localActionBarImpl.hasNonEmbeddedTabs()) && (localActionBarContainer.getTabContainer() != null))
        i += this.mActionBarHeight;
      if ((localActionBarView.isSplitActionBar()) && (localView2 != null))
      {
        if (i1 == 0)
          break label673;
        j = getSplitActionBarHeight();
      }
      localRect1 = getContentInsets();
      localRect2 = getInnerInsets();
      Rect localRect3 = getBaseInnerInsets();
      Rect localRect4 = getBaseContentInsets();
      localRect5 = getLastInnerInsets();
      localRect1.set(localRect4);
      localRect2.set(localRect3);
      if (this.mUpdateContentMargin)
      {
        if ((isOverlayMode()) || (i1 != 0))
          break label682;
        localRect1.top = (i + localRect1.top);
      }
    }
    for (localRect1.bottom = (j + localRect1.bottom); ; localRect2.bottom = (j + localRect2.bottom))
    {
      applyInsets(localView3, localRect1, true, true, this.mUpdateContentMargin, true);
      if (!localRect5.equals(localRect2))
      {
        localRect5.set(localRect2);
        superFitSystemWindows(localRect2);
      }
      measureChildWithMargins(localView3, paramInt1, 0, paramInt2, 0);
      ActionBarOverlayLayout.LayoutParams localLayoutParams2 = (ActionBarOverlayLayout.LayoutParams)localView3.getLayoutParams();
      int i2 = localView3.getMeasuredWidth() + localLayoutParams2.leftMargin + localLayoutParams2.rightMargin;
      int i3 = Math.max(k, i2);
      int i4 = localView3.getMeasuredHeight() + localLayoutParams2.topMargin + localLayoutParams2.bottomMargin;
      int i5 = Math.max(m, i4);
      int i6 = localView3.getMeasuredState();
      int i7 = combineMeasuredStates(n, i6);
      if ((this.mDimView != null) && (this.mDimView.getVisibility() == 0))
      {
        applyInsets(this.mDimView, localRect1, true, true, true, true);
        measureChildWithMargins(this.mDimView, paramInt1, 0, paramInt2, 0);
        int i10 = this.mDimView.getMeasuredState();
        i7 = combineMeasuredStates(i7, i10);
      }
      int i8 = i3 + (getPaddingLeft() + getPaddingRight());
      int i9 = Math.max(i5 + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight());
      setMeasuredDimension(resolveSizeAndState(Math.max(i8, getSuggestedMinimumWidth()), paramInt1, i7), resolveSizeAndState(i9, paramInt2, i7 << 16));
      return;
      i1 = 0;
      break;
      label657: if (localView1.getVisibility() != 0)
        break label280;
      i = getActionBarHeight();
      break label280;
      label673: j = getSplitActionBarHeight();
      break label304;
      label682: localRect2.top = (i + localRect2.top);
    }
  }

  public void setUpdateContentMarginEnabled(boolean paramBoolean)
  {
    this.mUpdateContentMargin = paramBoolean;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.widget.ActionBarOverlayLayout
 * JD-Core Version:    0.6.2
 */