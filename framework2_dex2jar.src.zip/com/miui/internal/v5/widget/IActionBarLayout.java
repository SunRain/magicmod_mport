package com.miui.internal.v5.widget;

public abstract interface IActionBarLayout
{
  public abstract void setUpdateContentMarginEnabled(boolean paramBoolean);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.widget.IActionBarLayout
 * JD-Core Version:    0.6.2
 */