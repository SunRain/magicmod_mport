package com.miui.internal.v5.view;

import android.view.ActionMode;

public abstract interface ActionModeView
{
  public abstract void animateToVisibility(int paramInt);

  public abstract void closeMode();

  public abstract void initForMode(ActionMode paramActionMode);

  public abstract void killMode();
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.view.ActionModeView
 * JD-Core Version:    0.6.2
 */