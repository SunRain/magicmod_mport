package com.miui.internal.v5.view.menu;

import com.android.internal.view.menu.MenuBuilder.ItemInvoker;
import com.android.internal.view.menu.MenuView.ItemView;

public abstract interface ActionMenuPrimaryItemView extends MenuView.ItemView
{
  public abstract void setItemInvoker(MenuBuilder.ItemInvoker paramItemInvoker);
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.view.menu.ActionMenuPrimaryItemView
 * JD-Core Version:    0.6.2
 */