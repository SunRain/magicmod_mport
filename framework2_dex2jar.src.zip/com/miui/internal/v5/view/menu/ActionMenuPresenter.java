package com.miui.internal.v5.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.android.internal.view.menu.BaseMenuPresenter;
import com.android.internal.view.menu.MenuBuilder;
import com.android.internal.view.menu.MenuItemImpl;
import com.android.internal.view.menu.MenuPresenter;
import com.android.internal.view.menu.MenuView;
import com.android.internal.view.menu.MenuView.ItemView;
import java.util.ArrayList;
import miui.util.UiUtils;

public class ActionMenuPresenter extends com.android.internal.view.menu.ActionMenuPresenter
{
  static final int MAX_PRIMARY_ITEMS = 4;
  private int mId;
  private boolean mIsEditMode;
  private int mLayoutResId;
  private int mMaxPrimaryItems = 4;
  private int mMenuItems;
  private ActionMenuPrimaryItemView mMoreView;
  private int mPrimaryItemResId;
  private int mSecondaryItemResId;
  private MenuUpdateListener mUpdateListener;

  public ActionMenuPresenter(Context paramContext, int paramInt1, int paramInt2, int paramInt3)
  {
    this(paramContext, paramInt1, paramInt2, paramInt3, false);
  }

  public ActionMenuPresenter(Context paramContext, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    super(paramContext);
    this.mLayoutResId = paramInt1;
    this.mPrimaryItemResId = paramInt2;
    this.mSecondaryItemResId = paramInt3;
    this.mIsEditMode = paramBoolean;
  }

  void addItemView(ViewGroup paramViewGroup, View paramView, int paramInt)
  {
    ViewGroup localViewGroup = (ViewGroup)paramView.getParent();
    if (localViewGroup != null)
      localViewGroup.removeView(paramView);
    paramViewGroup.addView(paramView, paramInt);
  }

  public boolean dismissPopupMenus()
  {
    boolean bool = false;
    ActionMenuView localActionMenuView = (ActionMenuView)this.mMenuView;
    if ((localActionMenuView != null) && (localActionMenuView.requestExpand(false)))
      bool = true;
    return bool;
  }

  public boolean flagActionItems()
  {
    ArrayList localArrayList = this.mMenu.miuiGetVisibleItems();
    int i = localArrayList.size();
    for (int j = 0; j < i; j++)
    {
      MenuItemImpl localMenuItemImpl = (MenuItemImpl)localArrayList.get(j);
      if ((localMenuItemImpl.requestsActionButton()) || (localMenuItemImpl.requiresActionButton()))
        localMenuItemImpl.setIsActionButton(true);
    }
    return true;
  }

  public int getMenuItems()
  {
    return this.mMenuItems;
  }

  public MenuView getMenuView(ViewGroup paramViewGroup)
  {
    if (this.mMenuView == null)
    {
      this.mMenuView = ((ActionMenuView)this.mSystemInflater.inflate(this.mLayoutResId, paramViewGroup, false));
      this.mMenuView.initialize(this.mMenu);
      ((ActionMenuView)this.mMenuView).setPresenter(this);
    }
    return this.mMenuView;
  }

  ActionMenuPrimaryItemView getPrimaryItemView(MenuItemImpl paramMenuItemImpl, View paramView)
  {
    if ((paramView instanceof ActionMenuPrimaryItemView));
    for (View localView = paramView; ; localView = View.inflate(this.mContext, this.mPrimaryItemResId, null))
    {
      ActionMenuPrimaryItemView localActionMenuPrimaryItemView = (ActionMenuPrimaryItemView)localView;
      localActionMenuPrimaryItemView.initialize(paramMenuItemImpl, 0);
      return localActionMenuPrimaryItemView;
    }
  }

  ActionMenuSecondaryItemView getSecondaryItemView(MenuItemImpl paramMenuItemImpl, View paramView)
  {
    if ((paramView instanceof ActionMenuSecondaryItemView));
    for (View localView = paramView; ; localView = View.inflate(this.mContext, this.mSecondaryItemResId, null))
    {
      ActionMenuSecondaryItemView localActionMenuSecondaryItemView = (ActionMenuSecondaryItemView)localView;
      localActionMenuSecondaryItemView.initialize(paramMenuItemImpl, 0);
      return localActionMenuSecondaryItemView;
    }
  }

  public boolean hideOverflowMenu()
  {
    if ((this.mMenuView != null) && (((ActionMenuView)this.mMenuView).requestExpand(false)));
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder)
  {
    if (this.mMenu != null)
      this.mMenu.removeMenuPresenter(this);
    this.mContext = paramContext;
    this.mMenu = paramMenuBuilder;
  }

  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean)
  {
    if (this.mMenuView == null);
    while (true)
    {
      return;
      ((ActionMenuView)this.mMenuView).requestExpand(false);
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    ActionMenuView localActionMenuView = (ActionMenuView)this.mMenuView;
    if (localActionMenuView != null)
    {
      localActionMenuView.getPrimaryContainer().removeAllViews();
      if (!this.mIsEditMode)
        break label47;
    }
    label47: for (Drawable localDrawable = UiUtils.getDrawable(this.mContext, 100728926); ; localDrawable = UiUtils.getDrawable(this.mContext, 100728900))
    {
      localActionMenuView.setPrimaryContainerCollapsedBackground(localDrawable);
      super.onConfigurationChanged(paramConfiguration);
      return;
    }
  }

  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
  }

  public Parcelable onSaveInstanceState()
  {
    return null;
  }

  public void setUpdateListener(MenuUpdateListener paramMenuUpdateListener)
  {
    this.mUpdateListener = paramMenuUpdateListener;
  }

  public void updateMenuView(boolean paramBoolean)
  {
    ActionMenuView localActionMenuView = (ActionMenuView)this.mMenuView;
    this.mMenuView.initialize(this.mMenu);
    if (this.mMenu == null)
    {
      localActionMenuView.getPrimaryContainer().removeAllViews();
      LinearLayout localLinearLayout4 = localActionMenuView.getSecondaryContainer(false);
      if (localLinearLayout4 != null)
        localLinearLayout4.removeAllViews();
      this.mMenuItems = 0;
    }
    while (true)
    {
      if (this.mUpdateListener != null)
        this.mUpdateListener.onMenuUpdated(this);
      return;
      ArrayList localArrayList = this.mMenu.miuiGetActionItems();
      this.mMenuItems = localArrayList.size();
      int i = this.mMenuItems;
      int j;
      int k;
      label122: LinearLayout localLinearLayout1;
      int m;
      label131: MenuItemImpl localMenuItemImpl3;
      View localView3;
      if (i > this.mMaxPrimaryItems)
      {
        j = 1;
        if (j == 0)
          break label261;
        k = -1 + this.mMaxPrimaryItems;
        localLinearLayout1 = localActionMenuView.getPrimaryContainer();
        m = 0;
        if (m >= k)
          break label274;
        localMenuItemImpl3 = (MenuItemImpl)localArrayList.get(m);
        localView3 = localLinearLayout1.getChildAt(m);
        if (!(localView3 instanceof MenuView.ItemView))
          break label268;
      }
      label261: label268: for (MenuItemImpl localMenuItemImpl4 = ((MenuView.ItemView)localView3).getItemData(); ; localMenuItemImpl4 = null)
      {
        ActionMenuPrimaryItemView localActionMenuPrimaryItemView = getPrimaryItemView(localMenuItemImpl3, localView3);
        ((View)localActionMenuPrimaryItemView).setOnClickListener(null);
        if (localMenuItemImpl3 != localMenuItemImpl4)
        {
          ((View)localActionMenuPrimaryItemView).setPressed(false);
          ((View)localActionMenuPrimaryItemView).jumpDrawablesToCurrentState();
        }
        if (localActionMenuPrimaryItemView != localView3)
        {
          addItemView(localLinearLayout1, (View)localActionMenuPrimaryItemView, m);
          localActionMenuPrimaryItemView.setItemInvoker(localActionMenuView);
        }
        m++;
        break label131;
        j = 0;
        break;
        k = i;
        break label122;
      }
      label274: if (j != 0)
      {
        View localView1 = localLinearLayout1.getChildAt(m);
        if ((localView1 != this.mMoreView) || (this.mMoreView == null))
        {
          this.mMoreView = localActionMenuView.createMoreItemView((ActionMenuPrimaryItemView)localView1, this.mPrimaryItemResId);
          if (this.mMoreView != localView1)
            addItemView(localLinearLayout1, (View)this.mMoreView, m);
        }
        LinearLayout localLinearLayout3 = localActionMenuView.getSecondaryContainer(true);
        int n = 0;
        if (m < i)
        {
          MenuItemImpl localMenuItemImpl1 = (MenuItemImpl)localArrayList.get(m);
          View localView2 = localLinearLayout3.getChildAt(n);
          if ((localView2 instanceof MenuView.ItemView));
          for (MenuItemImpl localMenuItemImpl2 = ((MenuView.ItemView)localView2).getItemData(); ; localMenuItemImpl2 = null)
          {
            ActionMenuSecondaryItemView localActionMenuSecondaryItemView = getSecondaryItemView(localMenuItemImpl1, localView2);
            if (localMenuItemImpl1 != localMenuItemImpl2)
            {
              localActionMenuSecondaryItemView.setPressed(false);
              localActionMenuSecondaryItemView.jumpDrawablesToCurrentState();
            }
            if (localActionMenuSecondaryItemView != localView2)
            {
              addItemView(localLinearLayout3, localActionMenuSecondaryItemView, n);
              localActionMenuSecondaryItemView.setItemInvoker(localActionMenuView);
            }
            m++;
            n++;
            break;
          }
        }
        localLinearLayout3.removeViews(n, localLinearLayout3.getChildCount() - n);
      }
      else
      {
        this.mMoreView = null;
        localLinearLayout1.removeViews(m, localLinearLayout1.getChildCount() - m);
        LinearLayout localLinearLayout2 = localActionMenuView.getSecondaryContainer(false);
        if (localLinearLayout2 != null)
          localLinearLayout2.removeAllViews();
      }
    }
  }

  public static abstract interface MenuUpdateListener
  {
    public abstract void onMenuUpdated(MenuPresenter paramMenuPresenter);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.miui.internal.v5.view.menu.ActionMenuPresenter
 * JD-Core Version:    0.6.2
 */