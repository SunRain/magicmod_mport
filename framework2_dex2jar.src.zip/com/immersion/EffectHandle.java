package com.immersion;

public class EffectHandle
{
  protected int deviceHandle;
  protected int effectHandle;

  protected EffectHandle(int paramInt1, int paramInt2)
  {
    this.deviceHandle = paramInt1;
    this.effectHandle = paramInt2;
  }

  public void appendWaveformEffect(WaveformEffectDefinition paramWaveformEffectDefinition)
  {
    this.effectHandle = ImmVibe.getInstance().appendWaveformEffect(this.deviceHandle, this.effectHandle, paramWaveformEffectDefinition.getData(), paramWaveformEffectDefinition.getDataSize(), paramWaveformEffectDefinition.getSampleRate(), paramWaveformEffectDefinition.getBitDepth(), paramWaveformEffectDefinition.getMagnitude());
  }

  public void destroyStreamingEffect()
  {
    ImmVibe.getInstance().destroyStreamingEffect(this.deviceHandle, this.effectHandle);
  }

  public int getState()
  {
    return ImmVibe.getInstance().getEffectState(this.deviceHandle, this.effectHandle);
  }

  public boolean isPaused()
  {
    if (getState() == 2);
    for (boolean bool = true; ; bool = false)
      return bool;
  }

  public boolean isPlaying()
  {
    int i = 1;
    if (getState() == i);
    while (true)
    {
      return i;
      int j = 0;
    }
  }

  public void modifyPlayingInterpolatedEffectInterpolant(int paramInt)
  {
    ImmVibe.getInstance().modifyPlayingInterpolatedEffectInterpolant(this.deviceHandle, this.effectHandle, paramInt);
  }

  public void modifyPlayingMagSweepEffect(MagSweepEffectDefinition paramMagSweepEffectDefinition)
  {
    ImmVibe.getInstance().modifyPlayingMagSweepEffect(this.deviceHandle, this.effectHandle, paramMagSweepEffectDefinition.getDuration(), paramMagSweepEffectDefinition.getMagnitude(), paramMagSweepEffectDefinition.getStyle(), paramMagSweepEffectDefinition.getAttackTime(), paramMagSweepEffectDefinition.getAttackLevel(), paramMagSweepEffectDefinition.getFadeTime(), paramMagSweepEffectDefinition.getFadeLevel());
  }

  public void modifyPlayingPeriodicEffect(PeriodicEffectDefinition paramPeriodicEffectDefinition)
  {
    ImmVibe.getInstance().modifyPlayingPeriodicEffect(this.deviceHandle, this.effectHandle, paramPeriodicEffectDefinition.getDuration(), paramPeriodicEffectDefinition.getMagnitude(), paramPeriodicEffectDefinition.getPeriod(), paramPeriodicEffectDefinition.getStyleAndWaveType(), paramPeriodicEffectDefinition.getAttackTime(), paramPeriodicEffectDefinition.getAttackLevel(), paramPeriodicEffectDefinition.getFadeTime(), paramPeriodicEffectDefinition.getFadeLevel());
  }

  public void pause()
  {
    ImmVibe.getInstance().pausePlayingEffect(this.deviceHandle, this.effectHandle);
  }

  public void playStreamingSample(byte[] paramArrayOfByte, int paramInt)
  {
    ImmVibe.getInstance().playStreamingSample(this.deviceHandle, this.effectHandle, paramArrayOfByte, paramInt);
  }

  public void playStreamingSampleWithOffset(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    ImmVibe.getInstance().playStreamingSampleWithOffset(this.deviceHandle, this.effectHandle, paramArrayOfByte, paramInt1, paramInt2);
  }

  public void resume()
  {
    ImmVibe.getInstance().resumePausedEffect(this.deviceHandle, this.effectHandle);
  }

  public void stop()
  {
    ImmVibe.getInstance().stopPlayingEffect(this.deviceHandle, this.effectHandle);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.EffectHandle
 * JD-Core Version:    0.6.2
 */