package com.immersion;

public class Device
{
  protected int deviceHandle;
  protected int deviceIndex;

  public static boolean getCapabilityBool(int paramInt1, int paramInt2)
  {
    return ImmVibe.getInstance().getDeviceCapabilityBool(paramInt1, paramInt2);
  }

  public static int getCapabilityInt32(int paramInt1, int paramInt2)
  {
    return ImmVibe.getInstance().getDeviceCapabilityInt32(paramInt1, paramInt2);
  }

  public static String getCapabilityString(int paramInt1, int paramInt2)
  {
    return ImmVibe.getInstance().getDeviceCapabilityString(paramInt1, paramInt2);
  }

  public static int getCount()
  {
    return ImmVibe.getInstance().getDeviceCount();
  }

  public static int getState(int paramInt)
  {
    return ImmVibe.getInstance().getDeviceState(paramInt);
  }

  public static Device newDevice()
    throws RuntimeException
  {
    Device localDevice = newDeviceInstance();
    if (localDevice != null)
    {
      localDevice.deviceIndex = -1;
      localDevice.deviceHandle = ImmVibe.getInstance().openCompositeDevice(getCount());
      return localDevice;
    }
    throw new RuntimeException("VIBE_E_FAIL");
  }

  public static Device newDevice(int paramInt)
    throws RuntimeException
  {
    Device localDevice = newDeviceInstance();
    if (localDevice != null)
    {
      localDevice.deviceIndex = paramInt;
      localDevice.deviceHandle = ImmVibe.getInstance().openDevice(paramInt);
      return localDevice;
    }
    throw new RuntimeException("VIBE_E_FAIL");
  }

  private static Device newDeviceInstance()
  {
    Device localDevice = newDeviceInstanceForName("com.immersion.android.Device");
    if (localDevice == null)
    {
      localDevice = newDeviceInstanceForName("com.immersion.J2ME.Device");
      if (localDevice == null)
        localDevice = new Device();
    }
    return localDevice;
  }

  private static Device newDeviceInstanceForName(String paramString)
  {
    Device localDevice = null;
    try
    {
      localDevice = (Device)Class.forName(paramString).newInstance();
      label13: return localDevice;
    }
    catch (Exception localException)
    {
      break label13;
    }
  }

  public void close()
  {
    ImmVibe.getInstance().closeDevice(this.deviceHandle);
    this.deviceHandle = -1;
    this.deviceIndex = -1;
  }

  public EffectHandle createStreamingEffect()
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().createStreamingEffect(this.deviceHandle));
  }

  public boolean getCapabilityBool(int paramInt)
  {
    return ImmVibe.getInstance().getDeviceCapabilityBool(this.deviceIndex, paramInt);
  }

  public int getCapabilityInt32(int paramInt)
  {
    return ImmVibe.getInstance().getDeviceCapabilityInt32(this.deviceIndex, paramInt);
  }

  public String getCapabilityString(int paramInt)
  {
    return ImmVibe.getInstance().getDeviceCapabilityString(this.deviceIndex, paramInt);
  }

  public boolean getPropertyBool(int paramInt)
  {
    return ImmVibe.getInstance().getDevicePropertyBool(this.deviceHandle, paramInt);
  }

  public int getPropertyInt32(int paramInt)
  {
    return ImmVibe.getInstance().getDevicePropertyInt32(this.deviceHandle, paramInt);
  }

  public String getPropertyString(int paramInt)
  {
    return ImmVibe.getInstance().getDevicePropertyString(this.deviceHandle, paramInt);
  }

  public int getState()
  {
    return ImmVibe.getInstance().getDeviceState(this.deviceIndex);
  }

  protected EffectHandle newEffectHandle(int paramInt1, int paramInt2)
  {
    return new EffectHandle(paramInt1, paramInt2);
  }

  public EffectHandle playIVTEffect(IVTBuffer paramIVTBuffer, int paramInt)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playIVTEffect(this.deviceHandle, paramIVTBuffer.getBuffer(), paramInt));
  }

  public EffectHandle playIVTEffectRepeat(IVTBuffer paramIVTBuffer, int paramInt, byte paramByte)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playIVTEffectRepeat(this.deviceHandle, paramIVTBuffer.getBuffer(), paramInt, paramByte));
  }

  public EffectHandle playIVTInterpolatedEffect(IVTBuffer paramIVTBuffer, int paramInt1, int paramInt2)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playIVTInterpolatedEffect(this.deviceHandle, paramIVTBuffer.getBuffer(), paramInt1, paramInt2));
  }

  public EffectHandle playMagSweepEffect(MagSweepEffectDefinition paramMagSweepEffectDefinition)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playMagSweepEffect(this.deviceHandle, paramMagSweepEffectDefinition.getDuration(), paramMagSweepEffectDefinition.getMagnitude(), paramMagSweepEffectDefinition.getStyle(), paramMagSweepEffectDefinition.getAttackTime(), paramMagSweepEffectDefinition.getAttackLevel(), paramMagSweepEffectDefinition.getFadeTime(), paramMagSweepEffectDefinition.getFadeLevel()));
  }

  public EffectHandle playPeriodicEffect(PeriodicEffectDefinition paramPeriodicEffectDefinition)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playPeriodicEffect(this.deviceHandle, paramPeriodicEffectDefinition.getDuration(), paramPeriodicEffectDefinition.getMagnitude(), paramPeriodicEffectDefinition.getPeriod(), paramPeriodicEffectDefinition.getStyleAndWaveType(), paramPeriodicEffectDefinition.getAttackTime(), paramPeriodicEffectDefinition.getAttackLevel(), paramPeriodicEffectDefinition.getFadeTime(), paramPeriodicEffectDefinition.getFadeLevel()));
  }

  public EffectHandle playWaveformEffect(WaveformEffectDefinition paramWaveformEffectDefinition)
  {
    return newEffectHandle(this.deviceHandle, ImmVibe.getInstance().playWaveformEffect(this.deviceHandle, paramWaveformEffectDefinition.getData(), paramWaveformEffectDefinition.getDataSize(), paramWaveformEffectDefinition.getSampleRate(), paramWaveformEffectDefinition.getBitDepth(), paramWaveformEffectDefinition.getMagnitude()));
  }

  public void setPropertyBool(int paramInt, boolean paramBoolean)
  {
    ImmVibe.getInstance().setDevicePropertyBool(this.deviceHandle, paramInt, paramBoolean);
  }

  public void setPropertyInt32(int paramInt1, int paramInt2)
  {
    ImmVibe.getInstance().setDevicePropertyInt32(this.deviceHandle, paramInt1, paramInt2);
  }

  public void setPropertyString(int paramInt, String paramString)
  {
    ImmVibe.getInstance().setDevicePropertyString(this.deviceHandle, paramInt, paramString);
  }

  public void stopAllPlayingEffects()
  {
    ImmVibe.getInstance().stopAllPlayingEffects(this.deviceHandle);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.Device
 * JD-Core Version:    0.6.2
 */