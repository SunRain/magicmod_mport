package com.immersion;

public class IVTWaveformElement extends IVTElement
{
  private WaveformEffectDefinition definition;

  public IVTWaveformElement(int paramInt, WaveformEffectDefinition paramWaveformEffectDefinition)
  {
    super(3, paramInt);
    this.definition = paramWaveformEffectDefinition;
  }

  public int[] getBuffer()
  {
    int[] arrayOfInt = new int[8];
    arrayOfInt[0] = getType();
    arrayOfInt[1] = getTime();
    arrayOfInt[2] = 0;
    arrayOfInt[3] = this.definition.getDataSize();
    arrayOfInt[4] = this.definition.getSampleRate();
    arrayOfInt[5] = this.definition.getBitDepth();
    arrayOfInt[6] = this.definition.getMagnitude();
    arrayOfInt[7] = this.definition.getActuatorIndex();
    return arrayOfInt;
  }

  public WaveformEffectDefinition getDefinition()
  {
    return this.definition;
  }

  public void setDefinition(WaveformEffectDefinition paramWaveformEffectDefinition)
  {
    this.definition = paramWaveformEffectDefinition;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTWaveformElement
 * JD-Core Version:    0.6.2
 */