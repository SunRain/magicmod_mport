package com.immersion.android;

public class EffectHandle extends com.immersion.EffectHandle
{
  protected EffectHandle(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }

  protected void finalize()
  {
    if ((-1 != this.deviceHandle) && (-1 != this.effectHandle) && ((0x30000000 & this.effectHandle) == 805306368))
      ImmVibe.getInstance().destroyStreamingEffect(this.deviceHandle, this.effectHandle);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.android.EffectHandle
 * JD-Core Version:    0.6.2
 */