package com.immersion.android;

public class ImmVibe extends com.immersion.ImmVibe
{
  static
  {
    System.loadLibrary("ImmVibeJ");
  }

  private native int AppendWaveformEffect(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  private native void CloseDevice2(int paramInt);

  private native int CreateStreamingEffect(int paramInt);

  private native void DeleteIVTFile(String paramString);

  private native void DestroyStreamingEffect(int paramInt1, int paramInt2);

  private native byte[] GetBuiltInEffects();

  private native boolean GetDeviceCapabilityBool(int paramInt1, int paramInt2);

  private native int GetDeviceCapabilityInt32(int paramInt1, int paramInt2);

  private native String GetDeviceCapabilityString(int paramInt1, int paramInt2);

  private native int GetDeviceCount();

  private native int GetDeviceKernelParameter(int paramInt1, int paramInt2);

  private native boolean GetDevicePropertyBool(int paramInt1, int paramInt2);

  private native int GetDevicePropertyInt32(int paramInt1, int paramInt2);

  private native String GetDevicePropertyString(int paramInt1, int paramInt2);

  private native int GetDeviceState(int paramInt);

  private native int GetEffectState(int paramInt1, int paramInt2);

  private native int GetIVTEffectCount(byte[] paramArrayOfByte);

  private native int GetIVTEffectDuration(byte[] paramArrayOfByte, int paramInt);

  private native int GetIVTEffectIndexFromName(byte[] paramArrayOfByte, String paramString);

  private native String GetIVTEffectName(byte[] paramArrayOfByte, int paramInt);

  private native int GetIVTEffectType(byte[] paramArrayOfByte, int paramInt);

  private native void GetIVTMagSweepEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7);

  private native void GetIVTPeriodicEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7, int[] paramArrayOfInt8);

  private native int GetIVTSize2(byte[] paramArrayOfByte);

  private native void Initialize2();

  private native byte[] InitializeIVTBuffer(int paramInt);

  private native byte[] InsertIVTElement2(byte[] paramArrayOfByte1, int paramInt, int[] paramArrayOfInt, byte[] paramArrayOfByte2);

  private native void ModifyPlayingInterpolatedEffectInterpolant(int paramInt1, int paramInt2, int paramInt3);

  private native void ModifyPlayingMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);

  private native void ModifyPlayingPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);

  private native int OpenCompositeDevice2(int[] paramArrayOfInt, int paramInt);

  private native int OpenDevice2(int paramInt);

  private native void PausePlayingEffect(int paramInt1, int paramInt2);

  private native int PlayIVTEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2);

  private native int PlayIVTEffectRepeat(int paramInt1, byte[] paramArrayOfByte, int paramInt2, byte paramByte);

  private native int PlayIVTInterpolatedEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);

  private native int PlayMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);

  private native int PlayPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);

  private native void PlayStreamingSample(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);

  private native void PlayStreamingSampleWithOffset(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4);

  private native int PlayWaveformEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  private native int[] ReadIVTElement2(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  private native byte[] ReadIVTElementData(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  private native byte[] RemoveIVTElement2(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  private native void ResumePausedEffect(int paramInt1, int paramInt2);

  private native void SaveIVTFile(byte[] paramArrayOfByte, String paramString);

  private native void SetDevicePropertyBool(int paramInt1, int paramInt2, boolean paramBoolean);

  private native void SetDevicePropertyInt32(int paramInt1, int paramInt2, int paramInt3);

  private native void SetDevicePropertyString(int paramInt1, int paramInt2, String paramString);

  private native void StopAllPlayingEffects(int paramInt);

  private native void StopPlayingEffect(int paramInt1, int paramInt2);

  private native void Terminate2();

  public int appendWaveformEffect(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return AppendWaveformEffect(paramInt1, paramInt2, paramArrayOfByte, paramInt3, paramInt4, paramInt5, paramInt6);
  }

  public void closeDevice(int paramInt)
  {
    if (paramInt != -1)
      CloseDevice2(paramInt);
  }

  public int createStreamingEffect(int paramInt)
  {
    return CreateStreamingEffect(paramInt);
  }

  public void deleteIVTFile(String paramString)
  {
    DeleteIVTFile(paramString);
  }

  public void destroyStreamingEffect(int paramInt1, int paramInt2)
  {
    DestroyStreamingEffect(paramInt1, paramInt2);
  }

  public byte[] getBuiltInEffects()
  {
    return GetBuiltInEffects();
  }

  public boolean getDeviceCapabilityBool(int paramInt1, int paramInt2)
  {
    return GetDeviceCapabilityBool(paramInt1, paramInt2);
  }

  public int getDeviceCapabilityInt32(int paramInt1, int paramInt2)
  {
    return GetDeviceCapabilityInt32(paramInt1, paramInt2);
  }

  public String getDeviceCapabilityString(int paramInt1, int paramInt2)
  {
    return GetDeviceCapabilityString(paramInt1, paramInt2);
  }

  public int getDeviceCount()
  {
    return GetDeviceCount();
  }

  public int getDeviceKernelParameter(int paramInt1, int paramInt2)
  {
    return GetDeviceKernelParameter(paramInt1, paramInt2);
  }

  public boolean getDevicePropertyBool(int paramInt1, int paramInt2)
  {
    return GetDevicePropertyBool(paramInt1, paramInt2);
  }

  public int getDevicePropertyInt32(int paramInt1, int paramInt2)
  {
    return GetDevicePropertyInt32(paramInt1, paramInt2);
  }

  public String getDevicePropertyString(int paramInt1, int paramInt2)
  {
    return GetDevicePropertyString(paramInt1, paramInt2);
  }

  public int getDeviceState(int paramInt)
  {
    return GetDeviceState(paramInt);
  }

  public int getEffectState(int paramInt1, int paramInt2)
  {
    return GetEffectState(paramInt1, paramInt2);
  }

  public int getIVTEffectCount(byte[] paramArrayOfByte)
  {
    return GetIVTEffectCount(paramArrayOfByte);
  }

  public int getIVTEffectDuration(byte[] paramArrayOfByte, int paramInt)
  {
    return GetIVTEffectDuration(paramArrayOfByte, paramInt);
  }

  public int getIVTEffectIndexFromName(byte[] paramArrayOfByte, String paramString)
  {
    return GetIVTEffectIndexFromName(paramArrayOfByte, paramString);
  }

  public String getIVTEffectName(byte[] paramArrayOfByte, int paramInt)
  {
    return GetIVTEffectName(paramArrayOfByte, paramInt);
  }

  public int getIVTEffectType(byte[] paramArrayOfByte, int paramInt)
  {
    return GetIVTEffectType(paramArrayOfByte, paramInt);
  }

  public void getIVTMagSweepEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7)
  {
    GetIVTMagSweepEffectDefinition(paramArrayOfByte, paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5, paramArrayOfInt6, paramArrayOfInt7);
  }

  public void getIVTPeriodicEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7, int[] paramArrayOfInt8)
  {
    GetIVTPeriodicEffectDefinition(paramArrayOfByte, paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5, paramArrayOfInt6, paramArrayOfInt7, paramArrayOfInt8);
  }

  public int getIVTSize(byte[] paramArrayOfByte)
  {
    return GetIVTSize2(paramArrayOfByte);
  }

  public int getIVTSize(byte[] paramArrayOfByte, int paramInt)
  {
    return GetIVTSize2(paramArrayOfByte);
  }

  public void initialize()
  {
    Initialize2();
  }

  public byte[] initializeIVTBuffer(int paramInt)
  {
    return InitializeIVTBuffer(paramInt);
  }

  public byte[] insertIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    return InsertIVTElement2(paramArrayOfByte, paramInt2, paramArrayOfInt, null);
  }

  public byte[] insertIVTElement(byte[] paramArrayOfByte1, int paramInt, int[] paramArrayOfInt, byte[] paramArrayOfByte2)
  {
    return InsertIVTElement2(paramArrayOfByte1, paramInt, paramArrayOfInt, paramArrayOfByte2);
  }

  public void modifyPlayingInterpolatedEffectInterpolant(int paramInt1, int paramInt2, int paramInt3)
  {
    ModifyPlayingInterpolatedEffectInterpolant(paramInt1, paramInt2, paramInt3);
  }

  public void modifyPlayingMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    ModifyPlayingMagSweepEffect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
  }

  public void modifyPlayingPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    ModifyPlayingPeriodicEffect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10);
  }

  public int openCompositeDevice(int paramInt)
  {
    return OpenCompositeDevice2(null, paramInt);
  }

  public int openCompositeDevice(int[] paramArrayOfInt, int paramInt, String paramString)
  {
    int i = OpenCompositeDevice2(null, paramInt);
    if ((paramString != null) && (!paramString.equals("")));
    try
    {
      setDevicePropertyString(i, 0, paramString);
      return i;
    }
    catch (Exception localException)
    {
      CloseDevice2(i);
      throw new RuntimeException(localException.getMessage());
    }
  }

  public int openDevice(int paramInt)
  {
    return OpenDevice2(paramInt);
  }

  public int openDevice(int paramInt, String paramString)
  {
    int i = OpenDevice2(paramInt);
    if ((paramString != null) && (!paramString.equals("")));
    try
    {
      setDevicePropertyString(i, 0, paramString);
      return i;
    }
    catch (Exception localException)
    {
      CloseDevice2(i);
      throw new RuntimeException(localException.getMessage());
    }
  }

  public void pausePlayingEffect(int paramInt1, int paramInt2)
  {
    PausePlayingEffect(paramInt1, paramInt2);
  }

  public int playBuiltInEffect(int paramInt1, int paramInt2)
  {
    return PlayIVTEffect(paramInt1, GetBuiltInEffects(), paramInt2);
  }

  public int playBuiltInEffectRepeat(int paramInt1, int paramInt2, byte paramByte)
  {
    return PlayIVTEffectRepeat(paramInt1, GetBuiltInEffects(), paramInt2, paramByte);
  }

  public int playIVTEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    return PlayIVTEffect(paramInt1, paramArrayOfByte, paramInt2);
  }

  public int playIVTEffectRepeat(int paramInt1, byte[] paramArrayOfByte, int paramInt2, byte paramByte)
  {
    return PlayIVTEffectRepeat(paramInt1, paramArrayOfByte, paramInt2, paramByte);
  }

  public int playIVTInterpolatedEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    return PlayIVTInterpolatedEffect(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
  }

  public int playMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    return PlayMagSweepEffect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
  }

  public int playPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    return PlayPeriodicEffect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
  }

  public void playStreamingSample(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    PlayStreamingSample(paramInt1, paramInt2, paramArrayOfByte, paramInt3);
  }

  public void playStreamingSampleWithOffset(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4)
  {
    PlayStreamingSampleWithOffset(paramInt1, paramInt2, paramArrayOfByte, paramInt3, paramInt4);
  }

  public int playWaveformEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    return PlayWaveformEffect(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4, paramInt5);
  }

  public int[] readIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return ReadIVTElement2(paramArrayOfByte, paramInt1, paramInt2);
  }

  public int[] readIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    return ReadIVTElement2(paramArrayOfByte, paramInt2, paramInt3);
  }

  public byte[] readIVTElementData(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return ReadIVTElementData(paramArrayOfByte, paramInt1, paramInt1);
  }

  public byte[] removeIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    return RemoveIVTElement2(paramArrayOfByte, paramInt1, paramInt2);
  }

  public byte[] removeIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    return RemoveIVTElement2(paramArrayOfByte, paramInt2, paramInt3);
  }

  public void resumePausedEffect(int paramInt1, int paramInt2)
  {
    ResumePausedEffect(paramInt1, paramInt2);
  }

  public void saveIVTFile(byte[] paramArrayOfByte, String paramString)
  {
    SaveIVTFile(paramArrayOfByte, paramString);
  }

  public void setDevicePropertyBool(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    SetDevicePropertyBool(paramInt1, paramInt2, paramBoolean);
  }

  public void setDevicePropertyInt32(int paramInt1, int paramInt2, int paramInt3)
  {
    SetDevicePropertyInt32(paramInt1, paramInt2, paramInt3);
  }

  public void setDevicePropertyString(int paramInt1, int paramInt2, String paramString)
  {
    SetDevicePropertyString(paramInt1, paramInt2, paramString);
  }

  public void stopAllPlayingEffects(int paramInt)
  {
    StopAllPlayingEffects(paramInt);
  }

  public void stopPlayingEffect(int paramInt1, int paramInt2)
  {
    StopPlayingEffect(paramInt1, paramInt2);
  }

  public void terminate()
  {
    Terminate2();
    super.terminate();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.android.ImmVibe
 * JD-Core Version:    0.6.2
 */