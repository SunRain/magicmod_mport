package com.immersion.android;

public class Device extends com.immersion.Device
{
  protected void finalize()
  {
    if (-1 != this.deviceHandle)
      close();
  }

  protected com.immersion.EffectHandle newEffectHandle(int paramInt1, int paramInt2)
  {
    return new EffectHandle(paramInt1, paramInt2);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.android.Device
 * JD-Core Version:    0.6.2
 */