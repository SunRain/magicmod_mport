package com.immersion;

public class IVTElement
{
  private int time;
  private int type;

  IVTElement(int paramInt1, int paramInt2)
  {
    setType(paramInt1);
    setTime(paramInt2);
  }

  static IVTElement newIVTElement(int[] paramArrayOfInt)
  {
    Object localObject = null;
    if (paramArrayOfInt != null)
      switch (paramArrayOfInt[0])
      {
      default:
      case 1:
      case 0:
      case 3:
      case 2:
      }
    while (true)
    {
      return localObject;
      localObject = new IVTMagSweepElement(paramArrayOfInt[1], new MagSweepEffectDefinition(paramArrayOfInt[2], paramArrayOfInt[3], paramArrayOfInt[4], paramArrayOfInt[5], paramArrayOfInt[6], paramArrayOfInt[7], paramArrayOfInt[8], paramArrayOfInt[9]));
      continue;
      localObject = new IVTPeriodicElement(paramArrayOfInt[1], new PeriodicEffectDefinition(paramArrayOfInt[2], paramArrayOfInt[3], paramArrayOfInt[4], paramArrayOfInt[5], paramArrayOfInt[6], paramArrayOfInt[7], paramArrayOfInt[8], paramArrayOfInt[9], paramArrayOfInt[10]));
      continue;
      localObject = new IVTWaveformElement(paramArrayOfInt[1], new WaveformEffectDefinition(null, paramArrayOfInt[3], paramArrayOfInt[4], paramArrayOfInt[5], paramArrayOfInt[6], paramArrayOfInt[7]));
      continue;
      localObject = new IVTRepeatElement(paramArrayOfInt[1], paramArrayOfInt[2], paramArrayOfInt[3]);
    }
  }

  public int[] getBuffer()
  {
    return null;
  }

  public int getTime()
  {
    return this.time;
  }

  public int getType()
  {
    return this.type;
  }

  public void setTime(int paramInt)
  {
    this.time = paramInt;
  }

  void setType(int paramInt)
  {
    this.type = paramInt;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTElement
 * JD-Core Version:    0.6.2
 */