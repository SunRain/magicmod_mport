package com.immersion;

public class MagSweepEffectDefinition
{
  private int actuatorIndex;
  private int attackLevel;
  private int attackTime;
  private int duration;
  private int fadeLevel;
  private int fadeTime;
  private int magnitude;
  private int style;

  public MagSweepEffectDefinition(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    setDuration(paramInt1);
    setMagnitude(paramInt2);
    setStyle(paramInt3);
    setAttackTime(paramInt4);
    setAttackLevel(paramInt5);
    setFadeTime(paramInt6);
    setFadeLevel(paramInt7);
    setActuatorIndex(paramInt8);
  }

  public int getActuatorIndex()
  {
    return this.actuatorIndex;
  }

  public int getAttackLevel()
  {
    return this.attackLevel;
  }

  public int getAttackTime()
  {
    return this.attackTime;
  }

  public int getDuration()
  {
    return this.duration;
  }

  public int getFadeLevel()
  {
    return this.fadeLevel;
  }

  public int getFadeTime()
  {
    return this.fadeTime;
  }

  public int getMagnitude()
  {
    return this.magnitude;
  }

  public int getStyle()
  {
    return this.style;
  }

  public void setActuatorIndex(int paramInt)
  {
    this.actuatorIndex = paramInt;
  }

  public void setAttackLevel(int paramInt)
  {
    this.attackLevel = paramInt;
  }

  public void setAttackTime(int paramInt)
  {
    this.attackTime = paramInt;
  }

  public void setDuration(int paramInt)
  {
    this.duration = paramInt;
  }

  public void setFadeLevel(int paramInt)
  {
    this.fadeLevel = paramInt;
  }

  public void setFadeTime(int paramInt)
  {
    this.fadeTime = paramInt;
  }

  public void setMagnitude(int paramInt)
  {
    this.magnitude = paramInt;
  }

  public void setStyle(int paramInt)
  {
    this.style = paramInt;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.MagSweepEffectDefinition
 * JD-Core Version:    0.6.2
 */