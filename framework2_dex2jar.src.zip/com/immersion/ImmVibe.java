package com.immersion;

public abstract class ImmVibe
  implements ImmVibeAPI
{
  private static ImmVibe sInstance = null;

  public static ImmVibe getInstance()
  {
    ImmVibe localImmVibe;
    if (sInstance == null)
    {
      localImmVibe = newImmVibeInstance();
      if (localImmVibe == null)
        throw new RuntimeException("VIBE_E_FAIL");
      localImmVibe.initialize();
      sInstance = localImmVibe;
    }
    while (true)
    {
      return localImmVibe;
      localImmVibe = sInstance;
    }
  }

  private static ImmVibe newImmVibeInstance()
  {
    ImmVibe localImmVibe = newImmVibeInstanceForName("com.immersion.android.ImmVibe");
    if (localImmVibe == null)
      localImmVibe = newImmVibeInstanceForName("com.immersion.J2ME.ImmVibe");
    return localImmVibe;
  }

  private static ImmVibe newImmVibeInstanceForName(String paramString)
  {
    ImmVibe localImmVibe = null;
    try
    {
      localImmVibe = (ImmVibe)Class.forName(paramString).newInstance();
      label13: return localImmVibe;
    }
    catch (Exception localException)
    {
      break label13;
    }
  }

  public void terminate()
  {
    sInstance = null;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.ImmVibe
 * JD-Core Version:    0.6.2
 */