package com.immersion;

public class IVTMagSweepElement extends IVTElement
{
  private MagSweepEffectDefinition definition;

  public IVTMagSweepElement(int paramInt, MagSweepEffectDefinition paramMagSweepEffectDefinition)
  {
    super(1, paramInt);
    this.definition = paramMagSweepEffectDefinition;
  }

  public int[] getBuffer()
  {
    int[] arrayOfInt = new int[10];
    arrayOfInt[0] = getType();
    arrayOfInt[1] = getTime();
    arrayOfInt[2] = this.definition.getDuration();
    arrayOfInt[3] = this.definition.getMagnitude();
    arrayOfInt[4] = this.definition.getStyle();
    arrayOfInt[5] = this.definition.getAttackTime();
    arrayOfInt[6] = this.definition.getAttackLevel();
    arrayOfInt[7] = this.definition.getFadeTime();
    arrayOfInt[8] = this.definition.getFadeLevel();
    arrayOfInt[9] = this.definition.getActuatorIndex();
    return arrayOfInt;
  }

  public MagSweepEffectDefinition getDefinition()
  {
    return this.definition;
  }

  public void setDefinition(MagSweepEffectDefinition paramMagSweepEffectDefinition)
  {
    this.definition = paramMagSweepEffectDefinition;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTMagSweepElement
 * JD-Core Version:    0.6.2
 */