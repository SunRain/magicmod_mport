package com.immersion;

public class WaveformEffectDefinition
{
  private int actuatorIndex;
  private int bitDepth;
  private byte[] data;
  private int dataSize;
  private int magnitude;
  private int sampleRate;

  public WaveformEffectDefinition(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    setData(paramArrayOfByte);
    setDataSize(paramInt1);
    setSampleRate(paramInt2);
    setBitDepth(paramInt3);
    setMagnitude(paramInt4);
    setActuatorIndex(paramInt5);
  }

  public int getActuatorIndex()
  {
    return this.actuatorIndex;
  }

  public int getBitDepth()
  {
    return this.bitDepth;
  }

  public byte[] getData()
  {
    return this.data;
  }

  public int getDataSize()
  {
    return this.dataSize;
  }

  public int getMagnitude()
  {
    return this.magnitude;
  }

  public int getSampleRate()
  {
    return this.sampleRate;
  }

  public void setActuatorIndex(int paramInt)
  {
    this.actuatorIndex = paramInt;
  }

  public void setBitDepth(int paramInt)
  {
    this.bitDepth = paramInt;
  }

  public void setData(byte[] paramArrayOfByte)
  {
    this.data = paramArrayOfByte;
  }

  public void setDataSize(int paramInt)
  {
    this.dataSize = paramInt;
  }

  public void setMagnitude(int paramInt)
  {
    this.magnitude = paramInt;
  }

  public void setSampleRate(int paramInt)
  {
    this.sampleRate = paramInt;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.WaveformEffectDefinition
 * JD-Core Version:    0.6.2
 */