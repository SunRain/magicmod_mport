package com.immersion;

public class IVTBuffer
{
  private byte[] ivt;

  public IVTBuffer(int paramInt)
  {
    this.ivt = ImmVibe.getInstance().initializeIVTBuffer(paramInt);
  }

  public IVTBuffer(byte[] paramArrayOfByte)
  {
    this.ivt = paramArrayOfByte;
  }

  public static void deleteHapticTrack(String paramString)
  {
    ImmVibe.getInstance().deleteIVTFile(paramString);
  }

  public static IVTBuffer getBuiltInEffects()
  {
    return new IVTBuffer(ImmVibe.getInstance().getBuiltInEffects());
  }

  public byte[] getBuffer()
  {
    return this.ivt;
  }

  public int getEffectCount()
  {
    return ImmVibe.getInstance().getIVTEffectCount(this.ivt);
  }

  public int getEffectDuration(int paramInt)
  {
    return ImmVibe.getInstance().getIVTEffectDuration(this.ivt, paramInt);
  }

  public int getEffectIndexFromName(String paramString)
  {
    return ImmVibe.getInstance().getIVTEffectIndexFromName(this.ivt, paramString);
  }

  public String getEffectName(int paramInt)
  {
    return ImmVibe.getInstance().getIVTEffectName(this.ivt, paramInt);
  }

  public int getEffectType(int paramInt)
  {
    return ImmVibe.getInstance().getIVTEffectType(this.ivt, paramInt);
  }

  public MagSweepEffectDefinition getMagSweepEffectDefinitionAtIndex(int paramInt)
  {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int[] arrayOfInt7 = new int[1];
    ImmVibe.getInstance().getIVTMagSweepEffectDefinition(this.ivt, paramInt, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7);
    return new MagSweepEffectDefinition(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt3[0], arrayOfInt4[0], arrayOfInt5[0], arrayOfInt6[0], arrayOfInt7[0], 0);
  }

  public PeriodicEffectDefinition getPeriodicEffectDefinitionAtIndex(int paramInt)
  {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int[] arrayOfInt7 = new int[1];
    int[] arrayOfInt8 = new int[1];
    ImmVibe.getInstance().getIVTPeriodicEffectDefinition(this.ivt, paramInt, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8);
    return new PeriodicEffectDefinition(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt3[0], arrayOfInt4[0], arrayOfInt5[0], arrayOfInt6[0], arrayOfInt7[0], arrayOfInt8[0], 0);
  }

  public int getSize()
  {
    return ImmVibe.getInstance().getIVTSize(this.ivt);
  }

  public void insertElement(int paramInt, IVTElement paramIVTElement)
  {
    if (paramIVTElement.getType() == 3);
    for (this.ivt = ImmVibe.getInstance().insertIVTElement(this.ivt, paramInt, paramIVTElement.getBuffer(), ((IVTWaveformElement)paramIVTElement).getDefinition().getData()); ; this.ivt = ImmVibe.getInstance().insertIVTElement(this.ivt, paramInt, paramIVTElement.getBuffer(), null))
      return;
  }

  public IVTElement readElement(int paramInt1, int paramInt2)
  {
    IVTElement localIVTElement = IVTElement.newIVTElement(ImmVibe.getInstance().readIVTElement(this.ivt, paramInt1, paramInt2));
    if ((localIVTElement != null) && (localIVTElement.getType() == 3))
      ((IVTWaveformElement)localIVTElement).getDefinition().setData(ImmVibe.getInstance().readIVTElementData(this.ivt, paramInt1, paramInt2));
    return localIVTElement;
  }

  public void removeElement(int paramInt1, int paramInt2)
  {
    this.ivt = ImmVibe.getInstance().removeIVTElement(this.ivt, paramInt1, paramInt2);
  }

  public void saveHapticTrack(String paramString)
  {
    ImmVibe.getInstance().saveIVTFile(this.ivt, paramString);
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTBuffer
 * JD-Core Version:    0.6.2
 */