package com.immersion;

public class IVTRepeatElement extends IVTElement
{
  private int duration;
  private int repeatCount;

  public IVTRepeatElement(int paramInt1, int paramInt2, int paramInt3)
  {
    super(2, paramInt1);
    this.repeatCount = paramInt2;
    this.duration = paramInt3;
  }

  public int[] getBuffer()
  {
    int[] arrayOfInt = new int[4];
    arrayOfInt[0] = getType();
    arrayOfInt[1] = getTime();
    arrayOfInt[2] = this.repeatCount;
    arrayOfInt[3] = this.duration;
    return arrayOfInt;
  }

  public int getDuration()
  {
    return this.duration;
  }

  public int getRepeatCount()
  {
    return this.repeatCount;
  }

  public void setDuration(int paramInt)
  {
    this.duration = paramInt;
  }

  public void setRepeatCount(int paramInt)
  {
    this.repeatCount = paramInt;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTRepeatElement
 * JD-Core Version:    0.6.2
 */