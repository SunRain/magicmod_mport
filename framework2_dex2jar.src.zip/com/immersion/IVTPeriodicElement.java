package com.immersion;

public class IVTPeriodicElement extends IVTElement
{
  private PeriodicEffectDefinition definition;

  public IVTPeriodicElement(int paramInt, PeriodicEffectDefinition paramPeriodicEffectDefinition)
  {
    super(0, paramInt);
    this.definition = paramPeriodicEffectDefinition;
  }

  public int[] getBuffer()
  {
    int[] arrayOfInt = new int[11];
    arrayOfInt[0] = getType();
    arrayOfInt[1] = getTime();
    arrayOfInt[2] = this.definition.getDuration();
    arrayOfInt[3] = this.definition.getPeriod();
    arrayOfInt[4] = this.definition.getMagnitude();
    arrayOfInt[5] = this.definition.getStyleAndWaveType();
    arrayOfInt[6] = this.definition.getAttackTime();
    arrayOfInt[7] = this.definition.getAttackLevel();
    arrayOfInt[8] = this.definition.getFadeTime();
    arrayOfInt[9] = this.definition.getFadeLevel();
    arrayOfInt[10] = this.definition.getActuatorIndex();
    return arrayOfInt;
  }

  public PeriodicEffectDefinition getDefinition()
  {
    return this.definition;
  }

  public void setDefinition(PeriodicEffectDefinition paramPeriodicEffectDefinition)
  {
    this.definition = paramPeriodicEffectDefinition;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.IVTPeriodicElement
 * JD-Core Version:    0.6.2
 */