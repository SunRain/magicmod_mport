package com.immersion;

public abstract interface ImmVibeAPI
{
  public static final int VIBE_BUILTINEFFECT_LONG = 11;
  public static final int VIBE_BUILTINEFFECT_LONG_ON_LONG_OFF = 8;
  public static final int VIBE_BUILTINEFFECT_LONG_ON_MEDIUM_OFF = 7;
  public static final int VIBE_BUILTINEFFECT_LONG_ON_SHORT_OFF = 6;
  public static final int VIBE_BUILTINEFFECT_MEDIUM = 10;
  public static final int VIBE_BUILTINEFFECT_MEDIUM_ON_LONG_OFF = 5;
  public static final int VIBE_BUILTINEFFECT_MEDIUM_ON_MEDIUM_OFF = 4;
  public static final int VIBE_BUILTINEFFECT_MEDIUM_ON_SHORT_OFF = 3;
  public static final int VIBE_BUILTINEFFECT_SHORT = 9;
  public static final int VIBE_BUILTINEFFECT_SHORT_ON_LONG_OFF = 2;
  public static final int VIBE_BUILTINEFFECT_SHORT_ON_MEDIUM_OFF = 1;
  public static final int VIBE_BUILTINEFFECT_SHORT_ON_SHORT_OFF = 0;
  public static final int VIBE_DEFAULT_STYLE = 1;
  public static final int VIBE_DEFAULT_WAVETYPE = 16;
  public static final int VIBE_DEVACTUATORTYPE_BLDC = 1;
  public static final int VIBE_DEVACTUATORTYPE_ERM = 0;
  public static final int VIBE_DEVACTUATORTYPE_LRA = 2;
  public static final int VIBE_DEVACTUATORTYPE_PIEZO = 4;
  public static final int VIBE_DEVACTUATORTYPE_PIEZO_WAVE = 4;
  public static final int VIBE_DEVCAPTYPE_ACTUATOR_TYPE = 3;
  public static final int VIBE_DEVCAPTYPE_APIVERSIONNUMBER = 12;
  public static final int VIBE_DEVCAPTYPE_DEVICE_CATEGORY = 0;
  public static final int VIBE_DEVCAPTYPE_DEVICE_NAME = 10;
  public static final int VIBE_DEVCAPTYPE_EDITION_LEVEL = 15;
  public static final int VIBE_DEVCAPTYPE_HANDSET_INDEX = 17;
  public static final int VIBE_DEVCAPTYPE_MAX_EFFECT_DURATION = 8;
  public static final int VIBE_DEVCAPTYPE_MAX_ENVELOPE_TIME = 11;
  public static final int VIBE_DEVCAPTYPE_MAX_IVT_SIZE = 14;
  public static final int VIBE_DEVCAPTYPE_MAX_IVT_SIZE_TETHERED = 13;
  public static final int VIBE_DEVCAPTYPE_MAX_NESTED_REPEATS = 1;
  public static final int VIBE_DEVCAPTYPE_MAX_PERIOD = 7;
  public static final int VIBE_DEVCAPTYPE_MIN_PERIOD = 6;
  public static final int VIBE_DEVCAPTYPE_NUM_ACTUATORS = 2;
  public static final int VIBE_DEVCAPTYPE_NUM_EFFECT_SLOTS = 4;
  public static final int VIBE_DEVCAPTYPE_SUPPORTED_EFFECTS = 9;
  public static final int VIBE_DEVCAPTYPE_SUPPORTED_STYLES = 5;
  public static final int VIBE_DEVCAPTYPE_SUPPORTED_WAVE_TYPES = 16;
  public static final int VIBE_DEVICECATEGORY_COMPOSITE = 6;
  public static final int VIBE_DEVICECATEGORY_EMBEDDED = 3;
  public static final int VIBE_DEVICECATEGORY_IFC = 0;
  public static final int VIBE_DEVICECATEGORY_IMMERSION_USB = 5;
  public static final int VIBE_DEVICECATEGORY_IMPULSE = 1;
  public static final int VIBE_DEVICECATEGORY_TETHERED = 4;
  public static final int VIBE_DEVICECATEGORY_VIRTUAL = 2;
  public static final int VIBE_DEVICESTATE_ATTACHED = 1;
  public static final int VIBE_DEVICESTATE_BUSY = 2;
  public static final int VIBE_DEVPRIORITY_DEFAULT = 0;
  public static final int VIBE_DEVPROPTYPE_DISABLE_EFFECTS = 2;
  public static final int VIBE_DEVPROPTYPE_LICENSE_KEY = 0;
  public static final int VIBE_DEVPROPTYPE_MASTERSTRENGTH = 4;
  public static final int VIBE_DEVPROPTYPE_PRIORITY = 1;
  public static final int VIBE_DEVPROPTYPE_STRENGTH = 3;
  public static final int VIBE_EDITION_3000 = 3000;
  public static final int VIBE_EDITION_4000 = 4000;
  public static final int VIBE_EDITION_5000 = 5000;
  public static final int VIBE_EFFECT_STATE_NOT_PLAYING = 0;
  public static final int VIBE_EFFECT_STATE_PAUSED = 2;
  public static final int VIBE_EFFECT_STATE_PLAYING = 1;
  public static final int VIBE_EFFECT_TYPE_INTERPOLATED = 5;
  public static final int VIBE_EFFECT_TYPE_MAGSWEEP = 1;
  public static final int VIBE_EFFECT_TYPE_PERIODIC = 0;
  public static final int VIBE_EFFECT_TYPE_STREAMING = 3;
  public static final int VIBE_EFFECT_TYPE_TIMELINE = 2;
  public static final int VIBE_EFFECT_TYPE_WAVEFORM = 4;
  public static final int VIBE_ELEMTYPE_MAGSWEEP = 1;
  public static final int VIBE_ELEMTYPE_PERIODIC = 0;
  public static final int VIBE_ELEMTYPE_REPEAT = 2;
  public static final int VIBE_ELEMTYPE_WAVEFORM = 3;
  public static final int VIBE_E_ALREADY_INITIALIZED = -1;
  public static final int VIBE_E_DEVICE_NEEDS_LICENSE = -8;
  public static final int VIBE_E_FAIL = -4;
  public static final int VIBE_E_INCOMPATIBLE_CAPABILITY_TYPE = -6;
  public static final int VIBE_E_INCOMPATIBLE_EFFECT_TYPE = -5;
  public static final int VIBE_E_INCOMPATIBLE_PROPERTY_TYPE = -7;
  public static final int VIBE_E_INSUFFICIENT_PRIORITY = -11;
  public static final int VIBE_E_INVALID_ARGUMENT = -3;
  public static final int VIBE_E_NOT_ENOUGH_MEMORY = -9;
  public static final int VIBE_E_NOT_INITIALIZED = -2;
  public static final int VIBE_E_NOT_SUPPORTED = -13;
  public static final int VIBE_E_SERVICE_BUSY = -12;
  public static final int VIBE_E_SERVICE_NOT_RUNNING = -10;
  public static final int VIBE_INVALID_DEVICE_HANDLE_VALUE = -1;
  public static final int VIBE_INVALID_EFFECT_HANDLE_VALUE = -1;
  public static final int VIBE_INVALID_INDEX = -1;
  public static final int VIBE_MAGSWEEP_EFFECT_SUPPORT = 2;
  public static final int VIBE_MAX_CAPABILITY_STRING_LENGTH = 64;
  public static final int VIBE_MAX_DEVICE_NAME_LENGTH = 64;
  public static final int VIBE_MAX_DEVICE_PRIORITY = 15;
  public static final int VIBE_MAX_DEV_DEVICE_PRIORITY = 7;
  public static final int VIBE_MAX_EFFECT_NAME_LENGTH = 128;
  public static final int VIBE_MAX_INTERPOLANT = 10000;
  public static final int VIBE_MAX_LOGICAL_DEVICE_COUNT = 16;
  public static final int VIBE_MAX_MAGNITUDE = 10000;
  public static final int VIBE_MAX_OEM_DEVICE_PRIORITY = 15;
  public static final int VIBE_MAX_PROPERTY_STRING_LENGTH = 64;
  public static final int VIBE_MAX_STREAMING_SAMPLE_SIZE = 255;
  public static final int VIBE_MIN_DEVICE_PRIORITY = 0;
  public static final int VIBE_MIN_MAGNITUDE = 0;
  public static final int VIBE_PERIODIC_EFFECT_SUPPORT = 1;
  public static final int VIBE_PERIOD_RESOLUTION_MICROSECOND = -2147483648;
  public static final int VIBE_REPEAT_COUNT_INFINITE = 255;
  public static final int VIBE_STREAMING_EFFECT_SUPPORT = 8;
  public static final int VIBE_STYLE_MASK = 15;
  public static final int VIBE_STYLE_SHARP = 2;
  public static final int VIBE_STYLE_SHARP_SUPPORT = 4;
  public static final int VIBE_STYLE_SMOOTH = 0;
  public static final int VIBE_STYLE_SMOOTH_SUPPORT = 1;
  public static final int VIBE_STYLE_STRONG = 1;
  public static final int VIBE_STYLE_STRONG_SUPPORT = 2;
  public static final int VIBE_STYLE_SUPPORT_MASK = 65535;
  public static final int VIBE_S_FALSE = 0;
  public static final int VIBE_S_SUCCESS = 0;
  public static final int VIBE_S_TRUE = 1;
  public static final int VIBE_TIMELINE_EFFECT_SUPPORT = 4;
  public static final int VIBE_TIME_INFINITE = 2147483647;
  public static final int VIBE_WAVEFORM_EFFECT_SUPPORT = 16;
  public static final int VIBE_WAVETYPE_MASK = 240;
  public static final int VIBE_WAVETYPE_SAWTOOTHDOWN = 80;
  public static final int VIBE_WAVETYPE_SAWTOOTHDOWN_SUPPORT = 2097152;
  public static final int VIBE_WAVETYPE_SAWTOOTHUP = 64;
  public static final int VIBE_WAVETYPE_SAWTOOTHUP_SUPPORT = 1048576;
  public static final int VIBE_WAVETYPE_SHIFT = 4;
  public static final int VIBE_WAVETYPE_SINE = 48;
  public static final int VIBE_WAVETYPE_SINE_SUPPORT = 524288;
  public static final int VIBE_WAVETYPE_SQUARE = 16;
  public static final int VIBE_WAVETYPE_SQUARE_SUPPORT = 131072;
  public static final int VIBE_WAVETYPE_SUPPORT_MASK = -65536;
  public static final int VIBE_WAVETYPE_TRIANGLE = 32;
  public static final int VIBE_WAVETYPE_TRIANGLE_SUPPORT = 262144;
  public static final int VIBE_W_EFFECTS_DISABLED = 3;
  public static final int VIBE_W_INSUFFICIENT_PRIORITY = 2;
  public static final int VIBE_W_NOT_PAUSED = 4;
  public static final int VIBE_W_NOT_PLAYING = 1;

  public abstract int appendWaveformEffect(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  public abstract void closeDevice(int paramInt);

  public abstract int createStreamingEffect(int paramInt);

  public abstract void deleteIVTFile(String paramString);

  public abstract void destroyStreamingEffect(int paramInt1, int paramInt2);

  public abstract byte[] getBuiltInEffects();

  public abstract boolean getDeviceCapabilityBool(int paramInt1, int paramInt2);

  public abstract int getDeviceCapabilityInt32(int paramInt1, int paramInt2);

  public abstract String getDeviceCapabilityString(int paramInt1, int paramInt2);

  public abstract int getDeviceCount();

  public abstract int getDeviceKernelParameter(int paramInt1, int paramInt2);

  public abstract boolean getDevicePropertyBool(int paramInt1, int paramInt2);

  public abstract int getDevicePropertyInt32(int paramInt1, int paramInt2);

  public abstract String getDevicePropertyString(int paramInt1, int paramInt2);

  public abstract int getDeviceState(int paramInt);

  public abstract int getEffectState(int paramInt1, int paramInt2);

  public abstract int getIVTEffectCount(byte[] paramArrayOfByte);

  public abstract int getIVTEffectDuration(byte[] paramArrayOfByte, int paramInt);

  public abstract int getIVTEffectIndexFromName(byte[] paramArrayOfByte, String paramString);

  public abstract String getIVTEffectName(byte[] paramArrayOfByte, int paramInt);

  public abstract int getIVTEffectType(byte[] paramArrayOfByte, int paramInt);

  public abstract void getIVTMagSweepEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7);

  public abstract void getIVTPeriodicEffectDefinition(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7, int[] paramArrayOfInt8);

  public abstract int getIVTSize(byte[] paramArrayOfByte);

  public abstract void initialize();

  public abstract byte[] initializeIVTBuffer(int paramInt);

  public abstract byte[] insertIVTElement(byte[] paramArrayOfByte1, int paramInt, int[] paramArrayOfInt, byte[] paramArrayOfByte2);

  public abstract void modifyPlayingInterpolatedEffectInterpolant(int paramInt1, int paramInt2, int paramInt3);

  public abstract void modifyPlayingMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);

  public abstract void modifyPlayingPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);

  public abstract int openCompositeDevice(int paramInt);

  public abstract int openDevice(int paramInt);

  public abstract void pausePlayingEffect(int paramInt1, int paramInt2);

  public abstract int playIVTEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2);

  public abstract int playIVTEffectRepeat(int paramInt1, byte[] paramArrayOfByte, int paramInt2, byte paramByte);

  public abstract int playIVTInterpolatedEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);

  public abstract int playMagSweepEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);

  public abstract int playPeriodicEffect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);

  public abstract void playStreamingSample(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);

  public abstract void playStreamingSampleWithOffset(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4);

  public abstract int playWaveformEffect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract int[] readIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract byte[] readIVTElementData(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract byte[] removeIVTElement(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract void resumePausedEffect(int paramInt1, int paramInt2);

  public abstract void saveIVTFile(byte[] paramArrayOfByte, String paramString);

  public abstract void setDevicePropertyBool(int paramInt1, int paramInt2, boolean paramBoolean);

  public abstract void setDevicePropertyInt32(int paramInt1, int paramInt2, int paramInt3);

  public abstract void setDevicePropertyString(int paramInt1, int paramInt2, String paramString);

  public abstract void stopAllPlayingEffects(int paramInt);

  public abstract void stopPlayingEffect(int paramInt1, int paramInt2);

  public abstract void terminate();
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.immersion.ImmVibeAPI
 * JD-Core Version:    0.6.2
 */