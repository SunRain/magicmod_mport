package com.google.android.gles_jni;

import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.opengles.GL;

public class EGLContextImpl extends EGLContext
{
  int mEGLContext;
  private GLImpl mGLContext;

  public EGLContextImpl(int paramInt)
  {
    this.mEGLContext = paramInt;
    this.mGLContext = new GLImpl();
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if ((paramObject == null) || (getClass() != paramObject.getClass()))
      {
        bool = false;
      }
      else
      {
        EGLContextImpl localEGLContextImpl = (EGLContextImpl)paramObject;
        if (this.mEGLContext != localEGLContextImpl.mEGLContext)
          bool = false;
      }
    }
  }

  public GL getGL()
  {
    return this.mGLContext;
  }

  public int hashCode()
  {
    return this.mEGLContext;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.gles_jni.EGLContextImpl
 * JD-Core Version:    0.6.2
 */