package com.google.android.gles_jni;

import javax.microedition.khronos.egl.EGLConfig;

public class EGLConfigImpl extends EGLConfig
{
  private int mEGLConfig;

  EGLConfigImpl(int paramInt)
  {
    this.mEGLConfig = paramInt;
  }

  int get()
  {
    return this.mEGLConfig;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.gles_jni.EGLConfigImpl
 * JD-Core Version:    0.6.2
 */