package com.google.android.gles_jni;

import javax.microedition.khronos.egl.EGLDisplay;

public class EGLDisplayImpl extends EGLDisplay
{
  int mEGLDisplay;

  public EGLDisplayImpl(int paramInt)
  {
    this.mEGLDisplay = paramInt;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = true;
    if (this == paramObject);
    while (true)
    {
      return bool;
      if ((paramObject == null) || (getClass() != paramObject.getClass()))
      {
        bool = false;
      }
      else
      {
        EGLDisplayImpl localEGLDisplayImpl = (EGLDisplayImpl)paramObject;
        if (this.mEGLDisplay != localEGLDisplayImpl.mEGLDisplay)
          bool = false;
      }
    }
  }

  public int hashCode()
  {
    return this.mEGLDisplay;
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.gles_jni.EGLDisplayImpl
 * JD-Core Version:    0.6.2
 */