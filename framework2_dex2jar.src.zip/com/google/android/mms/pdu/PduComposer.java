package com.google.android.mms.pdu;

import android.content.ContentResolver;
import android.content.Context;
import android.text.TextUtils;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashMap;

public class PduComposer
{
  private static final int END_STRING_FLAG = 0;
  private static final int LENGTH_QUOTE = 31;
  private static final int LONG_INTEGER_LENGTH_MAX = 8;
  private static final int PDU_COMPOSER_BLOCK_SIZE = 1024;
  private static final int PDU_COMPOSE_CONTENT_ERROR = 1;
  private static final int PDU_COMPOSE_FIELD_NOT_SET = 2;
  private static final int PDU_COMPOSE_FIELD_NOT_SUPPORTED = 3;
  private static final int PDU_COMPOSE_SUCCESS = 0;
  private static final int PDU_EMAIL_ADDRESS_TYPE = 2;
  private static final int PDU_IPV4_ADDRESS_TYPE = 3;
  private static final int PDU_IPV6_ADDRESS_TYPE = 4;
  private static final int PDU_PHONE_NUMBER_ADDRESS_TYPE = 1;
  private static final int PDU_UNKNOWN_ADDRESS_TYPE = 5;
  private static final int QUOTED_STRING_FLAG = 34;
  static final String REGEXP_EMAIL_ADDRESS_TYPE = "[a-zA-Z| ]*\\<{0,1}[a-zA-Z| ]+@{1}[a-zA-Z| ]+\\.{1}[a-zA-Z| ]+\\>{0,1}";
  static final String REGEXP_IPV4_ADDRESS_TYPE = "[0-9]{1,3}\\.{1}[0-9]{1,3}\\.{1}[0-9]{1,3}\\.{1}[0-9]{1,3}";
  static final String REGEXP_IPV6_ADDRESS_TYPE = "[a-fA-F]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}";
  static final String REGEXP_PHONE_NUMBER_ADDRESS_TYPE = "\\+?[0-9|\\.|\\-]+";
  private static final int SHORT_INTEGER_MAX = 127;
  static final String STRING_IPV4_ADDRESS_TYPE = "/TYPE=IPV4";
  static final String STRING_IPV6_ADDRESS_TYPE = "/TYPE=IPV6";
  static final String STRING_PHONE_NUMBER_ADDRESS_TYPE = "/TYPE=PLMN";
  private static final int TEXT_MAX = 127;
  private static HashMap<String, Integer> mContentTypeMap;
  protected ByteArrayOutputStream mMessage = null;
  private GenericPdu mPdu = null;
  private PduHeaders mPduHeader = null;
  protected int mPosition = 0;
  private final ContentResolver mResolver;
  private BufferStack mStack = null;

  static
  {
    if (!PduComposer.class.desiredAssertionStatus());
    for (boolean bool = true; ; bool = false)
    {
      $assertionsDisabled = bool;
      mContentTypeMap = null;
      mContentTypeMap = new HashMap();
      for (int i = 0; i < PduContentTypes.contentTypes.length; i++)
        mContentTypeMap.put(PduContentTypes.contentTypes[i], Integer.valueOf(i));
    }
  }

  public PduComposer(Context paramContext, GenericPdu paramGenericPdu)
  {
    this.mPdu = paramGenericPdu;
    this.mResolver = paramContext.getContentResolver();
    this.mPduHeader = paramGenericPdu.getPduHeaders();
    this.mStack = new BufferStack(null);
    this.mMessage = new ByteArrayOutputStream();
    this.mPosition = 0;
  }

  private EncodedStringValue appendAddressType(EncodedStringValue paramEncodedStringValue)
  {
    try
    {
      int i = checkAddressType(paramEncodedStringValue.getString());
      EncodedStringValue localEncodedStringValue2 = EncodedStringValue.copy(paramEncodedStringValue);
      if (1 == i)
        localEncodedStringValue2.appendTextString("/TYPE=PLMN".getBytes());
      else if (3 == i)
        localEncodedStringValue2.appendTextString("/TYPE=IPV4".getBytes());
      else if (4 == i)
        localEncodedStringValue2.appendTextString("/TYPE=IPV6".getBytes());
      localEncodedStringValue1 = localEncodedStringValue2;
      return localEncodedStringValue1;
    }
    catch (NullPointerException localNullPointerException)
    {
      while (true)
        EncodedStringValue localEncodedStringValue1 = null;
    }
  }

  private int appendHeader(int paramInt)
  {
    int j;
    int i1;
    switch (paramInt)
    {
    case 131:
    case 132:
    case 135:
    case 140:
    case 142:
    case 146:
    case 147:
    case 148:
    case 153:
    case 154:
    default:
      j = 3;
      return j;
    case 141:
      appendOctet(paramInt);
      i1 = this.mPduHeader.getOctet(paramInt);
      if (i1 == 0)
        appendShortInteger(18);
      break;
    case 139:
    case 152:
    case 129:
    case 130:
    case 151:
    case 137:
    case 134:
    case 143:
    case 144:
    case 145:
    case 149:
    case 155:
    case 133:
    case 150:
    case 138:
    case 136:
    }
    while (true)
    {
      label156: j = 0;
      break;
      appendShortInteger(i1);
      continue;
      byte[] arrayOfByte2 = this.mPduHeader.getTextString(paramInt);
      if (arrayOfByte2 == null)
      {
        j = 2;
        break;
      }
      appendOctet(paramInt);
      appendTextString(arrayOfByte2);
      continue;
      EncodedStringValue[] arrayOfEncodedStringValue = this.mPduHeader.getEncodedStringValues(paramInt);
      if (arrayOfEncodedStringValue == null)
      {
        j = 2;
        break;
      }
      for (int n = 0; ; n++)
      {
        if (n >= arrayOfEncodedStringValue.length)
          break label156;
        EncodedStringValue localEncodedStringValue4 = appendAddressType(arrayOfEncodedStringValue[n]);
        if (localEncodedStringValue4 == null)
        {
          j = 1;
          break;
        }
        appendOctet(paramInt);
        appendEncodedString(localEncodedStringValue4);
      }
      appendOctet(paramInt);
      EncodedStringValue localEncodedStringValue2 = this.mPduHeader.getEncodedStringValue(paramInt);
      if ((localEncodedStringValue2 == null) || (TextUtils.isEmpty(localEncodedStringValue2.getString())) || (new String(localEncodedStringValue2.getTextString()).equals("insert-address-token")))
      {
        append(1);
        append(129);
      }
      else
      {
        this.mStack.newbuf();
        PositionMarker localPositionMarker2 = this.mStack.mark();
        append(128);
        EncodedStringValue localEncodedStringValue3 = appendAddressType(localEncodedStringValue2);
        if (localEncodedStringValue3 == null)
        {
          j = 1;
          break;
        }
        appendEncodedString(localEncodedStringValue3);
        int m = localPositionMarker2.getLength();
        this.mStack.pop();
        appendValueLength(m);
        this.mStack.copy();
        continue;
        int k = this.mPduHeader.getOctet(paramInt);
        if (k == 0)
        {
          j = 2;
          break;
        }
        appendOctet(paramInt);
        appendOctet(k);
        continue;
        long l2 = this.mPduHeader.getLongInteger(paramInt);
        if (-1L == l2)
        {
          j = 2;
          break;
        }
        appendOctet(paramInt);
        appendDateValue(l2);
        continue;
        EncodedStringValue localEncodedStringValue1 = this.mPduHeader.getEncodedStringValue(paramInt);
        if (localEncodedStringValue1 == null)
        {
          j = 2;
          break;
        }
        appendOctet(paramInt);
        appendEncodedString(localEncodedStringValue1);
        continue;
        byte[] arrayOfByte1 = this.mPduHeader.getTextString(paramInt);
        if (arrayOfByte1 == null)
        {
          j = 2;
          break;
        }
        appendOctet(paramInt);
        if (Arrays.equals(arrayOfByte1, "advertisement".getBytes()))
        {
          appendOctet(129);
        }
        else if (Arrays.equals(arrayOfByte1, "auto".getBytes()))
        {
          appendOctet(131);
        }
        else if (Arrays.equals(arrayOfByte1, "personal".getBytes()))
        {
          appendOctet(128);
        }
        else if (Arrays.equals(arrayOfByte1, "informational".getBytes()))
        {
          appendOctet(130);
        }
        else
        {
          appendTextString(arrayOfByte1);
          continue;
          long l1 = this.mPduHeader.getLongInteger(paramInt);
          if (-1L == l1)
          {
            j = 2;
            break;
          }
          appendOctet(paramInt);
          this.mStack.newbuf();
          PositionMarker localPositionMarker1 = this.mStack.mark();
          append(129);
          appendLongInteger(l1);
          int i = localPositionMarker1.getLength();
          this.mStack.pop();
          appendValueLength(i);
          this.mStack.copy();
        }
      }
    }
  }

  protected static int checkAddressType(String paramString)
  {
    int i = 5;
    if (paramString == null);
    while (true)
    {
      return i;
      if (paramString.matches("[0-9]{1,3}\\.{1}[0-9]{1,3}\\.{1}[0-9]{1,3}\\.{1}[0-9]{1,3}"))
        i = 3;
      else if (paramString.matches("\\+?[0-9|\\.|\\-]+"))
        i = 1;
      else if (paramString.matches("[a-zA-Z| ]*\\<{0,1}[a-zA-Z| ]+@{1}[a-zA-Z| ]+\\.{1}[a-zA-Z| ]+\\>{0,1}"))
        i = 2;
      else if (paramString.matches("[a-fA-F]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}\\:{1}[a-fA-F0-9]{4}"))
        i = 4;
    }
  }

  private int makeAckInd()
  {
    int i = 1;
    if (this.mMessage == null)
    {
      this.mMessage = new ByteArrayOutputStream();
      this.mPosition = 0;
    }
    appendOctet(140);
    appendOctet(133);
    if (appendHeader(152) != 0);
    while (true)
    {
      return i;
      if (appendHeader(141) == 0)
      {
        appendHeader(145);
        i = 0;
      }
    }
  }

  // ERROR //
  private int makeMessageBody()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   4: invokevirtual 221	com/google/android/mms/pdu/PduComposer$BufferStack:newbuf	()V
    //   7: aload_0
    //   8: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   11: invokevirtual 225	com/google/android/mms/pdu/PduComposer$BufferStack:mark	()Lcom/google/android/mms/pdu/PduComposer$PositionMarker;
    //   14: astore_1
    //   15: new 158	java/lang/String
    //   18: dup
    //   19: aload_0
    //   20: getfield 115	com/google/android/mms/pdu/PduComposer:mPduHeader	Lcom/google/android/mms/pdu/PduHeaders;
    //   23: sipush 132
    //   26: invokevirtual 184	com/google/android/mms/pdu/PduHeaders:getTextString	(I)[B
    //   29: invokespecial 209	java/lang/String:<init>	([B)V
    //   32: astore_2
    //   33: getstatic 82	com/google/android/mms/pdu/PduComposer:mContentTypeMap	Ljava/util/HashMap;
    //   36: aload_2
    //   37: invokevirtual 285	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   40: checkcast 95	java/lang/Integer
    //   43: astore_3
    //   44: aload_3
    //   45: ifnonnull +9 -> 54
    //   48: iconst_1
    //   49: istore 5
    //   51: iload 5
    //   53: ireturn
    //   54: aload_0
    //   55: aload_3
    //   56: invokevirtual 288	java/lang/Integer:intValue	()I
    //   59: invokevirtual 180	com/google/android/mms/pdu/PduComposer:appendShortInteger	(I)V
    //   62: aload_0
    //   63: getfield 109	com/google/android/mms/pdu/PduComposer:mPdu	Lcom/google/android/mms/pdu/GenericPdu;
    //   66: checkcast 290	com/google/android/mms/pdu/SendReq
    //   69: invokevirtual 294	com/google/android/mms/pdu/SendReq:getBody	()Lcom/google/android/mms/pdu/PduBody;
    //   72: astore 4
    //   74: aload 4
    //   76: ifnull +11 -> 87
    //   79: aload 4
    //   81: invokevirtual 299	com/google/android/mms/pdu/PduBody:getPartsNum	()I
    //   84: ifne +28 -> 112
    //   87: aload_0
    //   88: lconst_0
    //   89: invokevirtual 302	com/google/android/mms/pdu/PduComposer:appendUintvarInteger	(J)V
    //   92: aload_0
    //   93: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   96: invokevirtual 234	com/google/android/mms/pdu/PduComposer$BufferStack:pop	()V
    //   99: aload_0
    //   100: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   103: invokevirtual 240	com/google/android/mms/pdu/PduComposer$BufferStack:copy	()V
    //   106: iconst_0
    //   107: istore 5
    //   109: goto -58 -> 51
    //   112: aload 4
    //   114: iconst_0
    //   115: invokevirtual 306	com/google/android/mms/pdu/PduBody:getPart	(I)Lcom/google/android/mms/pdu/PduPart;
    //   118: astore 38
    //   120: aload 38
    //   122: invokevirtual 311	com/google/android/mms/pdu/PduPart:getContentId	()[B
    //   125: astore 39
    //   127: aload 39
    //   129: ifnull +38 -> 167
    //   132: aload_0
    //   133: sipush 138
    //   136: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   139: bipush 60
    //   141: aload 39
    //   143: iconst_0
    //   144: baload
    //   145: if_icmpne +148 -> 293
    //   148: bipush 62
    //   150: aload 39
    //   152: iconst_m1
    //   153: aload 39
    //   155: arraylength
    //   156: iadd
    //   157: baload
    //   158: if_icmpne +135 -> 293
    //   161: aload_0
    //   162: aload 39
    //   164: invokevirtual 185	com/google/android/mms/pdu/PduComposer:appendTextString	([B)V
    //   167: aload_0
    //   168: sipush 137
    //   171: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   174: aload_0
    //   175: aload 38
    //   177: invokevirtual 314	com/google/android/mms/pdu/PduPart:getContentType	()[B
    //   180: invokevirtual 185	com/google/android/mms/pdu/PduComposer:appendTextString	([B)V
    //   183: aload_1
    //   184: invokevirtual 231	com/google/android/mms/pdu/PduComposer$PositionMarker:getLength	()I
    //   187: istore 7
    //   189: aload_0
    //   190: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   193: invokevirtual 234	com/google/android/mms/pdu/PduComposer$BufferStack:pop	()V
    //   196: aload_0
    //   197: iload 7
    //   199: i2l
    //   200: invokevirtual 238	com/google/android/mms/pdu/PduComposer:appendValueLength	(J)V
    //   203: aload_0
    //   204: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   207: invokevirtual 240	com/google/android/mms/pdu/PduComposer$BufferStack:copy	()V
    //   210: aload 4
    //   212: invokevirtual 299	com/google/android/mms/pdu/PduBody:getPartsNum	()I
    //   215: istore 8
    //   217: aload_0
    //   218: iload 8
    //   220: i2l
    //   221: invokevirtual 302	com/google/android/mms/pdu/PduComposer:appendUintvarInteger	(J)V
    //   224: iconst_0
    //   225: istore 9
    //   227: iload 9
    //   229: iload 8
    //   231: if_icmpge +641 -> 872
    //   234: aload 4
    //   236: iload 9
    //   238: invokevirtual 306	com/google/android/mms/pdu/PduBody:getPart	(I)Lcom/google/android/mms/pdu/PduPart;
    //   241: astore 10
    //   243: aload_0
    //   244: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   247: invokevirtual 221	com/google/android/mms/pdu/PduComposer$BufferStack:newbuf	()V
    //   250: aload_0
    //   251: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   254: invokevirtual 225	com/google/android/mms/pdu/PduComposer$BufferStack:mark	()Lcom/google/android/mms/pdu/PduComposer$PositionMarker;
    //   257: astore 11
    //   259: aload_0
    //   260: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   263: invokevirtual 221	com/google/android/mms/pdu/PduComposer$BufferStack:newbuf	()V
    //   266: aload_0
    //   267: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   270: invokevirtual 225	com/google/android/mms/pdu/PduComposer$BufferStack:mark	()Lcom/google/android/mms/pdu/PduComposer$PositionMarker;
    //   273: astore 12
    //   275: aload 10
    //   277: invokevirtual 314	com/google/android/mms/pdu/PduPart:getContentType	()[B
    //   280: astore 13
    //   282: aload 13
    //   284: ifnonnull +68 -> 352
    //   287: iconst_1
    //   288: istore 5
    //   290: goto -239 -> 51
    //   293: new 316	java/lang/StringBuilder
    //   296: dup
    //   297: invokespecial 317	java/lang/StringBuilder:<init>	()V
    //   300: ldc_w 319
    //   303: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: astore 40
    //   308: new 158	java/lang/String
    //   311: dup
    //   312: aload 39
    //   314: invokespecial 209	java/lang/String:<init>	([B)V
    //   317: astore 41
    //   319: aload_0
    //   320: aload 40
    //   322: aload 41
    //   324: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   327: ldc_w 324
    //   330: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   333: invokevirtual 327	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   336: invokevirtual 330	com/google/android/mms/pdu/PduComposer:appendTextString	(Ljava/lang/String;)V
    //   339: goto -172 -> 167
    //   342: astore 6
    //   344: aload 6
    //   346: invokevirtual 333	java/lang/ArrayIndexOutOfBoundsException:printStackTrace	()V
    //   349: goto -166 -> 183
    //   352: getstatic 82	com/google/android/mms/pdu/PduComposer:mContentTypeMap	Ljava/util/HashMap;
    //   355: astore 14
    //   357: new 158	java/lang/String
    //   360: dup
    //   361: aload 13
    //   363: invokespecial 209	java/lang/String:<init>	([B)V
    //   366: astore 15
    //   368: aload 14
    //   370: aload 15
    //   372: invokevirtual 285	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   375: checkcast 95	java/lang/Integer
    //   378: astore 16
    //   380: aload 16
    //   382: ifnonnull +51 -> 433
    //   385: aload_0
    //   386: aload 13
    //   388: invokevirtual 185	com/google/android/mms/pdu/PduComposer:appendTextString	([B)V
    //   391: aload 10
    //   393: invokevirtual 336	com/google/android/mms/pdu/PduPart:getName	()[B
    //   396: astore 17
    //   398: aload 17
    //   400: ifnonnull +45 -> 445
    //   403: aload 10
    //   405: invokevirtual 339	com/google/android/mms/pdu/PduPart:getFilename	()[B
    //   408: astore 17
    //   410: aload 17
    //   412: ifnonnull +33 -> 445
    //   415: aload 10
    //   417: invokevirtual 342	com/google/android/mms/pdu/PduPart:getContentLocation	()[B
    //   420: astore 17
    //   422: aload 17
    //   424: ifnonnull +21 -> 445
    //   427: iconst_1
    //   428: istore 5
    //   430: goto -379 -> 51
    //   433: aload_0
    //   434: aload 16
    //   436: invokevirtual 288	java/lang/Integer:intValue	()I
    //   439: invokevirtual 180	com/google/android/mms/pdu/PduComposer:appendShortInteger	(I)V
    //   442: goto -51 -> 391
    //   445: aload_0
    //   446: sipush 133
    //   449: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   452: aload_0
    //   453: aload 17
    //   455: invokevirtual 185	com/google/android/mms/pdu/PduComposer:appendTextString	([B)V
    //   458: aload 10
    //   460: invokevirtual 345	com/google/android/mms/pdu/PduPart:getCharset	()I
    //   463: istore 18
    //   465: iload 18
    //   467: ifeq +16 -> 483
    //   470: aload_0
    //   471: sipush 129
    //   474: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   477: aload_0
    //   478: iload 18
    //   480: invokevirtual 180	com/google/android/mms/pdu/PduComposer:appendShortInteger	(I)V
    //   483: aload 12
    //   485: invokevirtual 231	com/google/android/mms/pdu/PduComposer$PositionMarker:getLength	()I
    //   488: istore 19
    //   490: aload_0
    //   491: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   494: invokevirtual 234	com/google/android/mms/pdu/PduComposer$BufferStack:pop	()V
    //   497: aload_0
    //   498: iload 19
    //   500: i2l
    //   501: invokevirtual 238	com/google/android/mms/pdu/PduComposer:appendValueLength	(J)V
    //   504: aload_0
    //   505: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   508: invokevirtual 240	com/google/android/mms/pdu/PduComposer$BufferStack:copy	()V
    //   511: aload 10
    //   513: invokevirtual 311	com/google/android/mms/pdu/PduPart:getContentId	()[B
    //   516: astore 20
    //   518: aload 20
    //   520: ifnull +38 -> 558
    //   523: aload_0
    //   524: sipush 192
    //   527: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   530: bipush 60
    //   532: aload 20
    //   534: iconst_0
    //   535: baload
    //   536: if_icmpne +112 -> 648
    //   539: bipush 62
    //   541: aload 20
    //   543: iconst_m1
    //   544: aload 20
    //   546: arraylength
    //   547: iadd
    //   548: baload
    //   549: if_icmpne +99 -> 648
    //   552: aload_0
    //   553: aload 20
    //   555: invokevirtual 348	com/google/android/mms/pdu/PduComposer:appendQuotedString	([B)V
    //   558: aload 10
    //   560: invokevirtual 342	com/google/android/mms/pdu/PduPart:getContentLocation	()[B
    //   563: astore 21
    //   565: aload 21
    //   567: ifnull +16 -> 583
    //   570: aload_0
    //   571: sipush 142
    //   574: invokevirtual 172	com/google/android/mms/pdu/PduComposer:appendOctet	(I)V
    //   577: aload_0
    //   578: aload 21
    //   580: invokevirtual 185	com/google/android/mms/pdu/PduComposer:appendTextString	([B)V
    //   583: aload 11
    //   585: invokevirtual 231	com/google/android/mms/pdu/PduComposer$PositionMarker:getLength	()I
    //   588: istore 22
    //   590: iconst_0
    //   591: istore 23
    //   593: aload 10
    //   595: invokevirtual 351	com/google/android/mms/pdu/PduPart:getData	()[B
    //   598: astore 24
    //   600: aload 24
    //   602: ifnull +95 -> 697
    //   605: aload_0
    //   606: aload 24
    //   608: iconst_0
    //   609: aload 24
    //   611: arraylength
    //   612: invokevirtual 355	com/google/android/mms/pdu/PduComposer:arraycopy	([BII)V
    //   615: aload 24
    //   617: arraylength
    //   618: istore 23
    //   620: aload 11
    //   622: invokevirtual 231	com/google/android/mms/pdu/PduComposer$PositionMarker:getLength	()I
    //   625: iload 22
    //   627: isub
    //   628: istore 35
    //   630: iload 23
    //   632: iload 35
    //   634: if_icmpeq +204 -> 838
    //   637: new 281	java/lang/RuntimeException
    //   640: dup
    //   641: ldc_w 357
    //   644: invokespecial 359	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
    //   647: athrow
    //   648: new 316	java/lang/StringBuilder
    //   651: dup
    //   652: invokespecial 317	java/lang/StringBuilder:<init>	()V
    //   655: ldc_w 319
    //   658: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   661: astore 36
    //   663: new 158	java/lang/String
    //   666: dup
    //   667: aload 20
    //   669: invokespecial 209	java/lang/String:<init>	([B)V
    //   672: astore 37
    //   674: aload_0
    //   675: aload 36
    //   677: aload 37
    //   679: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   682: ldc_w 324
    //   685: invokevirtual 322	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   688: invokevirtual 327	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   691: invokevirtual 361	com/google/android/mms/pdu/PduComposer:appendQuotedString	(Ljava/lang/String;)V
    //   694: goto -136 -> 558
    //   697: aconst_null
    //   698: astore 25
    //   700: sipush 1024
    //   703: newarray byte
    //   705: astore 32
    //   707: aload_0
    //   708: getfield 123	com/google/android/mms/pdu/PduComposer:mResolver	Landroid/content/ContentResolver;
    //   711: aload 10
    //   713: invokevirtual 365	com/google/android/mms/pdu/PduPart:getDataUri	()Landroid/net/Uri;
    //   716: invokevirtual 371	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   719: astore 25
    //   721: aload 25
    //   723: aload 32
    //   725: invokevirtual 377	java/io/InputStream:read	([B)I
    //   728: istore 33
    //   730: iload 33
    //   732: iconst_m1
    //   733: if_icmpeq +150 -> 883
    //   736: aload_0
    //   737: getfield 107	com/google/android/mms/pdu/PduComposer:mMessage	Ljava/io/ByteArrayOutputStream;
    //   740: aload 32
    //   742: iconst_0
    //   743: iload 33
    //   745: invokevirtual 380	java/io/ByteArrayOutputStream:write	([BII)V
    //   748: aload_0
    //   749: iload 33
    //   751: aload_0
    //   752: getfield 111	com/google/android/mms/pdu/PduComposer:mPosition	I
    //   755: iadd
    //   756: putfield 111	com/google/android/mms/pdu/PduComposer:mPosition	I
    //   759: iload 23
    //   761: iload 33
    //   763: iadd
    //   764: istore 23
    //   766: goto -45 -> 721
    //   769: astore 31
    //   771: iconst_1
    //   772: istore 5
    //   774: aload 25
    //   776: ifnull -725 -> 51
    //   779: aload 25
    //   781: invokevirtual 383	java/io/InputStream:close	()V
    //   784: goto -733 -> 51
    //   787: astore 30
    //   789: iconst_1
    //   790: istore 5
    //   792: aload 25
    //   794: ifnull -743 -> 51
    //   797: aload 25
    //   799: invokevirtual 383	java/io/InputStream:close	()V
    //   802: goto -751 -> 51
    //   805: astore 28
    //   807: iconst_1
    //   808: istore 5
    //   810: aload 25
    //   812: ifnull -761 -> 51
    //   815: aload 25
    //   817: invokevirtual 383	java/io/InputStream:close	()V
    //   820: goto -769 -> 51
    //   823: astore 26
    //   825: aload 25
    //   827: ifnull +8 -> 835
    //   830: aload 25
    //   832: invokevirtual 383	java/io/InputStream:close	()V
    //   835: aload 26
    //   837: athrow
    //   838: aload_0
    //   839: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   842: invokevirtual 234	com/google/android/mms/pdu/PduComposer$BufferStack:pop	()V
    //   845: aload_0
    //   846: iload 22
    //   848: i2l
    //   849: invokevirtual 302	com/google/android/mms/pdu/PduComposer:appendUintvarInteger	(J)V
    //   852: aload_0
    //   853: iload 23
    //   855: i2l
    //   856: invokevirtual 302	com/google/android/mms/pdu/PduComposer:appendUintvarInteger	(J)V
    //   859: aload_0
    //   860: getfield 113	com/google/android/mms/pdu/PduComposer:mStack	Lcom/google/android/mms/pdu/PduComposer$BufferStack;
    //   863: invokevirtual 240	com/google/android/mms/pdu/PduComposer$BufferStack:copy	()V
    //   866: iinc 9 1
    //   869: goto -642 -> 227
    //   872: iconst_0
    //   873: istore 5
    //   875: goto -824 -> 51
    //   878: astore 27
    //   880: goto -45 -> 835
    //   883: aload 25
    //   885: ifnull -265 -> 620
    //   888: aload 25
    //   890: invokevirtual 383	java/io/InputStream:close	()V
    //   893: goto -273 -> 620
    //   896: astore 34
    //   898: goto -278 -> 620
    //   901: astore 29
    //   903: goto -852 -> 51
    //
    // Exception table:
    //   from	to	target	type
    //   112	183	342	java/lang/ArrayIndexOutOfBoundsException
    //   293	339	342	java/lang/ArrayIndexOutOfBoundsException
    //   700	759	769	java/io/FileNotFoundException
    //   700	759	787	java/io/IOException
    //   700	759	805	java/lang/RuntimeException
    //   700	759	823	finally
    //   830	835	878	java/io/IOException
    //   888	893	896	java/io/IOException
    //   779	820	901	java/io/IOException
  }

  private int makeNotifyResp()
  {
    int i = 1;
    if (this.mMessage == null)
    {
      this.mMessage = new ByteArrayOutputStream();
      this.mPosition = 0;
    }
    appendOctet(140);
    appendOctet(131);
    if (appendHeader(152) != 0);
    while (true)
    {
      return i;
      if ((appendHeader(141) == 0) && (appendHeader(149) == 0))
        i = 0;
    }
  }

  private int makeReadRecInd()
  {
    int i = 1;
    if (this.mMessage == null)
    {
      this.mMessage = new ByteArrayOutputStream();
      this.mPosition = 0;
    }
    appendOctet(140);
    appendOctet(135);
    if (appendHeader(141) != 0);
    while (true)
    {
      return i;
      if ((appendHeader(139) == 0) && (appendHeader(151) == 0) && (appendHeader(137) == 0))
      {
        appendHeader(133);
        if (appendHeader(155) == 0)
          i = 0;
      }
    }
  }

  private int makeSendReqPdu()
  {
    int i = 1;
    if (this.mMessage == null)
    {
      this.mMessage = new ByteArrayOutputStream();
      this.mPosition = 0;
    }
    appendOctet(140);
    appendOctet(128);
    appendOctet(152);
    byte[] arrayOfByte = this.mPduHeader.getTextString(152);
    if (arrayOfByte == null)
      throw new IllegalArgumentException("Transaction-ID is null.");
    appendTextString(arrayOfByte);
    if (appendHeader(141) != 0);
    while (true)
    {
      return i;
      appendHeader(133);
      if (appendHeader(137) == 0)
      {
        int j = 0;
        if (appendHeader(151) != i)
          j = 1;
        if (appendHeader(130) != i)
          j = 1;
        if (appendHeader(129) != i)
          j = 1;
        if (j != 0)
        {
          appendHeader(150);
          appendHeader(138);
          appendHeader(136);
          appendHeader(143);
          appendHeader(134);
          appendHeader(144);
          appendOctet(132);
          i = makeMessageBody();
        }
      }
    }
  }

  protected void append(int paramInt)
  {
    this.mMessage.write(paramInt);
    this.mPosition = (1 + this.mPosition);
  }

  protected void appendDateValue(long paramLong)
  {
    appendLongInteger(paramLong);
  }

  protected void appendEncodedString(EncodedStringValue paramEncodedStringValue)
  {
    assert (paramEncodedStringValue != null);
    int i = paramEncodedStringValue.getCharacterSet();
    byte[] arrayOfByte = paramEncodedStringValue.getTextString();
    if (arrayOfByte == null);
    while (true)
    {
      return;
      this.mStack.newbuf();
      PositionMarker localPositionMarker = this.mStack.mark();
      appendShortInteger(i);
      appendTextString(arrayOfByte);
      int j = localPositionMarker.getLength();
      this.mStack.pop();
      appendValueLength(j);
      this.mStack.copy();
    }
  }

  protected void appendLongInteger(long paramLong)
  {
    long l = paramLong;
    for (int i = 0; (l != 0L) && (i < 8); i++)
      l >>>= 8;
    appendShortLength(i);
    int j = 8 * (i - 1);
    for (int k = 0; k < i; k++)
    {
      append((int)(0xFF & paramLong >>> j));
      j -= 8;
    }
  }

  protected void appendOctet(int paramInt)
  {
    append(paramInt);
  }

  protected void appendQuotedString(String paramString)
  {
    appendQuotedString(paramString.getBytes());
  }

  protected void appendQuotedString(byte[] paramArrayOfByte)
  {
    append(34);
    arraycopy(paramArrayOfByte, 0, paramArrayOfByte.length);
    append(0);
  }

  protected void appendShortInteger(int paramInt)
  {
    append(0xFF & (paramInt | 0x80));
  }

  protected void appendShortLength(int paramInt)
  {
    append(paramInt);
  }

  protected void appendTextString(String paramString)
  {
    appendTextString(paramString.getBytes());
  }

  protected void appendTextString(byte[] paramArrayOfByte)
  {
    if ((0xFF & paramArrayOfByte[0]) > 127)
      append(127);
    arraycopy(paramArrayOfByte, 0, paramArrayOfByte.length);
    append(0);
  }

  protected void appendUintvarInteger(long paramLong)
  {
    long l = 127L;
    for (int i = 0; ; i++)
    {
      if ((i >= 5) || (paramLong < l))
        while (i > 0)
        {
          append((int)(0xFF & (0x80 | 0x7F & paramLong >>> i * 7)));
          i--;
        }
      l = 0x7F | l << 7;
    }
    append((int)(paramLong & 0x7F));
  }

  protected void appendValueLength(long paramLong)
  {
    if (paramLong < 31L)
      appendShortLength((int)paramLong);
    while (true)
    {
      return;
      append(31);
      appendUintvarInteger(paramLong);
    }
  }

  protected void arraycopy(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.mMessage.write(paramArrayOfByte, paramInt1, paramInt2);
    this.mPosition = (paramInt2 + this.mPosition);
  }

  public byte[] make()
  {
    byte[] arrayOfByte = null;
    switch (this.mPdu.getMessageType())
    {
    case 129:
    case 130:
    case 132:
    case 134:
    default:
    case 128:
    case 131:
    case 133:
    case 135:
    }
    while (true)
    {
      return arrayOfByte;
      if (makeSendReqPdu() == 0)
        do
        {
          do
          {
            do
            {
              arrayOfByte = this.mMessage.toByteArray();
              break;
            }
            while (makeNotifyResp() == 0);
            break;
          }
          while (makeAckInd() == 0);
          break;
        }
        while (makeReadRecInd() == 0);
    }
  }

  private class BufferStack
  {
    private PduComposer.LengthRecordNode stack = null;
    int stackSize = 0;
    private PduComposer.LengthRecordNode toCopy = null;

    private BufferStack()
    {
    }

    void copy()
    {
      PduComposer.this.arraycopy(this.toCopy.currentMessage.toByteArray(), 0, this.toCopy.currentPosition);
      this.toCopy = null;
    }

    PduComposer.PositionMarker mark()
    {
      PduComposer.PositionMarker localPositionMarker = new PduComposer.PositionMarker(PduComposer.this, null);
      PduComposer.PositionMarker.access$402(localPositionMarker, PduComposer.this.mPosition);
      PduComposer.PositionMarker.access$502(localPositionMarker, this.stackSize);
      return localPositionMarker;
    }

    void newbuf()
    {
      if (this.toCopy != null)
        throw new RuntimeException("BUG: Invalid newbuf() before copy()");
      PduComposer.LengthRecordNode localLengthRecordNode = new PduComposer.LengthRecordNode(null);
      localLengthRecordNode.currentMessage = PduComposer.this.mMessage;
      localLengthRecordNode.currentPosition = PduComposer.this.mPosition;
      localLengthRecordNode.next = this.stack;
      this.stack = localLengthRecordNode;
      this.stackSize = (1 + this.stackSize);
      PduComposer.this.mMessage = new ByteArrayOutputStream();
      PduComposer.this.mPosition = 0;
    }

    void pop()
    {
      ByteArrayOutputStream localByteArrayOutputStream = PduComposer.this.mMessage;
      int i = PduComposer.this.mPosition;
      PduComposer.this.mMessage = this.stack.currentMessage;
      PduComposer.this.mPosition = this.stack.currentPosition;
      this.toCopy = this.stack;
      this.stack = this.stack.next;
      this.stackSize = (-1 + this.stackSize);
      this.toCopy.currentMessage = localByteArrayOutputStream;
      this.toCopy.currentPosition = i;
    }
  }

  private static class LengthRecordNode
  {
    ByteArrayOutputStream currentMessage = null;
    public int currentPosition = 0;
    public LengthRecordNode next = null;
  }

  private class PositionMarker
  {
    private int c_pos;
    private int currentStackSize;

    private PositionMarker()
    {
    }

    int getLength()
    {
      if (this.currentStackSize != PduComposer.this.mStack.stackSize)
        throw new RuntimeException("BUG: Invalid call to getLength()");
      return PduComposer.this.mPosition - this.c_pos;
    }
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.mms.pdu.PduComposer
 * JD-Core Version:    0.6.2
 */