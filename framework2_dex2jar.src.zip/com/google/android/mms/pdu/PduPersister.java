package com.google.android.mms.pdu;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.drm.DrmManagerClient;
import android.net.Uri;
import android.net.Uri.Builder;
import android.provider.Telephony.Mms.Draft;
import android.provider.Telephony.Mms.Inbox;
import android.provider.Telephony.Mms.Outbox;
import android.provider.Telephony.Mms.Sent;
import android.provider.Telephony.MmsSms.PendingMessages;
import android.provider.Telephony.Threads;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.mms.ContentType;
import com.google.android.mms.InvalidHeaderValueException;
import com.google.android.mms.MmsException;
import com.google.android.mms.util.PduCache;
import com.google.android.mms.util.SqliteWrapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class PduPersister
{
  private static final int[] ADDRESS_FIELDS;
  private static final HashMap<Integer, Integer> CHARSET_COLUMN_INDEX_MAP;
  private static final HashMap<Integer, String> CHARSET_COLUMN_NAME_MAP;
  private static final boolean DEBUG = false;
  private static final long DUMMY_THREAD_ID = 9223372036854775807L;
  private static final HashMap<Integer, Integer> ENCODED_STRING_COLUMN_INDEX_MAP;
  private static final HashMap<Integer, String> ENCODED_STRING_COLUMN_NAME_MAP;
  private static final boolean LOCAL_LOGV = false;
  private static final HashMap<Integer, Integer> LONG_COLUMN_INDEX_MAP;
  private static final HashMap<Integer, String> LONG_COLUMN_NAME_MAP;
  private static final HashMap<Uri, Integer> MESSAGE_BOX_MAP;
  private static final HashMap<Integer, Integer> OCTET_COLUMN_INDEX_MAP;
  private static final HashMap<Integer, String> OCTET_COLUMN_NAME_MAP;
  private static final int PART_COLUMN_CHARSET = 1;
  private static final int PART_COLUMN_CONTENT_DISPOSITION = 2;
  private static final int PART_COLUMN_CONTENT_ID = 3;
  private static final int PART_COLUMN_CONTENT_LOCATION = 4;
  private static final int PART_COLUMN_CONTENT_TYPE = 5;
  private static final int PART_COLUMN_FILENAME = 6;
  private static final int PART_COLUMN_ID = 0;
  private static final int PART_COLUMN_NAME = 7;
  private static final int PART_COLUMN_TEXT = 8;
  private static final String[] PART_PROJECTION;
  private static final PduCache PDU_CACHE_INSTANCE;
  private static final int PDU_COLUMN_CONTENT_CLASS = 11;
  private static final int PDU_COLUMN_CONTENT_LOCATION = 5;
  private static final int PDU_COLUMN_CONTENT_TYPE = 6;
  private static final int PDU_COLUMN_DATE = 21;
  private static final int PDU_COLUMN_DELIVERY_REPORT = 12;
  private static final int PDU_COLUMN_DELIVERY_TIME = 22;
  private static final int PDU_COLUMN_EXPIRY = 23;
  private static final int PDU_COLUMN_ID = 0;
  private static final int PDU_COLUMN_MESSAGE_BOX = 1;
  private static final int PDU_COLUMN_MESSAGE_CLASS = 7;
  private static final int PDU_COLUMN_MESSAGE_ID = 8;
  private static final int PDU_COLUMN_MESSAGE_SIZE = 24;
  private static final int PDU_COLUMN_MESSAGE_TYPE = 13;
  private static final int PDU_COLUMN_MMS_VERSION = 14;
  private static final int PDU_COLUMN_PRIORITY = 15;
  private static final int PDU_COLUMN_READ_REPORT = 16;
  private static final int PDU_COLUMN_READ_STATUS = 17;
  private static final int PDU_COLUMN_REPORT_ALLOWED = 18;
  private static final int PDU_COLUMN_RESPONSE_TEXT = 9;
  private static final int PDU_COLUMN_RETRIEVE_STATUS = 19;
  private static final int PDU_COLUMN_RETRIEVE_TEXT = 3;
  private static final int PDU_COLUMN_RETRIEVE_TEXT_CHARSET = 26;
  private static final int PDU_COLUMN_STATUS = 20;
  private static final int PDU_COLUMN_SUBJECT = 4;
  private static final int PDU_COLUMN_SUBJECT_CHARSET = 25;
  private static final int PDU_COLUMN_THREAD_ID = 2;
  private static final int PDU_COLUMN_TRANSACTION_ID = 10;
  private static final String[] PDU_PROJECTION;
  public static final int PROC_STATUS_COMPLETED = 3;
  public static final int PROC_STATUS_PERMANENTLY_FAILURE = 2;
  public static final int PROC_STATUS_TRANSIENT_FAILURE = 1;
  private static final String TAG = "PduPersister";
  public static final String TEMPORARY_DRM_OBJECT_URI = "content://mms/9223372036854775807/part";
  private static final HashMap<Integer, Integer> TEXT_STRING_COLUMN_INDEX_MAP;
  private static final HashMap<Integer, String> TEXT_STRING_COLUMN_NAME_MAP;
  private static PduPersister sPersister;
  private final ContentResolver mContentResolver;
  private final Context mContext;
  private final DrmManagerClient mDrmManagerClient;
  private final TelephonyManager mTelephonyManager;

  static
  {
    if (!PduPersister.class.desiredAssertionStatus());
    for (boolean bool = true; ; bool = false)
    {
      $assertionsDisabled = bool;
      ADDRESS_FIELDS = new int[] { 129, 130, 137, 151 };
      PDU_PROJECTION = new String[] { "_id", "msg_box", "thread_id", "retr_txt", "sub", "ct_l", "ct_t", "m_cls", "m_id", "resp_txt", "tr_id", "ct_cls", "d_rpt", "m_type", "v", "pri", "rr", "read_status", "rpt_a", "retr_st", "st", "date", "d_tm", "exp", "m_size", "sub_cs", "retr_txt_cs" };
      PART_PROJECTION = new String[] { "_id", "chset", "cd", "cid", "cl", "ct", "fn", "name", "text" };
      MESSAGE_BOX_MAP = new HashMap();
      MESSAGE_BOX_MAP.put(Telephony.Mms.Inbox.CONTENT_URI, Integer.valueOf(1));
      MESSAGE_BOX_MAP.put(Telephony.Mms.Sent.CONTENT_URI, Integer.valueOf(2));
      MESSAGE_BOX_MAP.put(Telephony.Mms.Draft.CONTENT_URI, Integer.valueOf(3));
      MESSAGE_BOX_MAP.put(Telephony.Mms.Outbox.CONTENT_URI, Integer.valueOf(4));
      CHARSET_COLUMN_INDEX_MAP = new HashMap();
      CHARSET_COLUMN_INDEX_MAP.put(Integer.valueOf(150), Integer.valueOf(25));
      CHARSET_COLUMN_INDEX_MAP.put(Integer.valueOf(154), Integer.valueOf(26));
      CHARSET_COLUMN_NAME_MAP = new HashMap();
      CHARSET_COLUMN_NAME_MAP.put(Integer.valueOf(150), "sub_cs");
      CHARSET_COLUMN_NAME_MAP.put(Integer.valueOf(154), "retr_txt_cs");
      ENCODED_STRING_COLUMN_INDEX_MAP = new HashMap();
      ENCODED_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(154), Integer.valueOf(3));
      ENCODED_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(150), Integer.valueOf(4));
      ENCODED_STRING_COLUMN_NAME_MAP = new HashMap();
      ENCODED_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(154), "retr_txt");
      ENCODED_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(150), "sub");
      TEXT_STRING_COLUMN_INDEX_MAP = new HashMap();
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(131), Integer.valueOf(5));
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(132), Integer.valueOf(6));
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(138), Integer.valueOf(7));
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(139), Integer.valueOf(8));
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(147), Integer.valueOf(9));
      TEXT_STRING_COLUMN_INDEX_MAP.put(Integer.valueOf(152), Integer.valueOf(10));
      TEXT_STRING_COLUMN_NAME_MAP = new HashMap();
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(131), "ct_l");
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(132), "ct_t");
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(138), "m_cls");
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(139), "m_id");
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(147), "resp_txt");
      TEXT_STRING_COLUMN_NAME_MAP.put(Integer.valueOf(152), "tr_id");
      OCTET_COLUMN_INDEX_MAP = new HashMap();
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(186), Integer.valueOf(11));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(134), Integer.valueOf(12));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(140), Integer.valueOf(13));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(141), Integer.valueOf(14));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(143), Integer.valueOf(15));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(144), Integer.valueOf(16));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(155), Integer.valueOf(17));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(145), Integer.valueOf(18));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(153), Integer.valueOf(19));
      OCTET_COLUMN_INDEX_MAP.put(Integer.valueOf(149), Integer.valueOf(20));
      OCTET_COLUMN_NAME_MAP = new HashMap();
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(186), "ct_cls");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(134), "d_rpt");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(140), "m_type");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(141), "v");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(143), "pri");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(144), "rr");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(155), "read_status");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(145), "rpt_a");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(153), "retr_st");
      OCTET_COLUMN_NAME_MAP.put(Integer.valueOf(149), "st");
      LONG_COLUMN_INDEX_MAP = new HashMap();
      LONG_COLUMN_INDEX_MAP.put(Integer.valueOf(133), Integer.valueOf(21));
      LONG_COLUMN_INDEX_MAP.put(Integer.valueOf(135), Integer.valueOf(22));
      LONG_COLUMN_INDEX_MAP.put(Integer.valueOf(136), Integer.valueOf(23));
      LONG_COLUMN_INDEX_MAP.put(Integer.valueOf(142), Integer.valueOf(24));
      LONG_COLUMN_NAME_MAP = new HashMap();
      LONG_COLUMN_NAME_MAP.put(Integer.valueOf(133), "date");
      LONG_COLUMN_NAME_MAP.put(Integer.valueOf(135), "d_tm");
      LONG_COLUMN_NAME_MAP.put(Integer.valueOf(136), "exp");
      LONG_COLUMN_NAME_MAP.put(Integer.valueOf(142), "m_size");
      PDU_CACHE_INSTANCE = PduCache.getInstance();
      return;
    }
  }

  private PduPersister(Context paramContext)
  {
    this.mContext = paramContext;
    this.mContentResolver = paramContext.getContentResolver();
    this.mDrmManagerClient = new DrmManagerClient(paramContext);
    this.mTelephonyManager = ((TelephonyManager)paramContext.getSystemService("phone"));
  }

  public static String convertUriToPath(Context paramContext, Uri paramUri)
  {
    Object localObject1 = null;
    String str1;
    if (paramUri != null)
    {
      str1 = paramUri.getScheme();
      if ((str1 != null) && (!str1.equals("")) && (!str1.equals("file")))
        break label42;
      localObject1 = paramUri.getPath();
    }
    while (true)
    {
      return localObject1;
      label42: if (str1.equals("http"))
      {
        localObject1 = paramUri.toString();
      }
      else
      {
        if (!str1.equals("content"))
          break;
        String[] arrayOfString = { "_data" };
        Cursor localCursor = null;
        try
        {
          localCursor = paramContext.getContentResolver().query(paramUri, arrayOfString, null, null, null);
          if ((localCursor == null) || (localCursor.getCount() == 0) || (!localCursor.moveToFirst()))
            throw new IllegalArgumentException("Given Uri could not be found in media store");
        }
        catch (SQLiteException localSQLiteException)
        {
          throw new IllegalArgumentException("Given Uri is not formatted in a way so that it can be found in media store.");
        }
        finally
        {
          if (localCursor != null)
            localCursor.close();
        }
        String str2 = localCursor.getString(localCursor.getColumnIndexOrThrow("_data"));
        localObject1 = str2;
        if (localCursor != null)
          localCursor.close();
      }
    }
    throw new IllegalArgumentException("Given Uri scheme is not supported");
  }

  private byte[] getByteArrayFromPartColumn(Cursor paramCursor, int paramInt)
  {
    if (!paramCursor.isNull(paramInt));
    for (byte[] arrayOfByte = getBytes(paramCursor.getString(paramInt)); ; arrayOfByte = null)
      return arrayOfByte;
  }

  public static byte[] getBytes(String paramString)
  {
    try
    {
      byte[] arrayOfByte2 = paramString.getBytes("iso-8859-1");
      arrayOfByte1 = arrayOfByte2;
      return arrayOfByte1;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
      {
        Log.e("PduPersister", "ISO_8859_1 must be supported!", localUnsupportedEncodingException);
        byte[] arrayOfByte1 = new byte[0];
      }
    }
  }

  private Integer getIntegerFromPartColumn(Cursor paramCursor, int paramInt)
  {
    if (!paramCursor.isNull(paramInt));
    for (Integer localInteger = Integer.valueOf(paramCursor.getInt(paramInt)); ; localInteger = null)
      return localInteger;
  }

  private static String getPartContentType(PduPart paramPduPart)
  {
    if (paramPduPart.getContentType() == null);
    for (String str = null; ; str = toIsoString(paramPduPart.getContentType()))
      return str;
  }

  public static PduPersister getPduPersister(Context paramContext)
  {
    if ((sPersister == null) || (!paramContext.equals(sPersister.mContext)))
      sPersister = new PduPersister(paramContext);
    return sPersister;
  }

  private void loadAddress(long paramLong, PduHeaders paramPduHeaders)
  {
    Cursor localCursor = SqliteWrapper.query(this.mContext, this.mContentResolver, Uri.parse("content://mms/" + paramLong + "/addr"), new String[] { "address", "charset", "type" }, null, null, null);
    if (localCursor != null)
    {
      while (true)
      {
        String str;
        int i;
        try
        {
          if (!localCursor.moveToNext())
            break;
          str = localCursor.getString(0);
          if (TextUtils.isEmpty(str))
            continue;
          i = localCursor.getInt(2);
          switch (i)
          {
          default:
            Log.e("PduPersister", "Unknown address type: " + i);
            continue;
          case 137:
          case 129:
          case 130:
          case 151:
          }
        }
        finally
        {
          localCursor.close();
        }
        paramPduHeaders.setEncodedStringValue(new EncodedStringValue(localCursor.getInt(1), getBytes(str)), i);
        continue;
        paramPduHeaders.appendEncodedStringValue(new EncodedStringValue(localCursor.getInt(1), getBytes(str)), i);
      }
      localCursor.close();
    }
  }

  private PduPart[] loadParts(long paramLong)
    throws MmsException
  {
    Cursor localCursor = SqliteWrapper.query(this.mContext, this.mContentResolver, Uri.parse("content://mms/" + paramLong + "/part"), PART_PROJECTION, null, null, null);
    if (localCursor != null);
    while (true)
    {
      Object localObject1;
      PduPart[] arrayOfPduPart;
      Uri localUri;
      ByteArrayOutputStream localByteArrayOutputStream;
      InputStream localInputStream;
      try
      {
        int i = localCursor.getCount();
        if (i == 0)
        {
          localObject1 = null;
          return localObject1;
        }
        arrayOfPduPart = new PduPart[localCursor.getCount()];
        int j = 0;
        if (!localCursor.moveToNext())
          break label581;
        PduPart localPduPart = new PduPart();
        Integer localInteger = getIntegerFromPartColumn(localCursor, 1);
        if (localInteger != null)
          localPduPart.setCharset(localInteger.intValue());
        byte[] arrayOfByte1 = getByteArrayFromPartColumn(localCursor, 2);
        if (arrayOfByte1 != null)
          localPduPart.setContentDisposition(arrayOfByte1);
        byte[] arrayOfByte2 = getByteArrayFromPartColumn(localCursor, 3);
        if (arrayOfByte2 != null)
          localPduPart.setContentId(arrayOfByte2);
        byte[] arrayOfByte3 = getByteArrayFromPartColumn(localCursor, 4);
        if (arrayOfByte3 != null)
          localPduPart.setContentLocation(arrayOfByte3);
        byte[] arrayOfByte4 = getByteArrayFromPartColumn(localCursor, 5);
        if (arrayOfByte4 != null)
        {
          localPduPart.setContentType(arrayOfByte4);
          byte[] arrayOfByte5 = getByteArrayFromPartColumn(localCursor, 6);
          if (arrayOfByte5 != null)
            localPduPart.setFilename(arrayOfByte5);
          byte[] arrayOfByte6 = getByteArrayFromPartColumn(localCursor, 7);
          if (arrayOfByte6 != null)
            localPduPart.setName(arrayOfByte6);
          long l = localCursor.getLong(0);
          localUri = Uri.parse("content://mms/part/" + l);
          localPduPart.setDataUri(localUri);
          String str1 = toIsoString(arrayOfByte4);
          if ((!ContentType.isImageType(str1)) && (!ContentType.isAudioType(str1)) && (!ContentType.isVideoType(str1)))
          {
            localByteArrayOutputStream = new ByteArrayOutputStream();
            localInputStream = null;
            if ((!"text/plain".equals(str1)) && (!"application/smil".equals(str1)) && (!"text/html".equals(str1)))
              break label479;
            str2 = localCursor.getString(8);
            if (str2 == null)
              break label471;
            byte[] arrayOfByte7 = new EncodedStringValue(str2).getTextString();
            localByteArrayOutputStream.write(arrayOfByte7, 0, arrayOfByte7.length);
            localPduPart.setData(localByteArrayOutputStream.toByteArray());
          }
          int k = j + 1;
          arrayOfPduPart[j] = localPduPart;
          j = k;
          continue;
        }
        throw new MmsException("Content-Type must be set.");
      }
      finally
      {
        if (localCursor != null)
          localCursor.close();
      }
      label471: String str2 = "";
      continue;
      try
      {
        label479: localInputStream = this.mContentResolver.openInputStream(localUri);
        byte[] arrayOfByte8 = new byte[256];
        int n;
        for (int m = localInputStream.read(arrayOfByte8); m >= 0; m = n)
        {
          localByteArrayOutputStream.write(arrayOfByte8, 0, m);
          n = localInputStream.read(arrayOfByte8);
        }
      }
      catch (IOException localIOException2)
      {
        Log.e("PduPersister", "Failed to load part data", localIOException2);
        localCursor.close();
        throw new MmsException(localIOException2);
      }
      finally
      {
        if (localInputStream == null);
      }
      try
      {
        localInputStream.close();
        throw localObject3;
        label581: if (localCursor != null)
          localCursor.close();
        localObject1 = arrayOfPduPart;
      }
      catch (IOException localIOException1)
      {
        while (true)
          Log.e("PduPersister", "Failed to close stream", localIOException1);
      }
      if (localInputStream != null)
        try
        {
          localInputStream.close();
        }
        catch (IOException localIOException3)
        {
          Log.e("PduPersister", "Failed to close stream", localIOException3);
        }
    }
  }

  private void loadRecipients(int paramInt, HashSet<String> paramHashSet, HashMap<Integer, EncodedStringValue[]> paramHashMap, boolean paramBoolean)
  {
    EncodedStringValue[] arrayOfEncodedStringValue = (EncodedStringValue[])paramHashMap.get(Integer.valueOf(paramInt));
    if (arrayOfEncodedStringValue == null);
    while ((paramBoolean) && (arrayOfEncodedStringValue.length == 1))
      return;
    if (paramBoolean);
    for (String str1 = this.mTelephonyManager.getLine1Number(); ; str1 = null)
    {
      int i = arrayOfEncodedStringValue.length;
      for (int j = 0; j < i; j++)
      {
        EncodedStringValue localEncodedStringValue = arrayOfEncodedStringValue[j];
        if (localEncodedStringValue != null)
        {
          String str2 = localEncodedStringValue.getString();
          if (((str1 == null) || (!PhoneNumberUtils.compare(str2, str1))) && (!paramHashSet.contains(str2)))
            paramHashSet.add(str2);
        }
      }
      break;
    }
  }

  private void persistAddress(long paramLong, int paramInt, EncodedStringValue[] paramArrayOfEncodedStringValue)
  {
    ContentValues localContentValues = new ContentValues(3);
    int i = paramArrayOfEncodedStringValue.length;
    for (int j = 0; j < i; j++)
    {
      EncodedStringValue localEncodedStringValue = paramArrayOfEncodedStringValue[j];
      localContentValues.clear();
      localContentValues.put("address", toIsoString(localEncodedStringValue.getTextString()));
      localContentValues.put("charset", Integer.valueOf(localEncodedStringValue.getCharacterSet()));
      localContentValues.put("type", Integer.valueOf(paramInt));
      Uri localUri = Uri.parse("content://mms/" + paramLong + "/addr");
      SqliteWrapper.insert(this.mContext, this.mContentResolver, localUri, localContentValues);
    }
  }

  // ERROR //
  private void persistData(PduPart paramPduPart, Uri paramUri, String paramString, HashMap<Uri, InputStream> paramHashMap)
    throws MmsException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 5
    //   3: aconst_null
    //   4: astore 6
    //   6: aconst_null
    //   7: astore 7
    //   9: aconst_null
    //   10: astore 8
    //   12: aload_1
    //   13: invokevirtual 634	com/google/android/mms/pdu/PduPart:getData	()[B
    //   16: astore 22
    //   18: ldc_w 537
    //   21: aload_3
    //   22: invokevirtual 310	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   25: ifne +23 -> 48
    //   28: ldc_w 539
    //   31: aload_3
    //   32: invokevirtual 310	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   35: ifne +13 -> 48
    //   38: ldc_w 541
    //   41: aload_3
    //   42: invokevirtual 310	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   45: ifeq +203 -> 248
    //   48: new 607	android/content/ContentValues
    //   51: dup
    //   52: invokespecial 635	android/content/ContentValues:<init>	()V
    //   55: astore 23
    //   57: aload 23
    //   59: ldc 204
    //   61: new 459	com/google/android/mms/pdu/EncodedStringValue
    //   64: dup
    //   65: aload 22
    //   67: invokespecial 637	com/google/android/mms/pdu/EncodedStringValue:<init>	([B)V
    //   70: invokevirtual 589	com/google/android/mms/pdu/EncodedStringValue:getString	()Ljava/lang/String;
    //   73: invokevirtual 615	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/String;)V
    //   76: aload_0
    //   77: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   80: aload_2
    //   81: aload 23
    //   83: aconst_null
    //   84: aconst_null
    //   85: invokevirtual 641	android/content/ContentResolver:update	(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    //   88: iconst_1
    //   89: if_icmpeq +621 -> 710
    //   92: new 475	com/google/android/mms/MmsException
    //   95: dup
    //   96: new 412	java/lang/StringBuilder
    //   99: dup
    //   100: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   103: ldc_w 643
    //   106: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: aload_2
    //   110: invokevirtual 320	android/net/Uri:toString	()Ljava/lang/String;
    //   113: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   119: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   122: athrow
    //   123: astore 20
    //   125: ldc 103
    //   127: ldc_w 645
    //   130: aload 20
    //   132: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   135: pop
    //   136: new 475	com/google/android/mms/MmsException
    //   139: dup
    //   140: aload 20
    //   142: invokespecial 573	com/google/android/mms/MmsException:<init>	(Ljava/lang/Throwable;)V
    //   145: athrow
    //   146: astore 11
    //   148: aload 5
    //   150: ifnull +8 -> 158
    //   153: aload 5
    //   155: invokevirtual 648	java/io/OutputStream:close	()V
    //   158: aload 6
    //   160: ifnull +8 -> 168
    //   163: aload 6
    //   165: invokevirtual 574	java/io/InputStream:close	()V
    //   168: aload 7
    //   170: ifnull +75 -> 245
    //   173: aload 7
    //   175: aload 8
    //   177: invokevirtual 652	com/google/android/mms/util/DrmConvertSession:close	(Ljava/lang/String;)I
    //   180: pop
    //   181: new 654	java/io/File
    //   184: dup
    //   185: aload 8
    //   187: invokespecial 655	java/io/File:<init>	(Ljava/lang/String;)V
    //   190: astore 13
    //   192: new 607	android/content/ContentValues
    //   195: dup
    //   196: iconst_0
    //   197: invokespecial 609	android/content/ContentValues:<init>	(I)V
    //   200: astore 14
    //   202: aload_0
    //   203: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   206: aload_0
    //   207: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   210: new 412	java/lang/StringBuilder
    //   213: dup
    //   214: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   217: ldc_w 657
    //   220: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: aload 13
    //   225: invokevirtual 660	java/io/File:getName	()Ljava/lang/String;
    //   228: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   231: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   234: invokestatic 429	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   237: aload 14
    //   239: aconst_null
    //   240: aconst_null
    //   241: invokestatic 663	com/google/android/mms/util/SqliteWrapper:update	(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    //   244: pop
    //   245: aload 11
    //   247: athrow
    //   248: aload_3
    //   249: invokestatic 668	com/google/android/mms/util/DownloadDrmHelper:isDrmConvertNeeded	(Ljava/lang/String;)Z
    //   252: istore 35
    //   254: iload 35
    //   256: ifeq +179 -> 435
    //   259: aload_2
    //   260: ifnull +103 -> 363
    //   263: aload_0
    //   264: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   267: aload_2
    //   268: invokestatic 670	com/google/android/mms/pdu/PduPersister:convertUriToPath	(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;
    //   271: astore 8
    //   273: new 654	java/io/File
    //   276: dup
    //   277: aload 8
    //   279: invokespecial 655	java/io/File:<init>	(Ljava/lang/String;)V
    //   282: invokevirtual 674	java/io/File:length	()J
    //   285: lstore 52
    //   287: lload 52
    //   289: lconst_0
    //   290: lcmp
    //   291: ifle +72 -> 363
    //   294: iconst_0
    //   295: ifeq +5 -> 300
    //   298: aconst_null
    //   299: athrow
    //   300: iconst_0
    //   301: ifeq +5 -> 306
    //   304: aconst_null
    //   305: athrow
    //   306: iconst_0
    //   307: ifeq +22 -> 329
    //   310: aload 8
    //   312: pop
    //   313: aconst_null
    //   314: athrow
    //   315: aload 27
    //   317: aload 28
    //   319: aload 29
    //   321: aload 26
    //   323: aconst_null
    //   324: aconst_null
    //   325: invokestatic 663	com/google/android/mms/util/SqliteWrapper:update	(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    //   328: pop
    //   329: return
    //   330: astore 50
    //   332: ldc 103
    //   334: new 412	java/lang/StringBuilder
    //   337: dup
    //   338: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   341: ldc_w 676
    //   344: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   347: aload_1
    //   348: invokevirtual 680	com/google/android/mms/pdu/PduPart:getDataUri	()Landroid/net/Uri;
    //   351: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   354: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   357: aload 50
    //   359: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   362: pop
    //   363: aload_0
    //   364: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   367: aload_3
    //   368: invokestatic 687	com/google/android/mms/util/DrmConvertSession:open	(Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/mms/util/DrmConvertSession;
    //   371: astore 7
    //   373: aload 7
    //   375: ifnonnull +60 -> 435
    //   378: new 475	com/google/android/mms/MmsException
    //   381: dup
    //   382: new 412	java/lang/StringBuilder
    //   385: dup
    //   386: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   389: ldc_w 689
    //   392: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   395: aload_3
    //   396: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   399: ldc_w 691
    //   402: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   405: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   408: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   411: athrow
    //   412: astore 9
    //   414: ldc 103
    //   416: ldc_w 693
    //   419: aload 9
    //   421: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   424: pop
    //   425: new 475	com/google/android/mms/MmsException
    //   428: dup
    //   429: aload 9
    //   431: invokespecial 573	com/google/android/mms/MmsException:<init>	(Ljava/lang/Throwable;)V
    //   434: athrow
    //   435: aload_0
    //   436: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   439: aload_2
    //   440: invokevirtual 697	android/content/ContentResolver:openOutputStream	(Landroid/net/Uri;)Ljava/io/OutputStream;
    //   443: astore 5
    //   445: aload 22
    //   447: ifnonnull +251 -> 698
    //   450: aload_1
    //   451: invokevirtual 680	com/google/android/mms/pdu/PduPart:getDataUri	()Landroid/net/Uri;
    //   454: astore 38
    //   456: aload 38
    //   458: ifnull +9 -> 467
    //   461: aload 38
    //   463: aload_2
    //   464: if_acmpne +106 -> 570
    //   467: ldc 103
    //   469: ldc_w 699
    //   472: invokestatic 702	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;)I
    //   475: pop
    //   476: aload 5
    //   478: ifnull +8 -> 486
    //   481: aload 5
    //   483: invokevirtual 648	java/io/OutputStream:close	()V
    //   486: iconst_0
    //   487: ifeq +5 -> 492
    //   490: aconst_null
    //   491: athrow
    //   492: aload 7
    //   494: ifnull -165 -> 329
    //   497: aload 7
    //   499: aload 8
    //   501: invokevirtual 652	com/google/android/mms/util/DrmConvertSession:close	(Ljava/lang/String;)I
    //   504: pop
    //   505: new 654	java/io/File
    //   508: dup
    //   509: aload 8
    //   511: invokespecial 655	java/io/File:<init>	(Ljava/lang/String;)V
    //   514: astore 41
    //   516: new 607	android/content/ContentValues
    //   519: dup
    //   520: iconst_0
    //   521: invokespecial 609	android/content/ContentValues:<init>	(I)V
    //   524: astore 26
    //   526: aload_0
    //   527: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   530: astore 27
    //   532: aload_0
    //   533: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   536: astore 28
    //   538: new 412	java/lang/StringBuilder
    //   541: dup
    //   542: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   545: ldc_w 657
    //   548: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   551: aload 41
    //   553: invokevirtual 660	java/io/File:getName	()Ljava/lang/String;
    //   556: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   562: invokestatic 429	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   565: astore 29
    //   567: goto -252 -> 315
    //   570: aload 4
    //   572: ifnull +25 -> 597
    //   575: aload 4
    //   577: aload 38
    //   579: invokevirtual 705	java/util/HashMap:containsKey	(Ljava/lang/Object;)Z
    //   582: ifeq +15 -> 597
    //   585: aload 4
    //   587: aload 38
    //   589: invokevirtual 582	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   592: checkcast 564	java/io/InputStream
    //   595: astore 6
    //   597: aload 6
    //   599: ifnonnull +14 -> 613
    //   602: aload_0
    //   603: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   606: aload 38
    //   608: invokevirtual 562	android/content/ContentResolver:openInputStream	(Landroid/net/Uri;)Ljava/io/InputStream;
    //   611: astore 6
    //   613: sipush 8192
    //   616: newarray byte
    //   618: astore 46
    //   620: aload 6
    //   622: aload 46
    //   624: invokevirtual 568	java/io/InputStream:read	([B)I
    //   627: istore 47
    //   629: iload 47
    //   631: iconst_m1
    //   632: if_icmpeq +78 -> 710
    //   635: iload 35
    //   637: ifne +16 -> 653
    //   640: aload 5
    //   642: aload 46
    //   644: iconst_0
    //   645: iload 47
    //   647: invokevirtual 706	java/io/OutputStream:write	([BII)V
    //   650: goto -30 -> 620
    //   653: aload 7
    //   655: aload 46
    //   657: iload 47
    //   659: invokevirtual 710	com/google/android/mms/util/DrmConvertSession:convert	([BI)[B
    //   662: astore 48
    //   664: aload 48
    //   666: ifnull +21 -> 687
    //   669: aload 48
    //   671: arraylength
    //   672: istore 49
    //   674: aload 5
    //   676: aload 48
    //   678: iconst_0
    //   679: iload 49
    //   681: invokevirtual 706	java/io/OutputStream:write	([BII)V
    //   684: goto -64 -> 620
    //   687: new 475	com/google/android/mms/MmsException
    //   690: dup
    //   691: ldc_w 712
    //   694: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   697: athrow
    //   698: iload 35
    //   700: ifne +108 -> 808
    //   703: aload 5
    //   705: aload 22
    //   707: invokevirtual 714	java/io/OutputStream:write	([B)V
    //   710: aload 5
    //   712: ifnull +8 -> 720
    //   715: aload 5
    //   717: invokevirtual 648	java/io/OutputStream:close	()V
    //   720: aload 6
    //   722: ifnull +8 -> 730
    //   725: aload 6
    //   727: invokevirtual 574	java/io/InputStream:close	()V
    //   730: aload 7
    //   732: ifnull -403 -> 329
    //   735: aload 7
    //   737: aload 8
    //   739: invokevirtual 652	com/google/android/mms/util/DrmConvertSession:close	(Ljava/lang/String;)I
    //   742: pop
    //   743: new 654	java/io/File
    //   746: dup
    //   747: aload 8
    //   749: invokespecial 655	java/io/File:<init>	(Ljava/lang/String;)V
    //   752: astore 25
    //   754: new 607	android/content/ContentValues
    //   757: dup
    //   758: iconst_0
    //   759: invokespecial 609	android/content/ContentValues:<init>	(I)V
    //   762: astore 26
    //   764: aload_0
    //   765: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   768: astore 27
    //   770: aload_0
    //   771: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   774: astore 28
    //   776: new 412	java/lang/StringBuilder
    //   779: dup
    //   780: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   783: ldc_w 657
    //   786: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   789: aload 25
    //   791: invokevirtual 660	java/io/File:getName	()Ljava/lang/String;
    //   794: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   797: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   800: invokestatic 429	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   803: astore 29
    //   805: goto -490 -> 315
    //   808: aload 7
    //   810: aload 22
    //   812: aload 22
    //   814: arraylength
    //   815: invokevirtual 710	com/google/android/mms/util/DrmConvertSession:convert	([BI)[B
    //   818: astore 36
    //   820: aload 36
    //   822: ifnull +21 -> 843
    //   825: aload 36
    //   827: arraylength
    //   828: istore 37
    //   830: aload 5
    //   832: aload 36
    //   834: iconst_0
    //   835: iload 37
    //   837: invokevirtual 706	java/io/OutputStream:write	([BII)V
    //   840: goto -130 -> 710
    //   843: new 475	com/google/android/mms/MmsException
    //   846: dup
    //   847: ldc_w 712
    //   850: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   853: athrow
    //   854: astore 18
    //   856: ldc 103
    //   858: new 412	java/lang/StringBuilder
    //   861: dup
    //   862: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   865: ldc_w 716
    //   868: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   871: aload 5
    //   873: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   876: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   879: aload 18
    //   881: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   884: pop
    //   885: goto -727 -> 158
    //   888: astore 16
    //   890: ldc 103
    //   892: new 412	java/lang/StringBuilder
    //   895: dup
    //   896: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   899: ldc_w 716
    //   902: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   905: aload 6
    //   907: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   910: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   913: aload 16
    //   915: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   918: pop
    //   919: goto -751 -> 168
    //   922: astore 33
    //   924: ldc 103
    //   926: new 412	java/lang/StringBuilder
    //   929: dup
    //   930: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   933: ldc_w 716
    //   936: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   939: aload 5
    //   941: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   944: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   947: aload 33
    //   949: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   952: pop
    //   953: goto -233 -> 720
    //   956: astore 31
    //   958: ldc 103
    //   960: new 412	java/lang/StringBuilder
    //   963: dup
    //   964: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   967: ldc_w 716
    //   970: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   973: aload 6
    //   975: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   978: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   981: aload 31
    //   983: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   986: pop
    //   987: goto -257 -> 730
    //   990: astore 44
    //   992: ldc 103
    //   994: new 412	java/lang/StringBuilder
    //   997: dup
    //   998: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   1001: ldc_w 716
    //   1004: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1007: aload 5
    //   1009: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1012: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1015: aload 44
    //   1017: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1020: pop
    //   1021: goto -535 -> 486
    //   1024: astore 42
    //   1026: ldc 103
    //   1028: new 412	java/lang/StringBuilder
    //   1031: dup
    //   1032: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   1035: ldc_w 716
    //   1038: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1041: aconst_null
    //   1042: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1045: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1048: aload 42
    //   1050: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1053: pop
    //   1054: goto -562 -> 492
    //   1057: astore 57
    //   1059: ldc 103
    //   1061: new 412	java/lang/StringBuilder
    //   1064: dup
    //   1065: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   1068: ldc_w 716
    //   1071: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1074: aconst_null
    //   1075: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1078: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1081: aload 57
    //   1083: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1086: pop
    //   1087: goto -787 -> 300
    //   1090: astore 55
    //   1092: ldc 103
    //   1094: new 412	java/lang/StringBuilder
    //   1097: dup
    //   1098: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   1101: ldc_w 716
    //   1104: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1107: aconst_null
    //   1108: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1111: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1114: aload 55
    //   1116: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   1119: pop
    //   1120: goto -814 -> 306
    //
    // Exception table:
    //   from	to	target	type
    //   12	123	123	java/io/FileNotFoundException
    //   248	254	123	java/io/FileNotFoundException
    //   263	287	123	java/io/FileNotFoundException
    //   332	412	123	java/io/FileNotFoundException
    //   435	476	123	java/io/FileNotFoundException
    //   575	710	123	java/io/FileNotFoundException
    //   808	854	123	java/io/FileNotFoundException
    //   12	123	146	finally
    //   125	146	146	finally
    //   248	254	146	finally
    //   263	287	146	finally
    //   332	412	146	finally
    //   414	435	146	finally
    //   435	476	146	finally
    //   575	710	146	finally
    //   808	854	146	finally
    //   263	287	330	java/lang/Exception
    //   12	123	412	java/io/IOException
    //   248	254	412	java/io/IOException
    //   263	287	412	java/io/IOException
    //   332	412	412	java/io/IOException
    //   435	476	412	java/io/IOException
    //   575	710	412	java/io/IOException
    //   808	854	412	java/io/IOException
    //   153	158	854	java/io/IOException
    //   163	168	888	java/io/IOException
    //   715	720	922	java/io/IOException
    //   725	730	956	java/io/IOException
    //   481	486	990	java/io/IOException
    //   490	492	1024	java/io/IOException
    //   298	300	1057	java/io/IOException
    //   304	306	1090	java/io/IOException
  }

  private void setEncodedStringValueToHeaders(Cursor paramCursor, int paramInt1, PduHeaders paramPduHeaders, int paramInt2)
  {
    String str = paramCursor.getString(paramInt1);
    if ((str != null) && (str.length() > 0))
      paramPduHeaders.setEncodedStringValue(new EncodedStringValue(paramCursor.getInt(((Integer)CHARSET_COLUMN_INDEX_MAP.get(Integer.valueOf(paramInt2))).intValue()), getBytes(str)), paramInt2);
  }

  private void setLongToHeaders(Cursor paramCursor, int paramInt1, PduHeaders paramPduHeaders, int paramInt2)
  {
    if (!paramCursor.isNull(paramInt1))
      paramPduHeaders.setLongInteger(paramCursor.getLong(paramInt1), paramInt2);
  }

  private void setOctetToHeaders(Cursor paramCursor, int paramInt1, PduHeaders paramPduHeaders, int paramInt2)
    throws InvalidHeaderValueException
  {
    if (!paramCursor.isNull(paramInt1))
      paramPduHeaders.setOctet(paramCursor.getInt(paramInt1), paramInt2);
  }

  private void setTextStringToHeaders(Cursor paramCursor, int paramInt1, PduHeaders paramPduHeaders, int paramInt2)
  {
    String str = paramCursor.getString(paramInt1);
    if (str != null)
      paramPduHeaders.setTextString(getBytes(str), paramInt2);
  }

  public static String toIsoString(byte[] paramArrayOfByte)
  {
    try
    {
      str = new String(paramArrayOfByte, "iso-8859-1");
      return str;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
      {
        Log.e("PduPersister", "ISO_8859_1 must be supported!", localUnsupportedEncodingException);
        String str = "";
      }
    }
  }

  private void updateAddress(long paramLong, int paramInt, EncodedStringValue[] paramArrayOfEncodedStringValue)
  {
    SqliteWrapper.delete(this.mContext, this.mContentResolver, Uri.parse("content://mms/" + paramLong + "/addr"), "type=" + paramInt, null);
    persistAddress(paramLong, paramInt, paramArrayOfEncodedStringValue);
  }

  private void updatePart(Uri paramUri, PduPart paramPduPart, HashMap<Uri, InputStream> paramHashMap)
    throws MmsException
  {
    ContentValues localContentValues = new ContentValues(7);
    int i = paramPduPart.getCharset();
    if (i != 0)
      localContentValues.put("chset", Integer.valueOf(i));
    if (paramPduPart.getContentType() != null)
    {
      String str = toIsoString(paramPduPart.getContentType());
      localContentValues.put("ct", str);
      if (paramPduPart.getFilename() != null)
        localContentValues.put("fn", new String(paramPduPart.getFilename()));
      if (paramPduPart.getName() != null)
        localContentValues.put("name", new String(paramPduPart.getName()));
      if (paramPduPart.getContentDisposition() != null)
        localContentValues.put("cd", (String)toIsoString(paramPduPart.getContentDisposition()));
      if (paramPduPart.getContentId() != null)
        localContentValues.put("cid", (String)toIsoString(paramPduPart.getContentId()));
      if (paramPduPart.getContentLocation() != null)
        localContentValues.put("cl", (String)toIsoString(paramPduPart.getContentLocation()));
      SqliteWrapper.update(this.mContext, this.mContentResolver, paramUri, localContentValues, null, null);
      if ((paramPduPart.getData() != null) || (paramUri != paramPduPart.getDataUri()))
        persistData(paramPduPart, paramUri, str, paramHashMap);
      return;
    }
    throw new MmsException("MIME type of the part must be set.");
  }

  public Cursor getPendingMessages(long paramLong)
  {
    Uri.Builder localBuilder = Telephony.MmsSms.PendingMessages.CONTENT_URI.buildUpon();
    localBuilder.appendQueryParameter("protocol", "mms");
    String[] arrayOfString = new String[2];
    arrayOfString[0] = String.valueOf(10);
    arrayOfString[1] = String.valueOf(paramLong);
    return SqliteWrapper.query(this.mContext, this.mContentResolver, localBuilder.build(), null, "err_type < ? AND due_time <= ?", arrayOfString, "due_time");
  }

  // ERROR //
  public GenericPdu load(Uri paramUri)
    throws MmsException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: iconst_0
    //   3: istore_3
    //   4: ldc2_w 809
    //   7: lstore 4
    //   9: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   12: astore 11
    //   14: aload 11
    //   16: monitorenter
    //   17: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   20: aload_1
    //   21: invokevirtual 814	com/google/android/mms/util/PduCache:isUpdating	(Landroid/net/Uri;)Z
    //   24: istore 13
    //   26: iload 13
    //   28: ifeq +141 -> 169
    //   31: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   34: invokevirtual 817	java/lang/Object:wait	()V
    //   37: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   40: aload_1
    //   41: invokevirtual 818	com/google/android/mms/util/PduCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   44: checkcast 820	com/google/android/mms/util/PduCacheEntry
    //   47: astore_2
    //   48: aload_2
    //   49: ifnull +120 -> 169
    //   52: aload_2
    //   53: invokevirtual 824	com/google/android/mms/util/PduCacheEntry:getPdu	()Lcom/google/android/mms/pdu/GenericPdu;
    //   56: astore 31
    //   58: aload 11
    //   60: monitorexit
    //   61: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   64: astore 50
    //   66: aload 50
    //   68: monitorenter
    //   69: iconst_0
    //   70: ifeq +1018 -> 1088
    //   73: getstatic 128	com/google/android/mms/pdu/PduPersister:$assertionsDisabled	Z
    //   76: ifne +989 -> 1065
    //   79: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   82: aload_1
    //   83: invokevirtual 818	com/google/android/mms/util/PduCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   86: ifnull +979 -> 1065
    //   89: new 826	java/lang/AssertionError
    //   92: dup
    //   93: invokespecial 827	java/lang/AssertionError:<init>	()V
    //   96: athrow
    //   97: aload 50
    //   99: monitorexit
    //   100: aload 51
    //   102: athrow
    //   103: astore 48
    //   105: ldc 103
    //   107: ldc_w 829
    //   110: aload 48
    //   112: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   115: pop
    //   116: goto -79 -> 37
    //   119: aload 11
    //   121: monitorexit
    //   122: aload 12
    //   124: athrow
    //   125: astore 6
    //   127: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   130: astore 7
    //   132: aload 7
    //   134: monitorenter
    //   135: iconst_0
    //   136: ifeq +861 -> 997
    //   139: getstatic 128	com/google/android/mms/pdu/PduPersister:$assertionsDisabled	Z
    //   142: ifne +832 -> 974
    //   145: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   148: aload_1
    //   149: invokevirtual 818	com/google/android/mms/util/PduCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   152: ifnull +822 -> 974
    //   155: new 826	java/lang/AssertionError
    //   158: dup
    //   159: invokespecial 827	java/lang/AssertionError:<init>	()V
    //   162: athrow
    //   163: aload 7
    //   165: monitorexit
    //   166: aload 8
    //   168: athrow
    //   169: aload_2
    //   170: pop
    //   171: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   174: aload_1
    //   175: iconst_1
    //   176: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   179: aload 11
    //   181: monitorexit
    //   182: aload_0
    //   183: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   186: aload_0
    //   187: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   190: aload_1
    //   191: getstatic 188	com/google/android/mms/pdu/PduPersister:PDU_PROJECTION	[Ljava/lang/String;
    //   194: aconst_null
    //   195: aconst_null
    //   196: aconst_null
    //   197: invokestatic 440	com/google/android/mms/util/SqliteWrapper:query	(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   200: astore 15
    //   202: new 464	com/google/android/mms/pdu/PduHeaders
    //   205: dup
    //   206: invokespecial 834	com/google/android/mms/pdu/PduHeaders:<init>	()V
    //   209: astore 16
    //   211: aload_1
    //   212: invokestatic 840	android/content/ContentUris:parseId	(Landroid/net/Uri;)J
    //   215: lstore 17
    //   217: aload 15
    //   219: ifnull +24 -> 243
    //   222: aload 15
    //   224: invokeinterface 336 1 0
    //   229: iconst_1
    //   230: if_icmpne +13 -> 243
    //   233: aload 15
    //   235: invokeinterface 339 1 0
    //   240: ifne +53 -> 293
    //   243: new 475	com/google/android/mms/MmsException
    //   246: dup
    //   247: new 412	java/lang/StringBuilder
    //   250: dup
    //   251: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   254: ldc_w 842
    //   257: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: aload_1
    //   261: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   264: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   267: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   270: athrow
    //   271: astore 19
    //   273: aload 15
    //   275: ifnull +10 -> 285
    //   278: aload 15
    //   280: invokeinterface 351 1 0
    //   285: aload 19
    //   287: athrow
    //   288: astore 6
    //   290: goto -163 -> 127
    //   293: aload 15
    //   295: iconst_1
    //   296: invokeinterface 390 2 0
    //   301: istore_3
    //   302: aload 15
    //   304: iconst_2
    //   305: invokeinterface 514 2 0
    //   310: lstore 4
    //   312: getstatic 244	com/google/android/mms/pdu/PduPersister:ENCODED_STRING_COLUMN_INDEX_MAP	Ljava/util/HashMap;
    //   315: invokevirtual 846	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   318: invokeinterface 852 1 0
    //   323: astore 20
    //   325: aload 20
    //   327: invokeinterface 857 1 0
    //   332: ifeq +52 -> 384
    //   335: aload 20
    //   337: invokeinterface 861 1 0
    //   342: checkcast 863	java/util/Map$Entry
    //   345: astore 47
    //   347: aload_0
    //   348: aload 15
    //   350: aload 47
    //   352: invokeinterface 866 1 0
    //   357: checkcast 221	java/lang/Integer
    //   360: invokevirtual 485	java/lang/Integer:intValue	()I
    //   363: aload 16
    //   365: aload 47
    //   367: invokeinterface 869 1 0
    //   372: checkcast 221	java/lang/Integer
    //   375: invokevirtual 485	java/lang/Integer:intValue	()I
    //   378: invokespecial 871	com/google/android/mms/pdu/PduPersister:setEncodedStringValueToHeaders	(Landroid/database/Cursor;ILcom/google/android/mms/pdu/PduHeaders;I)V
    //   381: goto -56 -> 325
    //   384: getstatic 248	com/google/android/mms/pdu/PduPersister:TEXT_STRING_COLUMN_INDEX_MAP	Ljava/util/HashMap;
    //   387: invokevirtual 846	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   390: invokeinterface 852 1 0
    //   395: astore 21
    //   397: aload 21
    //   399: invokeinterface 857 1 0
    //   404: ifeq +52 -> 456
    //   407: aload 21
    //   409: invokeinterface 861 1 0
    //   414: checkcast 863	java/util/Map$Entry
    //   417: astore 46
    //   419: aload_0
    //   420: aload 15
    //   422: aload 46
    //   424: invokeinterface 866 1 0
    //   429: checkcast 221	java/lang/Integer
    //   432: invokevirtual 485	java/lang/Integer:intValue	()I
    //   435: aload 16
    //   437: aload 46
    //   439: invokeinterface 869 1 0
    //   444: checkcast 221	java/lang/Integer
    //   447: invokevirtual 485	java/lang/Integer:intValue	()I
    //   450: invokespecial 873	com/google/android/mms/pdu/PduPersister:setTextStringToHeaders	(Landroid/database/Cursor;ILcom/google/android/mms/pdu/PduHeaders;I)V
    //   453: goto -56 -> 397
    //   456: getstatic 252	com/google/android/mms/pdu/PduPersister:OCTET_COLUMN_INDEX_MAP	Ljava/util/HashMap;
    //   459: invokevirtual 846	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   462: invokeinterface 852 1 0
    //   467: astore 22
    //   469: aload 22
    //   471: invokeinterface 857 1 0
    //   476: ifeq +52 -> 528
    //   479: aload 22
    //   481: invokeinterface 861 1 0
    //   486: checkcast 863	java/util/Map$Entry
    //   489: astore 45
    //   491: aload_0
    //   492: aload 15
    //   494: aload 45
    //   496: invokeinterface 866 1 0
    //   501: checkcast 221	java/lang/Integer
    //   504: invokevirtual 485	java/lang/Integer:intValue	()I
    //   507: aload 16
    //   509: aload 45
    //   511: invokeinterface 869 1 0
    //   516: checkcast 221	java/lang/Integer
    //   519: invokevirtual 485	java/lang/Integer:intValue	()I
    //   522: invokespecial 875	com/google/android/mms/pdu/PduPersister:setOctetToHeaders	(Landroid/database/Cursor;ILcom/google/android/mms/pdu/PduHeaders;I)V
    //   525: goto -56 -> 469
    //   528: getstatic 256	com/google/android/mms/pdu/PduPersister:LONG_COLUMN_INDEX_MAP	Ljava/util/HashMap;
    //   531: invokevirtual 846	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   534: invokeinterface 852 1 0
    //   539: astore 23
    //   541: aload 23
    //   543: invokeinterface 857 1 0
    //   548: ifeq +52 -> 600
    //   551: aload 23
    //   553: invokeinterface 861 1 0
    //   558: checkcast 863	java/util/Map$Entry
    //   561: astore 44
    //   563: aload_0
    //   564: aload 15
    //   566: aload 44
    //   568: invokeinterface 866 1 0
    //   573: checkcast 221	java/lang/Integer
    //   576: invokevirtual 485	java/lang/Integer:intValue	()I
    //   579: aload 16
    //   581: aload 44
    //   583: invokeinterface 869 1 0
    //   588: checkcast 221	java/lang/Integer
    //   591: invokevirtual 485	java/lang/Integer:intValue	()I
    //   594: invokespecial 877	com/google/android/mms/pdu/PduPersister:setLongToHeaders	(Landroid/database/Cursor;ILcom/google/android/mms/pdu/PduHeaders;I)V
    //   597: goto -56 -> 541
    //   600: aload 15
    //   602: ifnull +10 -> 612
    //   605: aload 15
    //   607: invokeinterface 351 1 0
    //   612: lload 17
    //   614: ldc2_w 809
    //   617: lcmp
    //   618: ifne +14 -> 632
    //   621: new 475	com/google/android/mms/MmsException
    //   624: dup
    //   625: ldc_w 879
    //   628: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   631: athrow
    //   632: aload_0
    //   633: lload 17
    //   635: aload 16
    //   637: invokespecial 881	com/google/android/mms/pdu/PduPersister:loadAddress	(JLcom/google/android/mms/pdu/PduHeaders;)V
    //   640: aload 16
    //   642: sipush 140
    //   645: invokevirtual 884	com/google/android/mms/pdu/PduHeaders:getOctet	(I)I
    //   648: istore 24
    //   650: new 886	com/google/android/mms/pdu/PduBody
    //   653: dup
    //   654: invokespecial 887	com/google/android/mms/pdu/PduBody:<init>	()V
    //   657: astore 25
    //   659: iload 24
    //   661: sipush 132
    //   664: if_icmpeq +11 -> 675
    //   667: iload 24
    //   669: sipush 128
    //   672: if_icmpne +474 -> 1146
    //   675: aload_0
    //   676: lload 17
    //   678: invokespecial 889	com/google/android/mms/pdu/PduPersister:loadParts	(J)[Lcom/google/android/mms/pdu/PduPart;
    //   681: astore 26
    //   683: aload 26
    //   685: ifnull +461 -> 1146
    //   688: aload 26
    //   690: arraylength
    //   691: istore 41
    //   693: iconst_0
    //   694: istore 42
    //   696: iload 42
    //   698: iload 41
    //   700: if_icmpge +446 -> 1146
    //   703: aload 25
    //   705: aload 26
    //   707: iload 42
    //   709: aaload
    //   710: invokevirtual 893	com/google/android/mms/pdu/PduBody:addPart	(Lcom/google/android/mms/pdu/PduPart;)Z
    //   713: pop
    //   714: iinc 42 1
    //   717: goto -21 -> 696
    //   720: new 475	com/google/android/mms/MmsException
    //   723: dup
    //   724: new 412	java/lang/StringBuilder
    //   727: dup
    //   728: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   731: ldc_w 895
    //   734: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   737: iload 24
    //   739: invokestatic 898	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   742: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   745: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   748: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   751: athrow
    //   752: new 900	com/google/android/mms/pdu/NotificationInd
    //   755: dup
    //   756: aload 16
    //   758: invokespecial 903	com/google/android/mms/pdu/NotificationInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   761: astore 40
    //   763: aload 40
    //   765: astore 28
    //   767: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   770: astore 29
    //   772: aload 29
    //   774: monitorenter
    //   775: aload 28
    //   777: ifnull +351 -> 1128
    //   780: getstatic 128	com/google/android/mms/pdu/PduPersister:$assertionsDisabled	Z
    //   783: ifne +234 -> 1017
    //   786: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   789: aload_1
    //   790: invokevirtual 818	com/google/android/mms/util/PduCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   793: ifnull +224 -> 1017
    //   796: new 826	java/lang/AssertionError
    //   799: dup
    //   800: invokespecial 827	java/lang/AssertionError:<init>	()V
    //   803: athrow
    //   804: astore 30
    //   806: aload 29
    //   808: monitorexit
    //   809: aload 30
    //   811: athrow
    //   812: new 905	com/google/android/mms/pdu/DeliveryInd
    //   815: dup
    //   816: aload 16
    //   818: invokespecial 906	com/google/android/mms/pdu/DeliveryInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   821: astore 39
    //   823: aload 39
    //   825: astore 28
    //   827: goto -60 -> 767
    //   830: new 908	com/google/android/mms/pdu/ReadOrigInd
    //   833: dup
    //   834: aload 16
    //   836: invokespecial 909	com/google/android/mms/pdu/ReadOrigInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   839: astore 38
    //   841: aload 38
    //   843: astore 28
    //   845: goto -78 -> 767
    //   848: new 911	com/google/android/mms/pdu/RetrieveConf
    //   851: dup
    //   852: aload 16
    //   854: aload 25
    //   856: invokespecial 914	com/google/android/mms/pdu/RetrieveConf:<init>	(Lcom/google/android/mms/pdu/PduHeaders;Lcom/google/android/mms/pdu/PduBody;)V
    //   859: astore 37
    //   861: aload 37
    //   863: astore 28
    //   865: goto -98 -> 767
    //   868: new 916	com/google/android/mms/pdu/SendReq
    //   871: dup
    //   872: aload 16
    //   874: aload 25
    //   876: invokespecial 917	com/google/android/mms/pdu/SendReq:<init>	(Lcom/google/android/mms/pdu/PduHeaders;Lcom/google/android/mms/pdu/PduBody;)V
    //   879: astore 36
    //   881: aload 36
    //   883: astore 28
    //   885: goto -118 -> 767
    //   888: new 919	com/google/android/mms/pdu/AcknowledgeInd
    //   891: dup
    //   892: aload 16
    //   894: invokespecial 920	com/google/android/mms/pdu/AcknowledgeInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   897: astore 35
    //   899: aload 35
    //   901: astore 28
    //   903: goto -136 -> 767
    //   906: new 922	com/google/android/mms/pdu/NotifyRespInd
    //   909: dup
    //   910: aload 16
    //   912: invokespecial 923	com/google/android/mms/pdu/NotifyRespInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   915: astore 34
    //   917: aload 34
    //   919: astore 28
    //   921: goto -154 -> 767
    //   924: new 925	com/google/android/mms/pdu/ReadRecInd
    //   927: dup
    //   928: aload 16
    //   930: invokespecial 926	com/google/android/mms/pdu/ReadRecInd:<init>	(Lcom/google/android/mms/pdu/PduHeaders;)V
    //   933: astore 27
    //   935: aload 27
    //   937: astore 28
    //   939: goto -172 -> 767
    //   942: new 475	com/google/android/mms/MmsException
    //   945: dup
    //   946: new 412	java/lang/StringBuilder
    //   949: dup
    //   950: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   953: ldc_w 928
    //   956: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   959: iload 24
    //   961: invokestatic 898	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   964: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   967: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   970: invokespecial 558	com/google/android/mms/MmsException:<init>	(Ljava/lang/String;)V
    //   973: athrow
    //   974: new 820	com/google/android/mms/util/PduCacheEntry
    //   977: dup
    //   978: aconst_null
    //   979: iload_3
    //   980: lload 4
    //   982: invokespecial 931	com/google/android/mms/util/PduCacheEntry:<init>	(Lcom/google/android/mms/pdu/GenericPdu;IJ)V
    //   985: astore 9
    //   987: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   990: aload_1
    //   991: aload 9
    //   993: invokevirtual 934	com/google/android/mms/util/PduCache:put	(Landroid/net/Uri;Lcom/google/android/mms/util/PduCacheEntry;)Z
    //   996: pop
    //   997: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1000: aload_1
    //   1001: iconst_0
    //   1002: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   1005: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1008: invokevirtual 937	java/lang/Object:notifyAll	()V
    //   1011: aload 7
    //   1013: monitorexit
    //   1014: aload 6
    //   1016: athrow
    //   1017: new 820	com/google/android/mms/util/PduCacheEntry
    //   1020: dup
    //   1021: aload 28
    //   1023: iload_3
    //   1024: lload 4
    //   1026: invokespecial 931	com/google/android/mms/util/PduCacheEntry:<init>	(Lcom/google/android/mms/pdu/GenericPdu;IJ)V
    //   1029: astore 32
    //   1031: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1034: aload_1
    //   1035: aload 32
    //   1037: invokevirtual 934	com/google/android/mms/util/PduCache:put	(Landroid/net/Uri;Lcom/google/android/mms/util/PduCacheEntry;)Z
    //   1040: pop
    //   1041: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1044: aload_1
    //   1045: iconst_0
    //   1046: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   1049: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1052: invokevirtual 937	java/lang/Object:notifyAll	()V
    //   1055: aload 29
    //   1057: monitorexit
    //   1058: aload 28
    //   1060: astore 31
    //   1062: aload 31
    //   1064: areturn
    //   1065: new 820	com/google/android/mms/util/PduCacheEntry
    //   1068: dup
    //   1069: aconst_null
    //   1070: iconst_0
    //   1071: lload 4
    //   1073: invokespecial 931	com/google/android/mms/util/PduCacheEntry:<init>	(Lcom/google/android/mms/pdu/GenericPdu;IJ)V
    //   1076: astore 52
    //   1078: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1081: aload_1
    //   1082: aload 52
    //   1084: invokevirtual 934	com/google/android/mms/util/PduCache:put	(Landroid/net/Uri;Lcom/google/android/mms/util/PduCacheEntry;)Z
    //   1087: pop
    //   1088: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1091: aload_1
    //   1092: iconst_0
    //   1093: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   1096: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   1099: invokevirtual 937	java/lang/Object:notifyAll	()V
    //   1102: aload 50
    //   1104: monitorexit
    //   1105: goto -43 -> 1062
    //   1108: astore 30
    //   1110: goto -304 -> 806
    //   1113: astore 51
    //   1115: goto -1018 -> 97
    //   1118: astore 8
    //   1120: goto -957 -> 163
    //   1123: astore 12
    //   1125: goto -1006 -> 119
    //   1128: goto -87 -> 1041
    //   1131: astore 51
    //   1133: goto -1036 -> 97
    //   1136: astore 12
    //   1138: goto -1019 -> 119
    //   1141: astore 8
    //   1143: goto -980 -> 163
    //   1146: iload 24
    //   1148: tableswitch	default:+-428 -> 720, 128:+-280->868, 129:+-206->942, 130:+-396->752, 131:+-242->906, 132:+-300->848, 133:+-260->888, 134:+-336->812, 135:+-224->924, 136:+-318->830, 137:+-206->942, 138:+-206->942, 139:+-206->942, 140:+-206->942, 141:+-206->942, 142:+-206->942, 143:+-206->942, 144:+-206->942, 145:+-206->942, 146:+-206->942, 147:+-206->942, 148:+-206->942, 149:+-206->942, 150:+-206->942, 151:+-206->942
    //
    // Exception table:
    //   from	to	target	type
    //   31	37	103	java/lang/InterruptedException
    //   9	17	125	finally
    //   122	125	125	finally
    //   222	271	271	finally
    //   293	597	271	finally
    //   182	217	288	finally
    //   278	288	288	finally
    //   605	763	288	finally
    //   812	974	288	finally
    //   780	804	804	finally
    //   1017	1031	804	finally
    //   806	809	1108	finally
    //   1031	1058	1108	finally
    //   1078	1088	1113	finally
    //   987	997	1118	finally
    //   171	182	1123	finally
    //   73	100	1131	finally
    //   1065	1078	1131	finally
    //   1088	1105	1131	finally
    //   17	26	1136	finally
    //   31	37	1136	finally
    //   37	61	1136	finally
    //   105	122	1136	finally
    //   139	166	1141	finally
    //   974	987	1141	finally
    //   997	1014	1141	finally
  }

  public Uri move(Uri paramUri1, Uri paramUri2)
    throws MmsException
  {
    long l = ContentUris.parseId(paramUri1);
    if (l == -1L)
      throw new MmsException("Error! ID of the message: -1.");
    Integer localInteger = (Integer)MESSAGE_BOX_MAP.get(paramUri2);
    if (localInteger == null)
      throw new MmsException("Bad destination, must be one of content://mms/inbox, content://mms/sent, content://mms/drafts, content://mms/outbox, content://mms/temp.");
    ContentValues localContentValues = new ContentValues(1);
    localContentValues.put("msg_box", localInteger);
    SqliteWrapper.update(this.mContext, this.mContentResolver, paramUri1, localContentValues, null, null);
    return ContentUris.withAppendedId(paramUri2, l);
  }

  public Uri persist(GenericPdu paramGenericPdu, Uri paramUri, boolean paramBoolean1, boolean paramBoolean2, HashMap<Uri, InputStream> paramHashMap)
    throws MmsException
  {
    if (paramUri == null)
      throw new MmsException("Uri may not be null.");
    long l1 = -1L;
    label30: Uri localUri;
    try
    {
      long l5 = ContentUris.parseId(paramUri);
      l1 = l5;
      if (l1 != -1L);
      for (int i = 1; (i == 0) && (MESSAGE_BOX_MAP.get(paramUri) == null); i = 0)
        throw new MmsException("Bad destination, must be one of content://mms/inbox, content://mms/sent, content://mms/drafts, content://mms/outbox, content://mms/temp.");
      PduHeaders localPduHeaders;
      ContentValues localContentValues1;
      synchronized (PDU_CACHE_INSTANCE)
      {
        boolean bool = PDU_CACHE_INSTANCE.isUpdating(paramUri);
        if (bool);
        try
        {
          PDU_CACHE_INSTANCE.wait();
          PDU_CACHE_INSTANCE.purge(paramUri);
          localPduHeaders = paramGenericPdu.getPduHeaders();
          localContentValues1 = new ContentValues();
          Iterator localIterator1 = ENCODED_STRING_COLUMN_NAME_MAP.entrySet().iterator();
          while (localIterator1.hasNext())
          {
            Map.Entry localEntry4 = (Map.Entry)localIterator1.next();
            int i9 = ((Integer)localEntry4.getKey()).intValue();
            EncodedStringValue localEncodedStringValue2 = localPduHeaders.getEncodedStringValue(i9);
            if (localEncodedStringValue2 != null)
            {
              String str2 = (String)CHARSET_COLUMN_NAME_MAP.get(Integer.valueOf(i9));
              localContentValues1.put((String)localEntry4.getValue(), toIsoString(localEncodedStringValue2.getTextString()));
              localContentValues1.put(str2, Integer.valueOf(localEncodedStringValue2.getCharacterSet()));
            }
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            Log.e("PduPersister", "persist1: ", localInterruptedException);
        }
      }
      Iterator localIterator2 = TEXT_STRING_COLUMN_NAME_MAP.entrySet().iterator();
      while (localIterator2.hasNext())
      {
        Map.Entry localEntry3 = (Map.Entry)localIterator2.next();
        byte[] arrayOfByte = localPduHeaders.getTextString(((Integer)localEntry3.getKey()).intValue());
        if (arrayOfByte != null)
          localContentValues1.put((String)localEntry3.getValue(), toIsoString(arrayOfByte));
      }
      Iterator localIterator3 = OCTET_COLUMN_NAME_MAP.entrySet().iterator();
      while (localIterator3.hasNext())
      {
        Map.Entry localEntry2 = (Map.Entry)localIterator3.next();
        int i8 = localPduHeaders.getOctet(((Integer)localEntry2.getKey()).intValue());
        if (i8 != 0)
          localContentValues1.put((String)localEntry2.getValue(), Integer.valueOf(i8));
      }
      Iterator localIterator4 = LONG_COLUMN_NAME_MAP.entrySet().iterator();
      while (localIterator4.hasNext())
      {
        Map.Entry localEntry1 = (Map.Entry)localIterator4.next();
        long l4 = localPduHeaders.getLongInteger(((Integer)localEntry1.getKey()).intValue());
        if (l4 != -1L)
          localContentValues1.put((String)localEntry1.getValue(), Long.valueOf(l4));
      }
      HashMap localHashMap = new HashMap(ADDRESS_FIELDS.length);
      int[] arrayOfInt1 = ADDRESS_FIELDS;
      int j = arrayOfInt1.length;
      int k = 0;
      if (k < j)
      {
        int i7 = arrayOfInt1[k];
        EncodedStringValue[] arrayOfEncodedStringValue2 = null;
        if (i7 == 137)
        {
          EncodedStringValue localEncodedStringValue1 = localPduHeaders.getEncodedStringValue(i7);
          if (localEncodedStringValue1 != null)
          {
            arrayOfEncodedStringValue2 = new EncodedStringValue[1];
            arrayOfEncodedStringValue2[0] = localEncodedStringValue1;
          }
        }
        while (true)
        {
          localHashMap.put(Integer.valueOf(i7), arrayOfEncodedStringValue2);
          k++;
          break;
          arrayOfEncodedStringValue2 = localPduHeaders.getEncodedStringValues(i7);
        }
      }
      HashSet localHashSet = new HashSet();
      int m = paramGenericPdu.getMessageType();
      if ((m == 130) || (m == 132) || (m == 128))
        switch (m)
        {
        case 129:
        case 131:
        default:
        case 130:
        case 132:
        case 128:
        }
      long l3;
      int n;
      while (true)
      {
        long l2 = 0L;
        if ((paramBoolean1) && (!localHashSet.isEmpty()))
          l2 = Telephony.Threads.getOrCreateThreadId(this.mContext, localHashSet);
        localContentValues1.put("thread_id", Long.valueOf(l2));
        l3 = System.currentTimeMillis();
        n = 1;
        if (!(paramGenericPdu instanceof MultimediaMessagePdu))
          break;
        PduBody localPduBody = ((MultimediaMessagePdu)paramGenericPdu).getBody();
        if (localPduBody == null)
          break;
        int i5 = localPduBody.getPartsNum();
        if (i5 > 2)
          n = 0;
        for (int i6 = 0; i6 < i5; i6++)
        {
          PduPart localPduPart = localPduBody.getPart(i6);
          persistPart(localPduPart, l3, paramHashMap);
          String str1 = getPartContentType(localPduPart);
          if ((str1 != null) && (!"application/smil".equals(str1)) && (!"text/plain".equals(str1)))
            n = 0;
        }
        loadRecipients(137, localHashSet, localHashMap, false);
        if (paramBoolean2)
        {
          loadRecipients(151, localHashSet, localHashMap, true);
          continue;
          loadRecipients(151, localHashSet, localHashMap, false);
        }
      }
      int i1;
      if (n != 0)
      {
        i1 = 1;
        localContentValues1.put("text_only", Integer.valueOf(i1));
        if (i == 0)
          break label1131;
        localUri = paramUri;
        SqliteWrapper.update(this.mContext, this.mContentResolver, localUri, localContentValues1, null, null);
      }
      while (true)
      {
        ContentValues localContentValues2 = new ContentValues(1);
        localContentValues2.put("mid", Long.valueOf(l1));
        SqliteWrapper.update(this.mContext, this.mContentResolver, Uri.parse("content://mms/" + l3 + "/part"), localContentValues2, null, null);
        if (i == 0)
          localUri = Uri.parse(paramUri + "/" + l1);
        for (int i4 : ADDRESS_FIELDS)
        {
          EncodedStringValue[] arrayOfEncodedStringValue1 = (EncodedStringValue[])localHashMap.get(Integer.valueOf(i4));
          if (arrayOfEncodedStringValue1 != null)
            persistAddress(l1, i4, arrayOfEncodedStringValue1);
        }
        i1 = 0;
        break;
        label1131: localUri = SqliteWrapper.insert(this.mContext, this.mContentResolver, paramUri, localContentValues1);
        if (localUri == null)
          throw new MmsException("persist() failed: return null.");
        l1 = ContentUris.parseId(localUri);
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      break label30;
    }
    return localUri;
  }

  public Uri persistPart(PduPart paramPduPart, long paramLong, HashMap<Uri, InputStream> paramHashMap)
    throws MmsException
  {
    Uri localUri1 = Uri.parse("content://mms/" + paramLong + "/part");
    ContentValues localContentValues = new ContentValues(8);
    int i = paramPduPart.getCharset();
    if (i != 0)
      localContentValues.put("chset", Integer.valueOf(i));
    String str = getPartContentType(paramPduPart);
    Uri localUri2;
    if (str != null)
    {
      if ("image/jpg".equals(str))
        str = "image/jpeg";
      localContentValues.put("ct", str);
      if ("application/smil".equals(str))
        localContentValues.put("seq", Integer.valueOf(-1));
      if (paramPduPart.getFilename() != null)
        localContentValues.put("fn", new String(paramPduPart.getFilename()));
      if (paramPduPart.getName() != null)
        localContentValues.put("name", new String(paramPduPart.getName()));
      if (paramPduPart.getContentDisposition() != null)
        localContentValues.put("cd", (String)toIsoString(paramPduPart.getContentDisposition()));
      if (paramPduPart.getContentId() != null)
        localContentValues.put("cid", (String)toIsoString(paramPduPart.getContentId()));
      if (paramPduPart.getContentLocation() != null)
        localContentValues.put("cl", (String)toIsoString(paramPduPart.getContentLocation()));
      localUri2 = SqliteWrapper.insert(this.mContext, this.mContentResolver, localUri1, localContentValues);
      if (localUri2 == null)
        throw new MmsException("Failed to persist part, return null.");
    }
    else
    {
      throw new MmsException("MIME type of the part must be set.");
    }
    persistData(paramPduPart, localUri2, str, paramHashMap);
    paramPduPart.setDataUri(localUri2);
    return localUri2;
  }

  public void release()
  {
    Uri localUri = Uri.parse("content://mms/9223372036854775807/part");
    SqliteWrapper.delete(this.mContext, this.mContentResolver, localUri, null, null);
  }

  public void updateHeaders(Uri paramUri, SendReq paramSendReq)
  {
    ContentValues localContentValues;
    HashSet localHashSet;
    while (true)
    {
      PduHeaders localPduHeaders;
      int n;
      int i1;
      synchronized (PDU_CACHE_INSTANCE)
      {
        boolean bool = PDU_CACHE_INSTANCE.isUpdating(paramUri);
        if (bool);
        try
        {
          PDU_CACHE_INSTANCE.wait();
          PDU_CACHE_INSTANCE.purge(paramUri);
          localContentValues = new ContentValues(10);
          byte[] arrayOfByte1 = paramSendReq.getContentType();
          if (arrayOfByte1 != null)
            localContentValues.put("ct_t", toIsoString(arrayOfByte1));
          long l1 = paramSendReq.getDate();
          if (l1 != -1L)
            localContentValues.put("date", Long.valueOf(l1));
          int i = paramSendReq.getDeliveryReport();
          if (i != 0)
            localContentValues.put("d_rpt", Integer.valueOf(i));
          long l2 = paramSendReq.getExpiry();
          if (l2 != -1L)
            localContentValues.put("exp", Long.valueOf(l2));
          byte[] arrayOfByte2 = paramSendReq.getMessageClass();
          if (arrayOfByte2 != null)
            localContentValues.put("m_cls", toIsoString(arrayOfByte2));
          int j = paramSendReq.getPriority();
          if (j != 0)
            localContentValues.put("pri", Integer.valueOf(j));
          int k = paramSendReq.getReadReport();
          if (k != 0)
            localContentValues.put("rr", Integer.valueOf(k));
          byte[] arrayOfByte3 = paramSendReq.getTransactionId();
          if (arrayOfByte3 != null)
            localContentValues.put("tr_id", toIsoString(arrayOfByte3));
          EncodedStringValue localEncodedStringValue1 = paramSendReq.getSubject();
          if (localEncodedStringValue1 != null)
          {
            localContentValues.put("sub", toIsoString(localEncodedStringValue1.getTextString()));
            localContentValues.put("sub_cs", Integer.valueOf(localEncodedStringValue1.getCharacterSet()));
            long l3 = paramSendReq.getMessageSize();
            if (l3 > 0L)
              localContentValues.put("m_size", Long.valueOf(l3));
            localPduHeaders = paramSendReq.getPduHeaders();
            localHashSet = new HashSet();
            int[] arrayOfInt = ADDRESS_FIELDS;
            int m = arrayOfInt.length;
            n = 0;
            if (n >= m)
              break;
            i1 = arrayOfInt[n];
            arrayOfEncodedStringValue1 = null;
            if (i1 != 137)
              break label492;
            EncodedStringValue localEncodedStringValue3 = localPduHeaders.getEncodedStringValue(i1);
            if (localEncodedStringValue3 != null)
              arrayOfEncodedStringValue1 = new EncodedStringValue[] { localEncodedStringValue3 };
            if (arrayOfEncodedStringValue1 == null)
              break label504;
            updateAddress(ContentUris.parseId(paramUri), i1, arrayOfEncodedStringValue1);
            if (i1 != 151)
              break label504;
            EncodedStringValue[] arrayOfEncodedStringValue2 = arrayOfEncodedStringValue1;
            int i2 = arrayOfEncodedStringValue2.length;
            int i3 = 0;
            if (i3 >= i2)
              break label504;
            EncodedStringValue localEncodedStringValue2 = arrayOfEncodedStringValue2[i3];
            if (localEncodedStringValue2 != null)
              localHashSet.add(localEncodedStringValue2.getString());
            i3++;
            continue;
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          Log.e("PduPersister", "updateHeaders: ", localInterruptedException);
          continue;
        }
      }
      localContentValues.put("sub", "");
      continue;
      label492: EncodedStringValue[] arrayOfEncodedStringValue1 = localPduHeaders.getEncodedStringValues(i1);
      continue;
      label504: n++;
    }
    if (!localHashSet.isEmpty())
      localContentValues.put("thread_id", Long.valueOf(Telephony.Threads.getOrCreateThreadId(this.mContext, localHashSet)));
    SqliteWrapper.update(this.mContext, this.mContentResolver, paramUri, localContentValues, null, null);
  }

  // ERROR //
  public void updateParts(Uri paramUri, PduBody paramPduBody, HashMap<Uri, InputStream> paramHashMap)
    throws MmsException
  {
    // Byte code:
    //   0: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   3: astore 7
    //   5: aload 7
    //   7: monitorenter
    //   8: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   11: aload_1
    //   12: invokevirtual 814	com/google/android/mms/util/PduCache:isUpdating	(Landroid/net/Uri;)Z
    //   15: istore 9
    //   17: iload 9
    //   19: ifeq +38 -> 57
    //   22: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   25: invokevirtual 817	java/lang/Object:wait	()V
    //   28: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   31: aload_1
    //   32: invokevirtual 818	com/google/android/mms/util/PduCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   35: checkcast 820	com/google/android/mms/util/PduCacheEntry
    //   38: astore 38
    //   40: aload 38
    //   42: ifnull +15 -> 57
    //   45: aload 38
    //   47: invokevirtual 824	com/google/android/mms/util/PduCacheEntry:getPdu	()Lcom/google/android/mms/pdu/GenericPdu;
    //   50: checkcast 1005	com/google/android/mms/pdu/MultimediaMessagePdu
    //   53: aload_2
    //   54: invokevirtual 1083	com/google/android/mms/pdu/MultimediaMessagePdu:setBody	(Lcom/google/android/mms/pdu/PduBody;)V
    //   57: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   60: aload_1
    //   61: iconst_1
    //   62: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   65: aload 7
    //   67: monitorexit
    //   68: new 1085	java/util/ArrayList
    //   71: dup
    //   72: invokespecial 1086	java/util/ArrayList:<init>	()V
    //   75: astore 10
    //   77: new 208	java/util/HashMap
    //   80: dup
    //   81: invokespecial 211	java/util/HashMap:<init>	()V
    //   84: astore 11
    //   86: aload_2
    //   87: invokevirtual 1012	com/google/android/mms/pdu/PduBody:getPartsNum	()I
    //   90: istore 12
    //   92: new 412	java/lang/StringBuilder
    //   95: dup
    //   96: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   99: bipush 40
    //   101: invokevirtual 1089	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   104: astore 13
    //   106: iconst_0
    //   107: istore 14
    //   109: iload 14
    //   111: iload 12
    //   113: if_icmpge +163 -> 276
    //   116: aload_2
    //   117: iload 14
    //   119: invokevirtual 1016	com/google/android/mms/pdu/PduBody:getPart	(I)Lcom/google/android/mms/pdu/PduPart;
    //   122: astore 29
    //   124: aload 29
    //   126: invokevirtual 680	com/google/android/mms/pdu/PduPart:getDataUri	()Landroid/net/Uri;
    //   129: astore 30
    //   131: aload 30
    //   133: ifnull +17 -> 150
    //   136: aload 30
    //   138: invokevirtual 1092	android/net/Uri:getAuthority	()Ljava/lang/String;
    //   141: ldc_w 786
    //   144: invokevirtual 1095	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   147: ifne +71 -> 218
    //   150: aload 10
    //   152: aload 29
    //   154: invokevirtual 1096	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   157: pop
    //   158: iinc 14 1
    //   161: goto -52 -> 109
    //   164: astore 36
    //   166: ldc 103
    //   168: ldc_w 1098
    //   171: aload 36
    //   173: invokestatic 384	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   176: pop
    //   177: goto -149 -> 28
    //   180: astore 8
    //   182: aload 7
    //   184: monitorexit
    //   185: aload 8
    //   187: athrow
    //   188: astore 4
    //   190: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   193: astore 5
    //   195: aload 5
    //   197: monitorenter
    //   198: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   201: aload_1
    //   202: iconst_0
    //   203: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   206: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   209: invokevirtual 937	java/lang/Object:notifyAll	()V
    //   212: aload 5
    //   214: monitorexit
    //   215: aload 4
    //   217: athrow
    //   218: aload 11
    //   220: aload 30
    //   222: aload 29
    //   224: invokevirtual 229	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   227: pop
    //   228: aload 13
    //   230: invokevirtual 1099	java/lang/StringBuilder:length	()I
    //   233: iconst_1
    //   234: if_icmple +12 -> 246
    //   237: aload 13
    //   239: ldc_w 1101
    //   242: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   245: pop
    //   246: aload 13
    //   248: ldc 134
    //   250: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload 13
    //   256: ldc_w 1103
    //   259: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   262: pop
    //   263: aload 13
    //   265: aload 30
    //   267: invokevirtual 1106	android/net/Uri:getLastPathSegment	()Ljava/lang/String;
    //   270: invokestatic 1112	android/database/DatabaseUtils:appendEscapedSQLString	(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    //   273: goto -115 -> 158
    //   276: aload 13
    //   278: bipush 41
    //   280: invokevirtual 1089	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   283: pop
    //   284: aload_1
    //   285: invokestatic 840	android/content/ContentUris:parseId	(Landroid/net/Uri;)J
    //   288: lstore 16
    //   290: aload_0
    //   291: getfield 270	com/google/android/mms/pdu/PduPersister:mContext	Landroid/content/Context;
    //   294: astore 18
    //   296: aload_0
    //   297: getfield 278	com/google/android/mms/pdu/PduPersister:mContentResolver	Landroid/content/ContentResolver;
    //   300: astore 19
    //   302: new 412	java/lang/StringBuilder
    //   305: dup
    //   306: invokespecial 413	java/lang/StringBuilder:<init>	()V
    //   309: getstatic 1115	android/provider/Telephony$Mms:CONTENT_URI	Landroid/net/Uri;
    //   312: invokevirtual 683	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   315: ldc_w 1030
    //   318: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: lload 16
    //   323: invokevirtual 422	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   326: ldc_w 479
    //   329: invokevirtual 419	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   335: invokestatic 429	android/net/Uri:parse	(Ljava/lang/String;)Landroid/net/Uri;
    //   338: astore 20
    //   340: aload 13
    //   342: invokevirtual 1099	java/lang/StringBuilder:length	()I
    //   345: iconst_2
    //   346: if_icmple +165 -> 511
    //   349: aload 13
    //   351: invokevirtual 425	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   354: astore 21
    //   356: aload 18
    //   358: aload 19
    //   360: aload 20
    //   362: aload 21
    //   364: aconst_null
    //   365: invokestatic 747	com/google/android/mms/util/SqliteWrapper:delete	(Landroid/content/Context;Landroid/content/ContentResolver;Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    //   368: pop
    //   369: aload 10
    //   371: invokevirtual 1116	java/util/ArrayList:iterator	()Ljava/util/Iterator;
    //   374: astore 23
    //   376: aload 23
    //   378: invokeinterface 857 1 0
    //   383: ifeq +24 -> 407
    //   386: aload_0
    //   387: aload 23
    //   389: invokeinterface 861 1 0
    //   394: checkcast 394	com/google/android/mms/pdu/PduPart
    //   397: lload 16
    //   399: aload_3
    //   400: invokevirtual 1020	com/google/android/mms/pdu/PduPersister:persistPart	(Lcom/google/android/mms/pdu/PduPart;JLjava/util/HashMap;)Landroid/net/Uri;
    //   403: pop
    //   404: goto -28 -> 376
    //   407: aload 11
    //   409: invokevirtual 846	java/util/HashMap:entrySet	()Ljava/util/Set;
    //   412: invokeinterface 852 1 0
    //   417: astore 24
    //   419: aload 24
    //   421: invokeinterface 857 1 0
    //   426: ifeq +43 -> 469
    //   429: aload 24
    //   431: invokeinterface 861 1 0
    //   436: checkcast 863	java/util/Map$Entry
    //   439: astore 27
    //   441: aload_0
    //   442: aload 27
    //   444: invokeinterface 869 1 0
    //   449: checkcast 300	android/net/Uri
    //   452: aload 27
    //   454: invokeinterface 866 1 0
    //   459: checkcast 394	com/google/android/mms/pdu/PduPart
    //   462: aload_3
    //   463: invokespecial 1118	com/google/android/mms/pdu/PduPersister:updatePart	(Landroid/net/Uri;Lcom/google/android/mms/pdu/PduPart;Ljava/util/HashMap;)V
    //   466: goto -47 -> 419
    //   469: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   472: astore 25
    //   474: aload 25
    //   476: monitorenter
    //   477: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   480: aload_1
    //   481: iconst_0
    //   482: invokevirtual 833	com/google/android/mms/util/PduCache:setUpdating	(Landroid/net/Uri;Z)V
    //   485: getstatic 266	com/google/android/mms/pdu/PduPersister:PDU_CACHE_INSTANCE	Lcom/google/android/mms/util/PduCache;
    //   488: invokevirtual 937	java/lang/Object:notifyAll	()V
    //   491: aload 25
    //   493: monitorexit
    //   494: return
    //   495: astore 6
    //   497: aload 5
    //   499: monitorexit
    //   500: aload 6
    //   502: athrow
    //   503: astore 26
    //   505: aload 25
    //   507: monitorexit
    //   508: aload 26
    //   510: athrow
    //   511: aconst_null
    //   512: astore 21
    //   514: goto -158 -> 356
    //
    // Exception table:
    //   from	to	target	type
    //   22	28	164	java/lang/InterruptedException
    //   8	17	180	finally
    //   22	28	180	finally
    //   28	68	180	finally
    //   166	185	180	finally
    //   0	8	188	finally
    //   68	158	188	finally
    //   185	188	188	finally
    //   218	466	188	finally
    //   198	215	495	finally
    //   497	500	495	finally
    //   477	494	503	finally
    //   505	508	503	finally
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.mms.pdu.PduPersister
 * JD-Core Version:    0.6.2
 */