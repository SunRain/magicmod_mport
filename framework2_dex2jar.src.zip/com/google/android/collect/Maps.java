package com.google.android.collect;

import android.util.ArrayMap;
import java.util.HashMap;

public class Maps
{
  public static <K, V> ArrayMap<K, V> newArrayMap()
  {
    return new ArrayMap();
  }

  public static <K, V> HashMap<K, V> newHashMap()
  {
    return new HashMap();
  }
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     com.google.android.collect.Maps
 * JD-Core Version:    0.6.2
 */