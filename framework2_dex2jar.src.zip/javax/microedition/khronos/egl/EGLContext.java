package javax.microedition.khronos.egl;

import com.google.android.gles_jni.EGLImpl;
import javax.microedition.khronos.opengles.GL;

public abstract class EGLContext
{
  private static final EGL EGL_INSTANCE = new EGLImpl();

  public static EGL getEGL()
  {
    return EGL_INSTANCE;
  }

  public abstract GL getGL();
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     javax.microedition.khronos.egl.EGLContext
 * JD-Core Version:    0.6.2
 */