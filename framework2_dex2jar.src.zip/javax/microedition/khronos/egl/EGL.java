package javax.microedition.khronos.egl;

public abstract interface EGL
{
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     javax.microedition.khronos.egl.EGL
 * JD-Core Version:    0.6.2
 */