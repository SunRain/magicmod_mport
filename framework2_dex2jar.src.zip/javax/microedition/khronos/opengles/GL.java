package javax.microedition.khronos.opengles;

public abstract interface GL
{
}

/* Location:           /home/wangguojian/Dev/ROM_KITCHEN/WORKING_miui_n5/system/framework/framework2_dex2jar.jar
 * Qualified Name:     javax.microedition.khronos.opengles.GL
 * JD-Core Version:    0.6.2
 */